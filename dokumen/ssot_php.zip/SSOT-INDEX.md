# SSOT-INDEX — Single Source of Truth Index

> Master navigasi seluruh dokumen SSOT, implementation standard, dan artefak pendukung Platform Kernel.

## Status Dokumen

| Item | Nilai |
|---|---|
| Kode | SSOT-INDEX |
| Judul | Single Source of Truth Index |
| Versi | 2.0 |
| Status | Draft for Review |
| Terakhir disinkronkan | 2026-07-06 |
| Sumber inventaris | Struktur aktual paket `ssot.zip` |

## Legenda

- **✅ Tersedia**: file ditemukan pada paket.
- **⚪ Belum tersedia**: folder/domain tersedia tetapi belum memiliki dokumen.
- Kolom **Status Dokumen** mengikuti metadata di dalam file; keberadaan file tidak berarti dokumen telah berstatus `APPROVED`.

---

# 00. Governance

| Ketersediaan | Kode / Judul | Format | Status Dokumen | Lokasi |
|---|---|---|---|---|
| ✅ | SSOT-GOV-01 — Governance Framework | MD | Draft for Review | [SSOT-GOV-01.md](<00-Governance/SSOT-GOV-01.md>) |
| ✅ | SSOT-GOV-02 — Architecture Decision Records (ADR) | MD | Draft for Review | [SSOT-GOV-02.md](<00-Governance/SSOT-GOV-02.md>) |
| ✅ | SSOT-GOV-03 — Coding Standards | MD | Draft for Review | [SSOT-GOV-03.md](<00-Governance/SSOT-GOV-03.md>) |
| ✅ | SSOT-GOV-04 — Risk, Control & Exception Management | MD | Draft for Review | [SSOT-GOV-04.md](<00-Governance/SSOT-GOV-04.md>) |
| ✅ | SSOT-GOV-05 — Compliance & Audit Governance | MD | Draft for Review | [SSOT-GOV-05.md](<00-Governance/SSOT-GOV-05.md>) |
| ✅ | SSOT-GOV-06 — Change & Release Governance | MD | Draft for Review | [SSOT-GOV-06.md](<00-Governance/SSOT-GOV-06.md>) |
| ✅ | SSOT-GOV-07 — SSOT Repository Integrity, Document Identity & Dependency Validation Governance | MD | Draft Architecture | [SSOT-GOV-07.md](<00-Governance/SSOT-GOV-07.md>) |

---

# 01. Scope

> **Perbaikan 2026-07-07**: SSOT-SCOPE-01 ditambahkan ke index. Ini adalah gap yang dilaporkan sendiri oleh `SSOT-INTEGRITY-REPORT.md` ("Documents Missing From Index: SSOT-SCOPE-01") setelah konsolidasi paket -- alat konsolidasi mendeteksi gap ini tapi tidak memperbaikinya.
>
> **RESOLVED 2026-07-07 (ADR-0001)**: sempat ada peringatan konflik arsitektur di sini karena SSOT-SCOPE-01 ("Tenant, Organization, Facility & Resource Scope Governance", generik, 6 level) TIDAK SAMA dengan SSOT-SCOPE-01A ("Enterprise Scope Hierarchy", 10 level) yang menjadi basis skema `nerslink-mvp`. Keputusan sudah diambil oleh pemilik platform: **SCOPE-01A/02/03/04 tetap otoritatif** untuk hierarchy/schema (status quo, sudah dibangun & diuji, 45 migrasi); **SCOPE-01 superseded** untuk urusan hierarchy/schema, tapi konsep governance-nya (tenant mutation, reconciliation, versioning, delegation) disimpan sebagai backlog kernel masa depan. Detail lengkap: `nerslink-mvp/ADR-0001-scope-hierarchy-authority.md`. Anotasi status juga sudah ditambahkan di `SSOT-SCOPE-01.md` sendiri.

| Ketersediaan | Kode / Judul | Format | Status Dokumen | Lokasi |
|---|---|---|---|---|
| ✅ | SSOT-SCOPE-01 — Tenant, Organization, Facility & Resource Scope Governance | MD | Draft Architecture | [SSOT-SCOPE-01.md](<01-Scope/SSOT-SCOPE-01.md>) |
| ✅ | SSOT-RECORDS-01 — Records, Retention, Legal Hold & Defensible Disposition Governance | MD | Draft Architecture | [SSOT-RECORDS-01.md](<23-Records/SSOT-RECORDS-01.md>) |
| ✅ | SSOT-PRIVACY-01 — Privacy Operations, Data Subject Rights & Request Fulfillment Governance | MD | Draft Architecture | [SSOT-PRIVACY-01.md](<24-Privacy/SSOT-PRIVACY-01.md>) |
| ✅ | SSOT-SCOPE-01A — Enterprise Scope Hierarchy | DOCX | DOCX — status metadata perlu diverifikasi | [SSOT-SCOPE-01A - Enterprise Scope Hierarchy.docx](<01-Scope/SSOT-SCOPE-01A - Enterprise Scope Hierarchy.docx>) |
| ✅ | SSOT-SCOPE-02 — Scope Engine Technical Design | DOCX | DOCX — status metadata perlu diverifikasi | [SSOT-SCOPE-02 - Scope Engine Technical Design.docx](<01-Scope/SSOT-SCOPE-02 - Scope Engine Technical Design.docx>) |
| ✅ | SSOT-SCOPE-03 — Scope Database Migration Blueprint | DOCX | DOCX — status metadata perlu diverifikasi | [SSOT-SCOPE-03 - Scope Database Migration Blueprint.docx](<01-Scope/SSOT-SCOPE-03 - Scope Database Migration Blueprint.docx>) |
| ✅ | SSOT-SCOPE-04 — Scope Resolver & Middleware Implementation Plan | DOCX | DOCX — status metadata perlu diverifikasi | [SSOT-SCOPE-04 Implementation Plan.docx](<01-Scope/SSOT-SCOPE-04 Implementation Plan.docx>) |

---

# 02. IAM

| Ketersediaan | Kode / Judul | Format | Status Dokumen | Lokasi |
|---|---|---|---|---|
| ✅ | SSOT-IAM-01 — User Management Architecture | MD | Draft Architecture | [SSOT-IAM-01.md](<02-IAM/SSOT-IAM-01.md>) |
| ✅ | SSOT-IAM-02 — Authentication Architecture | MD | Draft Architecture | [SSOT-IAM-02.md](<02-IAM/SSOT-IAM-02.md>) |
| ✅ | SSOT-IAM-03 — Session Management Architecture | MD | Status metadata belum tersedia | [SSOT-IAM-03.md](<02-IAM/SSOT-IAM-03.md>) |
| ✅ | SSOT-IAM-04 — MFA & Privileged Access | MD | Status metadata belum tersedia | [SSOT-IAM-04.md](<02-IAM/SSOT-IAM-04.md>) |
| ✅ | SSOT-IAM-05 — API Key & Service Account Architecture | MD | Draft Architecture | [SSOT-IAM-05.md](<02-IAM/SSOT-IAM-05.md>) |
| ✅ | SSOT-IAM-06 — Federation, SSO & External Identity Architecture | MD | Draft Architecture | [SSOT-IAM-06.md](<02-IAM/SSOT-IAM-06.md>) |
| ✅ | SSOT-IAM-07 — Identity Lifecycle Provisioning & Deprovisioning | MD | Draft Architecture | [SSOT-IAM-07.md](<02-IAM/SSOT-IAM-07.md>) |
| ✅ | SSOT-IAM-08 — Identity Risk, Account Recovery & Identity Proofing | MD | Draft Architecture | [SSOT-IAM-08.md](<02-IAM/SSOT-IAM-08.md>) |

---

# 03. RBAC & Dynamic Menu

| Ketersediaan | Kode / Judul | Format | Status Dokumen | Lokasi |
|---|---|---|---|---|
| ✅ | SSOT-MENU-01 — Dynamic Menu Architecture Scope-Aware & RBAC-Aware | DOCX | DOCX — status metadata perlu diverifikasi | [SSOT-MENU-01 - Dynamic Menu Architecture Scope-Aware & RBAC-Aware.docx](<03-RBAC/SSOT-MENU-01 - Dynamic Menu Architecture Scope-Aware & RBAC-Aware.docx>) |
| ✅ | SSOT-MENU-02 — Menu Registry & Contribution Model | MD | Draft Architecture | [SSOT-MENU-02.md](<03-RBAC/SSOT-MENU-02.md>) |
| ✅ | SSOT-MENU-03 — Menu Projection by Role, Scope & Feature Flag | MD | Draft Architecture | [SSOT-MENU-03.md](<03-RBAC/SSOT-MENU-03.md>) |
| ✅ | SSOT-MENU-04 — Navigation Governance & Route Binding | MD | Draft Architecture | [SSOT-MENU-04.md](<03-RBAC/SSOT-MENU-04.md>) |
| ✅ | SSOT-RBAC-01 — Scope-Aware RBAC Architecture Blueprint | DOCX | DOCX — status metadata perlu diverifikasi | [SSOT-RBAC-01 - Scope-Aware RBAC Architecture Blueprint.docx](<03-RBAC/SSOT-RBAC-01 - Scope-Aware RBAC Architecture Blueprint.docx>) |
| ✅ | SSOT-RBAC-02 — RBAC Database Migration + Seed Blueprint | DOCX | DOCX — status metadata perlu diverifikasi | [SSOT-RBAC-02 - RBAC Database Migration + Seed Blueprint.docx](<03-RBAC/SSOT-RBAC-02 - RBAC Database Migration + Seed Blueprint.docx>) |
| ✅ | SSOT-RBAC-03 — Permission Checker & Middleware Implementation Plan | DOCX | DOCX — status metadata perlu diverifikasi | [SSOT-RBAC-03 - Permission Checker & Middleware Implementation Plan.docx](<03-RBAC/SSOT-RBAC-03 - Permission Checker & Middleware Implementation Plan.docx>) |
| ✅ | SSOT-RBAC-04 — Scoped Role Assignment & Authorization Scope | MD | Draft Architecture | [SSOT-RBAC-04.md](<03-RBAC/SSOT-RBAC-04.md>) |
| ✅ | SSOT-RBAC-05 — Policy Enforcement & Authorization Decision Architecture | MD | Draft Architecture | [SSOT-RBAC-05.md](<03-RBAC/SSOT-RBAC-05.md>) |
| ✅ | SSOT-RBAC-06 — Permission Catalog Governance | MD | Draft Architecture | [SSOT-RBAC-06.md](<03-RBAC/SSOT-RBAC-06.md>) |
| ✅ | SSOT-RBAC-07 — Segregation of Duties & Conflict Policy | MD | Draft Architecture | [SSOT-RBAC-07.md](<03-RBAC/SSOT-RBAC-07.md>) |
| ✅ | SSOT-RBAC-08 — Privileged Access & Temporary Grant Governance | MD | Draft Architecture | [SSOT-RBAC-08.md](<03-RBAC/SSOT-RBAC-08.md>) |
| ✅ | SSOT-RBAC-09 — Access Review & Certification Governance | MD | Draft Architecture | [SSOT-RBAC-09.md](<03-RBAC/SSOT-RBAC-09.md>) |
| ✅ | SSOT-RBAC-10 — Role Catalog & Role Lifecycle Governance | MD | Draft Architecture | [SSOT-RBAC-10.md](<03-RBAC/SSOT-RBAC-10.md>) |
| ✅ | SSOT-RBAC-11 — Authorization Reconciliation & Drift Management | MD | Draft Architecture | [SSOT-RBAC-11.md](<03-RBAC/SSOT-RBAC-11.md>) |

---

# 04. Audit

| Ketersediaan | Kode / Judul | Format | Status Dokumen | Lokasi |
|---|---|---|---|---|
| ✅ | SSOT-AUDIT-01 — Audit Trail Architecture | MD | Draft Architecture | [SSOT-AUDIT-01.md](<04-Audit/SSOT-AUDIT-01.md>) |
| ✅ | SSOT-AUDIT-02 — Audit Database | MD | Status metadata belum tersedia | [SSOT-AUDIT-02.md](<04-Audit/SSOT-AUDIT-02.md>) |
| ✅ | SSOT-AUDIT-03 — Audit Logger & Implementation | MD | Status metadata belum tersedia | [SSOT-AUDIT-03.md](<04-Audit/SSOT-AUDIT-03.md>) |

---

# 05. Data

| Ketersediaan | Kode / Judul | Format | Status Dokumen | Lokasi |
|---|---|---|---|---|
| ✅ | SSOT-DATA-01 — Database Standards | MD | Status metadata belum tersedia | [SSOT-DATA-01.md](<05-Data/SSOT-DATA-01.md>) |
| ✅ | SSOT-DATA-02 — Migration & Schema Management | MD | Status metadata belum tersedia | [SSOT-DATA-02.md](<05-Data/SSOT-DATA-02.md>) |
| ✅ | SSOT-DATA-03 — Repository & Data Access Layer | MD | Draft Architecture | [SSOT-DATA-03.md](<05-Data/SSOT-DATA-03.md>) |
| ✅ | SSOT-DATA-04 — Data Lifecycle | MD | Status metadata belum tersedia | [SSOT-DATA-04.md](<05-Data/SSOT-DATA-04.md>) |
| ✅ | SSOT-DATA-05 — Backup & Disaster Recovery | MD | Status metadata belum tersedia | [SSOT-DATA-05.md](<05-Data/SSOT-DATA-05.md>) |
| ✅ | SSOT-DATA-06 — Data Classification, Privacy & Access Governance | MD | Draft Architecture | [SSOT-DATA-06.md](<05-Data/SSOT-DATA-06.md>) |
| ✅ | SSOT-DATA-07 — Data Exchange, Canonical Mapping & Transformation Governance | MD | Draft Architecture | [SSOT-DATA-07.md](<05-Data/SSOT-DATA-07.md>) |
| ✅ | SSOT-DATA-08 — Data Quality Operations, Issue Management & Remediation Governance | MD | Draft Architecture | [SSOT-DATA-08.md](<05-Data/SSOT-DATA-08.md>) |
| ✅ | SSOT-DATA-09 — Data Lifecycle Enforcement, Archival & Secure Disposal Governance | MD | Draft Architecture | [SSOT-DATA-09.md](<05-Data/SSOT-DATA-09.md>) |
| ✅ | SSOT-ANALYTICS-01 — Analytics, Metrics & Semantic Layer Governance | MD | Draft Architecture | [SSOT-ANALYTICS-01.md](<22-Analytics/SSOT-ANALYTICS-01.md>) |

---

# 06. Workflow

| Ketersediaan | Kode / Judul | Format | Status Dokumen | Lokasi |
|---|---|---|---|---|
| ✅ | SSOT-WF-01 — Workflow Engine Architecture | MD | Draft Architecture | [SSOT-WF-01.md](<06-Workflow/SSOT-WF-01.md>) |
| ✅ | SSOT-WF-02 — State Machine | MD | Draft Architecture | [SSOT-WF-02.md](<06-Workflow/SSOT-WF-02.md>) |
| ✅ | SSOT-WF-03 — Approval Engine | MD | Draft Architecture | [SSOT-WF-03.md](<06-Workflow/SSOT-WF-03.md>) |
| ✅ | SSOT-WF-04 — Scheduler & Job Engine | MD | Draft Architecture | [SSOT-WF-04.md](<06-Workflow/SSOT-WF-04.md>) |
| ✅ | SSOT-WF-05 — Workflow Definition Registry & Versioning Governance | MD | Draft Architecture | [SSOT-WF-05.md](<06-Workflow/SSOT-WF-05.md>) |
| ✅ | SSOT-WF-06 — Human Task, Inbox & Assignment Governance | MD | Draft Architecture | [SSOT-WF-06.md](<06-Workflow/SSOT-WF-06.md>) |
| ✅ | SSOT-WF-07 — Workflow Recovery, Compensation & Reconciliation Governance | MD | Draft Architecture | [SSOT-WF-07.md](<06-Workflow/SSOT-WF-07.md>) |

---

# 07. Notification

| Ketersediaan | Kode / Judul | Format | Status Dokumen | Lokasi |
|---|---|---|---|---|
| ✅ | SSOT-NOTIFY-01 — Notification Framework | MD | Draft Architecture | [SSOT-NOTIFY-01.md](<07-Notification/SSOT-NOTIFY-01.md>) |
| ✅ | SSOT-NOTIFY-02 — Template Engine | MD | Status metadata belum tersedia | [SSOT-NOTIFY-02.md](<07-Notification/SSOT-NOTIFY-02.md>) |
| ✅ | SSOT-NOTIFY-03 — Notification Preferences & Subscription | MD | Status metadata belum tersedia | [SSOT-NOTIFY-03.md](<07-Notification/SSOT-NOTIFY-03.md>) |
| ✅ | SSOT-NOTIFY-04 — Notification Delivery, Retry & Failure Governance | MD | Draft Architecture | [SSOT-NOTIFY-04.md](<07-Notification/SSOT-NOTIFY-04.md>) |
| ✅ | SSOT-NOTIFY-05 — Consent, Preference & Communication Compliance | MD | Draft Architecture | [SSOT-NOTIFY-05.md](<07-Notification/SSOT-NOTIFY-05.md>) |

---

# 08. API

| Ketersediaan | Kode / Judul | Format | Status Dokumen | Lokasi |
|---|---|---|---|---|
| ✅ | SSOT-API-01 — REST API Standard | MD | Status metadata belum tersedia | [SSOT-API-01.md](<08-API/SSOT-API-01.md>) |
| ✅ | SSOT-API-02 — Authentication & Authorization Flow | MD | Draft Architecture | [SSOT-API-02.md](<08-API/SSOT-API-02.md>) |
| ✅ | SSOT-API-03 — API Gateway & Rate Limiting | MD | Draft Architecture | [SSOT-API-03.md](<08-API/SSOT-API-03.md>) |
| ✅ | SSOT-API-04 — Webhook & Callback Architecture | MD | Status metadata belum tersedia | [SSOT-API-04.md](<08-API/SSOT-API-04.md>) |
| ✅ | SSOT-API-05 — API Versioning & Deprecation Policy | MD | Status metadata belum tersedia | [SSOT-API-05.md](<08-API/SSOT-API-05.md>) |
| ✅ | SSOT-API-06 — API Authorization, Scope & Resource Binding Governance | MD | Draft Architecture | [SSOT-API-06.md](<08-API/SSOT-API-06.md>) |
| ✅ | SSOT-API-07 — API Idempotency, Concurrency & Request Safety Governance | MD | Draft Architecture | [SSOT-API-07.md](<08-API/SSOT-API-07.md>) |
| ✅ | SSOT-API-08 — API Consumer, Client Registration & Credential Governance | MD | Draft Architecture | [SSOT-API-08.md](<08-API/SSOT-API-08.md>) |
| ✅ | SSOT-API-09 — API Consumer Certification & Conformance Governance | MD | Draft Architecture | [SSOT-API-09.md](<08-API/SSOT-API-09.md>) |

---

# 09. Event

| Ketersediaan | Kode / Judul | Format | Status Dokumen | Lokasi |
|---|---|---|---|---|
| ✅ | SSOT-EVENT-01 — Event Bus & Domain Events | MD | Draft Architecture | [SSOT-EVENT-01.md](<09-Event/SSOT-EVENT-01.md>) |
| ✅ | SSOT-EVENT-02 — Event Store & Replay | MD | Draft Architecture | [SSOT-EVENT-02.md](<09-Event/SSOT-EVENT-02.md>) |
| ✅ | SSOT-EVENT-03 — Outbox Pattern & Reliable Messaging | MD | Draft Architecture | [SSOT-EVENT-03.md](<09-Event/SSOT-EVENT-03.md>) |
| ✅ | SSOT-EVENT-04 — Event Schema Registry & Compatibility Governance | MD | Draft Architecture | [SSOT-EVENT-04.md](<09-Event/SSOT-EVENT-04.md>) |
| ✅ | SSOT-EVENT-05 — Event Replay, Recovery & Dead-Letter Governance | MD | Draft Architecture | [SSOT-EVENT-05.md](<09-Event/SSOT-EVENT-05.md>) |

---

# 10. File & Object Storage

| Ketersediaan | Kode / Judul | Format | Status Dokumen | Lokasi |
|---|---|---|---|---|
| ✅ | SSOT-FILE-01 — File & Object Storage Architecture | MD | Draft Architecture | [SSOT-FILE-01.md](<10-File/SSOT-FILE-01.md>) |
| ✅ | SSOT-FILE-02 — File Security, Malware Scanning & Access Control | MD | Draft Architecture | [SSOT-FILE-02.md](<10-File/SSOT-FILE-02.md>) |
| ✅ | SSOT-FILE-03 — File Retention, Versioning & Evidence Governance | MD | Draft Architecture | [SSOT-FILE-03.md](<10-File/SSOT-FILE-03.md>) |

---

# 11. Search

| Ketersediaan | Kode / Judul | Format | Status Dokumen | Lokasi |
|---|---|---|---|---|
| ✅ | SSOT-SEARCH-01 — Search & Indexing | MD | Status metadata belum tersedia | [SSOT-SEARCH-01.md](<11-Search/SSOT-SEARCH-01.md>) |
| ✅ | SSOT-SEARCH-02 — Search Authorization & Tenant-Aware Indexing | MD | Draft Architecture | [SSOT-SEARCH-02.md](<11-Search/SSOT-SEARCH-02.md>) |
| ✅ | SSOT-SEARCH-03 — Search Reindexing, Consistency & Lifecycle Governance | MD | Draft Architecture | [SSOT-SEARCH-03.md](<11-Search/SSOT-SEARCH-03.md>) |

---

# 12. Integration

| Ketersediaan | Kode / Judul | Format | Status Dokumen | Lokasi |
|---|---|---|---|---|
| ✅ | SSOT-INTEGRATION-01 — External Integration Framework | MD | Draft Architecture | [SSOT-INTEGRATION-01.md](<12-Integration/SSOT-INTEGRATION-01.md>) |
| ✅ | SSOT-INTEGRATION-02 — Integration Credential & Connection Governance | MD | Draft Architecture | [SSOT-INTEGRATION-02.md](<12-Integration/SSOT-INTEGRATION-02.md>) |
| ✅ | SSOT-INTEGRATION-03 — Webhook, Callback & Partner Security | MD | Draft Architecture | [SSOT-INTEGRATION-03.md](<12-Integration/SSOT-INTEGRATION-03.md>) |
| ✅ | SSOT-INTEGRATION-04 — Integration Reliability, Retry & Reconciliation | MD | Draft Architecture | [SSOT-INTEGRATION-04.md](<12-Integration/SSOT-INTEGRATION-04.md>) |

---

# 13. Observability

| Ketersediaan | Kode / Judul | Format | Status Dokumen | Lokasi |
|---|---|---|---|---|
| ✅ | SSOT-OBS-01 — Observability Architecture | MD | Draft Architecture | [SSOT-OBS-01.md](<13-Observability/SSOT-OBS-01.md>) |
| ✅ | SSOT-OBS-02 — Structured Logging Standard | MD | Draft Implementation Standard | [SSOT-OBS-02.md](<13-Observability/SSOT-OBS-02.md>) |
| ✅ | SSOT-OBS-03 — Metrics & KPI Framework | MD | Draft Implementation Standard | [SSOT-OBS-03.md](<13-Observability/SSOT-OBS-03.md>) |
| ✅ | SSOT-OBS-04 — Distributed Tracing | MD | Draft Implementation Standard | [SSOT-OBS-04.md](<13-Observability/SSOT-OBS-04.md>) |
| ✅ | SSOT-OBS-05 — Health Check Framework | MD | Draft for Review | [SSOT-OBS-05.md](<13-Observability/SSOT-OBS-05.md>) |
| ✅ | SSOT-OBS-06 — Monitoring Dashboard Framework | MD | Draft for Review | [SSOT-OBS-06.md](<13-Observability/SSOT-OBS-06.md>) |
| ✅ | SSOT-OBS-07 — Alerting & Incident Management Framework | MD | Draft for Review | [SSOT-OBS-07.md](<13-Observability/SSOT-OBS-07.md>) |
| ✅ | SSOT-OBS-08 — Log Retention & Archiving Framework | MD | Draft for Review | [SSOT-OBS-08.md](<13-Observability/SSOT-OBS-08.md>) |
| ✅ | SSOT-OBS-09 — Performance Monitoring Framework | MD | Draft for Review | [SSOT-OBS-09.md](<13-Observability/SSOT-OBS-09.md>) |
| ✅ | SSOT-OBS-10 — Audit vs Logging vs Event Guideline | MD | Draft for Review | [SSOT-OBS-10.md](<13-Observability/SSOT-OBS-10.md>) |
| ✅ | SSOT-OBS-11 — Observability Governance & Maturity Framework | MD | Draft for Review | [SSOT-OBS-11.md](<13-Observability/SSOT-OBS-11.md>) |

---

# 14. Security

| Ketersediaan | Kode / Judul | Format | Status Dokumen | Lokasi |
|---|---|---|---|---|
| ✅ | DEPLOY-SEC-01 — Deployment & UAT Manual | MD | Draft Deployment & UAT Manual | [DEPLOY-SEC-01.md](<14-Security/DEPLOY-SEC-01.md>) |
| ✅ | SSOT-SEC-01 — Security Implementation Framework | MD | Draft for Review | [SSOT-SEC-01.md](<14-Security/SSOT-SEC-01.md>) |
| ✅ | SSOT-SEC-02 — Secure SDLC & Application Security Framework | MD | Draft for Review | [SSOT-SEC-02.md](<14-Security/SSOT-SEC-02.md>) |
| ✅ | SSOT-SEC-03 — Secrets, Key & Certificate Management | MD | Draft Architecture | [SSOT-SEC-03.md](<14-Security/SSOT-SEC-03.md>) |

---

# 15. Deployment

| Ketersediaan | Kode / Judul | Format | Status Dokumen | Lokasi |
|---|---|---|---|---|
| ✅ | SSOT-DEPLOY-01 — Deployment Architecture | MD | Draft for Review | [SSOT-DEPLOY-01.md](<15-Deployment/SSOT-DEPLOY-01.md>) |
| ✅ | SSOT-DEPLOY-02 — Environment & Configuration Management | MD | Draft for Review | [SSOT-DEPLOY-02.md](<15-Deployment/SSOT-DEPLOY-02.md>) |
| ✅ | SSOT-DEPLOY-03 — Release, Promotion & Rollback Strategy | MD | Draft for Review | [SSOT-DEPLOY-03.md](<15-Deployment/SSOT-DEPLOY-03.md>) |
| ✅ | SSOT-DEPLOY-04 — Backup, Restore & Disaster Recovery | MD | Draft for Review | [SSOT-DEPLOY-04.md](<15-Deployment/SSOT-DEPLOY-04.md>) |
| ✅ | SSOT-DEPLOY-05 — Infrastructure & Runtime Hardening | MD | Draft for Review | [SSOT-DEPLOY-05.md](<15-Deployment/SSOT-DEPLOY-05.md>) |

---

# 16. Testing

| Ketersediaan | Dokumen | Catatan |
|---|---|---|
| ⚪ | SSOT-TEST-01 — Testing Strategy | Folder `16-Testing/` tersedia tetapi kosong. |

---

# 17. Implementation Standards

| Ketersediaan | Kode / Judul | Format | Status Dokumen | Lokasi |
|---|---|---|---|---|
| ✅ | SSOT-CODE-01 — PHP Coding Standard | MD | Draft Implementation Standard | [SSOT-CODE-01.md](<17-Implementation/SSOT-CODE-01.md>) |
| ✅ | SSOT-DEV-01 — Local Development Guide for Windows | MD | Status metadata belum tersedia | [SSOT-DEV-01.md](<17-Implementation/SSOT-DEV-01.md>) |
| ✅ | SSOT-IMPLEMENTATION-01 — Modular Monolith Architecture & Module Lifecycle | MD | Draft | [SSOT-IMPLEMENTATION-01.md](<17-Implementation/SSOT-IMPLEMENTATION-01.md>) |
| ✅ | SSOT-MYSQL-01 — MySQL Implementation Rules | MD | Draft Implementation Standard | [SSOT-MYSQL-01.md](<17-Implementation/SSOT-MYSQL-01.md>) |
| ✅ | SSOT-STACK-01 — PHP + MySQL + XAMPP Standard | MD | Draft Implementation Standard | [SSOT-STACK-01.md](<17-Implementation/SSOT-STACK-01.md>) |

---

# 18. UI Assets

| Ketersediaan | Kode / Judul | Format | Status Dokumen | Lokasi |
|---|---|---|---|---|
| ✅ | SSOT-UI-01 — Enterprise UI Architecture & Design System | MD | Draft Architecture | [SSOT-UI-01.md](<18-UI/SSOT-UI-01.md>) |
| ✅ | master.css | CSS | Asset | [master.css](<18-UI/master.css>) |

---

# 19. Business Modules

| Ketersediaan | Kode / Judul | Format | Status Dokumen | Lokasi |
|---|---|---|---|---|
| ✅ | SSOT-MODULE-01 — Business Module Architecture & Lifecycle | MD | Draft Architecture | [SSOT-MODULE-01.md](<19-Modules/SSOT-MODULE-01.md>) |

---

# 20. Platform SDK

> File saat ini berada di root `ssot/`. Pemindahan folder tidak dilakukan dalam sinkronisasi index ini.

| Ketersediaan | Kode / Judul | Format | Status Dokumen | Lokasi |
|---|---|---|---|---|
| ✅ | SSOT-SDK-01 — Platform SDK Architecture | MD | Draft for Review | [SSOT-SDK-01.md](<20-SDK/SSOT-SDK-01.md>) |
| ✅ | SSOT-SDK-02 — Module SDK Contracts | MD | Draft for Review | [SSOT-SDK-02.md](<20-SDK/SSOT-SDK-02.md>) |
| ✅ | SSOT-SDK-03 — SDK Versioning & Compatibility | MD | Draft for Review | [SSOT-SDK-03.md](<20-SDK/SSOT-SDK-03.md>) |
| ✅ | SSOT-SDK-04 — Module Registration & Bootstrap | MD | Draft for Review | [SSOT-SDK-04.md](<20-SDK/SSOT-SDK-04.md>) |
| ✅ | SSOT-SDK-05 — Extension, Plugin & Capability Model | MD | Draft for Review | [SSOT-SDK-05.md](<20-SDK/SSOT-SDK-05.md>) |

---

# 21. Master & Reference Data (MDM)

> File saat ini berada di root `ssot/`. Pemindahan folder tidak dilakukan dalam sinkronisasi index ini.

| Ketersediaan | Kode / Judul | Format | Status Dokumen | Lokasi |
|---|---|---|---|---|
| ✅ | SSOT-MDM-01 — Master & Reference Data Framework | MD | Draft for Review | [SSOT-MDM-01.md](<21-MDM/SSOT-MDM-01.md>) |
| ✅ | SSOT-MDM-02 — Code Set, Taxonomy & Lookup Governance | MD | Draft for Review | [SSOT-MDM-02.md](<21-MDM/SSOT-MDM-02.md>) |
| ✅ | SSOT-MDM-03 — Data Ownership, Quality & Stewardship | MD | Draft for Review | [SSOT-MDM-03.md](<21-MDM/SSOT-MDM-03.md>) |

---

# 22. Dokumen Induk & Perencanaan

| Ketersediaan | Dokumen | Format | Status / Fungsi | Lokasi |
|---|---|---|---|---|
| ✅ | Enterprise Platform Kernel | MD | Status metadata belum tersedia | [README.md](<README.md>) |
| ✅ | SSOT-ROADMAP.md | MD | Status metadata belum tersedia | [SSOT-ROADMAP.md](<SSOT-ROADMAP.md>) |
| ✅ | SSOT-DEPENDENCY-MATRIX.md | MD | Status metadata belum tersedia | [SSOT-DEPENDENCY-MATRIX.md](<SSOT-DEPENDENCY-MATRIX.md>) |
| ✅ | PLANNING-APLIKASI-NERSLINK | MD | Status metadata belum tersedia | [PLANNING-APLIKASI-NERSLINK.md](<PLANNING-APLIKASI-NERSLINK.md>) |
| ✅ | Roadmap Development | MD | Status metadata belum tersedia | [sprint.md](<sprint.md>) |

---

# 23. Gap yang Terkonfirmasi

| Prioritas | Gap | Status |
|---:|---|---|
| 1 | Data Exchange, Canonical Mapping & Transformation Governance | Sudah terisi -- SSOT-DATA-07 (lihat §05). Baris ini dipertahankan sebagai catatan historis dari draft index sebelum SSOT-DATA-07 ditambahkan. |
| 2 | SSOT-SCOPE-01 tidak tercantum di index | Diperbaiki 2026-07-07 (lihat §01). Ditemukan sendiri oleh `SSOT-INTEGRITY-REPORT.md` tapi tidak diperbaiki oleh alat konsolidasi -- Claude yang menambahkannya secara manual. |
| 3 | `98-Legacy-Artifacts/Legacy-Scope-Architecture-Blueprint.docx` tidak tercantum di index mana pun | Sengaja tidak diberi entri "aktif" karena berstatus non-canonical/legacy per `SSOT-INTEGRITY-REPORT.md` ("Duplicate Scope DOCX preserved under 98-Legacy-Artifacts as a noncanonical artifact") -- dicatat di sini untuk keterlacakan saja, bukan sebagai dokumen aktif. |
| 4 | SSOT-MODULE-01 mencantumkan dependency ke kode yang tidak pernah ada di paket manapun: `SSOT-01, SSOT-02, SSOT-03A, SSOT-03B, SSOT-03C, SSOT-04` | Belum diperbaiki -- kemungkinan typo/placeholder yang tidak pernah diisi dengan kode asli (mis. dimaksudkan SSOT-SCOPE-01, SSOT-IAM-0x, SSOT-RBAC-0x/MENU-0x, SSOT-AUDIT-01). Salah satu dari 18 "Dependency Review Findings" yang disebut `SSOT-INTEGRITY-REPORT.md` tapi tidak dienumerasi di sana. Perlu klarifikasi arsitek, bukan ditebak oleh Claude. |

---

# 24. Catatan Konsistensi

- Prefix notification aktual adalah `SSOT-NOTIFY-*`; gunakan prefix tersebut secara konsisten pada dokumen berikutnya.
- Prefix integration aktual adalah `SSOT-INTEGRATION-*`; gunakan prefix tersebut secara konsisten.
- `DEPLOY-SEC-01` adalah runbook deployment/UAT dan bukan kode `SSOT-*`; tetap dicatat pada domain Security.
- Beberapa heading lama memakai tiga tanda hubung (`---`) dan telah dinormalisasi hanya pada tampilan index menjadi em dash (`—`); file sumber tidak diubah.
- File Scope dan RBAC masih berformat DOCX. Status normatifnya perlu diverifikasi dari metadata internal dokumen.
- SDK dan MDM masih berada di root. Struktur folder dapat dinormalisasi melalui perubahan terpisah agar tidak memutus tautan tanpa keputusan governance.

---

# 25. Dependency Ring

1. Governance
2. Scope
3. IAM
4. RBAC & Dynamic Menu
5. Audit
6. Data
7. Workflow
8. Notification
9. API
10. Event
11. File & Object Storage
12. Search
13. Integration
14. Observability
15. Security
16. Deployment
17. Implementation Standards
18. Platform SDK
19. Master & Reference Data
20. Testing
21. Business Modules

---

# 26. Ringkasan Inventaris

| Item | Jumlah |
|---|---:|
| Dokumen/artefak berkode `SSOT-*` atau `DEPLOY-*` selain index | 82 (direvisi dari 81 pada 2026-07-07 setelah SSOT-SCOPE-01 ditambahkan -- lihat §01 dan §23 gap #2) |
| Artefak pendukung non-SSOT | 4 |
| Total file dalam paket setelah sinkronisasi | 87 (direvisi dari 86) |
| Folder kosong | 0 folder SSOT utama yang telah diprioritaskan |
| Gap dokumen utama | Business continuity governance lanjutan, Runtime configuration governance lanjutan, Background job governance lanjutan |
| Catatan tidak terhitung di sini | `98-Legacy-Artifacts/` (1 file docx, non-canonical) dan file-file level-root non-domain (README, sprint.md, PLANNING-APLIKASI-NERSLINK, SSOT-ROADMAP, SSOT-DEPENDENCY-MATRIX, SSOT-INTEGRITY-REPORT) tidak masuk hitungan "dokumen berkode SSOT-*" di atas meskipun beberapa di antaranya juga muncul di §22. |

## Aturan Pemeliharaan Index

1. Setiap dokumen baru wajib ditambahkan ke index pada pull request yang sama.
2. Judul di index harus sama dengan heading utama dokumen.
3. Status di index harus mengikuti metadata dokumen, bukan asumsi berdasarkan keberadaan file.
4. Perubahan nama/pemindahan file wajib memperbarui tautan index dan dependency matrix.
5. Dokumen yang `SUPERSEDED` atau `RETIRED` tetap dicatat untuk menjaga traceability.
