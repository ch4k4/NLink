
# SSOT-STACK-01 — PHP + MySQL + XAMPP Standard

## Status Dokumen

| Item | Nilai |
|---|---|
| Kode | SSOT-STACK-01 |
| Nama | PHP + MySQL + XAMPP Standard |
| Versi | 1.0 |
| Status | Draft Implementation Standard |
| Domain | Platform Stack / Local Development |
| Target Stack | PHP, MySQL/MariaDB, Apache, XAMPP Windows |
| Bergantung pada | README.md, SSOT-DATA, SSOT-IAM, SSOT-RBAC, SSOT-AUDIT, SSOT-API |

---

# 1. Tujuan

Dokumen ini menetapkan standar teknis implementasi Platform Kernel menggunakan:

```text
PHP
MySQL / MariaDB
Apache
XAMPP
Windows
```

Tujuannya:

- membuat blueprint enterprise bisa dijalankan pada stack lokal yang sederhana;
- menjaga struktur kode tetap profesional walaupun memakai XAMPP;
- mencegah implementasi spaghetti;
- memastikan aplikasi tetap modular, aman, scope-aware, RBAC-aware, dan audit-aware;
- menjadi acuan developer saat mulai coding.

---

# 2. Prinsip Dasar

## 2.1 XAMPP hanya runtime lokal, bukan alasan arsitektur jadi lemah

Walaupun aplikasi dijalankan di XAMPP, struktur aplikasi tetap harus mengikuti:

```text
Modular Monolith
Service Layer
Repository Pattern
Middleware
Migration
RBAC
Audit
Scope
API Standard
```

## 2.2 Jangan menaruh business logic di file view

Tidak boleh:

```php
// homecare.php
$sql = "UPDATE visits SET status='done'";
```

Harus:

```text
Controller
→ Service
→ Repository
→ Database
```

## 2.3 Database access wajib melalui PDO

Gunakan:

```text
PDO
prepared statement
transaction
```

Jangan gunakan:

```text
mysql_* functions
mysqli raw query tanpa binding
string concatenation SQL
```

## 2.4 Semua konfigurasi berada di .env

Tidak boleh hardcode:

```php
$dbPassword = "";
```

Gunakan file `.env`.

---

# 3. Target Versi

Rekomendasi minimum:

```text
PHP >= 8.1
MySQL >= 8.0 atau MariaDB >= 10.4
Apache dari XAMPP
Composer >= 2.x
```

Jika XAMPP memakai MariaDB, pastikan fitur JSON dan FK InnoDB berjalan baik.

---

# 4. Struktur Folder Aplikasi

Rekomendasi:

```text
project-root/
│
├── public/
│   ├── index.php
│   ├── assets/
│   └── uploads/              # hanya public asset non-sensitif
│
├── app/
│   ├── Core/
│   │   ├── Config/
│   │   ├── Database/
│   │   ├── Http/
│   │   ├── Middleware/
│   │   ├── Routing/
│   │   ├── Security/
│   │   ├── Scope/
│   │   ├── RBAC/
│   │   ├── Audit/
│   │   ├── Event/
│   │   ├── Workflow/
│   │   ├── Notification/
│   │   ├── FileStorage/
│   │   └── Support/
│   │
│   └── Modules/
│       ├── IAM/
│       ├── Organization/
│       ├── Patient/
│       ├── Homecare/
│       └── ...
│
├── database/
│   ├── migrations/
│   ├── seeds/
│   └── schema/
│
├── storage/
│   ├── logs/
│   ├── cache/
│   ├── sessions/
│   ├── files/                # private file storage
│   ├── temp/
│   └── backups/
│
├── routes/
│   ├── web.php
│   └── api.php
│
├── config/
│   ├── app.php
│   ├── database.php
│   ├── security.php
│   └── modules.php
│
├── tools/
│   ├── migrate.php
│   ├── seed.php
│   └── health_check.php
│
├── tests/
│
├── vendor/
├── .env
├── .env.example
├── composer.json
└── README.md
```

---

# 5. Document Root

Apache DocumentRoot harus diarahkan ke:

```text
project-root/public
```

Bukan ke root project.

Benar:

```text
http://localhost/nama-project/public
```

Lebih baik via VirtualHost:

```text
http://nerslink.local
```

DocumentRoot:

```text
D:/xampp/htdocs/nerslink/public
```

Alasan:

- `.env` tidak bisa diakses publik;
- `app/` tidak terekspos;
- `storage/` tidak terekspos;
- keamanan lebih baik.

---

# 6. public/index.php

`public/index.php` menjadi satu-satunya entry point.

Contoh:

```php
<?php

declare(strict_types=1);

require dirname(__DIR__) . '/vendor/autoload.php';

use App\Core\Application;

$app = Application::boot(dirname(__DIR__));
$app->handle();
```

---

# 7. Autoloading

Gunakan Composer PSR-4.

`composer.json`:

```json
{
  "autoload": {
    "psr-4": {
      "App\\\\": "app/"
    }
  },
  "require": {
    "vlucas/phpdotenv": "^5.6"
  }
}
```

Setelah perubahan:

```bash
composer dump-autoload
```

---

# 8. .env Standard

`.env.example`:

```env
APP_NAME=NerslinkPlatform
APP_ENV=local
APP_DEBUG=true
APP_URL=http://nerslink.local
APP_TIMEZONE=Asia/Jakarta

DB_CONNECTION=mysql
DB_HOST=127.0.0.1
DB_PORT=3306
DB_DATABASE=nerslink_platform2
DB_USERNAME=root
DB_PASSWORD=

SESSION_DRIVER=file
SESSION_LIFETIME=120

LOG_CHANNEL=file
LOG_LEVEL=debug

STORAGE_DISK=local
```

`.env` tidak boleh masuk Git.

---

# 9. Configuration Loader

Konfigurasi harus dibaca dari `.env` dan file `config`.

Contoh helper:

```php
function env_value(string $key, mixed $default = null): mixed
{
    return $_ENV[$key] ?? $default;
}
```

---

# 10. Database Connection

Gunakan PDO.

```php
$pdo = new PDO(
    'mysql:host=127.0.0.1;dbname=nerslink_platform2;charset=utf8mb4',
    'root',
    '',
    [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
    ]
);
```

Wajib:

```text
utf8mb4
ERRMODE_EXCEPTION
prepared statements
```

---

# 11. MySQL Standard

Setiap tabel menggunakan:

```sql
ENGINE=InnoDB
DEFAULT CHARSET=utf8mb4
COLLATE=utf8mb4_unicode_ci
```

Contoh:

```sql
CREATE TABLE users (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    tenant_id BIGINT UNSIGNED NOT NULL,
    email VARCHAR(150) NULL,
    status VARCHAR(50) NOT NULL DEFAULT 'active',
    created_at TIMESTAMP NULL,
    updated_at TIMESTAMP NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
```

---

# 12. Migration Standard untuk XAMPP

Migration disimpan di:

```text
database/migrations
```

Format nama:

```text
YYYYMMDD_HHMMSS_create_users_table.sql
```

Contoh:

```text
20260703_090000_create_users_table.sql
```

Wajib ada tabel tracking:

```sql
CREATE TABLE migrations (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    migration VARCHAR(255) NOT NULL UNIQUE,
    batch INT NOT NULL,
    executed_at DATETIME NOT NULL
);
```

---

# 13. Migration Runner

Minimal command:

```bash
D:\\xampp\\php\\php.exe tools\\migrate.php
```

Runner harus:

- membaca file migration berurutan;
- skip migration yang sudah pernah jalan;
- mencatat ke tabel `migrations`;
- berhenti jika ada error;
- menampilkan summary.

---

# 14. Seed Standard

Seed disimpan di:

```text
database/seeds
```

Jenis seed:

```text
reference
system
demo
test
```

Production hanya boleh menjalankan:

```text
reference
system
```

Demo/test seed tidak boleh masuk production.

---

# 15. Routing Standard

Route dipisah:

```text
routes/web.php
routes/api.php
```

Contoh:

```php
$router->get('/login', [LoginController::class, 'show']);
$router->post('/login', [LoginController::class, 'login']);

$router->get('/api/v1/users', [UserApiController::class, 'index'])
    ->middleware(['auth', 'scope', 'permission:iam.user.read']);
```

---

# 16. Middleware Standard

Middleware minimum:

```text
ErrorHandlerMiddleware
SessionMiddleware
CsrfMiddleware
AuthenticationMiddleware
ScopeMiddleware
PermissionMiddleware
AuditMiddleware
ResponseMiddleware
```

Urutan web:

```text
Error
Session
CSRF
Auth
Scope
RBAC
Audit
Controller
```

Urutan API:

```text
Error
Correlation ID
Rate Limit
Auth
Scope
RBAC
Audit
Controller
Response Formatter
```

---

# 17. Controller Standard

Controller hanya menangani:

- menerima request;
- memanggil service;
- mengembalikan response;
- tidak query database langsung;
- tidak menulis business logic panjang.

Contoh:

```php
final class UserController
{
    public function store(Request $request): Response
    {
        $user = $this->service->createUser($request->validated());

        return Response::json([
            'success' => true,
            'data' => $user,
        ], 201);
    }
}
```

---

# 18. Service Standard

Service berisi business process.

Contoh:

```php
final class CreateUserService
{
    public function execute(array $data, ActorContext $actor): int
    {
        return $this->transaction->run(function () use ($data, $actor) {
            $userId = $this->users->create($data);

            $this->audit->log('iam.user.created', [
                'user_id' => $userId,
            ]);

            return $userId;
        });
    }
}
```

---

# 19. Repository Standard

Repository berisi query database.

Contoh:

```php
final class UserRepository
{
    public function findById(int $id): ?array
    {
        $stmt = $this->pdo->prepare(
            'SELECT * FROM users WHERE id = :id AND deleted_at IS NULL'
        );

        $stmt->execute(['id' => $id]);

        return $stmt->fetch() ?: null;
    }
}
```

---

# 20. Transaction Standard

Gunakan transaction untuk proses multi-tabel.

```php
$this->pdo->beginTransaction();

try {
    // business operation
    $this->pdo->commit();
} catch (Throwable $e) {
    $this->pdo->rollBack();
    throw $e;
}
```

Disarankan memakai `TransactionManager`.

---

# 21. Error Handling

Saat `APP_DEBUG=false`, jangan tampilkan stack trace ke user.

Tampilkan generic error:

```text
Terjadi kesalahan sistem.
```

Log detail ke:

```text
storage/logs/app.log
```

---

# 22. Logging

Log disimpan di:

```text
storage/logs
```

Format minimal:

```text
timestamp
level
message
context
correlation_id
user_id
ip
```

Jangan log:

```text
password
token
api key
OTP
secret
```

---

# 23. Session Standard

Session disimpan di:

```text
storage/sessions
```

Session security:

```text
HttpOnly
SameSite=Lax/Strict
Secure jika HTTPS
regenerate ID after login
```

---

# 24. CSRF

Semua form web POST/PUT/PATCH/DELETE wajib CSRF token.

API stateless tidak memakai CSRF, tetapi wajib auth token/API key.

---

# 25. Password Hashing

Gunakan:

```php
password_hash($password, PASSWORD_ARGON2ID)
```

Fallback:

```php
password_hash($password, PASSWORD_BCRYPT)
```

Verifikasi:

```php
password_verify($password, $hash)
```

---

# 26. File Upload di XAMPP

File sensitif tidak boleh disimpan di `public/uploads`.

Gunakan:

```text
storage/files
```

Download melalui controller dengan permission check.

Public asset biasa boleh di:

```text
public/assets
```

---

# 27. API Response Standard

```json
{
  "success": true,
  "data": {},
  "meta": {},
  "errors": [],
  "correlation_id": "..."
}
```

Error:

```json
{
  "success": false,
  "errors": [
    {
      "code": "validation.required",
      "message": "Field wajib diisi."
    }
  ],
  "correlation_id": "..."
}
```

---

# 28. Timezone

Aplikasi memakai:

```text
Asia/Jakarta
```

Database sebaiknya menyimpan UTC atau minimal konsisten.

Untuk platform enterprise, rekomendasi:

```text
DB timestamp = UTC
Display = Asia/Jakarta
```

---

# 29. Date Format

API:

```text
ISO 8601
```

UI:

```text
DD-MM-YYYY HH:mm
```

Database:

```text
DATETIME / TIMESTAMP
```

---

# 30. Security Baseline

Wajib:

- prepared statement;
- password hashing;
- CSRF;
- session regeneration;
- RBAC middleware;
- scope middleware;
- audit trail;
- file upload validation;
- `.env` tidak public;
- error detail tidak tampil di production.

---

# 31. Local VirtualHost

File:

```text
D:\\xampp\\apache\\conf\\extra\\httpd-vhosts.conf
```

Contoh:

```apache
<VirtualHost *:80>
    ServerName nerslink.local
    DocumentRoot "D:/xampp/htdocs/nerslink/public"

    <Directory "D:/xampp/htdocs/nerslink/public">
        AllowOverride All
        Require all granted
    </Directory>
</VirtualHost>
```

Tambahkan hosts Windows:

```text
127.0.0.1 nerslink.local
```

File hosts:

```text
C:\\Windows\\System32\\drivers\\etc\\hosts
```

---

# 32. .htaccess

`public/.htaccess`:

```apache
RewriteEngine On

RewriteCond %{REQUEST_FILENAME} !-f
RewriteCond %{REQUEST_FILENAME} !-d
RewriteRule ^ index.php [QSA,L]
```

Pastikan Apache `mod_rewrite` aktif.

---

# 33. Composer Commands

```bash
composer install
composer dump-autoload
```

Jalankan dengan PHP XAMPP bila perlu:

```bash
D:\\xampp\\php\\php.exe composer.phar install
```

---

# 34. CLI Tools

Semua tool CLI diletakkan di:

```text
tools/
```

Contoh:

```bash
D:\\xampp\\php\\php.exe tools\\migrate.php
D:\\xampp\\php\\php.exe tools\\seed.php
D:\\xampp\\php\\php.exe tools\\health_check.php
```

---

# 35. Health Check

Tool health check memeriksa:

- PHP version;
- extension PDO;
- database connection;
- folder storage writable;
- `.env` terbaca;
- migration status.

---

# 36. Required PHP Extensions

Minimum:

```text
pdo
pdo_mysql
mbstring
openssl
json
fileinfo
curl
gd
intl
```

Untuk XAMPP, cek di:

```text
php.ini
```

---

# 37. Folder Permission

Folder berikut harus writable:

```text
storage/logs
storage/cache
storage/sessions
storage/files
storage/temp
```

Di Windows biasanya tidak seketat Linux, tetapi tetap perlu dicek.

---

# 38. Development Mode

Local:

```env
APP_ENV=local
APP_DEBUG=true
```

Production:

```env
APP_ENV=production
APP_DEBUG=false
```

---

# 39. Anti-pattern

Hindari:

```text
database query di view
database query di controller
password plain
SQL string concatenation
upload file sensitif ke public
.env masuk Git
business logic di route
role hardcoded di PHP
clinic_id sebagai satu-satunya scope
audit tidak dicatat
migration manual tanpa tracking
```

---

# 40. Minimum Kernel Boot Order

Urutan implementasi kernel di PHP:

```text
1. Config Loader
2. Database Connection
3. Router
4. Request/Response
5. Middleware Pipeline
6. Session
7. Auth
8. Scope
9. RBAC
10. Audit
11. Repository Layer
12. Service Layer
13. API Response
14. Event/Outbox
15. Workflow
16. Notification
17. File Storage
```

---

# 41. Minimum Database Boot Order

Urutan migration awal:

```text
migrations
tenants
organizations
business_entities
users
sessions
roles
permissions
role_permissions
user_role_assignments
audit_events
modules
menus
workflow_definitions
event_messages
outbox_messages
file_objects
```

---

# 42. UAT Local Development

Checklist:

- aplikasi bisa dibuka dari browser;
- `.env` terbaca;
- database terkoneksi;
- migration berjalan;
- login berhasil;
- session tersimpan;
- RBAC menolak akses tanpa permission;
- scope aktif terbaca;
- audit login tercatat;
- API response konsisten;
- file private tidak bisa diakses langsung.

---

# 43. Definition of Done

Stack PHP + MySQL + XAMPP dianggap siap bila:

- DocumentRoot mengarah ke `public`;
- Composer autoload aktif;
- `.env` berjalan;
- PDO connection aman;
- migration runner tersedia;
- routing berjalan;
- middleware pipeline tersedia;
- session aman;
- CSRF aktif untuk web;
- API response standard;
- folder storage aman;
- error handling berjalan;
- log berjalan;
- struktur modular tersedia;
- developer dapat menjalankan aplikasi lokal tanpa konfigurasi manual berlebihan.
