
# SSOT-MYSQL-01 — MySQL Implementation Rules

## Status Dokumen

| Item | Nilai |
|---|---|
| Kode | SSOT-MYSQL-01 |
| Nama | MySQL Implementation Rules |
| Versi | 1.0 |
| Status | Draft Implementation Standard |
| Domain | Database Implementation |
| Target | MySQL 8.0+ / MariaDB 10.4+ on XAMPP Windows |
| Bergantung pada | SSOT-DATA-01, SSOT-DATA-02, SSOT-STACK-01, SSOT-CODE-01 |

---

# 1. Tujuan

Dokumen ini menetapkan aturan teknis implementasi database MySQL/MariaDB untuk Platform Kernel dan seluruh modul bisnis.

Tujuannya:

- menjaga schema konsisten;
- mendukung multi-tenant dan scope-aware data;
- menjaga integritas data;
- memastikan performa query;
- memudahkan migration;
- cocok untuk XAMPP Windows;
- tetap future-ready untuk production.

---

# 2. Target Database

Rekomendasi:

```text
MySQL 8.0+
```

Jika memakai XAMPP default:

```text
MariaDB 10.4+
```

Catatan:

- fitur JSON pada MariaDB berbeda dengan MySQL;
- index JSON expression mungkin tidak sama;
- hindari fitur vendor-specific bila tidak wajib.

---

# 3. Engine Standard

Semua tabel bisnis wajib memakai:

```sql
ENGINE=InnoDB
```

Tidak boleh memakai:

```text
MyISAM
MEMORY untuk data bisnis
CSV engine untuk transaksi
```

Alasan:

- foreign key;
- transaction;
- row-level locking;
- crash recovery.

---

# 4. Charset & Collation

Default:

```sql
DEFAULT CHARSET=utf8mb4
COLLATE=utf8mb4_unicode_ci
```

Untuk MySQL 8 bisa dipertimbangkan:

```sql
utf8mb4_0900_ai_ci
```

Namun untuk kompatibilitas XAMPP/MariaDB, gunakan:

```sql
utf8mb4_unicode_ci
```

---

# 5. Database Creation

```sql
CREATE DATABASE nerslink_platform2
CHARACTER SET utf8mb4
COLLATE utf8mb4_unicode_ci;
```

---

# 6. Table Naming

Gunakan:

```text
snake_case
plural
```

Contoh:

```text
users
patients
audit_events
workflow_instances
```

Hindari:

```text
User
tbl_user
m_user
dataPasien
```

---

# 7. Column Naming

Gunakan:

```text
snake_case
```

Foreign key:

```text
{table_singular}_id
```

Contoh:

```text
user_id
patient_id
business_entity_id
workflow_instance_id
```

---

# 8. Primary Key

Default:

```sql
id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY
```

Gunakan UUID tambahan bila perlu public identifier:

```sql
user_uuid CHAR(36) NOT NULL UNIQUE
```

Jangan menggunakan UUID sebagai PK utama untuk semua tabel di MySQL lokal kecuali ada kebutuhan kuat.

---

# 9. Foreign Key

Gunakan foreign key untuk relasi kuat.

Contoh:

```sql
CONSTRAINT fk_user_roles_user
    FOREIGN KEY (user_id) REFERENCES users(id)
```

Naming:

```text
fk_{table}_{referenced_table}
```

---

# 10. Cascade Rule

Untuk data bisnis, hindari:

```sql
ON DELETE CASCADE
```

Default:

```sql
ON DELETE RESTRICT
```

atau:

```sql
ON DELETE SET NULL
```

Gunakan cascade hanya untuk child data yang benar-benar tidak bermakna tanpa parent, misalnya detail temporary.

---

# 11. Timestamp Standard

Kolom standar:

```sql
created_at TIMESTAMP NULL
updated_at TIMESTAMP NULL
deleted_at TIMESTAMP NULL
```

Untuk event yang butuh waktu eksplisit:

```sql
occurred_at DATETIME NOT NULL
```

Rekomendasi:

- simpan waktu bisnis sebagai `DATETIME`;
- simpan metadata sistem sebagai `TIMESTAMP`;
- konsisten di seluruh aplikasi.

---

# 12. Audit Columns

Tabel bisnis wajib mendukung:

```sql
created_by BIGINT UNSIGNED NULL
updated_by BIGINT UNSIGNED NULL
deleted_by BIGINT UNSIGNED NULL
```

Detail audit tetap disimpan di Audit Trail.

---

# 13. Scope Columns

Tabel transaksi wajib menyimpan minimal:

```sql
tenant_id BIGINT UNSIGNED NOT NULL
organization_id BIGINT UNSIGNED NULL
business_entity_id BIGINT UNSIGNED NULL
```

Opsional:

```sql
branch_id BIGINT UNSIGNED NULL
department_id BIGINT UNSIGNED NULL
service_id BIGINT UNSIGNED NULL
team_id BIGINT UNSIGNED NULL
```

---

# 14. Soft Delete

Gunakan:

```sql
deleted_at TIMESTAMP NULL
deleted_by BIGINT UNSIGNED NULL
```

Query default harus menyaring:

```sql
WHERE deleted_at IS NULL
```

Hard delete hanya untuk:

- cache;
- queue transient;
- session expired;
- temporary import;
- data test.

---

# 15. Status Column

Gunakan `VARCHAR(50)` atau `ENUM`.

Rekomendasi praktis untuk fleksibilitas:

```sql
status VARCHAR(50) NOT NULL DEFAULT 'active'
```

ENUM boleh untuk status yang sangat stabil.

Hindari boolean untuk lifecycle kompleks.

Salah:

```sql
is_active TINYINT(1)
```

Benar:

```sql
status VARCHAR(50)
```

---

# 16. Boolean

Gunakan:

```sql
TINYINT(1) NOT NULL DEFAULT 0
```

Contoh:

```sql
is_visible TINYINT(1) NOT NULL DEFAULT 1
```

---

# 17. Money

Jangan gunakan `FLOAT` atau `DOUBLE`.

Gunakan:

```sql
amount DECIMAL(18,2) NOT NULL
```

atau integer minor unit:

```sql
amount_cents BIGINT NOT NULL
```

Untuk Rupiah, bisa:

```sql
amount DECIMAL(18,2)
```

---

# 18. Text Type

Gunakan sesuai kebutuhan:

```text
VARCHAR(255) untuk teks pendek
TEXT untuk deskripsi
LONGTEXT untuk payload besar
```

Jangan pakai `TEXT` untuk semua field.

---

# 19. JSON Column

Gunakan JSON untuk:

- snapshot;
- metadata;
- configuration;
- flexible payload.

Jangan gunakan JSON untuk relasi utama.

Benar:

```sql
scope_snapshot JSON NULL
metadata JSON NULL
```

Salah:

```sql
user_role_ids JSON
patient_visit_ids JSON
```

---

# 20. Index Standard

Wajib index untuk:

- foreign key;
- kolom scope;
- status;
- created_at;
- lookup code;
- unique business key;
- query filter yang sering dipakai.

Contoh:

```sql
INDEX idx_users_tenant_status (tenant_id, status)
INDEX idx_patients_scope (tenant_id, business_entity_id)
INDEX idx_audit_created_at (created_at)
```

---

# 21. Composite Index

Gunakan composite index sesuai pola query.

Contoh query:

```sql
WHERE tenant_id = ?
AND business_entity_id = ?
AND status = ?
ORDER BY created_at DESC
```

Index:

```sql
INDEX idx_scope_status_created (
    tenant_id,
    business_entity_id,
    status,
    created_at
)
```

---

# 22. Unique Constraint

Unique harus mempertimbangkan scope.

Contoh:

```sql
UNIQUE KEY uq_users_tenant_email (tenant_id, email)
UNIQUE KEY uq_permissions_code (code)
UNIQUE KEY uq_patient_mrn_scope (business_entity_id, medical_record_number)
```

Jangan membuat email global unique jika platform multi-tenant mengizinkan email sama di tenant berbeda.

---

# 23. Code Column

Untuk master/reference data, gunakan:

```sql
code VARCHAR(100) NOT NULL UNIQUE
name VARCHAR(150) NOT NULL
```

Jika scoped:

```sql
UNIQUE KEY uq_code_scope (tenant_id, code)
```

---

# 24. Migration Naming

Format:

```text
YYYYMMDD_HHMMSS_action_table.sql
```

Contoh:

```text
20260703_090000_create_users_table.sql
20260703_091000_add_status_to_users_table.sql
```

---

# 25. Migration Rule

Migration harus:

- kecil;
- berurutan;
- tidak mengubah file migration lama yang sudah dipakai;
- bisa dijalankan dari database kosong;
- dicatat di tabel `migrations`.

---

# 26. Table migrations

```sql
CREATE TABLE migrations (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    migration VARCHAR(255) NOT NULL UNIQUE,
    batch INT NOT NULL,
    executed_at DATETIME NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
```

---

# 27. Safe Schema Change

Untuk production future-ready, gunakan expand/contract.

Contoh rename kolom:

1. tambah kolom baru;
2. dual write;
3. backfill;
4. update aplikasi;
5. hapus kolom lama setelah aman.

Jangan langsung rename/drop kolom yang masih dipakai.

---

# 28. Transaction

Gunakan transaction untuk operasi multi-tabel.

```sql
START TRANSACTION;
-- operation
COMMIT;
```

Rollback jika gagal.

Di PHP gunakan PDO transaction.

---

# 29. Isolation Level

Default InnoDB biasanya cukup:

```sql
REPEATABLE READ
```

Untuk sebagian kasus bisa gunakan:

```sql
READ COMMITTED
```

Tetapkan hanya jika paham dampaknya.

---

# 30. Locking

Gunakan:

```sql
SELECT ... FOR UPDATE
```

untuk proses kritis:

- pembayaran;
- refund;
- closing encounter;
- inventory stock;
- workflow transition kritis.

---

# 31. Optimistic Locking

Tambahkan:

```sql
version INT NOT NULL DEFAULT 1
```

Update:

```sql
UPDATE table_name
SET status = :status,
    version = version + 1
WHERE id = :id
AND version = :expected_version;
```

---

# 32. Pagination

Gunakan:

```sql
LIMIT :limit OFFSET :offset
```

Untuk tabel besar, pertimbangkan keyset pagination:

```sql
WHERE id < :last_id
ORDER BY id DESC
LIMIT 20
```

---

# 33. Avoid SELECT *

Hindari:

```sql
SELECT * FROM patients
```

Gunakan kolom spesifik:

```sql
SELECT id, medical_record_number, full_name, status
FROM patients
```

---

# 34. Query Scope Rule

Semua query transaksi wajib memakai scope.

Contoh:

```sql
SELECT id, full_name
FROM patients
WHERE tenant_id = :tenant_id
AND business_entity_id = :business_entity_id
AND deleted_at IS NULL;
```

---

# 35. Update Scope Rule

Update wajib memakai scope.

```sql
UPDATE patients
SET full_name = :full_name,
    updated_at = NOW(),
    updated_by = :user_id
WHERE id = :id
AND tenant_id = :tenant_id
AND business_entity_id = :business_entity_id
AND deleted_at IS NULL;
```

---

# 36. Delete Scope Rule

Soft delete wajib memakai scope.

```sql
UPDATE patients
SET deleted_at = NOW(),
    deleted_by = :user_id
WHERE id = :id
AND tenant_id = :tenant_id
AND business_entity_id = :business_entity_id;
```

---

# 37. Audit Table Rule

Audit table bisa sangat besar.

Wajib:

- index `created_at`;
- index `actor_user_id`;
- index `correlation_id`;
- index scope;
- pertimbangkan partition untuk production.

---

# 38. Event/Outbox Table Rule

Outbox table wajib punya index:

```sql
INDEX idx_outbox_status (status, next_retry_at)
```

Worker harus membaca batch kecil.

---

# 39. Search Table Rule

Search read model boleh denormalized.

Namun harus:

- rebuildable;
- event-driven;
- tidak menjadi source of truth utama.

---

# 40. File Metadata Rule

Binary file tidak disimpan di MySQL.

MySQL hanya menyimpan metadata.

Salah:

```sql
file_blob LONGBLOB
```

Benar:

```sql
storage_path VARCHAR(1000)
checksum_sha256 CHAR(64)
```

Kecuali ada alasan kuat untuk file kecil tertentu.

---

# 41. Password & Secret Rule

Database tidak boleh menyimpan plain:

- password;
- API key;
- token;
- OTP;
- client secret.

Gunakan:

```text
hash
encrypted payload
vault reference
```

---

# 42. Data Masking

Untuk snapshot/log:

- mask PII/PHI;
- jangan simpan data klinis penuh di audit/event/search tanpa policy.

---

# 43. Seed Rule

Seed harus idempotent.

Gunakan:

```sql
INSERT ... ON DUPLICATE KEY UPDATE
```

atau logic check existing.

Jangan seed demo di production.

---

# 44. Backup Local

Untuk development:

```bash
mysqldump -u root nerslink_platform2 > backup.sql
```

Untuk production, backup harus mengikuti SSOT-DATA-05.

---

# 45. Import SQL di XAMPP

Opsi:

```bash
D:\xampp\mysql\bin\mysql.exe -u root nerslink_platform2 < file.sql
```

atau phpMyAdmin untuk file kecil.

File besar lebih aman via CLI.

---

# 46. Timezone

Set MySQL session timezone secara eksplisit bila perlu:

```sql
SET time_zone = '+00:00';
```

Aplikasi display ke:

```text
Asia/Jakarta
```

---

# 47. Performance Check

Gunakan:

```sql
EXPLAIN SELECT ...
```

Cek:

- apakah index dipakai;
- apakah full table scan terjadi;
- apakah filesort besar terjadi.

---

# 48. Slow Query

Untuk production future-ready, aktifkan slow query log.

Untuk XAMPP development, developer bisa melakukan manual EXPLAIN pada query berat.

---

# 49. Common Anti-pattern

Hindari:

```text
MyISAM untuk tabel bisnis
latin1 charset
SELECT *
query tanpa tenant_id
update berdasarkan id saja
delete permanen data transaksi
password plain
JSON untuk relasi utama
index terlalu sedikit
index berlebihan tanpa alasan
migration manual tanpa tracking
edit migration lama
foreign key tidak di-index
```

---

# 50. Minimum Table Template

```sql
CREATE TABLE example_entities (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,

    tenant_id BIGINT UNSIGNED NOT NULL,
    organization_id BIGINT UNSIGNED NULL,
    business_entity_id BIGINT UNSIGNED NULL,

    code VARCHAR(100) NOT NULL,
    name VARCHAR(150) NOT NULL,
    status VARCHAR(50) NOT NULL DEFAULT 'active',

    created_by BIGINT UNSIGNED NULL,
    updated_by BIGINT UNSIGNED NULL,
    deleted_by BIGINT UNSIGNED NULL,

    created_at TIMESTAMP NULL,
    updated_at TIMESTAMP NULL,
    deleted_at TIMESTAMP NULL,

    UNIQUE KEY uq_example_scope_code (tenant_id, code),
    INDEX idx_example_scope (tenant_id, business_entity_id),
    INDEX idx_example_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
```

---

# 51. UAT Checklist

- [ ] Database memakai utf8mb4.
- [ ] Semua tabel bisnis memakai InnoDB.
- [ ] Migration berjalan dari database kosong.
- [ ] Foreign key valid.
- [ ] Scope columns tersedia.
- [ ] Soft delete tersedia.
- [ ] Index query utama tersedia.
- [ ] Password/API key tidak plain.
- [ ] Query transaksi memakai tenant/scope.
- [ ] Seeder idempotent.

---

# 52. Definition of Done

Implementasi MySQL dianggap sesuai standar bila:

- semua tabel mengikuti naming convention;
- memakai InnoDB dan utf8mb4;
- primary key konsisten;
- foreign key dan index tersedia;
- scope-aware untuk data transaksi;
- soft delete untuk data bisnis;
- migration tracked;
- seed idempotent;
- tidak ada secret plain;
- query utama diuji dengan EXPLAIN;
- kompatibel dengan MySQL/MariaDB XAMPP.
