
# SSOT-IMPLEMENTATION-01 — Modular Monolith Architecture & Module Lifecycle

## Status

| Item | Nilai |
|---|---|
| Kode | SSOT-IMPLEMENTATION-01 |
| Versi | 1.0 |
| Status | Draft |
| Domain | Implementation Guide |

# 1. Tujuan

Dokumen ini menjelaskan cara mengimplementasikan Platform Kernel sebagai **Modular Monolith** sehingga seluruh modul mengikuti pola yang sama.

# 2. Prinsip

- Satu codebase.
- Satu deployment.
- Banyak module independen.
- Kernel tidak bergantung pada module bisnis.
- Komunikasi antarmodul melalui Service, Event, atau API internal.
- Tidak ada akses langsung ke tabel modul lain.

# 3. Arsitektur

```text
Presentation
    │
Controller
    │
Service
    │
Repository
    │
Database

            │
        Event Bus
            │
 Workflow / Notification / Integration
```

# 4. Siklus Hidup Module

1. Registrasi module.
2. Registrasi migration.
3. Registrasi permission.
4. Registrasi menu.
5. Registrasi route.
6. Registrasi workflow (bila perlu).
7. Registrasi event.
8. Registrasi notification.
9. UAT.
10. Go-live.

# 5. Struktur Module

```text
Modules/
└── Patient/
    ├── Application/
    ├── Domain/
    ├── Infrastructure/
    ├── Http/
    ├── Resources/
    ├── Database/
    └── Module.php
```

# 6. Dependency Rule

Module boleh bergantung pada:

- Platform Kernel
- SDK

Module tidak boleh bergantung langsung pada modul bisnis lain.

# 7. Lifecycle Request

Browser/API
→ Middleware
→ Controller
→ Service
→ Repository
→ Transaction
→ Audit
→ Outbox
→ Commit
→ Event Bus
→ Notification/Workflow

# 8. Definition of Module Done

- Migration selesai
- Seeder selesai
- Permission selesai
- Menu selesai
- API/Web selesai
- Audit aktif
- Event aktif
- UAT lulus
- Dokumentasi diperbarui

# 9. Anti-pattern

- Business logic di Controller
- Query SQL di View
- Modul mengakses tabel modul lain secara langsung
- Hardcoded role/permission
- Tidak menggunakan transaction

# 10. Dokumen Lanjutan

Seri implementasi:

- SSOT-IMPLEMENTATION-02 — Module Structure & Coding Standards
- SSOT-IMPLEMENTATION-03 — Controller, Request & Response
- SSOT-IMPLEMENTATION-04 — Service Layer & Transaction Management
- SSOT-IMPLEMENTATION-05 — Repository Layer & Database Access
- SSOT-IMPLEMENTATION-06 — Event, Workflow & Notification Integration
- SSOT-IMPLEMENTATION-07 — Module Registration & Dynamic Menu
- SSOT-IMPLEMENTATION-08 — End-to-End Feature Development Guide
- SSOT-IMPLEMENTATION-09 — Code Review & Quality Checklist
- SSOT-IMPLEMENTATION-10 — Reference Module (Golden Module)
