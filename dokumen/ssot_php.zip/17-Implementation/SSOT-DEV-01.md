
# SSOT-DEV-01 — Local Development Guide for Windows

## Status

| Item | Nilai |
|---|---|
| Kode | SSOT-DEV-01 |
| Nama | Local Development Guide for Windows |
| Versi | 1.0 |
| Target | Windows 10/11 + XAMPP |
| Stack | PHP, Apache, MySQL/MariaDB, Composer |

---

# 1. Tujuan

Dokumen ini menjadi panduan standar agar seluruh developer memiliki lingkungan pengembangan yang konsisten.

---

# 2. Software Minimum

- Windows 10/11 64-bit
- XAMPP (PHP 8.1+)
- Composer 2.x
- Git
- Visual Studio Code
- Browser modern

Opsional:

- Node.js (frontend)
- Postman/Insomnia
- DBeaver

---

# 3. Struktur Folder

```text
D:\xampp\htdocs\
    nerslink\
```

Project:

```text
D:\xampp\htdocs\nerslink
```

---

# 4. Clone Repository

```bash
cd D:\xampp\htdocs
git clone <repository-url> nerslink
cd nerslink
```

---

# 5. Install Dependency

```bash
composer install
composer dump-autoload
```

---

# 6. Konfigurasi .env

Salin:

```text
.env.example
```

menjadi:

```text
.env
```

Sesuaikan:

```env
APP_ENV=local
APP_DEBUG=true
APP_URL=http://nerslink.local

DB_HOST=127.0.0.1
DB_PORT=3306
DB_DATABASE=nerslink_platform2
DB_USERNAME=root
DB_PASSWORD=
```

---

# 7. Buat Database

Masuk phpMyAdmin atau MySQL:

```sql
CREATE DATABASE nerslink_platform2
CHARACTER SET utf8mb4
COLLATE utf8mb4_unicode_ci;
```

---

# 8. Jalankan Migration

```bash
D:\xampp\php\php.exe tools\migrate.php
```

Verifikasi tabel:

- migrations
- users
- roles
- permissions

---

# 9. Jalankan Seeder

```bash
D:\xampp\php\php.exe tools\seed.php
```

Minimal menghasilkan:

- admin
- role
- permission
- tenant
- organization

---

# 10. Virtual Host

Edit:

```text
D:\xampp\apache\conf\extra\httpd-vhosts.conf
```

Tambahkan:

```apache
<VirtualHost *:80>
 ServerName nerslink.local
 DocumentRoot "D:/xampp/htdocs/nerslink/public"

 <Directory "D:/xampp/htdocs/nerslink/public">
   AllowOverride All
   Require all granted
 </Directory>
</VirtualHost>
```

---

# 11. Hosts File

Edit sebagai Administrator:

```text
C:\Windows\System32\drivers\etc\hosts
```

Tambahkan:

```text
127.0.0.1 nerslink.local
```

Restart Apache.

---

# 12. Verifikasi

Buka:

```text
http://nerslink.local
```

Pastikan halaman login muncul.

---

# 13. Login Awal

Gunakan akun seed:

- Administrator
- Password sesuai seed project

Segera ubah password setelah login pertama.

---

# 14. Struktur Kerja Developer

Jangan mengubah langsung:

- app/Core
- kernel
- framework

Modul bisnis berada di:

```text
app/Modules/
```

---

# 15. Menambah Module

1. Buat folder module.
2. Tambah migration.
3. Tambah repository.
4. Tambah service.
5. Tambah controller.
6. Tambah route.
7. Tambah permission.
8. Tambah menu.
9. Tambah audit/event.
10. Tambah UAT.

---

# 16. Menjalankan Health Check

```bash
D:\xampp\php\php.exe tools\health_check.php
```

Periksa:

- PHP
- DB
- Storage
- .env
- Migration

---

# 17. Log

Lokasi:

```text
storage/logs/
```

Periksa saat terjadi error.

---

# 18. Troubleshooting

## Apache tidak start

- Port 80 dipakai aplikasi lain.
- Ganti ke 8080 atau hentikan layanan yang memakai port 80.

## MySQL tidak start

- Port 3306 dipakai.
- Periksa log MySQL XAMPP.

## Composer tidak ditemukan

Gunakan:

```bash
D:\xampp\php\php.exe composer.phar install
```

## Halaman 404

- Pastikan VirtualHost aktif.
- Pastikan mod_rewrite aktif.
- Periksa .htaccess.

## Database gagal koneksi

Periksa:

- .env
- service MySQL
- nama database
- username/password

---

# 19. Git Workflow

- Buat branch fitur.
- Jangan commit .env.
- Jangan commit storage/logs.
- Jalankan migration sebelum pull request.
- Sertakan perubahan SSOT bila mengubah arsitektur.

---

# 20. Checklist Developer Baru

- [ ] XAMPP terpasang
- [ ] Composer terpasang
- [ ] Repository berhasil di-clone
- [ ] composer install sukses
- [ ] .env dibuat
- [ ] Database dibuat
- [ ] Migration sukses
- [ ] Seeder sukses
- [ ] VirtualHost aktif
- [ ] Login berhasil
- [ ] Health check lulus

---

# 21. Definition of Done

Environment dianggap siap bila:

- aplikasi dapat diakses melalui browser;
- login berhasil;
- migration dan seeder berjalan;
- storage writable;
- audit dan RBAC aktif;
- developer dapat mulai mengembangkan modul tanpa konfigurasi tambahan.
