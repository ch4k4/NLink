
# SSOT-CODE-01 — PHP Coding Standard

## Status Dokumen

| Item | Nilai |
|---|---|
| Kode | SSOT-CODE-01 |
| Nama | PHP Coding Standard |
| Versi | 1.0 |
| Status | Draft Implementation Standard |
| Domain | Coding Standard |
| Target Stack | PHP 8.1+, MySQL/MariaDB, XAMPP Windows |
| Bergantung pada | SSOT-STACK-01, SSOT-DEV-01, SSOT-DATA, SSOT-API, SSOT-AUDIT, SSOT-RBAC, SSOT-SCOPE |

---

# 1. Tujuan

Dokumen ini menetapkan standar coding PHP untuk seluruh pengembangan Platform Kernel dan modul bisnis.

Tujuannya:

- kode konsisten antar developer;
- mudah dibaca dan dirawat;
- aman dari kesalahan umum PHP;
- siap untuk modular monolith;
- selaras dengan Scope, RBAC, Audit, Event, dan Repository Pattern;
- cocok dijalankan di XAMPP Windows tanpa mengorbankan kualitas arsitektur.

---

# 2. Versi PHP

Minimal:

```text
PHP 8.1+
```

Rekomendasi:

```text
PHP 8.2+
```

Gunakan fitur modern:

- typed property;
- constructor property promotion;
- readonly property bila tersedia;
- enum bila tersedia;
- nullsafe operator;
- match expression;
- strict types.

---

# 3. Strict Types

Setiap file PHP class wajib diawali:

```php
<?php

declare(strict_types=1);
```

Alasan:

- mengurangi bug tipe data;
- membuat kontrak method lebih jelas;
- membantu static analysis.

---

# 4. PSR Standard

Gunakan:

```text
PSR-4 untuk autoloading
PSR-12 untuk coding style
PSR-7/15 optional untuk HTTP abstraction
PSR-3 untuk logging interface
```

Composer:

```json
{
  "autoload": {
    "psr-4": {
      "App\\\\": "app/"
    }
  }
}
```

---

# 5. Namespace Standard

Format:

```text
App\\Core\\{Component}
App\\Modules\\{ModuleName}\\{Layer}
```

Contoh:

```php
namespace App\Core\Database;

namespace App\Modules\Patient\Application\Services;

namespace App\Modules\Homecare\Infrastructure\Repositories;
```

---

# 6. Struktur Class

Urutan isi class:

```text
namespace
use statements
class declaration
constants
properties
constructor
public methods
protected methods
private methods
```

Contoh:

```php
<?php

declare(strict_types=1);

namespace App\Modules\Patient\Application\Services;

use App\Core\Database\TransactionManager;

final class RegisterPatientService
{
    public function __construct(
        private readonly TransactionManager $transaction
    ) {}

    public function execute(array $input): int
    {
        return $this->transaction->run(function () use ($input): int {
            // process
            return 1;
        });
    }
}
```

---

# 7. Naming Convention

## Class

```text
PascalCase
```

Contoh:

```text
PatientRepository
CreateUserService
PermissionChecker
```

## Method

```text
camelCase
```

Contoh:

```text
findById
createUser
assertCan
```

## Variable

```text
camelCase
```

Contoh:

```php
$userId
$patientId
$activeScope
```

## Constant

```text
UPPER_SNAKE_CASE
```

Contoh:

```php
private const MAX_LOGIN_ATTEMPTS = 5;
```

## Database

```text
snake_case
```

Contoh:

```text
patient_id
created_at
deleted_by
```

---

# 8. File Naming

Class file mengikuti nama class:

```text
PatientRepository.php
CreatePatientService.php
PermissionMiddleware.php
```

Satu file = satu class utama.

---

# 9. Final Class by Default

Gunakan `final` untuk class yang tidak dirancang untuk inheritance.

```php
final class UserRepository
{
}
```

Gunakan inheritance hanya jika benar-benar diperlukan.

Prefer composition over inheritance.

---

# 10. Visibility

Selalu tulis visibility:

```php
public
protected
private
```

Tidak boleh property/method tanpa visibility.

---

# 11. Typed Properties

Gunakan typed properties.

```php
private PDO $pdo;
private string $tableName;
private int $userId;
```

Hindari property dinamis.

---

# 12. Constructor Injection

Dependency masuk melalui constructor.

```php
final class UserService
{
    public function __construct(
        private readonly UserRepository $users,
        private readonly AuditLogger $audit
    ) {}
}
```

Hindari service locator di business logic.

---

# 13. Return Type Wajib

Setiap function/method wajib punya return type.

```php
public function findById(int $id): ?array
{
}
```

Jika tidak mengembalikan nilai:

```php
public function log(array $event): void
{
}
```

---

# 14. Parameter Type Wajib

Parameter wajib diberi type bila memungkinkan.

```php
public function updateStatus(int $id, string $status): void
{
}
```

---

# 15. Array Shape

Jika memakai array untuk DTO ringan, dokumentasikan shape.

```php
/**
 * @param array{
 *   name:string,
 *   email:string
 * } $input
 */
public function create(array $input): int
{
}
```

Untuk data penting, gunakan DTO class.

---

# 16. DTO Standard

DTO digunakan untuk membawa data antar layer.

```php
final readonly class PatientData
{
    public function __construct(
        public int $id,
        public string $medicalRecordNumber,
        public string $fullName
    ) {}
}
```

DTO tidak boleh berisi business logic berat.

---

# 17. Enum Standard

Jika PHP mendukung enum, gunakan enum untuk status penting.

```php
enum UserStatus: string
{
    case Active = 'active';
    case Disabled = 'disabled';
    case Locked = 'locked';
}
```

Jika belum memakai enum, gunakan constant class.

---

# 18. Exception Standard

Gunakan exception spesifik.

Contoh:

```text
RecordNotFoundException
ForbiddenException
ValidationException
DuplicateRecordException
BusinessRuleException
```

Jangan lempar `Exception` generik untuk semua kasus.

---

# 19. Error Message

Error untuk user harus aman.

Jangan tampilkan:

```text
SQLSTATE[23000]
Stack trace
File path internal
```

Tampilkan:

```text
Terjadi kesalahan sistem.
```

Detail masuk log.

---

# 20. Logging Standard

Gunakan logger terpusat.

Log context:

```text
correlation_id
user_id
tenant_id
ip_address
route
exception_class
```

Jangan log:

```text
password
token
api_key
client_secret
OTP
raw PHI tanpa kebutuhan
```

---

# 21. Database Access

Wajib lewat Repository.

Controller dan View tidak boleh query database.

Gunakan PDO prepared statement:

```php
$stmt = $this->pdo->prepare(
    'SELECT * FROM users WHERE id = :id'
);

$stmt->execute(['id' => $id]);
```

Tidak boleh:

```php
$sql = "SELECT * FROM users WHERE id = $id";
```

---

# 22. Transaction

Gunakan TransactionManager untuk operasi multi-tabel.

```php
$this->transaction->run(function (): void {
    $this->patients->create(...);
    $this->audit->log(...);
});
```

---

# 23. Controller Rule

Controller hanya boleh:

- menerima request;
- memanggil service;
- mengembalikan response.

Tidak boleh:

- query database;
- business rule panjang;
- generate event langsung tanpa service;
- manipulasi banyak table.

---

# 24. Service Rule

Service berisi orchestration.

Service boleh:

- validasi business rule;
- membuka transaction;
- memanggil repository;
- memanggil audit/event/workflow;
- mengembalikan hasil.

---

# 25. Repository Rule

Repository berisi query.

Repository wajib:

- scope-aware untuk data transaksi;
- soft delete aware;
- prepared statement;
- pagination untuk list besar;
- tidak memuat business rule berat.

---

# 26. View Rule

View hanya untuk presentasi.

Tidak boleh:

```php
$db->query(...)
```

Tidak boleh menulis logic bisnis kompleks di view.

---

# 27. Request Validation

Validasi input dilakukan sebelum masuk service.

Validasi meliputi:

- required;
- type;
- length;
- format;
- enum;
- file type;
- business-safe constraint.

---

# 28. Output Escaping

Semua output HTML harus di-escape.

```php
htmlspecialchars($value, ENT_QUOTES, 'UTF-8');
```

Jangan echo input user mentah.

---

# 29. CSRF

Form web wajib CSRF.

```php
<input type="hidden" name="_token" value="<?= e($csrfToken) ?>">
```

API stateless memakai token/API key, bukan CSRF.

---

# 30. Password

Gunakan:

```php
password_hash($password, PASSWORD_ARGON2ID);
password_verify($password, $hash);
```

Fallback:

```php
PASSWORD_BCRYPT
```

Tidak boleh:

```text
md5
sha1
base64
custom encryption
```

---

# 31. Session

Setelah login:

```php
session_regenerate_id(true);
```

Session tidak boleh menyimpan data besar.

Simpan:

```text
user_id
active_scope_id
session_id
```

Jangan simpan permission lengkap bila cache sudah tersedia.

---

# 32. File Upload

Validasi:

- extension;
- MIME type;
- magic bytes;
- size;
- malware scan bila tersedia.

File sensitif simpan di:

```text
storage/files
```

Bukan:

```text
public/uploads
```

---

# 33. API Response

Gunakan envelope standar:

```php
return Response::json([
    'success' => true,
    'data' => $data,
    'meta' => [],
    'errors' => [],
    'correlation_id' => $correlationId,
]);
```

---

# 34. Date & Time

Gunakan `DateTimeImmutable`.

```php
$now = new DateTimeImmutable('now', new DateTimeZone('UTC'));
```

Display ke user:

```text
Asia/Jakarta
```

---

# 35. Money

Jangan gunakan float untuk uang.

Gunakan integer satuan terkecil.

Contoh:

```text
150000 = Rp 150.000
```

Atau gunakan decimal string.

---

# 36. Boolean

Database boleh memakai:

```text
TINYINT(1)
```

PHP gunakan:

```php
bool
```

Pastikan casting eksplisit.

---

# 37. Null Handling

Jangan pakai string kosong sebagai pengganti null untuk field opsional.

Gunakan:

```php
null
```

---

# 38. Magic Number

Hindari angka magic.

Tidak boleh:

```php
if ($attempts > 5) {}
```

Gunakan:

```php
private const MAX_LOGIN_ATTEMPTS = 5;
```

---

# 39. Configuration

Konfigurasi di:

```text
config/*.php
.env
```

Jangan hardcode:

```text
URL provider
password
path storage
feature flag
```

---

# 40. Security Baseline

Wajib:

- prepared statements;
- output escaping;
- CSRF;
- session regeneration;
- password hashing;
- permission middleware;
- scope middleware;
- audit logging;
- file validation;
- no secret in Git;
- no stack trace in production.

---

# 41. Static Analysis

Rekomendasi:

```text
PHPStan
Psalm
```

Level awal:

```text
PHPStan level 5
```

Naik bertahap.

---

# 42. Code Formatter

Rekomendasi:

```text
PHP-CS-Fixer
```

Target:

```text
PSR-12
```

---

# 43. Comment Standard

Komentar menjelaskan **kenapa**, bukan **apa**.

Baik:

```php
// Audit must be written before commit because role changes are security-sensitive.
```

Kurang baik:

```php
// increment i
```

---

# 44. PHPDoc

Gunakan PHPDoc untuk:

- array shape;
- generic collection;
- complex return;
- domain explanation.

Jangan PHPDoc yang mengulang type hint sederhana.

---

# 45. Anti-pattern Umum

Hindari:

```text
business logic di controller
query di view
SQL string concatenation
global variable liar
include file acak
class tanpa namespace
file PHP campur HTML, SQL, dan logic
password plain
role hardcoded
scope dari request user mentah
audit dilupakan
event dipublish sebelum commit
```

---

# 46. Contoh Layer Lengkap

Flow:

```text
Route
→ Controller
→ Request Validator
→ Service
→ Repository
→ Audit
→ Outbox
→ Response
```

Contoh service:

```php
final class CreatePatientService
{
    public function __construct(
        private readonly PatientRepository $patients,
        private readonly AuditLogger $audit,
        private readonly TransactionManager $transaction
    ) {}

    public function execute(array $input, ActorContext $actor): int
    {
        return $this->transaction->run(function () use ($input, $actor): int {
            $patientId = $this->patients->create($input, $actor->scope);

            $this->audit->log('patient.record.created', [
                'patient_id' => $patientId,
                'actor_user_id' => $actor->userId,
            ]);

            return $patientId;
        });
    }
}
```

---

# 47. Pull Request Checklist

Sebelum merge:

- [ ] strict_types aktif
- [ ] namespace benar
- [ ] tidak ada SQL di controller/view
- [ ] prepared statement
- [ ] permission check tersedia
- [ ] scope check tersedia
- [ ] audit tersedia
- [ ] transaction untuk multi-table
- [ ] response API standar
- [ ] error handling aman
- [ ] tidak ada secret di kode
- [ ] UAT tersedia

---

# 48. Definition of Done

Kode PHP dianggap memenuhi standar bila:

- mengikuti PSR-4 dan PSR-12;
- memakai strict types;
- class/method/property typed;
- controller tipis;
- service layer jelas;
- repository layer aman;
- database access memakai PDO prepared statement;
- input tervalidasi;
- output di-escape;
- scope dan RBAC diterapkan;
- audit untuk aksi penting;
- error/log aman;
- tidak ada anti-pattern kritis.
