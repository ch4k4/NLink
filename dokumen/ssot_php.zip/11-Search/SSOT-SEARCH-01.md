
# SSOT-SEARCH-01 — Search & Indexing

## Status Dokumen

| Item | Nilai |
|---|---|
| Kode | SSOT-SEARCH-01 |
| Nama | Search & Indexing |
| Versi | 1.0 |
| Domain | Platform Kernel / Search |
| Bergantung pada | SSOT-EVENT-01..03, SSOT-FILE-01, SSOT-RBAC, SSOT-SCOPE, SSOT-AUDIT |

# 1. Tujuan

Menyediakan arsitektur pencarian yang cepat, konsisten, aman, dan dapat diskalakan untuk seluruh platform tanpa membebani database transaksi.

Search digunakan untuk:

- pasien
- EMR
- homecare
- woundcare
- billing
- inventory
- CRM
- dokumen
- modul non-healthcare

# 2. Prinsip

- Search menggunakan read model/index.
- Database transaksi bukan mesin pencarian utama.
- Index dibangun dari event.
- Scope-aware.
- RBAC-aware.
- Audit-aware.
- Eventually consistent.

# 3. Komponen

- search_indexes
- search_documents
- search_index_jobs
- search_aliases
- search_synonyms
- search_query_logs

# 4. Arsitektur

Business Transaction
→ Event Bus
→ Index Worker
→ Search Index

Search hanya membaca index.

# 5. Database — search_indexes

```sql
CREATE TABLE search_indexes(
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 code VARCHAR(100) UNIQUE,
 name VARCHAR(150),
 entity_type VARCHAR(100),
 engine VARCHAR(50),
 status ENUM('active','rebuilding','inactive') DEFAULT 'active',
 created_at TIMESTAMP NULL,
 updated_at TIMESTAMP NULL
);
```

# 6. Database — search_documents

```sql
CREATE TABLE search_documents(
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 index_code VARCHAR(100) NOT NULL,
 resource_type VARCHAR(100) NOT NULL,
 resource_id BIGINT UNSIGNED NOT NULL,
 tenant_id BIGINT UNSIGNED NOT NULL,
 business_entity_id BIGINT UNSIGNED NULL,
 document_hash CHAR(64) NULL,
 indexed_at DATETIME NULL,
 UNIQUE KEY uq_doc(index_code,resource_type,resource_id)
);
```

# 7. Database — search_index_jobs

Menyimpan:

- rebuild
- update
- delete
- retry
- status
- duration

# 8. Database — search_query_logs

Menyimpan:

- actor
- keyword
- filter
- duration
- result_count
- correlation_id

# 9. Indexing Flow

Domain Event
→ Resolve Index
→ Build Search Document
→ Update Index
→ Audit

# 10. Rebuild

Rebuild dilakukan melalui replay event atau pembacaan batch database.

Selama rebuild gunakan alias agar downtime minimal.

# 11. Alias

Alias memungkinkan:

- blue/green index
- zero-downtime rebuild
- rollback

# 12. Search Engine

Fase awal:

- MySQL Fulltext (opsional)
- OpenSearch
- Elasticsearch

Engine harus dapat diganti melalui adapter.

# 13. Search Document

Contoh:

```json
{
 "patient_id":103,
 "mrn":"RM000103",
 "name":"Budi",
 "phone":"08xxxx",
 "status":"active"
}
```

Hanya data yang diperlukan untuk pencarian.

# 14. Filtering

Mendukung:

- tenant
- branch
- department
- status
- date
- category

Filter wajib divalidasi.

# 15. Scope

Index boleh menyimpan scope.

Query selalu menambahkan scope aktif.

# 16. RBAC

Hasil pencarian tidak boleh menampilkan resource yang tidak boleh diakses.

# 17. PHI Rule

Data sensitif:

- minim di index
- jangan index clinical note penuh
- gunakan masking bila perlu

# 18. File Search

Metadata file dapat diindex.

Isi file sensitif hanya diindex jika kebijakan mengizinkan.

# 19. Ranking

Pertimbangkan:

- exact match
- prefix
- typo tolerance
- freshness
- business boost

# 20. Synonym

Contoh:

DM = Diabetes Mellitus

Disimpan pada search_synonyms.

# 21. Pagination

Standar mengikuti SSOT-API.

# 22. Monitoring

Pantau:

- indexing lag
- failed jobs
- query latency
- rebuild duration
- index size

# 23. Audit

Event:

- search.index.updated
- search.index.rebuilt
- search.query.executed
- search.query.denied

# 24. UAT

- Event membuat index terbarui.
- Rebuild berhasil.
- Scope membatasi hasil.
- RBAC membatasi hasil.
- Query cepat dan audit tercatat.

# 25. Anti-pattern

- query LIKE ke tabel besar
- index tanpa event
- search mengabaikan scope
- PHI penuh di index
- rebuild mengunci aplikasi

# 26. Definition of Done

- Index adapter tersedia.
- Event-driven indexing tersedia.
- Rebuild tersedia.
- Alias tersedia.
- Scope & RBAC diterapkan.
- Audit tersedia.
- Monitoring tersedia.
