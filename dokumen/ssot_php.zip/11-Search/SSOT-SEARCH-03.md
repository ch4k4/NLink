# SSOT-SEARCH-03 — Search Reindexing, Consistency & Lifecycle Governance

## Status Dokumen

| Item | Nilai |
|---|---|
| Kode | SSOT-SEARCH-03 |
| Judul | Search Reindexing, Consistency & Lifecycle Governance |
| Versi | 1.0 |
| Status | Draft Architecture |
| Domain | Platform Kernel |
| Kategori | Search Operations, Index Lifecycle & Consistency |
| Cakupan | Versioned Index, Reindexing, Alias Switching, Consistency, Recovery, Rollback, Deletion Propagation, Reconciliation |
| Bergantung pada | SSOT-GOV-01, SSOT-GOV-04, SSOT-GOV-05, SSOT-SEARCH-01, SSOT-SEARCH-02, SSOT-EVENT-01, SSOT-EVENT-02, SSOT-EVENT-03, SSOT-OBS-01, SSOT-DATA-06, SSOT-FILE-03, SSOT-TEST-01 |
| Target Stack | PHP 8.1+, Search Engine-compatible, Queue/Event-ready |
| Target Evolusi | Distributed Reindexing, Zero-Downtime Search Migration, Continuous Consistency Verification |

# 1. Executive Summary

SSOT-SEARCH-03 menetapkan governance resmi untuk lifecycle index, reindexing, consistency, recovery, rollback, deletion propagation, dan reconciliation.

Dokumen ini mengatur:

- index lifecycle;
- versioned index;
- index aliases;
- blue-green reindexing;
- full reindex;
- partial reindex;
- incremental indexing;
- backfill;
- source snapshot;
- dual write;
- replay;
- cutover;
- rollback;
- stale index handling;
- indexing lag;
- deletion propagation;
- tombstone;
- consistency verification;
- disaster recovery;
- capacity planning;
- observability;
- reconciliation;
- database direction;
- API direction;
- SDK contracts;
- UAT;
- Definition of Done;
- implementation roadmap.

Tujuan akhirnya adalah memastikan search index:

- dapat dibangun ulang tanpa downtime;
- tetap konsisten dengan source of truth;
- tidak kehilangan deletion;
- tidak menerima event lama di atas versi baru;
- dapat rollback;
- dapat dipulihkan;
- dapat diverifikasi;
- memiliki evidence operasional.

# 2. Objectives

Framework harus:

- menyediakan canonical index lifecycle;
- mendukung zero-downtime reindex;
- mendukung blue-green alias switch;
- menjaga source-version consistency;
- mendukung replay dan backfill;
- menyediakan rollback;
- menjaga deletion consistency;
- mengukur indexing lag;
- menyediakan reconciliation;
- mendukung disaster recovery.

# 3. Core Principles

```text
Indexes Are Disposable, Sources Are Authoritative
Every Index Version Is Immutable After Cutover
Reindexing Must Be Repeatable
Cutover Must Be Atomic
Rollback Must Be Planned
Deletion Must Never Be Lost
Older Events Must Not Overwrite Newer State
Consistency Must Be Measurable
Rebuilds Must Be Auditable
No Manual Hidden Changes in Production Indexes
```

# 4. Scope

Berlaku untuk:

```text
Search Indexes
Aliases
Index Templates
Mappings
Analyzers
Synonyms
Document Pipelines
Indexing Jobs
Reindex Jobs
Deletion Pipelines
Search Caches
```

# 5. Non-Scope

Dokumen ini tidak menetapkan:

- vendor-specific deployment commands;
- ranking-model design;
- natural-language search model;
- database migration governance;
- business data ownership.

# 6. Index Lifecycle States

```text
PROPOSED
BUILDING
VALIDATING
READY
ACTIVE
DEGRADED
READ_ONLY
ROLLBACK_READY
DEPRECATED
RETIRED
FAILED
```

# 7. Index Version Identity

Recommended format:

```text
{index_code}-v{schema_version}-{build_id}
```

Contoh:

```text
patient-directory-v3-20260706-001
```

# 8. Logical Index Alias

Applications query logical alias, not physical index name.

# 9. Alias Types

```text
READ_ALIAS
WRITE_ALIAS
SHADOW_ALIAS
ROLLBACK_ALIAS
```

# 10. Active Index

Exactly one active read target per logical search contract unless sharding/federation policy defines otherwise.

# 11. Write Target

Write alias must point to the expected active build.

# 12. Immutable Schema Version

Index schema version changes when mappings, analyzers, security metadata, or field policies materially change.

# 13. Index Manifest

Minimum:

```text
index_code
schema_version
source_contract_version
security_policy_version
mapping_checksum
analyzer_checksum
owner
retention
```

# 14. Reindex Types

```text
FULL
PARTIAL
INCREMENTAL
REPAIR
BACKFILL
SECURITY_REINDEX
DELETION_REPAIR
```

# 15. Full Reindex

Rebuilds complete index from source of truth.

# 16. Partial Reindex

Rebuilds bounded subset by tenant, module, date range, or resource scope.

# 17. Incremental Indexing

Consumes source changes after a checkpoint.

# 18. Repair Reindex

Repairs known inconsistent documents.

# 19. Backfill

Indexes historical data not previously included.

# 20. Security Reindex

Rebuilds authorization metadata, masking policy, classification, or tenant bindings.

# 21. Reindex Lifecycle

```text
Plan
→ Snapshot Source
→ Create New Index
→ Apply Mapping
→ Bulk Load
→ Replay Delta
→ Validate
→ Switch Alias
→ Observe
→ Retire Old Index
```

# 22. Reindex Plan

Minimum:

```text
reason
scope
source snapshot
target schema
expected volume
capacity
cutover strategy
rollback strategy
validation criteria
owner
```

# 23. Source Snapshot

Reindex must define a consistent source boundary.

# 24. Snapshot Strategies

```text
DATABASE_SNAPSHOT
HIGH_WATER_MARK
EVENT_OFFSET
TIMESTAMP_BOUNDARY
TRANSACTION_ID
```

# 25. High-Water Mark

Records changes after snapshot boundary for delta replay.

# 26. Event Offset

Store exact event stream position used for build.

# 27. Bulk Load

Must be:

- idempotent;
- resumable;
- partitionable;
- rate limited;
- observable;
- tenant-aware.

# 28. Bulk Load Checkpoint

Each partition stores checkpoint and status.

# 29. Partitioning

Possible:

```text
tenant
primary-key range
date range
module
shard
```

# 30. Dual Write

Optional during migration, but must not be sole consistency mechanism.

# 31. Dual Write Risks

- partial success;
- ordering;
- retry duplication;
- hidden divergence;
- operational complexity.

# 32. Delta Replay

Replay source changes after snapshot into new index.

# 33. Replay Ordering

Use source version or monotonic sequence to prevent stale overwrite.

# 34. Event Idempotency

Same event processed multiple times must yield same index state.

# 35. Out-of-Order Event

Older source version must be rejected or ignored.

# 36. Document Version

Every indexed document should carry source version.

# 37. Deletion Events

Deletion must be represented explicitly.

# 38. Tombstones

Tombstones preserve deletion intent during rebuild and restore.

# 39. Tombstone Fields

```text
source_id
tenant_id
deleted_at
source_version
deletion_reason
```

# 40. Deletion Replay

Reindex must apply all deletions after snapshot.

# 41. Soft Delete

Soft-deleted records must follow visibility policy.

# 42. Hard Delete

Hard-deleted records must not reappear after rebuild.

# 43. Privacy Deletion

Privacy deletion/anonymization must propagate to all active and rollback-ready indexes.

# 44. Legal Hold

Legal hold may preserve source but does not automatically imply search visibility.

# 45. Validation

Validation must cover:

- document count;
- tenant count;
- checksums/sample hashes;
- source version;
- deletion state;
- security metadata;
- query behavior;
- latency;
- error rate.

# 46. Count Comparison

Count mismatches must be explained by policy, deletion, filtering, or timing.

# 47. Sample Validation

Use deterministic samples per tenant and category.

# 48. Security Validation

Verify:

- tenant isolation;
- scope metadata;
- field policies;
- masking;
- classification;
- deleted content absence.

# 49. Query Validation

Run canonical query suite against old and new indexes.

# 50. Shadow Traffic

Optional read-only comparison using mirrored queries.

# 51. Shadow Result Comparison

Compare:

- result count;
- top results;
- authorization behavior;
- latency;
- errors;
- projection.

# 52. Cutover

Alias switch must be atomic where engine supports.

# 53. Cutover Preconditions

- build completed;
- delta replay caught up;
- validation passed;
- rollback index ready;
- monitoring active;
- approval complete.

# 54. Cutover Freeze

Short controlled write freeze may be used if atomic consistency cannot otherwise be guaranteed.

# 55. Post-Cutover Observation

Monitor:

- error rate;
- latency;
- zero-result rate;
- tenant leakage indicators;
- indexing lag;
- deletion lag;
- resource utilization.

# 56. Rollback

Rollback returns alias to previous validated index.

# 57. Rollback Triggers

- authorization defect;
- missing documents;
- high error rate;
- latency regression;
- mapping incompatibility;
- deletion failure;
- data corruption.

# 58. Rollback Window

Previous index retained for bounded rollback period.

# 59. Rollback Data

Old index may need delta replay before reactivation.

# 60. Rollback Security

Old index must still satisfy current critical security/deletion requirements.

# 61. Index Retirement

Preconditions:

- rollback window expired;
- active index stable;
- evidence retained;
- no active dependency;
- deletion/privacy requirements applied.

# 62. Index Deletion

Physical index deletion must be approved and auditable.

# 63. Stale Index

Index is stale when source changes exceed freshness SLA.

# 64. Staleness States

```text
CURRENT
LAGGING
STALE
UNTRUSTED
```

# 65. Stale Index Behavior

Possible:

```text
WARN
DEGRADE_FEATURES
READ_ONLY
FALLBACK_TO_DATABASE
DISABLE_SEARCH
```

# 66. Critical Search

Critical workflows should define fallback behavior.

# 67. Indexing Lag

Measure:

```text
source_change_time → searchable_time
```

# 68. Deletion Lag

Measure:

```text
source_deletion_time → no_longer_searchable_time
```

# 69. Freshness SLA

Define per index and data category.

# 70. Index Health

Inputs:

- cluster health;
- shard status;
- queue depth;
- indexing lag;
- error rate;
- storage;
- query latency;
- reconciliation findings.

# 71. Degraded Mode

May disable autocomplete, facets, broad search, or exports first.

# 72. Mapping Changes

Breaking mapping changes require new physical index.

# 73. Non-Breaking Mapping Changes

Still require validation and version tracking.

# 74. Analyzer Changes

Analyzer changes generally require reindex.

# 75. Synonym Changes

May require reload or reindex depending on engine and policy.

# 76. Security Policy Changes

Changes to authorization metadata or field policy may require security reindex.

# 77. Index Template Governance

Templates must be versioned and checksummed.

# 78. Manual Index Changes

Direct production changes outside controlled pipeline are prohibited.

# 79. Capacity Planning

Estimate:

- document volume;
- growth;
- shard count;
- replicas;
- storage;
- bulk throughput;
- query load;
- retention of rollback indexes.

# 80. Reindex Throttling

Protect production database and search cluster.

# 81. Backpressure

Pause or slow indexing when downstream is unhealthy.

# 82. Retry

Retry must distinguish transient and permanent errors.

# 83. Dead-Letter

Permanent indexing failures go to dead-letter with reason and remediation path.

# 84. Poison Document

Malformed or repeatedly failing document must be isolated.

# 85. Indexing Job States

```text
QUEUED
RUNNING
PAUSED
RETRYING
COMPLETED
FAILED
CANCELLED
```

# 86. Job Idempotency

Re-running same job/partition must not duplicate effects.

# 87. Job Cancellation

Cancellation must preserve checkpoint and cleanup partial resources.

# 88. Disaster Recovery

DR plan must define:

- index rebuild source;
- event replay source;
- tombstone source;
- security policy source;
- acceptable recovery time;
- acceptable freshness loss.

# 89. Rebuild vs Backup Restore

Preferred strategy depends on source availability and index size.

# 90. Search Backups

Search snapshots may accelerate recovery but do not replace source-of-truth rebuild capability.

# 91. Restore Validation

Restored index must be validated before activation.

# 92. Multi-Region Search

Must define:

- active/active or active/passive;
- replication lag;
- deletion propagation;
- tenant residency;
- failover;
- consistency expectations.

# 93. Index Migration

Engine/vendor migration follows blue-green lifecycle.

# 94. Cross-Version Compatibility

Application clients should target logical contract version.

# 95. Search Contract

Search response contract changes must be versioned separately from physical index.

# 96. Reindex Service Contract

```php
interface SearchReindexServiceInterface
{
    public function start(
        SearchReindexRequest $request
    ): SearchReindexRun;

    public function cutover(
        SearchCutoverRequest $request
    ): SearchCutoverResult;
}
```

# 97. Snapshot Provider Contract

```php
interface SearchSourceSnapshotProviderInterface
{
    public function create(
        SearchSourceSnapshotRequest $request
    ): SearchSourceSnapshot;
}
```

# 98. Consistency Validator Contract

```php
interface SearchConsistencyValidatorInterface
{
    public function validate(
        SearchConsistencyRequest $request
    ): SearchConsistencyReport;
}
```

# 99. Alias Manager Contract

```php
interface SearchAliasManagerInterface
{
    public function switch(
        SearchAliasSwitchRequest $request
    ): SearchAliasSwitchResult;
}
```

# 100. Index Registry

Minimum:

```text
logical_index
physical_index
schema_version
source_version
security_policy_version
status
activated_at
retire_after
```

# 101. Reconciliation

Compare:

- source records;
- active index;
- rollback index;
- tombstones;
- event offsets;
- aliases;
- mappings;
- security metadata;
- index registry.

# 102. Reconciliation Findings

```text
SOURCE_DOCUMENT_MISSING
ORPHAN_INDEX_DOCUMENT
STALE_SOURCE_VERSION
DELETION_NOT_PROPAGATED
TOMBSTONE_MISSING
ALIAS_TARGET_MISMATCH
MAPPING_CHECKSUM_MISMATCH
SECURITY_POLICY_VERSION_DRIFT
ROLLBACK_INDEX_UNSAFE
EVENT_OFFSET_GAP
```

# 103. Audit Events

```text
SEARCH_REINDEX_PLANNED
SEARCH_REINDEX_STARTED
SEARCH_REINDEX_PARTITION_COMPLETED
SEARCH_REINDEX_VALIDATION_FAILED
SEARCH_REINDEX_READY
SEARCH_ALIAS_SWITCHED
SEARCH_REINDEX_ROLLED_BACK
SEARCH_INDEX_DEPRECATED
SEARCH_INDEX_RETIRED
SEARCH_CONSISTENCY_FINDING_CREATED
```

# 104. Metrics

```text
search_reindex_run_total
search_reindex_duration_seconds
search_reindex_document_total
search_reindex_failure_total
search_indexing_lag_seconds
search_deletion_lag_seconds
search_dead_letter_total
search_alias_switch_total
search_rollback_total
search_consistency_failure_total
```

# 105. KPIs

```text
Alias switch without successful validation = 0
Deleted records reappearing after rebuild = 0
Critical security policy drift = 0
Indexing lag beyond SLA = 0 for critical indexes
Untracked production index changes = 0
Rollback indexes violating deletion policy = 0
Reindex jobs without checkpoints = 0
```

# 106. KRIs

```text
Indexing lag growth
Deletion lag growth
Dead-letter growth
Reindex duration growth
Rollback frequency
Shadow query divergence
Storage pressure
Repeated poison documents
```

# 107. Database Direction

Potential tables:

```text
search_index_lifecycle
search_index_aliases
search_reindex_runs
search_reindex_partitions
search_source_snapshots
search_index_checkpoints
search_index_tombstones
search_index_dead_letters
search_consistency_runs
search_consistency_findings
```

# 108. Table: search_index_lifecycle

```sql
CREATE TABLE search_index_lifecycle (
    id CHAR(26) NOT NULL,
    logical_index_code VARCHAR(180) NOT NULL,
    physical_index_name VARCHAR(255) NOT NULL,
    schema_version VARCHAR(100) NOT NULL,
    source_contract_version VARCHAR(100) NOT NULL,
    security_policy_version VARCHAR(100) NOT NULL,
    mapping_checksum_sha256 CHAR(64) NOT NULL,
    status VARCHAR(30) NOT NULL,
    activated_at DATETIME(6) NULL,
    retire_after DATETIME(6) NULL,

    PRIMARY KEY (id),
    UNIQUE KEY uq_search_physical_index (
        physical_index_name
    ),
    KEY idx_search_index_lifecycle (
        logical_index_code,
        status
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

# 109. Table: search_reindex_runs

```sql
CREATE TABLE search_reindex_runs (
    id CHAR(26) NOT NULL,
    run_code VARCHAR(100) NOT NULL,
    logical_index_code VARCHAR(180) NOT NULL,
    reindex_type VARCHAR(40) NOT NULL,
    source_snapshot_reference VARCHAR(1000) NOT NULL,
    source_high_water_mark VARCHAR(255) NULL,
    target_physical_index VARCHAR(255) NOT NULL,
    status VARCHAR(30) NOT NULL,
    started_at DATETIME(6) NULL,
    completed_at DATETIME(6) NULL,
    requested_by VARCHAR(180) NOT NULL,

    PRIMARY KEY (id),
    UNIQUE KEY uq_search_reindex_run_code (
        run_code
    ),
    KEY idx_search_reindex_status (
        logical_index_code,
        status,
        started_at
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

# 110. Table: search_reindex_partitions

```sql
CREATE TABLE search_reindex_partitions (
    id CHAR(26) NOT NULL,
    reindex_run_id CHAR(26) NOT NULL,
    partition_code VARCHAR(180) NOT NULL,
    checkpoint_value VARCHAR(500) NULL,
    processed_count BIGINT UNSIGNED NOT NULL DEFAULT 0,
    failed_count BIGINT UNSIGNED NOT NULL DEFAULT 0,
    status VARCHAR(30) NOT NULL,
    started_at DATETIME(6) NULL,
    completed_at DATETIME(6) NULL,

    PRIMARY KEY (id),
    UNIQUE KEY uq_search_reindex_partition (
        reindex_run_id,
        partition_code
    ),
    CONSTRAINT fk_search_reindex_partition_run
        FOREIGN KEY (reindex_run_id)
        REFERENCES search_reindex_runs (id)
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

# 111. Table: search_index_tombstones

```sql
CREATE TABLE search_index_tombstones (
    id CHAR(26) NOT NULL,
    logical_index_code VARCHAR(180) NOT NULL,
    tenant_id CHAR(26) NOT NULL,
    source_id VARCHAR(255) NOT NULL,
    source_version VARCHAR(100) NOT NULL,
    deletion_reason VARCHAR(100) NOT NULL,
    deleted_at DATETIME(6) NOT NULL,

    PRIMARY KEY (id),
    UNIQUE KEY uq_search_index_tombstone (
        logical_index_code,
        tenant_id,
        source_id
    ),
    KEY idx_search_tombstone_deleted_at (
        deleted_at
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

# 112. Table: search_consistency_findings

```sql
CREATE TABLE search_consistency_findings (
    id CHAR(26) NOT NULL,
    run_id CHAR(26) NOT NULL,
    logical_index_code VARCHAR(180) NOT NULL,
    finding_type VARCHAR(60) NOT NULL,
    severity VARCHAR(30) NOT NULL,
    tenant_id CHAR(26) NULL,
    source_id VARCHAR(255) NULL,
    expected_state_json JSON NULL,
    actual_state_json JSON NULL,
    status VARCHAR(30) NOT NULL,
    detected_at DATETIME(6) NOT NULL,

    PRIMARY KEY (id),
    KEY idx_search_consistency_finding (
        logical_index_code,
        severity,
        status
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

# 113. API Direction

```text
GET  /api/internal/v1/search/index-lifecycle
POST /api/internal/v1/search/reindex-runs
GET  /api/internal/v1/search/reindex-runs/{runCode}
POST /api/internal/v1/search/reindex-runs/{runCode}/pause
POST /api/internal/v1/search/reindex-runs/{runCode}/resume
POST /api/internal/v1/search/reindex-runs/{runCode}/validate
POST /api/internal/v1/search/reindex-runs/{runCode}/cutover
POST /api/internal/v1/search/reindex-runs/{runCode}/rollback
POST /api/internal/v1/search/consistency/runs
GET  /api/internal/v1/search/consistency/findings
```

# 114. Error Codes

```text
SEARCH_REINDEX_PLAN_INVALID
SEARCH_SOURCE_SNAPSHOT_FAILED
SEARCH_REINDEX_PARTITION_FAILED
SEARCH_REINDEX_CHECKPOINT_INVALID
SEARCH_REINDEX_VALIDATION_FAILED
SEARCH_ALIAS_SWITCH_FAILED
SEARCH_ROLLBACK_UNAVAILABLE
SEARCH_STALE_EVENT_REJECTED
SEARCH_DELETION_REPLAY_FAILED
SEARCH_INDEX_UNTRUSTED
SEARCH_CONSISTENCY_FAILED
SEARCH_DR_RECOVERY_FAILED
```

# 115. Reindex Checklist

- [ ] Reason documented.
- [ ] Source boundary defined.
- [ ] Target schema version defined.
- [ ] Security policy version defined.
- [ ] Capacity checked.
- [ ] Partition strategy defined.
- [ ] Checkpoints enabled.
- [ ] Tombstones included.
- [ ] Delta replay planned.
- [ ] Validation criteria defined.
- [ ] Cutover plan approved.
- [ ] Rollback plan approved.

# 116. Cutover Checklist

- [ ] Bulk load complete.
- [ ] Delta replay caught up.
- [ ] Document counts validated.
- [ ] Security validation passed.
- [ ] Deletion validation passed.
- [ ] Query suite passed.
- [ ] Performance accepted.
- [ ] Rollback index ready.
- [ ] Monitoring active.
- [ ] Approval recorded.
- [ ] Alias switch atomic.
- [ ] Audit generated.

# 117. UAT — Full Reindex

- [ ] New physical index created.
- [ ] Mapping checksum matches.
- [ ] Bulk partitions complete.
- [ ] Checkpoint resume works.
- [ ] Duplicate processing remains idempotent.
- [ ] Delta replay catches up.
- [ ] Validation report generated.
- [ ] Alias switch succeeds.
- [ ] Old index retained for rollback.

# 118. UAT — Ordering & Idempotency

- [ ] Duplicate event produces no duplicate.
- [ ] Older event cannot overwrite newer document.
- [ ] Out-of-order delete handled correctly.
- [ ] Source version retained.
- [ ] Retry after failure resumes checkpoint.
- [ ] Poison document moves to dead-letter.
- [ ] Permanent failure visible.
- [ ] Manual repair reindexes only target document.

# 119. UAT — Deletion Consistency

- [ ] Soft delete removes visibility.
- [ ] Hard delete removes document.
- [ ] Tombstone survives rebuild.
- [ ] Privacy deletion reaches active index.
- [ ] Privacy deletion reaches rollback index.
- [ ] Deleted record does not reappear after restore.
- [ ] Deletion lag metric updates.
- [ ] Missing tombstone detected.

# 120. UAT — Cutover & Rollback

- [ ] Cutover is atomic.
- [ ] Queries continue during switch.
- [ ] Write alias targets correct index.
- [ ] Critical defect triggers rollback.
- [ ] Rollback restores query behavior.
- [ ] Old index receives required deletion updates.
- [ ] Rollback event audited.
- [ ] Retired index cannot reactivate accidentally.

# 121. UAT — Staleness & Degraded Mode

- [ ] Lagging state detected.
- [ ] Stale threshold triggers warning.
- [ ] Untrusted state disables search.
- [ ] Critical workflow fallback works.
- [ ] Autocomplete disables before core search where configured.
- [ ] Index recovery returns state to current.
- [ ] Operator notification generated.
- [ ] Metrics recover after catch-up.

# 122. UAT — Disaster Recovery

- [ ] Search snapshot restores.
- [ ] Source rebuild works.
- [ ] Event offsets resume correctly.
- [ ] Tombstones restore.
- [ ] Security policy reapplies.
- [ ] Validation required before alias activation.
- [ ] RTO measured.
- [ ] RPO measured.
- [ ] DR evidence retained.

# 123. UAT — Consistency Reconciliation

- [ ] Missing document detected.
- [ ] Orphan document detected.
- [ ] Stale version detected.
- [ ] Deletion drift detected.
- [ ] Alias mismatch detected.
- [ ] Mapping checksum drift detected.
- [ ] Security policy drift detected.
- [ ] Event offset gap detected.
- [ ] Critical finding opens incident.
- [ ] Repair reindex resolves finding.

# 124. Definition of Done — SSOT-SEARCH-03

SSOT-SEARCH-03 dianggap selesai bila:

- [ ] index lifecycle tersedia;
- [ ] versioned physical indexes tersedia;
- [ ] alias governance tersedia;
- [ ] full/partial/incremental reindex tersedia;
- [ ] source snapshot and high-water mark tersedia;
- [ ] partition/checkpoint tersedia;
- [ ] delta replay tersedia;
- [ ] ordering/idempotency tersedia;
- [ ] deletion/tombstone handling tersedia;
- [ ] validation suite tersedia;
- [ ] blue-green cutover tersedia;
- [ ] rollback tersedia;
- [ ] staleness/degraded mode tersedia;
- [ ] mapping/analyzer lifecycle tersedia;
- [ ] retry/dead-letter tersedia;
- [ ] DR recovery tersedia;
- [ ] reconciliation tersedia;
- [ ] audit/metrics tersedia;
- [ ] database direction tersedia;
- [ ] API direction tersedia;
- [ ] SDK contracts tersedia;
- [ ] UAT and DoD tersedia.

# 125. Implementation Roadmap

## Phase 1 — Index Lifecycle Foundation

- physical index registry;
- aliases;
- manifests;
- lifecycle states;
- mapping checksums;
- operational APIs.

## Phase 2 — Reindex Engine

- snapshots;
- partitions;
- checkpoints;
- bulk loading;
- delta replay;
- dead-letter handling.

## Phase 3 — Validation & Cutover

- count validation;
- sample validation;
- security validation;
- query comparison;
- alias cutover;
- rollback.

## Phase 4 — Consistency & Recovery

- tombstones;
- deletion replay;
- staleness detection;
- degraded mode;
- reconciliation;
- DR restore.

## Phase 5 — Continuous Search Operations

- shadow traffic;
- distributed reindexing;
- automated repair;
- multi-region consistency;
- predictive capacity;
- continuous consistency dashboard.

# 126. Initial Implementation Backlog

```text
SEARCH03-001 Index Lifecycle Registry
SEARCH03-002 Alias Manager
SEARCH03-003 Source Snapshot Provider
SEARCH03-004 Reindex Run Service
SEARCH03-005 Partition Planner
SEARCH03-006 Checkpoint Store
SEARCH03-007 Bulk Index Worker
SEARCH03-008 Delta Replay Worker
SEARCH03-009 Tombstone Registry
SEARCH03-010 Validation Suite
SEARCH03-011 Shadow Query Comparator
SEARCH03-012 Cutover Orchestrator
SEARCH03-013 Rollback Orchestrator
SEARCH03-014 Staleness Monitor
SEARCH03-015 Consistency Engine
SEARCH03-016 Search Operations Dashboard
```

# 127. Approval Gate

Dokumen dapat menjadi Approved setelah:

- Search Architecture review;
- Data Architecture review;
- Security review;
- Event Architecture review;
- Operations/SRE review;
- Backup/DR review;
- Audit/Compliance review;
- Quality Engineering review;
- UAT review.

# 128. Closing Statement

Search index harus dapat dibuang dan dibangun kembali dari source of truth.

Reindexing harus repeatable, observable, tenant-aware, dan deletion-safe.

Cutover harus atomic.

Rollback harus tersedia.

Index yang tidak konsisten tidak boleh dianggap terpercaya.
