
# SSOT-API-03 — API Gateway & Rate Limiting

## Status Dokumen

| Item | Nilai |
|---|---|
| Kode | SSOT-API-03 |
| Nama | API Gateway & Rate Limiting |
| Versi | 1.0 |
| Status | Draft Architecture |
| Domain | Platform Kernel / API |
| Bergantung pada | SSOT-API-01, SSOT-API-02, SSOT-IAM, SSOT-SCOPE, SSOT-RBAC, SSOT-AUDIT |

---

# 1. Tujuan

API Gateway & Rate Limiting adalah lapisan kontrol untuk melindungi API platform dari trafik berlebihan, penyalahgunaan, brute force, scraping, integrasi buruk, dan akses tidak sah.

Gateway menjadi pintu masuk standar untuk:

- web app;
- mobile app;
- partner API;
- service account;
- webhook;
- integrasi eksternal;
- microservice future-ready.

---

# 2. Prinsip Dasar

- Semua request API melewati gateway.
- Gateway tidak menggantikan authorization di service.
- Rate limit berlaku per actor, API key, tenant, endpoint, dan IP.
- Semua penolakan gateway diaudit.
- Gateway harus mendukung observability.
- Gateway harus future-ready untuk WAF, IP allowlist, quota, dan circuit breaker.

---

# 3. Fungsi API Gateway

```text
request routing
authentication pre-check
rate limiting
quota enforcement
IP allowlist/denylist
request size limit
CORS policy
correlation ID
request logging
response standardization
circuit breaker
maintenance mode
API version routing
```

---

# 4. Gateway Request Flow

```text
Request masuk
→ Validate protocol/HTTPS
→ Correlation ID
→ Request size check
→ IP allowlist/denylist
→ CORS check
→ Rate limit pre-check
→ Authentication
→ Rate limit actor-based
→ Scope/RBAC downstream
→ Route to controller/service
→ Response
→ Audit/metrics
```

---

# 5. Rate Limit Dimensions

Rate limit dapat diberlakukan berdasarkan:

```text
ip_address
tenant_id
user_id
api_client_id
api_key_id
service_account_id
endpoint
http_method
route_group
```

---

# 6. Rate Limit Types

```text
fixed_window
sliding_window
token_bucket
leaky_bucket
quota_daily
quota_monthly
```

Fase awal cukup:

```text
fixed_window
quota_daily
```

Future-ready:

```text
sliding_window
token_bucket
```

---

# 7. Rate Limit Policy

Contoh policy:

```text
login: 5 request / menit / IP
password reset: 3 request / jam / identifier
API key auth: 60 request / menit / key
patient read: 300 request / menit / user
export: 5 request / jam / user
webhook receive: 100 request / menit / client
```

---

# 8. Database — api_rate_limit_policies

```sql
CREATE TABLE api_rate_limit_policies (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,

    policy_code VARCHAR(100) NOT NULL UNIQUE,
    policy_name VARCHAR(150) NOT NULL,

    dimension VARCHAR(50) NOT NULL,
    route_pattern VARCHAR(255) NULL,
    http_method VARCHAR(10) NULL,

    limit_count INT NOT NULL,
    window_seconds INT NOT NULL,

    burst_limit INT NULL,
    quota_daily INT NULL,
    quota_monthly INT NULL,

    status ENUM('active','inactive') NOT NULL DEFAULT 'active',

    created_at TIMESTAMP NULL,
    updated_at TIMESTAMP NULL
);
```

---

# 9. Database — api_rate_limit_counters

```sql
CREATE TABLE api_rate_limit_counters (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,

    policy_id BIGINT UNSIGNED NOT NULL,
    dimension_key VARCHAR(255) NOT NULL,

    window_start DATETIME NOT NULL,
    window_end DATETIME NOT NULL,

    request_count INT NOT NULL DEFAULT 0,

    created_at TIMESTAMP NULL,
    updated_at TIMESTAMP NULL,

    UNIQUE KEY uq_rate_counter (policy_id, dimension_key, window_start),
    INDEX idx_rate_counter_window (window_end)
);
```

Catatan: untuk performa tinggi, counter sebaiknya memakai cache/Redis, sedangkan database dipakai untuk policy dan audit summary.

---

# 10. Database — api_quota_usage

```sql
CREATE TABLE api_quota_usage (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,

    tenant_id BIGINT UNSIGNED NULL,
    api_client_id BIGINT UNSIGNED NULL,
    user_id BIGINT UNSIGNED NULL,

    quota_type ENUM('daily','monthly') NOT NULL,
    quota_key VARCHAR(255) NOT NULL,

    period_start DATE NOT NULL,
    period_end DATE NOT NULL,

    used_count INT NOT NULL DEFAULT 0,
    limit_count INT NOT NULL,

    created_at TIMESTAMP NULL,
    updated_at TIMESTAMP NULL,

    UNIQUE KEY uq_quota_usage (quota_type, quota_key, period_start),
    INDEX idx_quota_scope (tenant_id, api_client_id, user_id)
);
```

---

# 11. Database — api_ip_access_rules

```sql
CREATE TABLE api_ip_access_rules (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,

    tenant_id BIGINT UNSIGNED NULL,
    api_client_id BIGINT UNSIGNED NULL,

    rule_type ENUM('allow','deny') NOT NULL,
    ip_cidr VARCHAR(100) NOT NULL,

    description TEXT NULL,

    status ENUM('active','inactive') NOT NULL DEFAULT 'active',

    created_at TIMESTAMP NULL,
    updated_at TIMESTAMP NULL,

    INDEX idx_ip_rule_scope (tenant_id, api_client_id),
    INDEX idx_ip_rule_type (rule_type, status)
);
```

---

# 12. Database — api_gateway_logs

```sql
CREATE TABLE api_gateway_logs (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,

    tenant_id BIGINT UNSIGNED NULL,
    user_id BIGINT UNSIGNED NULL,
    api_client_id BIGINT UNSIGNED NULL,
    api_key_id BIGINT UNSIGNED NULL,

    method VARCHAR(10) NOT NULL,
    path VARCHAR(500) NOT NULL,
    route_name VARCHAR(150) NULL,

    status_code INT NULL,
    gateway_result ENUM('allowed','blocked','rate_limited','denied','error') NOT NULL,

    block_reason VARCHAR(150) NULL,

    ip_address VARCHAR(45) NULL,
    user_agent TEXT NULL,

    duration_ms INT NULL,

    correlation_id VARCHAR(100) NULL,
    request_id VARCHAR(100) NULL,

    created_at TIMESTAMP NULL,

    INDEX idx_gateway_log_created (created_at),
    INDEX idx_gateway_log_actor (tenant_id, user_id, api_client_id),
    INDEX idx_gateway_log_result (gateway_result),
    INDEX idx_gateway_log_correlation (correlation_id)
);
```

---

# 13. Rate Limit Response

Jika rate limit tercapai:

```http
429 Too Many Requests
```

Response:

```json
{
  "success": false,
  "errors": [
    {
      "code": "api.rate_limit_exceeded",
      "message": "Terlalu banyak request. Coba lagi nanti."
    }
  ],
  "correlation_id": "..."
}
```

Header:

```text
X-RateLimit-Limit
X-RateLimit-Remaining
X-RateLimit-Reset
Retry-After
```

---

# 14. Request Size Limit

Gateway wajib membatasi ukuran request.

Contoh:

```text
JSON body: 1–5 MB
File upload: sesuai policy file
Webhook: sesuai provider policy
```

Request terlalu besar:

```http
413 Payload Too Large
```

---

# 15. CORS Policy

CORS harus dikonfigurasi per environment dan tenant bila perlu.

Tidak boleh:

```text
Access-Control-Allow-Origin: *
```

untuk endpoint sensitif.

---

# 16. IP Allowlist / Denylist

Digunakan untuk:

- partner API;
- service account;
- admin endpoint;
- integration endpoint.

Denylist mengalahkan allowlist jika konflik.

---

# 17. WAF Future-ready

Gateway harus bisa dipasang di belakang/di depan WAF.

WAF melindungi dari:

- SQL injection;
- XSS;
- known exploit;
- bot traffic;
- suspicious payload.

Namun validasi aplikasi tetap wajib.

---

# 18. Circuit Breaker

Circuit breaker mencegah service downstream overload.

Status:

```text
closed
open
half_open
```

Jika downstream gagal berulang:

```text
open circuit
return 503
```

---

# 19. Maintenance Mode

Gateway dapat menolak request tertentu saat maintenance.

Kecuali:

- health check;
- admin maintenance endpoint;
- emergency endpoint bila diizinkan.

---

# 20. Health Check

Endpoint:

```text
GET /health
GET /ready
GET /live
```

Jangan bocorkan detail sensitif pada public health check.

---

# 21. API Version Routing

Gateway dapat mengarahkan:

```text
/api/v1/*
/api/v2/*
```

ke handler versi yang sesuai.

---

# 22. Observability

Metrik minimum:

```text
request_count
latency_p50/p95/p99
error_rate
rate_limited_count
blocked_ip_count
auth_failed_count
quota_usage
```

---

# 23. Audit Integration

Event audit:

```text
api.gateway.request.allowed
api.gateway.request.blocked
api.gateway.rate_limited
api.gateway.ip_denied
api.gateway.quota_exceeded
api.gateway.circuit_opened
api.gateway.maintenance_blocked
```

Audit menyimpan:

```text
actor
tenant
client
endpoint
method
ip
result
reason
correlation_id
created_at
```

---

# 24. Security Rule

Gateway tidak boleh menyimpan payload penuh untuk request berisi PHI/PII.

Gunakan:

```text
request_hash
payload_size
schema_version
```

---

# 25. Healthcare Rule

Endpoint healthcare sensitif:

- EMR;
- patient data;
- billing;
- document disclosure;

harus memiliki limit lebih ketat untuk export dan bulk read.

---

# 26. Admin Endpoint Protection

Endpoint admin harus:

- MFA/step-up;
- IP allowlist bila memungkinkan;
- rate limit ketat;
- audit detail;
- permission khusus.

---

# 27. Partner API Protection

Partner API harus:

- API key/client credential;
- IP allowlist;
- quota;
- webhook signature;
- retry policy;
- monitoring.

---

# 28. UAT Scenario

## Scenario 1 — Normal Request

```text
Given request valid
When masuk gateway
Then request diteruskan ke service
And gateway log tercatat
```

## Scenario 2 — Rate Limit

```text
Given user melebihi limit
When request berikutnya
Then response 429
And audit api.gateway.rate_limited tercatat
```

## Scenario 3 — IP Denied

```text
Given IP masuk denylist
When request API
Then response 403/401 sesuai policy
And audit ip_denied tercatat
```

## Scenario 4 — Payload Too Large

```text
Given request body melebihi batas
When request dikirim
Then response 413
```

## Scenario 5 — Quota Exceeded

```text
Given API client melebihi quota harian
When request API
Then response 429
And quota_exceeded tercatat
```

---

# 29. Anti-pattern

Hindari:

```text
rate limit hanya berdasarkan IP
tidak ada rate limit login
gateway menyimpan payload sensitif penuh
CORS wildcard untuk API sensitif
semua partner memakai quota unlimited
gateway dianggap pengganti RBAC
tidak ada correlation ID
```

---

# 30. Definition of Done

API Gateway & Rate Limiting dianggap siap bila:

- gateway flow terdokumentasi;
- rate limit policy tersedia;
- quota tersedia;
- IP allowlist/denylist tersedia;
- request size limit tersedia;
- CORS policy tersedia;
- gateway logs tersedia;
- audit gateway tersedia;
- observability tersedia;
- mendukung admin endpoint protection;
- mendukung partner API protection;
- tidak menggantikan Scope/RBAC di service.
