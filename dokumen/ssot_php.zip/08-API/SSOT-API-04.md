
# SSOT-API-04 — Webhook & Callback Architecture

## Status Dokumen

| Item | Nilai |
|---|---|
| Kode | SSOT-API-04 |
| Domain | Platform Kernel / API |
| Bergantung pada | SSOT-API-01..03, SSOT-NOTIFY, SSOT-AUDIT |

# 1. Tujuan

Menetapkan standar pengiriman dan penerimaan webhook/callback yang aman, andal, dapat diulang, dan dapat diaudit.

# 2. Prinsip

- Event-driven.
- Signed request.
- Idempotent.
- Retryable.
- Observable.
- Audit lengkap.

# 3. Use Case

- HIS ↔ BPJS
- Payment gateway
- WhatsApp provider
- SMS provider
- CRM
- ERP
- Marketplace
- Sistem partner

# 4. Komponen

```text
webhook_endpoints
webhook_subscriptions
webhook_events
webhook_deliveries
webhook_attempts
webhook_secrets
webhook_dead_letters
```

# 5. Database

## webhook_endpoints

```sql
CREATE TABLE webhook_endpoints(
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 tenant_id BIGINT UNSIGNED NULL,
 code VARCHAR(100) UNIQUE,
 callback_url VARCHAR(500) NOT NULL,
 auth_type ENUM('signature','bearer','apikey','mtls') DEFAULT 'signature',
 status ENUM('active','inactive') DEFAULT 'active',
 created_at TIMESTAMP NULL,
 updated_at TIMESTAMP NULL
);
```

## webhook_subscriptions

```sql
CREATE TABLE webhook_subscriptions(
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 endpoint_id BIGINT UNSIGNED NOT NULL,
 event_code VARCHAR(150) NOT NULL,
 enabled TINYINT(1) DEFAULT 1,
 created_at TIMESTAMP NULL,
 updated_at TIMESTAMP NULL
);
```

## webhook_deliveries

```sql
CREATE TABLE webhook_deliveries(
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 endpoint_id BIGINT UNSIGNED NOT NULL,
 event_code VARCHAR(150),
 payload_hash CHAR(64),
 status ENUM('queued','sent','failed','dead_letter') DEFAULT 'queued',
 attempts INT DEFAULT 0,
 next_retry_at DATETIME NULL,
 correlation_id VARCHAR(100),
 created_at TIMESTAMP NULL,
 updated_at TIMESTAMP NULL
);
```

# 6. Signature

Header:

```text
X-Signature
X-Timestamp
X-Correlation-ID
```

Gunakan HMAC-SHA256 dengan secret per endpoint.

# 7. Replay Protection

Validasi:

- timestamp
- nonce/idempotency key
- toleransi waktu (mis. ±5 menit)

# 8. Delivery Flow

```text
Domain Event
→ Resolve subscription
→ Queue delivery
→ Sign payload
→ POST callback
→ Success
atau
Retry
→ Dead Letter
```

# 9. Retry

- exponential backoff
- maksimum 5 percobaan (default)
- dead-letter setelah gagal

# 10. Dead Letter Queue

Payload gagal permanen disimpan untuk investigasi dan replay manual.

# 11. Callback Receiver

Receiver wajib:

- verifikasi signature
- cek timestamp
- cek replay
- validasi schema
- proses idempotent

# 12. Timeout

Default:

- connect 5 detik
- response 30 detik

# 13. Response

2xx = sukses

4xx = kesalahan permanen (opsional tanpa retry sesuai policy)

5xx/timeout = retry

# 14. Event Version

Payload memuat:

```json
{
  "event":"homecare.visit.completed",
  "event_version":"1.0",
  "occurred_at":"...",
  "correlation_id":"..."
}
```

# 15. Observability

Pantau:

- success rate
- retry count
- latency
- dead letter
- endpoint health

# 16. Audit

Event:

```text
webhook.delivery.queued
webhook.delivery.sent
webhook.delivery.failed
webhook.delivery.retried
webhook.delivery.dead_letter
webhook.signature.invalid
```

# 17. Healthcare Rule

Jangan mengirim PHI penuh melalui webhook kecuali:

- ada dasar hukum/kontrak;
- kanal terenkripsi;
- partner berwenang.

# 18. UAT

- Signature tervalidasi.
- Retry berjalan.
- Replay ditolak.
- Dead letter terbentuk.
- Audit tercatat.

# 19. Anti-pattern

- webhook tanpa signature
- retry tanpa batas
- payload tanpa version
- callback tidak idempotent
- secret hardcoded

# 20. Definition of Done

- Signature tersedia.
- Replay protection tersedia.
- Retry & dead-letter tersedia.
- Observability tersedia.
- Audit lengkap.
- Mendukung healthcare dan non-healthcare.
