
# SSOT-API-02 — Authentication & Authorization Flow

## Status Dokumen

| Item | Nilai |
|---|---|
| Kode | SSOT-API-02 |
| Nama | Authentication & Authorization Flow |
| Versi | 1.0 |
| Status | Draft Architecture |
| Domain | Platform Kernel / API |
| Bergantung pada | SSOT-API-01, SSOT-IAM-01..05, SSOT-SCOPE, SSOT-RBAC, SSOT-AUDIT |

---

# 1. Tujuan

Dokumen ini mendefinisikan standar autentikasi dan otorisasi API agar seluruh endpoint platform memiliki kontrol akses yang konsisten, aman, scope-aware, RBAC-aware, dan audit-aware.

---

# 2. Prinsip Dasar

- Authentication menjawab: siapa pemanggil API?
- Scope menjawab: data wilayah mana yang boleh diakses?
- RBAC menjawab: aksi apa yang boleh dilakukan?
- Business rule menjawab: apakah aksi sah dalam konteks resource?
- Audit menjawab: apa yang benar-benar terjadi?

Urutan standar:

```text
Request
→ Correlation ID
→ Authentication
→ Token/API Key validation
→ Scope Resolution
→ RBAC Permission Check
→ Business Rule
→ Controller/Service
→ Audit
→ Response
```

---

# 3. Supported Authentication Methods

Platform mendukung:

```text
Session Cookie
Bearer Token
API Key
Client ID + Client Secret
Service Account Credential
OAuth2 Client Credentials (future-ready)
OIDC Login (future-ready)
mTLS (future-ready)
```

Fase awal minimal:

```text
Session Cookie
Bearer Token
API Key
Client ID + Client Secret
```

---

# 4. API Caller Types

```text
human_user
mobile_user
web_user
service_account
api_client
integration_client
system_job
webhook_sender
```

Setiap caller harus dimapping ke actor yang dapat diaudit.

---

# 5. Authentication Header Standard

## Bearer Token

```http
Authorization: Bearer <access_token>
```

## API Key

```http
X-API-Key: <api_key>
```

atau:

```http
Authorization: ApiKey <api_key>
```

## Client Credential

```http
X-Client-Id: <client_id>
X-Client-Secret: <client_secret>
```

---

# 6. Token Types

```text
access_token
refresh_token
personal_access_token
service_token
integration_token
temporary_token
```

---

# 7. Access Token Rule

Access token:

- short-lived;
- tidak disimpan plain;
- dapat direvoke;
- membawa reference ke user/session/client;
- tidak boleh menyimpan data sensitif berlebihan.

Recommended TTL:

```text
15 menit - 1 jam
```

---

# 8. Refresh Token Rule

Refresh token:

- lebih panjang masa berlaku;
- disimpan hash;
- rotation setiap dipakai;
- dapat direvoke;
- terikat device/session.

---

# 9. API Key Rule

API key:

- untuk machine-to-machine;
- disimpan hash;
- memiliki prefix;
- memiliki expiry;
- dapat dibatasi IP;
- dapat dibatasi scope;
- wajib audit.

---

# 10. Authentication Flow — Bearer Token

```text
Request masuk
→ Extract bearer token
→ Validate signature/hash
→ Check expiry
→ Check revoked status
→ Resolve user/session
→ Check user status
→ Resolve active scope
→ Continue to RBAC
```

Failure:

```text
401 Unauthorized
audit auth.token.failed
```

---

# 11. Authentication Flow — API Key

```text
Request masuk
→ Extract API key
→ Parse key prefix
→ Lookup key by prefix
→ Verify key hash
→ Check status
→ Check expiry
→ Check allowed IP
→ Resolve API client/service account
→ Resolve scope
→ Continue to RBAC
```

Failure:

```text
401 Unauthorized
audit auth.api_key.failed
```

---

# 12. Authentication Flow — Client Secret

```text
Request masuk
→ Validate client_id
→ Validate client_secret hash
→ Check client status
→ Check expiry
→ Issue service token or continue request
→ Audit
```

---

# 13. User Status Validation

User/caller ditolak jika:

```text
disabled
locked
terminated
archived
revoked
expired
```

---

# 14. Scope Resolution for API

Scope berasal dari:

```text
session active scope
token claim
api key scope
service account scope
explicit allowed scope header (hanya bila diizinkan)
```

Header scope tidak boleh dipercaya tanpa validasi.

Contoh optional header:

```http
X-Active-Business-Entity: 2
```

Sistem wajib memastikan caller memang punya scope tersebut.

---

# 15. Authorization Flow

```text
Authenticated actor
→ Scope valid
→ Required permission resolved from route
→ PermissionChecker.can(actor, permission, scope)
→ Business rule check
→ Allow/Deny
```

---

# 16. Route Permission Mapping

Setiap route harus memiliki permission.

Contoh:

```text
GET /api/v1/patients → patient.record.read
POST /api/v1/patients → patient.record.create
PATCH /api/v1/patients/{id} → patient.record.update
DELETE /api/v1/patients/{id} → patient.record.delete
```

---

# 17. Business Rule Layer

RBAC tidak cukup.

Contoh:

```text
Permission: emr.note.sign
Business rule: dokter harus memiliki clinical privilege aktif
```

Contoh lain:

```text
Permission: homecare.visit.update
Business rule: perawat harus assigned ke visit tersebut
```

---

# 18. Permission Denied Response

Gunakan:

```http
403 Forbidden
```

Response:

```json
{
  "success": false,
  "errors": [
    {
      "code": "access.forbidden",
      "message": "Anda tidak memiliki izin untuk melakukan aksi ini."
    }
  ],
  "correlation_id": "..."
}
```

Jangan bocorkan detail permission internal ke end-user biasa.

---

# 19. Authentication Failed Response

Gunakan:

```http
401 Unauthorized
```

Response:

```json
{
  "success": false,
  "errors": [
    {
      "code": "auth.unauthorized",
      "message": "Authentication required."
    }
  ],
  "correlation_id": "..."
}
```

---

# 20. Token Revocation

Token direvoke saat:

- logout;
- password reset;
- account disabled;
- session revoked;
- suspicious activity;
- API key revoked;
- client secret rotated.

---

# 21. Token Introspection

Untuk microservice future-ready, token dapat divalidasi melalui introspection endpoint.

```text
POST /api/v1/oauth/introspect
```

Response internal:

```json
{
  "active": true,
  "subject_type": "user",
  "subject_id": 12,
  "tenant_id": 1,
  "scope": {}
}
```

---

# 22. Impersonation

Impersonation sangat sensitif.

Default: tidak aktif.

Jika diaktifkan:

- permission khusus;
- alasan wajib;
- durasi terbatas;
- tidak boleh untuk PHI tanpa policy;
- semua aksi audit dengan actor asli dan actor impersonated.

Audit:

```text
api.impersonation.started
api.impersonation.ended
api.impersonation.action_performed
```

---

# 23. Step-up Authentication

Aksi API sensitif dapat membutuhkan step-up.

Contoh:

- export EMR;
- create API key;
- grant permission override;
- start break-glass;
- approve high-risk transaction.

Response jika butuh step-up:

```http
403 Forbidden
```

Code:

```text
auth.step_up_required
```

---

# 24. Break-glass API Access

Break-glass API hanya boleh untuk kondisi darurat.

Wajib:

- reason;
- expiry;
- audit;
- review;
- step-up bila human user.

---

# 25. Rate Limiting Integration

Rate limit diterapkan setelah identitas diketahui jika memungkinkan.

Basis:

```text
actor_user_id
api_client_id
api_key_id
tenant_id
ip_address
endpoint
```

---

# 26. Audit Events

Wajib:

```text
api.auth.success
api.auth.failed
api.authorization.allowed
api.authorization.denied
api.token.issued
api.token.refreshed
api.token.revoked
api.api_key.used
api.api_key.failed
api.client_secret.used
api.client_secret.failed
api.scope.denied
api.permission.denied
api.step_up.required
api.impersonation.started
api.impersonation.ended
```

Audit menyimpan:

```text
actor
caller_type
endpoint
method
permission
scope_snapshot
result
failure_reason
ip_address
user_agent
correlation_id
request_id
created_at
```

---

# 27. Middleware Order

Urutan middleware API:

```text
CorrelationIdMiddleware
RequestLoggingMiddleware
RateLimitPreCheckMiddleware
AuthenticationMiddleware
ScopeMiddleware
PermissionMiddleware
BusinessRuleMiddleware
AuditMiddleware
ResponseFormatterMiddleware
```

---

# 28. Service Account Rule

Service account:

- tidak boleh memakai session cookie;
- harus memakai API key/client credential/token;
- harus punya owner;
- harus scope-aware;
- harus RBAC-aware;
- semua aktivitas diaudit.

---

# 29. External Partner Rule

Partner API client:

- dibatasi IP bila memungkinkan;
- dibatasi endpoint;
- dibatasi rate limit;
- credential memiliki expiry;
- webhook memakai signature;
- payload sensitif dimasking di log.

---

# 30. Healthcare API Rule

Endpoint yang mengakses PHI/PII:

- wajib audit read access;
- wajib scope check;
- wajib permission spesifik;
- export butuh permission khusus;
- channel eksternal tidak boleh mengirim PHI penuh tanpa policy.

---

# 31. OpenAPI Security Definition

Dokumentasi OpenAPI harus mendefinisikan:

```text
bearerAuth
apiKeyAuth
clientCredentialAuth
```

Contoh:

```yaml
security:
  - bearerAuth: []
```

---

# 32. UAT Scenario

## Scenario 1 — Bearer Token Valid

```text
Given token valid
When request GET /patients
Then authentication success
And scope resolved
And permission checked
And response 200 jika allowed
```

## Scenario 2 — Token Expired

```text
Given token expired
When request API
Then response 401
And audit api.auth.failed tercatat
```

## Scenario 3 — Permission Denied

```text
Given user tidak punya patient.record.update
When PATCH /patients/{id}
Then response 403
And audit api.authorization.denied tercatat
```

## Scenario 4 — API Key Revoked

```text
Given API key revoked
When request API
Then response 401
And audit api.api_key.failed tercatat
```

## Scenario 5 — Service Account Scope Denied

```text
Given service account scope Klinik A
When request data Klinik B
Then response 403
And audit api.scope.denied tercatat
```

## Scenario 6 — Step-up Required

```text
Given user mau export EMR
When step-up belum valid
Then response auth.step_up_required
```

---

# 33. Anti-pattern

Hindari:

```text
API tanpa authentication
role dicek dari token tanpa validasi database
scope dari header dipercaya mentah
service account memakai akun manusia
token tidak bisa direvoke
API key plain di database
permission check di controller secara manual
endpoint sensitif tanpa audit
```

---

# 34. Definition of Done

API Authentication & Authorization dianggap siap bila:

- bearer token didukung;
- API key didukung;
- client secret didukung;
- token lifecycle tersedia;
- revocation tersedia;
- scope resolution tersedia;
- RBAC middleware tersedia;
- route permission mapping tersedia;
- business rule layer tersedia;
- step-up auth tersedia untuk aksi sensitif;
- service account aman;
- audit lengkap;
- OpenAPI security schema tersedia.
