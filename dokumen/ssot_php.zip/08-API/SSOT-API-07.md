# SSOT-API-07 — API Idempotency, Concurrency & Request Safety Governance

## Status Dokumen

| Item | Nilai |
|---|---|
| Kode | SSOT-API-07 |
| Judul | API Idempotency, Concurrency & Request Safety Governance |
| Versi | 1.0 |
| Status | Draft Architecture |
| Domain | Platform Kernel |
| Kategori | API Reliability, Concurrency Control & Safe Mutation |
| Cakupan | Idempotency Keys, Duplicate Requests, Optimistic Concurrency, Preconditions, Replay Safety, Race Conditions, Request Deduplication |
| Bergantung pada | SSOT-GOV-01, SSOT-GOV-04, SSOT-GOV-05, SSOT-AUDIT-01, SSOT-API-01..06, SSOT-INTEGRATION-04, SSOT-EVENT-05, SSOT-OBS-01, SSOT-TEST-01 |
| Target Stack | PHP 8.1+, REST/JSON, PDO, MySQL 8/MariaDB |
| Target Evolusi | Distributed Idempotency Service, Global Request Deduplication, Conflict-Free APIs, Policy-Driven Mutation Safety |

# 1. Executive Summary

SSOT-API-07 menetapkan governance resmi untuk idempotency, duplicate-request handling, optimistic concurrency, preconditions, race-condition handling, request replay safety, dan safe mutation.

Dokumen ini memastikan setiap mutating API:

- memiliki duplicate-request strategy;
- menggunakan idempotency bila diperlukan;
- mendeteksi stale updates;
- menolak conflicting writes;
- melindungi business effects;
- dapat membedakan retry aman dan retry berbahaya;
- menghindari double processing;
- dapat diaudit;
- dapat direkonsiliasi.

# 2. Objectives

Framework harus:

- menyediakan canonical idempotency model;
- menyediakan request fingerprinting;
- mencegah duplicate business effects;
- mendukung optimistic concurrency;
- mendukung HTTP preconditions;
- menangani concurrent writes;
- mengatur safe retries;
- menyediakan request-state registry;
- mendukung reconciliation;
- menghasilkan evidence.

# 3. Core Principles

```text
Retries Must Be Safe
Duplicate Requests Must Not Duplicate Effects
Idempotency Keys Are Scoped
Request Fingerprints Are Verified
Concurrent Writes Must Be Detected
Preconditions Must Be Enforced
Stale Updates Must Fail Safely
Unknown Outcomes Must Be Reconciled
Locks Must Be Bounded
Every Mutation Decision Is Auditable
```

# 4. Scope

Berlaku untuk:

```text
POST
PUT
PATCH
DELETE
Bulk Mutations
Payment-Like Operations
Workflow Actions
File Mutations
Partner APIs
Mobile Retry Scenarios
Background API Calls
```

# 5. Safe vs Unsafe Methods

General semantics:

```text
GET    safe and idempotent
HEAD   safe and idempotent
PUT    idempotent by contract
DELETE idempotent by contract
POST   non-idempotent unless governed
PATCH  potentially non-idempotent
```

Implementation must still enforce safety.

# 6. Idempotency Requirement

Required for:

- create operations with duplicate risk;
- financial effects;
- external side effects;
- workflow actions;
- booking/reservation;
- notification trigger;
- bulk imports;
- retry-prone mobile/partner calls.

# 7. Idempotency Key

Properties:

- client-generated or server-issued;
- opaque;
- unique within scope;
- bounded length;
- non-sensitive;
- stable for same logical request;
- not reused for different payload.

# 8. Idempotency Scope

Recommended dimensions:

```text
tenant
actor/client
endpoint
operation
resource
idempotency_key
```

# 9. Idempotency Record

Minimum:

```text
idempotency_key
scope
request_hash
status
response_status
response_reference
resource_reference
created_at
expires_at
```

# 10. Idempotency States

```text
RECEIVED
PROCESSING
COMPLETED
FAILED_RETRYABLE
FAILED_FINAL
EXPIRED
CONFLICT
```

# 11. First Request

First valid request atomically creates idempotency record.

# 12. Duplicate Request While Processing

Return controlled in-progress response or wait according to endpoint policy.

# 13. Completed Duplicate

Return original outcome or stable resource reference.

# 14. Same Key, Different Payload

Must return conflict.

# 15. Request Fingerprint

Recommended inputs:

```text
HTTP method
normalized path
tenant
actor/client
canonical body
selected headers
operation code
```

# 16. Canonical Body

Canonicalization must be deterministic.

# 17. Sensitive Data

Store hash, not full sensitive request, unless explicitly required and protected.

# 18. Idempotency TTL

TTL based on:

- retry window;
- business duplication risk;
- provider behavior;
- legal/audit needs;
- storage cost.

# 19. Expired Key Reuse

Policy must be explicit. High-risk operations should reject ambiguous reuse.

# 20. Atomic Acquisition

Use atomic insert or lock to establish single owner.

# 21. Concurrent Duplicate

Exactly one request may execute business effect.

# 22. Unknown Outcome

If process crashes after business commit but before idempotency completion:

- reconcile resource/effect;
- restore completed state;
- do not blindly execute again.

# 23. Response Replay

Response may be stored as:

- full safe response;
- resource reference;
- response hash;
- reconstructable result.

# 24. Response Privacy

Do not persist secrets, tokens, or sensitive payload unnecessarily.

# 25. Idempotent DELETE

Repeated delete should produce stable outcome without duplicate side effects.

# 26. Idempotent PUT

Repeated identical representation should converge to same resource state.

# 27. PATCH Safety

PATCH operation should use:

- resource version;
- precondition;
- operation idempotency where needed;
- conflict semantics.

# 28. Optimistic Concurrency

Every mutable resource should expose version or ETag where relevant.

# 29. Resource Version

Possible:

```text
integer version
updated_at precision timestamp
ETag
state revision
```

# 30. Preferred Version

Monotonic integer or strong ETag is preferred.

# 31. Preconditions

Supported:

```text
If-Match
If-None-Match
If-Unmodified-Since
resource_version
```

# 32. Update Precondition

Mutations should require current version for high-contention or sensitive resources.

# 33. Stale Write

Return conflict/precondition failure without applying change.

# 34. HTTP Status Direction

```text
409 Conflict
412 Precondition Failed
428 Precondition Required
```

Use consistent endpoint policy.

# 35. ETag

ETag must represent relevant resource state.

# 36. Weak vs Strong ETag

Strong ETag required for mutation preconditions.

# 37. Create-If-Absent

Use `If-None-Match: *` or unique constraint.

# 38. Lost Update Prevention

Flow:

```text
Read Version N
→ Modify
→ Update WHERE version = N
→ Increment to N+1
→ Fail if zero rows affected
```

# 39. Database Constraints

Unique constraints remain final defense against duplicates.

# 40. Pessimistic Locking

Use only for short critical sections.

# 41. Lock Rules

- bounded timeout;
- consistent lock ordering;
- minimal scope;
- no remote calls while holding lock;
- deadlock retry policy;
- audit for high-risk locks.

# 42. Distributed Lock

Use only when database uniqueness/idempotency cannot solve problem.

# 43. Distributed Lock Risks

- expiry race;
- split brain;
- lock loss;
- clock assumptions;
- stale owner.

# 44. Lock Fencing

High-risk distributed locks should use fencing token.

# 45. Race Conditions

Common:

- duplicate create;
- claim collision;
- balance update;
- state transition;
- inventory allocation;
- simultaneous approval;
- delete/update conflict.

# 46. Race-Condition Controls

Use:

- unique constraints;
- conditional update;
- version checks;
- atomic counters;
- transaction isolation;
- advisory/distributed locks where justified;
- idempotency records.

# 47. Transaction Boundaries

Database transaction should cover local state and idempotency state where possible.

# 48. External Side Effects

Do not hold database transaction open across remote calls.

# 49. Outbox Pattern

Use outbox for reliable post-commit events.

# 50. Saga Pattern

Use saga for multi-system mutation.

# 51. Request Retry Classification

```text
SAFE_RETRY
SAFE_WITH_SAME_IDEMPOTENCY_KEY
STATUS_CHECK_REQUIRED
DO_NOT_RETRY
```

# 52. Retryable Errors

Examples:

```text
connection reset
gateway timeout before processing known
temporary unavailable
rate limit
```

# 53. Ambiguous Timeout

If server may have processed request, client must retry with same key or query status.

# 54. Client Contract

Clients must:

- generate stable key;
- reuse key for same logical request;
- not reuse key for different request;
- respect conflict and in-progress response;
- use resource version;
- preserve correlation ID.

# 55. Server Contract

Server must:

- validate key;
- scope key;
- hash request;
- atomically acquire;
- store outcome;
- return stable result;
- detect conflicts;
- reconcile unknown states.

# 56. Bulk Mutations

Bulk operations require:

- batch idempotency key;
- item-level idempotency where partial processing allowed;
- per-item result;
- deterministic retry.

# 57. All-or-Nothing Bulk

Single transaction where feasible.

# 58. Partial Bulk

Each item gets stable identity and outcome.

# 59. Workflow Actions

Transition API must use:

- workflow instance version;
- transition idempotency key;
- allowed current state;
- actor authorization.

# 60. Claim/Assignment APIs

Atomic conditional update required.

# 61. Financial-Like Operations

Require:

- long-lived idempotency;
- stable operation reference;
- reconciliation;
- strict conflict handling;
- immutable attempt history.

# 62. File Operations

Upload/create should use content hash and operation idempotency where relevant.

# 63. Delete/Restore

Delete and restore must use state preconditions.

# 64. Replay Attack vs Legitimate Retry

Idempotency does not replace authentication, signature, nonce, or replay protection.

# 65. Request Timestamp

May be used for freshness, but not as sole idempotency control.

# 66. Idempotency and Authorization

Authorization must be re-evaluated on retry.

# 67. Cached Completed Result

Do not return result if current caller is no longer authorized.

# 68. Tenant Isolation

Idempotency records must be tenant-bound.

# 69. Client Isolation

Same key from different clients may be distinct according to scope policy.

# 70. Endpoint Manifest

Example:

```yaml
endpoint: billing.invoice.pay
idempotency:
  required: true
  ttl: 30d
  scope:
    - tenant
    - client
    - endpoint
concurrency:
  strategy: resource_version
  precondition_required: true
```

# 71. Manifest Validation

Checks:

- mutating endpoint policy exists;
- idempotency requirement defined;
- TTL defined;
- concurrency strategy defined;
- conflict status defined;
- tests available.

# 72. Idempotency Service Contract

```php
interface ApiIdempotencyServiceInterface
{
    public function acquire(
        ApiIdempotencyRequest $request
    ): ApiIdempotencyDecision;

    public function complete(
        ApiIdempotencyCompletion $completion
    ): void;
}
```

# 73. Concurrency Guard Contract

```php
interface ApiConcurrencyGuardInterface
{
    public function validate(
        ApiConcurrencyRequest $request
    ): ApiConcurrencyDecision;
}
```

# 74. Request Fingerprint Contract

```php
interface ApiRequestFingerprintInterface
{
    public function fingerprint(
        ApiRequestFingerprintInput $input
    ): string;
}
```

# 75. Reconciliation

Compare:

- idempotency records;
- resource state;
- operation journal;
- outbox;
- external provider state;
- response references;
- API audit logs.

# 76. Reconciliation Findings

```text
PROCESSING_RECORD_STALE
COMPLETED_WITHOUT_RESOURCE
RESOURCE_WITHOUT_COMPLETED_RECORD
REQUEST_HASH_CONFLICT
DUPLICATE_RESOURCE_CREATED
OUTBOX_EVENT_MISSING
EXTERNAL_EFFECT_UNKNOWN
EXPIRED_HIGH_RISK_RECORD
```

# 77. Auto-Remediation

Examples:

- mark completed from authoritative resource;
- reconstruct response reference;
- publish missing outbox event;
- close stale retryable record;
- quarantine conflicting record.

# 78. Manual Remediation

Required for:

- duplicate financial effect;
- ambiguous ownership;
- external unknown outcome;
- data corruption;
- conflicting resource state.

# 79. Audit Events

```text
API_IDEMPOTENCY_ACQUIRED
API_IDEMPOTENCY_REPLAYED
API_IDEMPOTENCY_CONFLICT
API_IDEMPOTENCY_COMPLETED
API_CONCURRENCY_CONFLICT
API_PRECONDITION_FAILED
API_LOCK_TIMEOUT
API_DUPLICATE_EFFECT_DETECTED
API_REQUEST_SAFETY_RECONCILIATION_FAILED
```

# 80. Metrics

```text
api_idempotency_acquired_total
api_idempotency_replay_total
api_idempotency_conflict_total
api_concurrency_conflict_total
api_precondition_failure_total
api_lock_timeout_total
api_duplicate_effect_total
api_stale_processing_record_total
api_request_safety_reconciliation_failure_total
```

# 81. KPIs

```text
Duplicate critical business effects = 0
Same idempotency key with different request accepted = 0
High-risk mutation without concurrency control = 0
Blind retry after ambiguous timeout = 0
Cross-tenant idempotency collision = 0
Completed operation without recoverable outcome = 0
```

# 82. KRIs

```text
Idempotency conflict growth
Stale processing records
Concurrency conflict frequency
Lock timeout growth
Ambiguous timeout frequency
Duplicate-resource findings
Bulk retry failures
High-risk record expiry
```

# 83. Database Direction

Potential tables:

```text
api_idempotency_records
api_idempotency_attempts
api_operation_journal
api_resource_versions
api_lock_records
api_request_safety_policies
api_request_safety_reconciliation_runs
api_request_safety_reconciliation_findings
```

# 84. Table: api_idempotency_records

```sql
CREATE TABLE api_idempotency_records (
    id CHAR(26) NOT NULL,
    tenant_id CHAR(26) NOT NULL,
    client_id VARCHAR(180) NOT NULL,
    endpoint_code VARCHAR(180) NOT NULL,
    idempotency_key VARCHAR(255) NOT NULL,
    request_hash CHAR(64) NOT NULL,
    status VARCHAR(30) NOT NULL,
    response_status INT NULL,
    resource_type VARCHAR(100) NULL,
    resource_id VARCHAR(255) NULL,
    response_reference VARCHAR(1000) NULL,
    created_at DATETIME(6) NOT NULL,
    expires_at DATETIME(6) NOT NULL,
    completed_at DATETIME(6) NULL,

    PRIMARY KEY (id),
    UNIQUE KEY uq_api_idempotency_scope (
        tenant_id,
        client_id,
        endpoint_code,
        idempotency_key
    ),
    KEY idx_api_idempotency_status (
        status,
        created_at
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

# 85. Table: api_idempotency_attempts

```sql
CREATE TABLE api_idempotency_attempts (
    id CHAR(26) NOT NULL,
    idempotency_record_id CHAR(26) NOT NULL,
    attempt_number INT NOT NULL,
    correlation_id VARCHAR(180) NOT NULL,
    result VARCHAR(30) NOT NULL,
    error_code VARCHAR(180) NULL,
    started_at DATETIME(6) NOT NULL,
    completed_at DATETIME(6) NULL,

    PRIMARY KEY (id),
    UNIQUE KEY uq_api_idempotency_attempt (
        idempotency_record_id,
        attempt_number
    ),
    CONSTRAINT fk_api_idempotency_attempt_record
        FOREIGN KEY (idempotency_record_id)
        REFERENCES api_idempotency_records (id)
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

# 86. Table: api_operation_journal

```sql
CREATE TABLE api_operation_journal (
    id CHAR(26) NOT NULL,
    operation_code VARCHAR(180) NOT NULL,
    tenant_id CHAR(26) NOT NULL,
    endpoint_code VARCHAR(180) NOT NULL,
    actor_id CHAR(26) NOT NULL,
    idempotency_record_id CHAR(26) NULL,
    resource_type VARCHAR(100) NULL,
    resource_id VARCHAR(255) NULL,
    resource_version_before BIGINT NULL,
    resource_version_after BIGINT NULL,
    status VARCHAR(30) NOT NULL,
    correlation_id VARCHAR(180) NOT NULL,
    created_at DATETIME(6) NOT NULL,

    PRIMARY KEY (id),
    UNIQUE KEY uq_api_operation_code (
        operation_code
    ),
    KEY idx_api_operation_resource (
        tenant_id,
        resource_type,
        resource_id,
        created_at
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

# 87. Table: api_request_safety_reconciliation_findings

```sql
CREATE TABLE api_request_safety_reconciliation_findings (
    id CHAR(26) NOT NULL,
    run_id CHAR(26) NOT NULL,
    finding_type VARCHAR(60) NOT NULL,
    severity VARCHAR(30) NOT NULL,
    idempotency_record_id CHAR(26) NULL,
    resource_type VARCHAR(100) NULL,
    resource_id VARCHAR(255) NULL,
    expected_state_json JSON NULL,
    actual_state_json JSON NULL,
    status VARCHAR(30) NOT NULL,
    detected_at DATETIME(6) NOT NULL,

    PRIMARY KEY (id),
    KEY idx_api_request_safety_finding (
        severity,
        status,
        detected_at
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

# 88. API Direction

```text
GET  /api/internal/v1/api-safety/idempotency-records
GET  /api/internal/v1/api-safety/idempotency-records/{id}
POST /api/internal/v1/api-safety/idempotency-records/{id}/reconcile
GET  /api/internal/v1/api-safety/policies
POST /api/internal/v1/api-safety/policies
POST /api/internal/v1/api-safety/policies/publish
POST /api/internal/v1/api-safety/reconciliation/runs
GET  /api/internal/v1/api-safety/reconciliation/findings
```

# 89. Error Codes

```text
API_IDEMPOTENCY_KEY_REQUIRED
API_IDEMPOTENCY_KEY_INVALID
API_IDEMPOTENCY_CONFLICT
API_IDEMPOTENCY_IN_PROGRESS
API_IDEMPOTENCY_EXPIRED
API_PRECONDITION_REQUIRED
API_PRECONDITION_FAILED
API_CONCURRENCY_CONFLICT
API_LOCK_TIMEOUT
API_DUPLICATE_OPERATION
API_OPERATION_OUTCOME_UNKNOWN
API_REQUEST_SAFETY_RECONCILIATION_FAILED
```

# 90. Endpoint Safety Checklist

- [ ] Mutation type identified.
- [ ] Idempotency requirement defined.
- [ ] Scope defined.
- [ ] TTL defined.
- [ ] Request fingerprint defined.
- [ ] Concurrency strategy defined.
- [ ] Precondition behavior defined.
- [ ] Conflict status defined.
- [ ] Unknown-outcome recovery defined.
- [ ] Tests available.

# 91. Request Execution Checklist

- [ ] Authorization passed.
- [ ] Idempotency key validated.
- [ ] Record acquired atomically.
- [ ] Request hash verified.
- [ ] Preconditions verified.
- [ ] Resource version verified.
- [ ] Transaction boundary defined.
- [ ] Business effect executed once.
- [ ] Outcome persisted.
- [ ] Audit generated.

# 92. UAT — Idempotency

- [ ] First request executes.
- [ ] Completed duplicate returns stable result.
- [ ] Concurrent duplicate executes once.
- [ ] Same key/different body rejected.
- [ ] Cross-tenant key isolated.
- [ ] Cross-client scope follows policy.
- [ ] Processing duplicate returns controlled response.
- [ ] Expired key follows endpoint policy.
- [ ] Sensitive body not stored.

# 93. UAT — Optimistic Concurrency

- [ ] Current version update succeeds.
- [ ] Stale version update fails.
- [ ] ETag precondition works.
- [ ] Missing required precondition returns 428.
- [ ] Concurrent writers yield one success.
- [ ] Version increments atomically.
- [ ] Delete/update conflict handled.
- [ ] Create-if-absent uses unique constraint.
- [ ] Audit complete.

# 94. UAT — Ambiguous Timeout & Retry

- [ ] Client retries with same key.
- [ ] Server returns original outcome.
- [ ] Crash after commit is reconciled.
- [ ] External unknown outcome triggers status check.
- [ ] Blind duplicate effect blocked.
- [ ] Retryable failure can continue.
- [ ] Final failure returns stable state.
- [ ] Correlation preserved.
- [ ] Metrics update.

# 95. UAT — Locks & Race Conditions

- [ ] Claim collision yields one winner.
- [ ] Lock timeout is bounded.
- [ ] Deadlock retry policy works.
- [ ] No remote call while DB lock held.
- [ ] Unique constraint blocks duplicate create.
- [ ] Conditional update blocks stale state transition.
- [ ] Distributed lock fencing rejects stale owner.
- [ ] Lock release failure detected.
- [ ] Reconciliation catches duplicates.

# 96. UAT — Bulk Mutations

- [ ] Batch key acquired.
- [ ] Item keys unique.
- [ ] Partial retry processes only failed items.
- [ ] Successful items not duplicated.
- [ ] All-or-nothing rollback works.
- [ ] Per-item results stable.
- [ ] Cross-tenant items rejected.
- [ ] Batch expiry handled.
- [ ] Audit complete.

# 97. UAT — Reconciliation

- [ ] Stale processing record detected.
- [ ] Completed record without resource detected.
- [ ] Resource without completed record detected.
- [ ] Request-hash conflict detected.
- [ ] Duplicate resource detected.
- [ ] Missing outbox event detected.
- [ ] External unknown effect detected.
- [ ] Expired high-risk record detected.
- [ ] Safe auto-remediation works.
- [ ] Critical finding opens incident.

# 98. Definition of Done — SSOT-API-07

SSOT-API-07 dianggap selesai bila:

- [ ] idempotency requirement model tersedia;
- [ ] key scope and lifecycle tersedia;
- [ ] request fingerprinting tersedia;
- [ ] atomic acquisition tersedia;
- [ ] duplicate-state handling tersedia;
- [ ] response replay tersedia;
- [ ] optimistic concurrency tersedia;
- [ ] ETag/version/preconditions tersedia;
- [ ] lost-update prevention tersedia;
- [ ] lock governance tersedia;
- [ ] race-condition patterns tersedia;
- [ ] safe retry classification tersedia;
- [ ] client/server contracts tersedia;
- [ ] bulk mutation safety tersedia;
- [ ] workflow/financial/file mutation guidance tersedia;
- [ ] authorization re-evaluation tersedia;
- [ ] manifest policies tersedia;
- [ ] reconciliation tersedia;
- [ ] audit and metrics tersedia;
- [ ] database direction tersedia;
- [ ] API direction tersedia;
- [ ] SDK contracts tersedia;
- [ ] UAT and DoD tersedia.

# 99. Implementation Roadmap

## Phase 1 — Idempotency Foundation

- idempotency registry;
- request fingerprinting;
- atomic acquisition;
- completed response replay;
- conflict semantics;
- administrative APIs.

## Phase 2 — Concurrency Controls

- resource versions;
- ETags;
- preconditions;
- conditional updates;
- lock policy;
- race-condition test kit.

## Phase 3 — High-Risk Mutation Safety

- financial-like operations;
- workflow actions;
- bulk APIs;
- file mutations;
- external side-effect recovery;
- long-lived idempotency.

## Phase 4 — Policy Assurance

- endpoint manifests;
- CI validation;
- stale-record detection;
- reconciliation;
- duplicate-effect incident handling;
- dashboards.

## Phase 5 — Distributed Request Safety

- distributed idempotency service;
- multi-region key consistency;
- global duplicate detection;
- conflict simulation;
- continuous safety assurance;
- request-safety dashboard.

# 100. Initial Implementation Backlog

```text
API07-001 Idempotency Record Store
API07-002 Request Fingerprint
API07-003 Atomic Acquisition
API07-004 Stable Result Replay
API07-005 Resource Versioning
API07-006 ETag Middleware
API07-007 Precondition Guard
API07-008 Conditional Mutation Repository
API07-009 Lock Policy
API07-010 Race Condition Test Kit
API07-011 Bulk Mutation Safety
API07-012 External Outcome Reconciliation
API07-013 Endpoint Safety Manifest
API07-014 Safety Policy Validator
API07-015 Reconciliation Engine
API07-016 Request Safety Dashboard
```

# 101. Approval Gate

Dokumen dapat menjadi Approved setelah:

- API Architecture review;
- Data/Transaction Architecture review;
- Integration Architecture review;
- Workflow Architecture review;
- Security review;
- Operations/SRE review;
- Audit/Compliance review;
- Developer Experience review;
- Quality Engineering review;
- UAT review.

# 102. Closing Statement

Retry tidak boleh menggandakan business effect.

Idempotency key harus scoped, fingerprinted, dan acquired secara atomic.

Concurrent writes harus dideteksi.

Stale updates harus gagal dengan aman.

Unknown outcome harus direkonsiliasi sebelum request dijalankan ulang.
