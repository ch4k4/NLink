
# SSOT-API-01 — REST API Standard

## Status Dokumen

| Item | Nilai |
|---|---|
| Kode | SSOT-API-01 |
| Domain | Platform Kernel / API |
| Bergantung pada | SSOT-IAM, SSOT-RBAC, SSOT-SCOPE, SSOT-AUDIT, SSOT-DATA, SSOT-WF, SSOT-NOTIFY |

# 1. Tujuan

Menetapkan standar REST API yang konsisten untuk seluruh platform agar seluruh modul memiliki pola endpoint, autentikasi, otorisasi, validasi, respons, versioning, dan audit yang seragam.

# 2. Prinsip

- Resource-oriented.
- Stateless.
- Versioned.
- Secure by default.
- Scope-aware.
- RBAC-aware.
- Audit-aware.
- Idempotent untuk operasi yang sesuai.

# 3. URI Standard

```text
/api/v1/patients
/api/v1/encounters
/api/v1/homecare/visits
/api/v1/workflows
```

Gunakan kata benda, huruf kecil, dan bentuk jamak.

# 4. HTTP Method

- GET: baca
- POST: buat
- PUT: ganti penuh
- PATCH: ubah sebagian
- DELETE: soft delete bila berlaku

# 5. Status Code

- 200 OK
- 201 Created
- 202 Accepted
- 204 No Content
- 400 Bad Request
- 401 Unauthorized
- 403 Forbidden
- 404 Not Found
- 409 Conflict
- 422 Validation Error
- 429 Too Many Requests
- 500 Internal Server Error

# 6. Response Envelope

```json
{
  "success": true,
  "data": {},
  "meta": {},
  "errors": [],
  "correlation_id": "..."
}
```

# 7. Error Format

```json
{
  "success": false,
  "errors": [
    {
      "code": "validation.required",
      "field": "patient_name",
      "message": "Field wajib diisi."
    }
  ],
  "correlation_id": "..."
}
```

# 8. Pagination

Parameter:

```text
page
per_page
sort
direction
filter
search
```

Response:

```json
{
  "meta":{
    "page":1,
    "per_page":20,
    "total":125,
    "total_pages":7
  }
}
```

# 9. Filtering & Sorting

Whitelist kolom.

Tidak boleh menerima nama kolom mentah tanpa validasi.

# 10. Authentication

Mendukung:

- OAuth2/OIDC (opsional)
- Bearer Token
- API Key (service account)
- Session (web)

# 11. Authorization

Semua endpoint:

- RBAC
- Scope
- Clinical privilege (modul klinis)

# 12. Idempotency

POST yang berisiko duplikasi mendukung:

```text
Idempotency-Key
```

Contoh:

- pembayaran
- refund
- registrasi eksternal

# 13. Concurrency

Gunakan:

```text
ETag
If-Match
version
```

atau optimistic locking.

# 14. Rate Limiting

Per:

- user
- API key
- IP
- tenant

Contoh header:

```text
X-RateLimit-Limit
X-RateLimit-Remaining
Retry-After
```

# 15. Correlation ID

Setiap request memiliki:

```text
X-Correlation-ID
```

Jika tidak dikirim client, server membuatnya.

# 16. Request Validation

Validasi:

- schema
- tipe data
- business rule
- scope
- permission

# 17. Versioning

Versi melalui URI:

```text
/api/v1
/api/v2
```

Versi lama memiliki kebijakan deprecation.

# 18. File Upload

Gunakan multipart/form-data.

Metadata dipisahkan dari file.

File mengikuti kebijakan SSOT-FILE.

# 19. Long-running Operation

Gunakan:

- 202 Accepted
- job_id
- polling endpoint

# 20. Webhook

Webhook harus mendukung:

- signature
- retry
- timestamp
- delivery log

# 21. Audit

Audit minimal:

- method
- endpoint
- actor
- scope
- correlation_id
- response_status
- duration

# 22. OpenAPI

Seluruh endpoint wajib terdokumentasi menggunakan OpenAPI 3.x.

# 23. Naming

Gunakan:

```text
patients
patient_id
encounter_id
```

Hindari singkatan tidak jelas.

# 24. Security

- HTTPS wajib.
- Tidak mengembalikan stack trace.
- Sanitasi input.
- Masking data sensitif.
- CORS sesuai kebijakan.

# 25. Healthcare Rule

API yang mengakses PHI:

- audit read access;
- masking bila perlu;
- permission khusus;
- scope klinis.

# 26. UAT

- Response envelope konsisten.
- Pagination benar.
- Rate limit bekerja.
- Correlation ID tersedia.
- Audit tercatat.
- OpenAPI sesuai implementasi.

# 27. Anti-pattern

Hindari:

- endpoint tanpa versi
- error HTML
- response tidak konsisten
- permission diabaikan
- query parameter langsung ke SQL
- endpoint berbeda pola antar modul

# 28. Definition of Done

- Seluruh endpoint mengikuti standar URI.
- Response envelope konsisten.
- Versioning diterapkan.
- Authentication & authorization aktif.
- Audit dan correlation ID tersedia.
- Dokumentasi OpenAPI tersedia.
