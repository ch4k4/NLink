
# SSOT-API-05 — API Versioning & Deprecation Policy

## Status Dokumen

| Item | Nilai |
|---|---|
| Kode | SSOT-API-05 |
| Domain | Platform Kernel / API |
| Bergantung pada | SSOT-API-01 s.d. SSOT-API-04, SSOT-AUDIT |

# 1. Tujuan

Menetapkan standar versioning API agar perubahan dapat dilakukan tanpa merusak integrasi yang sudah berjalan.

# 2. Prinsip

- Backward compatible bila memungkinkan.
- Breaking change hanya pada major version baru.
- Setiap perubahan terdokumentasi.
- Deprecation diumumkan sebelum sunset.
- Seluruh lifecycle diaudit.

# 3. Strategi Versioning

Versi menggunakan URI:

```text
/api/v1
/api/v2
```

Satu endpoint hanya berada pada satu versi aktif.

# 4. Jenis Perubahan

## Non-breaking

- tambah field opsional
- tambah endpoint baru
- tambah filter opsional
- optimasi performa

## Breaking

- menghapus field
- mengubah tipe data
- mengubah perilaku endpoint
- menghapus endpoint
- mengubah autentikasi secara tidak kompatibel

# 5. Lifecycle API

```text
Draft
→ Beta
→ General Availability (GA)
→ Deprecated
→ Sunset
→ Retired
```

# 6. Status

- Draft: internal.
- Beta: untuk early adopter.
- GA: produksi.
- Deprecated: masih didukung, tetapi akan dihentikan.
- Sunset: tanggal penghentian diumumkan.
- Retired: tidak dapat digunakan lagi.

# 7. Header

Saat deprecated:

```text
Deprecation: true
Sunset: Tue, 31 Dec 2030 23:59:59 GMT
Link: <https://developer.example.com/migration>; rel="deprecation"
```

# 8. Database

## api_versions

```sql
CREATE TABLE api_versions (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 version_code VARCHAR(20) NOT NULL UNIQUE,
 lifecycle_status ENUM(
   'draft','beta','ga','deprecated','sunset','retired'
 ) NOT NULL,
 release_date DATE NULL,
 sunset_date DATE NULL,
 retired_date DATE NULL,
 created_at TIMESTAMP NULL,
 updated_at TIMESTAMP NULL
);
```

## api_deprecation_notices

```sql
CREATE TABLE api_deprecation_notices (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 api_version_id BIGINT UNSIGNED NOT NULL,
 endpoint_pattern VARCHAR(255) NOT NULL,
 notice_text TEXT NOT NULL,
 migration_reference VARCHAR(255) NULL,
 created_at TIMESTAMP NULL
);
```

# 9. Compatibility Policy

Patch/minor update tidak boleh merusak client yang mengikuti kontrak API.

Breaking change wajib dipindahkan ke major version baru.

# 10. Migration Guide

Setiap major version baru wajib memiliki:

- daftar perubahan
- contoh request/response
- timeline migrasi
- tanggal sunset
- FAQ

# 11. SDK Policy

SDK resmi harus mendukung minimal:

- versi GA terbaru
- satu versi sebelumnya selama masa transisi

# 12. Monitoring

Pantau:

- penggunaan per versi
- endpoint deprecated yang masih dipakai
- error setelah migrasi

# 13. Audit

Event:

```text
api.version.created
api.version.released
api.version.deprecated
api.version.sunset
api.version.retired
```

# 14. UAT

- Client v1 tetap berjalan setelah rilis v2.
- Header deprecation muncul.
- Sunset date sesuai konfigurasi.
- Endpoint retired ditolak.
- Audit tercatat.

# 15. Anti-pattern

- mengganti kontrak API tanpa versi baru
- menghapus endpoint tanpa pemberitahuan
- tidak menyediakan migration guide
- beberapa versi dengan perilaku tidak terdokumentasi

# 16. Definition of Done

- Strategi versioning terdokumentasi.
- Lifecycle API tersedia.
- Header deprecation & sunset didukung.
- Migration guide diwajibkan.
- Monitoring penggunaan versi tersedia.
- Audit lifecycle API lengkap.
