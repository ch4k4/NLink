# SSOT-GOV-03 — Coding Standards

---

## Status Dokumen

| Item | Nilai |
|---|---|
| Kode | SSOT-GOV-03 |
| Judul | Coding Standards |
| Versi | 1.0 |
| Status | Draft for Review |
| Domain | Platform Kernel |
| Kategori | Engineering Governance |
| Cakupan | PHP, SQL, HTML, JavaScript, APIs, Testing, Logging, Security, Review, Automation |
| Bergantung pada | SSOT-GOV-01, SSOT-GOV-02, SSOT-SEC-01, SSOT-SEC-02 |
| Target Stack | PHP 8.1+, PDO, MySQL 8/MariaDB, Apache/XAMPP, HTML5, JavaScript |

---

# 1. Executive Summary

SSOT-GOV-03 menetapkan coding standards resmi untuk Platform Kernel dan seluruh module bisnis.

Standar ini mengatur:

- struktur kode;
- naming;
- typing;
- object design;
- error handling;
- logging;
- SQL;
- HTML;
- JavaScript;
- APIs;
- testing;
- security;
- code review;
- documentation;
- automation;
- quality gates;
- technical debt;
- metrics;
- UAT;
- Definition of Done.

Tujuan akhirnya adalah memastikan seluruh codebase:

- konsisten;
- aman;
- mudah dibaca;
- mudah diuji;
- mudah direview;
- memiliki boundaries yang jelas;
- tidak bergantung pada convention informal;
- mendukung maintainability dan scale.

---

# 2. Coding Standard Objectives

Coding standards harus:

- mengurangi ambiguity;
- mempercepat onboarding;
- meningkatkan readability;
- mencegah defect berulang;
- menjaga module boundaries;
- meningkatkan security;
- meningkatkan testability;
- memudahkan automation;
- mendukung review yang objektif;
- mengurangi technical debt.

---

# 3. Core Principles

```text
Readability First
Explicit over Implicit
Simple over Clever
Secure by Default
Testable by Design
Small and Focused Units
Stable Contracts
Clear Boundaries
Consistent Error Handling
No Hidden Side Effects
```

---

# 4. Normative Language

```text
MUST / WAJIB
MUST NOT / TIDAK BOLEH
SHOULD / DIREKOMENDASIKAN
MAY / DAPAT
```

---

# 5. Scope

Standar berlaku untuk:

```text
Platform Kernel
Module SDK
Business Modules
CLI Tools
HTTP Controllers
Background Jobs
Database Migrations
Tests
Configuration
Build Scripts
Integration Adapters
```

---

# 6. Repository Structure

Recommended:

```text
app/
├── Platform/
├── Modules/
├── Shared/
└── Bootstrap/

config/
database/
public/
resources/
storage/
tests/
tools/
bin/
```

---

# 7. Module Structure

Recommended:

```text
Module/
├── Domain/
├── Application/
├── Infrastructure/
└── Presentation/
```

---

# 8. Layer Responsibilities

## Domain

Contains:

- entities;
- value objects;
- domain services;
- domain events;
- domain rules.

Must not depend on infrastructure.

## Application

Contains:

- use cases;
- commands;
- queries;
- DTOs;
- service orchestration;
- ports/contracts.

## Infrastructure

Contains:

- repositories;
- database adapters;
- external integrations;
- filesystem;
- queue;
- email;
- implementations.

## Presentation

Contains:

- HTTP controllers;
- CLI commands;
- request/response mapping;
- view models.

---

# 9. Dependency Direction

```text
Presentation
→ Application
→ Domain

Infrastructure
→ Application Contracts
→ Domain
```

Domain must not depend on Presentation or Infrastructure.

---

# 10. Module Boundary

Business modules must not:

- directly access private classes of another module;
- directly query another module’s private tables;
- bypass Module SDK;
- depend on kernel internals.

---

# 11. Platform Kernel Boundary

Business modules may depend on:

```text
Platform Contracts
Module SDK
Shared Value Objects
Approved Shared Services
```

They must not depend directly on implementation classes inside Platform Kernel.

---

# 12. PHP Baseline

Every PHP file must start with:

```php
<?php

declare(strict_types=1);
```

---

# 13. PHP Version

Minimum:

```text
PHP 8.1+
```

Newer supported versions may be adopted through ADR.

---

# 14. PSR Alignment

Code should align with:

- PSR-1;
- PSR-4;
- PSR-12;
- PSR-3 for logging where used.

---

# 15. Namespace Standard

Example:

```php
namespace App\Modules\Patient\Domain;
```

---

# 16. Class Naming

Use PascalCase:

```text
PatientRepository
CreatePatientHandler
TenantScope
SecurityContext
```

---

# 17. Interface Naming

Use descriptive interface names.

Preferred:

```text
PatientRepositoryInterface
ClockInterface
AuthorizationServiceInterface
```

Avoid meaningless prefixes.

---

# 18. Method Naming

Use camelCase and action-oriented names:

```text
findById
createPatient
assertAllowed
rotateCredential
```

---

# 19. Variable Naming

Use descriptive camelCase:

```php
$patientId
$tenantScope
$securityContext
```

Avoid:

```php
$x
$tmp
$data2
$obj
```

except in very small local contexts.

---

# 20. Constant Naming

Use uppercase snake case:

```php
private const MAX_RETRY_COUNT = 3;
```

---

# 21. Enum Naming

Enum names use PascalCase.

Cases use uppercase snake case:

```php
enum ReleaseStatus: string
{
    case DRAFT = 'DRAFT';
    case APPROVED = 'APPROVED';
}
```

---

# 22. File Naming

One primary class per file.

Filename must match class name.

---

# 23. Type Declarations

Use:

- parameter types;
- return types;
- property types;
- nullable types explicitly;
- union/intersection types only when justified.

---

# 24. Avoid Mixed

Avoid `mixed` unless integration boundary requires it.

Convert untrusted input to typed DTOs as early as possible.

---

# 25. Readonly

Use `readonly` for immutable DTOs and value objects where appropriate.

---

# 26. Value Objects

Use value objects for:

- IDs;
- money;
- email;
- tenant scope;
- date ranges;
- security context;
- status where behavior matters.

---

# 27. Entity Design

Entities should:

- preserve invariants;
- expose behavior;
- avoid public mutable state;
- not be passive property bags.

---

# 28. Constructor Rules

Constructor should:

- establish valid initial state;
- avoid heavy I/O;
- avoid hidden side effects;
- avoid service locator lookups.

---

# 29. Dependency Injection

Use constructor injection.

Avoid:

- global state;
- service locator;
- static mutable dependencies;
- hidden container access.

---

# 30. Method Size

Methods should remain focused.

Recommended:

- one purpose;
- minimal nesting;
- extract complex branches;
- avoid long orchestration in controllers.

---

# 31. Class Responsibility

A class should have one clear reason to change.

---

# 32. Boolean Parameters

Avoid ambiguous boolean parameters.

Bad:

```php
$service->process($data, true, false);
```

Good:

```php
$service->process(
    $data,
    ProcessingOptions::strict()
);
```

---

# 33. Null Handling

Use nullable values only where absence is valid.

Avoid null as error signaling.

---

# 34. Return Values

Do not return unrelated types.

Prefer:

- specific object;
- collection;
- result object;
- exception for exceptional failure.

---

# 35. Collections

Collections should document contained type.

---

# 36. Arrays

Associative arrays may be used at boundaries, but internal business logic should prefer typed objects.

---

# 37. Magic Methods

Use sparingly.

Avoid behavior that hides important control flow.

---

# 38. Static Methods

Use only for:

- pure factories;
- immutable value object constructors;
- stateless utility where justified.

Avoid static state.

---

# 39. Traits

Traits should be limited to small, cohesive behavior.

Do not use traits to hide architecture problems.

---

# 40. Inheritance

Prefer composition over inheritance.

Use inheritance only for true substitutability.

---

# 41. Final Classes

Use `final` by default for concrete classes unless extension is intentional.

---

# 42. Exceptions

Use domain-specific exceptions.

Examples:

```text
ValidationException
AuthorizationException
ResourceNotFoundException
ConflictException
InfrastructureException
```

---

# 43. Exception Rules

Do not:

- throw generic `Exception` without reason;
- catch and ignore;
- expose raw exception to user;
- use exceptions for normal branching.

---

# 44. Catching Exceptions

Catch only when:

- adding meaningful context;
- translating boundary errors;
- recovering;
- logging once at appropriate boundary.

---

# 45. Error Codes

Public/API errors should use stable error codes.

---

# 46. Controllers

Controllers should:

- validate transport-level input;
- create command/query DTOs;
- call application service;
- map result to response.

Controllers must not contain core business logic.

---

# 47. Application Services

Application services should:

- orchestrate use cases;
- manage transactions;
- call domain;
- call ports;
- emit events;
- return typed results.

---

# 48. Domain Services

Use when business logic does not naturally belong to one entity/value object.

---

# 49. Repositories

Repository interfaces belong in Application or Domain depending architecture.

Implementations belong in Infrastructure.

---

# 50. Repository Naming

Examples:

```text
findById
findActiveByEmail
save
delete
existsByCode
```

Avoid vague methods such as:

```text
getData
process
handle
doQuery
```

---

# 51. Repository Scope

Tenant-aware repository methods must require trusted scope.

Example:

```php
public function findById(
    string $patientId,
    TenantScope $scope
): ?Patient;
```

---

# 52. Transaction Boundaries

Transactions belong at application service/use-case boundary.

---

# 53. Domain Events

Domain events should:

- represent facts;
- use past tense;
- be immutable;
- include stable identifiers;
- avoid sensitive payload unless required.

Examples:

```text
PatientCreated
RoleAssignmentGranted
CredentialRotated
```

---

# 54. Event Naming

Use past tense.

Bad:

```text
CreatePatient
```

Good:

```text
PatientCreated
```

---

# 55. Configuration

Configuration must:

- be typed or schema-validated;
- have safe defaults;
- fail fast on invalid critical config;
- never include committed production secrets.

---

# 56. Environment Variables

Access environment variables through configuration layer.

Do not scatter direct `getenv()` calls across business code.

---

# 57. Comments

Comments should explain why, not restate what.

Bad:

```php
// Increment counter
$counter++;
```

Good:

```php
// Retry is bounded to avoid duplicate external side effects.
```

---

# 58. Docblocks

Use docblocks for:

- public contracts;
- complex generics/array shapes;
- non-obvious behavior;
- thrown exceptions;
- security implications.

Do not duplicate obvious type information.

---

# 59. TODO Comments

Format:

```text
TODO(owner, YYYY-MM-DD): description
```

Every TODO should have:

- owner;
- reason;
- target date or ticket reference.

---

# 60. Dead Code

Dead code must be removed.

Do not comment out large code blocks.

Use version control history.

---

# 61. Feature Flags

Feature flags must have:

- owner;
- purpose;
- default;
- expiry/review;
- removal plan.

---

# 62. SQL Baseline

Use prepared statements for all untrusted values.

---

# 63. PDO Standard

```php
$pdo = new PDO(
    $dsn,
    $username,
    $password,
    [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
    ]
);
```

---

# 64. SQL Naming

Use snake_case for:

```text
tables
columns
indexes
constraints
```

---

# 65. Table Naming

Use plural or singular consistently across the platform.

Recommended:

```text
plural snake_case
```

Examples:

```text
patients
role_assignments
security_events
```

---

# 66. Primary Keys

Recommended:

```text
id CHAR(26) for ULID
```

or a formally approved alternative.

---

# 67. Foreign Keys

Foreign key column:

```text
{entity}_id
```

Example:

```text
tenant_id
patient_id
role_id
```

---

# 68. Tenant-Aware Tables

Must contain:

```text
tenant_id
```

and scope columns where applicable.

---

# 69. Audit Columns

Recommended:

```text
created_at
updated_at
created_by
updated_by
```

where meaningful.

---

# 70. Soft Delete

Use only when business/audit requirements justify it.

Common column:

```text
deleted_at
```

Do not treat soft delete as retention policy.

---

# 71. Index Naming

Format:

```text
idx_{table}_{columns}
uq_{table}_{columns}
fk_{table}_{referenced}
```

---

# 72. SQL Formatting

Recommended:

```sql
SELECT
    id,
    tenant_id,
    name
FROM patients
WHERE tenant_id = :tenant_id
  AND id = :id;
```

---

# 73. SELECT Star

Avoid:

```sql
SELECT *
```

Use explicit columns.

---

# 74. Dynamic SQL

Identifiers must use server-side allowlists.

---

# 75. Pagination

Every list query should support bounded pagination where result size may grow.

---

# 76. Database Transactions

Use transactions for multi-step state changes.

---

# 77. Migration Naming

Format:

```text
YYYYMMDDHHMMSS_description.sql
```

or project migration convention.

---

# 78. Migration Rules

Migrations must be:

- versioned;
- reviewed;
- repeatable once;
- safe for target DB;
- rollback-aware;
- tested on realistic data volume.

---

# 79. Destructive Migration

Requires explicit review, backup, and rollback/restore plan.

---

# 80. Expand-Migrate-Contract

Recommended for breaking schema changes.

---

# 81. HTML Standard

Use semantic HTML.

Examples:

```text
header
nav
main
section
article
aside
footer
```

---

# 82. Accessibility

UI must support:

- labels;
- keyboard navigation;
- sufficient semantics;
- focus states;
- accessible error messages;
- appropriate ARIA only when necessary.

---

# 83. Forms

Every form field should have:

- label;
- name;
- validation;
- error message;
- autocomplete behavior where applicable.

---

# 84. Output Encoding

All dynamic HTML output must be context-encoded.

---

# 85. Inline Styles

Avoid inline styles in production templates unless explicitly justified.

---

# 86. Inline Scripts

Avoid inline scripts.

Prefer external modules and CSP-compatible patterns.

---

# 87. CSS Naming

Recommended:

```text
component-based naming
utility naming
design-token usage
```

Avoid deeply coupled selectors.

---

# 88. CSS Specificity

Keep specificity low.

Avoid:

- excessive IDs;
- deeply nested selectors;
- `!important` except controlled utility cases.

---

# 89. JavaScript Baseline

Use:

- modules;
- `const` by default;
- `let` when reassignment required;
- strict equality;
- explicit error handling;
- no global mutable state.

---

# 90. JavaScript Naming

Use camelCase for variables/functions and PascalCase for classes/components.

---

# 91. JavaScript Functions

Functions should be small and focused.

---

# 92. Async Code

Use `async/await` consistently.

Handle rejected promises.

---

# 93. DOM Safety

Prefer:

```javascript
element.textContent = value;
```

Avoid unsafe HTML sinks for untrusted data.

---

# 94. Browser Storage

Do not store sensitive data in localStorage/sessionStorage without approved design.

---

# 95. API Design

APIs must use:

- versioning;
- consistent envelope;
- stable error codes;
- authentication;
- authorization;
- schema validation;
- pagination;
- idempotency where required.

---

# 96. API Naming

Use nouns for resources.

Examples:

```text
/patients
/role-assignments
/security-events
```

---

# 97. HTTP Methods

```text
GET    read
POST   create/action
PUT    replace
PATCH  partial update
DELETE remove
```

---

# 98. HTTP Status Codes

Use appropriate standard codes.

Examples:

```text
200 OK
201 Created
204 No Content
400 Bad Request
401 Unauthorized
403 Forbidden
404 Not Found
409 Conflict
422 Unprocessable Entity
429 Too Many Requests
500 Internal Server Error
```

---

# 99. API Error Envelope

```json
{
  "error": {
    "code": "PATIENT_NOT_FOUND",
    "message": "Patient not found."
  },
  "meta": {
    "request_id": "01J..."
  }
}
```

---

# 100. API Success Envelope

Recommended:

```json
{
  "data": {},
  "meta": {}
}
```

---

# 101. API Pagination

Recommended:

```json
{
  "data": [],
  "meta": {
    "page": 1,
    "page_size": 20,
    "total": 100
  }
}
```

---

# 102. Input Validation

Validate at boundary.

Do not pass raw request arrays deep into application logic.

---

# 103. Mass Assignment

Do not mass-assign request data directly to entities.

---

# 104. Authentication Code

Must use approved authentication service.

Do not create ad hoc login logic inside modules.

---

# 105. Authorization Code

Every sensitive action must use server-side authorization.

Do not rely on hidden menu/button.

---

# 106. Tenant Isolation

Every tenant-aware operation must use trusted tenant/scope context.

---

# 107. Secrets

Do not hard-code secrets.

Do not log secrets.

Do not commit `.env` with real credentials.

---

# 108. Cryptography

Use approved libraries and services.

Do not implement custom cryptographic primitives.

---

# 109. Logging

Use structured logs.

Recommended fields:

```text
timestamp
level
event_code
message
request_id
correlation_id
actor_id
tenant_id
result
```

---

# 110. Logging Levels

```text
DEBUG
INFO
NOTICE
WARNING
ERROR
CRITICAL
ALERT
EMERGENCY
```

---

# 111. Logging Rules

Do not log:

- passwords;
- tokens;
- API keys;
- encryption keys;
- session cookies;
- unrestricted sensitive payloads.

---

# 112. Audit vs Log

Audit records business/security-relevant actions.

Logs support diagnostics.

Do not substitute one for the other.

---

# 113. Testing Standards

Testing layers:

```text
Unit
Integration
Contract
Security
Tenant Isolation
UAT
```

---

# 114. Unit Tests

Unit tests should:

- be fast;
- be deterministic;
- avoid external I/O;
- test business rules;
- use clear names.

---

# 115. Test Naming

Recommended:

```text
test_it_denies_cross_tenant_patient_access
test_it_rotates_session_after_login
```

---

# 116. Arrange-Act-Assert

Preferred structure:

```text
Arrange
Act
Assert
```

---

# 117. Integration Tests

Integration tests should cover:

- database;
- repository;
- transaction;
- external adapter boundaries;
- middleware;
- authentication;
- authorization.

---

# 118. Security Tests

Must cover where applicable:

- injection;
- authorization;
- tenant isolation;
- session;
- CSRF;
- file upload;
- secret leakage;
- unsafe errors.

---

# 119. Regression Tests

Every verified critical/high bug should receive regression coverage where feasible.

---

# 120. Test Data

Use synthetic or masked data.

Do not use production secrets or unrestricted production data.

---

# 121. Test Isolation

Tests should not depend on execution order.

---

# 122. Test Assertions

Assert behavior, not implementation details.

---

# 123. Mocking

Mock external boundaries, not every internal object.

Over-mocking should be avoided.

---

# 124. Coverage

Coverage is a signal, not a goal by itself.

Critical business/security paths should have explicit tests.

---

# 125. Code Review Standard

Every production change requires review.

---

# 126. Review Focus

Reviewers should assess:

- correctness;
- readability;
- security;
- architecture alignment;
- tests;
- performance;
- operational impact;
- migration risk.

---

# 127. Pull Request Size

Prefer small, focused pull requests.

Large changes should be split when practical.

---

# 128. Pull Request Description

Must include:

```text
Summary
Reason
Risk
Testing
Security Impact
Migration Impact
Rollback
References
```

---

# 129. Review Comments

Classify:

```text
BLOCKER
REQUIRED
SUGGESTION
QUESTION
NOTE
```

---

# 130. Self-Approval

Critical changes must not rely on sole self-approval.

---

# 131. Code Owners

Sensitive paths should require designated reviewers.

---

# 132. Definition of Ready for Review

Before requesting review:

- [ ] code builds;
- [ ] tests pass;
- [ ] static analysis passes;
- [ ] no secret included;
- [ ] migration tested;
- [ ] documentation updated;
- [ ] PR description complete.

---

# 133. Definition of Done for Code Change

- [ ] acceptance criteria met;
- [ ] code standard followed;
- [ ] tests added;
- [ ] security impact reviewed;
- [ ] logs/audit added where required;
- [ ] migration safe;
- [ ] documentation updated;
- [ ] review approved;
- [ ] no unresolved blocker.

---

# 134. Static Analysis

Static analysis should run in CI.

---

# 135. Linting

Required:

- PHP syntax;
- code style;
- JavaScript lint;
- SQL/migration validation where available;
- Markdown checks for governance docs.

---

# 136. Formatter

Use automated formatter where feasible.

Formatting disputes should be resolved by tool configuration.

---

# 137. Composer Standards

`composer.json` must:

- define PHP version;
- use PSR-4 autoloading;
- pin dependencies via lockfile;
- avoid unnecessary packages;
- define scripts consistently.

---

# 138. Dependency Governance

Before adding dependency:

- assess necessity;
- maintenance;
- security;
- license;
- transitive dependencies;
- replacement path.

---

# 139. Deprecated APIs

Do not introduce new usage of deprecated APIs.

Existing usage should be tracked for remediation.

---

# 140. Performance Standards

Avoid premature optimization.

Optimize based on evidence.

---

# 141. Query Performance

Review:

- N+1 queries;
- missing indexes;
- unbounded lists;
- repeated queries;
- large payloads.

---

# 142. Caching

Caching must define:

- key;
- TTL;
- invalidation;
- tenant scope;
- consistency expectation.

---

# 143. Background Jobs

Jobs must be:

- idempotent;
- retry-bounded;
- tenant-aware;
- observable;
- safe against duplicate execution.

---

# 144. Retry Logic

Retry only transient failures.

Use:

- maximum attempts;
- backoff;
- idempotency;
- logging.

---

# 145. Time Handling

Use UTC internally unless domain requires local time.

Convert at boundaries.

---

# 146. Clock Abstraction

Business logic depending on time should use `ClockInterface`.

---

# 147. IDs

Use immutable identifiers.

Do not reuse deleted identifiers.

---

# 148. Money

Do not use floating point for money.

Use integer minor units or decimal value objects.

---

# 149. Localization

User-facing messages should support localization strategy.

Do not embed transport-specific text deep in domain logic.

---

# 150. Security Headers

Presentation layer should use centralized security headers middleware.

---

# 151. File Handling

File operations must:

- validate type;
- validate size;
- use generated names;
- store outside public root;
- authorize download;
- bind to tenant.

---

# 152. CLI Commands

CLI commands should:

- validate arguments;
- return meaningful exit codes;
- use structured logs;
- avoid exposing secrets;
- support dry-run for high-risk operations.

---

# 153. Exit Codes

Recommended:

```text
0 success
1 general failure
2 validation/configuration failure
3 authorization/security failure
4 partial completion
```

---

# 154. Database Seeders

Seeders must be:

- deterministic;
- repeatable where designed;
- safe for target environment;
- environment-aware;
- free of real secrets.

---

# 155. Technical Debt

Intentional compromise must create debt record.

---

# 156. Technical Debt Comment

Do not use vague comments.

Link to ticket/ADR/risk.

---

# 157. Code Quality Metrics

```text
static_analysis_failure_total
lint_failure_total
test_failure_total
critical_path_coverage_ratio
review_rework_total
code_review_lead_time
deprecated_api_usage_total
technical_debt_overdue_total
security_regression_total
```

---

# 158. Initial KPIs

```text
Critical static analysis findings = 0
Secrets committed = 0
Production changes without review = 0
Critical path tests passing = 100%
High-risk changes with security review = 100%
Expired critical TODO/debt items = 0
```

---

# 159. Quality Gate

Pull request must fail when:

- syntax invalid;
- lint fails;
- tests fail;
- critical static analysis finding exists;
- secret detected;
- tenant isolation test fails;
- required reviewer missing;
- migration invalid.

---

# 160. Coding Standard Exceptions

Exception requires:

```text
standard
scope
reason
risk
compensating_control
owner
approver
expires_at
```

---

# 161. Exception Rules

Exception must not be permanent.

Repeated exception should trigger standard or architecture review.

---

# 162. Legacy Code Adoption

Use staged approach:

```text
Inventory
→ Baseline
→ Prevent New Violations
→ Fix Critical Areas
→ Refactor Gradually
→ Enforce
```

---

# 163. Legacy Baseline

Baseline may temporarily allow existing violations but must not allow new violations.

---

# 164. Refactoring Standard

Refactoring must:

- preserve behavior;
- include tests;
- reduce complexity;
- not mix unrelated changes unnecessarily.

---

# 165. Safe Refactoring Order

```text
Add Characterization Tests
→ Isolate Boundary
→ Refactor
→ Verify
→ Remove Dead Code
```

---

# 166. Documentation Standard

Public contracts and complex decisions must be documented.

---

# 167. README Standard

Each module should document:

```text
Purpose
Owner
Dependencies
Public Contracts
Permissions
Configuration
Database Tables
Events
Tests
Operational Notes
```

---

# 168. Changelog

Breaking or notable changes should be recorded.

---

# 169. Deprecation

Deprecation must include:

- replacement;
- migration path;
- timeline;
- owner;
- removal release.

---

# 170. Coding Standard Governance

Owner:

```text
Engineering Governance
```

Reviewers:

```text
Platform Architecture
Application Security
QA
Backend Engineering
Frontend Engineering
Database Engineering
DevOps
```

---

# 171. Review Cadence

Coding standards should be reviewed:

- every 6 months;
- after major PHP/platform upgrade;
- after major security incident;
- after recurring review issues;
- after architecture change.

---

# 172. Enforcement Maturity

```text
DOCUMENTED
LINTED
TESTED
GATED
ENFORCED
MEASURED
```

---

# 173. Adoption Stages

```text
OFF
→ INFORM
→ WARN
→ BLOCK_NEW
→ ENFORCE
```

---

# 174. UAT — Coding Standards

## Structure & Architecture

- [ ] Repository structure defined.
- [ ] Module layers defined.
- [ ] Dependency direction enforced.
- [ ] Module boundary rules defined.
- [ ] Kernel/SDK boundary defined.
- [ ] Architecture violations detectable.

## PHP

- [ ] Strict types required.
- [ ] PSR alignment defined.
- [ ] Naming rules defined.
- [ ] Type declarations required.
- [ ] Constructor injection used.
- [ ] Value object guidance exists.
- [ ] Exception rules defined.
- [ ] Controllers remain thin.

## SQL

- [ ] Prepared statements required.
- [ ] Naming convention defined.
- [ ] Tenant-aware table rules defined.
- [ ] Index naming defined.
- [ ] SELECT star discouraged.
- [ ] Migration rules defined.
- [ ] Destructive migration review required.

## Frontend

- [ ] Semantic HTML required.
- [ ] Accessibility baseline defined.
- [ ] Output encoding required.
- [ ] Inline style/script policy defined.
- [ ] JavaScript naming and module rules defined.
- [ ] Unsafe DOM operations restricted.

## APIs

- [ ] Resource naming defined.
- [ ] HTTP method usage defined.
- [ ] Status codes defined.
- [ ] Error envelope defined.
- [ ] Pagination defined.
- [ ] Validation required.
- [ ] Authorization and tenant scope required.

## Security & Logging

- [ ] Secret rules defined.
- [ ] Crypto rules defined.
- [ ] Structured logging defined.
- [ ] Sensitive fields excluded.
- [ ] Audit separated from logs.
- [ ] File handling controls defined.

## Testing

- [ ] Unit/integration/security layers defined.
- [ ] Test naming defined.
- [ ] Test isolation required.
- [ ] Regression tests required.
- [ ] Production data prohibited.
- [ ] Critical path coverage expectations defined.

## Review & Automation

- [ ] Review required.
- [ ] PR description standard defined.
- [ ] Review comment categories defined.
- [ ] Self-approval restrictions defined.
- [ ] Static analysis required.
- [ ] Linting required.
- [ ] Formatting automated.
- [ ] Quality gate blocks critical failures.

## Governance

- [ ] Exception process defined.
- [ ] Legacy adoption path defined.
- [ ] Technical debt tracked.
- [ ] Metrics defined.
- [ ] Review cadence defined.
- [ ] Enforcement maturity defined.

---

# 175. Definition of Done — SSOT-GOV-03

SSOT-GOV-03 dianggap selesai bila:

- [ ] objectives tersedia;
- [ ] principles tersedia;
- [ ] scope tersedia;
- [ ] repository structure tersedia;
- [ ] layer responsibilities tersedia;
- [ ] dependency direction tersedia;
- [ ] module/kernel boundaries tersedia;
- [ ] PHP baseline tersedia;
- [ ] naming standards tersedia;
- [ ] typing rules tersedia;
- [ ] object design rules tersedia;
- [ ] exception/error rules tersedia;
- [ ] controller/application/domain rules tersedia;
- [ ] repository/transaction rules tersedia;
- [ ] event/config/comment rules tersedia;
- [ ] SQL standards tersedia;
- [ ] migration standards tersedia;
- [ ] HTML/accessibility standards tersedia;
- [ ] CSS/JavaScript standards tersedia;
- [ ] API standards tersedia;
- [ ] security standards tersedia;
- [ ] logging/audit standards tersedia;
- [ ] testing standards tersedia;
- [ ] code review standards tersedia;
- [ ] static analysis/linting standards tersedia;
- [ ] dependency/performance standards tersedia;
- [ ] jobs/time/money/file/CLI standards tersedia;
- [ ] technical debt/refactoring standards tersedia;
- [ ] documentation/deprecation standards tersedia;
- [ ] metrics/KPI tersedia;
- [ ] quality gate tersedia;
- [ ] exception process tersedia;
- [ ] legacy adoption tersedia;
- [ ] UAT tersedia.

---

# 176. Implementation Roadmap

## Phase 1 — Baseline

- approve naming and structure;
- enable strict types;
- enable formatter;
- enable lint;
- define PR template;
- define module README template.

## Phase 2 — Quality Gates

- static analysis;
- unit/integration tests;
- secret scan;
- migration validation;
- branch protection;
- code owner rules.

## Phase 3 — Security & Architecture Enforcement

- tenant isolation tests;
- architecture dependency tests;
- security review triggers;
- deprecated API detection;
- sensitive path review.

## Phase 4 — Legacy Remediation

- baseline existing violations;
- fix critical modules;
- reduce debt;
- remove dead code;
- standardize repositories/controllers.

## Phase 5 — Optimization

- automated metrics;
- trend dashboards;
- mutation testing;
- advanced static analysis;
- continuous quality improvement.

---

# 177. Initial Automation Backlog

Recommended:

```text
PHP syntax check
PSR-12 formatter/check
Static analysis
Composer audit
Secret scanning
PHPUnit
Tenant isolation tests
Migration validation
ADR/document lint
Architecture boundary tests
Deprecated API scanner
```

---

# 178. Approval Gate

Dokumen dapat menjadi Approved setelah:

- Engineering Governance review;
- Platform Architecture review;
- Application Security review;
- Backend Engineering review;
- Frontend Engineering review;
- Database Engineering review;
- QA review;
- DevOps review;
- lint/static analysis tool selection;
- quality gate approval;
- legacy adoption plan approval.

---

# 179. Closing Statement

Coding standards harus memastikan codebase:

- mudah dipahami;
- aman;
- konsisten;
- teruji;
- dapat diaudit;
- dapat dikembangkan;
- memiliki boundaries;
- tidak menyembunyikan risiko;
- tidak bergantung pada gaya personal.

Standar ini tidak boleh menjadi aturan kosmetik semata.

Standar harus membantu tim menghasilkan software yang benar, aman, maintainable, dan siap berkembang.
