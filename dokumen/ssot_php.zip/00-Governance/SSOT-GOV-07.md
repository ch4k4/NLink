# SSOT-GOV-07 — SSOT Repository Integrity, Document Identity & Dependency Validation Governance

## Status Dokumen

| Item | Nilai |
|---|---|
| Kode | SSOT-GOV-07 |
| Judul | SSOT Repository Integrity, Document Identity & Dependency Validation Governance |
| Versi | 1.0 |
| Status | Draft Architecture |
| Domain | Platform Kernel Governance |
| Kategori | SSOT Repository Integrity, Taxonomy, Identity, Dependency & Package Assurance |
| Cakupan | Document Identity, Folder Taxonomy, Deduplication, Index Integrity, Dependency Validation, Link Validation, Checksums, Release Packaging, Reconciliation |
| Bergantung pada | SSOT-GOV-01..06, SSOT-AUDIT-01, SSOT-TEST-01 |
| Digunakan oleh | Seluruh SSOT Platform Kernel, Architecture Reviews, Release Management, CI/CD, Audit |
| Target Evolusi | SSOT Registry Service, Policy-as-Code Validation, Signed Releases, Continuous Documentation Assurance |

# 1. Executive Summary

SSOT-GOV-07 menetapkan governance resmi untuk menjaga paket Single Source of Truth tetap konsisten, unik, dapat ditelusuri, dapat divalidasi, dan dapat dirilis secara defensible.

Dokumen ini memastikan:

- setiap kode dokumen memiliki satu identitas canonical;
- setiap dokumen berada pada folder domain resmi;
- index menunjuk ke lokasi nyata;
- dependency mengarah ke dokumen yang tersedia atau tercatat sebagai gap;
- duplikasi dapat dideteksi dan diselesaikan;
- checksum paket dapat diverifikasi;
- perubahan struktur dapat diaudit;
- setiap paket memiliki integrity report dan manifest.

# 2. Objectives

Framework harus:

- menyediakan document identity rules;
- menetapkan canonical taxonomy;
- mencegah duplicate document codes;
- memvalidasi index;
- memvalidasi links;
- memvalidasi dependencies;
- menghasilkan package manifest;
- menghasilkan integrity report;
- menyediakan release gates;
- mendukung reconciliation.

# 3. Core Principles

```text
One Document Code, One Canonical Document
Document Location Is Deterministic
Index Must Match the Filesystem
Dependencies Must Be Resolvable
Duplicate Content Must Be Eliminated
Conflicting Duplicates Require an Explicit Decision
Released Files Are Checksummed
Package Structure Is Versioned
Integrity Findings Block Release by Severity
Every Consolidation Is Auditable
```

# 4. Scope

Berlaku untuk:

```text
SSOT Markdown Documents
SSOT Index
Dependency Matrix
Roadmaps
Architecture Blueprints
Implementation Guides
Package Manifests
Integrity Reports
Release Archives
```

# 5. Document Identity

Canonical identity ditentukan oleh document code.

Format yang direkomendasikan:

```text
SSOT-{DOMAIN}-{SEQUENCE}
```

Contoh:

```text
SSOT-GOV-07
SSOT-DATA-09
SSOT-API-06
```

# 6. Identity Requirements

Setiap SSOT harus memiliki:

- unique code;
- unique canonical filename;
- one canonical path;
- title;
- version;
- status;
- owner/domain;
- dependency declaration;
- stable link from index.

# 7. Canonical Filename

Format:

```text
{DOCUMENT_CODE}.md
```

# 8. Duplicate Identity

Duplicate identity terjadi ketika dua atau lebih file menggunakan document code atau filename canonical yang sama.

# 9. Duplicate Types

```text
IDENTICAL_DUPLICATE
CONTENT_CONFLICT
LEGACY_COPY
GENERATED_COPY
ORPHAN_COPY
```

# 10. Identical Duplicate

Dapat dihapus otomatis setelah checksum diverifikasi sama.

# 11. Conflicting Duplicate

Harus diselesaikan dengan decision record.

# 12. Canonical Selection

Selection inputs:

- completeness;
- recency;
- normative status;
- dependency compatibility;
- references from index;
- owner approval;
- content size only as fallback.

# 13. Conflict Preservation

Bila konflik belum dapat diputuskan, release harus diblokir atau dokumen dipindahkan ke controlled quarantine, bukan tetap memiliki identity sama.

# 14. Folder Taxonomy

Canonical taxonomy menggunakan nomor urut unik dan domain yang stabil.

```text
00-Governance
01-Scope
02-IAM
03-RBAC
04-Audit
05-Data
06-Workflow
07-Notification
08-API
09-Event
10-File
11-Search
12-Integration
13-Observability
14-Security
15-Deployment
16-Testing
17-Implementation
18-UI
19-Modules
20-SDK
21-MDM
22-Analytics
23-Records
24-Privacy
```

# 15. Taxonomy Rules

- satu nomor folder untuk satu domain;
- satu domain memiliki satu folder canonical;
- dokumen domain tidak disimpan di root;
- root hanya untuk package-level documents;
- perubahan taxonomy harus melalui migration map;
- links harus diperbarui atomically.

# 16. Root-Level Documents

Allowed examples:

```text
README.md
SSOT-INDEX.md
SSOT-DEPENDENCY-MATRIX.md
SSOT-ROADMAP.md
SSOT-INTEGRITY-REPORT.md
SSOT-PACKAGE-MANIFEST.json
```

# 17. Document Status

Recommended:

```text
DRAFT
IN_REVIEW
APPROVED
DEPRECATED
RETIRED
SUPERSEDED
```

# 18. Supersession

Dokumen yang disupersede harus menyebut replacement dan tidak tetap menjadi normative source.

# 19. Index Governance

`SSOT-INDEX.md` adalah registry navigasi resmi.

# 20. Index Requirements

Index harus:

- memuat setiap SSOT canonical;
- tidak memuat duplicate code;
- menggunakan relative link yang valid;
- menampilkan status;
- menyimpan gap register;
- tidak menunjuk ke file yang hilang.

# 21. Index Link Resolution

Setiap link harus dinormalisasi terhadap lokasi `SSOT-INDEX.md`.

# 22. Index Rebuild

Automated rebuild diperbolehkan jika metadata document dapat diparsing secara andal.

# 23. Dependency Matrix

`SSOT-DEPENDENCY-MATRIX.md` mencatat hubungan normatif antar-dokumen.

# 24. Dependency Types

```text
NORMATIVE
IMPLEMENTATION
REFERENCE
USED_BY
SUPERSEDES
OPTIONAL
```

# 25. Dependency Validation

Validator harus mendeteksi:

- missing document;
- circular dependency where prohibited;
- dependency to retired document;
- unversioned ambiguous range;
- dependency code typo;
- document not represented in matrix.

# 26. Range Dependencies

Notation seperti `DATA-01..09` harus di-expand saat validation.

# 27. Missing Dependency

Harus diklasifikasikan sebagai:

```text
CRITICAL_MISSING
PLANNED_GAP
EXTERNAL_REFERENCE
TYPO_SUSPECTED
```

# 28. Link Validation

Validator memeriksa semua relative Markdown links.

# 29. Broken Link Severity

```text
CRITICAL: normative document link broken
HIGH: index/dependency link broken
MEDIUM: supporting link broken
LOW: optional reference unavailable
```

# 30. Internal Anchor Validation

Section anchors sebaiknya divalidasi untuk links yang digunakan lintas dokumen.

# 31. Content Integrity

Setiap release menghasilkan SHA-256 untuk seluruh file.

# 32. Package Manifest

Manifest minimum:

```text
package version
generated timestamp
file paths
file sizes
SHA-256
document codes
document count
integrity status
```

# 33. Manifest Immutability

Manifest release tidak boleh diubah setelah package dipublikasikan.

# 34. Archive Integrity

ZIP harus:

- lolos CRC validation;
- tidak memiliki duplicate paths;
- tidak memiliki path traversal;
- tidak memiliki hidden temporary files;
- berisi index, dependency matrix, report, dan manifest.

# 35. Package Version

Package version harus membedakan release struktur dan isi.

# 36. Release Candidate

Consolidation dijalankan sebelum release candidate ditandai valid.

# 37. Integrity Finding States

```text
OPEN
ACCEPTED
REMEDIATING
RESOLVED
FALSE_POSITIVE
DEFERRED_APPROVED
```

# 38. Integrity Severity

```text
INFO
LOW
MEDIUM
HIGH
CRITICAL
```

# 39. Critical Findings

Examples:

- duplicate canonical document code;
- missing index;
- broken normative index link;
- ZIP corruption;
- path traversal;
- missing critical dependency;
- conflicting duplicate unresolved.

# 40. High Findings

Examples:

- stale index entry;
- missing dependency-matrix entry;
- folder taxonomy collision;
- root-level domain document;
- invalid status metadata.

# 41. Medium Findings

Examples:

- optional broken reference;
- document missing owner metadata;
- inconsistent title;
- noncanonical filename.

# 42. Release Gates

Release must fail when:

- any critical finding remains;
- high finding lacks approved exception;
- ZIP validation fails;
- manifest mismatch exists;
- index does not cover canonical SSOTs.

# 43. Approved Exception

Requires:

- finding;
- reason;
- owner;
- risk;
- expiry;
- remediation plan;
- approver.

# 44. Consolidation Workflow

```text
Inventory
→ Detect Duplicates
→ Select Canonical Documents
→ Normalize Taxonomy
→ Rewrite Links
→ Validate Dependencies
→ Rebuild Index Metadata
→ Generate Manifest
→ Generate Integrity Report
→ Validate ZIP
→ Release
```

# 45. Inventory

Inventory must capture:

- path;
- filename;
- document code;
- title;
- size;
- checksum;
- status;
- domain;
- dependencies.

# 46. Document Code Extraction

Preferred from status table; filename is fallback.

# 47. Content Conflict Detection

Use checksum and document identity.

# 48. Migration Map

Folder or filename moves must be recorded as source-to-target map.

# 49. Link Rewrite

Links should be rewritten using filename-to-canonical-path registry.

# 50. Canonical Registry

The registry maps:

```text
document_code
filename
canonical_path
checksum
status
```

# 51. Stale Gap Detection

Gap entry is stale when the described document already exists.

# 52. Gap Register

Every gap should include:

- priority;
- proposed code;
- description;
- owner;
- status;
- dependency impact.

# 53. Reconciliation

Compare:

- filesystem inventory;
- index rows;
- dependency matrix;
- document headers;
- manifest;
- archive members.

# 54. Reconciliation Findings

```text
FILE_NOT_IN_INDEX
INDEX_ENTRY_WITHOUT_FILE
DUPLICATE_DOCUMENT_CODE
DUPLICATE_FILENAME
NONCANONICAL_FOLDER
ROOT_DOMAIN_DOCUMENT
MISSING_DEPENDENCY
BROKEN_RELATIVE_LINK
MANIFEST_HASH_MISMATCH
ARCHIVE_MEMBER_MISMATCH
STALE_GAP_ENTRY
```

# 55. Auto-Remediation

Safe examples:

- remove identical duplicate;
- move file to canonical folder;
- update relative index link;
- add missing manifest entry;
- remove stale gap entry;
- normalize folder numbering.

# 56. Manual Remediation

Required for:

- conflicting duplicate content;
- ambiguous canonical identity;
- missing critical normative document;
- incompatible dependency graph;
- status dispute;
- competing approved versions.

# 57. Audit Events

```text
SSOT_DOCUMENT_REGISTERED
SSOT_DOCUMENT_MOVED
SSOT_DUPLICATE_REMOVED
SSOT_CONFLICT_RESOLVED
SSOT_INDEX_REBUILT
SSOT_DEPENDENCY_VALIDATED
SSOT_MANIFEST_GENERATED
SSOT_INTEGRITY_FINDING_OPENED
SSOT_PACKAGE_VALIDATED
SSOT_RELEASE_PUBLISHED
```

# 58. Metrics

```text
ssot_document_total
ssot_duplicate_identity_total
ssot_broken_link_total
ssot_missing_dependency_total
ssot_noncanonical_path_total
ssot_index_coverage_ratio
ssot_manifest_mismatch_total
ssot_integrity_finding_total
ssot_package_validation_failure_total
```

# 59. KPIs

```text
Duplicate canonical identities = 0
Broken index links = 0
Missing critical dependencies = 0
Domain documents in root = 0
Canonical documents missing from index = 0
Manifest checksum mismatches = 0
Corrupt release archives = 0
```

# 60. KRIs

```text
Taxonomy drift
Stale gap entries
Conflicting duplicate growth
Missing dependency growth
Index coverage decline
Manual release exceptions
Package validation failures
```

# 61. Repository Layout

```text
ssot/
├── 00-Governance/
├── 01-Scope/
├── ...
├── 24-Privacy/
├── README.md
├── SSOT-INDEX.md
├── SSOT-DEPENDENCY-MATRIX.md
├── SSOT-INTEGRITY-REPORT.md
└── SSOT-PACKAGE-MANIFEST.json
```

# 62. CI Validation Direction

CI should run:

```text
inventory
identity uniqueness
folder taxonomy
index links
dependency expansion
Markdown links
required metadata
checksums
ZIP build/test
integrity report
```

# 63. Document Registry Contract

```php
interface SsotDocumentRegistryInterface
{
    public function findByCode(
        string $documentCode
    ): ?SsotDocument;

    public function requireCanonical(
        string $documentCode
    ): SsotDocument;
}
```

# 64. Integrity Validator Contract

```php
interface SsotIntegrityValidatorInterface
{
    public function validate(
        SsotPackage $package
    ): SsotIntegrityReport;
}
```

# 65. Consolidation Contract

```php
interface SsotConsolidationServiceInterface
{
    public function consolidate(
        SsotConsolidationRequest $request
    ): SsotConsolidationResult;
}
```

# 66. Error Codes

```text
SSOT_DOCUMENT_CODE_DUPLICATE
SSOT_CANONICAL_DOCUMENT_MISSING
SSOT_INDEX_MISSING
SSOT_INDEX_LINK_BROKEN
SSOT_DEPENDENCY_MISSING
SSOT_FOLDER_NONCANONICAL
SSOT_ROOT_DOMAIN_DOCUMENT
SSOT_MANIFEST_MISMATCH
SSOT_ARCHIVE_INVALID
SSOT_RELEASE_GATE_FAILED
```

# 67. Consolidation Checklist

- [ ] Base package verified.
- [ ] Inventory completed.
- [ ] Duplicate identities detected.
- [ ] Canonical selection recorded.
- [ ] Folder taxonomy normalized.
- [ ] Root domain files moved.
- [ ] Index links updated.
- [ ] Dependency matrix validated.
- [ ] Stale gaps removed.
- [ ] Manifest generated.
- [ ] Integrity report generated.
- [ ] ZIP CRC validated.

# 68. Release Checklist

- [ ] No critical findings.
- [ ] High findings resolved or approved.
- [ ] One canonical path per document code.
- [ ] All index links valid.
- [ ] Dependency report available.
- [ ] Package manifest complete.
- [ ] Checksums match.
- [ ] ZIP contains required package files.
- [ ] Release version assigned.
- [ ] Evidence retained.

# 69. UAT — Identity & Deduplication

- [ ] Identical duplicate removed.
- [ ] Conflicting duplicate detected.
- [ ] Canonical selection logged.
- [ ] Duplicate code blocks release.
- [ ] Root-level duplicate moved.
- [ ] Canonical checksum recorded.
- [ ] One file remains per code.
- [ ] Index points to canonical path.

# 70. UAT — Taxonomy

- [ ] Folder numbers unique.
- [ ] Domain folders unique.
- [ ] Notification folders merged.
- [ ] SDK documents consolidated.
- [ ] MDM documents consolidated.
- [ ] Analytics/Records/Privacy paths normalized.
- [ ] Domain docs absent from root.
- [ ] Migration map retained.

# 71. UAT — Index & Links

- [ ] Index exists.
- [ ] Every canonical SSOT indexed.
- [ ] Index has no duplicate codes.
- [ ] Relative links resolve.
- [ ] Stale entries detected.
- [ ] Stale gap detected.
- [ ] New GOV-07 entry resolves.
- [ ] Moved documents remain navigable.

# 72. UAT — Dependency Validation

- [ ] Explicit dependencies resolve.
- [ ] Range dependencies expand.
- [ ] Missing dependency classified.
- [ ] Typo-like dependency flagged.
- [ ] Retired dependency flagged.
- [ ] Dependency matrix includes GOV-07.
- [ ] Circular-policy checks run.
- [ ] Findings included in report.

# 73. UAT — Manifest & Archive

- [ ] Every file hashed.
- [ ] Manifest file count matches archive.
- [ ] Modified file mismatch detected.
- [ ] ZIP CRC passes.
- [ ] Duplicate archive path rejected.
- [ ] Path traversal rejected.
- [ ] Required files present.
- [ ] Integrity status recorded.

# 74. Definition of Done — SSOT-GOV-07

SSOT-GOV-07 dianggap selesai bila:

- [ ] document identity rules tersedia;
- [ ] canonical filename tersedia;
- [ ] duplicate taxonomy tersedia;
- [ ] canonical selection rules tersedia;
- [ ] folder taxonomy tersedia;
- [ ] root-document rules tersedia;
- [ ] index governance tersedia;
- [ ] dependency validation tersedia;
- [ ] link validation tersedia;
- [ ] manifest/checksum tersedia;
- [ ] ZIP validation tersedia;
- [ ] finding severity/status tersedia;
- [ ] release gates tersedia;
- [ ] consolidation workflow tersedia;
- [ ] migration map tersedia;
- [ ] stale-gap detection tersedia;
- [ ] reconciliation tersedia;
- [ ] audit and metrics tersedia;
- [ ] contracts/error codes tersedia;
- [ ] UAT and DoD tersedia.

# 75. Implementation Roadmap

## Phase 1 — Inventory & Identity

- document inventory;
- code extraction;
- checksum registry;
- duplicate detection;
- canonical paths.

## Phase 2 — Taxonomy & Links

- folder normalization;
- root cleanup;
- index link rewriting;
- gap validation;
- migration map.

## Phase 3 — Dependency Assurance

- dependency parser;
- range expansion;
- missing-document classification;
- dependency graph;
- release gates.

## Phase 4 — Package Assurance

- manifest generation;
- integrity report;
- archive validation;
- signed release metadata;
- CI integration.

## Phase 5 — Continuous SSOT Platform

- SSOT registry service;
- policy-as-code validation;
- document lifecycle workflow;
- automated dependency impact;
- continuous integrity dashboard.

# 76. Initial Implementation Backlog

```text
GOV07-001 Document Inventory
GOV07-002 Document Code Parser
GOV07-003 Duplicate Detector
GOV07-004 Canonical Selection Workflow
GOV07-005 Folder Taxonomy Validator
GOV07-006 Root Document Validator
GOV07-007 Index Link Validator
GOV07-008 Index Coverage Validator
GOV07-009 Dependency Parser
GOV07-010 Dependency Range Expander
GOV07-011 Gap Registry Validator
GOV07-012 Package Manifest Generator
GOV07-013 Integrity Report Generator
GOV07-014 ZIP Integrity Validator
GOV07-015 Release Gate
GOV07-016 SSOT Integrity Dashboard
```

# 77. Approval Gate

Dokumen dapat menjadi Approved setelah:

- Architecture Governance review;
- Documentation Governance review;
- Platform Architecture review;
- Release Engineering review;
- Audit/Compliance review;
- Quality Engineering review;
- UAT review.

# 78. Closing Statement

SSOT hanya dapat menjadi sumber kebenaran jika identitas, lokasi, index, dependency, dan paketnya dapat dipercaya.

Satu document code harus memiliki satu canonical document.

Index harus sesuai dengan filesystem.

Dependencies harus dapat diselesaikan.

Setiap release harus memiliki manifest, checksum, integrity report, dan archive validation.
