# SSOT-GOV-04 — Risk, Control & Exception Management

---

## Status Dokumen

| Item | Nilai |
|---|---|
| Kode | SSOT-GOV-04 |
| Judul | Risk, Control & Exception Management |
| Versi | 1.0 |
| Status | Draft for Review |
| Domain | Platform Kernel |
| Kategori | Governance, Risk & Control |
| Cakupan | Risk Register, Control Catalog, Control Testing, Exceptions, Evidence, Escalation |
| Bergantung pada | SSOT-GOV-01, SSOT-GOV-02, SSOT-GOV-03, SSOT-SEC-01, SSOT-SEC-02 |
| Target Arsitektur | Modular Monolith, Enterprise Platform Kernel |

---

# 1. Executive Summary

SSOT-GOV-04 menetapkan framework resmi untuk mengelola risk, control, dan exception pada Platform Kernel dan seluruh module bisnis.

Framework ini mengatur:

- risk identification;
- risk assessment;
- inherent risk;
- control mapping;
- residual risk;
- risk treatment;
- risk acceptance;
- control catalog;
- control ownership;
- control testing;
- control effectiveness;
- evidence;
- exception request;
- compensating controls;
- approvals;
- expiry;
- renewal;
- escalation;
- metrics;
- UAT;
- Definition of Done.

Tujuan akhirnya adalah memastikan setiap risk dan deviation:

- memiliki owner;
- dinilai konsisten;
- memiliki control;
- memiliki evidence;
- memiliki treatment;
- memiliki approval;
- memiliki expiry;
- dapat diaudit;
- dapat ditutup setelah verification.

---

# 2. Objectives

Framework harus:

- menjaga risk visibility;
- mengurangi unmanaged risk;
- memastikan control ownership;
- menghindari permanent exception;
- mendukung decision-making;
- mendukung audit;
- menghubungkan policy ke evidence;
- mengelola remediation;
- memperjelas residual risk;
- meningkatkan governance maturity.

---

# 3. Core Principles

```text
No Unowned Risk
No Unowned Control
No Permanent Exception
Evidence Before Closure
Risk-Based Prioritization
Explicit Residual Risk
Time-Bound Acceptance
Compensating Controls Required
Separation of Duties
Continuous Review
```

---

# 4. Scope

Framework berlaku untuk:

```text
Architecture
Security
Data
Privacy
Delivery
Operations
Compliance
Vendor
Financial
Strategic
Business Continuity
```

---

# 5. Risk Taxonomy

```text
STRATEGIC
ARCHITECTURE
SECURITY
DATA
PRIVACY
COMPLIANCE
OPERATIONAL
DELIVERY
VENDOR
FINANCIAL
RESILIENCE
```

---

# 6. Risk Lifecycle

```text
Identify
→ Classify
→ Assess
→ Assign Owner
→ Map Controls
→ Determine Residual Risk
→ Select Treatment
→ Approve
→ Monitor
→ Review
→ Close
```

---

# 7. Risk Identification Sources

Risk may originate from:

- architecture review;
- threat modeling;
- audit;
- incident;
- vulnerability scan;
- control testing;
- vendor review;
- compliance assessment;
- operational failure;
- roadmap planning;
- change review;
- user/customer feedback.

---

# 8. Risk Record

Minimum fields:

```text
risk_id
title
description
category
source
asset_or_process
inherent_likelihood
inherent_impact
inherent_rating
controls
residual_likelihood
residual_impact
residual_rating
treatment
owner
target_date
status
review_due_at
```

---

# 9. Risk Status

```text
NEW
ASSESSED
TREATMENT_PLANNED
IN_PROGRESS
MONITORED
ACCEPTED
TRANSFERRED
AVOIDED
CLOSED
ESCALATED
```

---

# 10. Risk Assessment Scale

Likelihood:

```text
1 — Rare
2 — Unlikely
3 — Possible
4 — Likely
5 — Almost Certain
```

Impact:

```text
1 — Insignificant
2 — Minor
3 — Moderate
4 — Major
5 — Severe
```

---

# 11. Risk Score

Formula:

```text
Risk Score = Likelihood × Impact
```

---

# 12. Risk Rating

| Score | Rating |
|---:|---|
| 1–4 | LOW |
| 5–9 | MEDIUM |
| 10–16 | HIGH |
| 17–25 | CRITICAL |

---

# 13. Inherent Risk

Inherent risk adalah risk sebelum memperhitungkan control.

---

# 14. Residual Risk

Residual risk adalah risk setelah control diterapkan dan diuji.

---

# 15. Risk Appetite

Risk appetite harus didefinisikan per domain.

Example:

| Domain | Appetite |
|---|---|
| Cross-tenant exposure | ZERO / VERY LOW |
| Privileged access misuse | VERY LOW |
| Critical data loss | VERY LOW |
| Temporary non-critical UI defect | MODERATE |
| Experimental internal tooling | MODERATE |

---

# 16. Risk Tolerance

Tolerance menentukan deviasi operasional yang masih dapat diterima.

---

# 17. Risk Treatment Options

```text
MITIGATE
ACCEPT
TRANSFER
AVOID
```

---

# 18. Mitigate

Reduce likelihood and/or impact through controls.

---

# 19. Accept

Accept residual risk with:

- owner;
- rationale;
- approval;
- review date;
- expiry where appropriate.

---

# 20. Transfer

Transfer through:

- insurance;
- contract;
- vendor SLA;
- managed service.

Risk accountability still remains with the organization.

---

# 21. Avoid

Stop or redesign activity that creates unacceptable risk.

---

# 22. Risk Owner

Risk owner is accountable for:

- treatment;
- funding;
- deadlines;
- residual risk;
- escalation;
- closure.

---

# 23. Risk Review Cadence

| Rating | Review |
|---|---:|
| Critical | weekly |
| High | monthly |
| Medium | quarterly |
| Low | semiannual/annual |

---

# 24. Critical Risk Rules

Critical risk requires:

- immediate escalation;
- treatment owner;
- target date;
- governance review;
- no silent acceptance;
- executive/security approval for acceptance.

---

# 25. Risk Aging

Track:

```text
days_open
days_overdue
last_review_at
next_review_at
```

---

# 26. Risk Closure

Risk may close only when:

- threat/process removed; or
- treatment implemented;
- residual risk accepted;
- evidence available;
- verifier confirms closure.

---

# 27. Control Framework

Control types:

```text
PREVENTIVE
DETECTIVE
CORRECTIVE
RECOVERY
GOVERNANCE
```

---

# 28. Control Domains

```text
IDENTITY
AUTHORIZATION
TENANT_ISOLATION
DATA_PROTECTION
SECURE_SDLC
CHANGE_MANAGEMENT
DEPLOYMENT
OBSERVABILITY
BACKUP_RECOVERY
VENDOR
COMPLIANCE
GOVERNANCE
```

---

# 29. Control Record

Minimum fields:

```text
control_id
title
objective
description
type
domain
owner
frequency
automation_level
evidence
status
design_effectiveness
operating_effectiveness
last_tested_at
next_test_at
```

---

# 30. Control Status

```text
DESIGNED
IMPLEMENTED
OPERATING
PARTIALLY_EFFECTIVE
INEFFECTIVE
SUSPENDED
RETIRED
```

---

# 31. Control Ownership

Every control must have:

- accountable owner;
- operator;
- evidence owner;
- reviewer.

---

# 32. Control Objective

Control objective must state intended outcome.

Example:

```text
Prevent unauthorized cross-tenant access to restricted records.
```

---

# 33. Control Design

Control design should define:

- trigger;
- action;
- scope;
- frequency;
- evidence;
- failure behavior;
- owner.

---

# 34. Control Frequency

```text
CONTINUOUS
PER_REQUEST
DAILY
WEEKLY
MONTHLY
QUARTERLY
ANNUAL
EVENT_DRIVEN
```

---

# 35. Automation Level

```text
MANUAL
SEMI_AUTOMATED
AUTOMATED
CONTINUOUS
```

---

# 36. Control Testing

Control testing must verify:

```text
Design Effectiveness
Operating Effectiveness
Evidence Quality
Coverage
Sustainability
```

---

# 37. Design Effectiveness

Question:

```text
If control operates as designed, will it reduce the risk?
```

---

# 38. Operating Effectiveness

Question:

```text
Did the control operate consistently during the test period?
```

---

# 39. Evidence Quality

Evidence should be:

- relevant;
- complete;
- accurate;
- attributable;
- timestamped;
- tamper-evident.

---

# 40. Control Test Types

```text
INSPECTION
REPERFORMANCE
SAMPLE_TEST
AUTOMATED_ASSERTION
TECHNICAL_TEST
INTERVIEW
OBSERVATION
```

---

# 41. Control Test Record

```text
test_id
control_id
period
method
sample_size
tester
result
finding
evidence
tested_at
```

---

# 42. Control Test Result

```text
PASS
PASS_WITH_OBSERVATION
FAIL
NOT_TESTED
NOT_APPLICABLE
```

---

# 43. Control Failure

A failed control should:

- create finding;
- reassess linked risks;
- assign owner;
- define remediation;
- trigger escalation if critical.

---

# 44. Compensating Control

Compensating control must:

- address same objective;
- reduce risk meaningfully;
- be testable;
- have owner;
- be time-bound when used for exception.

---

# 45. Key Controls

Key controls are controls critical to:

- regulatory compliance;
- tenant isolation;
- privileged access;
- restricted data protection;
- production release;
- backup/recovery.

---

# 46. Key Control Review

Key controls require:

- explicit owner;
- frequent testing;
- strong evidence;
- escalation on failure.

---

# 47. Control Mapping

```text
Policy
→ Requirement
→ Risk
→ Control
→ Evidence
→ Test
```

---

# 48. Control Coverage

Coverage should show:

- risks without controls;
- controls without risks;
- controls without evidence;
- controls not tested;
- ineffective controls.

---

# 49. Evidence Register

Minimum:

```text
evidence_id
control_id
source
period
owner
classification
checksum
storage_reference
created_at
retention_until
legal_hold
```

---

# 50. Evidence Classification

```text
PUBLIC
INTERNAL
CONFIDENTIAL
RESTRICTED
```

---

# 51. Evidence Retention

Retention depends on:

- policy;
- audit;
- legal requirements;
- incident/legal hold;
- system lifecycle.

---

# 52. Evidence Integrity

Critical evidence should use:

- checksum;
- immutable storage;
- access audit;
- versioning;
- chain of custody where required.

---

# 53. Exception Management

Exception lifecycle:

```text
Request
→ Assess
→ Review
→ Approve/Reject
→ Activate
→ Monitor
→ Renew/Expire
→ Close
```

---

# 54. Exception Types

```text
POLICY_EXCEPTION
STANDARD_EXCEPTION
CONTROL_EXCEPTION
ARCHITECTURE_EXCEPTION
SECURITY_EXCEPTION
TEMPORARY_OPERATIONAL_EXCEPTION
```

---

# 55. Exception Request

Minimum fields:

```text
exception_id
type
policy_or_control
scope
reason
business_justification
risk
compensating_controls
owner
requested_by
effective_from
expires_at
```

---

# 56. Exception Status

```text
DRAFT
REQUESTED
IN_REVIEW
APPROVED
REJECTED
ACTIVE
EXPIRED
REVOKED
CLOSED
```

---

# 57. Exception Approval

Approval depends on risk:

| Risk | Approval |
|---|---|
| Low | Control/Policy Owner |
| Medium | Domain Governance Owner |
| High | Governance + Security/Architecture |
| Critical | Governance Board + Executive/Security |

---

# 58. Exception Rules

Exception must not be:

- permanent;
- ownerless;
- without risk assessment;
- without compensating controls where needed;
- silently renewed;
- used to hide active exploitation;
- used to bypass legal requirements.

---

# 59. Exception Expiry

Every active exception must have:

```text
effective_from
expires_at
review_due_at
```

---

# 60. Exception Duration

Recommended maximum:

| Risk | Maximum |
|---|---:|
| Critical | 30 days |
| High | 90 days |
| Medium | 180 days |
| Low | 365 days |

---

# 61. Exception Renewal

Renewal requires:

- fresh assessment;
- updated evidence;
- status of remediation;
- renewed approval;
- new expiry.

---

# 62. Exception Revocation

Exception may be revoked when:

- risk increases;
- compensating control fails;
- scope changes;
- incident occurs;
- underlying requirement changes.

---

# 63. Exception Closure

Close when:

- root issue fixed;
- policy/control no longer applicable;
- system retired;
- exception replaced by approved design.

---

# 64. Exception Usage

Systems and releases must verify exception validity before relying on it.

Expired exception must fail closed for critical controls.

---

# 65. Risk Acceptance vs Exception

Risk acceptance:

```text
Accepts residual risk.
```

Exception:

```text
Temporarily permits deviation from a policy, standard, or control.
```

They may coexist but are not identical.

---

# 66. Segregation of Duties

Critical exception should avoid:

```text
requester = sole approver
```

---

# 67. Emergency Exception

Emergency exception may use expedited approval but must:

- be documented;
- be time-bound;
- have retrospective review;
- have remediation action;
- preserve audit.

---

# 68. Finding Lifecycle

Control tests, audits, and risk reviews may create findings.

Statuses:

```text
OPEN
ASSIGNED
IN_PROGRESS
REMEDIATED
VERIFICATION_PENDING
VERIFIED
RISK_ACCEPTED
CLOSED
```

---

# 69. Finding Record

```text
finding_id
source
control_id
risk_id
severity
description
owner
target_date
status
evidence
```

---

# 70. Remediation SLA

Recommended:

| Severity | Target |
|---|---:|
| Critical | 24–72 hours |
| High | 7–14 days |
| Medium | 30–60 days |
| Low | 90–180 days |

---

# 71. Escalation Rules

Escalate when:

- critical risk unowned;
- critical control fails;
- high/critical exception expires;
- finding overdue;
- evidence missing;
- repeated exception occurs;
- residual risk exceeds appetite.

---

# 72. Governance Forums

Recommended:

```text
Risk & Compliance Committee
Security Governance Committee
Architecture Review Board
Platform Governance Board
```

---

# 73. Risk Review Agenda

```text
Critical risks
Overdue treatments
Control failures
Expired exceptions
New audit findings
Residual risk above appetite
Repeated exceptions
Escalations
```

---

# 74. Metrics

```text
risk_open_total
risk_critical_total
risk_overdue_total
risk_without_owner_total
control_total
control_ineffective_total
control_untested_total
evidence_missing_total
exception_active_total
exception_expired_total
exception_renewal_total
finding_overdue_total
```

---

# 75. KPIs

Initial targets:

```text
Critical risks without owner = 0
Expired critical exceptions = 0
Key controls tested on schedule = 100%
Critical control failures unresolved = 0
Evidence completeness for key controls >= 95%
High-risk exceptions with compensating control = 100%
```

---

# 76. Dashboard Views

Recommended:

- risks by rating;
- risks by owner;
- risks by age;
- controls by effectiveness;
- controls overdue for test;
- evidence gaps;
- active exceptions;
- exceptions near expiry;
- repeated exceptions;
- overdue findings.

---

# 77. Automation

Automate where possible:

- risk review reminders;
- control test scheduling;
- evidence collection;
- exception expiry;
- approval routing;
- escalations;
- dashboard updates;
- linkage validation.

---

# 78. API Direction

Potential endpoints:

```text
/api/internal/v1/governance/risks
/api/internal/v1/governance/controls
/api/internal/v1/governance/control-tests
/api/internal/v1/governance/exceptions
/api/internal/v1/governance/evidence
/api/internal/v1/governance/findings
/api/internal/v1/governance/dashboard
```

---

# 79. Database Direction

Potential tables:

```text
gov_risks
gov_risk_events
gov_risk_controls
gov_controls
gov_control_tests
gov_control_evidence
gov_exceptions
gov_exception_approvals
gov_exception_reviews
gov_findings
gov_finding_events
```

---

# 80. Table: gov_risks

```sql
CREATE TABLE gov_risks (
    id CHAR(26) NOT NULL,
    risk_code VARCHAR(50) NOT NULL,
    title VARCHAR(500) NOT NULL,
    description_text LONGTEXT NOT NULL,
    category VARCHAR(50) NOT NULL,
    source VARCHAR(100) NOT NULL,
    owner_reference VARCHAR(180) NOT NULL,
    inherent_likelihood TINYINT UNSIGNED NOT NULL,
    inherent_impact TINYINT UNSIGNED NOT NULL,
    inherent_score TINYINT UNSIGNED NOT NULL,
    residual_likelihood TINYINT UNSIGNED NOT NULL,
    residual_impact TINYINT UNSIGNED NOT NULL,
    residual_score TINYINT UNSIGNED NOT NULL,
    treatment VARCHAR(30) NOT NULL,
    status VARCHAR(30) NOT NULL,
    target_date DATE NULL,
    review_due_at DATETIME(6) NULL,
    created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    updated_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6)
        ON UPDATE CURRENT_TIMESTAMP(6),

    PRIMARY KEY (id),
    UNIQUE KEY uq_gov_risk_code (risk_code),
    KEY idx_gov_risk_status (
        status,
        residual_score,
        review_due_at
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

# 81. Table: gov_controls

```sql
CREATE TABLE gov_controls (
    id CHAR(26) NOT NULL,
    control_code VARCHAR(50) NOT NULL,
    title VARCHAR(500) NOT NULL,
    objective_text LONGTEXT NOT NULL,
    description_text LONGTEXT NOT NULL,
    control_type VARCHAR(30) NOT NULL,
    domain VARCHAR(80) NOT NULL,
    owner_reference VARCHAR(180) NOT NULL,
    frequency VARCHAR(30) NOT NULL,
    automation_level VARCHAR(30) NOT NULL,
    status VARCHAR(30) NOT NULL,
    design_effectiveness VARCHAR(30) NULL,
    operating_effectiveness VARCHAR(30) NULL,
    last_tested_at DATETIME(6) NULL,
    next_test_at DATETIME(6) NULL,

    PRIMARY KEY (id),
    UNIQUE KEY uq_gov_control_code (control_code),
    KEY idx_gov_control_status (
        status,
        next_test_at
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

# 82. Table: gov_control_tests

```sql
CREATE TABLE gov_control_tests (
    id CHAR(26) NOT NULL,
    control_id CHAR(26) NOT NULL,
    test_method VARCHAR(50) NOT NULL,
    period_start DATE NOT NULL,
    period_end DATE NOT NULL,
    tester_reference VARCHAR(180) NOT NULL,
    result VARCHAR(30) NOT NULL,
    finding_reference VARCHAR(50) NULL,
    evidence_reference VARCHAR(1000) NULL,
    tested_at DATETIME(6) NOT NULL,

    PRIMARY KEY (id),
    KEY idx_gov_control_test (
        control_id,
        tested_at
    ),
    CONSTRAINT fk_gov_control_test_control
        FOREIGN KEY (control_id)
        REFERENCES gov_controls (id)
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

# 83. Table: gov_exceptions

```sql
CREATE TABLE gov_exceptions (
    id CHAR(26) NOT NULL,
    exception_code VARCHAR(50) NOT NULL,
    exception_type VARCHAR(50) NOT NULL,
    reference_code VARCHAR(100) NOT NULL,
    scope_text LONGTEXT NOT NULL,
    reason_text LONGTEXT NOT NULL,
    business_justification LONGTEXT NOT NULL,
    risk_rating VARCHAR(30) NOT NULL,
    compensating_controls_text LONGTEXT NULL,
    owner_reference VARCHAR(180) NOT NULL,
    requested_by VARCHAR(180) NOT NULL,
    status VARCHAR(30) NOT NULL,
    effective_from DATETIME(6) NULL,
    expires_at DATETIME(6) NOT NULL,
    review_due_at DATETIME(6) NOT NULL,
    created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),

    PRIMARY KEY (id),
    UNIQUE KEY uq_gov_exception_code (
        exception_code
    ),
    KEY idx_gov_exception_status (
        status,
        expires_at
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

# 84. Event Codes

```text
GOV_RISK_CREATED
GOV_RISK_ESCALATED
GOV_RISK_ACCEPTED
GOV_RISK_CLOSED
GOV_CONTROL_CREATED
GOV_CONTROL_TESTED
GOV_CONTROL_FAILED
GOV_EXCEPTION_REQUESTED
GOV_EXCEPTION_APPROVED
GOV_EXCEPTION_REJECTED
GOV_EXCEPTION_EXPIRED
GOV_EXCEPTION_REVOKED
GOV_FINDING_OPENED
GOV_FINDING_VERIFIED
```

---

# 85. Error Codes

```text
GOV_RISK_NOT_FOUND
GOV_RISK_OWNER_REQUIRED
GOV_RISK_ACCEPTANCE_APPROVAL_REQUIRED
GOV_CONTROL_NOT_FOUND
GOV_CONTROL_OWNER_REQUIRED
GOV_CONTROL_TEST_OVERDUE
GOV_EXCEPTION_NOT_FOUND
GOV_EXCEPTION_EXPIRED
GOV_EXCEPTION_APPROVAL_REQUIRED
GOV_EXCEPTION_COMPENSATING_CONTROL_REQUIRED
GOV_EVIDENCE_INCOMPLETE
GOV_FINDING_VERIFICATION_REQUIRED
```

---

# 86. Sample Risk

```yaml
risk_code: RISK-SEC-001
title: Cross-tenant data exposure
category: SECURITY
source: threat_model
inherent_likelihood: 3
inherent_impact: 5
inherent_score: 15
controls:
  - CTRL-SEC-001
  - CTRL-SEC-002
residual_likelihood: 1
residual_impact: 5
residual_score: 5
treatment: MITIGATE
owner: platform_security
status: MONITORED
```

---

# 87. Sample Control

```yaml
control_code: CTRL-SEC-001
title: Tenant-aware repository enforcement
objective: Prevent unauthorized cross-tenant access.
type: PREVENTIVE
domain: TENANT_ISOLATION
owner: platform_architecture
frequency: PER_REQUEST
automation_level: AUTOMATED
evidence:
  - tenant_isolation_test
  - authorization_denial_event
status: OPERATING
```

---

# 88. Sample Exception

```yaml
exception_code: EXC-2026-001
type: CONTROL_EXCEPTION
reference_code: CTRL-SEC-001
scope: legacy_reporting_module
reason: legacy query layer not yet tenant-aware
risk_rating: HIGH
compensating_controls:
  - restricted network access
  - read-only database account
  - daily export review
owner: reporting_module_owner
effective_from: 2026-07-01
expires_at: 2026-09-30
status: ACTIVE
```

---

# 89. Risk-Control Matrix

| Risk | Control | Type | Effectiveness | Evidence |
|---|---|---|---|---|
| Cross-tenant exposure | Tenant-aware repositories | Preventive | Effective | Tenant tests |
| Secret leakage | Secret scanning | Detective/Preventive | Effective | Scan reports |
| Invalid release | Release gate | Preventive | Effective | Gate evidence |

---

# 90. Exception Review Checklist

- [ ] Reference exists.
- [ ] Scope is narrow.
- [ ] Business justification is valid.
- [ ] Risk assessed.
- [ ] Compensating controls defined.
- [ ] Owner assigned.
- [ ] Expiry defined.
- [ ] Approval level correct.
- [ ] Remediation plan exists.
- [ ] Evidence attached.

---

# 91. Control Test Checklist

- [ ] Objective clear.
- [ ] Test period defined.
- [ ] Method appropriate.
- [ ] Sample sufficient.
- [ ] Evidence complete.
- [ ] Result justified.
- [ ] Findings created if needed.
- [ ] Owner notified.
- [ ] Retest planned.

---

# 92. UAT — Risk Management

- [ ] Risk taxonomy defined.
- [ ] Risk register exists.
- [ ] Likelihood/impact scales defined.
- [ ] Inherent and residual risk calculated.
- [ ] Risk appetite documented.
- [ ] Risk owners assigned.
- [ ] Treatment options available.
- [ ] Critical risks escalate.
- [ ] Review cadence works.
- [ ] Closure requires evidence.

---

# 93. UAT — Control Management

- [ ] Control catalog exists.
- [ ] Control types defined.
- [ ] Control owners assigned.
- [ ] Frequency defined.
- [ ] Automation level tracked.
- [ ] Design effectiveness assessed.
- [ ] Operating effectiveness assessed.
- [ ] Control tests recorded.
- [ ] Failed controls create findings.
- [ ] Key controls receive priority review.

---

# 94. UAT — Evidence

- [ ] Evidence register exists.
- [ ] Evidence linked to controls.
- [ ] Classification applied.
- [ ] Checksums available for critical evidence.
- [ ] Retention defined.
- [ ] Access controlled.
- [ ] Missing evidence visible.

---

# 95. UAT — Exception Management

- [ ] Exception types defined.
- [ ] Request workflow works.
- [ ] Risk assessment required.
- [ ] Compensating controls required where applicable.
- [ ] Approval routing based on risk.
- [ ] Expiry mandatory.
- [ ] Renewal requires reassessment.
- [ ] Expired exceptions fail closed for critical controls.
- [ ] Revocation works.
- [ ] Closure requires remediation/evidence.

---

# 96. UAT — Findings & Escalation

- [ ] Findings lifecycle defined.
- [ ] Remediation SLA defined.
- [ ] Overdue findings escalate.
- [ ] Control failure escalates.
- [ ] Critical risk without owner escalates.
- [ ] Repeated exceptions visible.
- [ ] Residual risk above appetite escalates.

---

# 97. UAT — Metrics & Automation

- [ ] Metrics defined.
- [ ] KPI targets defined.
- [ ] Dashboard views defined.
- [ ] Review reminders automated.
- [ ] Exception expiry automated.
- [ ] Control test scheduling automated.
- [ ] Evidence collection automated where feasible.
- [ ] Linkage validation works.

---

# 98. Definition of Done — SSOT-GOV-04

SSOT-GOV-04 dianggap selesai bila:

- [ ] objectives tersedia;
- [ ] principles tersedia;
- [ ] risk taxonomy tersedia;
- [ ] risk lifecycle tersedia;
- [ ] risk record tersedia;
- [ ] status model tersedia;
- [ ] likelihood/impact scales tersedia;
- [ ] risk rating tersedia;
- [ ] inherent/residual risk tersedia;
- [ ] risk appetite/tolerance tersedia;
- [ ] treatment options tersedia;
- [ ] owner/review cadence tersedia;
- [ ] control framework tersedia;
- [ ] control types/domains tersedia;
- [ ] control record tersedia;
- [ ] control testing tersedia;
- [ ] effectiveness model tersedia;
- [ ] evidence governance tersedia;
- [ ] exception lifecycle tersedia;
- [ ] exception types/status tersedia;
- [ ] approval levels tersedia;
- [ ] expiry/renewal/revocation tersedia;
- [ ] risk acceptance distinction tersedia;
- [ ] findings/remediation SLA tersedia;
- [ ] escalation rules tersedia;
- [ ] metrics/KPI tersedia;
- [ ] automation direction tersedia;
- [ ] API direction tersedia;
- [ ] database direction tersedia;
- [ ] event/error codes tersedia;
- [ ] samples tersedia;
- [ ] UAT tersedia.

---

# 99. Implementation Roadmap

## Phase 1 — Registers

- create risk register;
- create control catalog;
- create exception register;
- assign owners;
- define rating scales.

## Phase 2 — Testing & Evidence

- define key controls;
- schedule control tests;
- create evidence register;
- define retention;
- establish findings workflow.

## Phase 3 — Workflow

- automate approvals;
- automate expiry;
- automate escalations;
- integrate release/security gates;
- integrate audit.

## Phase 4 — Metrics

- dashboards;
- risk trends;
- control effectiveness;
- exception aging;
- overdue remediation.

## Phase 5 — Optimization

- continuous controls monitoring;
- automated evidence;
- predictive risk;
- policy-as-code integration;
- adaptive governance.

---

# 100. Approval Gate

Dokumen dapat menjadi Approved setelah:

- Platform Governance review;
- Risk & Compliance review;
- Security Governance review;
- Architecture review;
- Data Governance review;
- Operations review;
- risk scoring approval;
- control catalog review;
- exception approval model review;
- evidence and retention review;
- metrics and escalation review.

---

# 101. Closing Statement

Risk, control, dan exception management harus memastikan setiap risk dan deviation:

- memiliki owner;
- memiliki rating;
- memiliki control;
- memiliki evidence;
- memiliki treatment;
- memiliki approval;
- memiliki expiry;
- memiliki review;
- dapat diaudit;
- dapat ditutup setelah verification.

Framework ini tidak boleh menjadi register pasif.

Framework harus menjadi sistem aktif untuk mengurangi risk, menjaga control effectiveness, dan mencegah exception berubah menjadi permanent bypass.
