# SSOT-GOV-06 — Change & Release Governance

---

## Status Dokumen

| Item | Nilai |
|---|---|
| Kode | SSOT-GOV-06 |
| Judul | Change & Release Governance |
| Versi | 1.0 |
| Status | Draft for Review |
| Domain | Platform Kernel |
| Kategori | Governance, Change Management & Release Assurance |
| Cakupan | Change Classification, Approval, CAB, Release Readiness, Promotion, Deployment, Rollback, Emergency Change, Evidence |
| Bergantung pada | SSOT-GOV-01, SSOT-GOV-04, SSOT-GOV-05, SSOT-SEC-02, DEPLOY-SEC-01 |
| Target Arsitektur | Modular Monolith, Enterprise Platform Kernel |

---

# 1. Executive Summary

SSOT-GOV-06 menetapkan framework resmi untuk mengelola perubahan dan release pada Platform Kernel serta seluruh module bisnis.

Framework ini mengatur:

- change intake;
- change classification;
- impact and risk assessment;
- approval routing;
- Change Advisory Board;
- standard, normal, high-risk, dan emergency change;
- release planning;
- release readiness;
- environment promotion;
- deployment authorization;
- migration governance;
- rollback governance;
- segregation of duties;
- change evidence;
- post-implementation review;
- failed change review;
- metrics;
- UAT;
- Definition of Done.

Tujuan akhirnya adalah memastikan setiap perubahan:

- memiliki owner;
- memiliki scope;
- memiliki risk rating;
- memiliki test evidence;
- memiliki approval;
- memiliki rollback plan;
- dapat dilacak ke release;
- dapat diverifikasi;
- dapat diaudit;
- tidak mengganggu stabilitas, security, atau tenant isolation.

---

# 2. Objectives

Framework harus:

- mengurangi failed change;
- meningkatkan release predictability;
- menjaga security and compliance;
- memperjelas decision rights;
- mencegah unauthorized deployment;
- memastikan rollback readiness;
- mengontrol emergency changes;
- menjaga artifact integrity;
- mempercepat low-risk standard changes;
- meningkatkan auditability.

---

# 3. Core Principles

```text
No Unowned Change
No Production Change Without Authorization
Risk-Proportionate Approval
Build Once, Promote Many
Immutable Release Artifacts
Test Before Promote
Rollback Before Deploy
Separation of Duties
Evidence Before Closure
Emergency Does Not Mean Uncontrolled
```

---

# 4. Scope

Framework berlaku untuk:

```text
Application Code
Platform Kernel
Business Modules
Database Schema
Configuration
Infrastructure
Security Controls
Integrations
Scheduled Jobs
Feature Flags
Data Migration
Operational Procedures
Vendor-Managed Changes
```

---

# 5. Change Types

```text
STANDARD
NORMAL
HIGH_RISK
EMERGENCY
```

---

# 6. Standard Change

Standard change adalah perubahan:

- low risk;
- repeatable;
- documented;
- pre-approved;
- memiliki tested procedure;
- memiliki known rollback.

Examples:

- approved certificate renewal;
- routine log rotation config;
- scheduled dependency patch within approved baseline;
- routine user-visible content update without code impact.

---

# 7. Normal Change

Normal change memerlukan:

- change record;
- risk assessment;
- peer review;
- test evidence;
- approval sesuai scope;
- rollback plan.

---

# 8. High-Risk Change

High-risk change mencakup:

- authentication;
- authorization;
- tenant isolation;
- restricted data;
- database migration;
- external integration;
- payment-like workflow;
- encryption;
- key/secrets;
- critical infrastructure;
- irreversible data transformation.

---

# 9. Emergency Change

Emergency change digunakan untuk:

- active incident;
- critical vulnerability;
- production outage;
- imminent data loss;
- urgent regulatory requirement;
- severe integrity issue.

Emergency change tetap membutuhkan:

- minimum approval;
- logging;
- evidence;
- rollback;
- retrospective review.

---

# 10. Change Lifecycle

```text
Request
→ Classify
→ Assess
→ Plan
→ Review
→ Approve
→ Schedule
→ Implement
→ Verify
→ Close
→ Review
```

---

# 11. Change Record

Minimum fields:

```text
change_id
title
description
change_type
scope
systems
modules
owner
requester
risk_rating
business_impact
security_impact
data_impact
deployment_plan
test_plan
rollback_plan
maintenance_window
approvers
status
```

---

# 12. Change Status

```text
DRAFT
SUBMITTED
ASSESSMENT
AWAITING_APPROVAL
APPROVED
SCHEDULED
IMPLEMENTING
VERIFYING
COMPLETED
FAILED
ROLLED_BACK
CANCELLED
CLOSED
```

---

# 13. Change Classification Criteria

Assess:

- production impact;
- reversibility;
- security impact;
- data impact;
- compliance impact;
- tenant impact;
- downtime;
- dependency count;
- migration complexity;
- operational complexity.

---

# 14. Risk Rating

```text
LOW
MEDIUM
HIGH
CRITICAL
```

---

# 15. Risk Score Direction

Potential factors:

```text
Likelihood
Impact
Blast Radius
Reversibility
Data Sensitivity
Downtime
Operational Complexity
```

---

# 16. Change Owner

Responsible for:

- complete record;
- stakeholder coordination;
- implementation readiness;
- evidence;
- closure.

---

# 17. Change Implementer

Executes approved procedure.

---

# 18. Change Approver

Verifies:

- scope;
- risk;
- test evidence;
- rollback;
- timing;
- readiness.

---

# 19. Change Verifier

Confirms outcome and independent validation where required.

---

# 20. Change Advisory Board

CAB responsibilities:

- review high-risk changes;
- assess schedule conflict;
- review rollback readiness;
- review outage risk;
- review failed changes;
- approve/reject based on governance.

---

# 21. CAB Membership

Recommended:

```text
Change Manager
Platform Architect
Security Representative
Operations
QA
Database Representative
Module Owner
Business Representative
```

---

# 22. CAB Cadence

Recommended:

- weekly for planned changes;
- ad hoc for high-risk;
- emergency CAB for critical events.

---

# 23. CAB Agenda

```text
Pending Changes
High-Risk Changes
Schedule Conflicts
Rollback Readiness
Security/Data Impact
Open Incidents
Failed Changes
Emergency Changes
Post-Implementation Reviews
```

---

# 24. Approval Matrix

| Change Type | Minimum Approval |
|---|---|
| Standard | Pre-approved catalog |
| Normal | Module Owner + QA/Operations as applicable |
| High Risk | CAB + Architecture/Security/Data as applicable |
| Emergency | Emergency approver + post-review |

---

# 25. Segregation of Duties

Critical changes should avoid:

```text
requester = sole approver = sole implementer = sole verifier
```

---

# 26. Standard Change Catalog

Each standard change must define:

```text
catalog_id
title
scope
procedure
preconditions
rollback
owner
approval
review_due_at
```

---

# 27. Standard Change Review

Standard changes should be reviewed periodically.

If failure rate increases, remove pre-approved status.

---

# 28. Change Freeze

Freeze may apply during:

- financial closing;
- peak periods;
- major events;
- audit windows;
- critical incidents;
- major migration preparation.

---

# 29. Freeze Exception

Requires explicit approval and documented risk.

---

# 30. Maintenance Window

Changes requiring downtime or elevated risk must use approved maintenance window.

---

# 31. Blackout Window

No non-emergency production changes during blackout windows.

---

# 32. Change Dependencies

Record:

- upstream/downstream systems;
- database migrations;
- feature flags;
- infrastructure;
- external vendors;
- scheduled jobs;
- data synchronization.

---

# 33. Change Conflict Detection

Detect:

- same component;
- overlapping maintenance window;
- shared database;
- shared integration;
- same tenant migration;
- conflicting schema changes.

---

# 34. Change Planning

Plan must define:

```text
Pre-Checks
Execution Steps
Validation Steps
Rollback Triggers
Rollback Steps
Communications
Owners
Timings
```

---

# 35. Test Evidence

Minimum evidence:

- unit tests;
- integration tests;
- security tests where applicable;
- tenant isolation tests;
- migration test;
- performance test where applicable;
- UAT;
- artifact verification.

---

# 36. Change Readiness Gate

Checks:

- scope complete;
- owner assigned;
- risk assessed;
- approvals complete;
- tests passed;
- rollback ready;
- backup ready;
- monitoring ready;
- communications ready.

---

# 37. Release Governance

Release is a governed package of approved changes.

---

# 38. Release Record

Minimum fields:

```text
release_id
version
release_type
change_ids
artifact_id
commit_sha
build_id
sbom_id
target_environment
owner
risk_rating
gate_result
approvers
status
```

---

# 39. Release Types

```text
MAJOR
MINOR
PATCH
HOTFIX
EMERGENCY
```

---

# 40. Release Status

```text
DRAFT
ASSEMBLING
VALIDATING
AWAITING_APPROVAL
APPROVED
SCHEDULED
DEPLOYING
VERIFYING
COMPLETED
FAILED
ROLLED_BACK
CANCELLED
```

---

# 41. Release Scope

Release must list all included changes.

Untracked changes are prohibited.

---

# 42. Versioning

Recommended semantic versioning:

```text
MAJOR.MINOR.PATCH
```

---

# 43. Release Candidate

Release candidate must be immutable.

---

# 44. Build Once, Promote Many

The same artifact must move through:

```text
TEST
→ STAGING
→ PRE-PRODUCTION
→ PRODUCTION
```

---

# 45. Artifact Integrity

Release requires:

- checksum;
- signature;
- provenance;
- SBOM;
- release manifest.

---

# 46. Release Manifest

Minimum:

```text
version
commit_sha
build_id
artifact_hash
sbom_hash
included_changes
built_at
gate_result
```

---

# 47. Release Readiness Review

Review:

- included changes;
- unresolved findings;
- test coverage;
- migration;
- rollback;
- deployment window;
- monitoring;
- communication;
- support readiness.

---

# 48. Release Gate

Possible result:

```text
PASS
PASS_WITH_CONDITIONS
FAIL
UNKNOWN
```

---

# 49. Release Blocking Conditions

Block when:

- critical finding open;
- tenant isolation test fails;
- active secret detected;
- artifact signature invalid;
- required evidence missing;
- rollback unavailable;
- approval incomplete;
- expired exception used.

---

# 50. Conditional Approval

Must include:

- conditions;
- owner;
- deadline;
- evidence;
- consequence if unmet.

---

# 51. Environment Promotion

Promotion requires:

- source environment success;
- unchanged artifact;
- valid signature;
- target approval;
- target configuration validation;
- no expired exception.

---

# 52. Promotion Status

```text
REQUESTED
APPROVED
EXECUTING
COMPLETED
FAILED
CANCELLED
EXPIRED
```

---

# 53. Deployment Governance

Deployment is the execution of an approved release to an environment.

---

# 54. Deployment Preconditions

- artifact verified;
- release approved;
- maintenance window valid;
- migration approved;
- backup ready;
- rollback ready;
- health checks ready;
- on-call available.

---

# 55. Deployment Strategies

```text
IN_PLACE
BLUE_GREEN
CANARY
ROLLING
MAINTENANCE_WINDOW
```

---

# 56. Deployment Identity

Use dedicated deployment identity.

---

# 57. Manual Production Change

Manual production changes must be exceptional and documented.

Must record:

- operator;
- command/action;
- reason;
- approver;
- timestamp;
- reconciliation plan.

---

# 58. Configuration Changes

Configuration changes are governed changes.

They require:

- versioning;
- validation;
- approval;
- rollback;
- drift detection.

---

# 59. Feature Flag Changes

Feature flag changes require:

- owner;
- scope;
- environment;
- default;
- expiry;
- rollback;
- audit.

---

# 60. Database Migration Governance

Migration must be:

- versioned;
- reviewed;
- tested;
- backup-aware;
- tenant-safe;
- rollback-aware;
- auditable.

---

# 61. Migration Risk

High-risk migrations include:

- destructive DDL;
- large data rewrite;
- tenant key changes;
- encryption changes;
- index rebuild on large tables;
- irreversible transformation.

---

# 62. Expand-Migrate-Contract

Recommended:

```text
Expand
→ Deploy Compatible Code
→ Migrate Data
→ Verify
→ Contract Later
```

---

# 63. Data Migration

Data migration plan must define:

- source;
- target;
- mapping;
- validation;
- reconciliation;
- rollback;
- retention;
- owner.

---

# 64. Backup Readiness

Critical changes require verified backup and restore path.

---

# 65. Rollback Governance

Rollback must be:

- planned;
- approved;
- tested where feasible;
- artifact-aware;
- data-aware;
- auditable.

---

# 66. Rollback Triggers

Examples:

- health failure;
- authentication failure;
- authorization regression;
- tenant isolation failure;
- migration failure;
- critical error spike;
- data integrity issue;
- severe performance regression.

---

# 67. Rollback Decision

Must consider:

- artifact state;
- schema compatibility;
- data changes;
- vulnerability status of prior release;
- incident severity.

---

# 68. Roll-Forward

Use when rollback is unsafe or impossible.

---

# 69. Rollback Evidence

Record:

```text
trigger
decision
approver
operator
target_release
database_action
result
verification
```

---

# 70. Emergency Change Governance

Emergency change process:

```text
Declare Emergency
→ Minimal Assessment
→ Emergency Approval
→ Implement
→ Verify
→ Stabilize
→ Retrospective Review
```

---

# 71. Emergency Approval

Minimum approval should include:

- incident commander/change authority;
- technical owner;
- security/operations where relevant.

---

# 72. Emergency Change Evidence

Must capture:

- incident reference;
- reason;
- risk;
- action;
- operator;
- approval;
- outcome;
- follow-up.

---

# 73. Emergency Retrospective

Required within defined period.

Recommended:

```text
within 2 business days
```

---

# 74. Emergency Change Review

Assess:

- necessity;
- effectiveness;
- side effects;
- permanent fix;
- temporary bypass removal;
- control improvements.

---

# 75. Unauthorized Change

Unauthorized production change triggers:

- incident;
- access review;
- evidence preservation;
- impact assessment;
- governance escalation.

---

# 76. Failed Change

A failed change must:

- preserve evidence;
- assess impact;
- rollback or stabilize;
- create finding;
- undergo review if material.

---

# 77. Post-Implementation Review

Required for:

- high-risk changes;
- emergency changes;
- failed changes;
- major releases;
- significant incidents.

---

# 78. PIR Content

```text
Expected Outcome
Actual Outcome
Incidents
Rollback
Metrics
User Impact
Lessons
Actions
Owners
Due Dates
```

---

# 79. Change Closure

Close only when:

- implementation complete;
- validation passed;
- monitoring stable;
- evidence attached;
- communication complete;
- follow-up actions tracked.

---

# 80. Release Closure

Release closes when:

- deployment verified;
- no critical unresolved issue;
- release notes published;
- evidence complete;
- support handoff complete.

---

# 81. Change Evidence

Evidence may include:

- approval;
- pull request;
- test report;
- release gate;
- artifact metadata;
- deployment log;
- migration log;
- rollback result;
- monitoring screenshots/logs;
- PIR.

---

# 82. Evidence Integrity

Critical evidence should have:

- checksum;
- immutable storage;
- access audit;
- retention;
- linkage to change/release.

---

# 83. Release Notes

Must include:

- version;
- date;
- changes;
- fixes;
- known issues;
- migration notes;
- rollback notes;
- owner/support contact.

---

# 84. Communication Plan

For impactful changes define:

- audience;
- pre-change notice;
- maintenance message;
- completion notice;
- failure notice;
- support escalation.

---

# 85. Stakeholder Notification

Potential stakeholders:

- business owner;
- module owner;
- operations;
- security;
- support;
- customers/tenants;
- vendors.

---

# 86. Hypercare

Major/high-risk release should define hypercare period.

---

# 87. Hypercare Activities

- monitor errors;
- monitor security events;
- monitor performance;
- review user reports;
- verify scheduled jobs;
- maintain rollback readiness.

---

# 88. Change Calendar

Should show:

- planned changes;
- maintenance windows;
- freezes;
- releases;
- migrations;
- vendor changes;
- emergency changes.

---

# 89. Change Collision Management

Conflicting changes should be rescheduled or coordinated.

---

# 90. Vendor Changes

Vendor-managed changes must:

- be assessed;
- be scheduled;
- have communication;
- include rollback/contingency;
- be monitored.

---

# 91. Dependency Changes

Dependency updates require:

- advisory review;
- compatibility test;
- lockfile update;
- security scan;
- release evidence.

---

# 92. Security Changes

Security-sensitive changes require Security review.

---

# 93. Data Changes

Data-impacting changes require Data Owner review.

---

# 94. Architecture Changes

Architecture-significant changes require ADR.

---

# 95. Compliance Changes

Regulatory or contractual changes require Compliance review.

---

# 96. Audit Trail

Critical actions to audit:

```text
Change Submitted
Risk Changed
Approval Granted
Approval Revoked
Release Approved
Promotion Executed
Deployment Started
Deployment Failed
Rollback Executed
Emergency Change Declared
Change Closed
```

---

# 97. Metrics

```text
change_total
standard_change_total
normal_change_total
high_risk_change_total
emergency_change_total
change_success_rate
failed_change_total
rollback_total
unauthorized_change_total
change_lead_time
approval_lead_time
release_frequency
deployment_frequency
mean_time_to_recover
```

---

# 98. KPIs

Initial targets:

```text
Unauthorized production changes = 0
Critical releases without rollback plan = 0
High-risk changes with complete evidence = 100%
Emergency changes with PIR completed = 100%
Failed change rate trending downward
Artifact integrity validation = 100%
```

---

# 99. KRI

Potential KRIs:

```text
Emergency change ratio
Failed change rate
Rollback rate
Unauthorized change count
Expired approval count
Change collision count
High-risk change without CAB review
```

---

# 100. Dashboard Views

Recommended:

- changes by type;
- changes by status;
- changes by owner;
- failed changes;
- emergency changes;
- approvals overdue;
- releases by environment;
- rollbacks;
- change calendar;
- PIR actions overdue.

---

# 101. Change Quality Score

Potential components:

```text
Risk Assessment Completeness
Test Evidence
Rollback Readiness
Approval Completeness
Deployment Success
Post-Change Stability
```

---

# 102. Automation

Automate where possible:

- classification;
- approval routing;
- calendar conflict checks;
- evidence collection;
- release gate evaluation;
- promotion validation;
- rollback readiness check;
- PIR reminders;
- metrics.

---

# 103. API Direction

Potential endpoints:

```text
/api/internal/v1/change/requests
/api/internal/v1/change/catalog
/api/internal/v1/change/approvals
/api/internal/v1/change/calendar
/api/internal/v1/releases
/api/internal/v1/promotions
/api/internal/v1/deployments
/api/internal/v1/rollbacks
/api/internal/v1/pir
/api/internal/v1/change/dashboard
```

---

# 104. Database Direction

Potential tables:

```text
chg_requests
chg_assessments
chg_approvals
chg_standard_catalog
chg_schedules
chg_dependencies
chg_evidence
rel_releases
rel_release_changes
rel_promotions
rel_deployments
rel_deployment_events
rel_rollbacks
rel_post_implementation_reviews
```

---

# 105. Table: chg_requests

```sql
CREATE TABLE chg_requests (
    id CHAR(26) NOT NULL,
    change_code VARCHAR(80) NOT NULL,
    title VARCHAR(500) NOT NULL,
    description_text LONGTEXT NOT NULL,
    change_type VARCHAR(30) NOT NULL,
    risk_rating VARCHAR(30) NOT NULL,
    owner_reference VARCHAR(180) NOT NULL,
    requester_reference VARCHAR(180) NOT NULL,
    status VARCHAR(30) NOT NULL,
    planned_start_at DATETIME(6) NULL,
    planned_end_at DATETIME(6) NULL,
    maintenance_window_reference VARCHAR(100) NULL,
    deployment_plan_text LONGTEXT NOT NULL,
    test_plan_text LONGTEXT NOT NULL,
    rollback_plan_text LONGTEXT NOT NULL,
    created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    updated_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6)
        ON UPDATE CURRENT_TIMESTAMP(6),

    PRIMARY KEY (id),
    UNIQUE KEY uq_chg_request_code (
        change_code
    ),
    KEY idx_chg_request_status (
        change_type,
        risk_rating,
        status,
        planned_start_at
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

# 106. Table: chg_approvals

```sql
CREATE TABLE chg_approvals (
    id CHAR(26) NOT NULL,
    change_id CHAR(26) NOT NULL,
    approval_type VARCHAR(50) NOT NULL,
    approver_reference VARCHAR(180) NOT NULL,
    decision VARCHAR(30) NOT NULL,
    comments_text LONGTEXT NULL,
    decided_at DATETIME(6) NOT NULL,

    PRIMARY KEY (id),
    UNIQUE KEY uq_chg_approval (
        change_id,
        approval_type,
        approver_reference
    ),
    CONSTRAINT fk_chg_approval_change
        FOREIGN KEY (change_id)
        REFERENCES chg_requests (id)
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

# 107. Table: rel_releases

```sql
CREATE TABLE rel_releases (
    id CHAR(26) NOT NULL,
    release_code VARCHAR(80) NOT NULL,
    version VARCHAR(100) NOT NULL,
    release_type VARCHAR(30) NOT NULL,
    artifact_reference VARCHAR(500) NOT NULL,
    artifact_sha256 CHAR(64) NOT NULL,
    commit_sha CHAR(64) NOT NULL,
    build_reference VARCHAR(100) NOT NULL,
    sbom_reference VARCHAR(500) NULL,
    target_environment VARCHAR(40) NOT NULL,
    owner_reference VARCHAR(180) NOT NULL,
    risk_rating VARCHAR(30) NOT NULL,
    gate_result VARCHAR(30) NULL,
    status VARCHAR(30) NOT NULL,
    scheduled_at DATETIME(6) NULL,
    completed_at DATETIME(6) NULL,

    PRIMARY KEY (id),
    UNIQUE KEY uq_rel_release_code (
        release_code
    ),
    KEY idx_rel_release_status (
        target_environment,
        status,
        scheduled_at
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

# 108. Table: rel_post_implementation_reviews

```sql
CREATE TABLE rel_post_implementation_reviews (
    id CHAR(26) NOT NULL,
    change_id CHAR(26) NULL,
    release_id CHAR(26) NULL,
    review_type VARCHAR(50) NOT NULL,
    expected_outcome_text LONGTEXT NOT NULL,
    actual_outcome_text LONGTEXT NOT NULL,
    lessons_text LONGTEXT NULL,
    actions_text LONGTEXT NULL,
    reviewer_reference VARCHAR(180) NOT NULL,
    status VARCHAR(30) NOT NULL,
    reviewed_at DATETIME(6) NOT NULL,

    PRIMARY KEY (id),
    KEY idx_rel_pir_status (
        status,
        reviewed_at
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

# 109. Event Codes

```text
CHG_REQUEST_CREATED
CHG_CLASSIFIED
CHG_APPROVED
CHG_REJECTED
CHG_SCHEDULED
CHG_IMPLEMENTATION_STARTED
CHG_COMPLETED
CHG_FAILED
CHG_ROLLED_BACK
CHG_EMERGENCY_DECLARED
CHG_UNAUTHORIZED_DETECTED
REL_RELEASE_CREATED
REL_RELEASE_APPROVED
REL_PROMOTION_EXECUTED
REL_DEPLOYMENT_STARTED
REL_DEPLOYMENT_FAILED
REL_ROLLBACK_EXECUTED
REL_PIR_COMPLETED
```

---

# 110. Error Codes

```text
CHG_REQUEST_NOT_FOUND
CHG_CLASSIFICATION_REQUIRED
CHG_APPROVAL_REQUIRED
CHG_RISK_ASSESSMENT_INCOMPLETE
CHG_TEST_EVIDENCE_MISSING
CHG_ROLLBACK_PLAN_MISSING
CHG_MAINTENANCE_WINDOW_INVALID
CHG_FREEZE_ACTIVE
CHG_CONFLICT_DETECTED
REL_RELEASE_NOT_FOUND
REL_ARTIFACT_INVALID
REL_GATE_FAILED
REL_PROMOTION_NOT_ALLOWED
REL_DEPLOYMENT_FAILED
REL_ROLLBACK_NOT_ALLOWED
REL_PIR_REQUIRED
```

---

# 111. Sample Standard Change

```yaml
catalog_id: STD-CHG-001
title: Renew approved TLS certificate
scope: approved production endpoints
preconditions:
  - certificate validated
  - private key stored securely
procedure:
  - install certificate
  - reload web server
  - validate endpoint
rollback:
  - restore previous certificate
owner: platform_operations
status: ACTIVE
```

---

# 112. Sample High-Risk Change

```yaml
change_code: CHG-2026-001
title: Enable tenant-aware repository enforcement
change_type: HIGH_RISK
risk_rating: HIGH
systems:
  - patient_module
  - homecare_module
security_impact: tenant_isolation
test_plan:
  - unit
  - integration
  - tenant_isolation
  - UAT
rollback_plan:
  - deploy previous artifact
  - restore compatible configuration
status: AWAITING_APPROVAL
```

---

# 113. Sample Release

```yaml
release_code: REL-2026-1.8.0
version: 1.8.0
release_type: MINOR
changes:
  - CHG-2026-001
  - CHG-2026-002
artifact_id: ART-901
artifact_sha256: abc123
sbom_id: SBOM-901
target_environment: PRODUCTION
gate_result: PASS
status: APPROVED
```

---

# 114. Sample Emergency Change

```yaml
change_code: CHG-EMG-2026-003
title: Revoke compromised API credential
change_type: EMERGENCY
risk_rating: CRITICAL
incident_reference: INC-2026-014
approval:
  - incident_commander
  - security_lead
rollback_plan: issue replacement credential if service impact occurs
pir_due_at: 2026-07-07
status: IMPLEMENTING
```

---

# 115. Change Request Checklist

- [ ] Scope clear.
- [ ] Owner assigned.
- [ ] Type classified.
- [ ] Risk assessed.
- [ ] Dependencies listed.
- [ ] Tests defined.
- [ ] Rollback defined.
- [ ] Maintenance window valid.
- [ ] Communications defined.
- [ ] Approvals identified.

---

# 116. Release Readiness Checklist

- [ ] All changes approved.
- [ ] Artifact immutable.
- [ ] Checksum valid.
- [ ] Signature valid.
- [ ] SBOM valid.
- [ ] Tests pass.
- [ ] Critical findings = 0.
- [ ] Migration tested.
- [ ] Backup ready.
- [ ] Rollback ready.
- [ ] Monitoring ready.
- [ ] Support ready.

---

# 117. Deployment Checklist

- [ ] Release approval valid.
- [ ] Artifact verified.
- [ ] Target environment ready.
- [ ] Configuration validated.
- [ ] Migration account ready.
- [ ] Backup verified.
- [ ] Maintenance mode plan ready.
- [ ] Health check ready.
- [ ] Security smoke tests ready.
- [ ] Rollback artifact available.

---

# 118. PIR Checklist

- [ ] Outcome compared.
- [ ] User impact assessed.
- [ ] Incidents reviewed.
- [ ] Rollback reviewed.
- [ ] Metrics captured.
- [ ] Lessons documented.
- [ ] Actions assigned.
- [ ] Due dates defined.
- [ ] Temporary bypasses removed.
- [ ] Governance updates considered.

---

# 119. UAT — Change Governance

- [ ] Change types defined.
- [ ] Classification workflow works.
- [ ] Risk rating applied.
- [ ] Change owner required.
- [ ] Approval routing works.
- [ ] Standard catalog works.
- [ ] Freeze/blackout controls work.
- [ ] Conflict detection works.
- [ ] High-risk CAB review works.
- [ ] Unauthorized changes escalate.

---

# 120. UAT — Release Governance

- [ ] Release record exists.
- [ ] Included changes traceable.
- [ ] Semantic versioning defined.
- [ ] Same artifact promoted.
- [ ] Artifact verification works.
- [ ] SBOM linked.
- [ ] Release gate blocks failures.
- [ ] Conditional approval controlled.
- [ ] Promotion history preserved.
- [ ] Release closure requires evidence.

---

# 121. UAT — Deployment & Migration

- [ ] Deployment identity separated.
- [ ] Production approval required.
- [ ] Configuration changes governed.
- [ ] Feature flags audited.
- [ ] Migrations versioned.
- [ ] Destructive migration review required.
- [ ] Backup readiness checked.
- [ ] Health/security validation works.
- [ ] Manual production changes audited.
- [ ] Drift detection works.

---

# 122. UAT — Rollback & Emergency

- [ ] Rollback triggers defined.
- [ ] Previous artifact verified.
- [ ] Data/schema compatibility assessed.
- [ ] Rollback evidence retained.
- [ ] Emergency approval works.
- [ ] Emergency evidence recorded.
- [ ] PIR required.
- [ ] Temporary bypass removal tracked.
- [ ] Rollback to vulnerable release controlled.
- [ ] Failed changes create findings.

---

# 123. UAT — Metrics & Evidence

- [ ] Change metrics defined.
- [ ] Release metrics defined.
- [ ] Failed change visible.
- [ ] Emergency ratio visible.
- [ ] Approval delays visible.
- [ ] PIR actions visible.
- [ ] Evidence linked to change/release.
- [ ] Audit trail complete.
- [ ] Dashboards defined.
- [ ] Automation direction defined.

---

# 124. Definition of Done — SSOT-GOV-06

SSOT-GOV-06 dianggap selesai bila:

- [ ] objectives tersedia;
- [ ] principles tersedia;
- [ ] change types tersedia;
- [ ] change lifecycle tersedia;
- [ ] record/status model tersedia;
- [ ] classification/risk tersedia;
- [ ] owner/roles tersedia;
- [ ] CAB model tersedia;
- [ ] approval matrix tersedia;
- [ ] segregation of duties tersedia;
- [ ] standard change catalog tersedia;
- [ ] freeze/window controls tersedia;
- [ ] dependency/conflict controls tersedia;
- [ ] planning/readiness gates tersedia;
- [ ] release governance tersedia;
- [ ] release types/status/versioning tersedia;
- [ ] immutable artifact model tersedia;
- [ ] release gate tersedia;
- [ ] environment promotion tersedia;
- [ ] deployment governance tersedia;
- [ ] config/feature flag governance tersedia;
- [ ] migration/data migration governance tersedia;
- [ ] backup readiness tersedia;
- [ ] rollback/roll-forward governance tersedia;
- [ ] emergency change governance tersedia;
- [ ] failed/unauthorized change process tersedia;
- [ ] PIR tersedia;
- [ ] evidence/release notes/communication tersedia;
- [ ] hypercare/calendar/vendor changes tersedia;
- [ ] architecture/security/data/compliance review triggers tersedia;
- [ ] audit trail tersedia;
- [ ] metrics/KPI/KRI tersedia;
- [ ] automation direction tersedia;
- [ ] API/database direction tersedia;
- [ ] event/error codes tersedia;
- [ ] samples/checklists tersedia;
- [ ] UAT tersedia.

---

# 125. Implementation Roadmap

## Phase 1 — Change Foundation

- define change types;
- create change register;
- define approval matrix;
- create standard change catalog;
- establish CAB.

## Phase 2 — Release Governance

- create release records;
- integrate artifact/SBOM;
- implement readiness gates;
- define promotion workflow;
- define release calendar.

## Phase 3 — Deployment & Rollback

- integrate deployment evidence;
- enforce production approval;
- govern migrations;
- implement rollback workflow;
- activate PIR.

## Phase 4 — Automation

- approval routing;
- conflict detection;
- calendar integration;
- evidence collection;
- release gate automation;
- dashboards.

## Phase 5 — Optimization

- predictive change risk;
- automated quality scoring;
- canary governance;
- continuous verification;
- policy-as-code release assurance.

---

# 126. Approval Gate

Dokumen dapat menjadi Approved setelah:

- Platform Governance review;
- Change Advisory Board review;
- Release Engineering review;
- Platform Architecture review;
- Security Governance review;
- Data/Database review;
- QA review;
- Operations review;
- Compliance review;
- emergency and rollback process review;
- metrics and evidence review.

---

# 127. Closing Statement

Change dan release governance harus memastikan setiap perubahan:

- memiliki owner;
- memiliki classification;
- memiliki risk;
- memiliki test evidence;
- memiliki approval;
- memiliki release linkage;
- memiliki rollback;
- memiliki verification;
- memiliki audit trail;
- memiliki review setelah failure atau emergency.

Framework ini tidak boleh memperlambat low-risk change secara tidak perlu.

Framework harus mempercepat perubahan yang aman, sambil memblokir perubahan yang tidak siap, tidak teruji, tidak dapat dipulihkan, atau tidak dapat dipertanggungjawabkan.
