# SSOT-GOV-02 — Architecture Decision Records (ADR)

---

## Status Dokumen

| Item | Nilai |
|---|---|
| Kode | SSOT-GOV-02 |
| Judul | Architecture Decision Records (ADR) |
| Versi | 1.0 |
| Status | Draft for Review |
| Domain | Platform Kernel |
| Kategori | Architecture Governance |
| Cakupan | Decision Records, Review, Approval, Supersede, Traceability, Audit |
| Bergantung pada | SSOT-GOV-01 — Governance Framework |
| Target Arsitektur | Modular Monolith, Microservice Ready, Platform Kernel |

---

# 1. Executive Summary

SSOT-GOV-02 menetapkan standar resmi Architecture Decision Records untuk Platform Kernel dan seluruh module bisnis.

ADR digunakan untuk mencatat keputusan arsitektur yang:

- signifikan;
- berdampak lintas module;
- sulit dibalik;
- memiliki risiko;
- mengubah platform standard;
- memengaruhi security, data, integration, deployment, atau operations;
- membutuhkan traceability.

Framework ini menetapkan:

- kapan ADR wajib dibuat;
- siapa yang membuat dan menyetujui;
- format dan numbering;
- lifecycle;
- status;
- repository structure;
- review;
- supersede;
- amendment;
- exception;
- linkage ke SSOT, policy, requirement, release, dan risk;
- audit;
- metrics;
- UAT;
- Definition of Done.

Tujuan akhirnya adalah memastikan keputusan arsitektur:

- tidak hilang;
- tidak bergantung pada ingatan;
- memiliki rationale;
- memiliki owner;
- dapat ditelusuri;
- dapat dievaluasi ulang;
- dapat diaudit;
- dapat diwariskan ke tim berikutnya.

---

# 2. ADR Vision

ADR harus menjadi:

```text
Decision Memory
Architecture Traceability
Governance Evidence
Change Context
Risk Record
Knowledge Transfer
```

ADR bukan dokumentasi desain penuh.

ADR adalah catatan ringkas, normatif, dan authoritative mengenai keputusan penting.

---

# 3. ADR Objectives

ADR framework harus:

- menjelaskan alasan keputusan;
- mencatat opsi yang dipertimbangkan;
- mengurangi decision churn;
- mencegah keputusan berulang;
- mendukung onboarding;
- menjaga konsistensi architecture;
- mendukung audit;
- menghubungkan decision dengan implementation;
- membantu review dan supersede;
- mengelola technical debt.

---

# 4. ADR Principles

```text
One Decision per ADR
Context Before Conclusion
Options Must Be Visible
Consequences Must Be Explicit
Status Must Be Current
Supersede, Do Not Rewrite History
Owner Must Be Named
Evidence Must Be Traceable
Decision Must Be Reviewable
ADR Must Be Accessible
```

---

# 5. ADR Scope

ADR berlaku untuk keputusan:

```text
Platform Architecture
Module Architecture
Security Architecture
Data Architecture
Integration Architecture
Deployment Architecture
Observability Architecture
Infrastructure Architecture
API Architecture
Technology Selection
Migration Strategy
Shared Standards
```

---

# 6. When ADR Is Mandatory

ADR wajib dibuat untuk:

- memilih technology baru;
- mengubah architecture style;
- membuat shared kernel service;
- mengubah tenant isolation model;
- mengubah authentication/authorization model;
- mengubah database strategy;
- mengubah integration pattern;
- membuat cross-domain API;
- mengubah deployment topology;
- mengadopsi external vendor/platform;
- membuat irreversible migration;
- menyetujui major deviation dari standard;
- menerima architecture risk yang signifikan.

---

# 7. When ADR Is Recommended

ADR direkomendasikan untuk:

- internal module pattern;
- caching strategy;
- queue processing model;
- background job architecture;
- file storage architecture;
- reporting architecture;
- search/index architecture;
- observability pattern;
- performance trade-off;
- deprecation strategy.

---

# 8. When ADR Is Not Required

ADR biasanya tidak diperlukan untuk:

- minor implementation detail;
- bug fix tanpa architecture impact;
- CSS/UI adjustment;
- routine dependency patch;
- refactor non-breaking;
- temporary local development setting;
- small test-only change.

---

# 9. ADR Trigger Questions

Buat ADR jika salah satu jawabannya “ya”:

```text
Will this affect more than one module?
Is this difficult or expensive to reverse?
Does this change a platform standard?
Does this introduce a new technology?
Does this affect security or tenant isolation?
Does this affect production operations?
Does this create long-term maintenance cost?
Will future engineers ask why this was chosen?
```

---

# 10. ADR Decision Levels

```text
LEVEL 1 — Module Decision
LEVEL 2 — Platform Decision
LEVEL 3 — Cross-Domain Decision
LEVEL 4 — Critical/Enterprise Decision
```

---

# 11. Level 1 — Module Decision

Examples:

- module-internal pattern;
- module repository structure;
- module cache strategy.

Approval:

- module owner;
- engineering lead.

---

# 12. Level 2 — Platform Decision

Examples:

- shared interface;
- common library;
- platform service;
- shared error model.

Approval:

- platform architect;
- relevant owner.

---

# 13. Level 3 — Cross-Domain Decision

Examples:

- shared data model;
- integration protocol;
- platform authentication pattern;
- enterprise logging format.

Approval:

- Architecture Review Board;
- domain owners;
- security/data reviewers as applicable.

---

# 14. Level 4 — Critical Decision

Examples:

- architecture style change;
- tenant isolation model change;
- cryptography model;
- external cloud/provider dependency;
- production topology overhaul.

Approval:

- Platform Governance Board;
- Architecture Review Board;
- Security/Compliance;
- Executive Sponsor where required.

---

# 15. ADR Roles

```text
Author
Proposer
Decision Owner
Reviewer
Approver
Implementer
Verifier
Custodian
```

---

# 16. Author

Responsible for writing ADR accurately.

---

# 17. Proposer

Introduces the architecture decision.

Author and proposer may be the same person.

---

# 18. Decision Owner

Accountable for:

- decision quality;
- stakeholder engagement;
- implementation alignment;
- review cadence;
- supersede decision.

---

# 19. Reviewer

Evaluates:

- context;
- options;
- risks;
- consequences;
- alignment;
- completeness.

---

# 20. Approver

Authorized to accept/reject the ADR.

---

# 21. Implementer

Executes the accepted decision.

---

# 22. Verifier

Confirms implementation matches ADR.

---

# 23. ADR Custodian

Maintains:

- numbering;
- repository;
- index;
- status consistency;
- metadata quality;
- archival integrity.

---

# 24. RACI Example

| Activity | Author | Decision Owner | Architect | Security/Data | Governance | Implementer |
|---|---|---|---|---|---|---|
| Draft ADR | R | A | C | C | I | I |
| Review | C | A | R | C | I | I |
| Approve | I | C | A | C | C | I |
| Implement | I | A | C | I | I | R |
| Verify | I | A | R | C | I | C |
| Supersede | R | A | R | C | C | I |

---

# 25. ADR Status Model

```text
DRAFT
PROPOSED
IN_REVIEW
ACCEPTED
REJECTED
SUPERSEDED
DEPRECATED
RETIRED
```

---

# 26. DRAFT

ADR sedang ditulis.

Tidak normatif.

---

# 27. PROPOSED

ADR siap direview.

Belum boleh dianggap keputusan final.

---

# 28. IN_REVIEW

ADR sedang dinilai oleh reviewer dan approver.

---

# 29. ACCEPTED

ADR resmi dan normatif.

Implementation harus mengikuti ADR.

---

# 30. REJECTED

Keputusan tidak diterima.

ADR tetap dipertahankan sebagai history.

---

# 31. SUPERSEDED

ADR digantikan oleh ADR baru.

Original ADR tidak dihapus.

---

# 32. DEPRECATED

ADR masih tercatat tetapi tidak lagi direkomendasikan.

Biasanya dalam transition period.

---

# 33. RETIRED

ADR tidak lagi berlaku karena system/feature sudah dihentikan.

---

# 34. ADR State Transition

```text
DRAFT
→ PROPOSED
→ IN_REVIEW
→ ACCEPTED
   ├── SUPERSEDED
   ├── DEPRECATED
   └── RETIRED

PROPOSED/IN_REVIEW
→ REJECTED
```

---

# 35. ADR Numbering

Format:

```text
ADR-XXXX
```

Contoh:

```text
ADR-0001
ADR-0002
ADR-0003
```

---

# 36. Domain-Prefixed Numbering

Optional:

```text
ADR-PLT-0001
ADR-SEC-0001
ADR-DATA-0001
ADR-OBS-0001
ADR-APP-0001
```

Recommended final standard:

```text
ADR-XXXX
```

Gunakan metadata domain untuk filtering.

---

# 37. ADR Filename

Format:

```text
ADR-0001-short-kebab-title.md
```

Contoh:

```text
ADR-0001-modular-monolith.md
ADR-0002-platform-kernel-boundary.md
ADR-0003-tenant-isolation-model.md
```

---

# 38. ADR Repository Structure

Recommended:

```text
docs/
└── architecture/
    ├── adr/
    │   ├── ADR-0001-modular-monolith.md
    │   ├── ADR-0002-platform-kernel-boundary.md
    │   ├── ADR-0003-tenant-isolation-model.md
    │   └── README.md
    ├── diagrams/
    ├── standards/
    └── reviews/
```

---

# 39. ADR Index

`docs/architecture/adr/README.md` should contain:

```text
ADR ID
Title
Status
Domain
Owner
Accepted Date
Superseded By
```

---

# 40. ADR Metadata

Every ADR must include:

```yaml
adr_id: ADR-0001
title: Adopt Modular Monolith Architecture
status: ACCEPTED
decision_level: LEVEL_3
domain: PLATFORM
owner: platform_architecture
authors:
  - backend_lead
reviewers:
  - security_architecture
  - database_architecture
approvers:
  - architecture_review_board
created_at: 2026-07-05
accepted_at: 2026-07-12
review_due_at: 2027-07-12
supersedes: null
superseded_by: null
related_ssot:
  - SSOT-GOV-01
```

---

# 41. ADR Mandatory Sections

```text
Title
Status
Context
Decision
Decision Drivers
Considered Options
Consequences
Risks
Implementation Notes
Verification
References
```

---

# 42. ADR Optional Sections

```text
Assumptions
Constraints
Out of Scope
Migration Plan
Rollback Plan
Security Impact
Data Impact
Operational Impact
Cost Impact
Compliance Impact
Open Questions
```

---

# 43. ADR Template

```markdown
# ADR-XXXX — Title

## Metadata

| Item | Value |
|---|---|
| Status | PROPOSED |
| Decision Level | LEVEL_2 |
| Domain | PLATFORM |
| Owner | ... |
| Authors | ... |
| Reviewers | ... |
| Approvers | ... |
| Created At | YYYY-MM-DD |
| Review Due At | YYYY-MM-DD |
| Supersedes | None |
| Superseded By | None |

## Context

Describe the problem, constraints, and why a decision is needed.

## Decision Drivers

- ...
- ...
- ...

## Considered Options

### Option A

Description.

### Option B

Description.

### Option C

Description.

## Decision

State the decision clearly.

## Consequences

### Positive

- ...

### Negative

- ...

### Neutral/Trade-offs

- ...

## Risks

| Risk | Likelihood | Impact | Treatment |
|---|---|---|---|
| ... | ... | ... | ... |

## Implementation Notes

- ...

## Verification

- test;
- architecture review;
- migration evidence;
- production validation.

## References

- SSOT;
- diagrams;
- tickets;
- pull requests;
- external references.
```

---

# 44. Context Section

Context must explain:

- existing state;
- problem;
- constraint;
- urgency;
- stakeholders;
- consequences of no decision.

---

# 45. Decision Drivers

Examples:

```text
Security
Scalability
Maintainability
Time to Market
Operational Complexity
Cost
Compliance
Team Capability
Reversibility
Vendor Lock-In
```

---

# 46. Considered Options

At minimum include:

- selected option;
- one or more realistic alternatives;
- do-nothing option where relevant.

---

# 47. Option Evaluation

Recommended table:

| Criterion | Weight | Option A | Option B | Option C |
|---|---:|---:|---:|---:|
| Security | 5 | 5 | 4 | 2 |
| Complexity | 3 | 4 | 2 | 5 |
| Cost | 2 | 4 | 3 | 5 |

Scoring is supporting evidence, not a substitute for judgment.

---

# 48. Decision Statement

Decision must be:

- explicit;
- concise;
- testable;
- unambiguous.

Bad:

```text
We may use queues.
```

Good:

```text
The platform will use a database-backed outbox pattern for reliable domain event publication.
```

---

# 49. Consequences

Every ADR must list:

- positive consequences;
- negative consequences;
- trade-offs;
- operational impact;
- migration impact where applicable.

---

# 50. Risks

Risks should link to:

- risk register;
- control;
- mitigation;
- owner;
- review date.

---

# 51. Assumptions

Assumptions must be explicit.

If an assumption becomes invalid, ADR may require review.

---

# 52. Constraints

Examples:

- PHP 8.1+;
- MySQL/MariaDB;
- XAMPP local environment;
- limited DevOps maturity;
- existing legacy schema;
- regulatory constraints.

---

# 53. Out of Scope

Out-of-scope section prevents future misinterpretation.

---

# 54. Security Impact

Security review required if ADR affects:

- identity;
- authentication;
- authorization;
- tenant isolation;
- cryptography;
- secrets;
- logging/audit;
- file handling;
- external integrations.

---

# 55. Data Impact

Data review required if ADR affects:

- schema;
- ownership;
- classification;
- retention;
- migration;
- lineage;
- replication;
- export.

---

# 56. Operational Impact

Operational review required if ADR affects:

- deployment;
- rollback;
- observability;
- support;
- SLO;
- backup;
- recovery;
- capacity.

---

# 57. Compliance Impact

Compliance review required if ADR affects:

- regulated data;
- privacy;
- auditability;
- legal retention;
- external commitments.

---

# 58. ADR Review Workflow

```text
Draft
→ Self-Check
→ Stakeholder Review
→ Architecture Review
→ Security/Data Review if Needed
→ Approval
→ Publish
→ Implement
→ Verify
```

---

# 59. ADR Self-Check

Before review:

- [ ] problem is clear;
- [ ] decision is singular;
- [ ] options are real;
- [ ] consequences are honest;
- [ ] owner exists;
- [ ] references exist;
- [ ] implementation path exists.

---

# 60. Review SLA

Recommended:

| Decision Level | Review Target |
|---|---:|
| Level 1 | 3 business days |
| Level 2 | 5 business days |
| Level 3 | 10 business days |
| Level 4 | 15 business days |

---

# 61. Approval Requirements

| Decision Level | Minimum Approval |
|---|---|
| Level 1 | Module Owner |
| Level 2 | Platform Architect |
| Level 3 | Architecture Review Board |
| Level 4 | Governance Board + Required Domain Owners |

---

# 62. Review Comments

Review comments should be resolved as:

```text
ACCEPTED
REJECTED_WITH_REASON
DEFERRED
OUT_OF_SCOPE
```

---

# 63. Consensus

Consensus is preferred but not mandatory.

Decision owner/approver remains accountable.

---

# 64. Dissent

Material dissent should be documented in ADR.

---

# 65. Time-Boxing Decisions

If decision is urgent:

- define decision deadline;
- record known uncertainty;
- set review date;
- define temporary status;
- avoid informal undocumented decision.

---

# 66. Provisional ADR

Optional status extension:

```text
ACCEPTED_WITH_REVIEW
```

Use only if governance approves.

Must have explicit expiry/review date.

---

# 67. ADR Publication

Accepted ADR must be:

- committed to repository;
- indexed;
- linked to relevant SSOT;
- linked to implementation issue/PR;
- announced to affected teams.

---

# 68. ADR Immutability

Accepted ADR history must not be rewritten to hide original rationale.

Minor typo corrections are allowed.

Material changes require amendment or new ADR.

---

# 69. ADR Amendment

Use amendment when:

- clarification needed;
- implementation detail added;
- decision outcome unchanged.

Record amendment history.

---

# 70. Superseding ADR

Create new ADR when:

- decision changes;
- assumptions invalid;
- architecture evolves;
- better option selected;
- major constraint changes.

---

# 71. Supersede Process

```text
Create New ADR
→ Reference Old ADR
→ Explain Reason
→ Approve New ADR
→ Mark Old ADR SUPERSEDED
→ Update Index
```

---

# 72. Rejected ADR

Rejected ADR remains valuable because it records:

- context;
- options;
- rationale;
- rejected direction.

---

# 73. Deprecated ADR

Use when:

- decision still exists temporarily;
- no longer recommended;
- migration away is planned.

---

# 74. Retired ADR

Use when:

- system removed;
- feature retired;
- decision no longer applicable.

---

# 75. ADR Linkage

ADR should link to:

```text
SSOT
Policy
Standard
Requirement
Risk
Exception
Epic/Story
Pull Request
Release
Diagram
Test Evidence
```

---

# 76. ADR Traceability Matrix

| ADR | SSOT | Requirement | Implementation | Test | Release |
|---|---|---|---|---|---|
| ADR-0003 | SSOT-SEC-01 | REQ-TENANT-001 | PR-821 | TEST-TENANT-01 | REL-1.4 |

---

# 77. ADR and SSOT

ADR explains why.

SSOT defines what is authoritative now.

---

# 78. ADR and Policy

ADR may create or change policy direction.

Policy remains the normative control.

---

# 79. ADR and Standards

Standards translate accepted ADRs into implementation rules.

---

# 80. ADR and Technical Debt

Accepted compromise should create technical debt record if applicable.

---

# 81. ADR and Risk Register

High/critical residual risk must be linked to risk register.

---

# 82. ADR and Exception

Temporary deviation from accepted ADR requires exception.

---

# 83. ADR Exception Record

Minimum:

```text
exception_id
adr_id
scope
reason
risk
compensating_control
owner
expires_at
approval
```

---

# 84. ADR Compliance Check

Architecture review should verify implementation against accepted ADRs.

---

# 85. Implementation Verification

Accepted ADR must define verification method.

Examples:

- code review;
- architecture test;
- tenant isolation test;
- schema inspection;
- deployment evidence;
- security test.

---

# 86. Architecture Fitness Functions

Where possible, automate ADR compliance.

Examples:

```text
No module may directly query another module's private tables.
All tenant-aware tables must contain tenant_id.
Public API responses must use canonical envelope.
```

---

# 87. ADR Enforcement Levels

```text
DOCUMENTED
REVIEWED
TESTED
AUTOMATED
ENFORCED
```

---

# 88. ADR Repository Governance

Repository must:

- restrict destructive history rewrite;
- require review;
- preserve authorship;
- support search;
- maintain index;
- maintain status.

---

# 89. ADR Pull Request

ADR changes should use dedicated pull request or clearly isolated commit.

---

# 90. ADR Branching

Recommended:

```text
docs/adr-0007-new-event-model
```

---

# 91. ADR Review Checklist

- [ ] ID unique.
- [ ] Title specific.
- [ ] Context clear.
- [ ] Decision drivers listed.
- [ ] Alternatives evaluated.
- [ ] Decision explicit.
- [ ] Consequences balanced.
- [ ] Risks captured.
- [ ] Owner assigned.
- [ ] Verification defined.
- [ ] Links complete.
- [ ] Approval level correct.

---

# 92. ADR Quality Criteria

Good ADR is:

- concise;
- contextual;
- honest;
- current;
- traceable;
- actionable;
- reviewable.

---

# 93. ADR Anti-Pattern

Avoid:

- recording only the selected option;
- hiding negative consequences;
- combining many unrelated decisions;
- rewriting accepted history;
- ownerless ADR;
- no implementation link;
- no review date for provisional decision;
- using ADR as design specification;
- creating ADR after implementation solely for paperwork;
- never superseding outdated ADR.

---

# 94. ADR Naming Anti-Pattern

Bad:

```text
ADR-0010-new-thing.md
ADR-0011-improvements.md
ADR-0012-tech-choice.md
```

Good:

```text
ADR-0010-use-outbox-for-domain-events.md
ADR-0011-separate-platform-kernel-from-module-sdk.md
ADR-0012-use-ulid-for-public-identifiers.md
```

---

# 95. ADR Review Cadence

Review accepted ADR:

- annually;
- when assumptions change;
- after major incident;
- before architecture migration;
- when linked technology becomes unsupported.

---

# 96. ADR Review Outcome

```text
RETAIN
AMEND
DEPRECATE
SUPERSEDE
RETIRE
```

---

# 97. ADR Review Record

Minimum:

```text
adr_id
review_date
reviewer
outcome
rationale
actions
next_review
```

---

# 98. ADR Metrics

```text
adr_total
adr_by_status
adr_review_overdue_total
adr_without_owner_total
adr_without_implementation_link_total
adr_superseded_total
adr_decision_lead_time
adr_rework_total
adr_compliance_gap_total
```

---

# 99. ADR KPIs

Initial targets:

```text
Accepted ADR without owner = 0
Accepted ADR without implementation link = 0
Critical ADR review overdue = 0
ADR index completeness = 100%
High-risk architecture change with ADR = 100%
```

---

# 100. ADR Dashboard

Recommended views:

- by status;
- by domain;
- by owner;
- by age;
- by decision level;
- by review due;
- by supersede chain;
- by compliance status.

---

# 101. ADR Search Tags

Recommended metadata tags:

```text
platform
security
data
integration
deployment
observability
tenant
api
database
legacy
migration
```

---

# 102. ADR Automation

Automate:

- ID allocation;
- metadata validation;
- index generation;
- broken link checking;
- review reminders;
- supersede link validation;
- missing owner detection.

---

# 103. ADR Linter

Linter should validate:

- filename;
- ID;
- mandatory sections;
- valid status;
- owner;
- dates;
- references;
- supersede consistency.

---

# 104. ADR CI Gate

Pull request should fail if:

- duplicate ADR ID;
- invalid status;
- missing mandatory section;
- broken supersede reference;
- invalid metadata;
- accepted ADR changed materially without amendment.

---

# 105. ADR API Direction

Potential endpoints:

```text
GET  /api/internal/v1/governance/adrs
GET  /api/internal/v1/governance/adrs/{adrId}
POST /api/internal/v1/governance/adrs
POST /api/internal/v1/governance/adrs/{adrId}/submit
POST /api/internal/v1/governance/adrs/{adrId}/approve
POST /api/internal/v1/governance/adrs/{adrId}/reject
POST /api/internal/v1/governance/adrs/{adrId}/supersede
POST /api/internal/v1/governance/adrs/{adrId}/review
```

---

# 106. ADR Database Direction

Potential tables:

```text
gov_adrs
gov_adr_versions
gov_adr_options
gov_adr_reviews
gov_adr_approvals
gov_adr_links
gov_adr_compliance_checks
```

---

# 107. Table: gov_adrs

```sql
CREATE TABLE gov_adrs (
    id CHAR(26) NOT NULL,
    adr_code VARCHAR(30) NOT NULL,
    title VARCHAR(500) NOT NULL,
    status VARCHAR(30) NOT NULL,
    decision_level VARCHAR(30) NOT NULL,
    domain VARCHAR(80) NOT NULL,
    owner_reference VARCHAR(180) NOT NULL,
    context_text LONGTEXT NOT NULL,
    decision_text LONGTEXT NOT NULL,
    consequences_text LONGTEXT NOT NULL,
    created_at DATETIME(6) NOT NULL,
    accepted_at DATETIME(6) NULL,
    review_due_at DATETIME(6) NULL,
    supersedes_adr_code VARCHAR(30) NULL,
    superseded_by_adr_code VARCHAR(30) NULL,

    PRIMARY KEY (id),
    UNIQUE KEY uq_gov_adr_code (adr_code),
    KEY idx_gov_adr_status (
        status,
        review_due_at
    ),
    KEY idx_gov_adr_domain (
        domain,
        status
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

# 108. Table: gov_adr_options

```sql
CREATE TABLE gov_adr_options (
    id CHAR(26) NOT NULL,
    adr_id CHAR(26) NOT NULL,
    option_code VARCHAR(50) NOT NULL,
    title VARCHAR(500) NOT NULL,
    description_text LONGTEXT NOT NULL,
    pros_text LONGTEXT NULL,
    cons_text LONGTEXT NULL,
    score DECIMAL(8,2) NULL,
    selected_flag TINYINT(1) NOT NULL DEFAULT 0,

    PRIMARY KEY (id),
    UNIQUE KEY uq_gov_adr_option (
        adr_id,
        option_code
    ),
    CONSTRAINT fk_gov_adr_option_adr
        FOREIGN KEY (adr_id)
        REFERENCES gov_adrs (id)
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

# 109. Table: gov_adr_reviews

```sql
CREATE TABLE gov_adr_reviews (
    id CHAR(26) NOT NULL,
    adr_id CHAR(26) NOT NULL,
    reviewer_reference VARCHAR(180) NOT NULL,
    review_type VARCHAR(50) NOT NULL,
    outcome VARCHAR(30) NOT NULL,
    comments_text LONGTEXT NULL,
    reviewed_at DATETIME(6) NOT NULL,

    PRIMARY KEY (id),
    KEY idx_gov_adr_review (
        adr_id,
        reviewed_at
    ),
    CONSTRAINT fk_gov_adr_review_adr
        FOREIGN KEY (adr_id)
        REFERENCES gov_adrs (id)
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

# 110. Table: gov_adr_links

```sql
CREATE TABLE gov_adr_links (
    id CHAR(26) NOT NULL,
    adr_id CHAR(26) NOT NULL,
    link_type VARCHAR(50) NOT NULL,
    reference_code VARCHAR(255) NOT NULL,
    reference_uri VARCHAR(1000) NULL,

    PRIMARY KEY (id),
    UNIQUE KEY uq_gov_adr_link (
        adr_id,
        link_type,
        reference_code
    ),
    CONSTRAINT fk_gov_adr_link_adr
        FOREIGN KEY (adr_id)
        REFERENCES gov_adrs (id)
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

# 111. ADR Event Codes

```text
GOV_ADR_CREATED
GOV_ADR_SUBMITTED
GOV_ADR_REVIEWED
GOV_ADR_ACCEPTED
GOV_ADR_REJECTED
GOV_ADR_AMENDED
GOV_ADR_DEPRECATED
GOV_ADR_SUPERSEDED
GOV_ADR_RETIRED
GOV_ADR_REVIEW_OVERDUE
```

---

# 112. ADR Error Codes

```text
GOV_ADR_NOT_FOUND
GOV_ADR_ID_DUPLICATE
GOV_ADR_STATUS_INVALID
GOV_ADR_OWNER_REQUIRED
GOV_ADR_APPROVAL_REQUIRED
GOV_ADR_MANDATORY_SECTION_MISSING
GOV_ADR_SUPERSEDE_REFERENCE_INVALID
GOV_ADR_REVIEW_OVERDUE
GOV_ADR_MATERIAL_CHANGE_NOT_ALLOWED
```

---

# 113. Sample ADR-0001

```markdown
# ADR-0001 — Adopt Modular Monolith Architecture

## Metadata

| Item | Value |
|---|---|
| Status | ACCEPTED |
| Decision Level | LEVEL_3 |
| Domain | PLATFORM |
| Owner | Platform Architecture |
| Created At | 2026-07-05 |
| Review Due At | 2027-07-05 |

## Context

The platform requires rapid delivery, shared governance, and future migration readiness without the operational cost of microservices at the current maturity level.

## Decision Drivers

- delivery speed;
- transaction consistency;
- lower operational complexity;
- module boundaries;
- future extraction capability.

## Considered Options

### Option A — Modular Monolith

Shared deployment with enforced module boundaries.

### Option B — Microservices

Independent services and deployments.

### Option C — Traditional Monolith

Single codebase without strict module boundaries.

## Decision

The platform will use a Modular Monolith architecture with strict module boundaries, a separate Platform Kernel, module SDK contracts, and microservice-ready integration patterns.

## Consequences

### Positive

- lower operational complexity;
- easier local development;
- consistent transactions;
- gradual extraction path.

### Negative

- requires boundary discipline;
- shared deployment;
- risk of hidden coupling.

## Verification

- architecture tests;
- dependency rules;
- module boundary review;
- no direct private table access across modules.
```

---

# 114. Sample ADR-0002

```markdown
# ADR-0002 — Separate Platform Kernel from Module SDK

## Context

Business modules require shared capabilities without depending directly on kernel internals.

## Decision

The Platform Kernel will expose stable contracts through a Module SDK. Business modules may depend on the SDK but not on kernel implementation classes.

## Consequences

- clearer boundaries;
- easier kernel replacement;
- increased contract maintenance;
- need for compatibility testing.
```

---

# 115. Sample ADR-0003

```markdown
# ADR-0003 — Enforce Tenant and Clinic Scope in Repository Queries

## Context

Client-supplied tenant and clinic identifiers cannot be trusted, and cross-tenant data exposure is unacceptable.

## Decision

All tenant-aware repository operations will require a trusted server-side TenantScope object and include tenant/clinic predicates in queries.

## Consequences

- stronger isolation;
- more explicit repository contracts;
- migration work for legacy repositories;
- mandatory tenant isolation tests.
```

---

# 116. Sample ADR-0004

```markdown
# ADR-0004 — Use ULID for Public Identifiers

## Context

Sequential numeric identifiers increase enumeration risk and are difficult to generate outside the database.

## Decision

New externally exposed entities will use ULID identifiers. Existing numeric IDs may remain internally during migration.

## Consequences

- opaque identifiers;
- sortable IDs;
- larger indexes;
- dual-ID migration complexity.
```

---

# 117. Sample ADR-0005

```markdown
# ADR-0005 — Use Outbox Pattern for Reliable Domain Events

## Context

Database state changes and event publication must remain consistent.

## Decision

The platform will write domain events to an outbox table within the same database transaction and publish asynchronously.

## Consequences

- reliable publication;
- eventual consistency;
- outbox cleanup and monitoring required;
- consumers must be idempotent.
```

---

# 118. ADR Implementation Workflow

```text
Accepted ADR
→ Create Implementation Epic
→ Break into Tasks
→ Add Architecture Tests
→ Implement
→ Verify
→ Link Release
→ Mark Compliance
```

---

# 119. ADR Compliance Status

```text
NOT_STARTED
IN_PROGRESS
COMPLIANT
PARTIALLY_COMPLIANT
NON_COMPLIANT
EXCEPTION_ACTIVE
```

---

# 120. ADR Compliance Record

Minimum:

```text
adr_id
system_or_module
status
evidence
owner
checked_at
next_check
```

---

# 121. ADR Drift

Architecture drift occurs when implementation no longer matches accepted ADR.

---

# 122. Drift Response

```text
Detect
→ Assess
→ Fix
→ Create Exception
→ Amend/Supersede ADR
→ Verify
```

---

# 123. ADR Review Meeting

Recommended agenda:

```text
Context
Decision Drivers
Options
Risk
Security/Data Impact
Consequences
Implementation
Verification
Approval
```

---

# 124. ADR Decision Log

Decision log may include:

| Date | ADR | Decision | Owner | Status |
|---|---|---|---|---|
| 2026-07-05 | ADR-0001 | Adopt Modular Monolith | Platform Architecture | ACCEPTED |

---

# 125. ADR Training

Relevant roles should understand:

- when ADR is required;
- how to write context;
- how to evaluate options;
- how to document consequences;
- how to supersede;
- how to link implementation.

---

# 126. ADR Onboarding

New engineers should review:

- active platform ADRs;
- security ADRs;
- data ADRs;
- supersede chains;
- module-specific ADRs.

---

# 127. ADR Retention

ADR history should be retained for the platform lifetime plus governance retention period.

---

# 128. ADR Backup

ADR repository should be backed up with source control and documentation backup.

---

# 129. ADR Access

Read access should be broad internally.

Write/approve access should be controlled.

---

# 130. ADR Confidentiality

ADR containing sensitive security details may use restricted classification while preserving a public/internal summary.

---

# 131. ADR and Vendor Decisions

Vendor ADR should document:

- lock-in;
- data access;
- security;
- cost;
- exit plan;
- SLA;
- substitution options.

---

# 132. ADR and Open Source

Open-source adoption ADR should document:

- license;
- maintenance;
- security history;
- community;
- transitive dependencies;
- replacement path.

---

# 133. ADR and Database Changes

Database ADR should document:

- schema impact;
- migration;
- rollback;
- data retention;
- indexes;
- operational risk.

---

# 134. ADR and API Changes

API ADR should document:

- versioning;
- compatibility;
- authentication;
- authorization;
- error model;
- deprecation.

---

# 135. ADR and Security Decisions

Security ADR must be reviewed by Security Architecture.

---

# 136. ADR and Data Decisions

Data ADR must be reviewed by Data Owner/Data Architecture.

---

# 137. ADR and Operations

Operational ADR must include:

- observability;
- support;
- recovery;
- deployment;
- capacity;
- ownership.

---

# 138. UAT — ADR Framework

## Governance

- [ ] ADR scope defined.
- [ ] Mandatory triggers defined.
- [ ] Decision levels defined.
- [ ] Roles defined.
- [ ] RACI available.
- [ ] Approval requirements defined.

## Lifecycle

- [ ] Status model defined.
- [ ] State transitions defined.
- [ ] Rejected ADR retained.
- [ ] Supersede process works.
- [ ] Deprecated/retired states work.
- [ ] Review cadence defined.

## Repository

- [ ] Numbering unique.
- [ ] Filename standard enforced.
- [ ] Repository structure exists.
- [ ] ADR index exists.
- [ ] Metadata standard exists.
- [ ] Search tags available.

## Content Quality

- [ ] Context required.
- [ ] Decision drivers required.
- [ ] Alternatives required.
- [ ] Decision explicit.
- [ ] Consequences balanced.
- [ ] Risks captured.
- [ ] Verification defined.
- [ ] References complete.

## Review & Approval

- [ ] Review SLA defined.
- [ ] Required reviewers applied.
- [ ] Security/data reviewers triggered.
- [ ] Critical self-approval restricted.
- [ ] Dissent recorded.
- [ ] Decision history preserved.

## Traceability

- [ ] ADR links to SSOT.
- [ ] ADR links to implementation.
- [ ] ADR links to tests.
- [ ] ADR links to release.
- [ ] ADR links to risks/exceptions.
- [ ] Compliance status available.

## Automation

- [ ] ADR linter works.
- [ ] Duplicate IDs blocked.
- [ ] Missing sections blocked.
- [ ] Broken supersede links blocked.
- [ ] Index can be generated.
- [ ] Review reminders work.

## Metrics

- [ ] ADR metrics defined.
- [ ] Overdue reviews visible.
- [ ] Missing owners visible.
- [ ] Compliance gaps visible.
- [ ] Dashboard requirements defined.

---

# 139. Definition of Done — SSOT-GOV-02

SSOT-GOV-02 dianggap selesai bila:

- [ ] ADR vision tersedia;
- [ ] objectives tersedia;
- [ ] principles tersedia;
- [ ] scope tersedia;
- [ ] mandatory triggers tersedia;
- [ ] decision levels tersedia;
- [ ] roles tersedia;
- [ ] RACI tersedia;
- [ ] status model tersedia;
- [ ] state transitions tersedia;
- [ ] numbering tersedia;
- [ ] filename standard tersedia;
- [ ] repository structure tersedia;
- [ ] index standard tersedia;
- [ ] metadata tersedia;
- [ ] mandatory sections tersedia;
- [ ] template tersedia;
- [ ] option evaluation tersedia;
- [ ] review workflow tersedia;
- [ ] approval requirements tersedia;
- [ ] amendment rules tersedia;
- [ ] supersede rules tersedia;
- [ ] linkage model tersedia;
- [ ] implementation verification tersedia;
- [ ] fitness function direction tersedia;
- [ ] linter/CI gate direction tersedia;
- [ ] API direction tersedia;
- [ ] database direction tersedia;
- [ ] event/error codes tersedia;
- [ ] sample ADRs tersedia;
- [ ] compliance/drift model tersedia;
- [ ] metrics/KPI tersedia;
- [ ] UAT tersedia.

---

# 140. Implementation Roadmap

## Phase 1 — Repository Foundation

- create ADR directory;
- create template;
- create index;
- define numbering;
- assign custodian.

## Phase 2 — Governance Adoption

- classify active architecture decisions;
- create baseline ADRs;
- define reviewers;
- add approval workflow;
- link SSOT.

## Phase 3 — Automation

- implement ADR linter;
- auto-generate index;
- review reminders;
- metadata validation;
- broken link checks.

## Phase 4 — Compliance

- architecture fitness functions;
- compliance checks;
- drift detection;
- dashboards;
- exception integration.

## Phase 5 — Optimization

- decision analytics;
- lead-time reduction;
- recurring decision pattern library;
- searchable decision knowledge base;
- AI-assisted ADR drafting with human approval.

---

# 141. Initial ADR Backlog

Recommended first ADRs:

```text
ADR-0001 — Adopt Modular Monolith Architecture
ADR-0002 — Separate Platform Kernel from Module SDK
ADR-0003 — Enforce Tenant and Clinic Scope in Repository Queries
ADR-0004 — Use ULID for Public Identifiers
ADR-0005 — Use Outbox Pattern for Reliable Domain Events
ADR-0006 — Use RBAC with Scoped Role Assignments
ADR-0007 — Use Server-Side Sessions for Browser Authentication
ADR-0008 — Store Restricted Files Outside Public Root
ADR-0009 — Use Policy-as-Code for Critical Security Gates
ADR-0010 — Build Once and Promote Immutable Artifacts
```

---

# 142. Approval Gate

Dokumen dapat menjadi Approved setelah:

- Platform Governance review;
- Architecture Review Board review;
- Security Architecture review;
- Data Architecture review;
- Delivery/Operations review;
- ADR repository and template review;
- numbering and lifecycle review;
- traceability review;
- automation/linter direction review;
- initial ADR backlog approval.

---

# 143. Closing Statement

Architecture Decision Records harus memastikan setiap keputusan arsitektur penting:

- memiliki context;
- memiliki rationale;
- memiliki owner;
- memiliki options;
- memiliki consequences;
- memiliki approval;
- memiliki implementation link;
- memiliki verification;
- dapat disupersede;
- dapat diaudit.

ADR tidak boleh menjadi formalitas.

ADR harus menjadi memori arsitektur yang membantu platform berkembang secara konsisten tanpa kehilangan alasan di balik keputusan penting.
