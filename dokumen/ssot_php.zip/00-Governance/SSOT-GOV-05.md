# SSOT-GOV-05 — Compliance & Audit Governance

---

## Status Dokumen

| Item | Nilai |
|---|---|
| Kode | SSOT-GOV-05 |
| Judul | Compliance & Audit Governance |
| Versi | 1.0 |
| Status | Draft for Review |
| Domain | Platform Kernel |
| Kategori | Governance, Compliance & Assurance |
| Cakupan | Compliance Obligations, Applicability, Control Mapping, Audit, Evidence, Findings, Remediation, Assurance |
| Bergantung pada | SSOT-GOV-01, SSOT-GOV-04, SSOT-SEC-01, SSOT-SEC-02 |
| Target Arsitektur | Modular Monolith, Enterprise Platform Kernel |

---

# 1. Executive Summary

SSOT-GOV-05 menetapkan governance framework untuk compliance dan audit pada Platform Kernel serta seluruh module bisnis.

Framework ini mengatur:

- compliance obligation register;
- applicability assessment;
- requirement interpretation;
- mapping requirement ke policy, control, evidence, owner, dan test;
- compliance monitoring;
- control self-assessment;
- internal audit;
- external audit;
- audit planning;
- audit scope;
- sampling;
- evidence handling;
- audit findings;
- remediation;
- verification;
- assurance reporting;
- regulatory change management;
- metrics;
- UAT;
- Definition of Done.

Tujuan akhirnya adalah memastikan setiap obligation:

- diketahui;
- dinilai applicability-nya;
- memiliki owner;
- memiliki mapped control;
- memiliki evidence;
- diuji;
- dapat diaudit;
- memiliki remediation bila gap ditemukan;
- dapat dilaporkan kepada stakeholder secara konsisten.

---

# 2. Objectives

Framework harus:

- mencegah unknown obligations;
- menjaga compliance visibility;
- mengurangi duplicate control;
- memastikan evidence readiness;
- meningkatkan audit efficiency;
- mempercepat remediation;
- menjaga consistency antar framework;
- mendukung regulator/customer assurance;
- memisahkan compliance status dari subjective opinion;
- meningkatkan continuous assurance.

---

# 3. Core Principles

```text
No Unowned Obligation
No Obligation Without Applicability Decision
No Applicable Requirement Without Control Mapping
No Control Claim Without Evidence
No Finding Closure Without Verification
No Permanent Audit Exception
One Evidence, Multiple Frameworks Where Valid
Independence of Assurance
Traceability End to End
Continuous Compliance
```

---

# 4. Scope

Framework berlaku untuk:

```text
Legal Requirements
Regulatory Requirements
Contractual Commitments
Industry Standards
Internal Policies
Customer Assurance Requirements
Security and Privacy Controls
Operational Resilience Requirements
Vendor Obligations
Data Retention Requirements
```

---

# 5. Compliance Governance Model

```text
Source
→ Obligation
→ Applicability
→ Interpretation
→ Policy
→ Control
→ Evidence
→ Test
→ Finding
→ Remediation
→ Assurance
```

---

# 6. Compliance Sources

Potential sources:

```text
Law
Regulation
License
Contract
Customer Requirement
Industry Standard
Internal Policy
Board Directive
Risk Treatment
Audit Commitment
```

---

# 7. Compliance Obligation Register

Minimum fields:

```text
obligation_id
source
source_reference
title
requirement_text
jurisdiction
effective_date
applicability
interpretation
owner
mapped_policies
mapped_controls
evidence
status
review_due_at
```

---

# 8. Obligation Status

```text
DISCOVERED
UNDER_REVIEW
APPLICABLE
PARTIALLY_APPLICABLE
NOT_APPLICABLE
IMPLEMENTED
PARTIALLY_IMPLEMENTED
NON_COMPLIANT
REMEDIATION
RETIRED
```

---

# 9. Applicability Assessment

Assessment should consider:

- legal entity;
- jurisdiction;
- industry;
- data type;
- customer segment;
- contract;
- system role;
- processing activity;
- vendor relationship;
- deployment location.

---

# 10. Applicability Decision

Decision must record:

```text
applicable
partially_applicable
not_applicable
rationale
owner
reviewer
approved_at
review_due_at
```

---

# 11. Not Applicable Decision

A requirement may be marked not applicable only with:

- documented rationale;
- evidence;
- reviewer;
- approval;
- future review trigger.

---

# 12. Requirement Interpretation

Raw legal or contractual language should be translated into operational requirement.

Example:

```text
Source Requirement:
Access must be limited to authorized personnel.

Operational Requirement:
All access to restricted records must require authenticated identity,
approved permission, tenant scope, and auditable authorization decision.
```

---

# 13. Requirement Decomposition

One broad obligation may decompose into:

```text
Policy Requirement
Technical Control
Operational Procedure
Evidence Requirement
Review Frequency
```

---

# 14. Requirement Identifier

Format:

```text
COMP-{SOURCE}-{NUMBER}
```

Examples:

```text
COMP-INTERNAL-001
COMP-CONTRACT-014
COMP-PRIVACY-021
COMP-SECURITY-032
```

---

# 15. Requirement-to-Control Mapping

Minimum traceability:

```text
Requirement
→ Policy
→ Standard
→ Control
→ Evidence
→ Test
→ Owner
```

---

# 16. Mapping Types

```text
ONE_TO_ONE
ONE_TO_MANY
MANY_TO_ONE
MANY_TO_MANY
```

---

# 17. Common Control Framework

Where valid, one control may satisfy multiple obligations.

Example:

```text
CTRL-SEC-001 — Privileged access approval
```

may support:

- internal security policy;
- contractual access control;
- audit requirement;
- compliance framework requirement.

---

# 18. Common Control Rules

Common control reuse requires:

- equivalent objective;
- sufficient scope;
- sufficient frequency;
- acceptable evidence;
- no material interpretation gap.

---

# 19. Compliance Matrix

Recommended columns:

| Requirement | Applicable | Policy | Control | Evidence | Owner | Status |
|---|---|---|---|---|---|---|

---

# 20. Compliance Owner

Responsible for:

- interpretation coordination;
- applicability;
- mapping;
- monitoring;
- reporting;
- regulatory change intake;
- escalation.

---

# 21. Requirement Owner

Responsible for implementation and ongoing compliance.

---

# 22. Control Owner

Responsible for control design, operation, evidence, and remediation.

---

# 23. Evidence Owner

Responsible for evidence completeness, integrity, retention, and accessibility.

---

# 24. Audit Owner

Responsible for audit coordination, scope, evidence requests, and remediation tracking.

---

# 25. RACI Example

| Activity | Compliance | Legal | Security | Control Owner | Audit | Governance |
|---|---|---|---|---|---|---|
| Obligation identification | R | A/C | C | I | I | I |
| Applicability | R | A | C | C | I | I |
| Control mapping | A/R | C | C | R | I | I |
| Evidence readiness | C | I | C | R | C | I |
| Internal audit | C | I | C | C | A/R | I |
| External audit | R | C | C | C | A | I |
| Finding remediation | C | I | C | A/R | C | I |
| Risk acceptance | C | C | C | R | I | A |

---

# 26. Compliance Lifecycle

```text
Discover
→ Interpret
→ Assess Applicability
→ Map Controls
→ Implement
→ Collect Evidence
→ Test
→ Report
→ Remediate
→ Review
```

---

# 27. Regulatory Change Management

Process:

```text
Detect Change
→ Assess Impact
→ Identify Affected Obligations
→ Update Mapping
→ Create Actions
→ Implement
→ Verify
→ Communicate
```

---

# 28. Change Sources

Potential sources:

- regulator notices;
- legal updates;
- contract amendments;
- vendor terms;
- customer questionnaires;
- internal policy changes;
- industry standard updates.

---

# 29. Regulatory Change Record

```text
change_id
source
summary
effective_date
affected_requirements
impact
owner
actions
status
```

---

# 30. Change Impact Rating

```text
LOW
MEDIUM
HIGH
CRITICAL
```

---

# 31. Critical Regulatory Change

Requires:

- immediate owner;
- gap analysis;
- governance review;
- implementation deadline;
- executive awareness;
- evidence of compliance.

---

# 32. Compliance Calendar

Should include:

```text
Policy Reviews
Control Tests
Evidence Collection
Regulatory Reviews
Internal Audits
External Audits
Customer Assessments
Training
Certification Renewals
```

---

# 33. Continuous Compliance

Continuous compliance uses automated controls and evidence where feasible.

Examples:

- access review status;
- encryption configuration;
- artifact signature validation;
- vulnerability SLA;
- backup success;
- log retention;
- exception expiry.

---

# 34. Compliance Monitoring

Monitoring methods:

```text
Automated Control Monitoring
Periodic Self-Assessment
Control Owner Attestation
Internal Audit
External Audit
Management Review
```

---

# 35. Control Self-Assessment

Control owner periodically assesses:

- control design;
- operation;
- evidence;
- known failures;
- exceptions;
- remediation.

---

# 36. Self-Assessment Status

```text
EFFECTIVE
PARTIALLY_EFFECTIVE
INEFFECTIVE
NOT_TESTED
NOT_APPLICABLE
```

---

# 37. Attestation

Attestation should include:

```text
control_id
period
owner
statement
known_exceptions
evidence
signed_at
```

---

# 38. Assurance Model

```text
First Line — Control Owners and Operations
Second Line — Governance, Risk, Compliance, Security
Third Line — Independent Audit
External Assurance — Regulator/Customer/Certification Auditor
```

---

# 39. First Line Responsibilities

- operate controls;
- collect evidence;
- remediate gaps;
- report failures.

---

# 40. Second Line Responsibilities

- define framework;
- monitor compliance;
- challenge first line;
- review exceptions;
- coordinate reporting.

---

# 41. Third Line Responsibilities

- independent assurance;
- assess design and operation;
- report to governance;
- verify remediation.

---

# 42. Audit Types

```text
INTERNAL_AUDIT
EXTERNAL_AUDIT
REGULATORY_AUDIT
CUSTOMER_AUDIT
CERTIFICATION_AUDIT
CONTROL_SELF_ASSESSMENT
TECHNICAL_ASSESSMENT
```

---

# 43. Audit Lifecycle

```text
Plan
→ Approve Scope
→ Prepare
→ Fieldwork
→ Analyze
→ Report
→ Remediate
→ Verify
→ Close
```

---

# 44. Audit Plan

Minimum fields:

```text
audit_id
title
type
objective
scope
criteria
period
auditor
auditee
schedule
sampling_method
evidence_required
status
```

---

# 45. Audit Status

```text
PLANNED
APPROVED
PREPARATION
FIELDWORK
REPORTING
REMEDIATION
VERIFICATION
CLOSED
CANCELLED
```

---

# 46. Audit Scope

Scope must define:

- systems;
- modules;
- processes;
- controls;
- period;
- locations;
- exclusions;
- assumptions.

---

# 47. Audit Criteria

Criteria may include:

- applicable obligations;
- policies;
- standards;
- procedures;
- contracts;
- control design;
- operating effectiveness.

---

# 48. Audit Independence

Auditor should not be the sole operator of the control being audited.

---

# 49. Conflict of Interest

Potential conflict must be disclosed and managed.

---

# 50. Audit Preparation

Prepare:

- control matrix;
- system inventory;
- evidence list;
- owner contacts;
- prior findings;
- open exceptions;
- risk register;
- audit schedule.

---

# 51. Evidence Request List

Minimum:

```text
request_id
audit_id
control_id
description
owner
due_date
classification
status
```

---

# 52. Evidence Request Status

```text
REQUESTED
IN_PROGRESS
SUBMITTED
REJECTED
ACCEPTED
OVERDUE
```

---

# 53. Evidence Rules

Evidence must be:

- relevant to audit period;
- complete;
- authentic;
- attributable;
- retained;
- protected according classification.

---

# 54. Evidence Sampling

Sampling should consider:

- population size;
- risk;
- control frequency;
- prior failures;
- automation;
- materiality.

---

# 55. Sampling Methods

```text
RANDOM
RISK_BASED
JUDGMENTAL
SYSTEMATIC
STATISTICAL
FULL_POPULATION
```

---

# 56. Full Population Testing

Recommended for automated controls where data is available.

---

# 57. Sample Size

Sample size should be documented and justified.

---

# 58. Audit Workpaper

Workpaper should record:

```text
control
procedure
sample
evidence
result
conclusion
reviewer
date
```

---

# 59. Audit Finding

Minimum fields:

```text
finding_id
audit_id
title
criteria
condition
cause
impact
severity
recommendation
owner
target_date
status
```

---

# 60. Finding Components

Use:

```text
Criteria
Condition
Cause
Consequence
Corrective Action
```

---

# 61. Finding Severity

```text
CRITICAL
HIGH
MEDIUM
LOW
OBSERVATION
```

---

# 62. Critical Finding Examples

- cross-tenant exposure;
- active privileged access bypass;
- material data loss risk;
- missing required legal control;
- evidence falsification;
- repeated failed key control.

---

# 63. Finding Status

```text
DRAFT
OPEN
ASSIGNED
IN_PROGRESS
REMEDIATED
VERIFICATION_PENDING
VERIFIED
RISK_ACCEPTED
CLOSED
```

---

# 64. Finding Ownership

Every finding must have:

- accountable owner;
- action plan;
- due date;
- verification method.

---

# 65. Remediation Plan

Minimum:

```text
action
owner
due_date
dependencies
evidence
verification
```

---

# 66. Remediation SLA

Recommended:

| Severity | Target |
|---|---:|
| Critical | 24–72 hours |
| High | 7–30 days |
| Medium | 30–90 days |
| Low | 90–180 days |

Exact target depends on risk and obligation.

---

# 67. Finding Verification

Closure requires:

- remediation implemented;
- evidence available;
- verifier independent enough;
- retest passed;
- residual risk acceptable.

---

# 68. Risk Acceptance for Audit Finding

Allowed only with:

- documented rationale;
- residual risk;
- owner;
- compensating control;
- governance approval;
- expiry/review.

---

# 69. Repeat Finding

Repeat finding should:

- increase escalation;
- trigger root cause review;
- reassess control ownership;
- reassess governance effectiveness.

---

# 70. Root Cause Categories

```text
POLICY_GAP
CONTROL_DESIGN_GAP
OPERATING_FAILURE
OWNERSHIP_GAP
TRAINING_GAP
TECHNICAL_DEBT
EVIDENCE_GAP
MONITORING_GAP
MANAGEMENT_OVERRIDE
```

---

# 71. Audit Report

Minimum sections:

```text
Executive Summary
Objective
Scope
Criteria
Methodology
Overall Conclusion
Findings
Risk Summary
Management Response
Remediation Plan
Limitations
```

---

# 72. Audit Opinion

Possible ratings:

```text
EFFECTIVE
GENERALLY_EFFECTIVE
PARTIALLY_EFFECTIVE
INEFFECTIVE
NO_OPINION
```

---

# 73. Management Response

Management response should:

- accept or challenge finding;
- provide rationale;
- commit action;
- assign owner;
- set due date.

---

# 74. Audit Closure

Audit closes when:

- report approved;
- findings tracked;
- owners assigned;
- remediation governance active.

Individual findings may remain open.

---

# 75. External Audit Coordination

Must define:

- primary contact;
- evidence workflow;
- secure data exchange;
- scope confirmation;
- confidentiality;
- issue escalation;
- response approval.

---

# 76. Customer Assurance

Customer questionnaires should reuse authoritative control and evidence data.

Avoid inconsistent ad hoc answers.

---

# 77. Certification Governance

Certification lifecycle:

```text
Readiness
→ Gap Assessment
→ Remediation
→ Audit
→ Certification
→ Surveillance
→ Renewal
```

---

# 78. Assurance Statements

Assurance statements must be approved and evidence-backed.

---

# 79. Evidence Reuse

One evidence artifact may support multiple obligations if:

- period matches;
- scope matches;
- control objective matches;
- classification allows reuse.

---

# 80. Evidence Repository

Recommended categories:

```text
Policies
Approvals
Control Tests
Access Reviews
Security Scans
Deployment Records
Incident Reports
Backup Tests
Training Records
Vendor Assessments
Audit Reports
```

---

# 81. Evidence Metadata

```text
evidence_id
title
control_id
requirement_id
period_start
period_end
owner
classification
checksum
storage_reference
created_at
retention_until
```

---

# 82. Evidence Access

Access must follow least privilege and classification.

---

# 83. Evidence Chain of Custody

Required for sensitive audit or incident evidence.

---

# 84. Evidence Retention

Retention should be mapped to:

- legal requirement;
- contract;
- internal policy;
- audit cycle;
- litigation/legal hold.

---

# 85. Evidence Quality Rating

```text
SUFFICIENT
PARTIALLY_SUFFICIENT
INSUFFICIENT
INVALID
```

---

# 86. Compliance Gap

A gap occurs when:

- obligation applicable but unmapped;
- control missing;
- control ineffective;
- evidence insufficient;
- test overdue;
- finding unresolved.

---

# 87. Gap Status

```text
IDENTIFIED
ASSESSED
REMEDIATION_PLANNED
IN_PROGRESS
VERIFICATION
CLOSED
RISK_ACCEPTED
```

---

# 88. Compliance Exception

Temporary deviation from requirement/control must use SSOT-GOV-04 exception process.

---

# 89. Non-Waivable Requirements

Legal or regulatory requirements may be non-waivable.

Such gaps require immediate escalation and remediation.

---

# 90. Compliance Reporting

Reports should cover:

```text
Applicability
Implementation Status
Control Effectiveness
Evidence Completeness
Open Findings
Overdue Remediation
Exceptions
Regulatory Changes
Audit Status
```

---

# 91. Management Compliance Report

Recommended cadence:

- monthly for critical domains;
- quarterly enterprise summary;
- event-driven for material breaches.

---

# 92. Board/Executive Reporting

Should focus on:

- material risks;
- critical non-compliance;
- repeated findings;
- regulatory changes;
- remediation progress;
- assurance opinion.

---

# 93. Compliance Metrics

```text
obligation_total
applicable_obligation_total
unmapped_requirement_total
control_mapping_coverage_ratio
evidence_completeness_ratio
control_test_pass_ratio
audit_findings_open_total
audit_findings_overdue_total
repeat_finding_total
regulatory_change_overdue_total
```

---

# 94. KPIs

Initial targets:

```text
Applicable obligations without owner = 0
Applicable obligations without control mapping = 0
Critical audit findings overdue = 0
Evidence completeness for key controls >= 95%
Repeat critical findings = 0
Regulatory change actions overdue = 0
```

---

# 95. KRI

Potential KRIs:

```text
Critical non-compliance total
Expired compliance exceptions
Key control failure rate
Evidence rejection rate
Repeat finding rate
Audit delay days
```

---

# 96. Dashboard Views

Recommended:

- obligations by source;
- applicability status;
- mapping coverage;
- compliance by domain;
- evidence readiness;
- open audits;
- findings by severity;
- overdue remediation;
- regulatory changes;
- certification status.

---

# 97. Compliance Calendar Metrics

Track:

- audits due;
- evidence due;
- policy reviews due;
- certification renewals;
- regulatory effective dates;
- training deadlines.

---

# 98. Audit Committee / Governance Forum

Recommended forum:

```text
Risk & Compliance Committee
```

Responsibilities:

- review compliance posture;
- approve major remediation;
- review critical findings;
- review audit plans;
- review assurance reports;
- escalate material issues.

---

# 99. Meeting Agenda

```text
Regulatory Changes
Compliance Status
Control Failures
Audit Progress
Critical Findings
Overdue Remediation
Exceptions
Evidence Gaps
Assurance Decisions
```

---

# 100. Escalation Rules

Escalate when:

- critical non-compliance;
- legal deadline at risk;
- audit obstruction;
- evidence integrity issue;
- repeated key control failure;
- overdue critical finding;
- regulatory inquiry;
- material breach.

---

# 101. Audit Obstruction

Deliberate obstruction, concealment, or evidence manipulation must trigger security/governance escalation.

---

# 102. Compliance Breach

Potential compliance breach should trigger:

- impact assessment;
- legal/compliance review;
- incident process;
- evidence preservation;
- notification decision;
- remediation.

---

# 103. Vendor Compliance

Vendor governance should include:

- obligation flow-down;
- audit rights;
- evidence rights;
- notification obligations;
- control expectations;
- exit requirements.

---

# 104. Subprocessor / Subcontractor

Where applicable, vendor must disclose and govern subprocessors.

---

# 105. Contractual Control Mapping

Customer-specific obligations should map to shared controls where possible.

---

# 106. Training & Awareness

Roles requiring training:

- control owners;
- evidence owners;
- auditors;
- module owners;
- operations;
- security;
- compliance coordinators.

---

# 107. Training Topics

- evidence quality;
- audit conduct;
- requirement mapping;
- finding remediation;
- conflict of interest;
- regulatory change;
- exception process.

---

# 108. Audit Ethics

Auditors should follow:

- independence;
- objectivity;
- confidentiality;
- professional skepticism;
- evidence-based conclusions.

---

# 109. Confidentiality

Audit data may contain restricted system, security, or personal information.

---

# 110. Audit Trail

All critical actions should be auditable:

```text
Obligation Created
Applicability Changed
Control Mapping Changed
Evidence Submitted
Evidence Rejected
Audit Scope Approved
Finding Created
Finding Severity Changed
Finding Closed
Risk Accepted
```

---

# 111. Automation

Automate where possible:

- obligation review reminders;
- mapping validation;
- evidence collection;
- evidence expiry;
- audit scheduling;
- finding aging;
- remediation escalation;
- dashboard reporting.

---

# 112. API Direction

Potential endpoints:

```text
/api/internal/v1/compliance/obligations
/api/internal/v1/compliance/applicability
/api/internal/v1/compliance/mappings
/api/internal/v1/compliance/evidence
/api/internal/v1/compliance/audits
/api/internal/v1/compliance/findings
/api/internal/v1/compliance/regulatory-changes
/api/internal/v1/compliance/dashboard
```

---

# 113. Database Direction

Potential tables:

```text
comp_sources
comp_obligations
comp_applicability_assessments
comp_requirement_mappings
comp_regulatory_changes
comp_calendars
audit_engagements
audit_scopes
audit_evidence_requests
audit_workpapers
audit_findings
audit_finding_actions
audit_reports
audit_assurance_statements
```

---

# 114. Table: comp_obligations

```sql
CREATE TABLE comp_obligations (
    id CHAR(26) NOT NULL,
    obligation_code VARCHAR(80) NOT NULL,
    source_type VARCHAR(50) NOT NULL,
    source_reference VARCHAR(500) NOT NULL,
    title VARCHAR(500) NOT NULL,
    requirement_text LONGTEXT NOT NULL,
    jurisdiction VARCHAR(100) NULL,
    applicability VARCHAR(30) NOT NULL,
    interpretation_text LONGTEXT NULL,
    owner_reference VARCHAR(180) NOT NULL,
    status VARCHAR(30) NOT NULL,
    effective_date DATE NULL,
    review_due_at DATETIME(6) NULL,
    created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    updated_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6)
        ON UPDATE CURRENT_TIMESTAMP(6),

    PRIMARY KEY (id),
    UNIQUE KEY uq_comp_obligation_code (
        obligation_code
    ),
    KEY idx_comp_obligation_status (
        applicability,
        status,
        review_due_at
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

# 115. Table: comp_requirement_mappings

```sql
CREATE TABLE comp_requirement_mappings (
    id CHAR(26) NOT NULL,
    obligation_id CHAR(26) NOT NULL,
    policy_reference VARCHAR(100) NULL,
    control_reference VARCHAR(100) NOT NULL,
    evidence_requirement VARCHAR(1000) NULL,
    owner_reference VARCHAR(180) NOT NULL,
    mapping_status VARCHAR(30) NOT NULL,
    reviewed_at DATETIME(6) NULL,

    PRIMARY KEY (id),
    UNIQUE KEY uq_comp_mapping (
        obligation_id,
        control_reference
    ),
    CONSTRAINT fk_comp_mapping_obligation
        FOREIGN KEY (obligation_id)
        REFERENCES comp_obligations (id)
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

# 116. Table: audit_engagements

```sql
CREATE TABLE audit_engagements (
    id CHAR(26) NOT NULL,
    audit_code VARCHAR(80) NOT NULL,
    title VARCHAR(500) NOT NULL,
    audit_type VARCHAR(50) NOT NULL,
    objective_text LONGTEXT NOT NULL,
    scope_text LONGTEXT NOT NULL,
    criteria_text LONGTEXT NOT NULL,
    lead_auditor_reference VARCHAR(180) NOT NULL,
    auditee_owner_reference VARCHAR(180) NOT NULL,
    status VARCHAR(30) NOT NULL,
    planned_start_at DATETIME(6) NULL,
    planned_end_at DATETIME(6) NULL,
    actual_start_at DATETIME(6) NULL,
    actual_end_at DATETIME(6) NULL,
    created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),

    PRIMARY KEY (id),
    UNIQUE KEY uq_audit_engagement_code (
        audit_code
    ),
    KEY idx_audit_engagement_status (
        status,
        planned_start_at
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

# 117. Table: audit_findings

```sql
CREATE TABLE audit_findings (
    id CHAR(26) NOT NULL,
    finding_code VARCHAR(80) NOT NULL,
    audit_id CHAR(26) NOT NULL,
    title VARCHAR(500) NOT NULL,
    criteria_text LONGTEXT NOT NULL,
    condition_text LONGTEXT NOT NULL,
    cause_text LONGTEXT NULL,
    impact_text LONGTEXT NOT NULL,
    severity VARCHAR(30) NOT NULL,
    recommendation_text LONGTEXT NOT NULL,
    owner_reference VARCHAR(180) NOT NULL,
    target_date DATE NOT NULL,
    status VARCHAR(30) NOT NULL,
    verified_at DATETIME(6) NULL,

    PRIMARY KEY (id),
    UNIQUE KEY uq_audit_finding_code (
        finding_code
    ),
    KEY idx_audit_finding_status (
        severity,
        status,
        target_date
    ),
    CONSTRAINT fk_audit_finding_engagement
        FOREIGN KEY (audit_id)
        REFERENCES audit_engagements (id)
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

# 118. Event Codes

```text
COMP_OBLIGATION_DISCOVERED
COMP_APPLICABILITY_APPROVED
COMP_MAPPING_CREATED
COMP_GAP_IDENTIFIED
COMP_REGULATORY_CHANGE_RECEIVED
COMP_EVIDENCE_SUBMITTED
COMP_EVIDENCE_REJECTED
AUDIT_PLANNED
AUDIT_FIELDWORK_STARTED
AUDIT_FINDING_CREATED
AUDIT_FINDING_VERIFIED
AUDIT_REPORT_APPROVED
AUDIT_CLOSED
```

---

# 119. Error Codes

```text
COMP_OBLIGATION_NOT_FOUND
COMP_APPLICABILITY_REQUIRED
COMP_MAPPING_INCOMPLETE
COMP_CONTROL_REFERENCE_INVALID
COMP_EVIDENCE_INSUFFICIENT
COMP_REGULATORY_CHANGE_OVERDUE
AUDIT_NOT_FOUND
AUDIT_SCOPE_NOT_APPROVED
AUDIT_EVIDENCE_OVERDUE
AUDIT_FINDING_OWNER_REQUIRED
AUDIT_FINDING_VERIFICATION_REQUIRED
AUDIT_CONFLICT_OF_INTEREST
```

---

# 120. Sample Obligation

```yaml
obligation_code: COMP-INTERNAL-001
source_type: INTERNAL_POLICY
source_reference: SSOT-SEC-01
title: Privileged access must be approved and time-bound
applicability: APPLICABLE
owner: security_governance
mapped_controls:
  - CTRL-IAM-PRIV-001
evidence:
  - privileged_access_approval_log
  - expiry_job_result
status: IMPLEMENTED
```

---

# 121. Sample Audit Plan

```yaml
audit_code: AUD-2026-SEC-001
title: Security Access Governance Audit
type: INTERNAL_AUDIT
objective: Assess design and operating effectiveness of privileged access controls.
scope:
  - privileged_access
  - role_assignments
  - access_reviews
criteria:
  - SSOT-SEC-01
  - SSOT-GOV-04
period:
  start: 2026-01-01
  end: 2026-06-30
sampling_method: RISK_BASED
status: PLANNED
```

---

# 122. Sample Finding

```yaml
finding_code: FIND-2026-001
audit_code: AUD-2026-SEC-001
title: Privileged assignments without timely review
severity: HIGH
criteria: Privileged assignments must be reviewed monthly.
condition: 4 assignments exceeded the review period.
cause: Scheduler failure and missing escalation.
impact: Excessive privileged access may remain active.
owner: iam_operations
target_date: 2026-07-31
status: OPEN
```

---

# 123. Compliance Review Checklist

- [ ] Source identified.
- [ ] Requirement recorded.
- [ ] Applicability assessed.
- [ ] Interpretation approved.
- [ ] Owner assigned.
- [ ] Control mapping complete.
- [ ] Evidence defined.
- [ ] Test frequency defined.
- [ ] Gaps recorded.
- [ ] Review date set.

---

# 124. Audit Planning Checklist

- [ ] Objective clear.
- [ ] Scope approved.
- [ ] Criteria defined.
- [ ] Independence assessed.
- [ ] Auditee identified.
- [ ] Sampling documented.
- [ ] Evidence requests prepared.
- [ ] Prior findings reviewed.
- [ ] Open exceptions reviewed.
- [ ] Schedule approved.

---

# 125. Audit Finding Checklist

- [ ] Criteria stated.
- [ ] Condition supported by evidence.
- [ ] Root cause assessed.
- [ ] Impact described.
- [ ] Severity justified.
- [ ] Recommendation actionable.
- [ ] Owner assigned.
- [ ] Due date set.
- [ ] Verification method defined.

---

# 126. UAT — Compliance Obligations

- [ ] Obligation register exists.
- [ ] Source types defined.
- [ ] Applicability workflow works.
- [ ] Not-applicable rationale required.
- [ ] Requirement interpretation recorded.
- [ ] Owners assigned.
- [ ] Effective/review dates tracked.
- [ ] Regulatory change process works.

---

# 127. UAT — Mapping & Evidence

- [ ] Requirement-to-control mapping exists.
- [ ] Common control reuse is governed.
- [ ] Evidence requirements defined.
- [ ] Evidence metadata complete.
- [ ] Evidence classification applied.
- [ ] Evidence integrity protected.
- [ ] Evidence rejection works.
- [ ] Mapping gaps are visible.

---

# 128. UAT — Audit Planning

- [ ] Audit types defined.
- [ ] Audit lifecycle defined.
- [ ] Scope and criteria required.
- [ ] Independence assessed.
- [ ] Sampling methods available.
- [ ] Workpapers recorded.
- [ ] Evidence requests tracked.
- [ ] Audit calendar available.

---

# 129. UAT — Findings & Remediation

- [ ] Finding model defined.
- [ ] Severity model defined.
- [ ] Owners assigned.
- [ ] Remediation plans required.
- [ ] SLA tracked.
- [ ] Repeat findings escalated.
- [ ] Risk acceptance governed.
- [ ] Closure requires verification.

---

# 130. UAT — Assurance & Reporting

- [ ] Assurance model defined.
- [ ] Audit opinions defined.
- [ ] Management response required.
- [ ] Compliance metrics defined.
- [ ] Dashboard views defined.
- [ ] Executive reporting defined.
- [ ] Critical issues escalate.
- [ ] External audit coordination defined.

---

# 131. UAT — Automation

- [ ] Review reminders work.
- [ ] Mapping validation works.
- [ ] Evidence collection automated where feasible.
- [ ] Audit scheduling works.
- [ ] Finding aging visible.
- [ ] Remediation escalation works.
- [ ] Regulatory effective-date alerts work.

---

# 132. Definition of Done — SSOT-GOV-05

SSOT-GOV-05 dianggap selesai bila:

- [ ] objectives tersedia;
- [ ] principles tersedia;
- [ ] compliance sources tersedia;
- [ ] obligation register tersedia;
- [ ] status model tersedia;
- [ ] applicability assessment tersedia;
- [ ] interpretation model tersedia;
- [ ] requirement identifiers tersedia;
- [ ] control mapping tersedia;
- [ ] common control framework tersedia;
- [ ] ownership/RACI tersedia;
- [ ] compliance lifecycle tersedia;
- [ ] regulatory change process tersedia;
- [ ] compliance calendar tersedia;
- [ ] continuous compliance tersedia;
- [ ] self-assessment/attestation tersedia;
- [ ] assurance model tersedia;
- [ ] audit types/lifecycle tersedia;
- [ ] audit plan/scope/criteria tersedia;
- [ ] independence/conflict rules tersedia;
- [ ] evidence request/sampling tersedia;
- [ ] workpaper model tersedia;
- [ ] finding model tersedia;
- [ ] remediation/verification tersedia;
- [ ] risk acceptance/repeat finding tersedia;
- [ ] audit reporting/opinion tersedia;
- [ ] external audit/customer assurance tersedia;
- [ ] certification governance tersedia;
- [ ] evidence governance tersedia;
- [ ] compliance gap model tersedia;
- [ ] reporting/metrics/KPI/KRI tersedia;
- [ ] escalation tersedia;
- [ ] vendor compliance tersedia;
- [ ] training/ethics tersedia;
- [ ] audit trail tersedia;
- [ ] automation direction tersedia;
- [ ] API/database direction tersedia;
- [ ] event/error codes tersedia;
- [ ] samples tersedia;
- [ ] UAT tersedia.

---

# 133. Implementation Roadmap

## Phase 1 — Obligation Foundation

- create compliance source catalog;
- create obligation register;
- define applicability workflow;
- assign owners;
- create mapping template.

## Phase 2 — Evidence & Monitoring

- define evidence repository;
- define retention;
- implement self-assessment;
- implement compliance calendar;
- create dashboards.

## Phase 3 — Audit Operations

- create audit planning workflow;
- create workpapers;
- create evidence requests;
- create findings workflow;
- implement remediation tracking.

## Phase 4 — Assurance Integration

- integrate risk/control framework;
- integrate security and privacy evidence;
- integrate vendor assurance;
- automate reporting;
- enable customer assurance reuse.

## Phase 5 — Continuous Compliance

- automated control monitoring;
- continuous evidence;
- regulatory change feeds;
- compliance drift detection;
- predictive assurance.

---

# 134. Approval Gate

Dokumen dapat menjadi Approved setelah:

- Platform Governance review;
- Risk & Compliance review;
- Legal review;
- Internal Audit review;
- Security Governance review;
- Data/Privacy review;
- Operations review;
- evidence and retention review;
- finding severity/SLA review;
- reporting and escalation review.

---

# 135. Closing Statement

Compliance dan audit governance harus memastikan setiap obligation, control, evidence, audit, dan finding:

- memiliki owner;
- memiliki applicability decision;
- memiliki traceability;
- memiliki evidence;
- memiliki review;
- memiliki remediation;
- dapat diverifikasi;
- dapat diaudit;
- dapat dilaporkan.

Framework ini tidak boleh menjadi aktivitas periodik yang hanya muncul menjelang audit.

Framework harus membangun continuous compliance dan assurance yang berjalan sebagai bagian normal dari platform governance.
