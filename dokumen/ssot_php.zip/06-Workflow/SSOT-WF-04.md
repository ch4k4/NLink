
# SSOT-WF-04 — Scheduler & Job Engine

## Status Dokumen

| Item | Nilai |
|---|---|
| Kode | SSOT-WF-04 |
| Nama | Scheduler & Job Engine |
| Versi | 1.0 |
| Status | Draft Architecture |
| Domain | Platform Kernel / Workflow |
| Bergantung pada | SSOT-WF-01, SSOT-WF-02, SSOT-WF-03, SSOT-AUDIT, SSOT-IAM, SSOT-DATA |

---

# 1. Tujuan

Scheduler & Job Engine menjalankan pekerjaan otomatis di luar request pengguna.

Contoh:

- reminder
- workflow timeout
- escalation
- retry integrasi
- sinkronisasi data
- archive
- backup
- notifikasi
- laporan terjadwal

---

# 2. Prinsip

- Semua job idempotent.
- Mendukung retry.
- Mendukung penjadwalan sekali maupun berulang.
- Mendukung eksekusi sinkron dan asinkron.
- Seluruh eksekusi diaudit.

---

# 3. Komponen

```text
job_definitions
job_schedules
job_queue
job_executions
job_failures
job_locks
```

---

# 4. Jenis Job

```text
one_time
recurring
cron
event_driven
delayed
retry
maintenance
```

---

# 5. Database — job_definitions

```sql
CREATE TABLE job_definitions (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  code VARCHAR(100) NOT NULL UNIQUE,
  name VARCHAR(150) NOT NULL,
  handler_class VARCHAR(255) NOT NULL,
  queue_name VARCHAR(100) DEFAULT 'default',
  timeout_seconds INT DEFAULT 300,
  max_retries INT DEFAULT 3,
  status ENUM('active','inactive') DEFAULT 'active',
  created_at TIMESTAMP NULL,
  updated_at TIMESTAMP NULL
);
```

---

# 6. Database — job_schedules

```sql
CREATE TABLE job_schedules (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  job_definition_id BIGINT UNSIGNED NOT NULL,
  schedule_type ENUM('once','cron','interval') NOT NULL,
  cron_expression VARCHAR(100) NULL,
  interval_seconds INT NULL,
  next_run_at DATETIME NULL,
  enabled TINYINT(1) DEFAULT 1,
  created_at TIMESTAMP NULL,
  updated_at TIMESTAMP NULL
);
```

---

# 7. Database — job_queue

```sql
CREATE TABLE job_queue (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  tenant_id BIGINT UNSIGNED NULL,
  job_definition_id BIGINT UNSIGNED NOT NULL,
  payload JSON NULL,
  priority ENUM('low','normal','high','critical') DEFAULT 'normal',
  status ENUM('queued','running','completed','failed','cancelled') DEFAULT 'queued',
  attempts INT DEFAULT 0,
  available_at DATETIME NOT NULL,
  started_at DATETIME NULL,
  finished_at DATETIME NULL,
  correlation_id VARCHAR(100) NULL,
  created_at TIMESTAMP NULL,
  updated_at TIMESTAMP NULL,
  INDEX idx_job_status(status,available_at)
);
```

---

# 8. Database — job_executions

Menyimpan histori eksekusi:

- waktu mulai
- waktu selesai
- durasi
- worker
- hasil
- metadata

---

# 9. Database — job_failures

Menyimpan:

- exception
- stack trace
- payload
- retry count
- failure reason

---

# 10. Job Lifecycle

```text
Scheduled
→ Queued
→ Running
→ Completed

atau

Running
→ Failed
→ Retry
→ Completed

atau

Running
→ Failed
→ Dead Letter
```

---

# 11. Retry Policy

Strategi:

- fixed delay
- exponential backoff
- maximum retry
- dead-letter queue

---

# 12. Locking

Gunakan distributed lock agar job periodik tidak berjalan ganda.

Contoh:

```text
daily_backup
monthly_archive
```

---

# 13. Priority

```text
critical
high
normal
low
```

Job prioritas tinggi diproses lebih dahulu.

---

# 14. Worker

Worker bertugas:

- mengambil job
- mengunci job
- menjalankan handler
- mencatat hasil
- melepas lock

---

# 15. Scheduler Flow

```text
Read schedule
→ Create queue item
→ Worker mengambil job
→ Execute
→ Audit
→ Update status
```

---

# 16. Workflow Integration

Scheduler menjalankan:

- approval expiry
- SLA breach
- auto escalation
- auto close
- reminder task

---

# 17. Notification Integration

Scheduler dapat mengirim:

- reminder kunjungan
- reminder approval
- reminder pembayaran
- reminder credentialing

---

# 18. Data Integration

Scheduler dapat menjalankan:

- archive
- purge
- backup
- reindex
- cache warmup

---

# 19. Monitoring

Pantau:

- queued jobs
- running jobs
- failed jobs
- retry jobs
- execution time
- success rate

---

# 20. Audit

Event wajib:

```text
job.queued
job.started
job.completed
job.failed
job.retried
job.cancelled
```

---

# 21. Keamanan

- Handler hanya dari whitelist.
- Payload divalidasi.
- Job sensitif menggunakan service account.
- Tidak menyimpan secret dalam payload.

---

# 22. Healthcare Example

```text
00:00 Archive audit
00:15 Backup database
01:00 Escalasi approval credentialing
07:00 Reminder homecare
23:59 Auto close completed visit
```

---

# 23. Non-Healthcare Example

```text
Sync marketplace
Generate invoice
Recalculate inventory
Daily sales report
```

---

# 24. UAT

- Job terjadwal masuk queue.
- Worker menjalankan job.
- Retry bekerja saat gagal.
- Lock mencegah duplikasi.
- Audit tercatat.
- Monitoring menunjukkan status yang benar.

---

# 25. Anti-pattern

Hindari:

- cron langsung memanggil business logic
- job tanpa retry
- job tanpa timeout
- job tidak idempotent
- job gagal tanpa logging
- payload berisi password/secret

---

# 26. Definition of Done

- Scheduler mendukung once, interval, dan cron.
- Queue mendukung prioritas.
- Worker mendukung retry dan timeout.
- Dead-letter tersedia.
- Workflow, Approval, Audit, dan Notification terintegrasi.
- Mendukung healthcare dan non-healthcare.
