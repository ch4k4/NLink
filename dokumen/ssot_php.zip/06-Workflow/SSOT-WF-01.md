# SSOT-WF-01 — Workflow Engine Architecture

## Status Dokumen

| Item | Nilai |
|---|---|
| Kode | SSOT-WF-01 |
| Nama | Workflow Engine Architecture |
| Versi | 1.0 |
| Status | Draft Architecture |
| Domain | Platform Kernel / Workflow |
| Berlaku Untuk | Multi-tenant, multi-organization, multi-business entity, healthcare, non-healthcare |
| Dependensi | SSOT-SCOPE, SSOT-RBAC, SSOT-AUDIT, SSOT-IAM, SSOT-DATA |

---

# 1. Tujuan

Workflow Engine adalah komponen Platform Kernel untuk mengatur alur proses bisnis secara konsisten, terukur, dan dapat diaudit.

Workflow Engine harus dapat digunakan lintas domain:

- healthcare;
- retail;
- manufacturing;
- education;
- hospitality;
- finance;
- CRM;
- internal operation.

Contoh workflow healthcare:

```text
Registrasi Pasien
Homecare Visit
Woundcare Assessment
EMR Signing
Billing Approval
Patient Safety Incident
Credentialing
```

Contoh workflow non-healthcare:

```text
Sales Order
Purchase Request
Inventory Adjustment
Delivery Assignment
Complaint Handling
Employee Onboarding
```

---

# 2. Prinsip Dasar

## 2.1 Workflow bukan hardcoded if-else

Tidak boleh:

```php
if ($status === 'draft') {
    $status = 'submitted';
}
```

Harus ada definisi workflow, state, transition, guard, action, dan audit.

## 2.2 Workflow harus scope-aware

Setiap workflow instance wajib memiliki scope.

Minimal:

```text
tenant_id
organization_id
business_entity_id
```

## 2.3 Workflow harus RBAC-aware

Transition hanya boleh dilakukan user yang memiliki permission sesuai.

## 2.4 Workflow harus audit-aware

Setiap transition wajib mencatat audit event.

## 2.5 Workflow harus reusable lintas modul

Kernel tidak boleh hardcode istilah:

```text
patient
doctor
nurse
invoice
warehouse
```

Istilah domain berada di modul bisnis.

---

# 3. Komponen Workflow Engine

```text
workflow_definitions
workflow_versions
workflow_states
workflow_transitions
workflow_guards
workflow_actions
workflow_instances
workflow_instance_histories
workflow_tasks
workflow_task_assignments
workflow_comments
workflow_attachments
```

---

# 4. Workflow Definition

Workflow definition adalah template proses.

Contoh:

```text
patient_registration
homecare_visit
billing_refund
purchase_approval
```

Satu workflow definition dapat memiliki banyak versi.

---

# 5. Workflow Versioning

Workflow harus versioned.

Alasan:

- workflow lama tetap berjalan dengan versi lama;
- workflow baru memakai versi terbaru;
- perubahan workflow tidak merusak instance berjalan.

Contoh:

```text
homecare_visit:v1
homecare_visit:v2
```

---

# 6. Workflow State

State adalah posisi proses saat ini.

Contoh generik:

```text
draft
submitted
reviewed
approved
rejected
in_progress
completed
cancelled
closed
```

State boleh berbeda per workflow.

---

# 7. Workflow Transition

Transition adalah perpindahan dari state A ke state B.

Contoh:

```text
draft → submitted
submitted → approved
submitted → rejected
approved → in_progress
in_progress → completed
```

Setiap transition dapat memiliki:

```text
permission
guard
action
notification
audit event
```

---

# 8. Workflow Guard

Guard menentukan apakah transition boleh dilakukan.

Contoh guard:

```text
user_has_permission
resource_in_scope
required_fields_completed
clinical_privilege_valid
invoice_amount_within_limit
stock_available
```

Guard tidak selalu RBAC. Guard juga mencakup business rule.

---

# 9. Workflow Action

Action dijalankan saat transition berhasil.

Contoh action:

```text
set_submitted_at
assign_reviewer
generate_invoice
lock_emr_note
send_notification
create_audit_event
enqueue_integration_message
```

Action harus idempotent bila dijalankan ulang.

---

# 10. Workflow Instance

Workflow instance adalah proses nyata yang berjalan.

Contoh:

```text
Homecare Visit #123
Refund Request #88
Credentialing Application #10
```

Instance menyimpan:

```text
workflow_definition_id
workflow_version_id
current_state
resource_type
resource_id
scope
status
started_at
completed_at
```

---

# 11. Workflow Task

Task adalah pekerjaan yang muncul dari workflow.

Contoh:

```text
Review credentialing
Approve refund
Investigate incident
Visit patient
Sign EMR note
```

Task dapat diberikan ke:

```text
user
role
team
department
service account
```

---

# 12. Workflow Comment

Workflow harus mendukung komentar.

Komentar digunakan untuk:

- alasan approval;
- alasan rejection;
- catatan reviewer;
- catatan investigasi;
- catatan follow-up.

Komentar sensitif harus mengikuti data classification.

---

# 13. Workflow Attachment

Attachment digunakan untuk bukti.

Contoh:

- dokumen izin;
- foto woundcare;
- bukti CAPA;
- bukti pembayaran;
- dokumen approval.

Attachment harus scope-aware dan audit-aware.

---

# 14. Database — workflow_definitions

```sql
CREATE TABLE workflow_definitions (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,

    code VARCHAR(100) NOT NULL UNIQUE,
    name VARCHAR(150) NOT NULL,
    description TEXT NULL,

    domain_code VARCHAR(100) NULL,
    industry_type VARCHAR(50) NULL,

    status ENUM('active','inactive','deprecated') NOT NULL DEFAULT 'active',

    created_at TIMESTAMP NULL,
    updated_at TIMESTAMP NULL,
    deleted_at TIMESTAMP NULL
);
```

---

# 15. Database — workflow_versions

```sql
CREATE TABLE workflow_versions (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,

    workflow_definition_id BIGINT UNSIGNED NOT NULL,

    version_number INT NOT NULL,
    version_label VARCHAR(50) NULL,

    status ENUM('draft','active','deprecated','retired') NOT NULL DEFAULT 'draft',

    effective_from DATETIME NULL,
    effective_until DATETIME NULL,

    definition_json JSON NULL,

    created_by BIGINT UNSIGNED NULL,
    approved_by BIGINT UNSIGNED NULL,
    approved_at DATETIME NULL,

    created_at TIMESTAMP NULL,
    updated_at TIMESTAMP NULL,

    UNIQUE KEY uq_workflow_version (workflow_definition_id, version_number),
    INDEX idx_workflow_version_status (status)
);
```

---

# 16. Database — workflow_states

```sql
CREATE TABLE workflow_states (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,

    workflow_version_id BIGINT UNSIGNED NOT NULL,

    code VARCHAR(100) NOT NULL,
    name VARCHAR(150) NOT NULL,

    state_type ENUM('initial','normal','terminal','cancelled','error') NOT NULL DEFAULT 'normal',

    sort_order INT NOT NULL DEFAULT 0,
    is_editable TINYINT(1) NOT NULL DEFAULT 1,
    is_terminal TINYINT(1) NOT NULL DEFAULT 0,

    created_at TIMESTAMP NULL,
    updated_at TIMESTAMP NULL,

    UNIQUE KEY uq_workflow_state_code (workflow_version_id, code),
    INDEX idx_workflow_state_version (workflow_version_id)
);
```

---

# 17. Database — workflow_transitions

```sql
CREATE TABLE workflow_transitions (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,

    workflow_version_id BIGINT UNSIGNED NOT NULL,

    code VARCHAR(100) NOT NULL,
    name VARCHAR(150) NOT NULL,

    from_state_id BIGINT UNSIGNED NOT NULL,
    to_state_id BIGINT UNSIGNED NOT NULL,

    required_permission VARCHAR(150) NULL,
    requires_reason TINYINT(1) NOT NULL DEFAULT 0,
    requires_comment TINYINT(1) NOT NULL DEFAULT 0,

    status ENUM('active','inactive') NOT NULL DEFAULT 'active',

    sort_order INT NOT NULL DEFAULT 0,

    created_at TIMESTAMP NULL,
    updated_at TIMESTAMP NULL,

    UNIQUE KEY uq_workflow_transition_code (workflow_version_id, code),
    INDEX idx_transition_from_to (from_state_id, to_state_id)
);
```

---

# 18. Database — workflow_guards

```sql
CREATE TABLE workflow_guards (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,

    transition_id BIGINT UNSIGNED NOT NULL,

    guard_code VARCHAR(100) NOT NULL,
    guard_config JSON NULL,

    failure_message VARCHAR(255) NULL,

    sort_order INT NOT NULL DEFAULT 0,
    status ENUM('active','inactive') NOT NULL DEFAULT 'active',

    created_at TIMESTAMP NULL,
    updated_at TIMESTAMP NULL,

    INDEX idx_guard_transition (transition_id)
);
```

---

# 19. Database — workflow_actions

```sql
CREATE TABLE workflow_actions (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,

    transition_id BIGINT UNSIGNED NOT NULL,

    action_code VARCHAR(100) NOT NULL,
    action_config JSON NULL,

    run_mode ENUM('sync','async') NOT NULL DEFAULT 'sync',
    failure_policy ENUM('rollback','continue','retry') NOT NULL DEFAULT 'rollback',

    sort_order INT NOT NULL DEFAULT 0,
    status ENUM('active','inactive') NOT NULL DEFAULT 'active',

    created_at TIMESTAMP NULL,
    updated_at TIMESTAMP NULL,

    INDEX idx_action_transition (transition_id)
);
```

---

# 20. Database — workflow_instances

```sql
CREATE TABLE workflow_instances (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,

    tenant_id BIGINT UNSIGNED NOT NULL,
    organization_id BIGINT UNSIGNED NULL,
    business_entity_id BIGINT UNSIGNED NULL,
    branch_id BIGINT UNSIGNED NULL,
    division_id BIGINT UNSIGNED NULL,
    department_id BIGINT UNSIGNED NULL,
    service_id BIGINT UNSIGNED NULL,
    team_id BIGINT UNSIGNED NULL,
    workgroup_id BIGINT UNSIGNED NULL,
    assignment_id BIGINT UNSIGNED NULL,

    workflow_definition_id BIGINT UNSIGNED NOT NULL,
    workflow_version_id BIGINT UNSIGNED NOT NULL,
    current_state_id BIGINT UNSIGNED NOT NULL,

    resource_type VARCHAR(100) NOT NULL,
    resource_id BIGINT UNSIGNED NOT NULL,

    status ENUM('active','completed','cancelled','failed') NOT NULL DEFAULT 'active',

    started_by BIGINT UNSIGNED NULL,
    started_at DATETIME NOT NULL,
    completed_at DATETIME NULL,

    created_at TIMESTAMP NULL,
    updated_at TIMESTAMP NULL,
    deleted_at TIMESTAMP NULL,

    INDEX idx_wfi_scope (
        tenant_id,
        organization_id,
        business_entity_id,
        branch_id,
        division_id,
        department_id,
        service_id,
        team_id,
        workgroup_id,
        assignment_id
    ),
    INDEX idx_wfi_resource (resource_type, resource_id),
    INDEX idx_wfi_status (status)
);
```

---

# 21. Database — workflow_instance_histories

```sql
CREATE TABLE workflow_instance_histories (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,

    workflow_instance_id BIGINT UNSIGNED NOT NULL,

    from_state_id BIGINT UNSIGNED NULL,
    to_state_id BIGINT UNSIGNED NOT NULL,
    transition_id BIGINT UNSIGNED NULL,

    actor_user_id BIGINT UNSIGNED NULL,

    reason TEXT NULL,
    comment TEXT NULL,

    result ENUM('success','failed','denied','cancelled') NOT NULL DEFAULT 'success',
    failure_reason TEXT NULL,

    scope_snapshot JSON NULL,
    metadata JSON NULL,

    correlation_id VARCHAR(100) NULL,

    created_at TIMESTAMP NULL,

    INDEX idx_wfh_instance (workflow_instance_id),
    INDEX idx_wfh_actor (actor_user_id),
    INDEX idx_wfh_created (created_at)
);
```

---

# 22. Database — workflow_tasks

```sql
CREATE TABLE workflow_tasks (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,

    tenant_id BIGINT UNSIGNED NOT NULL,
    business_entity_id BIGINT UNSIGNED NULL,

    workflow_instance_id BIGINT UNSIGNED NOT NULL,

    title VARCHAR(150) NOT NULL,
    description TEXT NULL,

    task_type VARCHAR(100) NULL,
    status ENUM('open','in_progress','completed','cancelled','expired') NOT NULL DEFAULT 'open',

    due_at DATETIME NULL,
    priority ENUM('low','normal','high','critical') NOT NULL DEFAULT 'normal',

    created_by BIGINT UNSIGNED NULL,
    completed_by BIGINT UNSIGNED NULL,
    completed_at DATETIME NULL,

    created_at TIMESTAMP NULL,
    updated_at TIMESTAMP NULL,
    deleted_at TIMESTAMP NULL,

    INDEX idx_task_scope (tenant_id, business_entity_id),
    INDEX idx_task_instance (workflow_instance_id),
    INDEX idx_task_status_due (status, due_at)
);
```

---

# 23. Database — workflow_task_assignments

```sql
CREATE TABLE workflow_task_assignments (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,

    workflow_task_id BIGINT UNSIGNED NOT NULL,

    assignee_type ENUM('user','role','team','department','service_account') NOT NULL,
    assignee_id BIGINT UNSIGNED NOT NULL,

    status ENUM('active','completed','cancelled') NOT NULL DEFAULT 'active',

    assigned_by BIGINT UNSIGNED NULL,
    assigned_at DATETIME NOT NULL,

    completed_at DATETIME NULL,

    created_at TIMESTAMP NULL,
    updated_at TIMESTAMP NULL,

    INDEX idx_task_assignment_task (workflow_task_id),
    INDEX idx_task_assignment_assignee (assignee_type, assignee_id)
);
```

---

# 24. Workflow Engine Interface

```php
interface WorkflowEngineInterface
{
    public function start(
        string $workflowCode,
        string $resourceType,
        int $resourceId,
        ScopeContext $scope,
        int $actorUserId
    ): WorkflowInstance;

    public function transition(
        int $workflowInstanceId,
        string $transitionCode,
        int $actorUserId,
        ?string $reason = null,
        array $metadata = []
    ): WorkflowInstance;

    public function availableTransitions(
        int $workflowInstanceId,
        int $actorUserId
    ): array;
}
```

---

# 25. Transition Execution Flow

```text
Load workflow instance
→ Apply scope filter
→ Validate current state
→ Find transition
→ Check required permission
→ Run guards
→ Begin transaction
→ Execute actions
→ Update current state
→ Write history
→ Write audit event
→ Commit
→ Dispatch async actions
```

---

# 26. Guard Interface

```php
interface WorkflowGuardInterface
{
    public function passes(
        WorkflowInstance $instance,
        WorkflowTransition $transition,
        WorkflowContext $context
    ): bool;

    public function message(): string;
}
```

---

# 27. Action Interface

```php
interface WorkflowActionInterface
{
    public function execute(
        WorkflowInstance $instance,
        WorkflowTransition $transition,
        WorkflowContext $context
    ): void;
}
```

---

# 28. Workflow Context

Workflow context membawa:

```text
actor_user_id
scope_context
resource_type
resource_id
correlation_id
request_metadata
input_metadata
```

---

# 29. Permission Integration

Transition dapat memiliki `required_permission`.

Contoh:

```text
billing.refund.approve
emr.note.sign
credentialing.application.approve
```

RBAC tetap dicek oleh PermissionChecker.

---

# 30. Scope Integration

Workflow instance hanya dapat diakses jika sesuai active scope.

Transition lintas scope hanya boleh melalui cross-scope access resmi.

---

# 31. Audit Integration

Event wajib:

```text
workflow.instance.started
workflow.transition.executed
workflow.transition.denied
workflow.transition.failed
workflow.task.created
workflow.task.completed
workflow.instance.completed
workflow.instance.cancelled
```

Audit wajib menyimpan:

```text
workflow_code
instance_id
from_state
to_state
transition_code
actor
scope_snapshot
resource
correlation_id
```

---

# 32. Notification Integration

Workflow dapat memicu notifikasi.

Contoh:

```text
approval requested
task assigned
task overdue
workflow completed
workflow rejected
```

Notifikasi detail dibuat di SSOT-NOTIFY.

---

# 33. Scheduler Integration

Workflow dapat memiliki deadline.

Contoh:

```text
task due_at
SLA breach
auto-expire
auto-escalate
```

Scheduler detail dibuat di SSOT-WF-04.

---

# 34. Approval Integration

Approval Engine adalah spesialisasi workflow.

Contoh:

```text
submitted → approved
submitted → rejected
```

Approval detail dibuat di SSOT-WF-03.

---

# 35. State Machine Integration

Workflow Engine menggunakan State Machine sebagai mekanisme formal validasi state.

State Machine detail dibuat di SSOT-WF-02.

---

# 36. Error Handling

Jika guard gagal:

```text
transition denied
history recorded
audit workflow.transition.denied
```

Jika action gagal:

```text
rollback jika failure_policy = rollback
continue jika failure_policy = continue
retry jika failure_policy = retry
```

---

# 37. Idempotency

Transition harus mencegah double submit.

Gunakan:

```text
idempotency_key
current_state check
optimistic locking
```

---

# 38. Concurrency

Jika dua user mencoba transition bersamaan:

- hanya satu yang berhasil;
- yang lain mendapat conflict;
- audit mencatat failure bila perlu.

---

# 39. Workflow Definition Deployment

Perubahan workflow tidak boleh langsung mengubah instance lama.

Flow:

```text
draft version
→ review
→ approve
→ activate
→ new instance uses active version
```

---

# 40. Healthcare Example — Homecare Visit

```text
requested
→ scheduled
→ assigned
→ in_progress
→ completed
→ closed
```

Transition:

```text
schedule_visit
assign_nurse
start_visit
complete_visit
close_visit
cancel_visit
```

---

# 41. Healthcare Example — Woundcare Assessment

```text
draft
→ submitted
→ reviewed
→ signed
→ amended
```

---

# 42. Non-Healthcare Example — Sales Order

```text
draft
→ submitted
→ approved
→ fulfilled
→ delivered
→ closed
```

---

# 43. Non-Healthcare Example — Purchase Request

```text
draft
→ submitted
→ manager_approved
→ finance_approved
→ ordered
→ received
→ closed
```

---

# 44. UAT Scenario

## Scenario 1 — Start Workflow

```text
Given user punya permission membuat resource
When workflow dimulai
Then workflow_instance dibuat
And current_state = initial state
And audit workflow.instance.started tercatat
```

## Scenario 2 — Valid Transition

```text
Given instance berada di draft
When user menjalankan submit
Then state berubah ke submitted
And history tercatat
And audit tercatat
```

## Scenario 3 — Invalid Transition

```text
Given instance berada di closed
When user menjalankan submit
Then sistem menolak
And audit workflow.transition.denied tercatat
```

## Scenario 4 — Permission Denied

```text
Given user tidak punya permission approve
When user menjalankan approve
Then transition ditolak
And audit access denied tercatat
```

## Scenario 5 — Guard Failed

```text
Given required field belum lengkap
When user submit
Then guard menolak
And state tidak berubah
```

---

# 45. Anti-pattern

Hindari:

```text
status hardcoded di controller
transition tanpa audit
workflow tanpa versi
task tanpa assignee
approval dibuat ulang di tiap modul
state diubah langsung via SQL
workflow tidak scope-aware
workflow tidak RBAC-aware
```

---

# 46. Definition of Done

Workflow Engine Architecture dianggap siap bila:

- workflow definition tersedia;
- versioning tersedia;
- state dan transition tersedia;
- guard dan action tersedia;
- instance dan history tersedia;
- task dan assignment tersedia;
- transition scope-aware;
- transition RBAC-aware;
- transition audit-aware;
- mendukung workflow healthcare dan non-healthcare;
- instance lama tetap memakai versi workflow lama;
- mendukung concurrency dan idempotency.
