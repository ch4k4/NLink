# SSOT-WF-03 — Approval Engine

## Status Dokumen

| Item | Nilai |
|---|---|
| Kode | SSOT-WF-03 |
| Nama | Approval Engine |
| Versi | 1.0 |
| Status | Draft Architecture |
| Domain | Platform Kernel / Workflow |
| Bergantung pada | SSOT-WF-01, SSOT-WF-02, SSOT-SCOPE, SSOT-RBAC, SSOT-AUDIT, SSOT-IAM, SSOT-DATA |

---

# 1. Tujuan

Approval Engine adalah komponen Platform Kernel untuk mengelola proses persetujuan secara konsisten di seluruh modul.

Approval Engine digunakan untuk:

- approval role/permission;
- approval credentialing;
- approval clinical privilege;
- approval refund;
- approval billing adjustment;
- approval export data sensitif;
- approval dokumen/SOP;
- approval workflow klinis;
- approval purchase request;
- approval inventory adjustment;
- approval non-healthcare business process.

Approval Engine tidak boleh dibuat ulang di setiap modul.

---

# 2. Prinsip Dasar

## 2.1 Approval adalah spesialisasi workflow

Approval Engine berjalan di atas Workflow Engine dan State Machine.

Contoh sederhana:

```text
draft
→ submitted
→ approved / rejected
```

## 2.2 Approval harus scope-aware

Approver hanya dapat menyetujui request dalam scope yang sah.

## 2.3 Approval harus RBAC-aware

Approver wajib memiliki permission approval yang sesuai.

## 2.4 Approval harus audit-aware

Setiap keputusan approval wajib dicatat.

## 2.5 Maker-checker principle

Pembuat request tidak boleh menjadi approver final untuk request-nya sendiri bila policy melarang.

---

# 3. Jenis Approval

```text
single_approval
multi_level_approval
parallel_approval
sequential_approval
conditional_approval
amount_based_approval
role_based_approval
committee_approval
time_limited_approval
```

---

# 4. Approval Use Case

## Healthcare

```text
credentialing approval
clinical privilege approval
EMR amendment approval
medical record disclosure approval
patient safety incident closure
CAPA closure
```

## Finance

```text
refund approval
billing adjustment approval
payment void approval
tariff activation approval
```

## Platform

```text
role assignment approval
permission override approval
break-glass review
API key creation approval
```

## Non-Healthcare

```text
purchase request approval
stock adjustment approval
sales discount approval
delivery exception approval
```

---

# 5. Komponen Approval Engine

```text
approval_definitions
approval_rules
approval_levels
approval_requests
approval_request_items
approval_decisions
approval_delegations
approval_escalations
approval_comments
approval_attachments
approval_policies
```

---

# 6. Approval Definition

Approval definition adalah template approval.

Contoh:

```text
billing_refund_approval
credentialing_approval
permission_override_approval
purchase_request_approval
```

---

# 7. Approval Rule

Approval rule menentukan kapan approval diperlukan.

Contoh:

```text
refund amount > 1.000.000
permission override includes audit.log.export
clinical privilege high risk
purchase request > budget limit
```

---

# 8. Approval Level

Approval level menentukan urutan approval.

Contoh:

```text
Level 1: Department Manager
Level 2: Finance Manager
Level 3: Director
```

---

# 9. Approval Request

Approval request adalah instance nyata dari approval.

Contoh:

```text
Refund Request #88
Credentialing Application #12
Permission Override #7
```

---

# 10. Approval Decision

Decision adalah keputusan approver.

Status:

```text
approved
rejected
returned
delegated
escalated
expired
cancelled
```

---

# 11. Database — approval_definitions

```sql
CREATE TABLE approval_definitions (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,

    code VARCHAR(100) NOT NULL UNIQUE,
    name VARCHAR(150) NOT NULL,
    description TEXT NULL,

    domain_code VARCHAR(100) NULL,
    industry_type VARCHAR(50) NULL,

    status ENUM('active','inactive','deprecated') NOT NULL DEFAULT 'active',

    created_at TIMESTAMP NULL,
    updated_at TIMESTAMP NULL,
    deleted_at TIMESTAMP NULL
);
```

---

# 12. Database — approval_policies

```sql
CREATE TABLE approval_policies (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,

    approval_definition_id BIGINT UNSIGNED NOT NULL,

    policy_code VARCHAR(100) NOT NULL,
    policy_name VARCHAR(150) NOT NULL,

    maker_checker_required TINYINT(1) NOT NULL DEFAULT 1,
    allow_self_approval TINYINT(1) NOT NULL DEFAULT 0,
    allow_delegation TINYINT(1) NOT NULL DEFAULT 1,
    allow_parallel_approval TINYINT(1) NOT NULL DEFAULT 0,

    expiry_hours INT NULL,
    escalation_hours INT NULL,

    status ENUM('active','inactive') NOT NULL DEFAULT 'active',

    created_at TIMESTAMP NULL,
    updated_at TIMESTAMP NULL,

    UNIQUE KEY uq_approval_policy_code (approval_definition_id, policy_code),
    INDEX idx_approval_policy_definition (approval_definition_id)
);
```

---

# 13. Database — approval_rules

```sql
CREATE TABLE approval_rules (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,

    approval_definition_id BIGINT UNSIGNED NOT NULL,

    rule_code VARCHAR(100) NOT NULL,
    rule_name VARCHAR(150) NOT NULL,

    condition_json JSON NULL,
    priority INT NOT NULL DEFAULT 0,

    status ENUM('active','inactive') NOT NULL DEFAULT 'active',

    created_at TIMESTAMP NULL,
    updated_at TIMESTAMP NULL,

    UNIQUE KEY uq_approval_rule_code (approval_definition_id, rule_code),
    INDEX idx_approval_rule_priority (approval_definition_id, priority)
);
```

Contoh `condition_json`:

```json
{
  "field": "amount",
  "operator": ">",
  "value": 1000000
}
```

---

# 14. Database — approval_levels

```sql
CREATE TABLE approval_levels (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,

    approval_definition_id BIGINT UNSIGNED NOT NULL,
    approval_rule_id BIGINT UNSIGNED NULL,

    level_number INT NOT NULL,
    level_name VARCHAR(150) NOT NULL,

    approver_type ENUM('user','role','team','department','committee','dynamic') NOT NULL,
    approver_id BIGINT UNSIGNED NULL,
    approver_resolver VARCHAR(150) NULL,

    required_permission VARCHAR(150) NULL,

    min_approvals_required INT NOT NULL DEFAULT 1,
    allow_reject TINYINT(1) NOT NULL DEFAULT 1,
    allow_return TINYINT(1) NOT NULL DEFAULT 1,

    status ENUM('active','inactive') NOT NULL DEFAULT 'active',

    created_at TIMESTAMP NULL,
    updated_at TIMESTAMP NULL,

    INDEX idx_approval_level_definition (approval_definition_id),
    INDEX idx_approval_level_rule (approval_rule_id)
);
```

---

# 15. Database — approval_requests

```sql
CREATE TABLE approval_requests (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,

    tenant_id BIGINT UNSIGNED NOT NULL,
    organization_id BIGINT UNSIGNED NULL,
    business_entity_id BIGINT UNSIGNED NULL,
    branch_id BIGINT UNSIGNED NULL,
    division_id BIGINT UNSIGNED NULL,
    department_id BIGINT UNSIGNED NULL,
    service_id BIGINT UNSIGNED NULL,
    team_id BIGINT UNSIGNED NULL,
    workgroup_id BIGINT UNSIGNED NULL,
    assignment_id BIGINT UNSIGNED NULL,

    approval_definition_id BIGINT UNSIGNED NOT NULL,
    approval_policy_id BIGINT UNSIGNED NULL,

    resource_type VARCHAR(100) NOT NULL,
    resource_id BIGINT UNSIGNED NOT NULL,

    request_title VARCHAR(150) NOT NULL,
    request_summary TEXT NULL,

    requested_by BIGINT UNSIGNED NOT NULL,
    requested_at DATETIME NOT NULL,

    current_level INT NOT NULL DEFAULT 1,

    status ENUM(
        'draft',
        'submitted',
        'in_review',
        'approved',
        'rejected',
        'returned',
        'cancelled',
        'expired'
    ) NOT NULL DEFAULT 'submitted',

    due_at DATETIME NULL,
    completed_at DATETIME NULL,

    scope_snapshot JSON NULL,
    metadata JSON NULL,

    created_at TIMESTAMP NULL,
    updated_at TIMESTAMP NULL,
    deleted_at TIMESTAMP NULL,

    INDEX idx_approval_request_scope (
        tenant_id,
        organization_id,
        business_entity_id,
        branch_id,
        division_id,
        department_id,
        service_id,
        team_id,
        workgroup_id,
        assignment_id
    ),
    INDEX idx_approval_request_resource (resource_type, resource_id),
    INDEX idx_approval_request_status (status),
    INDEX idx_approval_request_requested_by (requested_by)
);
```

---

# 16. Database — approval_request_items

```sql
CREATE TABLE approval_request_items (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,

    approval_request_id BIGINT UNSIGNED NOT NULL,

    item_type VARCHAR(100) NULL,
    item_reference VARCHAR(150) NULL,
    item_summary TEXT NULL,

    old_value JSON NULL,
    new_value JSON NULL,

    metadata JSON NULL,

    created_at TIMESTAMP NULL,
    updated_at TIMESTAMP NULL,

    INDEX idx_approval_item_request (approval_request_id)
);
```

---

# 17. Database — approval_decisions

```sql
CREATE TABLE approval_decisions (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,

    approval_request_id BIGINT UNSIGNED NOT NULL,

    level_number INT NOT NULL,

    approver_user_id BIGINT UNSIGNED NOT NULL,

    decision ENUM('approved','rejected','returned','delegated','escalated') NOT NULL,

    decision_reason TEXT NULL,
    decision_comment TEXT NULL,

    decided_at DATETIME NOT NULL,

    scope_snapshot JSON NULL,
    metadata JSON NULL,

    correlation_id VARCHAR(100) NULL,

    created_at TIMESTAMP NULL,

    INDEX idx_approval_decision_request (approval_request_id),
    INDEX idx_approval_decision_approver (approver_user_id),
    INDEX idx_approval_decision_decided_at (decided_at)
);
```

---

# 18. Database — approval_delegations

```sql
CREATE TABLE approval_delegations (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,

    tenant_id BIGINT UNSIGNED NOT NULL,
    business_entity_id BIGINT UNSIGNED NULL,

    delegator_user_id BIGINT UNSIGNED NOT NULL,
    delegate_user_id BIGINT UNSIGNED NOT NULL,

    approval_definition_id BIGINT UNSIGNED NULL,

    reason TEXT NOT NULL,

    valid_from DATETIME NOT NULL,
    valid_until DATETIME NOT NULL,

    status ENUM('active','revoked','expired') NOT NULL DEFAULT 'active',

    created_by BIGINT UNSIGNED NULL,
    revoked_by BIGINT UNSIGNED NULL,
    revoked_at DATETIME NULL,

    created_at TIMESTAMP NULL,
    updated_at TIMESTAMP NULL,

    INDEX idx_approval_delegation_delegator (delegator_user_id),
    INDEX idx_approval_delegation_delegate (delegate_user_id),
    INDEX idx_approval_delegation_validity (valid_from, valid_until)
);
```

---

# 19. Database — approval_escalations

```sql
CREATE TABLE approval_escalations (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,

    approval_request_id BIGINT UNSIGNED NOT NULL,

    from_user_id BIGINT UNSIGNED NULL,
    to_user_id BIGINT UNSIGNED NULL,
    to_role_id BIGINT UNSIGNED NULL,

    escalation_reason TEXT NOT NULL,
    escalated_at DATETIME NOT NULL,

    status ENUM('active','completed','cancelled') NOT NULL DEFAULT 'active',

    created_at TIMESTAMP NULL,
    updated_at TIMESTAMP NULL,

    INDEX idx_approval_escalation_request (approval_request_id),
    INDEX idx_approval_escalation_status (status)
);
```

---

# 20. Approval Engine Interface

```php
interface ApprovalEngineInterface
{
    public function submit(
        string $approvalCode,
        string $resourceType,
        int $resourceId,
        int $requesterUserId,
        ScopeContext $scope,
        array $metadata = []
    ): ApprovalRequest;

    public function approve(
        int $approvalRequestId,
        int $approverUserId,
        ?string $comment = null
    ): ApprovalRequest;

    public function reject(
        int $approvalRequestId,
        int $approverUserId,
        string $reason
    ): ApprovalRequest;

    public function returnForRevision(
        int $approvalRequestId,
        int $approverUserId,
        string $reason
    ): ApprovalRequest;

    public function availableActions(
        int $approvalRequestId,
        int $userId
    ): array;
}
```

---

# 21. Approval Submit Flow

```text
Create resource draft
→ Submit approval
→ Resolve approval definition
→ Resolve applicable rule
→ Create approval request
→ Create workflow instance/task
→ Notify approver
→ Audit approval.request.submitted
```

---

# 22. Approval Decision Flow

```text
Load approval request
→ Validate scope
→ Validate status
→ Resolve current approval level
→ Validate approver
→ Validate maker-checker
→ Check required permission
→ Save decision
→ Move to next level or final state
→ Execute post-approval action
→ Audit decision
```

---

# 23. Approver Resolution

Approver dapat ditentukan dari:

```text
specific user
role
team
department manager
business entity director
committee
dynamic resolver
```

Dynamic resolver contoh:

```text
manager_of_requester
finance_manager_for_scope
clinical_director_for_service
credentialing_committee
```

---

# 24. Maker-Checker Rule

Jika `maker_checker_required = true`, maka:

```text
requested_by != approver_user_id
```

Jika user sama, approval ditolak.

Exception hanya boleh jika:

```text
allow_self_approval = true
```

dan harus audit.

---

# 25. Amount-Based Approval

Contoh:

```text
refund <= 1.000.000 → supervisor
refund > 1.000.000 → manager + director
```

Rule disimpan di `approval_rules.condition_json`.

---

# 26. Parallel Approval

Parallel approval digunakan jika beberapa approver dapat menyetujui pada level yang sama.

Contoh:

```text
min_approvals_required = 2
```

Jika minimal approval tercapai, lanjut level berikutnya.

---

# 27. Sequential Approval

Sequential approval mengikuti urutan level.

Contoh:

```text
Level 1 → Level 2 → Level 3
```

Level berikutnya tidak aktif sebelum level sebelumnya selesai.

---

# 28. Rejection

Jika request ditolak:

```text
status = rejected
workflow state = rejected
post action dijalankan bila ada
audit approval.request.rejected
```

Rejection wajib memiliki alasan.

---

# 29. Return for Revision

Jika dikembalikan:

```text
status = returned
resource kembali editable sesuai policy
requester menerima task revisi
audit approval.request.returned
```

---

# 30. Cancellation

Requester atau admin tertentu dapat membatalkan request jika belum final.

Cancellation wajib mencatat alasan.

---

# 31. Expiry

Approval dapat expired jika melewati due date.

Scheduler mengubah status:

```text
expired
```

dan mencatat audit.

---

# 32. Escalation

Escalation terjadi bila approval terlalu lama.

Flow:

```text
approval overdue
→ scheduler detects
→ create escalation
→ notify higher approver
→ audit approval.request.escalated
```

---

# 33. Delegation

Approver dapat mendelegasikan approval bila policy mengizinkan.

Rule:

- delegasi punya masa berlaku;
- delegasi punya alasan;
- delegasi diaudit;
- delegate harus punya scope dan permission yang sesuai.

---

# 34. Scope Integration

Approval request memiliki scope.

Approver harus berada dalam scope yang sama atau memiliki cross-scope grant.

---

# 35. RBAC Integration

Permission contoh:

```text
approval.request.read
approval.request.submit
approval.request.approve
approval.request.reject
approval.request.delegate
approval.request.escalate
```

Permission bisa spesifik domain:

```text
billing.refund.approve
credentialing.application.approve
rbac.permission_override.approve
```

---

# 36. Audit Integration

Event wajib:

```text
approval.request.submitted
approval.request.approved
approval.request.rejected
approval.request.returned
approval.request.cancelled
approval.request.expired
approval.request.escalated
approval.delegation.created
approval.delegation.revoked
```

Audit menyimpan:

```text
approval_request_id
approval_code
resource_type
resource_id
decision
actor
scope_snapshot
reason
correlation_id
```

---

# 37. Workflow Integration

Approval Engine dapat membuat workflow task.

Contoh:

```text
submitted → in_review
approved → next_level / approved
rejected → rejected
returned → revision_required
```

---

# 38. Notification Integration

Notifikasi dikirim saat:

```text
request submitted
approval assigned
approval overdue
request approved
request rejected
request returned
request escalated
```

Detail notifikasi dibuat di SSOT-NOTIFY.

---

# 39. Scheduler Integration

Scheduler diperlukan untuk:

```text
expiry
reminder
escalation
SLA breach
```

Detail scheduler dibuat di SSOT-WF-04.

---

# 40. Healthcare Example — Credentialing Approval

```text
draft
→ submitted
→ committee_review
→ director_approved
→ privilege_granted
```

Approver:

```text
credentialing_reviewer
credentialing_chair
medical_director
```

---

# 41. Healthcare Example — EMR Amendment Approval

```text
amendment_requested
→ reviewed
→ approved
→ amendment_applied
```

Guard:

```text
record_locked
reason_required
approver_not_author
```

---

# 42. Finance Example — Refund Approval

```text
draft
→ submitted
→ supervisor_approved
→ finance_approved
→ paid
```

Amount-based approval digunakan.

---

# 43. Platform Example — Permission Override

```text
requested
→ security_review
→ approved
→ active
→ expired
```

Wajib MFA/step-up untuk approver.

---

# 44. UAT Scenario

## Scenario 1 — Submit Approval

```text
Given user punya permission submit
When request diajukan
Then approval_request dibuat
And task approver dibuat
And audit tercatat
```

## Scenario 2 — Approve Level 1

```text
Given approval request berada di level 1
When approver valid approve
Then decision tercatat
And request lanjut ke level berikutnya
```

## Scenario 3 — Maker Checker

```text
Given requester mencoba approve request sendiri
When maker_checker_required = true
Then approval ditolak
And audit denied tercatat
```

## Scenario 4 — Reject

```text
Given request menunggu approval
When approver reject dengan alasan
Then status menjadi rejected
And audit tercatat
```

## Scenario 5 — Escalation

```text
Given approval overdue
When scheduler berjalan
Then escalation dibuat
And approver baru diberi notifikasi
```

---

# 45. Anti-pattern

Hindari:

```text
approval hardcoded di controller
approver ditulis langsung di resource table
approval tanpa audit
self-approval tanpa policy
approval tanpa scope
approval tanpa permission
approval tanpa history
delegasi tanpa masa berlaku
```

---

# 46. Definition of Done

Approval Engine dianggap siap bila:

- approval definition tersedia;
- approval policy tersedia;
- approval rule tersedia;
- approval level tersedia;
- approval request dan decision tersedia;
- maker-checker rule tersedia;
- approval scope-aware;
- approval RBAC-aware;
- approval audit-aware;
- delegation tersedia;
- escalation tersedia;
- expiry tersedia;
- workflow task terintegrasi;
- mendukung healthcare dan non-healthcare.
