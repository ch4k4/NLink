# SSOT-WF-07 — Workflow Recovery, Compensation & Reconciliation Governance

## Status Dokumen

| Item | Nilai |
|---|---|
| Kode | SSOT-WF-07 |
| Judul | Workflow Recovery, Compensation & Reconciliation Governance |
| Versi | 1.0 |
| Status | Draft Architecture |
| Domain | Platform Kernel |
| Kategori | Workflow Recovery, Compensation, Rollback & Reconciliation |
| Cakupan | Stuck Instances, Failed Transitions, Compensation, Rollback, Timeout Recovery, Manual Recovery, State Reconciliation |
| Bergantung pada | SSOT-GOV-01, SSOT-GOV-04, SSOT-GOV-05, SSOT-AUDIT-01, SSOT-EVENT-05, SSOT-INTEGRATION-04, SSOT-WF-05, SSOT-WF-06, SSOT-OBS-01, SSOT-TEST-01 |
| Target Stack | PHP 8.1+, PDO, MySQL 8/MariaDB, Queue/Event-ready |
| Target Evolusi | Automated Recovery Orchestration, Saga Compensation Engine, Continuous Workflow Assurance, Predictive Stuck-Instance Detection |

# 1. Executive Summary

SSOT-WF-07 menetapkan governance resmi untuk workflow recovery, compensation, rollback, stuck-instance handling, timeout recovery, manual intervention, dan reconciliation.

Dokumen ini memastikan setiap workflow failure:

- dapat dideteksi;
- dapat diklasifikasikan;
- tidak meninggalkan instance dalam state ambigu;
- memiliki recovery path;
- memiliki compensation path bila side effect telah terjadi;
- dapat direkonsiliasi dengan task, event, timer, dan external systems;
- dapat diaudit;
- dapat dipulihkan tanpa menggandakan business effect.

# 2. Objectives

Framework harus:

- menyediakan failure taxonomy;
- mendeteksi stuck instances;
- menyediakan retry dan recovery;
- menyediakan compensation;
- menyediakan rollback;
- mendukung manual intervention;
- menjaga idempotency;
- menjaga task/event/timer consistency;
- menyediakan reconciliation;
- menghasilkan evidence operasional.

# 3. Core Principles

```text
No Workflow Instance Is Silently Stuck
Recovery Must Be Explicit
Compensation Must Be Governed
Rollback Must Preserve Evidence
Retries Must Be Idempotent
Unknown State Must Be Reconciled
Human Tasks Must Stay Consistent
Timers Must Be Recoverable
External Side Effects Must Be Verified
Every Recovery Action Is Auditable
```

# 4. Scope

Berlaku untuk:

```text
Automated Workflows
Human Workflows
Approval Flows
Clinical Processes
Homecare Processes
Billing Processes
Case Management
Long-Running Sagas
Timer-Driven Processes
External Integration Workflows
```

# 5. Workflow Failure Categories

```text
TRANSIENT_ACTION_FAILURE
PERMANENT_ACTION_FAILURE
GUARD_EVALUATION_FAILURE
EVENT_DELIVERY_FAILURE
TIMER_FAILURE
TASK_CREATION_FAILURE
TASK_COMPLETION_FAILURE
EXTERNAL_SIDE_EFFECT_UNKNOWN
COMPENSATION_FAILURE
STATE_PERSISTENCE_FAILURE
VERSION_MISMATCH
MANUAL_DATA_ERROR
UNKNOWN
```

# 6. Instance Recovery States

```text
HEALTHY
AT_RISK
STUCK
RECOVERY_PENDING
RECOVERING
COMPENSATING
MANUAL_INTERVENTION
RECONCILING
RECOVERED
FAILED_FINAL
CANCELLED
```

# 7. Stuck Instance Definition

Instance dianggap stuck jika:

- tidak ada progress melebihi threshold;
- expected timer tidak aktif;
- pending action tidak memiliki worker;
- task completion tidak memicu transition;
- event correlation hilang;
- state dan side effect berbeda;
- retries exhausted;
- dependency permanently unavailable.

# 8. Stuck Detection Inputs

```text
last_transition_at
next_expected_action
pending_timer
pending_task
consumer lag
retry count
external status
instance version
heartbeat
```

# 9. Recovery Priority

```text
CRITICAL
HIGH
NORMAL
LOW
```

# 10. Recovery Modes

```text
RETRY_ACTION
REPLAY_EVENT
RECREATE_TASK
REBUILD_TIMER
REAPPLY_TRANSITION
ROLLBACK_STATE
COMPENSATE
REFRESH_EXTERNAL_STATUS
MANUAL_COMPLETE
MANUAL_CANCEL
MIGRATE_INSTANCE
```

# 11. Retry Action

Retry hanya diperbolehkan jika:

- error transient;
- action idempotent;
- retry budget tersedia;
- state belum berubah;
- side-effect status diketahui atau dapat diverifikasi.

# 12. Retry Budget

Setiap action harus memiliki:

```text
max_attempts
retry_deadline
backoff
jitter
retryable_errors
```

# 13. Unknown External Outcome

Jika external call timeout setelah request dikirim:

```text
DO NOT blindly retry
→ query external status
→ reconcile by idempotency/reference
→ continue only when outcome known
```

# 14. Compensation

Compensation menetralkan side effect sebelumnya.

# 15. Compensation Types

```text
AUTOMATIC
MANUAL
FINANCIAL_REVERSAL
STATUS_REVERSAL
RESOURCE_RELEASE
NOTIFICATION_CORRECTION
TASK_CANCELLATION
```

# 16. Compensation Preconditions

- original effect known;
- compensation supported;
- authorization valid;
- business impact assessed;
- idempotency key defined;
- evidence available.

# 17. Compensation Ordering

Compensations generally run in reverse order of completed side effects.

# 18. Compensation Idempotency

Repeated compensation must not duplicate reversal.

# 19. Non-Compensatable Effects

Must create:

- manual recovery task;
- impact record;
- owner;
- deadline;
- audit trail.

# 20. Workflow Rollback

Rollback returns workflow to earlier safe state.

# 21. Rollback Types

```text
STATE_ONLY
STATE_AND_DATA
STATE_TASK_TIMER
FULL_SNAPSHOT
VERSION_ROLLBACK
```

# 22. Rollback Preconditions

- safe target state identified;
- snapshot/checkpoint available;
- side effects assessed;
- compensation completed where required;
- open tasks mapped;
- timers mapped;
- approval complete.

# 23. Rollback Limitations

Rollback cannot erase historical evidence or pretend side effects never happened.

# 24. Recovery Checkpoint

Minimum:

```text
workflow_instance_id
definition_version
state
data_version
task_snapshot
timer_snapshot
last_event_id
last_transition_id
created_at
checksum
```

# 25. Checkpoint Creation

Recommended:

- before high-risk transition;
- after durable transition;
- before migration;
- before bulk recovery;
- before compensation sequence.

# 26. Checkpoint Integrity

Checkpoint must be checksummed and immutable.

# 27. Transition Journal

Every transition records:

```text
from_state
to_state
trigger
guard_result
action_results
task_changes
timer_changes
events
actor
correlation_id
occurred_at
```

# 28. Action Journal

Each action records:

- action code;
- attempt;
- input hash;
- output reference;
- result;
- error;
- side-effect reference;
- idempotency key.

# 29. State Persistence Failure

If side effect succeeds but state commit fails:

- mark outcome unknown;
- preserve external reference;
- reconcile;
- avoid blind repeat;
- recover transactionally.

# 30. Event Delivery Failure

Use outbox/event recovery and EVENT-05.

# 31. Task Creation Failure

Recovery may:

- recreate task;
- reconcile duplicate;
- rebind existing task;
- create manual exception.

# 32. Task Completion Drift

If task completed but workflow not advanced:

- verify task outcome;
- verify instance version;
- reapply transition idempotently;
- emit missing event;
- reconcile inbox projection.

# 33. Timer Failure

Timer recovery may:

- recreate missing timer;
- reschedule;
- execute overdue timer;
- escalate;
- cancel obsolete timer.

# 34. Timer Idempotency

Overdue timer execution must be idempotent.

# 35. Duplicate Transition

Transition command/event must use stable idempotency key.

# 36. Out-of-Order Events

Use sequence, aggregate version, or workflow transition number.

# 37. Version Mismatch

Instance definition version mismatch requires:

- stop;
- resolve actual version;
- compare registry;
- migrate or restore binding;
- reconcile state.

# 38. Recovery Plan

Minimum:

```text
incident/reason
affected instances
failure category
recovery mode
side effects
owner
approval
dry run
rollback
validation
```

# 39. Recovery Scope

Can be:

```text
SINGLE_INSTANCE
TENANT
WORKFLOW_VERSION
STATE
TIME_RANGE
FAILURE_CATEGORY
BATCH
```

# 40. Selective Recovery

Default adalah scope terkecil.

# 41. Bulk Recovery

Requires:

- stable selection criteria;
- dry run;
- capacity review;
- idempotency;
- exclusions;
- checkpoints;
- partial-failure handling.

# 42. Dry Run

Reports:

- instance count;
- states;
- definition versions;
- tasks;
- timers;
- side effects;
- unsupported cases;
- expected actions;
- estimated duration.

# 43. Manual Intervention

Manual recovery task must include:

- exact problem;
- evidence;
- permitted actions;
- required role;
- deadline;
- decision outcomes;
- audit requirement.

# 44. Manual Completion

Manual completion must not bypass mandatory evidence or authorization.

# 45. Manual State Change

Direct state mutation is prohibited outside governed recovery service.

# 46. Emergency Override

Requires:

- elevated permission;
- maker-checker for critical cases;
- reason;
- expiry;
- incident reference;
- post-action reconciliation.

# 47. Recovery Lock

Instance recovery requires lock to prevent concurrent normal processing.

# 48. Lock Timeout

Expired recovery locks must be detectable and safely releasable.

# 49. Live Processing During Recovery

Normal processing should pause for affected instance.

# 50. Recovery Idempotency

Each recovery action has stable recovery key.

# 51. Partial Recovery Failure

Successful instances stay successful; failed instances are isolated and reported.

# 52. Recovery Resume

Resume from recovery checkpoint.

# 53. Recovery Cancellation

Cancellation preserves completed actions and marks remaining work.

# 54. Workflow Reconciliation

Compare:

- workflow instance state;
- transition journal;
- action journal;
- human tasks;
- timers;
- events;
- external system state;
- definition version;
- recovery records.

# 55. Reconciliation Findings

```text
INSTANCE_STATE_MISMATCH
MISSING_TRANSITION
DUPLICATE_TRANSITION
TASK_STATE_MISMATCH
MISSING_TASK
ORPHAN_TASK
MISSING_TIMER
OVERDUE_TIMER_NOT_EXECUTED
EVENT_NOT_PUBLISHED
EXTERNAL_EFFECT_UNKNOWN
COMPENSATION_INCOMPLETE
VERSION_BINDING_MISMATCH
```

# 56. Reconciliation Frequency

- real time for critical workflows;
- hourly for high-risk;
- daily for standard;
- after incident;
- after migration;
- after recovery.

# 57. Auto-Remediation

Examples:

- recreate missing timer;
- publish missing idempotent event;
- repair inbox projection;
- restore version binding;
- reapply completed task transition.

# 58. Manual Remediation

Required for:

- financial ambiguity;
- clinical impact;
- irreversible effect;
- conflicting evidence;
- cross-tenant risk;
- failed compensation.

# 59. Recovery Verification

Must verify:

- final instance state;
- task consistency;
- timer consistency;
- event consistency;
- external side effects;
- audit trail;
- no duplicate effects.

# 60. Recovery Closure

Closure requires:

- recovery completed;
- reconciliation passed;
- owner sign-off;
- incident link;
- root-cause documented;
- preventive action tracked.

# 61. Workflow Recovery Service Contract

```php
interface WorkflowRecoveryServiceInterface
{
    public function plan(
        WorkflowRecoveryPlanRequest $request
    ): WorkflowRecoveryPlan;

    public function execute(
        WorkflowRecoveryExecutionRequest $request
    ): WorkflowRecoveryResult;
}
```

# 62. Compensation Service Contract

```php
interface WorkflowCompensationServiceInterface
{
    public function compensate(
        WorkflowCompensationRequest $request
    ): WorkflowCompensationResult;
}
```

# 63. Reconciliation Service Contract

```php
interface WorkflowReconciliationServiceInterface
{
    public function reconcile(
        WorkflowReconciliationRequest $request
    ): WorkflowReconciliationResult;
}
```

# 64. Checkpoint Service Contract

```php
interface WorkflowCheckpointServiceInterface
{
    public function create(
        WorkflowCheckpointRequest $request
    ): WorkflowCheckpoint;

    public function restore(
        WorkflowCheckpointRestoreRequest $request
    ): WorkflowRecoveryResult;
}
```

# 65. Audit Events

```text
WORKFLOW_INSTANCE_STUCK_DETECTED
WORKFLOW_RECOVERY_PLANNED
WORKFLOW_RECOVERY_STARTED
WORKFLOW_RECOVERY_ACTION_EXECUTED
WORKFLOW_COMPENSATION_STARTED
WORKFLOW_COMPENSATION_COMPLETED
WORKFLOW_ROLLBACK_EXECUTED
WORKFLOW_MANUAL_INTERVENTION_CREATED
WORKFLOW_RECOVERY_COMPLETED
WORKFLOW_RECOVERY_FAILED
WORKFLOW_RECONCILIATION_FAILED
```

# 66. Metrics

```text
workflow_stuck_instance_total
workflow_recovery_run_total
workflow_recovery_success_total
workflow_recovery_failure_total
workflow_compensation_total
workflow_compensation_failure_total
workflow_manual_intervention_total
workflow_recovery_duration_seconds
workflow_reconciliation_failure_total
```

# 67. KPIs

```text
Silently stuck instances = 0
Recovery without owner = 0
Blind retry after unknown external outcome = 0
Duplicate critical side effects = 0
Failed compensation without escalation = 0
Manual state mutation outside recovery service = 0
Recovery closed without reconciliation = 0
```

# 68. KRIs

```text
Stuck-instance growth
Recovery failure rate
Compensation frequency
Unknown external outcomes
Manual intervention backlog
Overdue timer count
Repeated recovery by workflow version
Emergency override frequency
```

# 69. Database Direction

Potential tables:

```text
workflow_instance_checkpoints
workflow_transition_journal
workflow_action_journal
workflow_recovery_plans
workflow_recovery_runs
workflow_recovery_items
workflow_compensation_records
workflow_manual_interventions
workflow_reconciliation_runs
workflow_reconciliation_findings
```

# 70. Table: workflow_instance_checkpoints

```sql
CREATE TABLE workflow_instance_checkpoints (
    id CHAR(26) NOT NULL,
    workflow_instance_id CHAR(26) NOT NULL,
    definition_version VARCHAR(100) NOT NULL,
    state_code VARCHAR(180) NOT NULL,
    data_version BIGINT UNSIGNED NOT NULL,
    checkpoint_data JSON NOT NULL,
    checksum_sha256 CHAR(64) NOT NULL,
    created_by VARCHAR(180) NOT NULL,
    created_at DATETIME(6) NOT NULL,

    PRIMARY KEY (id),
    KEY idx_workflow_checkpoint_instance (
        workflow_instance_id,
        created_at
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

# 71. Table: workflow_recovery_plans

```sql
CREATE TABLE workflow_recovery_plans (
    id CHAR(26) NOT NULL,
    recovery_code VARCHAR(100) NOT NULL,
    workflow_code VARCHAR(180) NOT NULL,
    recovery_scope VARCHAR(40) NOT NULL,
    failure_category VARCHAR(60) NOT NULL,
    recovery_mode VARCHAR(60) NOT NULL,
    owner_reference VARCHAR(180) NOT NULL,
    plan_document JSON NOT NULL,
    status VARCHAR(30) NOT NULL,
    created_at DATETIME(6) NOT NULL,

    PRIMARY KEY (id),
    UNIQUE KEY uq_workflow_recovery_code (
        recovery_code
    ),
    KEY idx_workflow_recovery_plan_status (
        status,
        created_at
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

# 72. Table: workflow_recovery_items

```sql
CREATE TABLE workflow_recovery_items (
    id CHAR(26) NOT NULL,
    recovery_run_id CHAR(26) NOT NULL,
    workflow_instance_id CHAR(26) NOT NULL,
    recovery_key VARCHAR(255) NOT NULL,
    source_state VARCHAR(180) NOT NULL,
    target_state VARCHAR(180) NULL,
    action_code VARCHAR(180) NOT NULL,
    status VARCHAR(30) NOT NULL,
    error_code VARCHAR(180) NULL,
    started_at DATETIME(6) NULL,
    completed_at DATETIME(6) NULL,

    PRIMARY KEY (id),
    UNIQUE KEY uq_workflow_recovery_item (
        recovery_run_id,
        workflow_instance_id,
        recovery_key
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

# 73. Table: workflow_reconciliation_findings

```sql
CREATE TABLE workflow_reconciliation_findings (
    id CHAR(26) NOT NULL,
    run_id CHAR(26) NOT NULL,
    workflow_instance_id CHAR(26) NOT NULL,
    finding_type VARCHAR(60) NOT NULL,
    severity VARCHAR(30) NOT NULL,
    expected_state_json JSON NULL,
    actual_state_json JSON NULL,
    owner_reference VARCHAR(180) NULL,
    status VARCHAR(30) NOT NULL,
    detected_at DATETIME(6) NOT NULL,
    resolved_at DATETIME(6) NULL,

    PRIMARY KEY (id),
    KEY idx_workflow_reconciliation_finding (
        severity,
        status,
        detected_at
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

# 74. API Direction

```text
GET  /api/internal/v1/workflows/stuck-instances
POST /api/internal/v1/workflows/recovery-plans
POST /api/internal/v1/workflows/recovery-runs
GET  /api/internal/v1/workflows/recovery-runs/{recoveryCode}
POST /api/internal/v1/workflows/recovery-runs/{recoveryCode}/cancel
POST /api/internal/v1/workflows/instances/{instanceId}/compensate
POST /api/internal/v1/workflows/instances/{instanceId}/rollback
POST /api/internal/v1/workflows/instances/{instanceId}/manual-intervention
POST /api/internal/v1/workflows/reconciliation/runs
GET  /api/internal/v1/workflows/reconciliation/findings
```

# 75. Error Codes

```text
WORKFLOW_INSTANCE_NOT_STUCK
WORKFLOW_RECOVERY_PLAN_INVALID
WORKFLOW_RECOVERY_NOT_APPROVED
WORKFLOW_RECOVERY_LOCKED
WORKFLOW_RECOVERY_IDEMPOTENCY_CONFLICT
WORKFLOW_EXTERNAL_OUTCOME_UNKNOWN
WORKFLOW_COMPENSATION_UNAVAILABLE
WORKFLOW_COMPENSATION_FAILED
WORKFLOW_ROLLBACK_UNSAFE
WORKFLOW_CHECKPOINT_INVALID
WORKFLOW_MANUAL_INTERVENTION_REQUIRED
WORKFLOW_RECONCILIATION_FAILED
```

# 76. Recovery Planning Checklist

- [ ] Failure category identified.
- [ ] Affected instances selected.
- [ ] Definition versions known.
- [ ] Side effects classified.
- [ ] Idempotency verified.
- [ ] Tasks reviewed.
- [ ] Timers reviewed.
- [ ] Events reviewed.
- [ ] External outcomes checked.
- [ ] Checkpoint available.
- [ ] Compensation planned.
- [ ] Approval complete.

# 77. Recovery Closure Checklist

- [ ] Target state reached.
- [ ] Tasks consistent.
- [ ] Timers consistent.
- [ ] Events consistent.
- [ ] External effects verified.
- [ ] Compensation complete.
- [ ] Reconciliation passed.
- [ ] Owner signed off.
- [ ] Root cause documented.
- [ ] Preventive action created.

# 78. UAT — Stuck Detection

- [ ] No-progress threshold detects instance.
- [ ] Missing timer detected.
- [ ] Missing task detected.
- [ ] Failed transition detected.
- [ ] Unknown external outcome detected.
- [ ] Version mismatch detected.
- [ ] False positive can be dismissed with reason.
- [ ] Critical case alerts owner.
- [ ] Metrics update.

# 79. UAT — Retry & Recovery

- [ ] Transient action retries.
- [ ] Permanent error does not retry.
- [ ] Retry budget enforced.
- [ ] Unknown external outcome queries status first.
- [ ] Duplicate retry remains idempotent.
- [ ] Recovery lock blocks normal processing.
- [ ] Partial batch failures isolated.
- [ ] Cancellation preserves progress.
- [ ] Resume continues from checkpoint.

# 80. UAT — Compensation

- [ ] Completed side effects compensated in reverse order.
- [ ] Duplicate compensation prevented.
- [ ] Failed compensation escalates.
- [ ] Non-compensatable effect creates manual task.
- [ ] Financial compensation requires approval.
- [ ] Notification correction follows policy.
- [ ] Evidence retained.
- [ ] Final state reconciled.

# 81. UAT — Rollback

- [ ] Safe state rollback works.
- [ ] State/data checkpoint restores.
- [ ] Open tasks reconcile.
- [ ] Timers reconcile.
- [ ] Missing events repaired.
- [ ] Irreversible effects flagged.
- [ ] Emergency rollback requires elevated permission.
- [ ] Historical evidence preserved.
- [ ] Audit complete.

# 82. UAT — Task, Timer & Event Recovery

- [ ] Missing task recreated once.
- [ ] Orphan task closed safely.
- [ ] Completed task transition reapplied.
- [ ] Missing timer recreated.
- [ ] Overdue timer executes idempotently.
- [ ] Missing event published once.
- [ ] Duplicate event does not duplicate effect.
- [ ] Inbox projection repaired.
- [ ] State remains consistent.

# 83. UAT — Manual Intervention

- [ ] Manual case includes evidence.
- [ ] Required role enforced.
- [ ] Direct state mutation blocked.
- [ ] Maker-checker enforced for critical case.
- [ ] Completion evidence required.
- [ ] Timeout/escalation works.
- [ ] Outcome updates workflow safely.
- [ ] Audit retained.

# 84. UAT — Reconciliation

- [ ] State mismatch detected.
- [ ] Missing transition detected.
- [ ] Duplicate transition detected.
- [ ] Task mismatch detected.
- [ ] Missing timer detected.
- [ ] Event not published detected.
- [ ] External effect unknown detected.
- [ ] Incomplete compensation detected.
- [ ] Version binding mismatch detected.
- [ ] Critical finding opens incident.

# 85. Definition of Done — SSOT-WF-07

SSOT-WF-07 dianggap selesai bila:

- [ ] failure taxonomy tersedia;
- [ ] recovery states tersedia;
- [ ] stuck detection tersedia;
- [ ] retry governance tersedia;
- [ ] unknown external outcome handling tersedia;
- [ ] compensation governance tersedia;
- [ ] rollback governance tersedia;
- [ ] checkpoints/journals tersedia;
- [ ] task/timer/event recovery tersedia;
- [ ] version mismatch handling tersedia;
- [ ] recovery plans/scopes tersedia;
- [ ] dry run/bulk recovery tersedia;
- [ ] manual intervention tersedia;
- [ ] locks/idempotency tersedia;
- [ ] partial failure/cancel/resume tersedia;
- [ ] reconciliation tersedia;
- [ ] closure verification tersedia;
- [ ] audit and metrics tersedia;
- [ ] database direction tersedia;
- [ ] API direction tersedia;
- [ ] SDK contracts tersedia;
- [ ] UAT and DoD tersedia.

# 86. Implementation Roadmap

## Phase 1 — Recovery Foundation

- failure taxonomy;
- stuck detection;
- recovery state;
- transition/action journals;
- recovery locks;
- administrative APIs.

## Phase 2 — Retry & Checkpoints

- retry policy;
- checkpoints;
- idempotency;
- timer recovery;
- task recovery;
- event repair.

## Phase 3 — Compensation & Rollback

- compensation registry;
- reverse-order execution;
- rollback service;
- manual intervention;
- emergency override;
- evidence.

## Phase 4 — Reconciliation

- state reconciliation;
- task/timer/event comparison;
- external outcome verification;
- auto-remediation;
- incident workflow;
- closure gates.

## Phase 5 — Continuous Workflow Assurance

- predictive stuck detection;
- automated recovery recommendations;
- recovery simulation;
- compensation analytics;
- continuous reconciliation;
- recovery dashboard.

# 87. Initial Implementation Backlog

```text
WF07-001 Failure Taxonomy
WF07-002 Stuck Instance Detector
WF07-003 Transition Journal
WF07-004 Action Journal
WF07-005 Recovery Checkpoint Service
WF07-006 Recovery Plan Service
WF07-007 Recovery Lock
WF07-008 Retry Recovery Executor
WF07-009 Task/Timer/Event Repair
WF07-010 Compensation Registry
WF07-011 Compensation Executor
WF07-012 Rollback Service
WF07-013 Manual Intervention Workflow
WF07-014 Reconciliation Engine
WF07-015 Recovery Closure Gate
WF07-016 Workflow Recovery Dashboard
```

# 88. Approval Gate

Dokumen dapat menjadi Approved setelah:

- Workflow Architecture review;
- Event Architecture review;
- Integration Architecture review;
- Operations/SRE review;
- Security review;
- Business Process review;
- Audit/Compliance review;
- Quality Engineering review;
- UAT review.

# 89. Closing Statement

Workflow recovery tidak boleh dilakukan dengan mengubah state langsung di database.

Setiap recovery harus memiliki plan, owner, idempotency, evidence, dan reconciliation.

Compensation harus terkontrol.

Rollback harus menjaga history.

Workflow dinyatakan pulih hanya setelah seluruh state, task, timer, event, dan external effect konsisten.
