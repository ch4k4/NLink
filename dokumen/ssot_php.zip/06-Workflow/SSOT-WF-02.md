# SSOT-WF-02 — State Machine

## Status Dokumen

| Item | Nilai |
|---|---|
| Kode | SSOT-WF-02 |
| Nama | State Machine |
| Versi | 1.0 |
| Status | Draft Architecture |
| Domain | Platform Kernel / Workflow |
| Bergantung pada | SSOT-WF-01, SSOT-SCOPE, SSOT-RBAC, SSOT-AUDIT, SSOT-DATA |

---

# 1. Tujuan

State Machine adalah mekanisme formal untuk memastikan perubahan status resource hanya terjadi melalui transition yang sah.

Tujuannya:

- mencegah perubahan status sembarangan;
- memastikan setiap transition tervalidasi;
- memastikan transition scope-aware;
- memastikan transition RBAC-aware;
- memastikan transition audit-aware;
- mendukung workflow lintas domain;
- mendukung concurrency dan idempotency.

---

# 2. Konsep Utama

State Machine terdiri dari:

```text
state
transition
guard
action
context
history
```

Contoh:

```text
draft → submitted → approved → completed
```

Perubahan dari `draft` langsung ke `completed` tidak boleh terjadi jika tidak ada transition yang mendefinisikannya.

---

# 3. Prinsip Dasar

## 3.1 State tidak boleh diubah langsung

Tidak boleh:

```sql
UPDATE homecare_visits SET status = 'completed' WHERE id = 10;
```

Harus melalui:

```text
StateMachine.transition(instance, 'complete_visit')
```

## 3.2 State harus eksplisit

State tidak boleh ambigu.

Hindari:

```text
status = proses
```

Gunakan state jelas:

```text
scheduled
assigned
in_progress
completed
closed
cancelled
```

## 3.3 Transition harus eksplisit

Setiap perpindahan state wajib terdaftar.

## 3.4 Guard dijalankan sebelum transition

Guard mencegah transition bila syarat belum terpenuhi.

## 3.5 Action dijalankan setelah guard lolos

Action menjalankan efek samping seperti audit, notifikasi, lock record, atau generate billing.

---

# 4. State Types

Jenis state:

```text
initial
normal
terminal
cancelled
failed
error
```

## initial

State awal workflow.

## normal

State aktif biasa.

## terminal

State akhir yang tidak punya transition keluar.

## cancelled

State pembatalan.

## failed/error

State gagal karena proses sistem atau integrasi.

---

# 5. Transition Types

Jenis transition:

```text
normal
approval
rejection
cancellation
rollback
system
timeout
escalation
```

Contoh:

```text
submit
approve
reject
cancel
auto_expire
escalate
```

---

# 6. Guard Types

Guard umum:

```text
permission_guard
scope_guard
required_field_guard
ownership_guard
assignment_guard
time_window_guard
amount_limit_guard
clinical_privilege_guard
document_signed_guard
no_open_task_guard
```

---

# 7. Action Types

Action umum:

```text
set_timestamp
assign_task
complete_task
lock_resource
unlock_resource
send_notification
write_audit
enqueue_job
call_integration
generate_document
```

---

# 8. State Machine Definition

State machine dapat didefinisikan melalui database atau JSON.

Contoh JSON:

```json
{
  "code": "homecare_visit",
  "initial": "requested",
  "states": ["requested", "scheduled", "assigned", "in_progress", "completed", "closed", "cancelled"],
  "transitions": [
    {"code": "schedule", "from": "requested", "to": "scheduled"},
    {"code": "assign", "from": "scheduled", "to": "assigned"},
    {"code": "start", "from": "assigned", "to": "in_progress"},
    {"code": "complete", "from": "in_progress", "to": "completed"},
    {"code": "close", "from": "completed", "to": "closed"},
    {"code": "cancel", "from": "*", "to": "cancelled"}
  ]
}
```

---

# 9. Wildcard Transition

Wildcard transition boleh dipakai secara terbatas.

Contoh:

```text
any state → cancelled
```

Rule:

- harus memiliki permission;
- harus membutuhkan alasan;
- harus audit;
- tidak boleh digunakan untuk bypass proses utama.

---

# 10. Terminal State

Jika instance sudah masuk terminal state, transition keluar dilarang kecuali ada transition khusus seperti reopen.

Contoh terminal:

```text
closed
completed
cancelled
archived
```

---

# 11. Reopen Transition

Reopen hanya boleh bila:

- ada permission khusus;
- ada alasan;
- state lama mendukung reopen;
- audit dicatat.

Contoh:

```text
closed → reopened
```

---

# 12. Database — state_machine_definitions

```sql
CREATE TABLE state_machine_definitions (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    code VARCHAR(100) NOT NULL UNIQUE,
    name VARCHAR(150) NOT NULL,
    description TEXT NULL,
    domain_code VARCHAR(100) NULL,
    industry_type VARCHAR(50) NULL,
    status ENUM('active','inactive','deprecated') NOT NULL DEFAULT 'active',
    created_at TIMESTAMP NULL,
    updated_at TIMESTAMP NULL,
    deleted_at TIMESTAMP NULL
);
```

---

# 13. Database — state_machine_versions

```sql
CREATE TABLE state_machine_versions (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    state_machine_definition_id BIGINT UNSIGNED NOT NULL,
    version_number INT NOT NULL,
    status ENUM('draft','active','deprecated','retired') NOT NULL DEFAULT 'draft',
    definition_json JSON NULL,
    effective_from DATETIME NULL,
    effective_until DATETIME NULL,
    created_by BIGINT UNSIGNED NULL,
    approved_by BIGINT UNSIGNED NULL,
    approved_at DATETIME NULL,
    created_at TIMESTAMP NULL,
    updated_at TIMESTAMP NULL,
    UNIQUE KEY uq_sm_version (state_machine_definition_id, version_number),
    INDEX idx_sm_version_status (status)
);
```

---

# 14. Database — states

```sql
CREATE TABLE states (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    state_machine_version_id BIGINT UNSIGNED NOT NULL,
    code VARCHAR(100) NOT NULL,
    name VARCHAR(150) NOT NULL,
    state_type ENUM('initial','normal','terminal','cancelled','failed','error') NOT NULL DEFAULT 'normal',
    is_terminal TINYINT(1) NOT NULL DEFAULT 0,
    is_editable TINYINT(1) NOT NULL DEFAULT 1,
    sort_order INT NOT NULL DEFAULT 0,
    created_at TIMESTAMP NULL,
    updated_at TIMESTAMP NULL,
    UNIQUE KEY uq_state_code (state_machine_version_id, code),
    INDEX idx_state_version (state_machine_version_id)
);
```

---

# 15. Database — transitions

```sql
CREATE TABLE transitions (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    state_machine_version_id BIGINT UNSIGNED NOT NULL,
    code VARCHAR(100) NOT NULL,
    name VARCHAR(150) NOT NULL,
    from_state_id BIGINT UNSIGNED NULL,
    to_state_id BIGINT UNSIGNED NOT NULL,
    transition_type VARCHAR(50) NOT NULL DEFAULT 'normal',
    is_wildcard TINYINT(1) NOT NULL DEFAULT 0,
    required_permission VARCHAR(150) NULL,
    requires_reason TINYINT(1) NOT NULL DEFAULT 0,
    status ENUM('active','inactive') NOT NULL DEFAULT 'active',
    sort_order INT NOT NULL DEFAULT 0,
    created_at TIMESTAMP NULL,
    updated_at TIMESTAMP NULL,
    UNIQUE KEY uq_transition_code (state_machine_version_id, code),
    INDEX idx_transition_from_to (from_state_id, to_state_id)
);
```

---

# 16. Database — transition_guards

```sql
CREATE TABLE transition_guards (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    transition_id BIGINT UNSIGNED NOT NULL,
    guard_code VARCHAR(100) NOT NULL,
    guard_config JSON NULL,
    failure_message VARCHAR(255) NULL,
    sort_order INT NOT NULL DEFAULT 0,
    status ENUM('active','inactive') NOT NULL DEFAULT 'active',
    created_at TIMESTAMP NULL,
    updated_at TIMESTAMP NULL,
    INDEX idx_transition_guard (transition_id)
);
```

---

# 17. Database — transition_actions

```sql
CREATE TABLE transition_actions (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    transition_id BIGINT UNSIGNED NOT NULL,
    action_code VARCHAR(100) NOT NULL,
    action_config JSON NULL,
    run_mode ENUM('sync','async') NOT NULL DEFAULT 'sync',
    failure_policy ENUM('rollback','continue','retry') NOT NULL DEFAULT 'rollback',
    sort_order INT NOT NULL DEFAULT 0,
    status ENUM('active','inactive') NOT NULL DEFAULT 'active',
    created_at TIMESTAMP NULL,
    updated_at TIMESTAMP NULL,
    INDEX idx_transition_action (transition_id)
);
```

---

# 18. State Machine Interface

```php
interface StateMachineInterface
{
    public function canTransition(
        StatefulResource $resource,
        string $transitionCode,
        StateMachineContext $context
    ): bool;

    public function transition(
        StatefulResource $resource,
        string $transitionCode,
        StateMachineContext $context
    ): StatefulResource;

    public function availableTransitions(
        StatefulResource $resource,
        StateMachineContext $context
    ): array;
}
```

---

# 19. Stateful Resource

Resource yang memakai state machine harus memiliki:

```text
id
state
status
version
scope
```

Contoh:

```text
workflow_instance
homecare_visit
woundcare_assessment
billing_refund
credentialing_application
```

---

# 20. StateMachineContext

Context membawa:

```text
actor_user_id
scope_context
resource_type
resource_id
correlation_id
reason
metadata
request_ip
user_agent
```

---

# 21. Execution Flow

```text
Load resource
→ Validate scope
→ Load state machine version
→ Validate current state
→ Find transition
→ Validate permission
→ Run guards
→ Begin transaction
→ Run sync actions
→ Update state
→ Increment version
→ Write history
→ Write audit
→ Commit
→ Dispatch async actions
```

---

# 22. Permission Integration

Transition dapat memiliki `required_permission`.

Jika user tidak punya permission:

```text
transition denied
audit state_machine.transition.denied
```

---

# 23. Scope Integration

Transition harus menggunakan ScopeContext aktif.

Jika resource berada di scope berbeda:

```text
transition denied
reason = scope_denied
```

---

# 24. Audit Integration

Audit event wajib:

```text
state_machine.transition.executed
state_machine.transition.denied
state_machine.transition.failed
state_machine.state.changed
```

Audit harus menyimpan:

```text
from_state
to_state
transition_code
actor
scope_snapshot
resource
reason
correlation_id
```

---

# 25. History

Setiap transition menghasilkan history.

Minimal:

```text
resource_type
resource_id
from_state
to_state
transition_code
actor_user_id
reason
result
created_at
```

---

# 26. Concurrency

Gunakan optimistic locking.

Resource memiliki:

```text
version
```

Saat update:

```sql
UPDATE resource
SET state = :new_state,
    version = version + 1
WHERE id = :id
AND version = :expected_version
```

Jika gagal, berarti ada update bersamaan.

---

# 27. Idempotency

Untuk mencegah double submit, transition dapat menerima `idempotency_key`.

Jika request sama dikirim ulang:

- tidak membuat transition ganda;
- response dapat dikembalikan dari hasil sebelumnya.

---

# 28. Guard Failure

Jika guard gagal:

```text
state tidak berubah
history dapat dicatat sebagai denied
audit denied
pesan error aman dikembalikan
```

---

# 29. Action Failure

Jika action gagal:

| Failure Policy | Perilaku |
|---|---|
| rollback | batalkan transition |
| continue | lanjutkan transition |
| retry | masukkan ke queue retry |

---

# 30. Async Action

Async action digunakan untuk:

- notifikasi;
- webhook;
- integrasi;
- report generation.

Async action tidak boleh menentukan validitas transition utama kecuali dikonfigurasi sebagai blocking.

---

# 31. Healthcare Example — EMR Note

State:

```text
draft
signed
locked
amended
voided
```

Transition:

```text
sign
lock
amend
void
```

Guard:

```text
clinical_privilege_valid
encounter_active
required_fields_completed
```

---

# 32. Healthcare Example — Homecare Visit

State:

```text
requested
scheduled
assigned
in_progress
completed
closed
cancelled
```

Transition:

```text
schedule
assign
start
complete
close
cancel
```

---

# 33. Non-Healthcare Example — Delivery Order

State:

```text
created
assigned
picked_up
in_transit
delivered
failed
cancelled
```

---

# 34. Testing Scenario

## Scenario 1 — Valid Transition

```text
Given resource state draft
When transition submit
Then state becomes submitted
And history recorded
And audit recorded
```

## Scenario 2 — Invalid Transition

```text
Given resource state closed
When transition submit
Then denied
And state unchanged
```

## Scenario 3 — Guard Failed

```text
Given required field missing
When transition submit
Then denied
And guard message returned
```

## Scenario 4 — Permission Denied

```text
Given user lacks approve permission
When transition approve
Then denied
```

## Scenario 5 — Concurrent Update

```text
Given two users transition same resource
When both submit
Then only one succeeds
And other receives conflict
```

---

# 35. Anti-pattern

Hindari:

```text
state update langsung via SQL
status hardcoded di controller
transition tanpa permission
transition tanpa audit
workflow tanpa version
guard logic tersebar di banyak file
action tidak idempotent
```

---

# 36. Definition of Done

State Machine dianggap siap bila:

- state definition tersedia;
- transition definition tersedia;
- guard tersedia;
- action tersedia;
- transition scope-aware;
- transition RBAC-aware;
- transition audit-aware;
- mendukung concurrency;
- mendukung idempotency;
- mendukung terminal state;
- mendukung versioning;
- dapat dipakai healthcare dan non-healthcare.
