# SSOT-WF-06 — Human Task, Inbox & Assignment Governance

## Status Dokumen

| Item | Nilai |
|---|---|
| Kode | SSOT-WF-06 |
| Judul | Human Task, Inbox & Assignment Governance |
| Versi | 1.0 |
| Status | Draft Architecture |
| Domain | Platform Kernel |
| Kategori | Human Task, Assignment, Inbox, SLA & Workload Governance |
| Cakupan | Task Lifecycle, Inbox, Assignment, Claiming, Delegation, Escalation, SLA, Workload Balancing, Reconciliation |
| Bergantung pada | SSOT-GOV-01, SSOT-GOV-04, SSOT-GOV-05, SSOT-AUDIT-01, SSOT-RBAC-05, SSOT-RBAC-06, SSOT-SCOPE-01, SSOT-WF-05, SSOT-NOTIFY-04, SSOT-OBS-01, SSOT-TEST-01 |
| Target Stack | PHP 8.1+, PDO, MySQL 8/MariaDB, Queue/Event-ready |
| Target Evolusi | Intelligent Work Allocation, Skills-Based Routing, Dynamic Escalation, Workforce Analytics |

# 1. Executive Summary

SSOT-WF-06 menetapkan governance resmi untuk human task lifecycle, inbox, assignment, claiming, delegation, reassignment, escalation, SLA, workload balancing, dan reconciliation.

Dokumen ini memastikan setiap task:

- memiliki identity;
- memiliki owner dan assignee;
- memiliki scope;
- memiliki due date/SLA;
- memiliki permission;
- dapat diklaim;
- dapat didelegasikan;
- dapat dieskalasi;
- tidak hilang;
- dapat direkonsiliasi;
- dapat diaudit.

# 2. Objectives

Framework harus:

- menyediakan canonical task lifecycle;
- menyediakan personal/team inbox;
- mengatur assignment;
- mendukung claim/release;
- mendukung delegation;
- mendukung escalation;
- mengatur SLA;
- mendukung workload balancing;
- menyediakan task reconciliation;
- menyediakan audit dan metrics.

# 3. Core Principles

```text
Every Human Task Has an Owner
Every Task Has a Scope
Assignment Must Be Authorized
Claiming Must Be Atomic
Delegation Must Be Traceable
SLA Must Be Measurable
Escalation Must Be Deterministic
Workload Must Be Visible
No Task Is Silently Lost
Every Task Action Is Auditable
```

# 4. Scope

Berlaku untuk:

```text
Approval Tasks
Review Tasks
Clinical Tasks
Homecare Tasks
Billing Tasks
Case Tasks
Manual Verification
Exception Handling
Compliance Review
Incident Follow-Up
```

# 5. Task Identity

Minimum:

```text
task_id
workflow_instance_id
workflow_definition_version
task_type
title
description
tenant_id
scope
status
priority
created_at
due_at
```

# 6. Task Lifecycle

```text
CREATED
READY
ASSIGNED
CLAIMED
IN_PROGRESS
BLOCKED
DELEGATED
ESCALATED
COMPLETED
CANCELLED
EXPIRED
FAILED
```

# 7. Task Ownership

Every task must have:

- business owner;
- task queue owner;
- workflow owner;
- current assignee or candidate group;
- escalation owner.

# 8. Candidate Models

```text
USER
ROLE
TEAM
DEPARTMENT
CLINIC
ORGANIZATION
SKILL_GROUP
DYNAMIC_RULE
```

# 9. Assignment Types

```text
DIRECT
ROLE_BASED
TEAM_BASED
ROUND_ROBIN
LEAST_LOADED
SKILL_BASED
MANUAL
ESCALATION
```

# 10. Assignment Preconditions

- task active;
- candidate eligible;
- tenant/scope match;
- permission valid;
- identity active;
- workload allowed;
- conflict checks passed.

# 11. Personal Inbox

Personal inbox shows tasks:

- assigned to user;
- claimed by user;
- delegated to user;
- escalated to user;
- followed by user if policy allows.

# 12. Team Inbox

Team inbox shows tasks available to candidate group.

# 13. Inbox Security

Inbox query must be:

- tenant-aware;
- scope-aware;
- permission-aware;
- status-aware;
- masking-aware.

# 14. Claiming

Claim is atomic transfer from candidate pool to one assignee.

# 15. Claim Rules

- only eligible identity;
- task still unclaimed;
- candidate membership valid;
- no conflicting assignment;
- optimistic or pessimistic lock;
- audit generated.

# 16. Claim Conflict

Concurrent claim attempts must yield exactly one winner.

# 17. Release

Claimed task may return to team pool if policy permits.

# 18. Direct Assignment

Direct assignment requires authorized assigner and valid assignee.

# 19. Reassignment

Reassignment records:

- previous assignee;
- new assignee;
- reason;
- actor;
- timestamp;
- SLA impact.

# 20. Delegation

Delegation transfers execution authority without changing original accountability unless policy defines otherwise.

# 21. Delegation Types

```text
TEMPORARY
PERMANENT
TASK_SPECIFIC
DATE_RANGE
ROLE_COVERAGE
OUT_OF_OFFICE
```

# 22. Delegation Preconditions

- delegator authorized;
- delegate active;
- same tenant/scope;
- no prohibited duty conflict;
- effective dates valid;
- task category allowed.

# 23. Delegation Chain

Delegation depth must be bounded.

# 24. Circular Delegation

Circular delegation must be rejected.

# 25. Out-of-Office Routing

Can automatically route eligible tasks during approved absence.

# 26. Task Priority

```text
CRITICAL
HIGH
NORMAL
LOW
```

# 27. SLA

Every task type should define:

```text
response_sla
completion_sla
warning_threshold
escalation_threshold
calendar
timezone
pause_rules
```

# 28. SLA Clock

SLA clock may use:

- business hours;
- calendar hours;
- clinic hours;
- jurisdiction holidays;
- tenant calendar.

# 29. SLA Pause

Allowed for:

- blocked dependency;
- waiting on external input;
- approved hold;
- system incident;
- legal hold.

# 30. SLA Resume

Resume must preserve elapsed time and reason history.

# 31. SLA Outcomes

```text
ON_TRACK
AT_RISK
BREACHED
PAUSED
EXEMPT
```

# 32. Escalation

Escalation may:

- raise priority;
- notify supervisor;
- reassign;
- add watcher;
- create incident;
- trigger alternate workflow path.

# 33. Escalation Levels

```text
LEVEL_1_WARNING
LEVEL_2_SUPERVISOR
LEVEL_3_MANAGER
LEVEL_4_CRITICAL
```

# 34. Escalation Triggers

- SLA threshold;
- manual request;
- blocked too long;
- repeated reassignment;
- high-risk task;
- assignee inactive;
- queue overload.

# 35. Escalation Matrix

Minimum:

```text
task_type
priority
threshold
target_role
action
notification
```

# 36. Workload

Workload calculation may include:

- active task count;
- weighted task score;
- priority;
- estimated effort;
- due dates;
- skill match;
- availability;
- working hours.

# 37. Workload Capacity

Each identity/team may have:

- max concurrent tasks;
- weighted capacity;
- protected critical capacity;
- temporary override.

# 38. Least-Loaded Assignment

Must use comparable workload units.

# 39. Round Robin

Must be tenant/scope-aware and skip unavailable identities.

# 40. Skills-Based Routing

Task and assignee skills must use canonical skill codes.

# 41. Availability

Identity availability may include:

```text
AVAILABLE
BUSY
OUT_OF_OFFICE
SUSPENDED
OFF_SHIFT
ON_CALL
```

# 42. Shift Awareness

Assignments should respect shift schedules where applicable.

# 43. Conflict of Duties

Some tasks cannot be assigned to:

- requester;
- creator;
- prior approver;
- related party;
- same role in maker-checker process.

# 44. Maker-Checker

Task definition can require different identities for maker and checker.

# 45. Self-Approval

Self-approval must be blocked unless explicit approved exception.

# 46. Task Actions

```text
CLAIM
START
PAUSE
RESUME
COMPLETE
REJECT
RETURN
DELEGATE
REASSIGN
ESCALATE
CANCEL
```

# 47. Completion

Completion requires:

- assignee authorized;
- task in allowed state;
- required data valid;
- required evidence attached;
- outcome selected;
- audit generated.

# 48. Rejection

Rejection must record reason and next routing.

# 49. Return

Task may return to previous stage or queue according to workflow policy.

# 50. Blocked Task

Blocked task must record:

- blocking reason;
- dependency;
- expected resolution;
- owner;
- SLA pause policy.

# 51. Task Expiry

Expired tasks follow configured outcome:

```text
AUTO_ESCALATE
AUTO_CANCEL
AUTO_REASSIGN
CREATE_EXCEPTION
```

# 52. Cancellation

Cancellation requires reason and workflow consistency check.

# 53. Task Visibility

Visibility may differ from assignment eligibility.

# 54. Watchers

Watchers may view progress but not execute task unless separately authorized.

# 55. Comments

Task comments must:

- be auditable;
- respect classification;
- avoid secrets;
- support mentions carefully;
- retain history.

# 56. Attachments

Task attachments follow FILE-02 and FILE-03.

# 57. Notifications

Task notifications follow NOTIFY-04 and NOTIFY-05.

# 58. Inbox Sorting

Recommended:

```text
priority
due_at
SLA risk
created_at
task type
```

# 59. Inbox Filters

```text
status
priority
task type
workflow
assignee
team
due date
SLA state
tenant/scope
```

# 60. Bulk Actions

Bulk task actions require:

- same action eligibility;
- per-task authorization;
- bounded batch size;
- partial-failure reporting;
- audit.

# 61. Task Search

Search results must follow SEARCH-02 authorization rules.

# 62. Mobile Inbox

Must preserve same authorization and action constraints.

# 63. Offline Task Work

Offline mode is high risk and requires conflict-resolution governance.

# 64. Optimistic Locking

Task updates should use version number.

# 65. Task Version

Each mutation increments task version.

# 66. Stale Update

Stale task version must be rejected.

# 67. Task Events

```text
workflow.task.created.v1
workflow.task.assigned.v1
workflow.task.claimed.v1
workflow.task.started.v1
workflow.task.delegated.v1
workflow.task.escalated.v1
workflow.task.completed.v1
workflow.task.cancelled.v1
```

# 68. Event Idempotency

Task event handlers must be idempotent.

# 69. Human Task Contract

```php
interface HumanTaskServiceInterface
{
    public function claim(
        HumanTaskClaimRequest $request
    ): HumanTaskResult;

    public function complete(
        HumanTaskCompletionRequest $request
    ): HumanTaskResult;
}
```

# 70. Assignment Policy Contract

```php
interface HumanTaskAssignmentPolicyInterface
{
    public function resolve(
        HumanTaskAssignmentContext $context
    ): HumanTaskAssignmentDecision;
}
```

# 71. SLA Service Contract

```php
interface HumanTaskSlaServiceInterface
{
    public function evaluate(
        HumanTaskSlaContext $context
    ): HumanTaskSlaDecision;
}
```

# 72. Delegation Service Contract

```php
interface HumanTaskDelegationServiceInterface
{
    public function delegate(
        HumanTaskDelegationRequest $request
    ): HumanTaskDelegationResult;
}
```

# 73. Reconciliation

Compare:

- workflow instance;
- task registry;
- assignment records;
- inbox projections;
- delegation records;
- SLA timers;
- escalation state;
- identity status;
- team membership.

# 74. Reconciliation Findings

```text
TASK_MISSING
ORPHAN_TASK
ASSIGNEE_INACTIVE
ASSIGNMENT_SCOPE_MISMATCH
INBOX_PROJECTION_MISSING
DELEGATION_EXPIRED_ACTIVE
SLA_TIMER_MISSING
ESCALATION_NOT_APPLIED
COMPLETED_TASK_STILL_OPEN
TASK_VERSION_DRIFT
```

# 75. Audit Events

```text
HUMAN_TASK_CREATED
HUMAN_TASK_ASSIGNED
HUMAN_TASK_CLAIMED
HUMAN_TASK_RELEASED
HUMAN_TASK_STARTED
HUMAN_TASK_BLOCKED
HUMAN_TASK_DELEGATED
HUMAN_TASK_REASSIGNED
HUMAN_TASK_ESCALATED
HUMAN_TASK_COMPLETED
HUMAN_TASK_CANCELLED
HUMAN_TASK_RECONCILIATION_FAILED
```

# 76. Metrics

```text
human_task_created_total
human_task_open_total
human_task_completed_total
human_task_sla_breach_total
human_task_reassignment_total
human_task_delegation_total
human_task_escalation_total
human_task_claim_conflict_total
human_task_average_age_seconds
human_task_reconciliation_failure_total
```

# 77. KPIs

```text
Tasks without owner = 0
Tasks assigned outside tenant/scope = 0
Concurrent claim double-winner = 0
Completed tasks without evidence where required = 0
SLA breach without escalation = 0
Expired delegation still active = 0
Inactive assignee holding critical task = 0
```

# 78. KRIs

```text
SLA breach growth
Task aging
Reassignment frequency
Delegation depth
Queue overload
Critical-task backlog
Claim conflicts
Stuck blocked tasks
```

# 79. Database Direction

Potential tables:

```text
human_tasks
human_task_candidates
human_task_assignments
human_task_assignment_history
human_task_delegations
human_task_sla_states
human_task_escalations
human_task_comments
human_task_watchers
human_task_reconciliation_runs
human_task_reconciliation_findings
```

# 80. Table: human_tasks

```sql
CREATE TABLE human_tasks (
    id CHAR(26) NOT NULL,
    workflow_instance_id CHAR(26) NOT NULL,
    workflow_definition_version VARCHAR(100) NOT NULL,
    task_type VARCHAR(100) NOT NULL,
    tenant_id CHAR(26) NOT NULL,
    title VARCHAR(255) NOT NULL,
    status VARCHAR(30) NOT NULL,
    priority VARCHAR(20) NOT NULL,
    assignee_id CHAR(26) NULL,
    candidate_group_code VARCHAR(180) NULL,
    due_at DATETIME(6) NULL,
    task_version BIGINT UNSIGNED NOT NULL DEFAULT 1,
    created_at DATETIME(6) NOT NULL,
    completed_at DATETIME(6) NULL,

    PRIMARY KEY (id),
    KEY idx_human_task_inbox (
        tenant_id,
        assignee_id,
        status,
        due_at
    ),
    KEY idx_human_task_candidate (
        tenant_id,
        candidate_group_code,
        status
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

# 81. Table: human_task_assignments

```sql
CREATE TABLE human_task_assignments (
    id CHAR(26) NOT NULL,
    task_id CHAR(26) NOT NULL,
    assignment_type VARCHAR(40) NOT NULL,
    assignee_id CHAR(26) NULL,
    candidate_group_code VARCHAR(180) NULL,
    assigned_by CHAR(26) NULL,
    assignment_reason VARCHAR(500) NULL,
    effective_from DATETIME(6) NOT NULL,
    effective_to DATETIME(6) NULL,
    status VARCHAR(30) NOT NULL,

    PRIMARY KEY (id),
    KEY idx_human_task_assignment (
        task_id,
        status
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

# 82. Table: human_task_delegations

```sql
CREATE TABLE human_task_delegations (
    id CHAR(26) NOT NULL,
    tenant_id CHAR(26) NOT NULL,
    delegator_id CHAR(26) NOT NULL,
    delegate_id CHAR(26) NOT NULL,
    delegation_type VARCHAR(40) NOT NULL,
    task_type VARCHAR(100) NULL,
    effective_from DATETIME(6) NOT NULL,
    effective_to DATETIME(6) NOT NULL,
    status VARCHAR(30) NOT NULL,
    reason VARCHAR(500) NOT NULL,

    PRIMARY KEY (id),
    KEY idx_human_task_delegation_active (
        tenant_id,
        delegator_id,
        status,
        effective_from,
        effective_to
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

# 83. Table: human_task_sla_states

```sql
CREATE TABLE human_task_sla_states (
    id CHAR(26) NOT NULL,
    task_id CHAR(26) NOT NULL,
    sla_state VARCHAR(30) NOT NULL,
    response_due_at DATETIME(6) NULL,
    completion_due_at DATETIME(6) NULL,
    paused_at DATETIME(6) NULL,
    pause_reason VARCHAR(500) NULL,
    breached_at DATETIME(6) NULL,
    updated_at DATETIME(6) NOT NULL,

    PRIMARY KEY (id),
    UNIQUE KEY uq_human_task_sla (
        task_id
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

# 84. API Direction

```text
GET  /api/internal/v1/tasks/inbox
GET  /api/internal/v1/tasks/{taskId}
POST /api/internal/v1/tasks/{taskId}/claim
POST /api/internal/v1/tasks/{taskId}/release
POST /api/internal/v1/tasks/{taskId}/start
POST /api/internal/v1/tasks/{taskId}/complete
POST /api/internal/v1/tasks/{taskId}/delegate
POST /api/internal/v1/tasks/{taskId}/reassign
POST /api/internal/v1/tasks/{taskId}/escalate
POST /api/internal/v1/tasks/{taskId}/cancel
POST /api/internal/v1/tasks/reconciliation/runs
```

# 85. Error Codes

```text
HUMAN_TASK_NOT_FOUND
HUMAN_TASK_NOT_ELIGIBLE
HUMAN_TASK_ALREADY_CLAIMED
HUMAN_TASK_ASSIGNMENT_CONFLICT
HUMAN_TASK_SCOPE_MISMATCH
HUMAN_TASK_PERMISSION_DENIED
HUMAN_TASK_DELEGATION_INVALID
HUMAN_TASK_SLA_INVALID
HUMAN_TASK_STALE_VERSION
HUMAN_TASK_COMPLETION_INVALID
HUMAN_TASK_RECONCILIATION_FAILED
```

# 86. Assignment Checklist

- [ ] Task active.
- [ ] Candidate active.
- [ ] Tenant/scope match.
- [ ] Permission valid.
- [ ] Availability checked.
- [ ] Workload checked.
- [ ] Duty conflict checked.
- [ ] Assignment type recorded.
- [ ] SLA impact evaluated.
- [ ] Audit generated.

# 87. Completion Checklist

- [ ] Correct assignee.
- [ ] Task state valid.
- [ ] Task version current.
- [ ] Required fields complete.
- [ ] Evidence attached.
- [ ] Outcome selected.
- [ ] Workflow transition valid.
- [ ] SLA finalized.
- [ ] Event emitted.
- [ ] Audit generated.

# 88. UAT — Inbox & Security

- [ ] Personal inbox shows assigned tasks.
- [ ] Team inbox shows eligible tasks.
- [ ] Tenant A cannot see Tenant B tasks.
- [ ] Scope filter works.
- [ ] Unauthorized task hidden.
- [ ] Sensitive fields masked.
- [ ] Search respects task access.
- [ ] Mobile inbox matches web permissions.
- [ ] Audit generated.

# 89. UAT — Claiming & Assignment

- [ ] Eligible user claims task.
- [ ] Ineligible user denied.
- [ ] Concurrent claim yields one winner.
- [ ] Release returns task to pool.
- [ ] Direct assignment works.
- [ ] Reassignment records history.
- [ ] Inactive user cannot receive task.
- [ ] Workload limit enforced.
- [ ] Maker-checker conflict blocked.

# 90. UAT — Delegation

- [ ] Valid delegation works.
- [ ] Cross-tenant delegation blocked.
- [ ] Circular delegation blocked.
- [ ] Excessive depth blocked.
- [ ] Date-range delegation expires.
- [ ] Out-of-office routing works.
- [ ] Prohibited task type not delegated.
- [ ] Delegation history retained.
- [ ] Audit complete.

# 91. UAT — SLA & Escalation

- [ ] SLA clock calculates correctly.
- [ ] Business hours applied.
- [ ] Pause/resume works.
- [ ] Warning threshold triggers.
- [ ] Breach triggers escalation.
- [ ] Escalation reassigns where configured.
- [ ] Critical task creates incident.
- [ ] Exception requires approval.
- [ ] Metrics update.

# 92. UAT — Workload Balancing

- [ ] Round robin skips unavailable users.
- [ ] Least-loaded routing uses weighted load.
- [ ] Skills-based routing matches requirements.
- [ ] Shift rules applied.
- [ ] Protected critical capacity preserved.
- [ ] Overloaded queue triggers alert.
- [ ] Manual override audited.
- [ ] Tenant isolation preserved.

# 93. UAT — Completion & Concurrency

- [ ] Valid completion advances workflow.
- [ ] Missing evidence blocks completion.
- [ ] Unauthorized completion denied.
- [ ] Stale task version rejected.
- [ ] Duplicate completion idempotent.
- [ ] Rejection routes correctly.
- [ ] Return to prior stage works.
- [ ] Cancelled task cannot complete.
- [ ] Event emitted once.

# 94. UAT — Reconciliation

- [ ] Missing task detected.
- [ ] Orphan task detected.
- [ ] Inactive assignee detected.
- [ ] Scope mismatch detected.
- [ ] Missing inbox projection detected.
- [ ] Expired delegation detected.
- [ ] Missing SLA timer detected.
- [ ] Missing escalation detected.
- [ ] Completed task still open detected.
- [ ] Critical finding opens incident.

# 95. Definition of Done — SSOT-WF-06

SSOT-WF-06 dianggap selesai bila:

- [ ] task identity/lifecycle tersedia;
- [ ] personal/team inbox tersedia;
- [ ] candidate/assignment models tersedia;
- [ ] atomic claiming tersedia;
- [ ] release/reassignment tersedia;
- [ ] delegation governance tersedia;
- [ ] SLA and calendar tersedia;
- [ ] escalation matrix tersedia;
- [ ] workload/capacity tersedia;
- [ ] availability/shift awareness tersedia;
- [ ] duty-conflict controls tersedia;
- [ ] completion/rejection/return tersedia;
- [ ] comments/attachments/watchers tersedia;
- [ ] optimistic locking tersedia;
- [ ] task events tersedia;
- [ ] reconciliation tersedia;
- [ ] audit and metrics tersedia;
- [ ] database direction tersedia;
- [ ] API direction tersedia;
- [ ] SDK contracts tersedia;
- [ ] UAT and DoD tersedia.

# 96. Implementation Roadmap

## Phase 1 — Human Task Foundation

- task registry;
- lifecycle;
- candidate groups;
- assignment records;
- inbox APIs;
- audit events.

## Phase 2 — Claiming & Delegation

- atomic claim;
- release;
- reassignment;
- delegation;
- out-of-office routing;
- version locking.

## Phase 3 — SLA & Escalation

- SLA calendars;
- pause/resume;
- warning/breach;
- escalation matrix;
- notifications;
- incident integration.

## Phase 4 — Workload & Skills

- workload scoring;
- capacity;
- round robin;
- least-loaded;
- skills routing;
- shift awareness.

## Phase 5 — Intelligent Workforce Operations

- predictive workload;
- dynamic assignment;
- anomaly detection;
- automated rebalancing;
- continuous reconciliation;
- workforce dashboard.

# 97. Initial Implementation Backlog

```text
WF06-001 Human Task Registry
WF06-002 Task Candidate Registry
WF06-003 Personal/Team Inbox
WF06-004 Atomic Claim Service
WF06-005 Reassignment Service
WF06-006 Delegation Service
WF06-007 Out-of-Office Routing
WF06-008 SLA Calendar Service
WF06-009 Escalation Engine
WF06-010 Workload Calculator
WF06-011 Skills-Based Router
WF06-012 Shift Availability Resolver
WF06-013 Duty Conflict Guard
WF06-014 Task Event Publisher
WF06-015 Reconciliation Engine
WF06-016 Workforce Operations Dashboard
```

# 98. Approval Gate

Dokumen dapat menjadi Approved setelah:

- Workflow Architecture review;
- RBAC/Scope review;
- Business Operations review;
- HR/Workforce review where applicable;
- Security and Privacy review;
- Audit/Compliance review;
- Operations review;
- Quality Engineering review;
- UAT review.

# 99. Closing Statement

Human task adalah operational commitment.

Task tidak boleh kehilangan owner, assignee, SLA, scope, atau audit trail.

Claiming harus atomic.

Delegation harus terkontrol.

Escalation harus deterministic.

Workload harus terlihat dan dapat direkonsiliasi.
