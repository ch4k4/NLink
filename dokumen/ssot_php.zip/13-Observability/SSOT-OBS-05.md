# SSOT-OBS-05 — Health Check Framework

> Single Source of Truth untuk arsitektur, implementasi, interface, keamanan, operasi, dan pengujian Health Check Framework pada Platform Kernel.

## Metadata Dokumen

| Item | Nilai |
|---|---|
| Kode | SSOT-OBS-05 |
| Judul | Health Check Framework |
| Versi | 1.0 |
| Status | Draft for Review |
| Domain | Platform Kernel |
| Kategori | Observability |
| Target Stack | PHP 8.1+, PDO, MySQL 8/MariaDB, Apache/XAMPP, Modular Monolith |
| Bergantung pada | SSOT-OBS-01, SSOT-OBS-02, SSOT-OBS-03, SSOT-OBS-04 |
| Pemilik | Platform Architecture, Platform Operations, Security |
| Reviewer | Backend Engineering, DevOps, QA, Security |

## Tujuan Dokumen

Dokumen ini menetapkan standar tunggal untuk:

- model status dan criticality;
- Health Provider;
- registry, manager, executor, dan aggregator;
- caching dan persistence;
- database schema;
- endpoint `/live`, `/ready`, `/health`, dan internal diagnostics;
- authentication, permission, scope, dan sanitasi;
- CLI, scheduler, deployment, incident handling, dan UAT.

## Daftar Isi

1. Bagian I — Arsitektur dan Health Model
2. Bagian II.A — Database, Storage, dan Queue Providers
3. Bagian II.B — Scheduler, Workflow, dan Event Bus Providers
4. Bagian II.C — Notification, Integration, dan Search Providers
5. Bagian II.D — Module, Tenant, Scope, dan Security Providers
6. Bagian III — Core Implementation dan Database Design
7. Bagian IV — HTTP Endpoints, Security, dan Routing
8. Bagian V — Reference Implementation dan Operational Readiness

## Status Normatif

Kata **wajib**, **harus**, dan **tidak boleh** menyatakan persyaratan normatif. Kata **direkomendasikan**, **sebaiknya**, dan **dapat** menyatakan panduan yang dapat disesuaikan melalui keputusan arsitektur terdokumentasi.

---

## Bagian I — Arsitektur dan Health Model

### 1. Executive Summary

Platform Enterprise bukan hanya harus berjalan.

Platform harus mampu membuktikan dirinya sehat.

Health Check Framework menyediakan mekanisme standar untuk menentukan kondisi seluruh Platform Kernel secara otomatis.

Health Check bukan sekadar endpoint `GET /health`, tetapi sebuah framework yang mampu mengevaluasi kondisi Platform, Module, Database, Storage, Workflow, Queue, Scheduler, Notification, Event Bus, Integration, Search, API, Security, Tenant, dan Business Entity secara konsisten.

Health Check menjadi fondasi bagi:

- Monitoring
- Dashboard
- Alerting
- Auto Recovery
- Deployment
- Load Balancer
- CI/CD
- SLA Monitoring

---

### 2. Problem Statement

Sebagian besar aplikasi hanya memiliki endpoint sederhana seperti:

```text
GET /health
{
  "status":"UP"
}
```

Informasi tersebut tidak cukup.

Misalnya database masih hidup tetapi Queue, Scheduler, atau Integration gagal. Framework ini dirancang agar mampu mendeteksi kondisi tersebut secara akurat.

---

### 3. Tujuan Framework

Framework ini harus mampu menjawab:

- Apakah Platform sehat?
- Modul mana yang bermasalah?
- Dependency mana yang gagal?
- Seberapa parah dampaknya?
- Apakah aplikasi masih boleh menerima request?
- Apakah perlu mengirim alert?
- Apakah deployment boleh dilanjutkan?

---

### 4. Design Goals

Framework harus:

- Independent
- Extensible
- Lightweight
- Predictable
- Machine Readable
- Human Readable
- Vendor Independent

---

### 5. High Level Architecture

```text
Browser / Mobile
        │
        ▼
Health Endpoint
        │
        ▼
Health Check Manager
        │
 ┌──────┼──────────────┐
 ▼      ▼              ▼
Database Storage     Queue
 ▼      ▼              ▼
Workflow Notification Integration
        │
        ▼
Health Aggregator
        │
        ▼
JSON Response
        │
        ▼
Dashboard / Monitoring
```

---

### 6. Komponen Framework

Framework terdiri dari:

- Health Endpoint
- Health Manager
- Health Registry
- Health Provider
- Dependency Checker
- Health Aggregator
- Health Response

Setiap provider hanya bertanggung jawab terhadap satu komponen.

---

### 7. Health State Model

Status standar:

| Status | Arti |
|---|---|
| UP | Berfungsi normal |
| DEGRADED | Masih berjalan namun performa menurun |
| DOWN | Tidak dapat digunakan |
| UNKNOWN | Belum dapat dipastikan |
| MAINTENANCE | Sengaja dinonaktifkan |

---

### 8. Severity Mapping

| Health | Severity |
|---|---|
| UP | INFO |
| DEGRADED | WARNING |
| DOWN | ERROR |
| UNKNOWN | WARNING |
| MAINTENANCE | NOTICE |

---

### 9. Critical Component

Komponen berikut dianggap kritikal:

- Database
- Authentication
- Scope
- RBAC
- Workflow Engine
- Event Outbox
- API Gateway

Jika salah satu gagal maka status platform minimal menjadi DEGRADED.

---

### 10. Health Dependency Matrix

| Komponen | Bergantung pada |
|---|---|
| Workflow | Database |
| Notification | Queue |
| Integration | Network, Database |
| Event Bus | Database, Outbox |
| Search | Database, Event |
| Scheduler | Database |

Health Framework harus memperhitungkan dependency tersebut saat menghitung status akhir platform.

---

### 11. Prinsip

Health Check:

- tidak mengubah data;
- tidak menjalankan transaksi bisnis;
- tidak mengirim notifikasi;
- tidak mempublikasikan event;
- bersifat read-only;
- ringan dan aman dijalankan berkala.

---

---

## Bagian II.A — Database, Storage, dan Queue Providers

### 1. Tujuan

Health Provider adalah komponen yang bertanggung jawab memeriksa **satu dependency** secara independen.

Aturan utama:

- satu provider hanya memeriksa satu komponen;
- provider tidak mengubah data;
- provider harus ringan dan idempotent;
- provider mengembalikan objek HealthResult yang seragam.

---

### 2. Kontrak Provider

Semua provider mengikuti kontrak logis berikut:

```text
HealthProvider
 ├── name()
 ├── check()
 └── critical()
```

Hasil pemeriksaan:

```text
HealthResult
 ├── component
 ├── status
 ├── duration_ms
 ├── message
 ├── details
 └── checked_at
```

---

### 3. Database Health Provider

#### Tujuan

Memastikan database tersedia, dapat menerima koneksi, dan mampu menjalankan query sederhana.

#### Pemeriksaan Minimum

- koneksi berhasil;
- `SELECT 1` berhasil;
- transaksi dapat dibuka dan dibatalkan;
- latency berada di bawah ambang batas.

#### Status

##### UP

- koneksi berhasil;
- query < 100 ms.

##### DEGRADED

- koneksi berhasil;
- query lambat (misalnya > 500 ms).

##### DOWN

- koneksi gagal;
- timeout;
- transaksi gagal dibuat.

#### Contoh JSON

```json
{
  "component":"database",
  "status":"UP",
  "latency_ms":18
}
```

#### Catatan Implementasi PHP

Gunakan koneksi PDO yang sama dengan aplikasi. Jangan membuka banyak koneksi baru hanya untuk health check.

---

### 4. Storage Health Provider

#### Tujuan

Memastikan storage aplikasi dapat digunakan.

Yang diperiksa:

- folder tersedia;
- writable;
- ruang penyimpanan cukup;
- operasi tulis/hapus file sementara berhasil.

#### Komponen

- storage/logs
- storage/cache
- storage/temp
- storage/files

#### Status

UP:
- seluruh direktori tersedia dan writable.

DEGRADED:
- ruang hampir habis atau salah satu direktori lambat.

DOWN:
- tidak dapat menulis file.

#### Contoh JSON

```json
{
  "component":"storage",
  "status":"UP",
  "free_space_percent":72
}
```

---

### 5. Queue Health Provider

#### Tujuan

Memastikan antrean pekerjaan latar belakang dapat diproses.

#### Pemeriksaan

- worker aktif;
- backlog tidak melebihi ambang;
- retry tidak berlebihan;
- tidak ada dead queue yang meningkat.

#### KPI

- pending_jobs
- failed_jobs
- retry_jobs
- average_wait_seconds

#### Status

UP:
- backlog normal.

DEGRADED:
- backlog meningkat tetapi masih diproses.

DOWN:
- worker berhenti atau antrean tidak bergerak.

#### Contoh JSON

```json
{
  "component":"queue",
  "status":"DEGRADED",
  "pending_jobs":128,
  "failed_jobs":0
}
```

---

### 6. Dependency Rule

Queue dapat bergantung pada:

- Database (table queue/outbox)
- Message broker (future)

Jika dependency gagal, provider harus mencerminkan dampaknya pada status.

---

### 7. Health Aggregation

Contoh:

| Komponen | Status |
|---|---|
| Database | UP |
| Storage | UP |
| Queue | DEGRADED |

Hasil agregasi:

```text
Platform = DEGRADED
```

Karena queue merupakan komponen operasional penting.

---

### 8. Anti-pattern

Hindari:

- query berat pada health check;
- operasi INSERT/UPDATE permanen;
- menghapus data produksi;
- membuka koneksi berulang tanpa reuse;
- menjalankan pemeriksaan yang memakan waktu lama pada setiap request.

---

### 9. UAT

- [ ] Database UP saat koneksi normal.
- [ ] Database DOWN saat layanan dimatikan.
- [ ] Storage DOWN saat direktori tidak writable.
- [ ] Queue DEGRADED saat backlog melewati threshold.
- [ ] Waktu eksekusi seluruh provider < 200 ms pada lingkungan lokal.

---

---

## Bagian II.B — Scheduler, Workflow, dan Event Bus Providers

### 1. Pendahuluan

Bagian ini mendefinisikan provider untuk komponen inti Platform Kernel:

- Scheduler
- Workflow Engine
- Event Bus

Masing-masing provider hanya memeriksa satu komponen dan tidak boleh mengubah data bisnis.

---

### 2. Scheduler Health Provider

#### Tujuan

Memastikan seluruh scheduled job berjalan sesuai jadwal.

#### Pemeriksaan

- Scheduler process aktif
- Heartbeat terakhir masih dalam ambang batas
- Tidak ada job yang macet
- Tidak ada job gagal berulang

#### KPI

- scheduler_last_heartbeat
- scheduled_job_success_total
- scheduled_job_failed_total
- overdue_jobs

#### Status

**UP**
- heartbeat normal
- tidak ada overdue job

**DEGRADED**
- heartbeat terlambat
- terdapat overdue job dalam batas toleransi

**DOWN**
- scheduler berhenti
- heartbeat hilang
- seluruh job gagal dijalankan

#### Contoh

```json
{
  "component":"scheduler",
  "status":"UP",
  "heartbeat_seconds":12,
  "overdue_jobs":0
}
```

---

### 3. Workflow Health Provider

#### Tujuan

Memastikan Workflow Engine dapat memproses transisi state.

#### Pemeriksaan

- workflow engine aktif
- transition berhasil
- approval queue normal
- workflow timeout dalam batas

#### KPI

- workflow_started_total
- workflow_completed_total
- workflow_failed_total
- workflow_timeout_total
- approval_duration_ms

#### Status

**UP**
- workflow diproses normal

**DEGRADED**
- approval lambat
- antrean meningkat

**DOWN**
- workflow engine gagal
- transition tidak dapat dijalankan

#### Dependency

Workflow bergantung pada:

- Database
- Event Bus
- Notification (opsional)

Jika Database DOWN maka Workflow minimal DEGRADED.

---

### 4. Event Bus Health Provider

#### Tujuan

Memastikan seluruh domain event dapat dipublikasikan.

#### Pemeriksaan

- outbox terbaca
- publisher aktif
- retry normal
- failed publish rendah

#### KPI

- event_published_total
- event_failed_total
- outbox_pending_total
- retry_total
- average_publish_latency_ms

#### Status

**UP**
- event diproses normal

**DEGRADED**
- retry meningkat
- pending event bertambah

**DOWN**
- publisher berhenti
- outbox tidak diproses

#### Contoh

```json
{
  "component":"event_bus",
  "status":"DEGRADED",
  "pending_events":37,
  "failed_events":0
}
```

---

### 5. Aggregation Rule

| Scheduler | Workflow | Event Bus | Platform |
|---|---|---|---|
| UP | UP | UP | UP |
| UP | DEGRADED | UP | DEGRADED |
| UP | UP | DOWN | DEGRADED |
| DOWN | DOWN | DOWN | DOWN |

Health Aggregator harus mempertimbangkan tingkat kekritisan setiap komponen.

---

### 6. Logging

Setiap provider menghasilkan structured log:

- component
- status
- duration_ms
- correlation_id
- checked_at

Perubahan status harus dicatat sebagai WARNING atau ERROR.

---

### 7. Anti-pattern

Hindari:

- health check menjalankan workflow nyata;
- mempublikasikan event produksi untuk pengujian;
- menjalankan scheduler dari endpoint health;
- query berat pada setiap pemeriksaan.

---

### 8. UAT

- [ ] Scheduler berubah DOWN saat heartbeat hilang.
- [ ] Workflow menjadi DEGRADED saat approval backlog meningkat.
- [ ] Event Bus menjadi DOWN saat publisher dimatikan.
- [ ] Dashboard menampilkan status ketiga provider.
- [ ] Semua provider selesai diperiksa dalam batas waktu yang ditentukan.

---

## Bagian II.C — Notification, Integration, dan Search Providers

### 1. Pendahuluan

Bagian ini mendefinisikan Health Provider untuk layanan pendukung Platform Kernel:

- Notification Framework;
- External Integration Framework;
- Search & Indexing.

Ketiga provider ini tidak selalu menentukan apakah aplikasi sepenuhnya mati, tetapi kegagalannya dapat menurunkan kualitas layanan secara signifikan.

---

### 2. Notification Health Provider

#### 2.1 Tujuan

Memastikan Notification Framework mampu:

- membuat notification message;
- mengantrikan delivery;
- memproses delivery;
- menghubungi provider;
- mencatat hasil pengiriman;
- menjalankan retry bila diperlukan.

#### 2.2 Pemeriksaan Minimum

Provider memeriksa:

- notification queue tersedia;
- worker notification aktif;
- delivery backlog;
- jumlah failure terbaru;
- retry masih berjalan;
- provider utama dapat diakses;
- credential provider belum kedaluwarsa;
- template aktif tersedia untuk event kritis.

#### 2.3 KPI

```text
notification_queued_total
notification_sent_total
notification_failed_total
notification_retry_total
notification_pending_total
notification_oldest_pending_seconds
notification_provider_latency_ms
notification_provider_error_rate
```

#### 2.4 Status

##### UP

- worker aktif;
- backlog normal;
- provider utama responsif;
- failure rate di bawah threshold;
- credential aktif.

##### DEGRADED

- backlog meningkat;
- satu provider gagal tetapi fallback tersedia;
- latency provider tinggi;
- retry meningkat;
- sebagian channel tidak tersedia.

##### DOWN

- seluruh worker notification berhenti;
- seluruh provider utama gagal;
- credential utama invalid atau expired;
- delivery tidak bergerak;
- event kritis tidak dapat dikirim.

#### 2.5 Contoh JSON

```json
{
  "component": "notification",
  "status": "DEGRADED",
  "pending_deliveries": 84,
  "failed_deliveries_last_hour": 7,
  "available_channels": [
    "in_app",
    "email"
  ],
  "unavailable_channels": [
    "whatsapp"
  ],
  "oldest_pending_seconds": 420
}
```

#### 2.6 Dependency

Notification bergantung pada:

- Database;
- Queue;
- Scheduler untuk reminder/retry;
- Template Engine;
- external provider untuk email, SMS, WhatsApp, atau push.

Jika Queue DOWN, status Notification minimal DEGRADED.

Jika seluruh provider eksternal DOWN tetapi in-app masih tersedia, status dapat DEGRADED.

#### 2.7 Aturan Keamanan

Health response tidak boleh menampilkan:

- API key provider;
- client secret;
- nomor telepon atau email recipient;
- raw provider response sensitif;
- payload notifikasi.

---

### 3. Integration Health Provider

#### 3.1 Tujuan

Memastikan External Integration Framework mampu berkomunikasi dengan sistem eksternal secara andal.

Contoh connector:

- SATUSEHAT;
- BPJS;
- payment gateway;
- WhatsApp provider;
- ERP;
- marketplace;
- partner API.

#### 3.2 Pemeriksaan Minimum

Provider memeriksa:

- connector aktif;
- credential valid;
- endpoint reachable;
- circuit breaker status;
- request backlog;
- retry backlog;
- dead-letter count;
- last successful request;
- sync state terbaru;
- rate limit provider.

#### 3.3 KPI

```text
integration_request_total
integration_success_total
integration_failure_total
integration_retry_total
integration_dead_letter_total
integration_pending_total
integration_latency_ms
integration_success_rate
integration_last_success_age_seconds
```

#### 3.4 Status

##### UP

- connector utama aktif;
- endpoint reachable;
- credential valid;
- success rate di atas threshold;
- tidak ada backlog berbahaya.

##### DEGRADED

- provider lambat;
- circuit breaker half-open;
- retry meningkat;
- sebagian endpoint gagal;
- last successful sync terlalu lama;
- rate limit mendekati batas.

##### DOWN

- provider utama tidak dapat diakses;
- credential invalid;
- circuit breaker open terus-menerus;
- seluruh request gagal;
- backlog tidak bergerak;
- sinkronisasi wajib berhenti total.

#### 3.5 Contoh JSON

```json
{
  "component": "integration",
  "status": "DEGRADED",
  "connectors": {
    "satusehat": "UP",
    "bpjs": "DOWN",
    "payment_gateway": "UP"
  },
  "pending_requests": 23,
  "dead_letter_count": 2,
  "average_latency_ms": 1180
}
```

#### 3.6 Dependency

Integration bergantung pada:

- Database;
- Event Bus;
- Outbox;
- Queue;
- Scheduler;
- Network;
- Credential Store;
- API Gateway bila inbound.

#### 3.7 Circuit Breaker Awareness

Provider harus membaca status circuit breaker:

```text
closed
half_open
open
```

Interpretasi:

- `closed` = normal;
- `half_open` = DEGRADED;
- `open` = DOWN atau DEGRADED tergantung criticality connector.

#### 3.8 Criticality Per Connector

Setiap connector memiliki level:

```text
critical
important
optional
```

Contoh:

- payment gateway untuk pembayaran aktif = critical;
- SATUSEHAT untuk sinkronisasi regulator = important/critical sesuai kebijakan;
- marketing provider = optional.

Status akhir Integration harus memperhitungkan criticality.

#### 3.9 Aturan Keamanan

Health response tidak boleh menampilkan:

- full endpoint URL jika sensitif;
- credential reference internal;
- token;
- request/response payload PHI;
- detail autentikasi partner.

---

### 4. Search Health Provider

#### 4.1 Tujuan

Memastikan Search & Indexing mampu menerima update index dan melayani query pencarian.

#### 4.2 Pemeriksaan Minimum

Provider memeriksa:

- search engine tersedia;
- index aktif tersedia;
- alias menunjuk index yang benar;
- indexing worker aktif;
- indexing lag;
- failed indexing jobs;
- rebuild status;
- query latency;
- index storage usage.

#### 4.3 KPI

```text
search_query_total
search_query_error_total
search_query_latency_ms
search_index_update_total
search_index_failed_total
search_index_lag_seconds
search_rebuild_status
search_index_size_bytes
```

#### 4.4 Status

##### UP

- search engine reachable;
- active index tersedia;
- alias valid;
- indexing lag dalam batas;
- query latency normal.

##### DEGRADED

- indexing lag meningkat;
- rebuild sedang berjalan;
- query latency tinggi;
- sebagian index gagal;
- fallback database search aktif.

##### DOWN

- search engine tidak tersedia;
- active index hilang;
- alias rusak;
- seluruh query gagal;
- indexing worker berhenti total.

#### 4.5 Contoh JSON

```json
{
  "component": "search",
  "status": "UP",
  "engine": "mysql_fulltext",
  "active_indexes": 6,
  "failed_index_jobs": 0,
  "index_lag_seconds": 12,
  "average_query_latency_ms": 34
}
```

#### 4.6 Dependency

Search bergantung pada:

- Database;
- Event Bus;
- Outbox;
- Index Worker;
- Search Engine/Adapter;
- File metadata bila file search aktif.

#### 4.7 Fallback Behavior

Jika search engine eksternal gagal tetapi fallback query database tersedia:

```text
status = DEGRADED
```

Bukan langsung DOWN, selama pencarian dasar tetap berfungsi.

#### 4.8 Healthcare Privacy

Health check tidak boleh:

- menjalankan pencarian memakai nama pasien nyata;
- menampilkan contoh PHI;
- menampilkan indexed document content;
- membocorkan jumlah pasien spesifik bila endpoint publik.

Gunakan query sintetis atau metadata index.

---

### 5. Aggregation Rule

Contoh:

| Notification | Integration | Search | Supporting Services |
|---|---|---|---|
| UP | UP | UP | UP |
| DEGRADED | UP | UP | DEGRADED |
| UP | DOWN (optional) | UP | DEGRADED |
| UP | DOWN (critical) | UP | DOWN/DEGRADED |
| UP | UP | DOWN dengan fallback | DEGRADED |
| DOWN | DOWN | DOWN | DOWN |

Status akhir bergantung pada criticality masing-masing provider dan availability fallback.

---

### 6. Threshold Configuration

Threshold tidak boleh hardcoded.

Contoh konfigurasi:

```php
return [
    'notification' => [
        'pending_warning' => 100,
        'pending_down' => 1000,
        'failure_rate_warning' => 0.05,
    ],
    'integration' => [
        'latency_warning_ms' => 2000,
        'failure_rate_warning' => 0.10,
        'dead_letter_warning' => 1,
    ],
    'search' => [
        'lag_warning_seconds' => 300,
        'latency_warning_ms' => 500,
        'failed_jobs_warning' => 10,
    ],
];
```

---

### 7. Logging

Setiap provider menghasilkan structured log dengan field minimum:

```text
component
status
previous_status
duration_ms
thresholds
correlation_id
checked_at
```

Perubahan status harus menghasilkan log:

```text
INFO untuk UP
WARNING untuk DEGRADED
ERROR untuk DOWN
```

---

### 8. Metrics Integration

Setiap hasil health check dapat menghasilkan metric:

```text
health_component_status
health_check_duration_ms
health_check_failure_total
health_component_degraded_total
```

Mapping status numerik:

```text
UP = 1
DEGRADED = 0.5
DOWN = 0
UNKNOWN = -1
MAINTENANCE = 0.25
```

Mapping numerik hanya untuk metric, bukan untuk response publik.

---

### 9. Timeout

Setiap provider harus memiliki timeout.

Rekomendasi lokal:

```text
Notification: 500 ms
Integration lightweight check: 1000–3000 ms
Search: 500 ms
```

Pemeriksaan eksternal yang berat harus dijalankan secara asynchronous dan dibaca dari last known health.

---

### 10. Cached Health Result

Untuk menghindari request eksternal pada setiap `/health`:

- simpan hasil health terakhir;
- tentukan TTL;
- jalankan deep check via scheduler;
- endpoint hanya membaca hasil cache untuk komponen mahal.

Contoh TTL:

```text
Notification: 30 detik
Integration: 60 detik
Search: 30 detik
```

---

### 11. Anti-pattern

Hindari:

- mengirim notifikasi nyata saat health check;
- memanggil endpoint transaksi provider;
- membuat data pasien/customer palsu di production;
- melakukan full index rebuild dari endpoint health;
- menampilkan credential/provider secret;
- menjadikan kegagalan provider optional sebagai status platform DOWN;
- tidak membedakan connector critical dan optional.

---

### 12. UAT

#### Notification

- [ ] Status UP saat worker dan provider normal.
- [ ] Status DEGRADED saat WhatsApp gagal tetapi email aktif.
- [ ] Status DOWN saat seluruh worker berhenti.
- [ ] Credential expired terdeteksi.

#### Integration

- [ ] Connector reachable menghasilkan UP.
- [ ] Circuit breaker half-open menghasilkan DEGRADED.
- [ ] Connector critical DOWN memengaruhi status platform.
- [ ] Dead-letter count tampil tanpa payload sensitif.

#### Search

- [ ] Search engine aktif menghasilkan UP.
- [ ] Indexing lag tinggi menghasilkan DEGRADED.
- [ ] Engine gagal tetapi fallback aktif menghasilkan DEGRADED.
- [ ] Alias index rusak menghasilkan DOWN.

#### General

- [ ] Semua provider mematuhi timeout.
- [ ] Tidak ada PHI/PII/secret pada response.
- [ ] Perubahan status menghasilkan log dan metric.
- [ ] Pemeriksaan tidak menghasilkan side effect bisnis.

---

### 13. Definition of Done Part 2C

Part 2C dianggap selesai bila:

- Notification Health Provider didefinisikan;
- Integration Health Provider didefinisikan;
- Search Health Provider didefinisikan;
- status dan threshold terdokumentasi;
- dependency dan criticality jelas;
- fallback behavior tersedia;
- security/privacy rule tersedia;
- UAT tersedia;
- dapat diintegrasikan ke Health Registry dan Health Aggregator.

---

---

## Bagian II.D — Module, Tenant, Scope, dan Security Providers

### 1. Pendahuluan

Bagian ini mendefinisikan Health Provider yang memeriksa kesehatan platform dari perspektif struktur aplikasi, tenant, scope, dan kontrol keamanan.

Provider yang dibahas:

- Module Health Provider;
- Tenant Health Provider;
- Scope Health Provider;
- Security Health Provider.

Keempat provider ini penting karena sebuah aplikasi dapat terlihat hidup secara teknis, tetapi sebenarnya tidak sehat secara arsitektural atau operasional.

Contoh:

- module aktif tetapi migration belum lengkap;
- tenant aktif tetapi konfigurasi wajib belum tersedia;
- scope assignment rusak;
- kontrol keamanan kritis dinonaktifkan.

---

### 2. Prinsip Umum

Setiap provider wajib:

- bersifat read-only;
- tidak memperbaiki data secara otomatis;
- menggunakan threshold/configuration;
- tidak membocorkan konfigurasi sensitif;
- menghasilkan HealthResult yang seragam;
- mendukung pemeriksaan per komponen maupun agregat;
- mencatat perubahan status melalui structured logging;
- menghasilkan metric observability.

---

### 3. Module Health Provider

#### 3.1 Tujuan

Memastikan setiap module yang diregistrasikan pada Platform Kernel berada dalam kondisi konsisten dan dapat digunakan.

Module yang sehat harus memiliki:

- registration metadata;
- migration sesuai versi;
- service provider/bootstrapping aktif;
- route terdaftar;
- permission tersedia;
- menu registration valid bila diperlukan;
- dependency module terpenuhi;
- konfigurasi wajib tersedia;
- health provider module dapat dijalankan bila didefinisikan.

#### 3.2 Pemeriksaan Minimum

Provider memeriksa:

- module terdaftar;
- module status aktif/inaktif jelas;
- module version tersedia;
- migration module lengkap;
- dependency module tersedia;
- konfigurasi wajib tersedia;
- route registration berhasil;
- permission registration berhasil;
- event subscriber terdaftar bila diperlukan;
- menu registration valid;
- module bootstrap tidak menghasilkan exception.

#### 3.3 KPI

```text
module_registered_total
module_active_total
module_inactive_total
module_failed_total
module_missing_dependency_total
module_pending_migration_total
module_bootstrap_error_total
```

#### 3.4 Status

##### UP

- module aktif;
- dependency lengkap;
- migration sesuai;
- bootstrap berhasil;
- konfigurasi wajib tersedia.

##### DEGRADED

- module aktif tetapi fitur optional gagal;
- menu registration bermasalah;
- health check module optional gagal;
- migration non-kritis tertunda;
- dependency optional tidak tersedia.

##### DOWN

- dependency kritis hilang;
- bootstrap gagal;
- migration wajib belum diterapkan;
- service utama module tidak dapat di-resolve;
- route utama tidak terdaftar.

##### MAINTENANCE

- module sengaja dinonaktifkan untuk maintenance;
- status maintenance telah dikonfigurasi secara eksplisit.

#### 3.5 Contoh JSON

```json
{
  "component": "module",
  "status": "DEGRADED",
  "modules": {
    "IAM": "UP",
    "Workflow": "UP",
    "Search": "DEGRADED",
    "Reporting": "MAINTENANCE"
  },
  "pending_migrations": 2,
  "missing_dependencies": 0
}
```

#### 3.6 Dependency

Module Health bergantung pada:

- module registry;
- migration registry;
- service container;
- route registry;
- permission registry;
- configuration service.

#### 3.7 Criticality

Setiap module memiliki criticality:

```text
kernel_critical
business_critical
optional
```

Contoh:

- IAM = kernel_critical;
- RBAC = kernel_critical;
- Workflow = kernel_critical atau business_critical;
- Reporting = optional;
- Marketing = optional.

Status platform harus mempertimbangkan criticality module.

#### 3.8 Aturan Keamanan

Health response tidak boleh menampilkan:

- internal class path detail pada endpoint publik;
- stack trace;
- konfigurasi secret;
- full route map;
- internal permission dump.

---

### 4. Tenant Health Provider

#### 4.1 Tujuan

Memastikan setiap tenant memiliki konfigurasi minimum agar platform dapat digunakan secara benar.

Tenant yang sehat harus memiliki:

- tenant record aktif;
- organization/business entity minimum;
- admin aktif;
- konfigurasi dasar;
- timezone;
- locale;
- scope assignment;
- subscription/license bila digunakan;
- storage configuration;
- notification/integration configuration sesuai kebutuhan.

#### 4.2 Pemeriksaan Minimum

Provider memeriksa:

- status tenant;
- validitas periode tenant;
- organization tersedia;
- business entity tersedia;
- administrator aktif tersedia;
- default scope tersedia;
- default timezone tersedia;
- storage tenant tersedia;
- konfigurasi wajib tersedia;
- quota tidak terlampaui;
- fitur aktif sesuai subscription/policy;
- tidak ada konflik tenant identifier.

#### 4.3 KPI

```text
tenant_total
tenant_active_total
tenant_degraded_total
tenant_down_total
tenant_missing_admin_total
tenant_missing_scope_total
tenant_quota_exceeded_total
tenant_configuration_error_total
```

#### 4.4 Status

##### UP

- tenant aktif;
- konfigurasi minimum lengkap;
- admin dan scope tersedia;
- quota normal;
- storage tersedia.

##### DEGRADED

- fitur optional belum dikonfigurasi;
- quota mendekati batas;
- provider notification optional gagal;
- business entity tertentu bermasalah tetapi tenant masih dapat digunakan sebagian.

##### DOWN

- tenant suspended/expired;
- tidak memiliki default scope;
- tidak memiliki admin aktif;
- database/storage tenant tidak dapat digunakan;
- konfigurasi minimum rusak.

##### MAINTENANCE

- tenant sengaja ditempatkan dalam maintenance mode.

#### 4.5 Contoh JSON

```json
{
  "component": "tenant",
  "status": "DEGRADED",
  "tenant_id": 12,
  "checks": {
    "configuration": "UP",
    "default_scope": "UP",
    "administrator": "UP",
    "quota": "DEGRADED",
    "storage": "UP"
  },
  "quota_usage_percent": 92
}
```

#### 4.6 Multi-Tenant Aggregation

Endpoint agregat tidak boleh selalu menampilkan seluruh detail tenant.

Pilihan:

- platform admin: dapat melihat agregat seluruh tenant;
- tenant admin: hanya tenant sendiri;
- public health endpoint: hanya status platform global.

#### 4.7 Privacy

Jangan tampilkan:

- nama tenant pada endpoint publik;
- jumlah user/pasien/customer secara detail;
- configuration payload;
- billing/subscription detail sensitif;
- credential integration.

---

### 5. Scope Health Provider

#### 5.1 Tujuan

Memastikan Scope Engine dan data assignment bekerja secara konsisten.

Scope Health Provider memeriksa:

- hierarchy scope;
- active scope resolution;
- assignment;
- default scope;
- orphan scope;
- invalid binding;
- cross-scope policy;
- cache scope bila digunakan.

#### 5.2 Pemeriksaan Minimum

Provider memeriksa:

- root tenant scope tersedia;
- hierarchy tidak memiliki cycle;
- parent-child relation valid;
- default scope user valid;
- active scope dapat di-resolve;
- assignment mengacu ke resource aktif;
- tidak ada orphan scope;
- business entity relation konsisten;
- cross-scope grant belum expired;
- scope cache sinkron dengan database.

#### 5.3 KPI

```text
scope_total
scope_active_total
scope_orphan_total
scope_cycle_detected_total
scope_invalid_assignment_total
scope_expired_grant_total
scope_resolution_failure_total
scope_cache_mismatch_total
```

#### 5.4 Status

##### UP

- hierarchy valid;
- assignment valid;
- resolution normal;
- tidak ada orphan/cycle kritis.

##### DEGRADED

- terdapat assignment tidak kritis yang invalid;
- cache scope stale;
- cross-scope grant hampir expired;
- sebagian scope optional tidak dapat digunakan.

##### DOWN

- default scope tidak dapat di-resolve;
- hierarchy cycle kritis;
- tenant root scope hilang;
- seluruh permission evaluation gagal karena scope engine rusak.

#### 5.5 Contoh JSON

```json
{
  "component": "scope",
  "status": "DOWN",
  "root_scope_available": true,
  "orphan_scopes": 0,
  "invalid_assignments": 18,
  "cycle_detected": true,
  "resolution_failures_last_hour": 42
}
```

#### 5.6 Dependency

Scope Health bergantung pada:

- tenant;
- organization;
- business entity;
- user scope assignments;
- scope policy;
- cache;
- RBAC integration.

#### 5.7 Pemeriksaan Cycle

Hierarchy scope wajib bebas cycle.

Contoh invalid:

```text
Organization A
→ Business Entity B
→ Department C
→ Organization A
```

Cycle harus membuat status DOWN bila memengaruhi root hierarchy.

#### 5.8 Aturan Keamanan

Health response tidak boleh menampilkan seluruh hierarchy scope pada endpoint publik.

Gunakan summary:

```text
valid
invalid_count
orphan_count
cycle_detected
```

---

### 6. Security Health Provider

#### 6.1 Tujuan

Memastikan kontrol keamanan minimum Platform Kernel aktif dan berada dalam konfigurasi aman.

Provider ini bukan penetration test.

Provider hanya memeriksa posture/configuration dan indikator operasional keamanan.

#### 6.2 Pemeriksaan Minimum

Provider memeriksa:

- APP_DEBUG nonaktif pada production;
- HTTPS enforcement;
- secure session cookie;
- HttpOnly cookie;
- SameSite policy;
- CSRF aktif untuk web;
- password hashing algorithm valid;
- MFA policy untuk privileged user;
- secrets tidak memakai default value;
- encryption key tersedia;
- key rotation status;
- rate limiting aktif;
- audit trail aktif;
- failed login anomaly;
- privileged account aktif;
- API key/credential hampir expired;
- security headers aktif;
- file upload protection aktif;
- backup encryption bila diwajibkan.

#### 6.3 KPI

```text
security_control_total
security_control_failed_total
security_control_warning_total
privileged_account_without_mfa_total
expired_credential_total
failed_login_rate
security_header_missing_total
default_secret_detected_total
encryption_key_rotation_overdue_total
```

#### 6.4 Status

##### UP

- seluruh kontrol kritis aktif;
- tidak ada secret default;
- MFA privileged aktif;
- audit aktif;
- encryption key valid;
- rate limit aktif.

##### DEGRADED

- kontrol non-kritis tidak aktif;
- key rotation mendekati jatuh tempo;
- security header optional hilang;
- failed login meningkat tetapi masih dalam threshold.

##### DOWN

- production debug aktif;
- encryption key hilang;
- secret default terdeteksi;
- audit security mati;
- privileged access tanpa kontrol minimum;
- session cookie tidak aman pada production;
- seluruh rate limiting tidak aktif;
- credential kritis expired.

#### 6.5 Contoh JSON

```json
{
  "component": "security",
  "status": "DEGRADED",
  "critical_controls": {
    "debug_disabled": "UP",
    "audit_enabled": "UP",
    "encryption_key": "UP",
    "privileged_mfa": "UP",
    "rate_limit": "UP"
  },
  "warnings": {
    "key_rotation_due_days": 5,
    "missing_optional_headers": 1
  }
}
```

#### 6.6 Public Response Rule

Endpoint publik hanya boleh mengembalikan:

```json
{
  "component": "security",
  "status": "UP"
}
```

Detail kontrol hanya tersedia untuk role keamanan/admin melalui endpoint internal.

#### 6.7 Dependency

Security Health bergantung pada:

- IAM;
- MFA;
- session configuration;
- API Gateway;
- Audit;
- Secrets/Key Management;
- application configuration;
- web server configuration.

#### 6.8 Batasan

Security Health Provider tidak boleh:

- membaca secret dalam bentuk plain lalu menampilkannya;
- menjalankan serangan simulasi terhadap production;
- mencoba login brute force;
- menonaktifkan kontrol untuk pengujian;
- menggantikan vulnerability scan atau penetration test.

---

### 7. Aggregation Rule

Contoh:

| Module | Tenant | Scope | Security | Platform |
|---|---|---|---|---|
| UP | UP | UP | UP | UP |
| DEGRADED | UP | UP | UP | DEGRADED |
| UP | DEGRADED | UP | UP | DEGRADED |
| UP | UP | DOWN | UP | DOWN |
| UP | UP | UP | DOWN | DOWN |
| MAINTENANCE optional | UP | UP | UP | UP/DEGRADED |

Scope dan Security memiliki criticality tinggi.

Jika Scope DOWN:

```text
Platform = DOWN
```

Jika Security DOWN:

```text
Platform = DOWN
```

kecuali provider hanya mendeteksi kontrol non-kritis dan telah mengklasifikasikannya sebagai DEGRADED.

---

### 8. Threshold Configuration

Threshold wajib configurable.

Contoh:

```php
return [
    'module' => [
        'pending_migration_warning' => 1,
        'bootstrap_error_down' => 1,
    ],
    'tenant' => [
        'quota_warning_percent' => 85,
        'quota_down_percent' => 100,
    ],
    'scope' => [
        'invalid_assignment_warning' => 1,
        'cycle_down' => true,
    ],
    'security' => [
        'failed_login_rate_warning' => 20,
        'key_rotation_warning_days' => 14,
        'critical_control_failure_down' => true,
    ],
];
```

---

### 9. Cached vs Live Check

#### Live Check

Cocok untuk:

- config flag;
- module registry;
- root scope;
- basic security configuration.

#### Cached/Background Check

Cocok untuk:

- scope hierarchy cycle scan besar;
- seluruh tenant validation;
- credential expiry scan;
- privileged MFA compliance scan;
- migration consistency lintas module.

Scheduler menjalankan deep check dan endpoint membaca last known result.

---

### 10. Logging

Perubahan status provider harus dicatat.

Field minimum:

```text
component
status
previous_status
criticality
duration_ms
affected_count
correlation_id
checked_at
```

Level:

```text
UP = INFO
DEGRADED = WARNING
DOWN = ERROR/CRITICAL
MAINTENANCE = NOTICE
UNKNOWN = WARNING
```

---

### 11. Metrics Integration

Metric minimum:

```text
health_module_status
health_tenant_status
health_scope_status
health_security_status
health_invalid_scope_assignment_total
health_tenant_degraded_total
health_security_control_failure_total
health_module_pending_migration_total
```

Hindari label tenant_id untuk seluruh tenant jika cardinality terlalu tinggi.

Untuk metric agregat gunakan:

```text
tenant_status
criticality
module_code
control_code
```

dengan kontrol cardinality.

---

### 12. API Access Policy

#### Public

```text
GET /health
GET /live
```

Hanya status ringkas.

#### Internal Operations

```text
GET /internal/health/modules
GET /internal/health/tenants
GET /internal/health/scope
GET /internal/health/security
```

Wajib:

- authentication;
- permission;
- scope;
- audit;
- IP restriction bila perlu.

#### Permission

Contoh:

```text
observability.health.read
observability.health.detail.read
observability.health.security.read
observability.health.tenant.read
```

---

### 13. Anti-pattern

Hindari:

- menganggap module terdaftar berarti pasti sehat;
- memeriksa seluruh tenant secara live pada setiap request publik;
- menampilkan scope hierarchy lengkap;
- mengembalikan detail kontrol keamanan ke publik;
- menyimpan secret pada health result;
- menganggap warning security sebagai INFO biasa;
- mengubah konfigurasi otomatis dari endpoint health;
- menggabungkan health provider dengan repair job.

---

### 14. UAT

#### Module

- [ ] Module aktif dan lengkap menghasilkan UP.
- [ ] Migration wajib hilang menghasilkan DOWN.
- [ ] Dependency optional hilang menghasilkan DEGRADED.
- [ ] Module maintenance menghasilkan MAINTENANCE.

#### Tenant

- [ ] Tenant lengkap menghasilkan UP.
- [ ] Quota > warning threshold menghasilkan DEGRADED.
- [ ] Default scope hilang menghasilkan DOWN.
- [ ] Tenant maintenance tidak dianggap failure platform bila sesuai policy.

#### Scope

- [ ] Hierarchy valid menghasilkan UP.
- [ ] Orphan non-kritis menghasilkan DEGRADED.
- [ ] Cycle kritis menghasilkan DOWN.
- [ ] Cache mismatch terdeteksi.

#### Security

- [ ] Production debug aktif menghasilkan DOWN.
- [ ] Secret default terdeteksi menghasilkan DOWN.
- [ ] Key rotation mendekati jatuh tempo menghasilkan DEGRADED.
- [ ] Endpoint publik tidak menampilkan detail kontrol.
- [ ] Endpoint internal membutuhkan permission khusus.

#### General

- [ ] Semua provider memiliki timeout.
- [ ] Semua hasil menghasilkan log/metric.
- [ ] Tidak ada secret/PII/PHI pada response.
- [ ] Deep check dijalankan melalui scheduler.
- [ ] Aggregator memperhitungkan criticality.

---

### 15. Definition of Done Part 2D

Part 2D dianggap selesai bila:

- Module Health Provider didefinisikan;
- Tenant Health Provider didefinisikan;
- Scope Health Provider didefinisikan;
- Security Health Provider didefinisikan;
- criticality dan aggregation rule jelas;
- privacy/security response rule tersedia;
- threshold configurable;
- live vs cached check didefinisikan;
- permission endpoint tersedia;
- UAT tersedia;
- provider siap didaftarkan ke Health Registry.

---

---

## Bagian III — Core Implementation dan Database Design

### 1. Executive Summary

Part 3 mendefinisikan implementasi inti Health Check Framework.

Bagian ini menjadi kontrak tunggal untuk:

- `HealthStatus`;
- `HealthResult`;
- `HealthProviderInterface`;
- `HealthRegistry`;
- `HealthManager`;
- `HealthAggregator`;
- execution policy;
- timeout;
- caching;
- persistence;
- provider registration;
- database schema;
- folder structure;
- structured logging;
- metrics integration;
- error handling;
- UAT.

Tujuan utamanya adalah memastikan seluruh Health Provider yang telah didefinisikan pada Part 2A–2D dapat dijalankan melalui mekanisme yang seragam, aman, ringan, dan dapat diperluas.

Framework harus dapat digunakan pada:

- local development;
- XAMPP Windows;
- staging;
- production;
- load balancer;
- monitoring dashboard;
- CI/CD;
- future container orchestration.

---

### 2. Scope Part 3

Part 3 mencakup:

1. domain model Health Check;
2. kontrak provider;
3. registrasi provider;
4. eksekusi provider;
5. agregasi status;
6. execution profile;
7. timeout dan isolation;
8. cache health result;
9. persistence snapshot;
10. struktur folder;
11. contoh konfigurasi;
12. contoh implementasi PHP;
13. database schema;
14. logging dan metrics;
15. security boundary;
16. UAT;
17. Definition of Done.

Part 3 belum membahas detail HTTP endpoint secara penuh. Standar endpoint dan response publik dibahas pada Part 4.

---

### 3. Design Principles

#### 3.1 Single Responsibility

Setiap provider hanya memeriksa satu komponen.

Contoh:

```text
DatabaseHealthProvider
```

tidak boleh memeriksa:

```text
Queue
Storage
Notification
```

Provider boleh melaporkan dependency yang memengaruhi hasil, tetapi tidak mengambil alih tanggung jawab provider lain.

#### 3.2 Immutable Result

`HealthResult` harus diperlakukan sebagai value object immutable.

Setelah dibuat, hasil tidak boleh diubah.

Manfaat:

- mencegah perubahan status tidak terkontrol;
- memudahkan logging;
- memudahkan serialisasi;
- aman untuk cache;
- mudah diuji.

#### 3.3 Fail Safe

Jika provider melempar exception, framework tidak boleh ikut crash.

Exception diubah menjadi:

```text
status = UNKNOWN
```

atau:

```text
status = DOWN
```

sesuai execution policy dan criticality.

#### 3.4 Read-Only

Health Check tidak boleh:

- mengubah data bisnis;
- memicu workflow;
- mengirim notifikasi;
- mengubah konfigurasi;
- menjalankan migration;
- melakukan repair otomatis.

#### 3.5 Explicit Criticality

Setiap provider wajib memiliki criticality.

Nilai standar:

```text
critical
important
optional
```

Criticality memengaruhi hasil agregasi.

#### 3.6 Bounded Execution

Setiap provider wajib memiliki timeout.

Health Check tidak boleh menunggu tanpa batas.

#### 3.7 Cached Deep Check

Pemeriksaan yang mahal harus dijalankan melalui scheduler dan disimpan sebagai last known result.

Endpoint health tidak boleh menjalankan deep scan besar secara langsung.

#### 3.8 No Secret Disclosure

Result, logs, metrics, dan persistence tidak boleh menyimpan:

- password;
- API key;
- token;
- client secret;
- PHI;
- PII yang tidak diperlukan;
- raw request/response sensitif.

---

### 4. Core Domain Model

Core domain model terdiri dari:

```text
HealthStatus
HealthCriticality
HealthCheckType
HealthResult
HealthCheckContext
HealthExecutionProfile
```

---

### 5. HealthStatus

#### 5.1 Nilai Status

```php
<?php

declare(strict_types=1);

namespace App\Platform\Observability\Health\Domain;

enum HealthStatus: string
{
    case UP = 'UP';
    case DEGRADED = 'DEGRADED';
    case DOWN = 'DOWN';
    case UNKNOWN = 'UNKNOWN';
    case MAINTENANCE = 'MAINTENANCE';
}
```

#### 5.2 Urutan Keparahan

Framework harus menggunakan urutan eksplisit:

```text
UP
MAINTENANCE
DEGRADED
UNKNOWN
DOWN
```

Contoh implementasi:

```php
public function severityWeight(): int
{
    return match ($this) {
        self::UP => 0,
        self::MAINTENANCE => 1,
        self::DEGRADED => 2,
        self::UNKNOWN => 3,
        self::DOWN => 4,
    };
}
```

Catatan:

- `MAINTENANCE` bukan kegagalan teknis;
- `UNKNOWN` lebih buruk dari `DEGRADED` karena kondisi belum dapat dipastikan;
- `DOWN` merupakan status terburuk.

---

### 6. HealthCriticality

```php
<?php

declare(strict_types=1);

namespace App\Platform\Observability\Health\Domain;

enum HealthCriticality: string
{
    case CRITICAL = 'critical';
    case IMPORTANT = 'important';
    case OPTIONAL = 'optional';
}
```

Interpretasi:

| Criticality | Makna |
|---|---|
| CRITICAL | kegagalan dapat membuat platform tidak boleh menerima traffic |
| IMPORTANT | kegagalan menurunkan layanan tetapi platform masih dapat berjalan |
| OPTIONAL | kegagalan tidak menghentikan fungsi inti |

Contoh:

| Provider | Criticality |
|---|---|
| Database | CRITICAL |
| Authentication | CRITICAL |
| Scope | CRITICAL |
| Security | CRITICAL |
| Queue | IMPORTANT |
| Notification | IMPORTANT |
| Reporting | OPTIONAL |
| Marketing Integration | OPTIONAL |

---

### 7. HealthCheckType

```php
<?php

declare(strict_types=1);

namespace App\Platform\Observability\Health\Domain;

enum HealthCheckType: string
{
    case LIVE = 'live';
    case READY = 'ready';
    case SHALLOW = 'shallow';
    case DEEP = 'deep';
    case SCHEDULED = 'scheduled';
}
```

#### 7.1 LIVE

Menjawab:

> Apakah process aplikasi hidup?

Tidak boleh memeriksa dependency eksternal yang mahal.

#### 7.2 READY

Menjawab:

> Apakah aplikasi siap menerima traffic?

Memeriksa dependency kritis minimum.

#### 7.3 SHALLOW

Pemeriksaan ringan per komponen.

Contoh:

- `SELECT 1`;
- cek direktori writable;
- cek heartbeat terakhir;
- baca cache status.

#### 7.4 DEEP

Pemeriksaan mendalam.

Contoh:

- scan migration module;
- scope hierarchy validation;
- credential expiry scan;
- queue backlog analysis;
- integration connector diagnostics.

#### 7.5 SCHEDULED

Deep check yang dijalankan scheduler dan disimpan sebagai snapshot.

---

### 8. HealthCheckContext

Context memberikan informasi eksekusi kepada provider.

```php
<?php

declare(strict_types=1);

namespace App\Platform\Observability\Health\Domain;

final readonly class HealthCheckContext
{
    public function __construct(
        public HealthCheckType $type,
        public string $environment,
        public ?int $tenantId = null,
        public ?int $scopeId = null,
        public ?int $actorUserId = null,
        public ?string $correlationId = null,
        public bool $includeDetails = false,
        public bool $forceRefresh = false,
    ) {
    }
}
```

Aturan:

- `tenantId` hanya diisi untuk pemeriksaan tenant-specific;
- `includeDetails` hanya boleh aktif pada endpoint internal;
- `forceRefresh` harus dibatasi permission;
- provider tidak boleh mempercayai input context tanpa policy validation.

---

### 9. HealthResult

#### 9.1 Kontrak Value Object

```php
<?php

declare(strict_types=1);

namespace App\Platform\Observability\Health\Domain;

use DateTimeImmutable;

final readonly class HealthResult
{
    /**
     * @param array<string, mixed> $details
     * @param array<string, string> $dependencies
     * @param list<string> $warnings
     */
    public function __construct(
        public string $component,
        public HealthStatus $status,
        public HealthCriticality $criticality,
        public int $durationMs,
        public string $message,
        public array $details,
        public array $dependencies,
        public array $warnings,
        public DateTimeImmutable $checkedAt,
        public ?DateTimeImmutable $validUntil = null,
        public ?string $errorCode = null,
        public ?string $providerVersion = null,
    ) {
        if ($this->component === '') {
            throw new \InvalidArgumentException('Health component cannot be empty.');
        }

        if ($this->durationMs < 0) {
            throw new \InvalidArgumentException('Health duration cannot be negative.');
        }
    }
}
```

#### 9.2 Field Standard

| Field | Wajib | Keterangan |
|---|---:|---|
| component | Ya | identifier unik provider |
| status | Ya | hasil pemeriksaan |
| criticality | Ya | tingkat kekritisan |
| duration_ms | Ya | waktu pemeriksaan |
| message | Ya | ringkasan manusia |
| details | Ya | metadata aman |
| dependencies | Ya | status dependency relevan |
| warnings | Ya | warning non-fatal |
| checked_at | Ya | waktu pemeriksaan |
| valid_until | Tidak | masa berlaku cached result |
| error_code | Tidak | kode error stabil |
| provider_version | Tidak | versi provider |

#### 9.3 Factory Methods

Direkomendasikan menyediakan factory:

```php
public static function up(
    string $component,
    HealthCriticality $criticality,
    int $durationMs,
    string $message = 'Component is healthy.',
    array $details = [],
): self
```

Factory lain:

```text
degraded()
down()
unknown()
maintenance()
```

Tujuan:

- mengurangi boilerplate;
- menjaga konsistensi;
- memudahkan unit test.

---

### 10. HealthProviderInterface

#### 10.1 Kontrak Utama

```php
<?php

declare(strict_types=1);

namespace App\Platform\Observability\Health\Application\Contracts;

use App\Platform\Observability\Health\Domain\HealthCheckContext;
use App\Platform\Observability\Health\Domain\HealthCheckType;
use App\Platform\Observability\Health\Domain\HealthCriticality;
use App\Platform\Observability\Health\Domain\HealthResult;

interface HealthProviderInterface
{
    public function name(): string;

    public function criticality(): HealthCriticality;

    /**
     * @return list<HealthCheckType>
     */
    public function supportedTypes(): array;

    public function timeoutMs(): int;

    public function cacheTtlSeconds(): int;

    public function check(HealthCheckContext $context): HealthResult;
}
```

#### 10.2 Provider Name

Provider name harus:

- unik;
- lowercase snake_case;
- stabil;
- tidak berubah karena label UI.

Contoh:

```text
database
storage
queue
scheduler
workflow
event_bus
notification
integration
search
module
tenant
scope
security
```

#### 10.3 Timeout

Provider wajib mengembalikan timeout positif.

Contoh:

| Provider | Timeout |
|---|---:|
| Database shallow | 500 ms |
| Storage | 500 ms |
| Queue | 750 ms |
| Integration cached | 250 ms |
| Integration live | 3000 ms |
| Scope deep | 5000 ms |
| Security deep | 5000 ms |

#### 10.4 Cache TTL

TTL `0` berarti tidak menggunakan cache.

Contoh:

| Provider | TTL |
|---|---:|
| Liveness | 0 |
| Database readiness | 5 detik |
| Queue | 15 detik |
| Integration | 60 detik |
| Tenant aggregate | 300 detik |
| Scope deep scan | 300 detik |
| Security posture | 300 detik |

---

### 11. Optional Provider Capabilities

Provider dapat mengimplementasikan interface tambahan.

#### 11.1 TenantAwareHealthProviderInterface

```php
interface TenantAwareHealthProviderInterface
{
    public function supportsTenant(int $tenantId): bool;
}
```

#### 11.2 DetailedHealthProviderInterface

```php
interface DetailedHealthProviderInterface
{
    public function sanitizeDetails(array $details, bool $includeDetails): array;
}
```

#### 11.3 ScheduledHealthProviderInterface

```php
interface ScheduledHealthProviderInterface
{
    public function scheduleExpression(): string;
}
```

#### 11.4 DependencyAwareHealthProviderInterface

```php
interface DependencyAwareHealthProviderInterface
{
    /**
     * @return list<string>
     */
    public function dependencyNames(): array;
}
```

---

### 12. HealthRegistry

#### 12.1 Tujuan

HealthRegistry menyimpan seluruh provider yang tersedia.

Registry bertanggung jawab untuk:

- registrasi provider;
- validasi nama unik;
- pencarian provider;
- filter berdasarkan check type;
- filter berdasarkan criticality;
- mencegah duplicate registration.

Registry tidak menjalankan provider.

#### 12.2 Kontrak

```php
<?php

declare(strict_types=1);

namespace App\Platform\Observability\Health\Application;

use App\Platform\Observability\Health\Application\Contracts\HealthProviderInterface;
use App\Platform\Observability\Health\Domain\HealthCheckType;
use App\Platform\Observability\Health\Domain\HealthCriticality;

final class HealthRegistry
{
    /** @var array<string, HealthProviderInterface> */
    private array $providers = [];

    public function register(HealthProviderInterface $provider): void
    {
        $name = $provider->name();

        if (isset($this->providers[$name])) {
            throw new \LogicException(
                sprintf('Health provider "%s" is already registered.', $name)
            );
        }

        $this->providers[$name] = $provider;
    }

    public function get(string $name): HealthProviderInterface
    {
        if (!isset($this->providers[$name])) {
            throw new \OutOfBoundsException(
                sprintf('Health provider "%s" is not registered.', $name)
            );
        }

        return $this->providers[$name];
    }

    /**
     * @return list<HealthProviderInterface>
     */
    public function all(): array
    {
        return array_values($this->providers);
    }

    /**
     * @return list<HealthProviderInterface>
     */
    public function forType(HealthCheckType $type): array
    {
        return array_values(array_filter(
            $this->providers,
            static fn (HealthProviderInterface $provider): bool =>
                in_array($type, $provider->supportedTypes(), true)
        ));
    }

    /**
     * @return list<HealthProviderInterface>
     */
    public function forCriticality(HealthCriticality $criticality): array
    {
        return array_values(array_filter(
            $this->providers,
            static fn (HealthProviderInterface $provider): bool =>
                $provider->criticality() === $criticality
        ));
    }
}
```

#### 12.3 Registry Rules

Registry wajib gagal saat:

- nama provider kosong;
- duplicate provider;
- timeout tidak valid;
- check type kosong;
- criticality tidak valid.

Validasi dapat dilakukan melalui provider validator pada bootstrap.

---

### 13. Provider Registration

#### 13.1 Static Registration

Untuk Modular Monolith, provider dapat diregistrasikan pada bootstrap:

```php
$registry->register($container->get(DatabaseHealthProvider::class));
$registry->register($container->get(StorageHealthProvider::class));
$registry->register($container->get(QueueHealthProvider::class));
```

#### 13.2 Module Registration

Setiap module dapat mendaftarkan provider sendiri:

```php
interface HealthProviderRegistrarInterface
{
    public function registerHealthProviders(HealthRegistry $registry): void;
}
```

Contoh:

```php
final class WorkflowModuleHealthRegistrar
    implements HealthProviderRegistrarInterface
{
    public function __construct(
        private readonly WorkflowHealthProvider $provider
    ) {
    }

    public function registerHealthProviders(HealthRegistry $registry): void
    {
        $registry->register($this->provider);
    }
}
```

#### 13.3 Configuration Registration

Alternatif:

```php
return [
    DatabaseHealthProvider::class,
    StorageHealthProvider::class,
    QueueHealthProvider::class,
];
```

Bootstrap membaca class list lalu mengambil instance dari container.

#### 13.4 Larangan

Jangan:

- scan seluruh filesystem pada setiap request;
- membuat provider melalui `new` langsung jika memiliki dependency;
- meregistrasikan provider berdasarkan input pengguna;
- memuat provider dari source yang tidak dipercaya.

---

### 14. HealthExecutionProfile

Execution profile menentukan bagaimana health check dijalankan.

```php
<?php

declare(strict_types=1);

namespace App\Platform\Observability\Health\Domain;

final readonly class HealthExecutionProfile
{
    /**
     * @param list<HealthCriticality> $criticalities
     * @param list<string> $includedProviders
     * @param list<string> $excludedProviders
     */
    public function __construct(
        public HealthCheckType $type,
        public array $criticalities,
        public array $includedProviders = [],
        public array $excludedProviders = [],
        public bool $useCache = true,
        public bool $persistResult = false,
        public bool $stopOnCriticalDown = false,
        public int $overallTimeoutMs = 5000,
    ) {
    }
}
```

#### 14.1 Profile Standard

##### Liveness Profile

```text
type = LIVE
criticalities = CRITICAL
use_cache = false
persist_result = false
overall_timeout = 250 ms
```

##### Readiness Profile

```text
type = READY
criticalities = CRITICAL, IMPORTANT
use_cache = true
persist_result = false
overall_timeout = 2000 ms
```

##### Deep Profile

```text
type = DEEP
criticalities = all
use_cache = false
persist_result = true
overall_timeout = 30000 ms
```

##### Scheduled Profile

```text
type = SCHEDULED
criticalities = all
use_cache = false
persist_result = true
overall_timeout = 60000 ms
```

---

### 15. HealthManager

#### 15.1 Tanggung Jawab

HealthManager adalah orchestrator.

Tugas:

1. menerima context dan execution profile;
2. memilih provider dari registry;
3. membaca cache bila diizinkan;
4. menjalankan provider;
5. menangani timeout/exception;
6. menyimpan cache;
7. menyimpan snapshot bila diaktifkan;
8. mengirim log/metric;
9. mengembalikan hasil provider;
10. meminta aggregator menentukan status akhir.

HealthManager tidak menentukan aturan status akhir sendiri.

#### 15.2 Kontrak Result Collection

```php
final readonly class HealthReport
{
    /**
     * @param array<string, HealthResult> $components
     */
    public function __construct(
        public HealthStatus $status,
        public array $components,
        public int $durationMs,
        public \DateTimeImmutable $checkedAt,
        public string $reportId,
    ) {
    }
}
```

#### 15.3 Contoh Manager

```php
<?php

declare(strict_types=1);

namespace App\Platform\Observability\Health\Application;

use App\Platform\Observability\Health\Domain\HealthCheckContext;
use App\Platform\Observability\Health\Domain\HealthExecutionProfile;
use App\Platform\Observability\Health\Domain\HealthReport;
use App\Platform\Observability\Health\Domain\HealthResult;
use App\Platform\Observability\Health\Domain\HealthStatus;

final class HealthManager
{
    public function __construct(
        private readonly HealthRegistry $registry,
        private readonly HealthProviderExecutor $executor,
        private readonly HealthAggregator $aggregator,
        private readonly HealthResultCacheInterface $cache,
        private readonly HealthSnapshotRepositoryInterface $snapshots,
        private readonly HealthTelemetryInterface $telemetry,
    ) {
    }

    public function run(
        HealthCheckContext $context,
        HealthExecutionProfile $profile
    ): HealthReport {
        $startedAt = hrtime(true);
        $results = [];

        foreach ($this->resolveProviders($profile) as $provider) {
            $result = $this->resolveResult(
                provider: $provider,
                context: $context,
                profile: $profile,
            );

            $results[$provider->name()] = $result;
            $this->telemetry->record($result);

            if (
                $profile->stopOnCriticalDown
                && $result->criticality->value === 'critical'
                && $result->status === HealthStatus::DOWN
            ) {
                break;
            }
        }

        $status = $this->aggregator->aggregate($results);
        $durationMs = (int) ((hrtime(true) - $startedAt) / 1_000_000);

        $report = new HealthReport(
            status: $status,
            components: $results,
            durationMs: $durationMs,
            checkedAt: new \DateTimeImmutable(),
            reportId: bin2hex(random_bytes(16)),
        );

        if ($profile->persistResult) {
            $this->snapshots->saveReport($report, $context, $profile);
        }

        return $report;
    }

    private function resolveProviders(
        HealthExecutionProfile $profile
    ): array {
        $providers = $this->registry->forType($profile->type);

        return array_values(array_filter(
            $providers,
            static function ($provider) use ($profile): bool {
                if (
                    $profile->includedProviders !== []
                    && !in_array($provider->name(), $profile->includedProviders, true)
                ) {
                    return false;
                }

                if (in_array($provider->name(), $profile->excludedProviders, true)) {
                    return false;
                }

                return in_array(
                    $provider->criticality(),
                    $profile->criticalities,
                    true
                );
            }
        ));
    }
}
```

Kode di atas merupakan contoh arsitektural. Implementasi production harus melengkapi:

- cache resolution;
- timeout;
- exception mapping;
- logging;
- metrics;
- global timeout;
- cancellation policy.

---

### 16. HealthProviderExecutor

#### 16.1 Tujuan

Executor memisahkan detail eksekusi provider dari HealthManager.

Tanggung jawab:

- mengukur durasi;
- menangkap exception;
- menerapkan timeout;
- membuat fallback result;
- membersihkan detail sensitif;
- mencatat error internal.

#### 16.2 Kontrak

```php
interface HealthProviderExecutorInterface
{
    public function execute(
        HealthProviderInterface $provider,
        HealthCheckContext $context
    ): HealthResult;
}
```

#### 16.3 Exception Mapping

| Kondisi | Status |
|---|---|
| timeout provider critical | DOWN atau UNKNOWN sesuai policy |
| timeout provider optional | DEGRADED/UNKNOWN |
| connection refused | DOWN |
| invalid configuration | DOWN |
| unsupported check type | UNKNOWN |
| unexpected exception | UNKNOWN |
| maintenance configured | MAINTENANCE |

#### 16.4 Error Code

Gunakan kode stabil:

```text
HEALTH_TIMEOUT
HEALTH_CONNECTION_FAILED
HEALTH_CONFIGURATION_INVALID
HEALTH_DEPENDENCY_DOWN
HEALTH_PROVIDER_EXCEPTION
HEALTH_RESULT_STALE
HEALTH_PERMISSION_DENIED
```

Jangan menampilkan exception message mentah kepada endpoint publik.

---

### 17. Timeout Strategy

#### 17.1 Keterbatasan PHP

PHP synchronous biasa tidak memiliki preemptive cancellation universal untuk seluruh operasi.

Karena itu timeout harus diterapkan berlapis:

1. PDO connection/query timeout;
2. cURL timeout;
3. stream timeout;
4. provider-level elapsed time;
5. overall request timeout;
6. scheduled deep check untuk operasi mahal.

#### 17.2 PDO Example

```php
$pdo = new PDO(
    $dsn,
    $username,
    $password,
    [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_TIMEOUT => 2,
    ]
);
```

Untuk MySQL, query timeout dapat memerlukan driver/configuration tambahan.

#### 17.3 cURL Example

```php
curl_setopt_array($handle, [
    CURLOPT_CONNECTTIMEOUT_MS => 500,
    CURLOPT_TIMEOUT_MS => 1500,
]);
```

#### 17.4 Global Timeout

HealthManager harus menghentikan pemilihan provider baru bila overall timeout tercapai.

Provider yang belum dijalankan diberi status:

```text
UNKNOWN
error_code = HEALTH_OVERALL_TIMEOUT
```

---

### 18. HealthAggregator

#### 18.1 Tujuan

Aggregator menentukan status akhir report berdasarkan:

- status provider;
- criticality;
- maintenance policy;
- dependency;
- fallback availability;
- execution profile.

#### 18.2 Kontrak

```php
interface HealthAggregatorInterface
{
    /**
     * @param array<string, HealthResult> $results
     */
    public function aggregate(array $results): HealthStatus;
}
```

#### 18.3 Default Aggregation Matrix

##### Critical Provider

| Status Provider | Status Platform Minimum |
|---|---|
| UP | tidak mengubah |
| MAINTENANCE | DEGRADED atau DOWN sesuai policy |
| DEGRADED | DEGRADED |
| UNKNOWN | DEGRADED/UNKNOWN |
| DOWN | DOWN |

##### Important Provider

| Status Provider | Status Platform Minimum |
|---|---|
| UP | tidak mengubah |
| MAINTENANCE | DEGRADED |
| DEGRADED | DEGRADED |
| UNKNOWN | DEGRADED |
| DOWN | DEGRADED, dapat menjadi DOWN bila fungsi bisnis inti berhenti |

##### Optional Provider

| Status Provider | Status Platform Minimum |
|---|---|
| UP | tidak mengubah |
| MAINTENANCE | UP/DEGRADED |
| DEGRADED | UP/DEGRADED |
| UNKNOWN | UP/DEGRADED |
| DOWN | DEGRADED maksimum secara default |

#### 18.4 Default Algorithm

```php
public function aggregate(array $results): HealthStatus
{
    $final = HealthStatus::UP;

    foreach ($results as $result) {
        $candidate = $this->mapToPlatformStatus($result);

        if ($candidate->severityWeight() > $final->severityWeight()) {
            $final = $candidate;
        }
    }

    return $final;
}
```

#### 18.5 Dependency-Aware Aggregation

Aggregator harus mencegah misleading result.

Contoh:

```text
Database = DOWN
Workflow = UNKNOWN karena tidak dijalankan
```

Platform tetap:

```text
DOWN
```

Workflow tidak perlu mengubah hasil menjadi kondisi berbeda.

#### 18.6 Maintenance Policy

Maintenance harus eksplisit.

Contoh:

- optional reporting maintenance → platform tetap UP;
- critical database maintenance → readiness DOWN;
- tenant-specific maintenance → tenant DOWN/MAINTENANCE, platform global dapat UP.

---

### 19. HealthResult Cache

#### 19.1 Tujuan

Cache mengurangi:

- beban database;
- panggilan integration;
- scan seluruh tenant;
- scan scope hierarchy;
- pemeriksaan security berat.

#### 19.2 Kontrak

```php
interface HealthResultCacheInterface
{
    public function get(
        string $providerName,
        HealthCheckContext $context
    ): ?HealthResult;

    public function put(
        HealthResult $result,
        HealthCheckContext $context,
        int $ttlSeconds
    ): void;

    public function forget(
        string $providerName,
        HealthCheckContext $context
    ): void;
}
```

#### 19.3 Cache Key

Format rekomendasi:

```text
health:{environment}:{provider}:{type}:{tenant}:{scope}
```

Contoh:

```text
health:production:database:ready:global:global
health:production:tenant:deep:12:global
```

#### 19.4 Cache Backend

Tahap awal:

- filesystem cache;
- database cache;
- APCu bila tersedia.

Future:

- Redis;
- distributed cache.

#### 19.5 Stale Result

Jika cached result sudah expired:

- jangan diperlakukan sebagai fresh;
- dapat dikembalikan sebagai fallback dengan status `UNKNOWN` atau `DEGRADED`;
- beri `error_code = HEALTH_RESULT_STALE`;
- sertakan checked_at dan valid_until.

---

### 20. Persistence Strategy

#### 20.1 Prinsip

Jangan menyimpan setiap request `/health` ke database.

Alasannya:

- meningkatkan beban;
- menyebabkan health check bergantung pada persistence health sendiri;
- menghasilkan data besar;
- dapat memperburuk outage database.

Persistence hanya untuk:

- scheduled deep check;
- perubahan status;
- snapshot berkala;
- incident analysis;
- SLA reporting.

#### 20.2 Data yang Disimpan

Simpan:

- report id;
- provider;
- status;
- criticality;
- duration;
- message aman;
- details aman;
- checked_at;
- valid_until;
- environment;
- tenant/scope context bila diperlukan;
- error code.

Jangan simpan:

- token;
- password;
- raw stack trace;
- PHI/PII;
- payload integration.

---

### 21. Database Schema

#### 21.1 Table: `health_check_reports`

```sql
CREATE TABLE health_check_reports (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    report_uuid CHAR(32) NOT NULL,
    environment VARCHAR(32) NOT NULL,
    check_type VARCHAR(32) NOT NULL,
    overall_status VARCHAR(20) NOT NULL,
    duration_ms INT UNSIGNED NOT NULL DEFAULT 0,
    tenant_id BIGINT UNSIGNED NULL,
    scope_id BIGINT UNSIGNED NULL,
    correlation_id VARCHAR(100) NULL,
    checked_at DATETIME(6) NOT NULL,
    created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),

    PRIMARY KEY (id),
    UNIQUE KEY uq_health_report_uuid (report_uuid),
    KEY idx_health_report_checked_at (checked_at),
    KEY idx_health_report_status (overall_status),
    KEY idx_health_report_tenant (tenant_id, checked_at),
    KEY idx_health_report_type (check_type, checked_at)
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

#### 21.2 Table: `health_check_results`

```sql
CREATE TABLE health_check_results (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    health_check_report_id BIGINT UNSIGNED NOT NULL,
    component VARCHAR(100) NOT NULL,
    status VARCHAR(20) NOT NULL,
    criticality VARCHAR(20) NOT NULL,
    duration_ms INT UNSIGNED NOT NULL DEFAULT 0,
    message VARCHAR(500) NOT NULL,
    details_json JSON NULL,
    dependencies_json JSON NULL,
    warnings_json JSON NULL,
    error_code VARCHAR(100) NULL,
    provider_version VARCHAR(50) NULL,
    checked_at DATETIME(6) NOT NULL,
    valid_until DATETIME(6) NULL,
    created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),

    PRIMARY KEY (id),
    CONSTRAINT fk_health_result_report
        FOREIGN KEY (health_check_report_id)
        REFERENCES health_check_reports(id)
        ON DELETE CASCADE,

    KEY idx_health_result_component (component, checked_at),
    KEY idx_health_result_status (status, checked_at),
    KEY idx_health_result_report (health_check_report_id)
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

#### 21.3 Table: `health_component_state`

Table ini menyimpan current state terakhir per context.

```sql
CREATE TABLE health_component_state (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    environment VARCHAR(32) NOT NULL,
    component VARCHAR(100) NOT NULL,
    check_type VARCHAR(32) NOT NULL,
    tenant_id BIGINT UNSIGNED NULL,
    scope_id BIGINT UNSIGNED NULL,
    status VARCHAR(20) NOT NULL,
    previous_status VARCHAR(20) NULL,
    criticality VARCHAR(20) NOT NULL,
    duration_ms INT UNSIGNED NOT NULL DEFAULT 0,
    message VARCHAR(500) NOT NULL,
    details_json JSON NULL,
    error_code VARCHAR(100) NULL,
    checked_at DATETIME(6) NOT NULL,
    valid_until DATETIME(6) NULL,
    changed_at DATETIME(6) NOT NULL,
    updated_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6)
        ON UPDATE CURRENT_TIMESTAMP(6),

    PRIMARY KEY (id),
    UNIQUE KEY uq_health_component_context (
        environment,
        component,
        check_type,
        tenant_id,
        scope_id
    ),
    KEY idx_health_component_status (status, checked_at),
    KEY idx_health_component_changed (changed_at)
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

#### 21.4 NULL pada Unique Index

MySQL memperlakukan `NULL` secara khusus pada unique index.

Untuk konsistensi, implementasi dapat menggunakan nilai sentinel:

```text
tenant_id = 0 untuk global
scope_id = 0 untuk global
```

Alternatif:

- generated columns;
- normalized context key;
- unique hash column.

Rekomendasi sederhana:

```sql
context_key VARCHAR(255) NOT NULL
```

Contoh:

```text
production|database|ready|tenant:global|scope:global
```

Lalu buat unique index pada `context_key`.

#### 21.5 Table: `health_status_transitions`

```sql
CREATE TABLE health_status_transitions (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    environment VARCHAR(32) NOT NULL,
    component VARCHAR(100) NOT NULL,
    check_type VARCHAR(32) NOT NULL,
    tenant_id BIGINT UNSIGNED NULL,
    scope_id BIGINT UNSIGNED NULL,
    from_status VARCHAR(20) NULL,
    to_status VARCHAR(20) NOT NULL,
    reason_code VARCHAR(100) NULL,
    message VARCHAR(500) NOT NULL,
    report_uuid CHAR(32) NULL,
    correlation_id VARCHAR(100) NULL,
    changed_at DATETIME(6) NOT NULL,

    PRIMARY KEY (id),
    KEY idx_health_transition_component (component, changed_at),
    KEY idx_health_transition_status (to_status, changed_at),
    KEY idx_health_transition_tenant (tenant_id, changed_at)
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

#### 21.6 Retention

Rekomendasi awal:

| Data | Retention |
|---|---|
| Current state | selama komponen terdaftar |
| Transition | 12–24 bulan |
| Detailed report | 30–90 hari |
| Aggregated KPI | 12–24 bulan |
| Debug payload | tidak disimpan |

Retention final mengikuti SSOT-OBS-08.

---

### 22. Repository Contracts

#### 22.1 Snapshot Repository

```php
interface HealthSnapshotRepositoryInterface
{
    public function saveReport(
        HealthReport $report,
        HealthCheckContext $context,
        HealthExecutionProfile $profile
    ): void;

    public function findLatest(
        string $component,
        HealthCheckContext $context
    ): ?HealthResult;
}
```

#### 22.2 State Repository

```php
interface HealthStateRepositoryInterface
{
    public function upsert(
        HealthResult $result,
        HealthCheckContext $context,
        HealthCheckType $type
    ): void;
}
```

#### 22.3 Transition Repository

Transition hanya disimpan bila status berubah.

```php
interface HealthTransitionRepositoryInterface
{
    public function recordIfChanged(
        HealthResult $result,
        HealthCheckContext $context,
        HealthCheckType $type,
        ?HealthStatus $previousStatus
    ): void;
}
```

---

### 23. Transaction Policy

Persistence report dapat menggunakan transaction:

```text
insert report
insert component results
update current state
insert transitions
commit
```

Namun kegagalan persistence tidak boleh mengubah hasil health asli.

Contoh:

```text
Database provider = UP
Snapshot persistence gagal
```

Hasil health database tidak boleh otomatis menjadi DOWN karena mekanisme history gagal, kecuali persistence tersebut memang bagian dependency kritis yang sedang diperiksa.

Kegagalan persistence dicatat sebagai:

```text
structured log
metric
internal warning
```

---

### 24. Folder Structure

Rekomendasi:

```text
app/
└── Platform/
    └── Observability/
        └── Health/
            ├── Domain/
            │   ├── HealthStatus.php
            │   ├── HealthCriticality.php
            │   ├── HealthCheckType.php
            │   ├── HealthCheckContext.php
            │   ├── HealthExecutionProfile.php
            │   ├── HealthResult.php
            │   └── HealthReport.php
            │
            ├── Application/
            │   ├── Contracts/
            │   │   ├── HealthProviderInterface.php
            │   │   ├── HealthAggregatorInterface.php
            │   │   ├── HealthResultCacheInterface.php
            │   │   ├── HealthSnapshotRepositoryInterface.php
            │   │   └── HealthTelemetryInterface.php
            │   │
            │   ├── HealthRegistry.php
            │   ├── HealthManager.php
            │   ├── HealthProviderExecutor.php
            │   ├── HealthAggregator.php
            │   └── HealthProfileFactory.php
            │
            ├── Infrastructure/
            │   ├── Cache/
            │   │   ├── FileHealthResultCache.php
            │   │   └── DatabaseHealthResultCache.php
            │   │
            │   ├── Persistence/
            │   │   ├── PdoHealthSnapshotRepository.php
            │   │   ├── PdoHealthStateRepository.php
            │   │   └── PdoHealthTransitionRepository.php
            │   │
            │   ├── Telemetry/
            │   │   ├── StructuredLogHealthTelemetry.php
            │   │   └── MetricsHealthTelemetry.php
            │   │
            │   └── Providers/
            │       ├── DatabaseHealthProvider.php
            │       ├── StorageHealthProvider.php
            │       ├── QueueHealthProvider.php
            │       ├── SchedulerHealthProvider.php
            │       ├── WorkflowHealthProvider.php
            │       ├── EventBusHealthProvider.php
            │       ├── NotificationHealthProvider.php
            │       ├── IntegrationHealthProvider.php
            │       ├── SearchHealthProvider.php
            │       ├── ModuleHealthProvider.php
            │       ├── TenantHealthProvider.php
            │       ├── ScopeHealthProvider.php
            │       └── SecurityHealthProvider.php
            │
            └── Presentation/
                ├── Http/
                │   ├── HealthController.php
                │   └── InternalHealthController.php
                └── Cli/
                    └── HealthCheckCommand.php
```

Untuk module-specific provider:

```text
app/Modules/Workflow/Infrastructure/Health/
└── WorkflowHealthProvider.php
```

Provider tetap mengimplementasikan kontrak Kernel.

---

### 25. Configuration Structure

Contoh `config/health.php`:

```php
<?php

declare(strict_types=1);

use App\Platform\Observability\Health\Infrastructure\Providers\DatabaseHealthProvider;
use App\Platform\Observability\Health\Infrastructure\Providers\StorageHealthProvider;
use App\Platform\Observability\Health\Infrastructure\Providers\QueueHealthProvider;

return [
    'enabled' => true,

    'environment' => getenv('APP_ENV') ?: 'local',

    'providers' => [
        DatabaseHealthProvider::class,
        StorageHealthProvider::class,
        QueueHealthProvider::class,
    ],

    'profiles' => [
        'live' => [
            'overall_timeout_ms' => 250,
            'use_cache' => false,
            'persist' => false,
        ],
        'ready' => [
            'overall_timeout_ms' => 2000,
            'use_cache' => true,
            'persist' => false,
        ],
        'deep' => [
            'overall_timeout_ms' => 30000,
            'use_cache' => false,
            'persist' => true,
        ],
    ],

    'cache' => [
        'driver' => 'file',
        'path' => dirname(__DIR__) . '/storage/cache/health',
    ],

    'persistence' => [
        'enabled' => true,
        'persist_only_changes' => false,
    ],

    'security' => [
        'public_details' => false,
        'internal_details' => true,
    ],
];
```

---

### 26. Example Database Provider

```php
<?php

declare(strict_types=1);

namespace App\Platform\Observability\Health\Infrastructure\Providers;

use App\Platform\Observability\Health\Application\Contracts\HealthProviderInterface;
use App\Platform\Observability\Health\Domain\HealthCheckContext;
use App\Platform\Observability\Health\Domain\HealthCheckType;
use App\Platform\Observability\Health\Domain\HealthCriticality;
use App\Platform\Observability\Health\Domain\HealthResult;
use App\Platform\Observability\Health\Domain\HealthStatus;
use DateTimeImmutable;
use PDO;
use Throwable;

final class DatabaseHealthProvider implements HealthProviderInterface
{
    public function __construct(
        private readonly PDO $pdo,
        private readonly int $warningLatencyMs = 250,
    ) {
    }

    public function name(): string
    {
        return 'database';
    }

    public function criticality(): HealthCriticality
    {
        return HealthCriticality::CRITICAL;
    }

    public function supportedTypes(): array
    {
        return [
            HealthCheckType::READY,
            HealthCheckType::SHALLOW,
            HealthCheckType::DEEP,
            HealthCheckType::SCHEDULED,
        ];
    }

    public function timeoutMs(): int
    {
        return 500;
    }

    public function cacheTtlSeconds(): int
    {
        return 5;
    }

    public function check(HealthCheckContext $context): HealthResult
    {
        $startedAt = hrtime(true);

        try {
            $statement = $this->pdo->query('SELECT 1');
            $value = $statement->fetchColumn();

            $durationMs = (int) ((hrtime(true) - $startedAt) / 1_000_000);

            if ((int) $value !== 1) {
                return new HealthResult(
                    component: $this->name(),
                    status: HealthStatus::DOWN,
                    criticality: $this->criticality(),
                    durationMs: $durationMs,
                    message: 'Database validation query returned an invalid result.',
                    details: [],
                    dependencies: [],
                    warnings: [],
                    checkedAt: new DateTimeImmutable(),
                    errorCode: 'HEALTH_DATABASE_INVALID_RESULT',
                );
            }

            $status = $durationMs > $this->warningLatencyMs
                ? HealthStatus::DEGRADED
                : HealthStatus::UP;

            return new HealthResult(
                component: $this->name(),
                status: $status,
                criticality: $this->criticality(),
                durationMs: $durationMs,
                message: $status === HealthStatus::UP
                    ? 'Database is reachable.'
                    : 'Database is reachable but latency is high.',
                details: [
                    'latency_ms' => $durationMs,
                ],
                dependencies: [],
                warnings: $status === HealthStatus::DEGRADED
                    ? ['Database latency exceeded warning threshold.']
                    : [],
                checkedAt: new DateTimeImmutable(),
                validUntil: new DateTimeImmutable('+5 seconds'),
                providerVersion: '1.0.0',
            );
        } catch (Throwable $exception) {
            $durationMs = (int) ((hrtime(true) - $startedAt) / 1_000_000);

            return new HealthResult(
                component: $this->name(),
                status: HealthStatus::DOWN,
                criticality: $this->criticality(),
                durationMs: $durationMs,
                message: 'Database connection failed.',
                details: [],
                dependencies: [],
                warnings: [],
                checkedAt: new DateTimeImmutable(),
                errorCode: 'HEALTH_DATABASE_CONNECTION_FAILED',
                providerVersion: '1.0.0',
            );
        }
    }
}
```

Catatan:

- exception detail dicatat internal, bukan pada result publik;
- jangan menampilkan DSN;
- jangan menampilkan username;
- jangan menjalankan query terhadap data bisnis.

---

### 27. Telemetry Integration

#### 27.1 Structured Log

Format minimum:

```json
{
  "event": "health_check_completed",
  "component": "database",
  "status": "UP",
  "criticality": "critical",
  "duration_ms": 18,
  "check_type": "ready",
  "environment": "production",
  "tenant_id": null,
  "scope_id": null,
  "correlation_id": "01J...",
  "checked_at": "2026-07-04T19:00:00+07:00"
}
```

#### 27.2 Status Change Log

```json
{
  "event": "health_status_changed",
  "component": "queue",
  "from_status": "UP",
  "to_status": "DEGRADED",
  "reason_code": "HEALTH_QUEUE_BACKLOG_HIGH"
}
```

#### 27.3 Metrics

Metric minimum:

```text
health_check_status
health_check_duration_ms
health_check_execution_total
health_check_failure_total
health_status_transition_total
health_result_cache_hit_total
health_result_cache_miss_total
```

#### 27.4 Cardinality

Jangan gunakan label:

- user_id;
- patient_id;
- request_id unik;
- seluruh tenant_id jika jumlah sangat besar.

Gunakan agregasi tenant tier/status bila diperlukan.

---

### 28. Error Handling

#### 28.1 Provider Exception

Provider exception:

- ditangkap executor;
- dicatat dengan stack trace internal;
- dikonversi menjadi safe HealthResult;
- tidak diteruskan ke endpoint publik.

#### 28.2 Registry Error

Duplicate registration merupakan startup error.

Aplikasi harus gagal bootstrap pada environment development/test.

Pada production, deployment harus ditolak sebelum traffic diterima.

#### 28.3 Persistence Error

Tidak membatalkan report.

Tambahkan internal warning:

```text
HEALTH_SNAPSHOT_PERSIST_FAILED
```

#### 28.4 Cache Error

Fallback ke live check bila aman.

Jika provider mahal dan live check tidak aman:

```text
UNKNOWN
HEALTH_CACHE_UNAVAILABLE
```

#### 28.5 Serialization Error

Result harus disanitasi.

Field non-serializable tidak boleh dimasukkan ke `details`.

---

### 29. Security Boundary

#### 29.1 Public vs Internal

Core framework harus mendukung dua projection:

```text
PublicHealthReportProjection
InternalHealthReportProjection
```

Public:

- status;
- timestamp;
- optional request id.

Internal:

- provider status;
- duration;
- safe details;
- error code;
- dependency summary.

#### 29.2 Detail Sanitizer

Gunakan central sanitizer:

```php
interface HealthDetailSanitizerInterface
{
    public function sanitize(array $details): array;
}
```

Blocked keys:

```text
password
secret
token
authorization
api_key
client_secret
dsn
patient
email
phone
payload
```

#### 29.3 Audit

Health polling normal bukan audit event.

Yang diaudit:

- perubahan health configuration;
- perubahan threshold;
- force deep check;
- akses detail security health;
- perubahan maintenance status;
- manual cache invalidation;
- manual provider enable/disable.

---

### 30. Scheduler Integration

Scheduled deep check:

```text
every minute:
  critical shallow health

every 5 minutes:
  queue, scheduler, workflow, event bus

every 15 minutes:
  integration, notification, search

hourly:
  module, tenant aggregate, scope deep, security posture
```

Frekuensi final harus configurable.

CLI contoh:

```bash
php tools/health-check.php --profile=scheduled
php tools/health-check.php --provider=database
php tools/health-check.php --provider=tenant --tenant=12
php tools/health-check.php --profile=deep --persist
```

CLI harus mengembalikan exit code:

| Status | Exit Code |
|---|---:|
| UP | 0 |
| DEGRADED | 1 |
| DOWN | 2 |
| UNKNOWN | 3 |
| invalid command/config | 4 |

---

### 31. Performance Standard

Target awal:

| Profile | Target |
|---|---:|
| LIVE | < 100 ms |
| READY | < 1000 ms |
| SHALLOW single provider | < 500 ms |
| DEEP | sesuai provider, async/scheduled |
| Cached read | < 50 ms |

Aturan:

- tidak ada N+1 query;
- tenant aggregate menggunakan query agregat;
- deep hierarchy scan tidak dijalankan di public request;
- persistence batch insert;
- cache result berat;
- metrics tidak memblokir response.

---

### 32. Testing Strategy

#### 32.1 Unit Test

Wajib menguji:

- HealthStatus severity;
- HealthResult validation;
- duplicate registry;
- provider filter;
- aggregator criticality;
- timeout mapping;
- exception mapping;
- stale cache;
- detail sanitizer.

#### 32.2 Integration Test

Wajib menguji:

- PDO provider dengan database test;
- filesystem cache;
- snapshot repository;
- current state upsert;
- transition persistence;
- configuration loading.

#### 32.3 Failure Injection

Skenario:

- database mati;
- storage read-only;
- cache gagal;
- provider exception;
- provider timeout;
- stale snapshot;
- duplicate provider;
- persistence gagal.

---

### 33. UAT Part 3

#### 33.1 Registry

- [ ] Seluruh provider dapat diregistrasikan.
- [ ] Duplicate name ditolak.
- [ ] Provider dapat difilter berdasarkan type.
- [ ] Provider dapat difilter berdasarkan criticality.

#### 33.2 Manager

- [ ] Manager menjalankan provider sesuai profile.
- [ ] Provider yang dikecualikan tidak dijalankan.
- [ ] Stop-on-critical-down bekerja.
- [ ] Report memiliki report ID unik.
- [ ] Overall duration tercatat.

#### 33.3 Executor

- [ ] Exception provider tidak membuat aplikasi crash.
- [ ] Timeout menghasilkan safe result.
- [ ] Error code stabil.
- [ ] Stack trace tidak muncul pada result publik.

#### 33.4 Aggregator

- [ ] Critical DOWN menghasilkan platform DOWN.
- [ ] Important DOWN menghasilkan DEGRADED sesuai policy.
- [ ] Optional DOWN tidak otomatis membuat platform DOWN.
- [ ] Maintenance diproses sesuai criticality.

#### 33.5 Cache

- [ ] Fresh cache digunakan.
- [ ] Expired cache tidak dianggap fresh.
- [ ] Force refresh melewati cache.
- [ ] Cache key tenant tidak bercampur.

#### 33.6 Database

- [ ] Report dapat disimpan.
- [ ] Component result dapat disimpan.
- [ ] Current state dapat di-upsert.
- [ ] Transition hanya tercatat saat status berubah.
- [ ] Detail sensitif tidak tersimpan.

#### 33.7 Security

- [ ] Public projection tidak menampilkan details.
- [ ] Internal projection memerlukan permission.
- [ ] Secret keys disanitasi.
- [ ] Force deep check diaudit.

#### 33.8 Performance

- [ ] LIVE memenuhi target latency.
- [ ] READY memenuhi overall timeout.
- [ ] Deep check tidak dijalankan melalui endpoint publik.
- [ ] Persistence failure tidak menggagalkan report.

---

### 34. Anti-Pattern

Hindari:

- satu provider memeriksa seluruh platform;
- provider mengakses global state tanpa dependency injection;
- provider menyimpan hasil sendiri;
- aggregator menjalankan provider;
- controller langsung memanggil provider;
- setiap health request disimpan ke database;
- exception mentah dikembalikan;
- cache key tanpa tenant/scope context;
- status ditentukan hanya berdasarkan HTTP 200;
- deep scan dijalankan pada load balancer probe;
- maintenance dianggap sama dengan DOWN tanpa policy;
- provider melakukan self-healing;
- threshold di-hardcode dalam banyak class.

---

### 35. Migration Strategy

Urutan implementasi:

#### Phase 1 — Core Domain

- HealthStatus;
- HealthCriticality;
- HealthCheckType;
- HealthResult;
- HealthReport;
- HealthCheckContext.

#### Phase 2 — Application Core

- HealthProviderInterface;
- HealthRegistry;
- HealthAggregator;
- HealthProviderExecutor;
- HealthManager.

#### Phase 3 — Infrastructure

- file cache;
- structured logging telemetry;
- database repositories;
- schema migration.

#### Phase 4 — Initial Providers

- database;
- storage;
- queue;
- scheduler.

#### Phase 5 — Extended Providers

- workflow;
- event bus;
- notification;
- integration;
- search;
- module;
- tenant;
- scope;
- security.

#### Phase 6 — Endpoint & Dashboard

Dibahas pada Part 4 dan Part 5.

---

### 36. Definition of Done Part 3

Part 3 dianggap selesai bila:

- [ ] HealthStatus tersedia.
- [ ] HealthCriticality tersedia.
- [ ] HealthCheckType tersedia.
- [ ] HealthCheckContext tersedia.
- [ ] HealthResult immutable tersedia.
- [ ] HealthReport tersedia.
- [ ] HealthProviderInterface tersedia.
- [ ] HealthRegistry tersedia.
- [ ] HealthProviderExecutor tersedia.
- [ ] HealthManager tersedia.
- [ ] HealthAggregator tersedia.
- [ ] Execution profile tersedia.
- [ ] Cache contract tersedia.
- [ ] Persistence contract tersedia.
- [ ] Database schema tersedia.
- [ ] Folder structure disepakati.
- [ ] Provider registration standard tersedia.
- [ ] Structured logging tersedia.
- [ ] Metrics contract tersedia.
- [ ] Detail sanitizer tersedia.
- [ ] UAT lulus.
- [ ] Tidak ada secret/PII/PHI dalam result.

---

### 37. Future Evolution

Framework harus siap berkembang menuju:

- asynchronous parallel provider execution;
- Redis cache;
- Prometheus exporter;
- OpenTelemetry health event correlation;
- Kubernetes liveness/readiness/startup probe;
- distributed service health;
- service dependency graph;
- automated incident creation;
- SLO/error budget integration;
- health trend prediction;
- tenant-level service status page;
- controlled remediation workflow.

Future evolution tidak boleh mengubah kontrak dasar `HealthProviderInterface` secara breaking tanpa versioning.

---

### 38. Lanjutan

Part 4 akan membahas:

- HTTP endpoint architecture;
- `/live`, `/ready`, `/health`;
- internal detail endpoint;
- response JSON standard;
- HTTP status mapping;
- authentication dan permission;
- rate limiting;
- Apache/XAMPP routing;
- CLI endpoint parity;
- sequence diagram;
- configuration profile;
- public vs internal disclosure policy.

---

## Bagian IV — HTTP Endpoints, Security, dan Routing

### 1. Executive Summary

Part 4 mendefinisikan bagaimana Health Check Framework diekspos ke:

- load balancer;
- browser;
- monitoring agent;
- CI/CD;
- administrator;
- CLI;
- future container orchestrator.

Endpoint health harus membedakan kebutuhan:

```text
process hidup
aplikasi siap menerima traffic
platform sehat secara operasional
diagnostik internal mendalam
```

Karena itu framework tidak boleh hanya memiliki satu endpoint generik.

Standar minimum:

```text
GET /live
GET /ready
GET /health
GET /internal/health
GET /internal/health/{component}
```

Setiap endpoint memiliki:

- tujuan;
- execution profile;
- authentication policy;
- response projection;
- timeout;
- HTTP status mapping;
- rate limit;
- logging policy.

---

### 2. Design Goals

Interface health harus:

- sederhana untuk machine probe;
- stabil dan versionable;
- aman untuk endpoint publik;
- tidak membocorkan detail internal;
- cepat;
- konsisten;
- mendukung per-component diagnostics;
- dapat dipakai CLI;
- kompatibel dengan Apache/XAMPP;
- siap dikembangkan untuk Kubernetes dan service mesh.

---

### 3. Endpoint Classification

#### 3.1 Public Probe Endpoints

Endpoint minimal disclosure:

```text
GET /live
GET /ready
GET /health
```

Digunakan oleh:

- load balancer;
- reverse proxy;
- uptime monitor;
- deployment validation;
- administrator dasar.

#### 3.2 Internal Diagnostic Endpoints

Endpoint detail:

```text
GET /internal/health
GET /internal/health/{component}
GET /internal/health/tenants/{tenantId}
GET /internal/health/reports/{reportId}
```

Digunakan oleh:

- platform administrator;
- security administrator;
- operations;
- support engineer;
- incident responder.

#### 3.3 Command Line Interface

Contoh:

```bash
php tools/health-check.php --profile=live
php tools/health-check.php --profile=ready
php tools/health-check.php --profile=deep
php tools/health-check.php --provider=database
```

CLI harus menggunakan `HealthManager` yang sama, bukan implementasi terpisah.

---

### 4. Endpoint: GET /live

#### 4.1 Tujuan

Menjawab:

> Apakah process aplikasi dapat merespons?

Liveness tidak dimaksudkan untuk memeriksa seluruh dependency.

#### 4.2 Pemeriksaan

Boleh memeriksa:

- PHP process berhasil menjalankan request;
- bootstrap minimum berhasil;
- kernel dapat membuat response;
- optional lightweight self-state.

Tidak boleh memeriksa:

- database query berat;
- integration;
- queue backlog;
- seluruh tenant;
- scope hierarchy;
- external network.

#### 4.3 Execution Profile

```text
type = LIVE
cache = false
persist = false
details = false
overall timeout = 250 ms
```

#### 4.4 Response UP

```json
{
  "status": "UP",
  "service": "platform-kernel",
  "timestamp": "2026-07-04T19:00:00+07:00"
}
```

#### 4.5 Response Failure

Jika aplikasi masih dapat menghasilkan response tetapi bootstrap minimum bermasalah:

```json
{
  "status": "DOWN",
  "service": "platform-kernel",
  "timestamp": "2026-07-04T19:00:00+07:00"
}
```

---

### 5. Endpoint: GET /ready

#### 5.1 Tujuan

Menjawab:

> Apakah aplikasi siap menerima request pengguna?

Readiness memeriksa dependency kritis minimum.

#### 5.2 Provider Minimum

Rekomendasi:

- database;
- authentication configuration;
- scope engine;
- RBAC;
- event outbox bila wajib;
- storage minimum;
- module kernel-critical.

#### 5.3 Execution Profile

```text
type = READY
cache = true
persist = false
details = false
overall timeout = 2000 ms
stop_on_critical_down = true
```

#### 5.4 Response UP

```json
{
  "status": "UP",
  "service": "platform-kernel",
  "ready": true,
  "timestamp": "2026-07-04T19:00:00+07:00"
}
```

#### 5.5 Response Not Ready

```json
{
  "status": "DOWN",
  "service": "platform-kernel",
  "ready": false,
  "timestamp": "2026-07-04T19:00:00+07:00",
  "code": "SERVICE_NOT_READY"
}
```

Endpoint publik tidak menampilkan provider mana yang gagal.

---

### 6. Endpoint: GET /health

#### 6.1 Tujuan

Memberikan ringkasan kesehatan platform.

Endpoint dapat digunakan untuk:

- uptime monitor;
- dashboard ringkas;
- operational status;
- deployment smoke test.

#### 6.2 Execution Profile

Rekomendasi:

```text
type = SHALLOW
cache = true
persist = false
details = false
overall timeout = 3000 ms
```

#### 6.3 Response Standard

```json
{
  "status": "DEGRADED",
  "service": "platform-kernel",
  "version": "1.0.0",
  "environment": "production",
  "timestamp": "2026-07-04T19:00:00+07:00",
  "duration_ms": 86,
  "request_id": "01J2ABCDEF1234567890"
}
```

Public response tidak menampilkan:

- hostname internal;
- database name;
- module class;
- IP internal;
- tenant detail;
- security control detail;
- stack trace;
- error message mentah.

---

### 7. Endpoint: GET /internal/health

#### 7.1 Tujuan

Memberikan diagnostic report kepada pihak berwenang.

#### 7.2 Authentication

Wajib:

- authenticated user atau service account;
- permission `observability.health.detail.read`;
- valid active scope;
- tenant boundary;
- optional IP allowlist;
- audit logging.

#### 7.3 Response

```json
{
  "report_id": "49f866831b5649f7a25af4d8c83306c1",
  "status": "DEGRADED",
  "service": "platform-kernel",
  "version": "1.0.0",
  "environment": "production",
  "check_type": "shallow",
  "timestamp": "2026-07-04T19:00:00+07:00",
  "duration_ms": 184,
  "components": {
    "database": {
      "status": "UP",
      "criticality": "critical",
      "duration_ms": 18,
      "message": "Database is reachable.",
      "checked_at": "2026-07-04T19:00:00+07:00",
      "valid_until": "2026-07-04T19:00:05+07:00"
    },
    "queue": {
      "status": "DEGRADED",
      "criticality": "important",
      "duration_ms": 8,
      "message": "Queue backlog exceeded warning threshold.",
      "error_code": "HEALTH_QUEUE_BACKLOG_HIGH",
      "details": {
        "pending_jobs": 128,
        "oldest_job_seconds": 420
      },
      "checked_at": "2026-07-04T19:00:00+07:00"
    }
  },
  "summary": {
    "up": 11,
    "degraded": 1,
    "down": 0,
    "unknown": 0,
    "maintenance": 0
  }
}
```

---

### 8. Endpoint: GET /internal/health/{component}

#### 8.1 Tujuan

Menjalankan atau membaca hasil satu provider.

Contoh:

```text
GET /internal/health/database
GET /internal/health/queue
GET /internal/health/security
```

#### 8.2 Validation

`component` harus berasal dari HealthRegistry.

Tidak boleh:

- digunakan sebagai class name;
- digunakan sebagai file path;
- dieksekusi secara dinamis dari input mentah.

#### 8.3 Query Parameters

Contoh:

```text
?type=shallow
?refresh=false
?details=true
```

Aturan:

| Parameter | Nilai | Policy |
|---|---|---|
| type | shallow/deep | deep perlu permission tambahan |
| refresh | true/false | true mengabaikan cache |
| details | true/false | hanya endpoint internal |
| tenant_id | integer | wajib tenant access validation |
| scope_id | integer | wajib scope validation |

#### 8.4 Permission

Minimum:

```text
observability.health.detail.read
```

Tambahan:

```text
observability.health.deep.execute
observability.health.cache.bypass
observability.health.security.read
observability.health.tenant.read
```

---

### 9. Tenant-Specific Endpoint

Contoh:

```text
GET /internal/health/tenants/12
```

#### 9.1 Policy

Endpoint wajib memastikan:

- actor boleh mengakses tenant tersebut;
- global platform admin atau tenant admin yang sah;
- tenant ID tidak digunakan tanpa scope validation;
- response tidak menyertakan tenant lain.

#### 9.2 Response

```json
{
  "tenant_id": 12,
  "status": "DEGRADED",
  "timestamp": "2026-07-04T19:00:00+07:00",
  "components": {
    "configuration": {
      "status": "UP"
    },
    "quota": {
      "status": "DEGRADED",
      "usage_percent": 92
    },
    "scope": {
      "status": "UP"
    }
  }
}
```

Public tenant endpoint tidak direkomendasikan.

---

### 10. Historical Report Endpoint

Contoh:

```text
GET /internal/health/reports/{reportId}
```

#### 10.1 Tujuan

Membaca snapshot yang telah disimpan.

#### 10.2 Policy

- read-only;
- permission `observability.health.history.read`;
- tenant/scope filtering;
- detail sanitization;
- retention enforcement.

#### 10.3 Not Found

Jangan membedakan secara berlebihan antara report tidak ada dan report tidak dapat diakses.

Gunakan:

```json
{
  "status": "ERROR",
  "code": "HEALTH_REPORT_NOT_FOUND",
  "message": "Health report was not found."
}
```

---

### 11. Canonical Response Envelope

#### 11.1 Success Envelope

```json
{
  "status": "UP",
  "data": {},
  "meta": {
    "service": "platform-kernel",
    "version": "1.0.0",
    "environment": "production",
    "timestamp": "2026-07-04T19:00:00+07:00",
    "request_id": "01J2ABCDEF1234567890",
    "duration_ms": 18
  }
}
```

Namun untuk `/live` dan `/ready`, compact response diperbolehkan agar probe sederhana.

#### 11.2 Error Envelope

```json
{
  "status": "ERROR",
  "code": "HEALTH_PERMISSION_DENIED",
  "message": "You are not authorized to access health details.",
  "meta": {
    "timestamp": "2026-07-04T19:00:00+07:00",
    "request_id": "01J2ABCDEF1234567890"
  }
}
```

#### 11.3 Naming Convention

Gunakan:

```text
snake_case
```

Contoh:

```text
duration_ms
checked_at
valid_until
error_code
request_id
```

---

### 12. HTTP Status Mapping

#### 12.1 Liveness

| Health Status | HTTP |
|---|---:|
| UP | 200 |
| DOWN | 503 |
| UNKNOWN | 503 |

#### 12.2 Readiness

| Health Status | HTTP |
|---|---:|
| UP | 200 |
| DEGRADED tetapi masih siap | 200 |
| DOWN | 503 |
| UNKNOWN | 503 |
| MAINTENANCE | 503 |

#### 12.3 General Health

Rekomendasi:

| Health Status | HTTP |
|---|---:|
| UP | 200 |
| DEGRADED | 200 |
| MAINTENANCE | 200 atau 503 sesuai endpoint |
| DOWN | 503 |
| UNKNOWN | 503 |

#### 12.4 Internal Diagnostic

Internal diagnostic sebaiknya:

- HTTP 200 bila report berhasil dibuat, meskipun component status DOWN;
- HTTP 4xx untuk request/auth error;
- HTTP 5xx bila framework tidak dapat membuat report.

Contoh:

```text
GET /internal/health
HTTP 200
overall status = DOWN
```

Alasannya: request diagnostic berhasil, dan data health berhasil dikembalikan.

#### 12.5 Authentication Errors

| Kondisi | HTTP |
|---|---:|
| unauthenticated | 401 |
| authenticated tetapi tidak berwenang | 403 |
| tenant/scope tidak ditemukan atau tidak dapat diakses | 404 |
| rate limit | 429 |
| invalid query | 422 |

---

### 13. Response Projection

#### 13.1 Public Projection

Field yang diperbolehkan:

```text
status
service
version
timestamp
duration_ms
request_id
ready
code generik
```

#### 13.2 Internal Projection

Field tambahan:

```text
component
criticality
message aman
details yang disanitasi
warnings
error_code
checked_at
valid_until
dependencies
```

#### 13.3 Security Projection

Security component memiliki projection paling ketat.

Public:

```json
{
  "status": "UP"
}
```

Internal security role:

```json
{
  "status": "DEGRADED",
  "controls": {
    "debug_disabled": "UP",
    "audit_enabled": "UP",
    "key_rotation": "DEGRADED"
  }
}
```

---

### 14. Controller Architecture

#### 14.1 Thin Controller

Controller hanya:

1. membaca request;
2. melakukan authorization;
3. membuat context/profile;
4. memanggil HealthManager;
5. memproyeksikan report;
6. menentukan HTTP status;
7. mengembalikan JSON.

Controller tidak boleh:

- memeriksa database langsung;
- menghitung status;
- menjalankan provider langsung;
- menyimpan snapshot sendiri;
- menampilkan exception mentah.

#### 14.2 Example Controller

```php
<?php

declare(strict_types=1);

namespace App\Platform\Observability\Health\Presentation\Http;

use App\Platform\Observability\Health\Application\HealthManager;
use App\Platform\Observability\Health\Application\HealthProfileFactory;
use App\Platform\Observability\Health\Domain\HealthCheckContext;
use App\Platform\Observability\Health\Domain\HealthCheckType;
use App\Platform\Observability\Health\Domain\HealthStatus;

final class HealthController
{
    public function __construct(
        private readonly HealthManager $manager,
        private readonly HealthProfileFactory $profiles,
        private readonly HealthResponseProjector $projector,
    ) {
    }

    public function live(): void
    {
        $context = new HealthCheckContext(
            type: HealthCheckType::LIVE,
            environment: APP_ENV,
            correlationId: request_id(),
            includeDetails: false,
        );

        $report = $this->manager->run(
            $context,
            $this->profiles->live()
        );

        json_response(
            $this->projector->publicLive($report),
            $report->status === HealthStatus::UP ? 200 : 503
        );
    }

    public function ready(): void
    {
        $context = new HealthCheckContext(
            type: HealthCheckType::READY,
            environment: APP_ENV,
            correlationId: request_id(),
            includeDetails: false,
        );

        $report = $this->manager->run(
            $context,
            $this->profiles->ready()
        );

        json_response(
            $this->projector->publicReady($report),
            in_array(
                $report->status,
                [HealthStatus::UP, HealthStatus::DEGRADED],
                true
            ) ? 200 : 503
        );
    }
}
```

---

### 15. HealthResponseProjector

#### 15.1 Tujuan

Memisahkan internal domain object dari response HTTP.

#### 15.2 Kontrak

```php
interface HealthResponseProjectorInterface
{
    public function publicLive(HealthReport $report): array;

    public function publicReady(HealthReport $report): array;

    public function publicHealth(HealthReport $report): array;

    public function internalHealth(HealthReport $report): array;

    public function internalComponent(HealthResult $result): array;
}
```

#### 15.3 Keuntungan

- public detail dapat dibatasi;
- versioning response lebih mudah;
- domain model tidak tergantung HTTP;
- output CLI dapat memakai projector berbeda;
- test keamanan lebih mudah.

---

### 16. API Versioning

#### 16.1 Stable Probe URL

URL berikut sebaiknya stabil:

```text
/live
/ready
/health
```

Jangan sering diubah karena digunakan load balancer.

#### 16.2 Internal API Versioning

Internal endpoint dapat memakai:

```text
/api/internal/v1/health
/api/internal/v1/health/{component}
```

Alternatif bila struktur aplikasi tidak memakai `/api`:

```text
/internal/health/v1
```

Pilih satu pola secara konsisten.

#### 16.3 Response Version

Tambahkan:

```json
{
  "schema_version": "1.0"
}
```

untuk internal diagnostic jika integrasi eksternal membaca response.

---

### 17. Authentication & Authorization

#### 17.1 Public Endpoint

`/live`, `/ready`, dan `/health` dapat tanpa authentication, tetapi wajib:

- minimal response;
- rate limiting;
- no-cache atau short cache;
- tidak menampilkan detail;
- tidak menampilkan dependency name sensitif.

#### 17.2 Internal Endpoint

Wajib authentication.

Metode:

- authenticated web session;
- service account;
- internal API token;
- mTLS di masa depan.

#### 17.3 Permission Matrix

| Endpoint | Permission |
|---|---|
| `/internal/health` | `observability.health.detail.read` |
| component detail | `observability.health.detail.read` |
| deep check | `observability.health.deep.execute` |
| bypass cache | `observability.health.cache.bypass` |
| security detail | `observability.health.security.read` |
| tenant detail | `observability.health.tenant.read` |
| history | `observability.health.history.read` |

#### 17.4 Scope Enforcement

Tenant-specific health harus mengikuti active scope.

Global health detail hanya boleh untuk:

```text
platform_admin
operations_admin
security_admin sesuai detail
```

---

### 18. Audit Policy

Jangan audit setiap public probe karena volume tinggi.

Audit wajib untuk:

- akses security health detail;
- menjalankan deep check manual;
- force refresh;
- bypass cache;
- membaca tenant health lintas tenant;
- mengubah threshold;
- mengubah maintenance state;
- mengaktifkan/nonaktifkan provider.

Audit event contoh:

```text
OBS_HEALTH_DEEP_CHECK_EXECUTED
OBS_HEALTH_SECURITY_DETAIL_VIEWED
OBS_HEALTH_CACHE_BYPASSED
OBS_HEALTH_TENANT_CROSS_SCOPE_VIEWED
```

---

### 19. Rate Limiting

#### 19.1 Public Probe

Rekomendasi awal per IP:

```text
/live: 120 request/menit
/ready: 120 request/menit
/health: 60 request/menit
```

Load balancer internal dapat dikecualikan melalui trusted network policy.

#### 19.2 Internal Diagnostic

```text
/internal/health: 30 request/menit/user
deep check: 5 request/15 menit/user
force refresh: 10 request/15 menit/user
```

#### 19.3 Response

```json
{
  "status": "ERROR",
  "code": "RATE_LIMIT_EXCEEDED",
  "message": "Too many health check requests."
}
```

HTTP:

```text
429 Too Many Requests
```

---

### 20. Cache Headers

#### 20.1 Liveness

```http
Cache-Control: no-store, no-cache, must-revalidate
Pragma: no-cache
```

#### 20.2 Readiness

```http
Cache-Control: no-store
```

#### 20.3 General Health

Boleh short cache:

```http
Cache-Control: private, max-age=5
```

Namun untuk endpoint publik lebih aman:

```http
Cache-Control: no-store
```

Caching utama dilakukan di application health result cache, bukan browser/proxy.

---

### 21. Security Headers

Response health tetap harus memiliki:

```http
Content-Type: application/json; charset=utf-8
X-Content-Type-Options: nosniff
X-Frame-Options: DENY
Referrer-Policy: no-referrer
```

Untuk API:

```http
Content-Security-Policy: default-src 'none'; frame-ancestors 'none'
```

---

### 22. CORS Policy

Public health endpoint tidak memerlukan cross-origin browser access secara default.

Rekomendasi:

```text
Access-Control-Allow-Origin tidak disetel
```

Jika dashboard berbeda origin memerlukan akses:

- gunakan explicit allowlist;
- jangan gunakan `*` untuk endpoint internal;
- credentials hanya untuk trusted origin.

---

### 23. CSRF Policy

#### 23.1 GET Health Endpoint

Karena read-only:

```text
CSRF tidak diperlukan
```

#### 23.2 Future Mutation Endpoint

Jika tersedia endpoint:

```text
POST /internal/health/maintenance
POST /internal/health/cache/invalidate
```

Wajib:

- CSRF untuk session-based web;
- authentication;
- permission;
- audit;
- idempotency policy.

Part 4 tidak merekomendasikan mutation endpoint sebelum workflow governance tersedia.

---

### 24. Apache/XAMPP Routing

#### 24.1 Document Root

Rekomendasi:

```text
D:\xampp\htdocs\platform\public
```

Apache DocumentRoot harus diarahkan ke folder `public`.

#### 24.2 `.htaccess`

Contoh:

```apache
RewriteEngine On

# Biarkan file/folder nyata dilayani langsung.
RewriteCond %{REQUEST_FILENAME} -f [OR]
RewriteCond %{REQUEST_FILENAME} -d
RewriteRule ^ - [L]

# Health routes masuk ke front controller.
RewriteRule ^ index.php [QSA,L]
```

#### 24.3 Virtual Host

Contoh:

```apache
<VirtualHost *:80>
    ServerName platform.local
    DocumentRoot "D:/xampp/htdocs/platform/public"

    <Directory "D:/xampp/htdocs/platform/public">
        AllowOverride All
        Require all granted
        Options -Indexes
    </Directory>

    ErrorLog "logs/platform-error.log"
    CustomLog "logs/platform-access.log" combined
</VirtualHost>
```

Tambahkan hosts Windows:

```text
127.0.0.1 platform.local
```

#### 24.4 Route Registration

Contoh pseudo-router:

```php
$router->get('/live', [HealthController::class, 'live']);
$router->get('/ready', [HealthController::class, 'ready']);
$router->get('/health', [HealthController::class, 'health']);

$router->group('/internal/health', function ($router): void {
    $router->get('', [InternalHealthController::class, 'index']);
    $router->get('/{component}', [InternalHealthController::class, 'component']);
});
```

---

### 25. Reverse Proxy & Trusted IP

Jika Apache berada di belakang proxy:

- definisikan trusted proxy;
- jangan mempercayai `X-Forwarded-For` dari semua client;
- rate limit menggunakan resolved trusted client IP;
- HTTPS detection harus mempertimbangkan trusted proxy header.

---

### 26. Maintenance Mode

#### 26.1 Application Maintenance

Saat deployment:

```text
/live = UP
/ready = 503 MAINTENANCE
/health = MAINTENANCE
```

Tujuannya:

- process tetap terlihat hidup;
- traffic baru dihentikan;
- deployment dapat menyelesaikan proses.

#### 26.2 Response

```json
{
  "status": "MAINTENANCE",
  "ready": false,
  "code": "SERVICE_MAINTENANCE",
  "timestamp": "2026-07-04T19:00:00+07:00"
}
```

#### 26.3 Tenant Maintenance

Tenant maintenance tidak harus membuat platform global tidak ready.

Tenant-specific endpoint menampilkan:

```text
MAINTENANCE
```

---

### 27. CLI Parity

CLI harus mendukung profile yang sama.

#### 27.1 Output Human

```text
Platform Health: DEGRADED

database      UP          18 ms
storage       UP           3 ms
queue         DEGRADED     8 ms
```

#### 27.2 Output JSON

```bash
php tools/health-check.php --profile=ready --format=json
```

#### 27.3 Exit Code

| Status | Exit Code |
|---|---:|
| UP | 0 |
| DEGRADED | 1 |
| DOWN | 2 |
| UNKNOWN | 3 |
| invalid command/config | 4 |

CI/CD dapat memakai exit code untuk menghentikan deployment.

---

### 28. Sequence Diagram — Public Readiness

```mermaid
sequenceDiagram
    participant LB as Load Balancer
    participant HC as HealthController
    participant HM as HealthManager
    participant HR as HealthRegistry
    participant Cache as Health Result Cache
    participant Provider as Critical Providers
    participant HA as HealthAggregator
    participant RP as ResponseProjector

    LB->>HC: GET /ready
    HC->>HM: run(context, ready profile)
    HM->>HR: providers for READY
    HR-->>HM: provider list

    loop each provider
        HM->>Cache: get cached result
        alt cache hit
            Cache-->>HM: HealthResult
        else cache miss
            HM->>Provider: check(context)
            Provider-->>HM: HealthResult
            HM->>Cache: put result
        end
    end

    HM->>HA: aggregate(results)
    HA-->>HM: overall status
    HM-->>HC: HealthReport
    HC->>RP: publicReady(report)
    RP-->>HC: safe JSON
    HC-->>LB: 200 or 503
```

---

### 29. Sequence Diagram — Internal Deep Check

```mermaid
sequenceDiagram
    participant Admin as Operations Admin
    participant Auth as Auth/RBAC/Scope
    participant IHC as InternalHealthController
    participant Audit as Audit Service
    participant HM as HealthManager
    participant Provider as Deep Health Providers
    participant Repo as Snapshot Repository
    participant RP as Internal Projector

    Admin->>IHC: GET /internal/health?type=deep&refresh=true
    IHC->>Auth: authorize permissions and scope
    Auth-->>IHC: allowed
    IHC->>Audit: record deep check execution
    IHC->>HM: run(deep context, deep profile)
    HM->>Provider: execute deep checks
    Provider-->>HM: HealthResults
    HM->>Repo: persist report and transitions
    Repo-->>HM: saved
    HM-->>IHC: HealthReport
    IHC->>RP: internalHealth(report)
    RP-->>IHC: sanitized detailed JSON
    IHC-->>Admin: HTTP 200
```

---

### 30. Data Flow

```text
HTTP Request
    ↓
Router
    ↓
Authentication Middleware
    ↓
Permission Middleware
    ↓
Scope Middleware
    ↓
Health Controller
    ↓
Context + Execution Profile
    ↓
Health Manager
    ↓
Registry → Cache → Executor → Provider
    ↓
Aggregator
    ↓
Telemetry / Optional Persistence
    ↓
Response Projector
    ↓
HTTP Response
```

---

### 31. Middleware Order

Rekomendasi internal endpoint:

```text
Request ID
→ Trusted Proxy
→ Security Headers
→ Authentication
→ Rate Limit
→ Tenant Context
→ Active Scope
→ Permission
→ Audit Context
→ Controller
```

Untuk public probe:

```text
Request ID
→ Trusted Proxy
→ Rate Limit
→ Security Headers
→ Controller
```

Public probe tidak boleh bergantung pada session/database hanya untuk authentication.

---

### 32. Configuration

Contoh tambahan `config/health.php`:

```php
return [
    'routes' => [
        'live' => '/live',
        'ready' => '/ready',
        'health' => '/health',
        'internal_prefix' => '/internal/health',
    ],

    'http' => [
        'public_details' => false,
        'include_version' => true,
        'include_environment' => true,
        'include_request_id' => true,
    ],

    'timeouts' => [
        'live_ms' => 250,
        'ready_ms' => 2000,
        'health_ms' => 3000,
        'deep_ms' => 30000,
    ],

    'rate_limits' => [
        'live_per_minute' => 120,
        'ready_per_minute' => 120,
        'health_per_minute' => 60,
        'internal_per_minute' => 30,
        'deep_per_15_minutes' => 5,
    ],

    'maintenance' => [
        'enabled' => false,
        'message' => 'Service is under maintenance.',
    ],

    'permissions' => [
        'detail_read' => 'observability.health.detail.read',
        'deep_execute' => 'observability.health.deep.execute',
        'cache_bypass' => 'observability.health.cache.bypass',
        'security_read' => 'observability.health.security.read',
        'tenant_read' => 'observability.health.tenant.read',
        'history_read' => 'observability.health.history.read',
    ],
];
```

---

### 33. Error Codes

Standar kode:

```text
SERVICE_NOT_READY
SERVICE_MAINTENANCE
HEALTH_COMPONENT_NOT_FOUND
HEALTH_CHECK_TYPE_INVALID
HEALTH_PERMISSION_DENIED
HEALTH_SCOPE_DENIED
HEALTH_TENANT_NOT_FOUND
HEALTH_DEEP_CHECK_FORBIDDEN
HEALTH_CACHE_BYPASS_FORBIDDEN
HEALTH_REPORT_NOT_FOUND
HEALTH_FRAMEWORK_FAILURE
RATE_LIMIT_EXCEEDED
```

Error code harus stabil dan terdokumentasi.

---

### 34. Logging Policy

#### 34.1 Public Probe

Jangan log setiap probe pada application log level INFO jika traffic tinggi.

Pilihan:

- access log Apache;
- sampling;
- log hanya failure/status change;
- metric counter.

#### 34.2 Internal Access

Log:

- actor;
- endpoint;
- profile;
- component;
- tenant/scope;
- duration;
- response status;
- permission result.

#### 34.3 Sensitive Data

Jangan log:

- authorization header;
- session cookie;
- token;
- secret;
- patient/customer data;
- raw diagnostic payload sensitif.

---

### 35. Observability of Health Endpoint

Health endpoint sendiri harus dipantau.

Metric:

```text
health_http_request_total
health_http_duration_ms
health_http_response_status_total
health_http_rate_limited_total
health_http_authorization_failure_total
health_deep_check_request_total
```

Jangan membuat recursive health check.

Health endpoint metric tidak boleh memanggil health endpoint kembali.

---

### 36. Performance Standard

| Endpoint | Target p95 |
|---|---:|
| `/live` | < 100 ms |
| `/ready` | < 1000 ms |
| `/health` | < 1500 ms |
| internal cached | < 1000 ms |
| deep check | asynchronous/scheduled atau < 30 detik |

Aturan:

- compact JSON;
- no expensive serialization;
- use cached result;
- stop on critical down untuk readiness;
- jangan membaca history pada public endpoint;
- jangan melakukan seluruh tenant scan live.

---

### 37. Testing Strategy

#### 37.1 Contract Test

Uji:

- field response;
- naming;
- HTTP status;
- content type;
- no secret disclosure;
- schema version.

#### 37.2 Security Test

Uji:

- unauthenticated internal endpoint;
- unauthorized role;
- cross-tenant access;
- missing scope;
- force refresh permission;
- security detail permission;
- rate limit.

#### 37.3 Routing Test

Uji:

- Apache rewrite;
- direct URL;
- query parameter;
- unknown component;
- trailing slash;
- invalid HTTP method.

#### 37.4 Load Test

Uji:

- repeated `/live`;
- repeated `/ready`;
- cache hit ratio;
- timeout behavior;
- concurrent health request.

---

### 38. UAT Part 4

#### 38.1 Public Endpoint

- [ ] `/live` mengembalikan HTTP 200 saat process hidup.
- [ ] `/live` tidak mengakses dependency berat.
- [ ] `/ready` mengembalikan 503 saat critical provider DOWN.
- [ ] `/health` mengembalikan response ringkas.
- [ ] Tidak ada detail internal pada response publik.
- [ ] Header cache dan security sesuai.

#### 38.2 Internal Endpoint

- [ ] Internal endpoint membutuhkan authentication.
- [ ] Permission detail read diterapkan.
- [ ] Component tidak terdaftar menghasilkan 404/422 yang aman.
- [ ] Deep check membutuhkan permission khusus.
- [ ] Force refresh membutuhkan permission khusus.
- [ ] Security detail hanya dapat dibaca role yang berwenang.
- [ ] Tenant health mengikuti scope.

#### 38.3 HTTP Mapping

- [ ] UP dipetakan dengan benar.
- [ ] DEGRADED readiness mengikuti policy.
- [ ] DOWN readiness menghasilkan 503.
- [ ] Diagnostic report DOWN tetap dapat HTTP 200 bila report berhasil dibuat.
- [ ] Rate limit menghasilkan 429.

#### 38.4 Apache/XAMPP

- [ ] Virtual host berfungsi.
- [ ] `.htaccess` mengarahkan route ke front controller.
- [ ] File statis tidak terganggu.
- [ ] Directory listing nonaktif.
- [ ] Endpoint dapat diakses melalui `platform.local`.

#### 38.5 Security

- [ ] Tidak ada stack trace.
- [ ] Tidak ada token/secret.
- [ ] CORS internal tidak memakai wildcard.
- [ ] Cross-tenant access ditolak.
- [ ] Deep check manual diaudit.

#### 38.6 CLI

- [ ] CLI menggunakan HealthManager yang sama.
- [ ] JSON output valid.
- [ ] Exit code sesuai status.
- [ ] CI dapat menghentikan deployment saat readiness DOWN.

---

### 39. Anti-Pattern

Hindari:

- satu endpoint mengembalikan seluruh detail ke publik;
- `/live` memeriksa database;
- `/ready` menjalankan deep tenant scan;
- HTTP 200 selalu dipakai tanpa memedulikan readiness;
- controller menjalankan SQL langsung;
- route component digunakan sebagai class name;
- authentication public probe bergantung database;
- menyimpan setiap probe ke database;
- menampilkan environment secret;
- wildcard CORS pada endpoint internal;
- tidak memasang rate limit;
- deep check dapat dipanggil semua user;
- maintenance mode membuat `/live` DOWN;
- membuat endpoint health yang bergantung pada dashboard.

---

### 40. Definition of Done Part 4

Part 4 dianggap selesai bila:

- [ ] `/live` didefinisikan.
- [ ] `/ready` didefinisikan.
- [ ] `/health` didefinisikan.
- [ ] internal health endpoint didefinisikan.
- [ ] component endpoint didefinisikan.
- [ ] tenant-specific endpoint didefinisikan.
- [ ] historical endpoint didefinisikan.
- [ ] public/internal projection tersedia.
- [ ] HTTP status mapping tersedia.
- [ ] permission matrix tersedia.
- [ ] scope policy tersedia.
- [ ] rate limiting tersedia.
- [ ] security headers tersedia.
- [ ] cache header policy tersedia.
- [ ] Apache/XAMPP routing tersedia.
- [ ] CLI parity tersedia.
- [ ] sequence diagram tersedia.
- [ ] configuration tersedia.
- [ ] UAT tersedia.
- [ ] tidak ada detail sensitif pada public response.

---

### 41. Future Evolution

Interface harus siap untuk:

- Kubernetes startup/liveness/readiness probes;
- service mesh health endpoint;
- Prometheus scrape endpoint;
- public status page;
- signed machine-to-machine diagnostic request;
- mTLS internal endpoint;
- health webhook;
- multi-region readiness;
- blue-green deployment;
- canary deployment;
- automated traffic draining;
- API schema publication.

---

### 42. Lanjutan

Part 5 akan membahas:

- reference implementation end-to-end;
- bootstrap wiring;
- concrete controller/projector example;
- SQL migration package;
- CLI script;
- sample configuration;
- test cases;
- deployment checklist;
- incident scenarios;
- final UAT;
- Definition of Done framework;
- future roadmap;
- final merge guidance untuk `SSOT-OBS-05.md`.

---

## Bagian V — Reference Implementation dan Operational Readiness

### 1. Executive Summary

Part 5 menutup rangkaian SSOT-OBS-05 dengan reference implementation yang dapat dijadikan acuan langsung untuk membangun Health Check Framework.

Bagian ini mencakup:

- bootstrap wiring;
- profile factory;
- registry initialization;
- concrete provider registration;
- response projector;
- controller;
- CLI command;
- SQL migration package;
- sample configuration;
- sample test;
- deployment checklist;
- incident scenarios;
- final UAT;
- rollback;
- Definition of Done;
- roadmap;
- panduan merge Part 1–5 menjadi `SSOT-OBS-05.md`.

Tujuan Part 5 bukan menghasilkan framework final yang langsung production-ready tanpa review, tetapi menyediakan baseline implementasi yang konsisten dengan seluruh keputusan arsitektur sebelumnya.

---

### 2. Reference Implementation Scope

Reference implementation minimum terdiri dari:

```text
Domain
Application
Infrastructure
Presentation
Configuration
Migration
CLI
Tests
Operations
```

Initial provider yang wajib tersedia:

```text
database
storage
queue
scheduler
```

Provider lanjutan:

```text
workflow
event_bus
notification
integration
search
module
tenant
scope
security
```

---

### 3. Final Folder Structure

```text
project-root/
├── app/
│   ├── Platform/
│   │   └── Observability/
│   │       └── Health/
│   │           ├── Domain/
│   │           │   ├── HealthStatus.php
│   │           │   ├── HealthCriticality.php
│   │           │   ├── HealthCheckType.php
│   │           │   ├── HealthCheckContext.php
│   │           │   ├── HealthExecutionProfile.php
│   │           │   ├── HealthResult.php
│   │           │   └── HealthReport.php
│   │           │
│   │           ├── Application/
│   │           │   ├── Contracts/
│   │           │   │   ├── HealthProviderInterface.php
│   │           │   │   ├── HealthAggregatorInterface.php
│   │           │   │   ├── HealthProviderExecutorInterface.php
│   │           │   │   ├── HealthResultCacheInterface.php
│   │           │   │   ├── HealthSnapshotRepositoryInterface.php
│   │           │   │   ├── HealthStateRepositoryInterface.php
│   │           │   │   ├── HealthTransitionRepositoryInterface.php
│   │           │   │   ├── HealthTelemetryInterface.php
│   │           │   │   └── HealthDetailSanitizerInterface.php
│   │           │   ├── HealthRegistry.php
│   │           │   ├── HealthManager.php
│   │           │   ├── HealthAggregator.php
│   │           │   ├── HealthProviderExecutor.php
│   │           │   └── HealthProfileFactory.php
│   │           │
│   │           ├── Infrastructure/
│   │           │   ├── Cache/
│   │           │   │   ├── FileHealthResultCache.php
│   │           │   │   └── NullHealthResultCache.php
│   │           │   ├── Persistence/
│   │           │   │   ├── PdoHealthSnapshotRepository.php
│   │           │   │   ├── PdoHealthStateRepository.php
│   │           │   │   └── PdoHealthTransitionRepository.php
│   │           │   ├── Telemetry/
│   │           │   │   ├── StructuredLogHealthTelemetry.php
│   │           │   │   └── CompositeHealthTelemetry.php
│   │           │   ├── Security/
│   │           │   │   └── DefaultHealthDetailSanitizer.php
│   │           │   └── Providers/
│   │           │       ├── DatabaseHealthProvider.php
│   │           │       ├── StorageHealthProvider.php
│   │           │       ├── QueueHealthProvider.php
│   │           │       └── SchedulerHealthProvider.php
│   │           │
│   │           └── Presentation/
│   │               ├── Http/
│   │               │   ├── HealthController.php
│   │               │   ├── InternalHealthController.php
│   │               │   └── HealthResponseProjector.php
│   │               └── Cli/
│   │                   └── HealthCheckCommand.php
│   │
│   └── Modules/
│       └── <ModuleName>/
│           └── Infrastructure/
│               └── Health/
│                   └── <ModuleName>HealthProvider.php
│
├── config/
│   └── health.php
│
├── database/
│   └── migrations/
│       └── 2026_07_04_000001_create_health_check_tables.sql
│
├── public/
│   ├── index.php
│   └── .htaccess
│
├── storage/
│   ├── cache/
│   │   └── health/
│   └── logs/
│
├── tests/
│   ├── Unit/
│   │   └── Platform/Observability/Health/
│   └── Integration/
│       └── Platform/Observability/Health/
│
└── tools/
    └── health-check.php
```

---

### 4. Bootstrap Wiring

#### 4.1 Tujuan

Bootstrap health harus:

- menggunakan dependency injection;
- membuat registry satu kali;
- mendaftarkan provider;
- membuat manager;
- tidak melakukan health check saat bootstrap;
- gagal cepat pada duplicate provider atau konfigurasi invalid.

#### 4.2 Example Bootstrap Factory

```php
<?php

declare(strict_types=1);

namespace App\Platform\Observability\Health;

use App\Platform\Observability\Health\Application\HealthAggregator;
use App\Platform\Observability\Health\Application\HealthManager;
use App\Platform\Observability\Health\Application\HealthProviderExecutor;
use App\Platform\Observability\Health\Application\HealthRegistry;
use App\Platform\Observability\Health\Infrastructure\Cache\FileHealthResultCache;
use App\Platform\Observability\Health\Infrastructure\Persistence\PdoHealthSnapshotRepository;
use App\Platform\Observability\Health\Infrastructure\Providers\DatabaseHealthProvider;
use App\Platform\Observability\Health\Infrastructure\Providers\QueueHealthProvider;
use App\Platform\Observability\Health\Infrastructure\Providers\SchedulerHealthProvider;
use App\Platform\Observability\Health\Infrastructure\Providers\StorageHealthProvider;
use App\Platform\Observability\Health\Infrastructure\Security\DefaultHealthDetailSanitizer;
use App\Platform\Observability\Health\Infrastructure\Telemetry\StructuredLogHealthTelemetry;
use PDO;
use Psr\Log\LoggerInterface;

final class HealthBootstrap
{
    public static function build(
        PDO $pdo,
        LoggerInterface $logger,
        array $config,
    ): HealthManager {
        $sanitizer = new DefaultHealthDetailSanitizer(
            blockedKeys: $config['security']['blocked_detail_keys'] ?? []
        );

        $cache = new FileHealthResultCache(
            path: $config['cache']['path'],
            sanitizer: $sanitizer,
        );

        $registry = new HealthRegistry();

        $registry->register(new DatabaseHealthProvider(
            pdo: $pdo,
            warningLatencyMs: $config['providers']['database']['warning_latency_ms']
        ));

        $registry->register(new StorageHealthProvider(
            paths: $config['providers']['storage']['paths'],
            warningFreeSpacePercent:
                $config['providers']['storage']['warning_free_space_percent']
        ));

        $registry->register(new QueueHealthProvider(
            pdo: $pdo,
            pendingWarning: $config['providers']['queue']['pending_warning'],
            pendingDown: $config['providers']['queue']['pending_down'],
        ));

        $registry->register(new SchedulerHealthProvider(
            pdo: $pdo,
            heartbeatWarningSeconds:
                $config['providers']['scheduler']['heartbeat_warning_seconds'],
            heartbeatDownSeconds:
                $config['providers']['scheduler']['heartbeat_down_seconds'],
        ));

        $telemetry = new StructuredLogHealthTelemetry($logger);

        $executor = new HealthProviderExecutor(
            sanitizer: $sanitizer,
            logger: $logger,
        );

        $aggregator = new HealthAggregator(
            policy: $config['aggregation']
        );

        $snapshotRepository = new PdoHealthSnapshotRepository(
            pdo: $pdo,
            sanitizer: $sanitizer,
        );

        return new HealthManager(
            registry: $registry,
            executor: $executor,
            aggregator: $aggregator,
            cache: $cache,
            snapshots: $snapshotRepository,
            telemetry: $telemetry,
        );
    }
}
```

#### 4.3 Container Registration

Contoh pseudo-container:

```php
$container->singleton(
    HealthManager::class,
    static fn ($container): HealthManager => HealthBootstrap::build(
        pdo: $container->get(PDO::class),
        logger: $container->get(LoggerInterface::class),
        config: $container->get('config.health'),
    )
);
```

---

### 5. HealthProfileFactory

```php
<?php

declare(strict_types=1);

namespace App\Platform\Observability\Health\Application;

use App\Platform\Observability\Health\Domain\HealthCheckType;
use App\Platform\Observability\Health\Domain\HealthCriticality;
use App\Platform\Observability\Health\Domain\HealthExecutionProfile;

final class HealthProfileFactory
{
    public function __construct(
        private readonly array $config
    ) {
    }

    public function live(): HealthExecutionProfile
    {
        return new HealthExecutionProfile(
            type: HealthCheckType::LIVE,
            criticalities: [
                HealthCriticality::CRITICAL,
            ],
            includedProviders: [],
            excludedProviders: [],
            useCache: false,
            persistResult: false,
            stopOnCriticalDown: true,
            overallTimeoutMs:
                $this->config['profiles']['live']['overall_timeout_ms'],
        );
    }

    public function ready(): HealthExecutionProfile
    {
        return new HealthExecutionProfile(
            type: HealthCheckType::READY,
            criticalities: [
                HealthCriticality::CRITICAL,
                HealthCriticality::IMPORTANT,
            ],
            useCache: true,
            persistResult: false,
            stopOnCriticalDown: true,
            overallTimeoutMs:
                $this->config['profiles']['ready']['overall_timeout_ms'],
        );
    }

    public function shallow(): HealthExecutionProfile
    {
        return new HealthExecutionProfile(
            type: HealthCheckType::SHALLOW,
            criticalities: [
                HealthCriticality::CRITICAL,
                HealthCriticality::IMPORTANT,
                HealthCriticality::OPTIONAL,
            ],
            useCache: true,
            persistResult: false,
            stopOnCriticalDown: false,
            overallTimeoutMs:
                $this->config['profiles']['shallow']['overall_timeout_ms'],
        );
    }

    public function deep(): HealthExecutionProfile
    {
        return new HealthExecutionProfile(
            type: HealthCheckType::DEEP,
            criticalities: [
                HealthCriticality::CRITICAL,
                HealthCriticality::IMPORTANT,
                HealthCriticality::OPTIONAL,
            ],
            useCache: false,
            persistResult: true,
            stopOnCriticalDown: false,
            overallTimeoutMs:
                $this->config['profiles']['deep']['overall_timeout_ms'],
        );
    }
}
```

---

### 6. Reference Configuration

Contoh `config/health.php`:

```php
<?php

declare(strict_types=1);

return [
    'enabled' => true,

    'service' => [
        'name' => 'platform-kernel',
        'version' => getenv('APP_VERSION') ?: '1.0.0',
        'environment' => getenv('APP_ENV') ?: 'local',
    ],

    'profiles' => [
        'live' => [
            'overall_timeout_ms' => 250,
        ],
        'ready' => [
            'overall_timeout_ms' => 2000,
        ],
        'shallow' => [
            'overall_timeout_ms' => 3000,
        ],
        'deep' => [
            'overall_timeout_ms' => 30000,
        ],
    ],

    'providers' => [
        'database' => [
            'enabled' => true,
            'warning_latency_ms' => 250,
        ],

        'storage' => [
            'enabled' => true,
            'warning_free_space_percent' => 15,
            'paths' => [
                dirname(__DIR__) . '/storage/logs',
                dirname(__DIR__) . '/storage/cache',
                dirname(__DIR__) . '/storage/files',
                dirname(__DIR__) . '/storage/temp',
            ],
        ],

        'queue' => [
            'enabled' => true,
            'pending_warning' => 100,
            'pending_down' => 1000,
        ],

        'scheduler' => [
            'enabled' => true,
            'heartbeat_warning_seconds' => 120,
            'heartbeat_down_seconds' => 300,
        ],
    ],

    'cache' => [
        'driver' => 'file',
        'path' => dirname(__DIR__) . '/storage/cache/health',
    ],

    'persistence' => [
        'enabled' => true,
        'persist_profiles' => [
            'deep',
            'scheduled',
        ],
        'persist_on_change' => true,
    ],

    'aggregation' => [
        'critical_down' => 'DOWN',
        'important_down' => 'DEGRADED',
        'optional_down' => 'DEGRADED',
        'unknown_critical' => 'DOWN',
        'unknown_important' => 'DEGRADED',
    ],

    'security' => [
        'public_details' => false,
        'blocked_detail_keys' => [
            'password',
            'secret',
            'token',
            'authorization',
            'api_key',
            'client_secret',
            'dsn',
            'payload',
            'patient',
            'email',
            'phone',
        ],
    ],

    'routes' => [
        'live' => '/live',
        'ready' => '/ready',
        'health' => '/health',
        'internal_prefix' => '/internal/health',
    ],
];
```

---

### 7. Concrete Storage Provider

```php
<?php

declare(strict_types=1);

namespace App\Platform\Observability\Health\Infrastructure\Providers;

use App\Platform\Observability\Health\Application\Contracts\HealthProviderInterface;
use App\Platform\Observability\Health\Domain\HealthCheckContext;
use App\Platform\Observability\Health\Domain\HealthCheckType;
use App\Platform\Observability\Health\Domain\HealthCriticality;
use App\Platform\Observability\Health\Domain\HealthResult;
use App\Platform\Observability\Health\Domain\HealthStatus;
use DateTimeImmutable;
use Throwable;

final class StorageHealthProvider implements HealthProviderInterface
{
    /**
     * @param list<string> $paths
     */
    public function __construct(
        private readonly array $paths,
        private readonly int $warningFreeSpacePercent = 15,
    ) {
    }

    public function name(): string
    {
        return 'storage';
    }

    public function criticality(): HealthCriticality
    {
        return HealthCriticality::IMPORTANT;
    }

    public function supportedTypes(): array
    {
        return [
            HealthCheckType::READY,
            HealthCheckType::SHALLOW,
            HealthCheckType::DEEP,
            HealthCheckType::SCHEDULED,
        ];
    }

    public function timeoutMs(): int
    {
        return 500;
    }

    public function cacheTtlSeconds(): int
    {
        return 15;
    }

    public function check(HealthCheckContext $context): HealthResult
    {
        $startedAt = hrtime(true);
        $warnings = [];
        $details = [];
        $status = HealthStatus::UP;

        try {
            foreach ($this->paths as $path) {
                if (!is_dir($path)) {
                    return $this->down(
                        $startedAt,
                        'Required storage directory does not exist.',
                        'HEALTH_STORAGE_PATH_MISSING'
                    );
                }

                if (!is_writable($path)) {
                    return $this->down(
                        $startedAt,
                        'Required storage directory is not writable.',
                        'HEALTH_STORAGE_NOT_WRITABLE'
                    );
                }

                $free = @disk_free_space($path);
                $total = @disk_total_space($path);

                if ($free !== false && $total !== false && $total > 0) {
                    $freePercent = (int) floor(($free / $total) * 100);
                    $details[basename($path) . '_free_percent'] = $freePercent;

                    if ($freePercent < $this->warningFreeSpacePercent) {
                        $status = HealthStatus::DEGRADED;
                        $warnings[] = sprintf(
                            'Free space for "%s" is below threshold.',
                            basename($path)
                        );
                    }
                }

                $tempFile = rtrim($path, DIRECTORY_SEPARATOR)
                    . DIRECTORY_SEPARATOR
                    . '.health-' . bin2hex(random_bytes(6)) . '.tmp';

                file_put_contents($tempFile, 'health-check', LOCK_EX);
                @unlink($tempFile);
            }

            return new HealthResult(
                component: $this->name(),
                status: $status,
                criticality: $this->criticality(),
                durationMs: $this->durationMs($startedAt),
                message: $status === HealthStatus::UP
                    ? 'Storage is writable.'
                    : 'Storage is writable but capacity is low.',
                details: $details,
                dependencies: [],
                warnings: $warnings,
                checkedAt: new DateTimeImmutable(),
                validUntil: new DateTimeImmutable('+15 seconds'),
                providerVersion: '1.0.0',
            );
        } catch (Throwable $exception) {
            return $this->down(
                $startedAt,
                'Storage validation failed.',
                'HEALTH_STORAGE_CHECK_FAILED'
            );
        }
    }

    private function down(
        int $startedAt,
        string $message,
        string $errorCode
    ): HealthResult {
        return new HealthResult(
            component: $this->name(),
            status: HealthStatus::DOWN,
            criticality: $this->criticality(),
            durationMs: $this->durationMs($startedAt),
            message: $message,
            details: [],
            dependencies: [],
            warnings: [],
            checkedAt: new DateTimeImmutable(),
            errorCode: $errorCode,
            providerVersion: '1.0.0',
        );
    }

    private function durationMs(int $startedAt): int
    {
        return (int) ((hrtime(true) - $startedAt) / 1_000_000);
    }
}
```

Catatan:

- penulisan file sementara merupakan pengecekan operasional non-bisnis;
- file harus segera dihapus;
- nama path internal tidak ditampilkan pada public projection;
- deep check dapat menambahkan permission dan ownership validation.

---

### 8. Health Response Projector

```php
<?php

declare(strict_types=1);

namespace App\Platform\Observability\Health\Presentation\Http;

use App\Platform\Observability\Health\Domain\HealthReport;
use App\Platform\Observability\Health\Domain\HealthResult;

final class HealthResponseProjector
{
    public function __construct(
        private readonly string $serviceName,
        private readonly string $serviceVersion,
        private readonly string $environment,
    ) {
    }

    public function publicLive(HealthReport $report): array
    {
        return [
            'status' => $report->status->value,
            'service' => $this->serviceName,
            'timestamp' => $report->checkedAt->format(DATE_ATOM),
        ];
    }

    public function publicReady(HealthReport $report): array
    {
        return [
            'status' => $report->status->value,
            'service' => $this->serviceName,
            'ready' => in_array(
                $report->status->value,
                ['UP', 'DEGRADED'],
                true
            ),
            'timestamp' => $report->checkedAt->format(DATE_ATOM),
        ];
    }

    public function publicHealth(HealthReport $report): array
    {
        return [
            'status' => $report->status->value,
            'service' => $this->serviceName,
            'version' => $this->serviceVersion,
            'environment' => $this->environment,
            'timestamp' => $report->checkedAt->format(DATE_ATOM),
            'duration_ms' => $report->durationMs,
            'request_id' => $report->reportId,
        ];
    }

    public function internalHealth(HealthReport $report): array
    {
        $components = [];

        foreach ($report->components as $name => $result) {
            $components[$name] = $this->internalComponent($result);
        }

        return [
            'report_id' => $report->reportId,
            'status' => $report->status->value,
            'service' => $this->serviceName,
            'version' => $this->serviceVersion,
            'environment' => $this->environment,
            'timestamp' => $report->checkedAt->format(DATE_ATOM),
            'duration_ms' => $report->durationMs,
            'components' => $components,
            'summary' => $this->summary($report),
        ];
    }

    public function internalComponent(HealthResult $result): array
    {
        return [
            'status' => $result->status->value,
            'criticality' => $result->criticality->value,
            'duration_ms' => $result->durationMs,
            'message' => $result->message,
            'details' => $result->details,
            'dependencies' => $result->dependencies,
            'warnings' => $result->warnings,
            'error_code' => $result->errorCode,
            'checked_at' => $result->checkedAt->format(DATE_ATOM),
            'valid_until' => $result->validUntil?->format(DATE_ATOM),
            'provider_version' => $result->providerVersion,
        ];
    }

    private function summary(HealthReport $report): array
    {
        $summary = [
            'up' => 0,
            'degraded' => 0,
            'down' => 0,
            'unknown' => 0,
            'maintenance' => 0,
        ];

        foreach ($report->components as $result) {
            $key = strtolower($result->status->value);
            $summary[$key]++;
        }

        return $summary;
    }
}
```

---

### 9. Controller Wiring

#### 9.1 Public Controller

```php
final class HealthController
{
    public function __construct(
        private readonly HealthManager $manager,
        private readonly HealthProfileFactory $profiles,
        private readonly HealthResponseProjector $projector,
        private readonly string $environment,
    ) {
    }

    public function live(): void
    {
        $report = $this->manager->run(
            new HealthCheckContext(
                type: HealthCheckType::LIVE,
                environment: $this->environment,
                correlationId: request_id(),
            ),
            $this->profiles->live()
        );

        json_response(
            $this->projector->publicLive($report),
            $report->status === HealthStatus::UP ? 200 : 503
        );
    }

    public function ready(): void
    {
        $report = $this->manager->run(
            new HealthCheckContext(
                type: HealthCheckType::READY,
                environment: $this->environment,
                correlationId: request_id(),
            ),
            $this->profiles->ready()
        );

        $ready = in_array(
            $report->status,
            [HealthStatus::UP, HealthStatus::DEGRADED],
            true
        );

        json_response(
            $this->projector->publicReady($report),
            $ready ? 200 : 503
        );
    }

    public function health(): void
    {
        $report = $this->manager->run(
            new HealthCheckContext(
                type: HealthCheckType::SHALLOW,
                environment: $this->environment,
                correlationId: request_id(),
            ),
            $this->profiles->shallow()
        );

        $httpStatus = in_array(
            $report->status,
            [HealthStatus::UP, HealthStatus::DEGRADED],
            true
        ) ? 200 : 503;

        json_response(
            $this->projector->publicHealth($report),
            $httpStatus
        );
    }
}
```

#### 9.2 Internal Controller Policy

Internal controller wajib:

- melewati middleware authentication;
- memeriksa permission;
- memeriksa active scope;
- mencatat audit untuk deep check dan cache bypass;
- membatasi component dari registry;
- memvalidasi query parameter;
- memproyeksikan detail aman.

---

### 10. CLI Reference Implementation

File:

```text
tools/health-check.php
```

Contoh:

```php
<?php

declare(strict_types=1);

use App\Platform\Observability\Health\Domain\HealthCheckContext;
use App\Platform\Observability\Health\Domain\HealthCheckType;
use App\Platform\Observability\Health\Domain\HealthStatus;

require dirname(__DIR__) . '/bootstrap/app.php';

$options = getopt('', [
    'profile::',
    'provider::',
    'format::',
    'tenant::',
    'scope::',
    'persist',
    'refresh',
]);

$profileName = $options['profile'] ?? 'ready';
$format = $options['format'] ?? 'text';

$profile = match ($profileName) {
    'live' => $profiles->live(),
    'ready' => $profiles->ready(),
    'shallow' => $profiles->shallow(),
    'deep' => $profiles->deep(),
    default => throw new InvalidArgumentException('Invalid health profile.'),
};

if (!empty($options['provider'])) {
    $profile = new HealthExecutionProfile(
        type: $profile->type,
        criticalities: $profile->criticalities,
        includedProviders: [(string) $options['provider']],
        useCache: !$options['refresh'],
        persistResult: isset($options['persist']),
        stopOnCriticalDown: false,
        overallTimeoutMs: $profile->overallTimeoutMs,
    );
}

$context = new HealthCheckContext(
    type: $profile->type,
    environment: APP_ENV,
    tenantId: isset($options['tenant']) ? (int) $options['tenant'] : null,
    scopeId: isset($options['scope']) ? (int) $options['scope'] : null,
    correlationId: bin2hex(random_bytes(12)),
    includeDetails: true,
    forceRefresh: isset($options['refresh']),
);

$report = $healthManager->run($context, $profile);

if ($format === 'json') {
    echo json_encode(
        $projector->internalHealth($report),
        JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES
    ) . PHP_EOL;
} else {
    echo 'Platform Health: ' . $report->status->value . PHP_EOL . PHP_EOL;

    foreach ($report->components as $name => $result) {
        printf(
            "%-20s %-12s %6d ms\n",
            $name,
            $result->status->value,
            $result->durationMs
        );
    }
}

exit(match ($report->status) {
    HealthStatus::UP => 0,
    HealthStatus::DEGRADED => 1,
    HealthStatus::DOWN => 2,
    HealthStatus::UNKNOWN => 3,
    HealthStatus::MAINTENANCE => 1,
});
```

---

### 11. SQL Migration Package

File:

```text
database/migrations/2026_07_04_000001_create_health_check_tables.sql
```

```sql
START TRANSACTION;

CREATE TABLE health_check_reports (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    report_uuid CHAR(32) NOT NULL,
    environment VARCHAR(32) NOT NULL,
    check_type VARCHAR(32) NOT NULL,
    overall_status VARCHAR(20) NOT NULL,
    duration_ms INT UNSIGNED NOT NULL DEFAULT 0,
    tenant_id BIGINT UNSIGNED NULL,
    scope_id BIGINT UNSIGNED NULL,
    correlation_id VARCHAR(100) NULL,
    checked_at DATETIME(6) NOT NULL,
    created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),

    PRIMARY KEY (id),
    UNIQUE KEY uq_health_report_uuid (report_uuid),
    KEY idx_health_report_checked_at (checked_at),
    KEY idx_health_report_status (overall_status),
    KEY idx_health_report_tenant (tenant_id, checked_at),
    KEY idx_health_report_type (check_type, checked_at)
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;

CREATE TABLE health_check_results (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    health_check_report_id BIGINT UNSIGNED NOT NULL,
    component VARCHAR(100) NOT NULL,
    status VARCHAR(20) NOT NULL,
    criticality VARCHAR(20) NOT NULL,
    duration_ms INT UNSIGNED NOT NULL DEFAULT 0,
    message VARCHAR(500) NOT NULL,
    details_json JSON NULL,
    dependencies_json JSON NULL,
    warnings_json JSON NULL,
    error_code VARCHAR(100) NULL,
    provider_version VARCHAR(50) NULL,
    checked_at DATETIME(6) NOT NULL,
    valid_until DATETIME(6) NULL,
    created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),

    PRIMARY KEY (id),
    CONSTRAINT fk_health_result_report
        FOREIGN KEY (health_check_report_id)
        REFERENCES health_check_reports(id)
        ON DELETE CASCADE,

    KEY idx_health_result_component (component, checked_at),
    KEY idx_health_result_status (status, checked_at),
    KEY idx_health_result_report (health_check_report_id)
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;

CREATE TABLE health_component_state (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    context_key VARCHAR(255) NOT NULL,
    environment VARCHAR(32) NOT NULL,
    component VARCHAR(100) NOT NULL,
    check_type VARCHAR(32) NOT NULL,
    tenant_id BIGINT UNSIGNED NULL,
    scope_id BIGINT UNSIGNED NULL,
    status VARCHAR(20) NOT NULL,
    previous_status VARCHAR(20) NULL,
    criticality VARCHAR(20) NOT NULL,
    duration_ms INT UNSIGNED NOT NULL DEFAULT 0,
    message VARCHAR(500) NOT NULL,
    details_json JSON NULL,
    error_code VARCHAR(100) NULL,
    checked_at DATETIME(6) NOT NULL,
    valid_until DATETIME(6) NULL,
    changed_at DATETIME(6) NOT NULL,
    updated_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6)
        ON UPDATE CURRENT_TIMESTAMP(6),

    PRIMARY KEY (id),
    UNIQUE KEY uq_health_component_context (context_key),
    KEY idx_health_component_status (status, checked_at),
    KEY idx_health_component_changed (changed_at)
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;

CREATE TABLE health_status_transitions (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    environment VARCHAR(32) NOT NULL,
    component VARCHAR(100) NOT NULL,
    check_type VARCHAR(32) NOT NULL,
    tenant_id BIGINT UNSIGNED NULL,
    scope_id BIGINT UNSIGNED NULL,
    from_status VARCHAR(20) NULL,
    to_status VARCHAR(20) NOT NULL,
    reason_code VARCHAR(100) NULL,
    message VARCHAR(500) NOT NULL,
    report_uuid CHAR(32) NULL,
    correlation_id VARCHAR(100) NULL,
    changed_at DATETIME(6) NOT NULL,

    PRIMARY KEY (id),
    KEY idx_health_transition_component (component, changed_at),
    KEY idx_health_transition_status (to_status, changed_at),
    KEY idx_health_transition_tenant (tenant_id, changed_at)
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;

COMMIT;
```

Rollback:

```sql
START TRANSACTION;

DROP TABLE IF EXISTS health_status_transitions;
DROP TABLE IF EXISTS health_component_state;
DROP TABLE IF EXISTS health_check_results;
DROP TABLE IF EXISTS health_check_reports;

COMMIT;
```

---

### 12. Initial Seed & Default Policy

Health framework tidak membutuhkan seed transaksi.

Namun konfigurasi permission perlu tersedia:

```text
observability.health.read
observability.health.detail.read
observability.health.deep.execute
observability.health.cache.bypass
observability.health.security.read
observability.health.tenant.read
observability.health.history.read
observability.health.maintenance.manage
```

Role rekomendasi:

| Role | Permission |
|---|---|
| Platform Admin | seluruh health permission |
| Operations Admin | read, detail, deep, history |
| Security Admin | read, detail, security read |
| Tenant Admin | read tenant health milik tenant sendiri |
| Support | read/detail terbatas |
| End User | tidak ada |

---

### 13. Route Registration Reference

```php
$router->get('/live', [HealthController::class, 'live']);
$router->get('/ready', [HealthController::class, 'ready']);
$router->get('/health', [HealthController::class, 'health']);

$router->group('/internal/health', [
    'middleware' => [
        AuthenticationMiddleware::class,
        ActiveScopeMiddleware::class,
        RateLimitMiddleware::class,
    ],
], function ($router): void {
    $router->get('', [InternalHealthController::class, 'index']);
    $router->get('/reports/{reportId}', [
        InternalHealthController::class,
        'report',
    ]);
    $router->get('/tenants/{tenantId}', [
        InternalHealthController::class,
        'tenant',
    ]);
    $router->get('/{component}', [
        InternalHealthController::class,
        'component',
    ]);
});
```

Urutan route penting:

```text
/reports/{reportId}
/tenants/{tenantId}
/{component}
```

Route spesifik harus didefinisikan sebelum route generik.

---

### 14. Scheduler Reference

Windows Task Scheduler atau cron-equivalent:

#### 14.1 Critical Shallow Check

```bat
D:\xampp\php\php.exe D:\xampp\htdocs\platform\tools\health-check.php --profile=ready --format=json
```

Frekuensi:

```text
setiap 1 menit
```

#### 14.2 Deep Check

```bat
D:\xampp\php\php.exe D:\xampp\htdocs\platform\tools\health-check.php --profile=deep --persist --format=json
```

Frekuensi:

```text
setiap 15 menit atau 1 jam
```

#### 14.3 Log Redirection

```bat
D:\xampp\php\php.exe D:\xampp\htdocs\platform\tools\health-check.php --profile=deep --persist >> D:\xampp\htdocs\platform\storage\logs\health-scheduler.log 2>&1
```

Pastikan:

- user Windows memiliki permission;
- path absolut;
- timezone konsisten;
- task tidak overlap.

---

### 15. Deployment Checklist

#### 15.1 Pre-Deployment

- [ ] Backup database tersedia.
- [ ] Migration telah direview.
- [ ] Config `health.php` tersedia.
- [ ] Storage cache directory dibuat.
- [ ] Storage directory writable.
- [ ] Provider minimum terdaftar.
- [ ] Permission health dimigrasikan.
- [ ] Public detail dimatikan.
- [ ] Internal endpoint dilindungi.
- [ ] Apache rewrite aktif.
- [ ] Unit test lulus.
- [ ] Integration test lulus.

#### 15.2 Deployment

1. Aktifkan application maintenance.
2. Pastikan `/live` tetap UP.
3. Pastikan `/ready` menjadi MAINTENANCE/503.
4. Deploy code.
5. Jalankan SQL migration.
6. Bersihkan cache bootstrap bila perlu.
7. Jalankan CLI health profile `deep`.
8. Verifikasi database, storage, queue, scheduler.
9. Nonaktifkan maintenance.
10. Verifikasi `/ready` HTTP 200.
11. Verifikasi `/health`.
12. Verifikasi internal detail dengan account operations.

#### 15.3 Post-Deployment

- [ ] Tidak ada duplicate provider.
- [ ] Tidak ada migration pending.
- [ ] `/live` < 100 ms.
- [ ] `/ready` < 1000 ms.
- [ ] Public response tidak membocorkan detail.
- [ ] Transition log tercatat.
- [ ] Scheduler task aktif.
- [ ] Alert test dijalankan.
- [ ] Dashboard menampilkan status.

---

### 16. Rollback Plan

Rollback harus mencakup:

```text
application code
database schema
configuration
scheduled task
route
permission
cache
```

#### 16.1 Safe Rollback

Urutan:

1. Aktifkan maintenance.
2. Hentikan scheduled deep check.
3. Rollback code.
4. Rollback schema hanya jika aman.
5. Hapus cache health yang tidak kompatibel.
6. Restore configuration sebelumnya.
7. Jalankan `/live`.
8. Jalankan `/ready`.
9. Nonaktifkan maintenance.

#### 16.2 Database Rollback Warning

Jangan drop health table jika:

- incident analysis masih berlangsung;
- data dibutuhkan untuk audit/operational review;
- version lama tetap dapat mengabaikan table baru.

Prefer:

```text
forward-compatible rollback
```

daripada langsung menghapus data.

---

### 17. Incident Scenario 1 — Database Down

#### Detection

```text
database = DOWN
readiness = DOWN
HTTP /ready = 503
```

#### Expected Behavior

- `/live` tetap UP;
- traffic baru dihentikan;
- internal report menunjukkan safe error code;
- tidak ada DSN/credential pada response;
- alert dikirim melalui jalur yang tidak bergantung database bila tersedia;
- status transition dicatat jika persistence memungkinkan.

#### Operator Action

1. Cek MySQL service.
2. Cek connection limit.
3. Cek disk.
4. Cek credential/config.
5. Cek network.
6. Pulihkan database.
7. Jalankan readiness ulang.
8. Verifikasi status kembali UP.

---

### 18. Incident Scenario 2 — Queue Backlog Tinggi

#### Detection

```text
queue = DEGRADED
pending_jobs > warning threshold
```

#### Expected Behavior

- platform masih ready;
- `/health` = DEGRADED;
- internal detail menampilkan jumlah backlog;
- alert warning;
- tidak ada job payload ditampilkan.

#### Operator Action

1. Cek worker aktif.
2. Cek job failure.
3. Cek scheduler.
4. Cek database lock.
5. Tambah worker bila perlu.
6. Verifikasi backlog menurun.
7. Pastikan transition kembali UP tercatat.

---

### 19. Incident Scenario 3 — Scheduler Heartbeat Hilang

#### Detection

```text
scheduler = DOWN
heartbeat age > down threshold
```

#### Expected Behavior

- platform dapat DEGRADED;
- reminder, retry, dan scheduled sync dianggap terganggu;
- alert operations;
- readiness policy menentukan apakah masih menerima traffic.

#### Operator Action

1. Cek Windows Task Scheduler.
2. Cek last run result.
3. Cek path PHP.
4. Cek permission user.
5. Cek overlapping task.
6. Jalankan command manual.
7. Verifikasi heartbeat.

---

### 20. Incident Scenario 4 — Integration Provider Down

#### Detection

```text
integration connector = DOWN
```

#### Expected Behavior

Jika optional:

```text
platform = DEGRADED
```

Jika critical:

```text
platform = DOWN atau DEGRADED sesuai policy
```

Operator Action:

- cek provider status;
- cek DNS/network;
- cek credential expiry;
- cek rate limit;
- cek circuit breaker;
- cek dead-letter;
- jangan retry tanpa batas.

---

### 21. Incident Scenario 5 — Security Control Failure

#### Detection

Contoh:

```text
APP_DEBUG aktif di production
secret default terdeteksi
audit disabled
```

#### Expected Behavior

```text
security = DOWN
platform = DOWN
```

Internal detail hanya untuk role security.

Operator Action:

1. Aktifkan incident security.
2. Batasi traffic.
3. Perbaiki konfigurasi.
4. Rotasi credential bila perlu.
5. Verifikasi audit.
6. Jalankan deep security health.
7. Dokumentasikan incident.

---

### 22. Incident Scenario 6 — Health Framework Failure

#### Detection

HealthManager tidak dapat membuat report.

#### Expected Behavior

Public:

```json
{
  "status": "DOWN",
  "code": "HEALTH_FRAMEWORK_FAILURE"
}
```

HTTP:

```text
503
```

Internal log:

- exception;
- correlation ID;
- bootstrap state;
- config validation error.

Jangan mengembalikan stack trace ke publik.

---

### 23. Alert Integration Contract

Part 5 tidak mendefinisikan Alerting Framework penuh, tetapi Health Check harus menghasilkan event standar:

```text
health.status.changed
health.component.down
health.component.degraded
health.component.recovered
health.framework.failed
```

Payload aman:

```json
{
  "event": "health.component.down",
  "component": "database",
  "from_status": "UP",
  "to_status": "DOWN",
  "criticality": "critical",
  "environment": "production",
  "error_code": "HEALTH_DATABASE_CONNECTION_FAILED",
  "checked_at": "2026-07-04T19:00:00+07:00"
}
```

Event tidak boleh berisi secret/PHI/PII.

---

### 24. Dashboard Minimum

Dashboard awal menampilkan:

```text
Overall Platform Status
Database
Storage
Queue
Scheduler
Workflow
Event Bus
Notification
Integration
Search
Module
Tenant
Scope
Security
```

Widget minimum:

- current status;
- last checked;
- duration;
- current warning;
- last transition;
- status history;
- error code;
- trend.

Dashboard tidak boleh menjadi dependency health endpoint.

---

### 25. Unit Test Examples

#### 25.1 Aggregator Test

```php
public function testCriticalDownMakesPlatformDown(): void
{
    $aggregator = new HealthAggregator([
        'critical_down' => 'DOWN',
        'important_down' => 'DEGRADED',
        'optional_down' => 'DEGRADED',
    ]);

    $result = new HealthResult(
        component: 'database',
        status: HealthStatus::DOWN,
        criticality: HealthCriticality::CRITICAL,
        durationMs: 10,
        message: 'Database failed.',
        details: [],
        dependencies: [],
        warnings: [],
        checkedAt: new DateTimeImmutable(),
    );

    self::assertSame(
        HealthStatus::DOWN,
        $aggregator->aggregate(['database' => $result])
    );
}
```

#### 25.2 Registry Duplicate Test

```php
public function testDuplicateProviderIsRejected(): void
{
    $registry = new HealthRegistry();
    $provider = new FakeDatabaseHealthProvider();

    $registry->register($provider);

    $this->expectException(LogicException::class);

    $registry->register($provider);
}
```

#### 25.3 Sanitizer Test

```php
public function testSensitiveDetailIsRemoved(): void
{
    $sanitizer = new DefaultHealthDetailSanitizer([
        'token',
        'password',
    ]);

    $result = $sanitizer->sanitize([
        'latency_ms' => 20,
        'token' => 'secret-value',
    ]);

    self::assertSame(['latency_ms' => 20], $result);
}
```

---

### 26. Integration Test Matrix

| Test | Expected |
|---|---|
| MySQL active | database UP |
| MySQL stopped | database DOWN |
| storage writable | storage UP |
| storage read-only | storage DOWN |
| queue backlog warning | queue DEGRADED |
| scheduler heartbeat stale | scheduler DOWN |
| cache fresh | cache hit |
| cache expired | provider executed |
| persistence unavailable | report still returned |
| internal endpoint unauthorized | 401/403 |
| cross-tenant request | 404/403 |
| deep check without permission | 403 |

---

### 27. Final UAT — Functional

#### 27.1 Core

- [ ] HealthStatus bekerja.
- [ ] Criticality bekerja.
- [ ] Registry bekerja.
- [ ] Manager bekerja.
- [ ] Executor menangani exception.
- [ ] Aggregator bekerja.
- [ ] Profile factory bekerja.
- [ ] Cache bekerja.
- [ ] Persistence bekerja.

#### 27.2 Provider

- [ ] Database provider tersedia.
- [ ] Storage provider tersedia.
- [ ] Queue provider tersedia.
- [ ] Scheduler provider tersedia.
- [ ] Provider module dapat mendaftar sendiri.
- [ ] Duplicate provider ditolak.

#### 27.3 Endpoint

- [ ] `/live` tersedia.
- [ ] `/ready` tersedia.
- [ ] `/health` tersedia.
- [ ] internal health tersedia.
- [ ] component detail tersedia.
- [ ] tenant detail tersedia.
- [ ] report history tersedia.

#### 27.4 CLI

- [ ] CLI profile live.
- [ ] CLI profile ready.
- [ ] CLI profile deep.
- [ ] CLI provider filter.
- [ ] JSON output valid.
- [ ] exit code valid.

---

### 28. Final UAT — Security

- [ ] Public endpoint tanpa detail internal.
- [ ] Internal endpoint membutuhkan authentication.
- [ ] Permission diterapkan.
- [ ] Active scope diterapkan.
- [ ] Cross-tenant ditolak.
- [ ] Security detail dibatasi.
- [ ] Force refresh diaudit.
- [ ] Deep check diaudit.
- [ ] Secret disanitasi.
- [ ] Stack trace tidak tampil.
- [ ] CORS aman.
- [ ] Rate limit aktif.

---

### 29. Final UAT — Performance

- [ ] `/live` p95 < 100 ms.
- [ ] `/ready` p95 < 1000 ms.
- [ ] `/health` p95 < 1500 ms.
- [ ] Cache hit menurunkan latency.
- [ ] Deep check tidak dijalankan pada probe.
- [ ] Tenant aggregate tidak menyebabkan N+1.
- [ ] Snapshot insert menggunakan batch/transaction.
- [ ] Metrics tidak memblokir response.

---

### 30. Final UAT — Failure & Recovery

- [ ] Database outage terdeteksi.
- [ ] Storage outage terdeteksi.
- [ ] Queue backlog terdeteksi.
- [ ] Scheduler failure terdeteksi.
- [ ] Integration failure terdeteksi.
- [ ] Security control failure terdeteksi.
- [ ] Recovery menghasilkan status UP.
- [ ] Transition DOWN → UP tercatat.
- [ ] Alert event recovery tersedia.
- [ ] Framework failure menghasilkan safe response.

---

### 31. Operational Acceptance Criteria

Framework dianggap siap operasional bila:

- probe digunakan oleh load balancer/deployment;
- deep check berjalan via scheduler;
- current state tersedia;
- transition history tersedia;
- dashboard minimum tersedia;
- alert status change tersedia;
- operator memiliki runbook;
- rollback telah diuji;
- tidak ada sensitive disclosure;
- seluruh provider kritis mempunyai owner.

---

### 32. Provider Ownership Matrix

| Provider | Owner |
|---|---|
| Database | Platform/DBA |
| Storage | Platform Operations |
| Queue | Platform Operations |
| Scheduler | Platform Operations |
| Workflow | Workflow Team |
| Event Bus | Platform Kernel Team |
| Notification | Communication Team |
| Integration | Integration Team |
| Search | Search/Data Team |
| Module | Module Owner |
| Tenant | Platform/Tenant Operations |
| Scope | IAM/Authorization Team |
| Security | Security Team |

Setiap provider wajib memiliki:

- owner;
- threshold owner;
- incident escalation;
- runbook;
- test scenario.

---

### 33. Runbook Minimum Template

Setiap provider memiliki runbook:

```text
Provider Name
Purpose
Criticality
Dependencies
Threshold
Known Failure Modes
How to Verify
How to Recover
Rollback
Escalation Contact
Related Dashboard
Related Logs
Related Metrics
```

Contoh file:

```text
docs/operations/runbooks/health/database.md
docs/operations/runbooks/health/queue.md
```

---

### 34. Production Readiness Checklist

- [ ] Config berbeda untuk local/staging/production.
- [ ] APP_DEBUG nonaktif.
- [ ] Public detail nonaktif.
- [ ] Storage writable.
- [ ] Cache directory terlindungi dari web.
- [ ] SQL migration berhasil.
- [ ] Scheduled task berjalan.
- [ ] Retention job tersedia.
- [ ] Log rotation tersedia.
- [ ] Health permission tersedia.
- [ ] Operations account tersedia.
- [ ] Alert destination tersedia.
- [ ] Incident runbook tersedia.
- [ ] Backup dan restore diuji.
- [ ] Load test lulus.
- [ ] Security review lulus.

---

### 35. Definition of Done — SSOT-OBS-05

SSOT-OBS-05 dianggap selesai secara dokumentasi bila:

#### Architecture

- [ ] tujuan framework jelas;
- [ ] problem statement jelas;
- [ ] state model jelas;
- [ ] criticality jelas;
- [ ] aggregation policy jelas;
- [ ] provider architecture jelas.

#### Provider Specification

- [ ] Database;
- [ ] Storage;
- [ ] Queue;
- [ ] Scheduler;
- [ ] Workflow;
- [ ] Event Bus;
- [ ] Notification;
- [ ] Integration;
- [ ] Search;
- [ ] Module;
- [ ] Tenant;
- [ ] Scope;
- [ ] Security.

#### Core Implementation

- [ ] Domain model;
- [ ] Provider interface;
- [ ] Registry;
- [ ] Manager;
- [ ] Executor;
- [ ] Aggregator;
- [ ] Cache;
- [ ] Persistence;
- [ ] Telemetry;
- [ ] Sanitizer.

#### Interface

- [ ] `/live`;
- [ ] `/ready`;
- [ ] `/health`;
- [ ] internal diagnostic;
- [ ] component detail;
- [ ] tenant detail;
- [ ] report history;
- [ ] CLI.

#### Operations

- [ ] deployment;
- [ ] rollback;
- [ ] scheduler;
- [ ] metrics;
- [ ] logs;
- [ ] alert event;
- [ ] incident scenario;
- [ ] runbook;
- [ ] final UAT.

---

### 36. Implementation Definition of Done

Implementasi dianggap selesai bila:

- [ ] seluruh class core dibuat;
- [ ] migration berhasil;
- [ ] initial provider aktif;
- [ ] endpoint tersedia;
- [ ] CLI tersedia;
- [ ] permission tersedia;
- [ ] unit test lulus;
- [ ] integration test lulus;
- [ ] UAT lulus;
- [ ] performance target tercapai;
- [ ] security review lulus;
- [ ] deployment runbook diuji;
- [ ] rollback diuji;
- [ ] monitoring dan alert tersedia.

---

### 37. Roadmap

#### Phase 1 — Foundation

- domain model;
- registry;
- manager;
- executor;
- aggregator;
- database/storage providers;
- `/live`, `/ready`, `/health`.

#### Phase 2 — Operations

- queue;
- scheduler;
- cache;
- persistence;
- CLI;
- dashboard;
- status transition.

#### Phase 3 — Platform Providers

- workflow;
- event bus;
- notification;
- integration;
- search.

#### Phase 4 — Governance Providers

- module;
- tenant;
- scope;
- security.

#### Phase 5 — Advanced Observability

- Prometheus exporter;
- OpenTelemetry correlation;
- alert automation;
- SLO;
- status page;
- predictive health;
- automated remediation workflow.

---

### 38. Future Evolution

Future capability:

- parallel provider execution;
- asynchronous deep checks;
- Redis;
- distributed lock;
- multi-node health aggregation;
- region health;
- startup probe;
- service dependency graph;
- error budget;
- anomaly detection;
- synthetic transactions;
- status page;
- controlled self-healing;
- incident automation.

Self-healing tidak boleh menjadi bagian langsung dari provider.

Gunakan workflow terpisah dengan:

- approval;
- audit;
- policy;
- rollback;
- safety guard.

---

### 39. Merge Guidance

Setelah Part 1–5 selesai, gabungkan menjadi:

```text
SSOT-OBS-05.md
```

Urutan:

```text
Part 1
Executive Summary
Problem Statement
Design Goals
Architecture
Health State Model

Part 2A
Database
Storage
Queue

Part 2B
Scheduler
Workflow
Event Bus

Part 2C
Notification
Integration
Search

Part 2D
Module
Tenant
Scope
Security

Part 3
Core Implementation
Registry
Manager
Aggregator
Database Design

Part 4
Endpoints
Response Standard
Security
Routing
Sequence Diagram

Part 5
Reference Implementation
Deployment
Incident Scenarios
Final UAT
Definition of Done
Roadmap
```

---

### 40. Merge Quality Checklist

Sebelum merge:

- [ ] heading number tidak duplikat;
- [ ] terminology konsisten;
- [ ] status enum konsisten;
- [ ] criticality konsisten;
- [ ] endpoint konsisten;
- [ ] permission konsisten;
- [ ] table name konsisten;
- [ ] namespace konsisten;
- [ ] error code konsisten;
- [ ] contoh waktu diperbarui bila perlu;
- [ ] tidak ada kontradiksi threshold;
- [ ] tidak ada duplicate section;
- [ ] link internal diperbarui;
- [ ] daftar isi dibuat;
- [ ] metadata final diperbarui;
- [ ] status menjadi Approved setelah review.

---

### 41. Final Document Metadata

Metadata final:

```yaml
document_code: SSOT-OBS-05
title: Health Check Framework
version: 1.0
status: Draft for Review
domain: Platform Kernel
category: Observability
owners:
  - Platform Architecture
  - Platform Operations
  - Security
reviewers:
  - Backend Engineering
  - DevOps
  - QA
  - Security
```

Setelah review:

```text
status = Approved
```

---

### 42. Approval Gate

Dokumen tidak boleh menjadi Approved sebelum:

- Architecture review selesai;
- Security review selesai;
- Operations review selesai;
- QA/UAT review selesai;
- implementation feasibility disetujui;
- naming dan schema disetujui;
- permission disetujui;
- retention disetujui;
- incident runbook disetujui.

---

### 43. Closing Statement

Health Check Framework adalah kontrak operasional Platform Kernel.

Framework ini memastikan platform tidak hanya dapat berjalan, tetapi juga dapat:

- menjelaskan kondisinya;
- mendeteksi kegagalan;
- membedakan gangguan kritis dan non-kritis;
- melindungi detail internal;
- mendukung deployment;
- mendukung monitoring;
- mendukung incident response;
- berkembang menuju arsitektur terdistribusi.

Implementasi Health Check harus tetap sederhana, deterministik, aman, dan tidak menjadi sumber kegagalan baru.

---

## Lampiran A — Sumber Penggabungan

Dokumen final ini digabung dan dinormalisasi dari:

- `SSOT-OBS-05-Part-1.md`
- `SSOT-OBS-05-Part-2A.md`
- `SSOT-OBS-05-Part-2B.md`
- `SSOT-OBS-05-Part-2C.md`
- `SSOT-OBS-05-Part-2D.md`
- `SSOT-OBS-05-Part-3.md`
- `SSOT-OBS-05-Part-4.md`
- `SSOT-OBS-05-Part-5.md`

## Lampiran B — Approval Gate

Status dokumen dapat diubah menjadi **Approved** setelah:

- architecture review selesai;
- security review selesai;
- operations review selesai;
- QA/UAT review selesai;
- database schema disetujui;
- permission dan scope policy disetujui;
- retention policy disetujui;
- implementation feasibility disetujui;
- runbook incident disetujui.
