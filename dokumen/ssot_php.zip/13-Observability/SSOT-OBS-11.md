# SSOT-OBS-11 — Observability Governance & Maturity Framework

> Single Source of Truth untuk governance, ownership, maturity, policy-as-code, review, approval, exception, evidence, cost, quality gate, dan continuous improvement seluruh capability observability pada Platform Kernel.

## Metadata Dokumen

| Item | Nilai |
|---|---|
| Kode | SSOT-OBS-11 |
| Judul | Observability Governance & Maturity Framework |
| Versi | 1.0 |
| Status | Draft for Review |
| Domain | Platform Kernel |
| Kategori | Observability Governance |
| Target Stack | PHP 8.1+, PDO, MySQL 8/MariaDB, Apache/XAMPP, Modular Monolith |
| Bergantung pada | SSOT-OBS-01 sampai SSOT-OBS-10 |
| Pemilik | Platform Architecture, Platform Operations, Security, Compliance |
| Reviewer | Backend Engineering, Frontend Engineering, Service Owners, DevOps, QA, Data Governance, FinOps |

## Tujuan Dokumen

Dokumen ini menetapkan standar tunggal untuk:

- governance model, council, operating model, ownership, RACI, maturity, review cadence, dan quality gates;
- governance catalogs, policy-as-code, review workflow, approval workflow, exception lifecycle, maturity scoring, evidence, scorecards, cost allocation, dan CI/CD gates;
- storage architecture, approval and exception records, maturity history, cost ledger, evidence, retention, legal hold, audit integrity, reporting, backup, dan disaster recovery;
- HTTP API, controllers, middleware, database schema, scheduler, policy engine, review engine, maturity service, cost APIs, dashboard, security, audit, dan routing;
- reference implementation, sample policies, maturity assessment, scorecards, budgets, deployment, rollback, simulations, runbooks, final UAT, dan Definition of Done.

## Daftar Isi

1. Bagian I — Vision, Governance Model, Operating Model, Ownership, Maturity Levels, Review Cadence & Quality Gates
2. Bagian II — Governance Catalogs, Policy-as-Code, Review Workflows, Exception Lifecycle, Maturity Scoring, Evidence, Cost Allocation, Scorecards & CI/CD Gates
3. Bagian III — Governance Storage Architecture, Evidence, Approvals, Exceptions, Maturity History, Cost Ledger, Retention, Legal Hold, Audit Integrity, Reporting & Disaster Recovery
4. Bagian IV — HTTP API, Controllers, Middleware, Database Schema, Scheduler, Approval Workflow, Review Engine, Maturity Service, Cost APIs, Dashboard, Audit & Routing
5. Bagian V — Reference Implementation, Sample Policies, Maturity Assessment, Scorecards, Budgets, Deployment, Simulation, Final UAT & Operational Readiness
6. Lampiran A — Sumber Penggabungan
7. Lampiran B — Approval Gate

## Status Normatif

Kata **wajib**, **harus**, dan **tidak boleh** menyatakan persyaratan normatif. Kata **direkomendasikan**, **sebaiknya**, dan **dapat** menyatakan panduan yang dapat disesuaikan melalui keputusan arsitektur terdokumentasi.

---

## Bagian I — Vision, Governance Model, Operating Model, Ownership, Maturity Levels, Review Cadence & Quality Gates

### 1. Executive Summary

SSOT-OBS-11 menetapkan governance dan maturity framework untuk seluruh observability capability pada Platform Kernel.

Framework ini menyatukan:

```text
Logging
Metrics
Tracing
Health Check
Dashboards
Alerting
Incident Management
Retention & Archiving
Performance Monitoring
Audit vs Logging vs Event Governance
```

Tujuan utamanya adalah memastikan observability tidak hanya tersedia secara teknis, tetapi juga:

- dimiliki;
- ditinjau;
- diukur;
- diaudit;
- ditingkatkan;
- dikendalikan biayanya;
- aman;
- konsisten antar module;
- siap untuk operasi enterprise;
- mendukung compliance dan incident response.

---

### 2. Problem Statement

Tanpa governance, observability cenderung mengalami:

- metric tanpa owner;
- dashboard tidak pernah dipakai;
- alert terlalu banyak;
- log tidak konsisten;
- trace sampling tidak terkontrol;
- retention tidak sinkron;
- SLO tanpa business approval;
- audit dan log bercampur;
- incident tidak menghasilkan corrective action;
- biaya telemetry meningkat tanpa manfaat;
- tenant isolation lemah;
- quality gate tidak diterapkan;
- tidak ada maturity roadmap.

---

### 3. Governance Objective

Governance harus menjawab:

- siapa pemilik setiap capability;
- siapa yang menyetujui perubahan;
- apa standar minimum;
- bagaimana maturity diukur;
- bagaimana quality gate diterapkan;
- bagaimana exception dikelola;
- bagaimana biaya dipantau;
- bagaimana review dilakukan;
- bagaimana evidence disimpan;
- kapan capability dianggap production-ready.

---

### 4. Scope

Framework mencakup:

```text
Architecture Governance
Signal Governance
Operational Governance
Security & Privacy Governance
Cost Governance
SLO Governance
Incident Governance
Data Quality Governance
Maturity Assessment
Exception Management
Continuous Improvement
```

---

### 5. Non-Goals

Part 1 tidak mendefinisikan detail:

- database schema governance;
- API implementation;
- dashboard implementation;
- scheduler implementation;
- automated scoring engine;
- CI/CD enforcement;
- migration scripts.

Hal tersebut dibahas pada Part 2–5.

---

### 6. Core Principle

Observability adalah shared platform capability, bukan sekadar fitur teknis per module.

Setiap module dan service wajib mengikuti standar yang sama untuk:

- naming;
- ownership;
- classification;
- retention;
- permission;
- quality;
- alerting;
- SLO;
- incident linkage;
- auditability.

---

### 7. Governance Domains

```text
GOV-ARCHITECTURE
GOV-LOGGING
GOV-METRICS
GOV-TRACING
GOV-HEALTH
GOV-DASHBOARD
GOV-ALERTING
GOV-INCIDENT
GOV-RETENTION
GOV-PERFORMANCE
GOV-SIGNALS
GOV-SECURITY
GOV-COST
GOV-MATURITY
```

---

### 8. Governance Model

```text
Observability Council
        │
        ├── Platform Architecture
        ├── Platform Operations
        ├── Security
        ├── Compliance
        ├── Data Governance
        ├── Service Owners
        ├── QA
        └── Product/Business Representatives
```

---

### 9. Observability Council

Observability Council bertanggung jawab atas:

- standards;
- exceptions;
- maturity review;
- cross-team conflicts;
- major SLO changes;
- cost controls;
- tooling direction;
- compliance alignment;
- annual roadmap.

---

### 10. Council Membership

Minimum:

```text
Platform Architect
Platform Operations Lead
Security Representative
Compliance Representative
Data Governance Representative
Backend Representative
Frontend Representative
QA Representative
Service Owner Representative
```

---

### 11. Council Cadence

Recommended:

```text
Monthly governance review
Quarterly maturity review
Semiannual architecture review
Annual roadmap review
Emergency review after major incident
```

---

### 12. Operating Model

```text
Define Standard
→ Implement
→ Validate
→ Operate
→ Review
→ Improve
→ Retire
```

---

### 13. Lifecycle States

```text
PROPOSED
DRAFT
REVIEW
APPROVED
ACTIVE
DEPRECATED
RETIRED
```

---

### 14. Standard Lifecycle

#### Proposed

Ide atau kebutuhan baru.

#### Draft

Dokumen/konfigurasi awal.

#### Review

Architecture, security, operations, dan owner review.

#### Approved

Disetujui untuk implementasi.

#### Active

Digunakan di production.

#### Deprecated

Masih tersedia tetapi tidak untuk implementasi baru.

#### Retired

Tidak lagi digunakan.

---

### 15. Ownership Types

```text
Capability Owner
Service Owner
Signal Owner
SLO Owner
Dashboard Owner
Alert Owner
Incident Owner
Retention Owner
Security Owner
Cost Owner
```

---

### 16. Capability Owner

Bertanggung jawab atas capability platform.

Contoh:

```text
Logging Framework
Metrics Framework
Tracing Framework
Alerting Framework
```

---

### 17. Service Owner

Bertanggung jawab atas observability service/module tertentu.

---

### 18. Signal Owner

Bertanggung jawab atas:

- metric;
- log event;
- audit action;
- domain event;
- integration event;
- trace operation.

---

### 19. SLO Owner

Bertanggung jawab atas:

- target;
- definition;
- review;
- error budget;
- exception;
- business alignment.

---

### 20. Dashboard Owner

Bertanggung jawab atas:

- audience;
- freshness;
- correctness;
- relevance;
- retirement.

---

### 21. Alert Owner

Bertanggung jawab atas:

- actionability;
- routing;
- threshold;
- runbook;
- suppression;
- false-positive review.

---

### 22. Incident Owner

Bertanggung jawab atas:

- response process;
- post-incident review;
- corrective actions;
- closure evidence.

---

### 23. RACI Model

| Activity | Council | Platform | Service Owner | Security | Compliance | QA |
|---|---|---|---|---|---|---|
| Define standard | A | R | C | C | C | C |
| Implement framework | C | R | C | C | I | C |
| Define service SLO | C | C | R/A | C | I | C |
| Approve restricted telemetry | C | C | R | A | C | I |
| Review audit policy | C | C | C | R | A | I |
| Validate UAT | I | C | C | C | I | R/A |
| Approve exception | A | C | R | C | C | I |

Legend:

```text
R = Responsible
A = Accountable
C = Consulted
I = Informed
```

---

### 24. Governance Artifacts

Required artifacts:

```text
Observability Standards
Signal Catalogs
Metric Catalog
SLO Catalog
Dashboard Catalog
Alert Catalog
Runbook Catalog
Incident Catalog
Retention Policies
Exception Register
Maturity Assessment
Cost Report
Review Minutes
Roadmap
```

---

### 25. Catalog Ownership

Setiap catalog entry wajib memiliki:

```text
code
name
owner
status
classification
retention
effective_from
review_due_at
last_reviewed_at
```

---

### 26. Review Cadence by Artifact

| Artifact | Review Cadence |
|---|---|
| Logging standard | 6 months |
| Metric catalog | quarterly |
| SLO catalog | quarterly |
| Dashboard catalog | quarterly |
| Alert catalog | monthly |
| Runbook catalog | quarterly |
| Incident process | after major incident + annual |
| Retention policies | annual |
| Security classification | annual |
| Cost report | monthly |
| Maturity assessment | quarterly |

---

### 27. Quality Gate Model

```text
Design Gate
Implementation Gate
Pre-Production Gate
Production Gate
Operational Review Gate
Retirement Gate
```

---

### 28. Design Gate

Wajib memeriksa:

- purpose;
- owner;
- signal type;
- classification;
- retention;
- tenant/scope;
- cardinality;
- SLO impact;
- alert need;
- privacy;
- cost.

---

### 29. Implementation Gate

Wajib memeriksa:

- schema;
- naming;
- instrumentation;
- error handling;
- tests;
- permissions;
- audit;
- fallback;
- overhead.

---

### 30. Pre-Production Gate

Wajib memeriksa:

- dashboards;
- alerts;
- runbooks;
- SLO;
- load test;
- failure simulation;
- data quality;
- security review;
- retention mapping.

---

### 31. Production Gate

Wajib memeriksa:

- telemetry flowing;
- owner reachable;
- alert routing active;
- dashboard valid;
- health checks active;
- rollback ready;
- no PHI/PII leakage;
- no cardinality explosion.

---

### 32. Operational Review Gate

Wajib memeriksa:

- false positives;
- noisy alerts;
- dashboard usage;
- SLO attainment;
- cost;
- retention;
- incident lessons;
- backlog.

---

### 33. Retirement Gate

Wajib memeriksa:

- consumer removed;
- dashboard removed;
- alert removed;
- retention applied;
- schema deprecated;
- documentation updated;
- audit trail preserved.

---

### 34. Exception Management

Exception digunakan bila standar tidak dapat dipenuhi sementara.

Exception wajib memiliki:

```text
exception_id
standard_reference
scope
reason
risk
compensating_control
owner
approver
effective_from
expires_at
review_date
status
```

---

### 35. Exception States

```text
REQUESTED
REVIEW
APPROVED
REJECTED
EXPIRED
CLOSED
```

---

### 36. Exception Rules

Exception tidak boleh:

- tanpa expiry;
- tanpa owner;
- tanpa compensating control;
- tanpa risk assessment;
- permanent secara diam-diam;
- dipakai untuk menghindari security requirement.

---

### 37. Risk Levels

```text
LOW
MEDIUM
HIGH
CRITICAL
```

---

### 38. Critical Exception

Critical exception membutuhkan:

- council approval;
- security approval;
- explicit time limit;
- monitoring;
- incident readiness;
- executive awareness bila perlu.

---

### 39. Maturity Framework

Maturity levels:

```text
LEVEL 0 — Ad Hoc
LEVEL 1 — Foundational
LEVEL 2 — Standardized
LEVEL 3 — Managed
LEVEL 4 — Optimized
LEVEL 5 — Predictive
```

---

### 40. Level 0 — Ad Hoc

Karakteristik:

- logs tidak terstruktur;
- tidak ada owner;
- alert manual;
- tidak ada SLO;
- tidak ada retention policy;
- incident informal.

---

### 41. Level 1 — Foundational

Karakteristik:

- structured logging dasar;
- health checks;
- basic metrics;
- basic dashboards;
- manual runbook;
- owner awal.

---

### 42. Level 2 — Standardized

Karakteristik:

- metric/log naming standard;
- tracing standard;
- alert catalog;
- SLO definitions;
- retention mapped;
- tenant isolation;
- catalog tersedia.

---

### 43. Level 3 — Managed

Karakteristik:

- SLO evaluated;
- error budget digunakan;
- alert quality measured;
- incident review formal;
- cost tracked;
- quality gates enforced;
- exceptions managed.

---

### 44. Level 4 — Optimized

Karakteristik:

- anomaly detection;
- regression detection;
- capacity forecasting;
- automated quality checks;
- advanced correlation;
- continuous tuning.

---

### 45. Level 5 — Predictive

Karakteristik:

- predictive capacity;
- automated remediation guardrails;
- adaptive sampling;
- proactive incident prevention;
- AI-assisted analysis;
- business-aware optimization.

---

### 46. Maturity Dimensions

```text
Architecture
Logging
Metrics
Tracing
Health
Dashboards
Alerting
Incident Management
Retention
Performance
Signal Governance
Security & Privacy
Cost Management
Automation
Culture
```

---

### 47. Maturity Scoring

Each dimension scored:

```text
0–5
```

Overall maturity:

```text
weighted average
```

---

### 48. Minimum Production Threshold

Initial recommendation:

```text
No dimension below Level 1
Critical services minimum Level 3
Platform Kernel target Level 4
```

---

### 49. Weighted Scoring

Example weights:

| Dimension | Weight |
|---|---:|
| Architecture | 10% |
| Logging | 8% |
| Metrics | 10% |
| Tracing | 8% |
| Alerting | 10% |
| Incident | 10% |
| SLO/Performance | 12% |
| Security/Privacy | 12% |
| Retention | 8% |
| Cost | 5% |
| Automation | 5% |
| Culture | 2% |

---

### 50. Maturity Evidence

Scoring harus berdasarkan evidence:

- configuration;
- catalog;
- dashboards;
- alerts;
- incident reports;
- SLO reports;
- cost reports;
- UAT;
- audit records;
- review minutes.

---

### 51. No Self-Declared Maturity

Maturity tidak boleh berdasarkan klaim tanpa evidence.

---

### 52. Data Quality Governance

Data quality dimensions:

```text
Completeness
Freshness
Accuracy
Consistency
Uniqueness
Validity
Traceability
```

---

### 53. Telemetry Quality States

```text
VALID
PARTIAL
STALE
INVALID
UNKNOWN
```

---

### 54. Data Quality Owner

Setiap pipeline harus memiliki owner untuk:

- ingestion;
- schema;
- freshness;
- retention;
- recovery.

---

### 55. Quality SLO

Contoh:

```text
99.9% metric ingestion available
99% expected audit records present
trace propagation > 95%
dashboard freshness < 2 minutes
```

---

### 56. Alert Quality Governance

Measure:

```text
actionable rate
false positive rate
duplicate rate
acknowledgement time
resolution time
runbook coverage
owner coverage
```

---

### 57. Alert Quality Targets

Contoh awal:

```text
Actionable rate > 80%
False positive rate < 10%
Runbook coverage = 100% for SEV1/SEV2
Owner coverage = 100%
```

---

### 58. Dashboard Governance

Dashboard wajib memiliki:

- purpose;
- audience;
- owner;
- freshness;
- source;
- classification;
- review date;
- retirement rule.

---

### 59. Dashboard Usage Review

Dashboard tanpa penggunaan atau owner harus:

- direview;
- digabung;
- disederhanakan;
- atau dipensiunkan.

---

### 60. SLO Governance

SLO wajib:

- business-aligned;
- service-owned;
- versioned;
- reviewed;
- supported by valid SLI;
- memiliki error budget policy;
- memiliki exception process.

---

### 61. Error Budget Governance

Error budget memengaruhi:

- release pace;
- reliability work;
- incident priority;
- change approval;
- capacity planning.

---

### 62. SLO Change Approval

Major SLO change membutuhkan:

- service owner;
- platform review;
- business approval;
- impact analysis;
- effective date;
- versioning.

---

### 63. Incident Governance

Major incident wajib menghasilkan:

- timeline;
- impact;
- root cause;
- contributing factors;
- corrective actions;
- owners;
- due dates;
- verification.

---

### 64. Post-Incident Review

Review harus blameless tetapi accountable.

---

### 65. Corrective Action Governance

Corrective action wajib:

```text
action_id
description
owner
priority
due_date
status
evidence
verification
```

---

### 66. Cost Governance

Track:

```text
log storage cost
metric cardinality cost
trace ingestion cost
dashboard/query cost
archive cost
per-tenant cost
cost per signal category
```

---

### 67. Cost Budget

Setiap capability/service dapat memiliki:

```text
monthly telemetry budget
storage budget
ingestion budget
query budget
```

---

### 68. Cost Optimization Rules

Allowed:

- reduce debug retention;
- adaptive trace sampling;
- rollups;
- archive tier;
- remove unused dashboards;
- reduce high-cardinality labels.

Not allowed:

- sample audit;
- drop critical security events;
- reduce SLI accuracy silently;
- remove required legal evidence.

---

### 69. Security Governance

Wajib memeriksa:

- PHI/PII;
- secrets;
- tenant isolation;
- classification;
- restricted access;
- export;
- retention;
- legal hold;
- tamper evidence.

---

### 70. Privacy Review Triggers

Review required when:

- new RUM field;
- new event payload;
- new audit detail;
- cross-tenant analytics;
- long retention;
- external telemetry provider;
- profile capture.

---

### 71. Vendor Governance

External vendor evaluation:

- data residency;
- security;
- privacy;
- export;
- lock-in;
- retention;
- deletion;
- cost;
- SLA;
- incident response.

---

### 72. Change Governance

Changes requiring review:

- new metric dimension;
- new audit action;
- new integration event;
- SLO target change;
- alert severity change;
- retention change;
- sampling change;
- cross-tenant dashboard;
- external exporter.

---

### 73. Change Risk Levels

```text
STANDARD
ELEVATED
HIGH_RISK
EMERGENCY
```

---

### 74. Emergency Change

Emergency change wajib:

- reason;
- approver;
- bounded scope;
- post-review;
- rollback;
- audit.

---

### 75. Review Meeting Inputs

Monthly review inputs:

- SLO report;
- incident summary;
- alert quality;
- telemetry quality;
- cost report;
- exceptions;
- maturity gaps;
- overdue actions.

---

### 76. Review Meeting Outputs

- decisions;
- owners;
- due dates;
- exceptions;
- roadmap updates;
- risk acceptance;
- escalation.

---

### 77. Governance KPIs

```text
% signals with owner
% alerts with runbook
% SLOs reviewed on time
% dashboards reviewed on time
exception overdue count
false positive rate
maturity score
telemetry cost variance
incident corrective action closure rate
data quality compliance
```

---

### 78. KPI Targets

Initial targets:

```text
Signal owner coverage = 100%
SEV1/SEV2 runbook coverage = 100%
Quarterly SLO review completion = 100%
Overdue critical exceptions = 0
Critical corrective action closure on time > 95%
```

---

### 79. Governance Dashboard

Minimum widgets:

- maturity score by dimension;
- overdue reviews;
- active exceptions;
- alert quality;
- SLO compliance;
- incident actions;
- telemetry cost;
- owner coverage;
- data quality.

---

### 80. Governance Reporting

Reports:

```text
Monthly Observability Governance Report
Quarterly Maturity Assessment
Annual Observability Roadmap
Exception Register Report
Telemetry Cost Report
Signal Quality Report
SLO Governance Report
Incident Improvement Report
```

---

### 81. Audit Requirements

Audit events:

```text
OBS_GOV_STANDARD_APPROVED
OBS_GOV_STANDARD_DEPRECATED
OBS_GOV_EXCEPTION_REQUESTED
OBS_GOV_EXCEPTION_APPROVED
OBS_GOV_EXCEPTION_EXPIRED
OBS_GOV_MATURITY_ASSESSED
OBS_GOV_SLO_APPROVED
OBS_GOV_RETENTION_CHANGED
OBS_GOV_COST_BUDGET_CHANGED
OBS_GOV_REVIEW_COMPLETED
```

---

### 82. Permission Model

```text
observability.governance.read
observability.governance.manage
observability.governance.review
observability.governance.approve
observability.governance.exception.read
observability.governance.exception.manage
observability.governance.maturity.read
observability.governance.maturity.assess
observability.governance.cost.read
observability.governance.cost.manage
observability.governance.cross_tenant.read
```

---

### 83. Segregation of Duties

Person yang mengajukan exception sebaiknya bukan satu-satunya approver.

Critical approval membutuhkan four-eyes principle.

---

### 84. Evidence Retention

Governance evidence mengikuti SSOT-OBS-08.

Contoh:

- approval;
- review minutes;
- maturity reports;
- exceptions;
- risk acceptance;
- cost reports;
- action closure evidence.

---

### 85. Automation Opportunities

```text
owner coverage check
review due reminder
schema compliance check
alert runbook check
SLO freshness check
exception expiry alert
cost budget alert
maturity evidence collection
quality gate enforcement
```

---

### 86. CI/CD Governance Gates

Possible checks:

- metric code registered;
- log event code registered;
- integration event schema compatible;
- no forbidden fields;
- SLO definition valid;
- dashboard owner exists;
- alert runbook exists;
- retention mapping exists.

---

### 87. Governance Exceptions in CI/CD

Exception reference dapat digunakan sementara.

Wajib:

- valid;
- not expired;
- scope match;
- risk accepted.

---

### 88. Cultural Practices

- observability by design;
- blameless review;
- ownership clarity;
- evidence-based decisions;
- continuous learning;
- no silent failure;
- no hidden exceptions.

---

### 89. Anti-Pattern

Hindari:

- governance hanya dokumentasi;
- owner generik tanpa nama/team;
- review date kosong;
- exception tanpa expiry;
- maturity score tanpa evidence;
- SLO ditentukan platform sendiri;
- cost optimization dengan menghapus audit;
- dashboard tidak pernah direview;
- alert tanpa runbook;
- incident action tanpa verification;
- standard berubah tanpa versioning;
- governance council tanpa decision log.

---

### 90. UAT Part 1

#### Governance Model

- [ ] Council terbentuk.
- [ ] Membership tersedia.
- [ ] Cadence tersedia.
- [ ] Decision log tersedia.
- [ ] Escalation path tersedia.

#### Ownership

- [ ] Capability owner tersedia.
- [ ] Service owner tersedia.
- [ ] Signal owner tersedia.
- [ ] SLO owner tersedia.
- [ ] Dashboard owner tersedia.
- [ ] Alert owner tersedia.

#### Quality Gates

- [ ] Design gate tersedia.
- [ ] Implementation gate tersedia.
- [ ] Pre-production gate tersedia.
- [ ] Production gate tersedia.
- [ ] Operational review gate tersedia.
- [ ] Retirement gate tersedia.

#### Exceptions

- [ ] Exception memiliki owner.
- [ ] Exception memiliki expiry.
- [ ] Compensating control tersedia.
- [ ] Risk level tersedia.
- [ ] Critical exception membutuhkan approval.
- [ ] Expired exception menghasilkan alert.

#### Maturity

- [ ] Level 0–5 terdefinisi.
- [ ] Dimensions terdefinisi.
- [ ] Weight tersedia.
- [ ] Evidence diperlukan.
- [ ] Minimum threshold tersedia.
- [ ] Quarterly assessment tersedia.

#### Governance Metrics

- [ ] Owner coverage dihitung.
- [ ] Runbook coverage dihitung.
- [ ] SLO review completion dihitung.
- [ ] Exception overdue dihitung.
- [ ] Alert quality dihitung.
- [ ] Cost variance dihitung.

#### Security & Cost

- [ ] Privacy review triggers tersedia.
- [ ] Vendor review tersedia.
- [ ] Cost budget tersedia.
- [ ] Audit/security tidak boleh dikurangi karena cost.
- [ ] Segregation of duties tersedia.
- [ ] Governance events diaudit.

---

### 91. Definition of Done Part 1

Part 1 dianggap selesai bila:

- [ ] governance objective tersedia;
- [ ] governance domains tersedia;
- [ ] council model tersedia;
- [ ] operating model tersedia;
- [ ] lifecycle states tersedia;
- [ ] ownership types tersedia;
- [ ] RACI tersedia;
- [ ] governance artifacts tersedia;
- [ ] review cadence tersedia;
- [ ] quality gates tersedia;
- [ ] exception management tersedia;
- [ ] maturity levels tersedia;
- [ ] maturity dimensions/scoring tersedia;
- [ ] data quality governance tersedia;
- [ ] alert/dashboard/SLO governance tersedia;
- [ ] incident governance tersedia;
- [ ] cost governance tersedia;
- [ ] security/privacy governance tersedia;
- [ ] change governance tersedia;
- [ ] governance KPIs tersedia;
- [ ] permission/audit tersedia;
- [ ] CI/CD gate direction tersedia;
- [ ] UAT tersedia.

---

### 92. Rencana Part Berikutnya

#### Part 2

Governance catalogs, policy-as-code, review workflows, exception lifecycle, maturity scoring model, evidence requirements, cost allocation, data quality scorecards, SLO governance, dan CI/CD quality gates.

#### Part 3

Governance storage architecture, review evidence, approval records, exception register, maturity history, cost ledger, compliance evidence, retention, legal hold, audit integrity, reporting, dan disaster recovery.

#### Part 4

HTTP API, controllers, middleware, database schema, scheduler, approval workflow, review engine, maturity assessment service, cost governance APIs, dashboard APIs, audit, security, routing, dan sequence diagrams.

#### Part 5

Reference implementation, sample policies, sample maturity assessment, migration, deployment, rollback, simulations, operational runbooks, final UAT, Definition of Done, roadmap, dan merge guidance.

---

## Bagian II — Governance Catalogs, Policy-as-Code, Review Workflows, Exception Lifecycle, Maturity Scoring, Evidence, Cost Allocation, Scorecards & CI/CD Gates

### 1. Executive Summary

Part 2 mendefinisikan control layer untuk Observability Governance & Maturity Framework.

Bagian ini menetapkan:

- governance catalogs;
- policy-as-code;
- review workflows;
- exception lifecycle;
- maturity scoring;
- evidence requirements;
- data quality scorecards;
- cost allocation;
- SLO governance;
- alert and dashboard governance;
- CI/CD quality gates;
- automation;
- UAT.

Tujuan utamanya adalah mengubah governance dari dokumen pasif menjadi kontrol yang:

- dapat divalidasi;
- dapat diaudit;
- dapat diotomatisasi;
- memiliki owner;
- memiliki expiry;
- memiliki evidence;
- dapat memblokir perubahan berisiko;
- dapat diukur secara konsisten.

---

### 2. Governance Catalog Architecture

Governance catalogs adalah sumber data terstruktur untuk seluruh artifact observability.

```text
Governance Catalog
    │
    ├── Standard Catalog
    ├── Capability Catalog
    ├── Signal Catalog
    ├── SLO Catalog
    ├── Dashboard Catalog
    ├── Alert Catalog
    ├── Runbook Catalog
    ├── Incident Action Catalog
    ├── Exception Register
    ├── Review Register
    ├── Cost Allocation Catalog
    └── Maturity Assessment Catalog
```

---

### 3. Standard Catalog

Menyimpan:

```text
standard_code
title
version
status
owner
approver
effective_from
review_due_at
supersedes
classification
```

---

### 4. Capability Catalog

Contoh capability:

```text
LOGGING
METRICS
TRACING
HEALTH_CHECK
DASHBOARD
ALERTING
INCIDENT
RETENTION
PERFORMANCE
SIGNAL_GOVERNANCE
```

Field minimum:

```text
capability_code
name
owner
target_maturity
current_maturity
criticality
review_due_at
status
```

---

### 5. Signal Catalog

Signal catalog dapat mereferensikan catalog dari SSOT-OBS-10.

Minimum:

```text
signal_code
signal_category
owner
schema_version
classification
retention_policy
sampling_policy
tenant_scope
review_due_at
status
```

---

### 6. SLO Catalog

```text
slo_code
service_code
owner
business_owner
sli_code
target
window
error_budget_policy
criticality
effective_from
review_due_at
status
```

---

### 7. Dashboard Catalog

```text
dashboard_code
name
purpose
audience
owner
data_sources
classification
freshness_target
usage_threshold
review_due_at
retirement_rule
status
```

---

### 8. Alert Catalog

```text
alert_code
name
owner
service
severity
signal_source
condition
routing_policy
runbook_reference
deduplication_key
suppression_policy
review_due_at
status
```

---

### 9. Runbook Catalog

```text
runbook_code
title
owner
applicable_alerts
applicable_incidents
last_tested_at
review_due_at
status
```

---

### 10. Exception Register

```text
exception_id
standard_reference
scope
reason
risk_level
compensating_control
owner
approver
effective_from
expires_at
review_due_at
status
```

---

### 11. Review Register

```text
review_id
artifact_type
artifact_reference
review_type
reviewer
result
findings
actions
reviewed_at
next_review_at
status
```

---

### 12. Maturity Assessment Catalog

```text
assessment_id
scope
dimension
score
target_score
evidence_references
assessor
assessment_date
next_assessment_date
status
```

---

### 13. Cost Allocation Catalog

```text
cost_center
tenant_id optional
service_code
signal_category
budget_amount
actual_amount
allocation_method
period
owner
status
```

---

### 14. Catalog Validation

Setiap catalog entry wajib:

- unique code;
- owner valid;
- status valid;
- effective date valid;
- review due date;
- classification;
- version;
- audit trail.

---

### 15. Catalog Lifecycle

```text
DRAFT
REVIEW
APPROVED
ACTIVE
DEPRECATED
RETIRED
```

---

### 16. Catalog Dependency Validation

Contoh:

- alert wajib mereferensikan runbook;
- SLO wajib mereferensikan SLI;
- dashboard wajib mereferensikan data source;
- signal wajib mereferensikan retention policy;
- exception wajib mereferensikan standard;
- review wajib mereferensikan artifact aktif.

---

### 17. Policy-as-Code

Policy-as-code mengubah requirement governance menjadi rule yang dapat dieksekusi.

Contoh:

```text
Every SEV1 alert must have an active runbook
Every active SLO must have an owner
Every metric dimension must be registered
Every exception must have an expiry
No restricted signal may use public storage
```

---

### 18. Policy Categories

```text
ARCHITECTURE
OWNERSHIP
SCHEMA
SECURITY
PRIVACY
RETENTION
SLO
ALERTING
DASHBOARD
COST
MATURITY
CI_CD
```

---

### 19. Policy Definition

```yaml
policy_code: OBS_ALERT_RUNBOOK_REQUIRED
version: "1.0"
category: ALERTING
severity: BLOCKING
scope: active_alerts
description: Every SEV1 and SEV2 alert must reference an active runbook.
condition:
  severity_in:
    - SEV1
    - SEV2
require:
  runbook_status: ACTIVE
owner: platform_operations
effective_from: 2026-07-01
```

---

### 20. Policy Severity

```text
INFO
WARNING
BLOCKING
CRITICAL
```

---

### 21. Policy Evaluation Result

```text
PASS
WARN
FAIL
SKIPPED
UNKNOWN
```

---

### 22. Policy Engine Inputs

```text
artifact
scope
environment
owner
classification
status
version
exception_reference
```

---

### 23. Policy Engine Output

```text
policy_code
result
severity
message
evidence
remediation
exception_allowed
```

---

### 24. Policy Exception

Policy exception hanya valid jika:

- aktif;
- belum expired;
- scope cocok;
- approver valid;
- compensating control aktif.

---

### 25. Example Policy — Owner Required

```yaml
policy_code: OBS_OWNER_REQUIRED
version: "1.0"
category: OWNERSHIP
severity: BLOCKING
scope:
  - metric
  - alert
  - dashboard
  - slo
  - signal
require:
  owner_not_empty: true
```

---

### 26. Example Policy — Review Due

```yaml
policy_code: OBS_REVIEW_NOT_OVERDUE
version: "1.0"
category: GOVERNANCE
severity: WARNING
scope: active_artifacts
require:
  review_due_at_gte: today
```

---

### 27. Example Policy — No Audit Sampling

```yaml
policy_code: OBS_AUDIT_NO_SAMPLING
version: "1.0"
category: SECURITY
severity: CRITICAL
scope: audit_signals
require:
  sampling_policy: NONE
```

---

### 28. Example Policy — Restricted Storage

```yaml
policy_code: OBS_RESTRICTED_STORAGE_REQUIRED
version: "1.0"
category: SECURITY
severity: BLOCKING
scope:
  classification_in:
    - RESTRICTED
    - SECURITY_RESTRICTED
require:
  storage_class_in:
    - RESTRICTED
    - ENCRYPTED
```

---

### 29. Policy Lifecycle

```text
DRAFT
TESTING
ACTIVE
DEPRECATED
DISABLED
```

---

### 30. Policy Change Control

Policy change membutuhkan:

- owner;
- version;
- impact analysis;
- test cases;
- effective date;
- rollback;
- audit.

---

### 31. Review Workflow

```text
Submit
→ Validate
→ Assign Reviewers
→ Review
→ Resolve Findings
→ Approve/Reject
→ Publish
→ Schedule Next Review
```

---

### 32. Review Types

```text
ARCHITECTURE_REVIEW
SECURITY_REVIEW
PRIVACY_REVIEW
OPERATIONS_REVIEW
SLO_REVIEW
COST_REVIEW
MATURITY_REVIEW
POST_INCIDENT_REVIEW
RETIREMENT_REVIEW
```

---

### 33. Review Request

Field:

```text
review_id
artifact_type
artifact_reference
review_type
requestor
reviewers
due_at
risk_level
evidence_required
status
```

---

### 34. Review States

```text
DRAFT
SUBMITTED
IN_REVIEW
CHANGES_REQUESTED
APPROVED
REJECTED
EXPIRED
CLOSED
```

---

### 35. Review Findings

```text
finding_id
review_id
severity
category
description
evidence
recommendation
owner
due_date
status
```

---

### 36. Finding Severity

```text
INFO
MINOR
MAJOR
CRITICAL
```

---

### 37. Review Approval Rules

Contoh:

- standard approval membutuhkan Platform Architecture;
- restricted telemetry membutuhkan Security;
- SLO target membutuhkan Service Owner dan Business Owner;
- retention change membutuhkan Data Governance;
- critical exception membutuhkan Council.

---

### 38. Four-Eyes Principle

Four-eyes wajib untuk:

- critical exception;
- restricted export policy;
- SLO downgrade pada critical service;
- audit retention reduction;
- security sampling change;
- cross-tenant observability access.

---

### 39. Review SLA

| Review Type | Target |
|---|---:|
| Standard | 5 business days |
| Elevated | 3 business days |
| High-risk | 2 business days |
| Emergency | same day |
| Quarterly maturity | 10 business days |

---

### 40. Review Evidence

Evidence dapat berupa:

- config;
- code diff;
- test result;
- dashboard screenshot;
- metric output;
- incident report;
- cost report;
- risk assessment;
- architecture decision.

---

### 41. Exception Lifecycle

```text
REQUESTED
→ RISK_REVIEW
→ APPROVAL
→ ACTIVE
→ REVIEW
→ CLOSED/EXPIRED
```

---

### 42. Exception Request

```text
exception_id
policy_code
artifact_reference
scope
reason
risk_level
business_impact
compensating_control
owner
requested_expiry
```

---

### 43. Exception Approval

Approval harus mempertimbangkan:

- risk;
- duration;
- compensating control;
- blast radius;
- tenant impact;
- compliance impact;
- cost;
- reversibility.

---

### 44. Exception Expiry

Expired exception harus:

- menjadi invalid otomatis;
- menghasilkan alert;
- memblokir gate jika policy blocking;
- masuk review register;
- memerlukan extension baru.

---

### 45. Exception Extension

Extension bukan edit diam-diam.

Buat:

- extension request;
- new expiry;
- updated risk;
- approval;
- audit.

---

### 46. Exception Closure

Closure membutuhkan:

- remediation complete;
- evidence;
- owner confirmation;
- policy compliance re-check;
- audit.

---

### 47. Maturity Scoring Model

Score per dimension:

```text
0 = absent
1 = basic
2 = standardized
3 = managed
4 = optimized
5 = predictive
```

---

### 48. Scoring Components

```text
Policy
Implementation
Coverage
Evidence
Automation
Operational Effectiveness
```

---

### 49. Dimension Score Formula

Contoh:

```text
dimension_score =
policy_score × 15%
+ implementation_score × 25%
+ coverage_score × 20%
+ evidence_score × 15%
+ automation_score × 10%
+ effectiveness_score × 15%
```

---

### 50. Evidence Quality Weight

Evidence quality:

```text
SELF_REPORTED = 0.5
DOCUMENTED = 0.7
SYSTEM_GENERATED = 0.9
INDEPENDENTLY_VERIFIED = 1.0
```

Adjusted score:

```text
adjusted_score =
raw_score × evidence_quality_weight
```

---

### 51. Maturity Score Rounding

Gunakan dua decimal untuk reporting.

Level ditentukan dari threshold:

```text
0.00–0.99 = Level 0
1.00–1.99 = Level 1
2.00–2.99 = Level 2
3.00–3.99 = Level 3
4.00–4.74 = Level 4
4.75–5.00 = Level 5
```

---

### 52. Critical Dimension Floor

Overall score tidak boleh menutupi critical weakness.

Contoh:

```text
Jika Security < 2,
overall maturity maksimum Level 2.
```

---

### 53. Maturity Assessment Scope

```text
PLATFORM
SERVICE
MODULE
TENANT_TIER
CAPABILITY
```

---

### 54. Assessment Cadence

```text
Critical service: quarterly
Standard service: semiannual
Platform Kernel: quarterly
Enterprise-wide: annual
```

---

### 55. Assessment Evidence

Minimum evidence:

- catalog coverage;
- policy evaluation;
- SLO report;
- alert quality report;
- dashboard review;
- incident actions;
- data quality;
- cost report;
- exception register;
- UAT.

---

### 56. Maturity Gap

Gap:

```text
target_score - current_score
```

---

### 57. Maturity Action Plan

```text
action_id
dimension
current_score
target_score
gap
action
owner
priority
due_date
evidence
status
```

---

### 58. Data Quality Scorecard

Dimensions:

```text
Completeness
Freshness
Accuracy
Consistency
Uniqueness
Validity
Traceability
```

---

### 59. Completeness Score

```text
actual_expected_records / expected_records
```

---

### 60. Freshness Score

Berdasarkan:

```text
actual_delay vs freshness_target
```

---

### 61. Accuracy Score

Menggunakan:

- reconciliation;
- source comparison;
- error sampling;
- incident evidence.

---

### 62. Consistency Score

Mengecek:

- schema;
- naming;
- dimensions;
- units;
- tenant/scope;
- timestamps.

---

### 63. Uniqueness Score

Mengecek duplicate:

- metric series;
- audit record;
- integration message;
- incident action;
- dashboard identifier.

---

### 64. Validity Score

Persentase signal lulus schema/policy validation.

---

### 65. Traceability Score

Persentase signal dengan:

```text
owner
correlation
source
version
retention
```

---

### 66. Scorecard Status

```text
GREEN
AMBER
RED
UNKNOWN
```

---

### 67. Scorecard Threshold

Example:

```text
GREEN >= 95
AMBER 85–94.99
RED < 85
UNKNOWN no valid data
```

---

### 68. Scorecard Rule

UNKNOWN tidak boleh dianggap GREEN.

---

### 69. SLO Governance Workflow

```text
Propose SLI
→ Validate Data Quality
→ Propose SLO
→ Business Review
→ Technical Review
→ Approve
→ Activate
→ Monitor
→ Quarterly Review
```

---

### 70. SLO Proposal Fields

```text
slo_code
service
sli_code
target
window
business_impact
customer_commitment
error_budget_policy
owner
business_owner
effective_from
```

---

### 71. SLO Quality Gate

SLO tidak boleh aktif jika:

- SLI invalid;
- no owner;
- no business approval;
- data quality rendah;
- no error budget policy;
- no alert/runbook;
- no review date.

---

### 72. SLO Change Classification

```text
MINOR
MAJOR
BREAKING
```

---

### 73. SLO Downgrade

Target lebih longgar pada critical service harus:

- impact analysis;
- business approval;
- Council notification;
- expiry bila temporary;
- audit.

---

### 74. Alert Governance Workflow

```text
Create
→ Validate Signal
→ Assign Owner
→ Define Severity
→ Attach Runbook
→ Test
→ Activate
→ Measure Quality
→ Tune/Retire
```

---

### 75. Alert Activation Gate

Wajib:

- owner;
- severity;
- condition;
- deduplication;
- routing;
- runbook;
- test result;
- suppression policy;
- review date.

---

### 76. Dashboard Governance Workflow

```text
Create
→ Define Audience
→ Validate Sources
→ Assign Owner
→ Security Review
→ Activate
→ Usage Review
→ Retire
```

---

### 77. Dashboard Retirement Rule

Candidate retirement jika:

- no owner;
- no usage > threshold;
- data source obsolete;
- duplicated;
- incorrect;
- not reviewed.

---

### 78. Cost Allocation Model

Allocation dimensions:

```text
service
module
tenant
signal_category
environment
storage_tier
team
```

---

### 79. Cost Allocation Methods

```text
DIRECT
PROPORTIONAL_USAGE
FIXED_SHARE
WEIGHTED_CRITICALITY
SHARED_PLATFORM
```

---

### 80. Direct Cost

Digunakan bila biaya dapat dipetakan langsung.

---

### 81. Proportional Usage

```text
team_cost =
team_usage / total_usage × shared_cost
```

---

### 82. Weighted Criticality

Critical service dapat menerima allocation berbeda berdasarkan policy.

---

### 83. Cost Budget

Field:

```text
budget_code
scope
period
currency
budget_amount
warning_threshold
critical_threshold
owner
```

---

### 84. Cost Alert

Contoh:

```text
80% budget = warning
100% budget = critical
120% budget = escalation
```

---

### 85. Cost Anomaly

Detect:

- sudden log volume;
- metric cardinality spike;
- trace sampling increase;
- archive retrieval spike;
- expensive dashboard query.

---

### 86. Cost Optimization Workflow

```text
Detect
→ Attribute
→ Review Value
→ Propose Optimization
→ Risk Review
→ Implement
→ Verify
```

---

### 87. Forbidden Cost Optimization

Tidak boleh:

- sample audit;
- drop critical security event;
- reduce required retention;
- remove mandatory SLO data;
- hide tenant cost;
- disable incident evidence.

---

### 88. CI/CD Quality Gates

Pipeline stages:

```text
Lint
→ Catalog Validation
→ Policy Evaluation
→ Schema Compatibility
→ Security/Privacy Scan
→ SLO/Alert/Runbook Check
→ Test
→ Approval
→ Deploy
```

---

### 89. Catalog Validation Gate

Check:

- code exists;
- owner exists;
- status active;
- version valid;
- retention mapped;
- review not overdue.

---

### 90. Policy Evaluation Gate

Blocking policies harus PASS atau memiliki valid exception.

---

### 91. Schema Compatibility Gate

Untuk:

- log schemas;
- domain events;
- integration events;
- metric definitions;
- audit schemas.

---

### 92. Security/Privacy Gate

Check:

- forbidden fields;
- secrets;
- PHI/PII;
- classification;
- storage;
- export;
- tenant scope.

---

### 93. SLO Gate

Check:

- service has required SLO;
- SLI valid;
- target approved;
- owner;
- error budget policy;
- alert/runbook.

---

### 94. Alert Gate

Check:

- runbook;
- owner;
- routing;
- dedup;
- severity;
- test.

---

### 95. Dashboard Gate

Check:

- owner;
- audience;
- data sources;
- classification;
- review date.

---

### 96. CI/CD Gate Results

```text
PASS
PASS_WITH_EXCEPTION
WARN
FAIL
UNKNOWN
```

---

### 97. Fail-Closed vs Fail-Open

Critical security, audit, schema, tenant, dan SLO gates direkomendasikan fail-closed.

Non-critical informational checks dapat fail-open dengan warning.

---

### 98. Gate Exception Reference

Artifact dapat menyertakan:

```text
governance_exception_id
```

Validator harus memastikan:

- active;
- not expired;
- scope match;
- policy match.

---

### 99. Policy Test Cases

Setiap policy wajib memiliki:

```text
positive case
negative case
exception case
unknown data case
```

---

### 100. Governance Evidence Requirements

Evidence classes:

```text
CONFIGURATION
CODE
TEST_RESULT
RUNTIME_METRIC
DASHBOARD
AUDIT_RECORD
INCIDENT_REPORT
APPROVAL
COST_REPORT
REVIEW_MINUTES
```

---

### 101. Evidence Metadata

```text
evidence_id
type
source
artifact_reference
collected_at
valid_until
checksum
classification
owner
```

---

### 102. Evidence Freshness

Evidence dapat expired.

Contoh:

```text
load test: 90 days
security review: 1 year
SLO review: 90 days
runbook test: 90 days
cost report: 30 days
```

---

### 103. Evidence Quality

```text
SELF_REPORTED
DOCUMENTED
SYSTEM_GENERATED
INDEPENDENTLY_VERIFIED
```

---

### 104. Evidence Reuse

Satu evidence dapat digunakan beberapa assessment jika:

- scope sama;
- masih valid;
- classification sesuai;
- integrity valid.

---

### 105. Governance Automation

Automation candidates:

```text
review due detection
exception expiry
owner coverage
runbook coverage
catalog drift
policy evaluation
schema compatibility
cost variance
maturity evidence collection
scorecard refresh
```

---

### 106. Scheduled Governance Jobs

```text
governance-review-due-check
governance-exception-expiry-check
governance-owner-coverage-check
governance-policy-evaluate
governance-scorecard-refresh
governance-cost-allocation
governance-maturity-evidence-collect
governance-artifact-retirement-check
```

---

### 107. Review Due Notification

Notification windows:

```text
30 days before
14 days before
7 days before
on due date
overdue escalation
```

---

### 108. Exception Expiry Notification

```text
30 days
14 days
7 days
1 day
expired
```

---

### 109. Governance KPIs

```text
catalog_coverage_ratio
policy_compliance_ratio
review_on_time_ratio
exception_overdue_total
maturity_score
evidence_validity_ratio
runbook_coverage_ratio
slo_governance_compliance_ratio
cost_budget_variance
data_quality_score
```

---

### 110. Policy Compliance Ratio

```text
passed_blocking_policies /
evaluated_blocking_policies
```

---

### 111. Review On-Time Ratio

```text
reviews_completed_on_time /
reviews_due
```

---

### 112. Evidence Validity Ratio

```text
valid_evidence /
required_evidence
```

---

### 113. Governance Dashboard

Widgets:

- policy compliance;
- overdue reviews;
- active/expiring exceptions;
- maturity score;
- data quality score;
- SLO governance;
- cost variance;
- owner coverage;
- runbook coverage;
- failing CI/CD gates.

---

### 114. Permission Model

```text
observability.governance.catalog.read
observability.governance.catalog.manage
observability.governance.policy.read
observability.governance.policy.manage
observability.governance.review.read
observability.governance.review.manage
observability.governance.review.approve
observability.governance.exception.read
observability.governance.exception.manage
observability.governance.exception.approve
observability.governance.maturity.read
observability.governance.maturity.assess
observability.governance.cost.read
observability.governance.cost.manage
observability.governance.evidence.read
observability.governance.evidence.manage
```

---

### 115. Audit Events

```text
OBS_GOV_CATALOG_ENTRY_CREATED
OBS_GOV_CATALOG_ENTRY_UPDATED
OBS_GOV_POLICY_CREATED
OBS_GOV_POLICY_UPDATED
OBS_GOV_REVIEW_SUBMITTED
OBS_GOV_REVIEW_APPROVED
OBS_GOV_EXCEPTION_REQUESTED
OBS_GOV_EXCEPTION_APPROVED
OBS_GOV_EXCEPTION_EXTENDED
OBS_GOV_EXCEPTION_EXPIRED
OBS_GOV_MATURITY_ASSESSED
OBS_GOV_COST_BUDGET_CREATED
OBS_GOV_CI_GATE_OVERRIDDEN
```

---

### 116. Error Codes

```text
GOV_CATALOG_ENTRY_NOT_FOUND
GOV_CATALOG_ENTRY_INVALID
GOV_POLICY_NOT_FOUND
GOV_POLICY_EVALUATION_FAILED
GOV_POLICY_BLOCKED
GOV_REVIEW_NOT_FOUND
GOV_REVIEW_NOT_APPROVED
GOV_EXCEPTION_NOT_FOUND
GOV_EXCEPTION_EXPIRED
GOV_EXCEPTION_SCOPE_MISMATCH
GOV_MATURITY_EVIDENCE_INSUFFICIENT
GOV_COST_BUDGET_EXCEEDED
GOV_CI_GATE_FAILED
GOV_EVIDENCE_EXPIRED
GOV_OWNER_NOT_FOUND
```

---

### 117. Anti-Pattern

Hindari:

- catalog tanpa owner;
- policy tanpa test;
- review tanpa evidence;
- exception edit langsung;
- maturity score tanpa floor;
- UNKNOWN dianggap PASS;
- cost allocation tanpa method;
- CI gate selalu fail-open;
- SLO aktif tanpa business approval;
- dashboard aktif tanpa usage review;
- alert aktif tanpa runbook;
- expired evidence tetap dianggap valid;
- policy override tanpa audit;
- exception digunakan lintas scope.

---

### 118. UAT Part 2

#### Catalogs

- [ ] Standard catalog bekerja.
- [ ] Capability catalog bekerja.
- [ ] SLO catalog bekerja.
- [ ] Alert catalog bekerja.
- [ ] Dashboard catalog bekerja.
- [ ] Duplicate code/version ditolak.
- [ ] Owner dan review date wajib.

#### Policy-as-Code

- [ ] Policy dapat dibuat.
- [ ] Policy dapat diuji.
- [ ] Blocking policy memblokir.
- [ ] Warning policy tidak memblokir.
- [ ] Valid exception dapat melewati gate.
- [ ] Expired exception ditolak.
- [ ] UNKNOWN tidak dianggap PASS.

#### Reviews

- [ ] Review request dapat dibuat.
- [ ] Reviewer assignment bekerja.
- [ ] Findings tersedia.
- [ ] Approval rules bekerja.
- [ ] Four-eyes bekerja.
- [ ] Review SLA dapat dipantau.
- [ ] Next review otomatis tersedia.

#### Exceptions

- [ ] Exception memiliki expiry.
- [ ] Risk dan compensating control wajib.
- [ ] Extension membuat audit baru.
- [ ] Expiry menonaktifkan exception.
- [ ] Scope matching bekerja.
- [ ] Closure memerlukan evidence.

#### Maturity

- [ ] Score 0–5 bekerja.
- [ ] Weighted formula bekerja.
- [ ] Evidence quality weight bekerja.
- [ ] Critical dimension floor bekerja.
- [ ] Gap dihitung.
- [ ] Action plan tersedia.
- [ ] Assessment history tersedia.

#### Scorecards

- [ ] Completeness dihitung.
- [ ] Freshness dihitung.
- [ ] Validity dihitung.
- [ ] Traceability dihitung.
- [ ] UNKNOWN state tersedia.
- [ ] Threshold GREEN/AMBER/RED bekerja.

#### Cost Governance

- [ ] Cost allocation method tersedia.
- [ ] Budget tersedia.
- [ ] Warning/critical threshold bekerja.
- [ ] Cost anomaly terdeteksi.
- [ ] Forbidden optimization ditolak.
- [ ] Cost report per service tersedia.

#### CI/CD Gates

- [ ] Catalog validation bekerja.
- [ ] Policy evaluation bekerja.
- [ ] Schema compatibility bekerja.
- [ ] Security/privacy scan bekerja.
- [ ] SLO gate bekerja.
- [ ] Alert/runbook gate bekerja.
- [ ] Exception reference divalidasi.
- [ ] Gate result tercatat dan diaudit.

---

### 119. Definition of Done Part 2

Part 2 dianggap selesai bila:

- [ ] governance catalogs tersedia;
- [ ] catalog validation tersedia;
- [ ] policy-as-code tersedia;
- [ ] policy lifecycle tersedia;
- [ ] review workflow tersedia;
- [ ] findings model tersedia;
- [ ] approval rules tersedia;
- [ ] exception lifecycle tersedia;
- [ ] maturity scoring formula tersedia;
- [ ] evidence quality weighting tersedia;
- [ ] critical dimension floor tersedia;
- [ ] data quality scorecard tersedia;
- [ ] SLO governance workflow tersedia;
- [ ] alert governance workflow tersedia;
- [ ] dashboard governance workflow tersedia;
- [ ] cost allocation tersedia;
- [ ] cost budget tersedia;
- [ ] CI/CD quality gates tersedia;
- [ ] evidence requirements tersedia;
- [ ] governance automation tersedia;
- [ ] KPIs dan dashboard tersedia;
- [ ] permissions dan audit tersedia;
- [ ] UAT tersedia.

---

### 120. Rencana Part Berikutnya

#### Part 3

Governance storage architecture, review evidence, approval records, exception register, maturity history, cost ledger, compliance evidence, retention, legal hold, audit integrity, reporting, dan disaster recovery.

#### Part 4

HTTP API, controllers, middleware, database schema, scheduler, approval workflow, review engine, maturity assessment service, cost governance APIs, dashboard APIs, audit, security, routing, dan sequence diagrams.

#### Part 5

Reference implementation, sample policies, sample maturity assessment, migration, deployment, rollback, simulations, operational runbooks, final UAT, Definition of Done, roadmap, dan merge guidance.

---

## Bagian III — Governance Storage Architecture, Evidence, Approvals, Exceptions, Maturity History, Cost Ledger, Retention, Legal Hold, Audit Integrity, Reporting & Disaster Recovery

### 1. Executive Summary

Part 3 mendefinisikan persistence, evidence, integrity, retention, reporting, dan disaster recovery untuk Observability Governance & Maturity Framework.

Bagian ini menetapkan:

- governance storage separation;
- catalog persistence;
- policy version history;
- review and finding records;
- approval records;
- exception register;
- maturity assessment history;
- evidence store;
- scorecard snapshots;
- cost ledger;
- budget records;
- corrective action records;
- compliance evidence;
- retention;
- legal hold;
- append-only audit;
- chain of custody;
- reports;
- backup;
- restore;
- disaster recovery;
- performance;
- UAT.

Tujuan utamanya adalah memastikan keputusan governance:

- tidak hilang;
- dapat ditelusuri;
- memiliki approval evidence;
- memiliki owner;
- memiliki version history;
- dapat diaudit;
- dapat dipertahankan selama masa retensi;
- terlindungi dari perubahan tanpa izin;
- dapat dipulihkan saat bencana;
- dapat digunakan untuk maturity dan compliance review.

---

### 2. Governance Storage Principle

Governance data bukan sekadar konfigurasi aplikasi.

Governance data adalah evidence keputusan dan kontrol yang harus memiliki:

- durability;
- integrity;
- versioning;
- access control;
- retention;
- legal hold awareness;
- auditability;
- recoverability.

---

### 3. Storage Separation

Recommended logical stores:

```text
Governance Catalog Store
Policy Store
Review & Approval Store
Exception Store
Maturity Assessment Store
Evidence Store
Scorecard Store
Cost Ledger Store
Corrective Action Store
Governance Audit Store
Archive Store
```

Initial implementation dapat memakai satu database dengan schema/table terpisah dan credential terkontrol.

---

### 4. Governance Data Classes

```text
MASTER
TRANSACTIONAL
EVIDENCE
DERIVED
AUDIT
ARCHIVE
```

---

### 5. MASTER Data

Contoh:

- standards;
- capabilities;
- policies;
- catalogs;
- scoring models;
- cost allocation methods.

---

### 6. TRANSACTIONAL Data

Contoh:

- review request;
- approval;
- exception request;
- maturity assessment;
- budget period;
- corrective action.

---

### 7. EVIDENCE Data

Contoh:

- test result;
- configuration snapshot;
- report;
- approval attachment;
- policy evaluation result;
- dashboard snapshot;
- incident document.

---

### 8. DERIVED Data

Contoh:

- maturity score;
- compliance ratio;
- quality scorecard;
- cost allocation summary;
- overdue review summary.

Derived data dapat dihitung ulang jika source evidence tersedia.

---

### 9. AUDIT Data

Mencatat perubahan dan keputusan privileged.

Audit harus append-only.

---

### 10. ARCHIVE Data

Long-term evidence dan historical snapshots.

---

### 11. Governance Storage Architecture

```text
Governance Application
        │
        ├── Catalog Repository
        ├── Policy Repository
        ├── Review Repository
        ├── Approval Repository
        ├── Exception Repository
        ├── Maturity Repository
        ├── Evidence Repository
        ├── Cost Ledger Repository
        ├── Scorecard Repository
        ├── Corrective Action Repository
        └── Audit Writer
                │
                ▼
        Governance Database
                │
                ├── Hot Operational Tables
                ├── Historical Tables
                ├── Evidence Metadata
                └── Archive Manifest
                        │
                        ▼
                Encrypted Archive Storage
```

---

### 12. Catalog Persistence

Catalog table wajib menyimpan:

```text
catalog_type
artifact_code
artifact_version
status
owner
classification
effective_from
review_due_at
created_by
updated_by
created_at
updated_at
```

---

### 13. Catalog Versioning

Perubahan semantic membutuhkan version baru.

Historical version tidak boleh ditimpa.

---

### 14. Catalog Snapshot

Pada review atau approval, simpan snapshot:

```text
artifact_snapshot_json
artifact_hash
snapshot_at
```

---

### 15. Policy Persistence

Policy store menyimpan:

```text
policy_code
policy_version
category
severity
definition
status
owner
effective_from
deprecated_at
definition_hash
```

---

### 16. Policy Evaluation Persistence

Setiap evaluasi blocking atau critical harus disimpan.

Field:

```text
evaluation_id
policy_code
policy_version
artifact_type
artifact_reference
result
severity
message
evidence_json
exception_reference
evaluated_at
evaluator_version
```

---

### 17. Review Persistence

Review store harus memisahkan:

```text
Review Request
Review Assignment
Review Finding
Review Decision
Review Evidence Link
Review Action
```

---

### 18. Review Request Record

```text
review_id
artifact_type
artifact_reference
review_type
requestor
risk_level
due_at
status
submitted_at
closed_at
```

---

### 19. Review Assignment Record

```text
assignment_id
review_id
reviewer_reference
reviewer_role
assigned_at
responded_at
decision
```

---

### 20. Review Finding Record

```text
finding_id
review_id
severity
category
description
recommendation
owner
due_date
status
resolved_at
verification_evidence_id
```

---

### 21. Review Decision Record

```text
decision_id
review_id
decision
decision_reason
decided_by
decided_at
conditions_json
artifact_snapshot_hash
```

---

### 22. Approval Record

Approval harus independen dari mutable review summary.

Field:

```text
approval_id
approval_type
artifact_type
artifact_reference
artifact_version
approver_reference
approver_role
decision
reason
conditions_json
approved_at
expires_at optional
snapshot_hash
```

---

### 23. Four-Eyes Evidence

Untuk approval dengan four-eyes:

```text
minimum_approvers
distinct_approver_count
requestor_may_approve = false
```

---

### 24. Approval Integrity

Approval record wajib:

- append-only;
- artifact snapshot hash;
- approver identity;
- decision timestamp;
- no silent overwrite.

---

### 25. Conditional Approval

Conditional approval harus memiliki:

```text
condition
owner
due_date
verification_method
status
```

Jika condition tidak dipenuhi, approval dapat expire atau berubah invalid menurut policy.

---

### 26. Exception Register Persistence

Exception store menyimpan seluruh lifecycle.

Main record:

```text
exception_id
policy_code
artifact_reference
scope_json
reason
risk_level
business_impact
compensating_control
owner
status
effective_from
expires_at
created_at
```

---

### 27. Exception Event History

Setiap transition disimpan sebagai event:

```text
REQUESTED
RISK_REVIEWED
APPROVED
REJECTED
EXTENDED
EXPIRED
CLOSED
```

---

### 28. Exception Extension Record

```text
extension_id
exception_id
previous_expiry
new_expiry
updated_risk
reason
requested_by
approved_by
approved_at
```

---

### 29. Exception Scope Hash

Scope exception di-hash untuk memastikan gate menggunakan scope yang sama.

---

### 30. Compensating Control Evidence

Exception aktif wajib menunjuk evidence bahwa compensating control berjalan.

---

### 31. Maturity Assessment Persistence

Assessment header:

```text
assessment_id
scope_type
scope_reference
assessment_period
target_level
overall_score
overall_level
assessor
reviewer
status
assessed_at
approved_at
```

---

### 32. Maturity Dimension Record

```text
assessment_id
dimension_code
raw_score
evidence_quality_weight
adjusted_score
target_score
gap
critical_floor_applied
notes
```

---

### 33. Maturity Evidence Link

```text
assessment_id
dimension_code
evidence_id
evidence_role
valid_at_assessment
```

---

### 34. Maturity History

Historical assessments tidak boleh ditimpa.

Trend dapat dihitung:

```text
current_score - previous_score
```

---

### 35. Maturity Baseline

Initial assessment menjadi baseline.

Improvement harus dibandingkan dengan baseline dan previous assessment.

---

### 36. Reassessment

Reassessment membuat record baru.

Jangan mengubah score historical.

---

### 37. Maturity Action Plan Persistence

```text
action_id
assessment_id
dimension_code
description
owner
priority
due_date
status
verification_evidence_id
closed_at
```

---

### 38. Data Quality Scorecard Persistence

Scorecard snapshot:

```text
scorecard_id
scope
period
completeness
freshness
accuracy
consistency
uniqueness
validity
traceability
overall_score
status
generated_at
```

---

### 39. Scorecard Evidence

Simpan:

```text
source_query_hash
source_window
record_counts
quality_rules_version
calculation_version
```

---

### 40. Cost Ledger

Cost ledger mencatat biaya observability per period.

```text
ledger_id
period
cost_center
service_code
module_code
tenant_id optional
signal_category
usage_quantity
usage_unit
unit_cost
allocated_cost
allocation_method
currency
source_reference
created_at
```

---

### 41. Cost Ledger Immutability

Ledger historical tidak boleh diubah tanpa adjustment record.

---

### 42. Cost Adjustment

```text
adjustment_id
ledger_id
adjustment_amount
reason
approved_by
created_at
```

---

### 43. Budget Persistence

```text
budget_id
budget_code
scope_type
scope_reference
period
currency
budget_amount
warning_threshold
critical_threshold
owner
status
```

---

### 44. Cost Forecast Persistence

```text
forecast_id
scope
period
current_spend
forecast_spend
variance
confidence
generated_at
```

---

### 45. Corrective Action Store

Corrective action dapat berasal dari:

- incident;
- review;
- maturity assessment;
- policy violation;
- cost anomaly;
- security review.

---

### 46. Corrective Action Record

```text
action_id
source_type
source_reference
description
owner
priority
due_date
status
evidence_required
verification_method
closed_at
```

---

### 47. Action States

```text
OPEN
IN_PROGRESS
BLOCKED
READY_FOR_VERIFICATION
VERIFIED
CLOSED
CANCELED
```

---

### 48. Action Verification

Action tidak boleh CLOSED tanpa:

- verification;
- evidence;
- verifier;
- verified_at.

---

### 49. Evidence Store

Evidence terdiri dari metadata dan content reference.

Metadata:

```text
evidence_id
evidence_type
source
artifact_reference
content_reference
checksum
classification
owner
collected_at
valid_until
retention_policy
legal_hold_status
```

---

### 50. Evidence Content

Content dapat berupa:

- JSON;
- CSV;
- PDF;
- image;
- configuration;
- test output;
- archived query result;
- signed manifest.

---

### 51. Evidence Storage Rule

Large evidence disimpan di secure object/archive storage.

Database hanya menyimpan metadata dan reference.

---

### 52. Evidence Checksum

Gunakan SHA-256 atau approved algorithm.

---

### 53. Evidence Signature

Restricted/high-risk evidence dapat menggunakan digital signature.

---

### 54. Evidence Freshness

Evidence validity harus dinilai pada waktu assessment/review.

---

### 55. Evidence Expiry

Expired evidence tidak dihapus otomatis jika masih dalam retention.

Status menjadi:

```text
EXPIRED_FOR_USE
```

---

### 56. Evidence Classification

```text
INTERNAL
CONFIDENTIAL
RESTRICTED
SECURITY_RESTRICTED
LEGAL_HOLD
```

---

### 57. Evidence Access

Access harus berdasarkan:

- role;
- purpose;
- scope;
- classification;
- tenant;
- legal hold;
- approval if required.

---

### 58. Compliance Evidence Package

Package dapat mencakup:

- policy definition;
- evaluation result;
- approval;
- exception;
- evidence;
- maturity score;
- audit records;
- chain of custody;
- manifest.

---

### 59. Compliance Package Manifest

```text
package_id
scope
period
artifact_count
evidence_count
checksums
root_hash
created_at
created_by
signature
```

---

### 60. Governance Audit Store

Audit governance harus terpisah secara logis dari mutable operational tables.

---

### 61. Governance Audit Events

Wajib mencatat:

- catalog create/update/deprecate;
- policy create/update/activate;
- review submit/approve/reject;
- exception request/approve/extend/expire/close;
- maturity assess/approve;
- cost budget change;
- evidence export;
- CI gate override;
- legal hold action;
- retention change.

---

### 62. Governance Audit Minimum Fields

```text
audit_id
occurred_at
actor
action_code
resource_type
resource_reference
result
reason
before_hash
after_hash
correlation_id
classification
```

---

### 63. Governance Audit Integrity

Gunakan append-only dan hash chain sesuai SSOT-OBS-10.

---

### 64. Chain Scope

Recommended:

```text
governance + month
```

atau:

```text
tenant + governance + month
```

jika tenant-specific governance tersedia.

---

### 65. Retention Policy Classes

```text
GOV_SHORT
GOV_STANDARD
GOV_EXTENDED
GOV_REGULATED
GOV_LEGAL_HOLD
```

---

### 66. Example Retention Mapping

| Data | Retention |
|---|---|
| Policy evaluation | 1–3 tahun |
| Review records | 3–7 tahun |
| Approval records | 5–10 tahun |
| Exception records | 5–10 tahun |
| Maturity assessments | 5 tahun |
| Cost ledger | 5–7 tahun |
| Evidence metadata | sesuai artifact |
| Compliance packages | 7–10 tahun |
| Governance audit | 7–10 tahun |
| Temporary workspace | 1–30 hari |

Final mengikuti legal/compliance requirements.

---

### 67. Retention Start Point

Harus eksplisit:

```text
created_at
approved_at
closed_at
period_end
exception_expired_at
assessment_approved_at
```

---

### 68. Legal Hold

Legal hold dapat diterapkan pada:

- reviews;
- approvals;
- exceptions;
- evidence;
- audit;
- cost records;
- maturity reports;
- corrective actions.

---

### 69. Legal Hold Criteria

```text
case_id
artifact_type
artifact_reference
scope
tenant_id
time range
owner
review_id
incident_id
```

---

### 70. Legal Hold Enforcement

Legal hold harus memblokir:

- purge;
- archive deletion;
- crypto erasure;
- evidence workspace cleanup jika designated.

---

### 71. Retention Override

Override memerlukan:

- policy;
- reason;
- approver;
- expiry;
- audit.

---

### 72. Purge Eligibility

Data hanya eligible bila:

- retention expired;
- no legal hold;
- no active review;
- no unresolved finding;
- no active exception dependency;
- archive/evidence requirement complete.

---

### 73. Purge Evidence

Purge menghasilkan:

```text
purge_batch_id
data_category
scope
records_deleted
objects_deleted
policy_code
verification
evidence_hash
executed_at
```

---

### 74. Chain of Custody

Required untuk restricted evidence export/retrieval.

Events:

```text
CREATED
COLLECTED
REVIEWED
APPROVED
EXPORTED
TRANSFERRED
ARCHIVED
VERIFIED
PURGED
```

---

### 75. Chain of Custody Record

```text
custody_id
evidence_id
action
actor
source
destination
reason
checksum_before
checksum_after
occurred_at
```

---

### 76. Archive Architecture

```text
Operational Database
→ Eligible Historical Data
→ Archive Batch
→ Manifest
→ Encryption
→ Immutable Storage
→ Verification
→ Purge Source if allowed
```

---

### 77. Archive Format

Recommended:

```text
NDJSON/CSV for structured records
PDF for formal reports
JSON manifest
compression
encryption
checksum
signature
```

---

### 78. Archive Object Naming

```text
governance/
artifact-type/
year/
month/
batch-id/
object-sequence
```

Jangan masukkan sensitive data pada object key.

---

### 79. Evidence Workspace

Temporary retrieval workspace wajib:

- encrypted;
- isolated;
- non-public;
- auto-expire;
- access logged;
- checksum verified.

---

### 80. Governance Reports

Required reports:

```text
Monthly Governance Report
Quarterly Maturity Report
Policy Compliance Report
Exception Register Report
Review SLA Report
Evidence Validity Report
Cost Allocation Report
Corrective Action Report
Annual Governance Summary
```

---

### 81. Monthly Governance Report

Isi:

- policy compliance;
- overdue reviews;
- active exceptions;
- expiring exceptions;
- scorecard status;
- cost variance;
- corrective actions;
- owner coverage.

---

### 82. Quarterly Maturity Report

Isi:

- score by dimension;
- overall level;
- critical floor;
- trend;
- target gap;
- evidence quality;
- action plan.

---

### 83. Exception Register Report

Isi:

- active;
- expiring;
- expired;
- critical;
- overdue remediation;
- compensating control status.

---

### 84. Review SLA Report

Isi:

- reviews due;
- completed;
- overdue;
- average lead time;
- findings;
- approval outcomes.

---

### 85. Evidence Validity Report

Isi:

- valid;
- expiring;
- expired;
- missing;
- invalid checksum;
- classification conflicts.

---

### 86. Cost Allocation Report

Isi:

- actual vs budget;
- variance;
- top services;
- top signal categories;
- tenant allocation;
- anomalies;
- recommended action.

---

### 87. Reporting Snapshots

Report harus menyimpan:

```text
report_id
report_type
period
scope
calculation_version
data_snapshot_hash
generated_at
generated_by
classification
```

---

### 88. Report Reproducibility

Simpan:

- source criteria;
- policy version;
- formula version;
- exchange rate source if relevant;
- calculation timestamp.

---

### 89. Backup Architecture

Backup wajib mencakup:

- catalogs;
- policies;
- reviews;
- approvals;
- exceptions;
- maturity history;
- evidence metadata;
- scorecards;
- cost ledger;
- budgets;
- corrective actions;
- audit;
- manifests;
- legal holds.

---

### 90. Backup Tiers

```text
Daily incremental
Weekly full
Monthly immutable
Quarterly restore test
```

---

### 91. Backup Encryption

Backup wajib terenkripsi.

Key management terpisah dari backup media.

---

### 92. Backup Integrity

Gunakan:

- checksum;
- manifest;
- verification logs;
- periodic restore.

---

### 93. Restore Order

Recommended:

```text
1. Governance schemas/config
2. Catalogs and policies
3. Retention/legal holds
4. Reviews and approvals
5. Exceptions
6. Evidence metadata
7. Maturity history
8. Cost ledger
9. Corrective actions
10. Audit and manifests
11. Derived scorecards/reports
```

---

### 94. Restore Validation

Validate:

- counts;
- hashes;
- versions;
- approval links;
- evidence references;
- legal holds;
- exception status;
- audit chain;
- report reproducibility.

---

### 95. Disaster Recovery

DR harus mendefinisikan:

```text
RPO
RTO
failover
restore
validation
communication
fallback
```

---

### 96. Recommended RPO/RTO

| Data | RPO | RTO |
|---|---:|---:|
| Governance catalogs | ≤ 15 min | ≤ 4 h |
| Reviews/approvals | ≤ 15 min | ≤ 4 h |
| Exceptions | ≤ 5 min | ≤ 2 h |
| Governance audit | ≤ 5 min | ≤ 4 h |
| Evidence metadata | ≤ 15 min | ≤ 8 h |
| Cost ledger | ≤ 24 h | ≤ 24 h |
| Maturity history | ≤ 24 h | ≤ 24 h |
| Reports | rebuildable | ≤ 48 h |

Final berdasarkan business impact.

---

### 97. DR Degraded Mode

Jika governance platform unavailable:

- existing approved controls remain valid;
- new critical approvals may be blocked;
- emergency process can be invoked;
- audit evidence must be preserved;
- reconciliation required after recovery.

---

### 98. Emergency Approval Fallback

Fallback wajib:

- pre-defined approvers;
- bounded duration;
- offline evidence;
- post-recovery registration;
- audit;
- no anonymous approval.

---

### 99. Reconciliation After Recovery

Reconcile:

- offline approvals;
- CI/CD overrides;
- exceptions;
- reviews;
- evidence uploads;
- audit sequence;
- cost events.

---

### 100. Data Residency

Governance evidence dapat mengandung restricted data.

Replication/archive harus mengikuti residency policy.

---

### 101. Multi-Tenant Governance

Tenant-specific governance data wajib:

- tenant_id;
- scope isolation;
- restricted cross-tenant queries;
- tenant-aware cost;
- tenant-aware exceptions;
- tenant-aware reports.

---

### 102. Cross-Tenant Governance

Cross-tenant reports harus:

- aggregate safely;
- suppress identifying detail;
- require permission;
- be audited.

---

### 103. Access Roles

```text
Governance Administrator
Reviewer
Approver
Compliance Analyst
Security Analyst
Cost Analyst
Service Owner
Auditor
Read-Only Executive
```

---

### 104. Least Privilege

Examples:

- reviewer tidak otomatis dapat approve;
- cost analyst tidak otomatis dapat read restricted security evidence;
- service owner hanya scope sendiri;
- auditor read-only;
- application cannot delete governance audit.

---

### 105. Database Credentials

Recommended:

```text
gov_app_rw
gov_review_rw
gov_approval_append
gov_audit_append
gov_report_read
gov_archive_operator
gov_restore_operator
```

---

### 106. Encryption

At-rest encryption wajib.

Field-level encryption untuk:

- restricted evidence references;
- approval notes sensitive;
- legal hold metadata;
- security findings.

---

### 107. Search Indexing

Index important fields:

```text
artifact_code
status
owner
review_due_at
expires_at
policy_code
scope
period
classification
```

Avoid indexing large evidence content.

---

### 108. Partitioning

Candidate partitioning:

- audit by month;
- policy evaluations by month/quarter;
- cost ledger by period;
- reports by year;
- evidence metadata by year.

---

### 109. Performance Requirements

Storage harus mendukung:

- fast governance dashboard;
- policy evaluation persistence;
- approval lookup;
- exception validation in CI/CD;
- report generation;
- maturity history queries;
- cost allocation.

---

### 110. Initial Performance Targets

```text
Catalog lookup p95 < 100 ms
Active exception validation p95 < 50 ms
Policy evaluation write p95 < 100 ms
Approval lookup p95 < 100 ms
Governance dashboard p95 < 1.5 s
Monthly report generation < 10 min
Quarterly maturity report < 15 min
```

---

### 111. Capacity Inputs

```text
artifact count
policy evaluation count
review count
evidence size
cost ledger rows
assessment frequency
report retention
tenant count
```

---

### 112. Derived Data Rebuild

Scorecards dan reports harus dapat dibangun ulang dari source records.

---

### 113. Integrity Verification Schedule

```text
daily audit chain check
weekly evidence checksum sample
monthly archive manifest verification
quarterly restore test
annual full governance evidence review
```

---

### 114. Integrity Failure

Jika failure:

- mark evidence suspect;
- block purge;
- create alert;
- create incident;
- preserve replicas;
- verify source;
- audit response.

---

### 115. Governance Health Metrics

```text
governance_catalog_total
governance_policy_evaluation_total
governance_policy_failure_total
governance_review_overdue_total
governance_exception_active_total
governance_exception_expired_total
governance_evidence_expired_total
governance_maturity_score
governance_cost_variance_ratio
governance_action_overdue_total
governance_audit_integrity_failure_total
governance_backup_failure_total
```

---

### 116. Alert Candidates

```text
critical_policy_failure
exception_expired
review_overdue_critical
evidence_integrity_failed
governance_audit_chain_broken
cost_budget_critical
critical_action_overdue
backup_failed
restore_test_failed
legal_hold_purge_attempted
```

---

### 117. Data Quality Rules

- no orphan approval;
- no active exception without approval;
- no review without artifact;
- no evidence without checksum;
- no maturity score without evidence;
- no cost adjustment without source ledger;
- no closed action without verification.

---

### 118. Reconciliation Jobs

```text
catalog-policy-reference-reconcile
review-approval-reconcile
exception-expiry-reconcile
maturity-evidence-reconcile
cost-ledger-budget-reconcile
action-verification-reconcile
archive-manifest-reconcile
audit-chain-reconcile
```

---

### 119. Migration Strategy

Migration from spreadsheets/manual docs:

1. inventory;
2. classify;
3. assign owner;
4. assign version;
5. map lifecycle;
6. validate dates;
7. attach evidence;
8. mark confidence;
9. import;
10. review.

---

### 120. Legacy Data Quality

Imported legacy records harus memiliki:

```text
migration_source
migration_batch
evidence_quality
confidence
```

---

### 121. Legacy Approval

Jangan menganggap email/chat lama sebagai formal approval tanpa qualification.

Tandai:

```text
approval_quality = LEGACY_INFERRED
```

---

### 122. Legacy Exception

Exception lama tanpa expiry harus:

- diberi temporary expiry;
- masuk review;
- tidak otomatis aktif permanen.

---

### 123. Anti-Pattern

Hindari:

- approval hanya field pada artifact;
- review history ditimpa;
- evidence disimpan di public folder;
- exception tanpa event history;
- maturity score tanpa version formula;
- cost ledger dapat diedit langsung;
- report tanpa snapshot hash;
- legal hold hanya dokumentasi;
- backup tanpa restore test;
- audit dan operational table memakai permission sama;
- evidence expired dihapus sebelum retention;
- cross-tenant report tanpa masking.

---

### 124. UAT Part 3

#### Catalog & Policy Storage

- [ ] Catalog version tersimpan.
- [ ] Historical version tidak tertimpa.
- [ ] Policy definition hash tersedia.
- [ ] Policy evaluation tersimpan.
- [ ] Artifact snapshot tersedia.
- [ ] Orphan reference ditolak.

#### Review & Approval

- [ ] Review request tersimpan.
- [ ] Assignment tersimpan.
- [ ] Findings tersimpan.
- [ ] Decision append-only.
- [ ] Approval snapshot hash tersedia.
- [ ] Four-eyes dapat diverifikasi.
- [ ] Conditional approval bekerja.

#### Exceptions

- [ ] Exception lifecycle tersimpan.
- [ ] Extension history tersedia.
- [ ] Scope hash tersedia.
- [ ] Expiry otomatis terdeteksi.
- [ ] Compensating control evidence wajib.
- [ ] Closure tidak menghapus history.

#### Maturity & Scorecards

- [ ] Assessment history immutable.
- [ ] Dimension scores tersimpan.
- [ ] Evidence links tersedia.
- [ ] Critical floor tersimpan.
- [ ] Reassessment membuat record baru.
- [ ] Scorecard calculation version tersedia.
- [ ] Derived report dapat direbuild.

#### Cost Ledger

- [ ] Ledger immutable.
- [ ] Adjustment record bekerja.
- [ ] Budget mapping bekerja.
- [ ] Forecast tersimpan.
- [ ] Cost allocation reproducible.
- [ ] Period lock tersedia.

#### Evidence

- [ ] Metadata dan content terpisah.
- [ ] Checksum diverifikasi.
- [ ] Expired-for-use state bekerja.
- [ ] Restricted access bekerja.
- [ ] Compliance package manifest dibuat.
- [ ] Chain of custody tersedia.

#### Retention & Legal Hold

- [ ] Retention mapping bekerja.
- [ ] Start point eksplisit.
- [ ] Legal hold memblokir purge.
- [ ] Active review memblokir purge bila policy.
- [ ] Purge evidence dibuat.
- [ ] Archive manifest diverifikasi.

#### Audit Integrity

- [ ] Governance audit append-only.
- [ ] Hash chain terbentuk.
- [ ] Integrity verification bekerja.
- [ ] Failure memblokir purge.
- [ ] Privileged search/export diaudit.
- [ ] Audit restore tervalidasi.

#### Backup & DR

- [ ] Backup terenkripsi.
- [ ] Daily/weekly/monthly tier berjalan.
- [ ] Restore order diuji.
- [ ] Approval links tetap valid.
- [ ] Exception status tetap benar.
- [ ] Evidence references tetap valid.
- [ ] RPO/RTO diuji.
- [ ] Emergency fallback direkonsiliasi.

#### Reporting & Performance

- [ ] Monthly report reproducible.
- [ ] Maturity report reproducible.
- [ ] Exception report akurat.
- [ ] Cost report akurat.
- [ ] Dashboard memenuhi target.
- [ ] Capacity metrics tersedia.

---

### 125. Definition of Done Part 3

Part 3 dianggap selesai bila:

- [ ] storage separation tersedia;
- [ ] catalog persistence tersedia;
- [ ] policy history tersedia;
- [ ] policy evaluation storage tersedia;
- [ ] review records tersedia;
- [ ] approval records tersedia;
- [ ] four-eyes evidence tersedia;
- [ ] exception register/history tersedia;
- [ ] maturity history tersedia;
- [ ] scorecard snapshots tersedia;
- [ ] cost ledger dan adjustment tersedia;
- [ ] budget/forecast tersedia;
- [ ] corrective action store tersedia;
- [ ] evidence metadata/content model tersedia;
- [ ] compliance package tersedia;
- [ ] governance audit append-only tersedia;
- [ ] retention mapping tersedia;
- [ ] legal hold tersedia;
- [ ] purge evidence tersedia;
- [ ] chain of custody tersedia;
- [ ] archive/retrieval tersedia;
- [ ] reporting tersedia;
- [ ] backup/restore tersedia;
- [ ] DR dan fallback tersedia;
- [ ] security/access tersedia;
- [ ] performance/capacity tersedia;
- [ ] reconciliation tersedia;
- [ ] UAT tersedia.

---

### 126. Rencana Part Berikutnya

#### Part 4

HTTP API, controllers, middleware, database schema, scheduler, approval workflow, review engine, maturity assessment service, cost governance APIs, dashboard APIs, audit, security, Apache/XAMPP routing, dan sequence diagrams.

#### Part 5

Reference implementation, sample policies, sample maturity assessment, migration, deployment, rollback, simulations, operational runbooks, final UAT, Definition of Done, roadmap, dan merge guidance.

---

## Bagian IV — HTTP API, Controllers, Middleware, Database Schema, Scheduler, Approval Workflow, Review Engine, Maturity Service, Cost APIs, Dashboard, Audit & Routing

### 1. Executive Summary

Part 4 mendefinisikan interface dan infrastructure untuk Observability Governance & Maturity Framework.

Bagian ini menetapkan:

- HTTP API;
- controller responsibilities;
- request/response contracts;
- middleware order;
- permission;
- tenant/scope isolation;
- governance catalog API;
- policy API;
- review API;
- approval API;
- exception API;
- maturity assessment API;
- scorecard API;
- evidence API;
- cost governance API;
- dashboard API;
- scheduler;
- approval workflow;
- review engine;
- policy evaluation engine;
- database schema;
- audit integration;
- security controls;
- metrics;
- alerts;
- Apache/XAMPP routing;
- sequence diagrams;
- UAT.

Tujuan utamanya adalah memastikan governance dapat dijalankan sebagai capability aktif yang:

- terstruktur;
- versioned;
- dapat diaudit;
- dapat diotomatisasi;
- dapat memblokir perubahan berisiko;
- dapat menilai maturity;
- dapat mengelola cost;
- dapat menegakkan review dan exception lifecycle;
- tenant/scope-aware;
- aman untuk bukti restricted.

---

### 2. API Architecture

```text
HTTP Request
    │
    ▼
Security Middleware
    │
    ├── Request ID
    ├── Authentication
    ├── Rate Limit
    ├── Tenant Context
    ├── Active Scope
    ├── Permission
    ├── Classification
    ├── CSRF
    └── Governance Context
    │
    ▼
Controller
    │
    ▼
Application Service
    │
    ├── Catalog Service
    ├── Policy Service
    ├── Review Service
    ├── Approval Service
    ├── Exception Service
    ├── Maturity Service
    ├── Scorecard Service
    ├── Evidence Service
    ├── Cost Governance Service
    ├── Dashboard Service
    └── Reporting Service
    │
    ▼
Repositories / Policy Engine / Workflow Engine / Scheduler
```

---

### 3. Base API Paths

```text
/api/internal/v1/governance/catalogs
/api/internal/v1/governance/policies
/api/internal/v1/governance/reviews
/api/internal/v1/governance/approvals
/api/internal/v1/governance/exceptions
/api/internal/v1/governance/maturity
/api/internal/v1/governance/scorecards
/api/internal/v1/governance/evidence
/api/internal/v1/governance/costs
/api/internal/v1/governance/reports
/api/internal/v1/governance/dashboard
/api/internal/v1/governance/health
```

---

### 4. Governance Catalog API

```text
GET    /api/internal/v1/governance/catalogs
GET    /api/internal/v1/governance/catalogs/{catalogType}
GET    /api/internal/v1/governance/catalogs/{catalogType}/{artifactCode}
POST   /api/internal/v1/governance/catalogs/{catalogType}
PUT    /api/internal/v1/governance/catalogs/{catalogType}/{artifactCode}
POST   /api/internal/v1/governance/catalogs/{catalogType}/{artifactCode}/submit
POST   /api/internal/v1/governance/catalogs/{catalogType}/{artifactCode}/activate
POST   /api/internal/v1/governance/catalogs/{catalogType}/{artifactCode}/deprecate
POST   /api/internal/v1/governance/catalogs/{catalogType}/{artifactCode}/retire
GET    /api/internal/v1/governance/catalogs/{catalogType}/{artifactCode}/versions
```

---

### 5. Policy API

```text
GET    /api/internal/v1/governance/policies
GET    /api/internal/v1/governance/policies/{policyCode}
POST   /api/internal/v1/governance/policies
PUT    /api/internal/v1/governance/policies/{policyCode}
POST   /api/internal/v1/governance/policies/{policyCode}/test
POST   /api/internal/v1/governance/policies/{policyCode}/activate
POST   /api/internal/v1/governance/policies/{policyCode}/deprecate
POST   /api/internal/v1/governance/policies/evaluate
GET    /api/internal/v1/governance/policies/evaluations
GET    /api/internal/v1/governance/policies/evaluations/{evaluationId}
```

---

### 6. Review API

```text
GET  /api/internal/v1/governance/reviews
GET  /api/internal/v1/governance/reviews/{reviewId}
POST /api/internal/v1/governance/reviews
POST /api/internal/v1/governance/reviews/{reviewId}/submit
POST /api/internal/v1/governance/reviews/{reviewId}/assign
POST /api/internal/v1/governance/reviews/{reviewId}/findings
POST /api/internal/v1/governance/reviews/{reviewId}/request-changes
POST /api/internal/v1/governance/reviews/{reviewId}/approve
POST /api/internal/v1/governance/reviews/{reviewId}/reject
POST /api/internal/v1/governance/reviews/{reviewId}/close
GET  /api/internal/v1/governance/reviews/{reviewId}/history
```

---

### 7. Approval API

```text
GET  /api/internal/v1/governance/approvals
GET  /api/internal/v1/governance/approvals/{approvalId}
POST /api/internal/v1/governance/approvals
POST /api/internal/v1/governance/approvals/{approvalId}/approve
POST /api/internal/v1/governance/approvals/{approvalId}/reject
POST /api/internal/v1/governance/approvals/{approvalId}/revoke
GET  /api/internal/v1/governance/approvals/{approvalId}/conditions
GET  /api/internal/v1/governance/approvals/{approvalId}/evidence
```

---

### 8. Exception API

```text
GET  /api/internal/v1/governance/exceptions
GET  /api/internal/v1/governance/exceptions/{exceptionId}
POST /api/internal/v1/governance/exceptions
POST /api/internal/v1/governance/exceptions/{exceptionId}/submit
POST /api/internal/v1/governance/exceptions/{exceptionId}/risk-review
POST /api/internal/v1/governance/exceptions/{exceptionId}/approve
POST /api/internal/v1/governance/exceptions/{exceptionId}/reject
POST /api/internal/v1/governance/exceptions/{exceptionId}/extend
POST /api/internal/v1/governance/exceptions/{exceptionId}/close
GET  /api/internal/v1/governance/exceptions/{exceptionId}/history
GET  /api/internal/v1/governance/exceptions/expiring
GET  /api/internal/v1/governance/exceptions/overdue
```

---

### 9. Maturity API

```text
GET  /api/internal/v1/governance/maturity/assessments
GET  /api/internal/v1/governance/maturity/assessments/{assessmentId}
POST /api/internal/v1/governance/maturity/assessments
POST /api/internal/v1/governance/maturity/assessments/{assessmentId}/calculate
POST /api/internal/v1/governance/maturity/assessments/{assessmentId}/submit
POST /api/internal/v1/governance/maturity/assessments/{assessmentId}/approve
GET  /api/internal/v1/governance/maturity/scopes/{scopeType}/{scopeReference}
GET  /api/internal/v1/governance/maturity/scopes/{scopeType}/{scopeReference}/trend
GET  /api/internal/v1/governance/maturity/scopes/{scopeType}/{scopeReference}/gaps
```

---

### 10. Scorecard API

```text
GET  /api/internal/v1/governance/scorecards
GET  /api/internal/v1/governance/scorecards/{scorecardId}
POST /api/internal/v1/governance/scorecards/generate
GET  /api/internal/v1/governance/scorecards/scopes/{scopeType}/{scopeReference}
GET  /api/internal/v1/governance/scorecards/scopes/{scopeType}/{scopeReference}/trend
```

---

### 11. Evidence API

```text
GET  /api/internal/v1/governance/evidence
GET  /api/internal/v1/governance/evidence/{evidenceId}
POST /api/internal/v1/governance/evidence
POST /api/internal/v1/governance/evidence/{evidenceId}/verify
POST /api/internal/v1/governance/evidence/{evidenceId}/archive
POST /api/internal/v1/governance/evidence/{evidenceId}/export
GET  /api/internal/v1/governance/evidence/{evidenceId}/custody
GET  /api/internal/v1/governance/evidence/expiring
```

---

### 12. Cost Governance API

```text
GET  /api/internal/v1/governance/costs/ledger
POST /api/internal/v1/governance/costs/ledger/import
GET  /api/internal/v1/governance/costs/budgets
POST /api/internal/v1/governance/costs/budgets
PUT  /api/internal/v1/governance/costs/budgets/{budgetId}
GET  /api/internal/v1/governance/costs/allocations
POST /api/internal/v1/governance/costs/allocate
GET  /api/internal/v1/governance/costs/forecasts
POST /api/internal/v1/governance/costs/forecasts/generate
GET  /api/internal/v1/governance/costs/anomalies
```

---

### 13. Dashboard API

```text
GET /api/internal/v1/governance/dashboard/overview
GET /api/internal/v1/governance/dashboard/policies
GET /api/internal/v1/governance/dashboard/reviews
GET /api/internal/v1/governance/dashboard/exceptions
GET /api/internal/v1/governance/dashboard/maturity
GET /api/internal/v1/governance/dashboard/quality
GET /api/internal/v1/governance/dashboard/costs
GET /api/internal/v1/governance/dashboard/actions
```

---

### 14. Report API

```text
GET  /api/internal/v1/governance/reports
GET  /api/internal/v1/governance/reports/{reportId}
POST /api/internal/v1/governance/reports/monthly
POST /api/internal/v1/governance/reports/maturity
POST /api/internal/v1/governance/reports/exceptions
POST /api/internal/v1/governance/reports/costs
POST /api/internal/v1/governance/reports/export
```

---

### 15. Common Query Filters

```text
artifact_type
artifact_code
artifact_version
status
owner
reviewer
approver
policy_code
result
risk_level
scope_type
scope_reference
tenant_id
classification
period
time_from
time_to
page
per_page
sort
```

---

### 16. Catalog Create Request

```json
{
  "artifact_code": "OBS_ALERT_CATALOG",
  "artifact_version": "1.0",
  "name": "Observability Alert Catalog",
  "owner": "platform_operations",
  "classification": "INTERNAL",
  "effective_from": "2026-07-01",
  "review_due_at": "2026-10-01",
  "content": {
    "description": "Catalog of active observability alerts."
  }
}
```

---

### 17. Policy Create Request

```json
{
  "policy_code": "OBS_ALERT_RUNBOOK_REQUIRED",
  "policy_version": "1.0",
  "category": "ALERTING",
  "severity": "BLOCKING",
  "scope": {
    "artifact_type": "ALERT",
    "severity_in": [
      "SEV1",
      "SEV2"
    ]
  },
  "definition": {
    "require": {
      "runbook_status": "ACTIVE"
    }
  },
  "owner": "platform_operations",
  "effective_from": "2026-07-01"
}
```

---

### 18. Review Create Request

```json
{
  "artifact_type": "SLO",
  "artifact_reference": "patient_api_availability_999",
  "review_type": "SLO_REVIEW",
  "risk_level": "HIGH",
  "due_at": "2026-07-15T17:00:00Z",
  "reviewers": [
    "service_owner:patient",
    "platform_architecture",
    "business_owner:clinical_operations"
  ],
  "evidence_required": [
    "SLI_DATA_QUALITY",
    "ERROR_BUDGET_POLICY",
    "LOAD_TEST_RESULT"
  ]
}
```

---

### 19. Exception Create Request

```json
{
  "policy_code": "OBS_TRACE_COVERAGE_MINIMUM",
  "artifact_reference": "legacy-billing-module",
  "scope": {
    "environment": "production",
    "module_code": "billing"
  },
  "reason": "Legacy integration does not yet propagate trace context.",
  "risk_level": "HIGH",
  "business_impact": "Potentially slower root cause analysis.",
  "compensating_control": "Enhanced structured logging and correlation IDs.",
  "requested_expiry": "2026-09-30T23:59:59Z"
}
```

---

### 20. Maturity Assessment Create Request

```json
{
  "scope_type": "SERVICE",
  "scope_reference": "patient-service",
  "assessment_period": "2026-Q3",
  "target_level": 3,
  "dimensions": [
    "ARCHITECTURE",
    "LOGGING",
    "METRICS",
    "TRACING",
    "ALERTING",
    "SLO_PERFORMANCE",
    "SECURITY_PRIVACY",
    "COST"
  ]
}
```

---

### 21. Cost Budget Create Request

```json
{
  "budget_code": "OBS-PATIENT-SERVICE-2026-07",
  "scope_type": "SERVICE",
  "scope_reference": "patient-service",
  "period": "2026-07",
  "currency": "IDR",
  "budget_amount": 15000000,
  "warning_threshold": 0.8,
  "critical_threshold": 1.0,
  "owner": "patient_service_owner"
}
```

---

### 22. Canonical Success Envelope

```json
{
  "data": {},
  "meta": {
    "request_id": "01J...",
    "generated_at": "2026-07-04T12:00:00Z",
    "classification": "INTERNAL"
  }
}
```

---

### 23. Canonical Error Envelope

```json
{
  "error": {
    "code": "GOV_POLICY_BLOCKED",
    "message": "The governance policy evaluation failed.",
    "details": [
      {
        "policy_code": "OBS_ALERT_RUNBOOK_REQUIRED",
        "reason": "Active SEV1 alert does not reference an active runbook."
      }
    ]
  },
  "meta": {
    "request_id": "01J...",
    "timestamp": "2026-07-04T12:00:00Z"
  }
}
```

---

### 24. HTTP Status Mapping

| Kondisi | HTTP |
|---|---:|
| success | 200 |
| created | 201 |
| accepted async | 202 |
| validation | 422 |
| unauthenticated | 401 |
| forbidden | 403 |
| not found | 404 |
| conflict | 409 |
| expired | 410 |
| rate limited | 429 |
| unavailable | 503 |
| unexpected | 500 |

---

### 25. Controller Responsibilities

Controller hanya:

- parse request;
- validate DTO;
- resolve tenant/scope;
- authorize;
- call application service;
- map exception;
- project response;
- create governance audit context.

Controller tidak boleh:

- menghitung maturity langsung;
- mengeksekusi SQL;
- approve tanpa approval service;
- mem-bypass policy engine;
- mem-bypass exception scope;
- mengubah historical approval;
- mengakses evidence restricted tanpa projector;
- menutup corrective action tanpa verification.

---

### 26. CatalogController Example

```php
final class CatalogController
{
    public function __construct(
        private readonly GovernanceCatalogServiceInterface $catalogs,
        private readonly GovernanceContextFactoryInterface $contexts,
        private readonly CatalogProjector $projector
    ) {
    }

    public function create(
        HttpRequest $request,
        string $catalogType
    ): HttpResponse {
        $context = $this->contexts->fromRequest($request);

        $entry = $this->catalogs->create(
            catalogType: $catalogType,
            command: CatalogCreateCommand::fromArray(
                $request->json()
            ),
            context: $context
        );

        return JsonResponse::created(
            $this->projector->entry($entry)
        );
    }
}
```

---

### 27. PolicyController Example

```php
final class PolicyController
{
    public function __construct(
        private readonly GovernancePolicyServiceInterface $policies,
        private readonly GovernanceContextFactoryInterface $contexts,
        private readonly PolicyProjector $projector
    ) {
    }

    public function evaluate(
        HttpRequest $request
    ): HttpResponse {
        $context = $this->contexts->fromRequest($request);

        $result = $this->policies->evaluate(
            PolicyEvaluationCommand::fromArray(
                $request->json()
            ),
            $context
        );

        return JsonResponse::ok(
            $this->projector->evaluation($result)
        );
    }
}
```

---

### 28. ReviewController Example

```php
final class ReviewController
{
    public function __construct(
        private readonly GovernanceReviewServiceInterface $reviews,
        private readonly GovernanceContextFactoryInterface $contexts,
        private readonly ReviewProjector $projector
    ) {
    }

    public function approve(
        HttpRequest $request,
        string $reviewId
    ): HttpResponse {
        $context = $this->contexts->fromRequest($request);

        $review = $this->reviews->approve(
            reviewId: $reviewId,
            command: ReviewDecisionCommand::fromArray(
                $request->json()
            ),
            context: $context
        );

        return JsonResponse::ok(
            $this->projector->review($review)
        );
    }
}
```

---

### 29. ExceptionController Example

```php
final class ExceptionController
{
    public function __construct(
        private readonly GovernanceExceptionServiceInterface $exceptions,
        private readonly GovernanceContextFactoryInterface $contexts,
        private readonly ExceptionProjector $projector
    ) {
    }

    public function extend(
        HttpRequest $request,
        string $exceptionId
    ): HttpResponse {
        $context = $this->contexts->fromRequest($request);

        $exception = $this->exceptions->extend(
            exceptionId: $exceptionId,
            command: ExceptionExtensionCommand::fromArray(
                $request->json()
            ),
            context: $context
        );

        return JsonResponse::ok(
            $this->projector->exception($exception)
        );
    }
}
```

---

### 30. MaturityController Example

```php
final class MaturityController
{
    public function __construct(
        private readonly MaturityAssessmentServiceInterface $maturity,
        private readonly GovernanceContextFactoryInterface $contexts,
        private readonly MaturityProjector $projector
    ) {
    }

    public function calculate(
        HttpRequest $request,
        string $assessmentId
    ): HttpResponse {
        $context = $this->contexts->fromRequest($request);

        $assessment = $this->maturity->calculate(
            assessmentId: $assessmentId,
            context: $context
        );

        return JsonResponse::ok(
            $this->projector->assessment($assessment)
        );
    }
}
```

---

### 31. CostController Example

```php
final class CostController
{
    public function __construct(
        private readonly GovernanceCostServiceInterface $costs,
        private readonly GovernanceContextFactoryInterface $contexts,
        private readonly CostProjector $projector
    ) {
    }

    public function allocate(
        HttpRequest $request
    ): HttpResponse {
        $context = $this->contexts->fromRequest($request);

        $result = $this->costs->allocate(
            CostAllocationCommand::fromArray(
                $request->json()
            ),
            $context
        );

        return JsonResponse::accepted(
            $this->projector->allocation($result)
        );
    }
}
```

---

### 32. Application Service Contracts

#### Catalog Service

```php
interface GovernanceCatalogServiceInterface
{
    public function create(
        string $catalogType,
        CatalogCreateCommand $command,
        GovernanceContext $context
    ): GovernanceCatalogEntry;

    public function update(
        string $catalogType,
        string $artifactCode,
        CatalogUpdateCommand $command,
        GovernanceContext $context
    ): GovernanceCatalogEntry;

    public function activate(
        string $catalogType,
        string $artifactCode,
        GovernanceContext $context
    ): GovernanceCatalogEntry;
}
```

---

### 33. Policy Service

```php
interface GovernancePolicyServiceInterface
{
    public function register(
        PolicyCreateCommand $command,
        GovernanceContext $context
    ): GovernancePolicy;

    public function evaluate(
        PolicyEvaluationCommand $command,
        GovernanceContext $context
    ): GovernancePolicyEvaluation;

    public function compatibility(
        string $policyCode,
        array $candidateDefinition,
        GovernanceContext $context
    ): PolicyCompatibilityResult;
}
```

---

### 34. Review Service

```php
interface GovernanceReviewServiceInterface
{
    public function create(
        ReviewCreateCommand $command,
        GovernanceContext $context
    ): GovernanceReview;

    public function submit(
        string $reviewId,
        GovernanceContext $context
    ): GovernanceReview;

    public function approve(
        string $reviewId,
        ReviewDecisionCommand $command,
        GovernanceContext $context
    ): GovernanceReview;
}
```

---

### 35. Approval Service

```php
interface GovernanceApprovalServiceInterface
{
    public function request(
        ApprovalRequestCommand $command,
        GovernanceContext $context
    ): GovernanceApproval;

    public function decide(
        string $approvalId,
        ApprovalDecisionCommand $command,
        GovernanceContext $context
    ): GovernanceApproval;
}
```

---

### 36. Exception Service

```php
interface GovernanceExceptionServiceInterface
{
    public function create(
        ExceptionCreateCommand $command,
        GovernanceContext $context
    ): GovernanceException;

    public function approve(
        string $exceptionId,
        GovernanceContext $context
    ): GovernanceException;

    public function extend(
        string $exceptionId,
        ExceptionExtensionCommand $command,
        GovernanceContext $context
    ): GovernanceException;
}
```

---

### 37. Maturity Service

```php
interface MaturityAssessmentServiceInterface
{
    public function create(
        MaturityAssessmentCreateCommand $command,
        GovernanceContext $context
    ): MaturityAssessment;

    public function calculate(
        string $assessmentId,
        GovernanceContext $context
    ): MaturityAssessment;

    public function approve(
        string $assessmentId,
        GovernanceContext $context
    ): MaturityAssessment;
}
```

---

### 38. Cost Governance Service

```php
interface GovernanceCostServiceInterface
{
    public function importLedger(
        CostLedgerImportCommand $command,
        GovernanceContext $context
    ): CostImportResult;

    public function allocate(
        CostAllocationCommand $command,
        GovernanceContext $context
    ): CostAllocationResult;

    public function forecast(
        CostForecastCommand $command,
        GovernanceContext $context
    ): CostForecast;
}
```

---

### 39. Dashboard Service

```php
interface GovernanceDashboardServiceInterface
{
    public function overview(
        GovernanceDashboardCriteria $criteria,
        GovernanceContext $context
    ): GovernanceOverview;

    public function maturity(
        GovernanceDashboardCriteria $criteria,
        GovernanceContext $context
    ): MaturityDashboard;

    public function costs(
        GovernanceDashboardCriteria $criteria,
        GovernanceContext $context
    ): CostDashboard;
}
```

---

### 40. Middleware Order

```text
Request ID
→ Trusted Proxy
→ Security Headers
→ Authentication
→ Rate Limit
→ Tenant Context
→ Active Scope
→ Permission
→ Classification
→ CSRF
→ Governance Context
→ Controller
```

---

### 41. Authentication

Semua endpoint internal membutuhkan authenticated principal.

Service account wajib:

- identity;
- scoped permission;
- rotation;
- audit.

---

### 42. Tenant Context

Tenant-specific governance wajib memakai tenant context valid.

Cross-tenant assessment/report memerlukan permission khusus.

---

### 43. Active Scope

Jika berlaku:

```text
organization_id
clinic_id
facility_id
scope_id
```

harus divalidasi sebelum review, exception, maturity, cost, atau evidence export.

---

### 44. Permission Middleware

Permissions utama:

```text
observability.governance.catalog.read
observability.governance.catalog.manage
observability.governance.policy.read
observability.governance.policy.manage
observability.governance.review.read
observability.governance.review.manage
observability.governance.review.approve
observability.governance.approval.read
observability.governance.approval.manage
observability.governance.exception.read
observability.governance.exception.manage
observability.governance.exception.approve
observability.governance.maturity.read
observability.governance.maturity.assess
observability.governance.maturity.approve
observability.governance.evidence.read
observability.governance.evidence.manage
observability.governance.cost.read
observability.governance.cost.manage
observability.governance.report.read
observability.governance.report.export
observability.governance.cross_tenant.read
```

---

### 45. Classification Middleware

Projector harus membatasi:

```text
INTERNAL
CONFIDENTIAL
RESTRICTED
SECURITY_RESTRICTED
LEGAL_HOLD
```

---

### 46. CSRF

Mutation berbasis session wajib CSRF:

- catalog create/update;
- policy create/update;
- review mutation;
- approval decision;
- exception mutation;
- maturity approval;
- evidence export;
- budget mutation;
- report export.

---

### 47. Rate Limiting

Rekomendasi awal:

| Endpoint | Limit |
|---|---:|
| catalog read | 120/min/user |
| catalog mutation | 30/hour/user |
| policy evaluate | 120/min/user |
| review mutation | 60/hour/user |
| approval decision | 30/hour/user |
| exception mutation | 30/hour/user |
| maturity calculate | 20/hour/user |
| evidence export | 10/hour/user |
| cost allocation | 20/hour/user |
| report generation | 20/hour/user |

---

### 48. Query Guard

Semua query wajib memiliki:

```text
time range where applicable
row limit
tenant/scope
classification permission
timeout
purpose
```

---

### 49. Review Guard

Review mutation wajib:

- valid state transition;
- assigned reviewer;
- no self-approval where prohibited;
- required evidence present;
- unresolved critical findings handled.

---

### 50. Approval Guard

Approval wajib:

- approver role valid;
- distinct approver count;
- artifact snapshot hash;
- conditions captured;
- no requestor self-approval if four-eyes required.

---

### 51. Exception Guard

Exception wajib:

- policy exists;
- risk assessed;
- scope bounded;
- expiry present;
- compensating control;
- approval;
- active evidence.

---

### 52. Maturity Guard

Assessment tidak dapat approved jika:

- insufficient evidence;
- missing critical dimension;
- scoring formula unknown;
- assessor conflict;
- unresolved critical findings.

---

### 53. Cost Guard

Cost mutation wajib:

- period valid;
- currency valid;
- allocation method valid;
- source ledger present;
- budget owner valid.

---

### 54. Scheduler Architecture

```text
Scheduler
    │
    ├── Review Due Check
    ├── Exception Expiry Check
    ├── Policy Evaluation
    ├── Owner Coverage Check
    ├── Scorecard Refresh
    ├── Maturity Evidence Collection
    ├── Cost Allocation
    ├── Cost Forecast
    ├── Corrective Action Overdue Check
    ├── Evidence Expiry Check
    ├── Report Generation
    ├── Audit Integrity Verification
    └── Reconciliation
```

---

### 55. Required Scheduler Jobs

```text
governance-review-due-check
governance-exception-expiry-check
governance-policy-evaluate
governance-owner-coverage-check
governance-scorecard-refresh
governance-maturity-evidence-collect
governance-cost-allocate
governance-cost-forecast
governance-action-overdue-check
governance-evidence-expiry-check
governance-report-monthly
governance-audit-verify
governance-reconcile
```

---

### 56. Scheduler Frequency

| Job | Frequency |
|---|---:|
| Review due check | daily |
| Exception expiry | hourly |
| Policy evaluate | on change + daily |
| Owner coverage | daily |
| Scorecard refresh | hourly/daily |
| Maturity evidence | daily |
| Cost allocation | daily/monthly |
| Cost forecast | daily |
| Action overdue | daily |
| Evidence expiry | daily |
| Monthly report | monthly |
| Audit verify | hourly/daily |
| Reconciliation | hourly |

---

### 57. Job Locking

Lock keys:

```text
gov-review-due:{date}
gov-exception-expiry:{hour}
gov-policy:{policy_code}:{scope}
gov-scorecard:{scope}:{period}
gov-maturity:{assessment_id}
gov-cost:{period}:{scope}
gov-report:{type}:{period}
gov-audit:{chain_id}
```

---

### 58. Job Idempotency

Keys:

```text
review_id + reminder_window
exception_id + expiry_event
policy_code + artifact_hash
scorecard_scope + period + calculation_version
assessment_id + evidence_version
cost_scope + period + allocation_version
report_type + period + scope
```

---

### 59. Policy Evaluation Engine

Flow:

```text
Load active policies
→ Resolve artifact
→ Resolve valid exception
→ Evaluate conditions
→ Produce result
→ Persist evaluation
→ Emit audit/metric
→ Block or warn
```

---

### 60. Policy Engine Contract

```php
interface GovernancePolicyEngineInterface
{
    public function evaluate(
        GovernanceArtifact $artifact,
        PolicyEvaluationContext $context
    ): PolicyEvaluationBatchResult;
}
```

---

### 61. Review Engine

Flow:

```text
Create review
→ Assign reviewers
→ Collect evidence
→ Record findings
→ Validate approval rules
→ Decide
→ Schedule next review
```

---

### 62. Review Engine Contract

```php
interface GovernanceReviewEngineInterface
{
    public function transition(
        GovernanceReview $review,
        ReviewTransitionCommand $command,
        GovernanceContext $context
    ): GovernanceReview;
}
```

---

### 63. Approval Workflow

```text
REQUESTED
→ PENDING_APPROVAL
→ APPROVED/REJECTED
→ CONDITIONALLY_VALID
→ EXPIRED/REVOKED
```

---

### 64. Approval Workflow Contract

```php
interface GovernanceApprovalWorkflowInterface
{
    public function request(
        ApprovalRequest $request
    ): GovernanceApproval;

    public function decide(
        GovernanceApproval $approval,
        ApprovalDecision $decision,
        GovernanceContext $context
    ): GovernanceApproval;
}
```

---

### 65. Exception Workflow

```text
DRAFT
→ SUBMITTED
→ RISK_REVIEW
→ APPROVED
→ ACTIVE
→ REVIEW
→ CLOSED/EXPIRED
```

---

### 66. Maturity Calculation Engine

Flow:

```text
Load scoring model
→ Load dimensions
→ Load evidence
→ Validate freshness
→ Calculate raw scores
→ Apply evidence weights
→ Apply critical floors
→ Calculate overall
→ Persist history
```

---

### 67. Maturity Calculator Contract

```php
interface MaturityCalculatorInterface
{
    public function calculate(
        MaturityAssessmentInput $input
    ): MaturityCalculationResult;
}
```

---

### 68. Cost Allocation Engine

Flow:

```text
Load ledger
→ Validate period
→ Group usage
→ Apply allocation method
→ Apply shared cost
→ Persist allocations
→ Compare budget
→ Detect anomaly
```

---

### 69. Cost Allocation Contract

```php
interface CostAllocationEngineInterface
{
    public function allocate(
        CostAllocationInput $input
    ): CostAllocationResult;
}
```

---

### 70. Dashboard Assembly

```php
final class GovernanceDashboardService
{
    public function overview(
        GovernanceDashboardCriteria $criteria,
        GovernanceContext $context
    ): GovernanceOverview {
        return GovernanceOverview::create(
            policyCompliance: $this->policies->summary(
                $criteria,
                $context
            ),
            overdueReviews: $this->reviews->overdueSummary(
                $criteria,
                $context
            ),
            exceptions: $this->exceptions->summary(
                $criteria,
                $context
            ),
            maturity: $this->maturity->summary(
                $criteria,
                $context
            ),
            quality: $this->scorecards->summary(
                $criteria,
                $context
            ),
            costs: $this->costs->summary(
                $criteria,
                $context
            ),
            actions: $this->actions->summary(
                $criteria,
                $context
            )
        );
    }
}
```

---

### 71. Database Schema Overview

Tables:

```text
governance_catalog_entries
governance_catalog_versions
governance_policies
governance_policy_evaluations
governance_reviews
governance_review_assignments
governance_review_findings
governance_review_decisions
governance_approvals
governance_approval_conditions
governance_exceptions
governance_exception_events
governance_exception_extensions
governance_maturity_assessments
governance_maturity_dimensions
governance_maturity_evidence
governance_scorecards
governance_cost_ledger
governance_cost_adjustments
governance_budgets
governance_cost_forecasts
governance_corrective_actions
governance_evidence
governance_chain_of_custody
governance_reports
governance_scheduler_runs
governance_reconciliation_runs
```

---

### 72. Table: governance_catalog_entries

```sql
CREATE TABLE governance_catalog_entries (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    catalog_type VARCHAR(80) NOT NULL,
    artifact_code VARCHAR(180) NOT NULL,
    current_version VARCHAR(20) NOT NULL,
    name VARCHAR(255) NOT NULL,
    owner_reference VARCHAR(180) NOT NULL,
    classification VARCHAR(40) NOT NULL,
    status VARCHAR(30) NOT NULL DEFAULT 'DRAFT',
    effective_from DATETIME(6) NULL,
    review_due_at DATETIME(6) NULL,
    created_by BIGINT UNSIGNED NOT NULL,
    updated_by BIGINT UNSIGNED NULL,
    created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    updated_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6)
        ON UPDATE CURRENT_TIMESTAMP(6),

    PRIMARY KEY (id),
    UNIQUE KEY uq_governance_catalog_artifact (
        catalog_type,
        artifact_code
    ),
    KEY idx_governance_catalog_status (
        catalog_type,
        status
    ),
    KEY idx_governance_catalog_review (
        review_due_at,
        status
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

### 73. Table: governance_catalog_versions

```sql
CREATE TABLE governance_catalog_versions (
    id CHAR(26) NOT NULL,
    catalog_entry_id BIGINT UNSIGNED NOT NULL,
    artifact_version VARCHAR(20) NOT NULL,
    content_json JSON NOT NULL,
    content_hash CHAR(64) NOT NULL,
    status VARCHAR(30) NOT NULL,
    effective_from DATETIME(6) NULL,
    created_by BIGINT UNSIGNED NOT NULL,
    created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),

    PRIMARY KEY (id),
    UNIQUE KEY uq_governance_catalog_version (
        catalog_entry_id,
        artifact_version
    ),
    CONSTRAINT fk_governance_catalog_version_entry
        FOREIGN KEY (catalog_entry_id)
        REFERENCES governance_catalog_entries (id)
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

### 74. Table: governance_policies

```sql
CREATE TABLE governance_policies (
    id CHAR(26) NOT NULL,
    policy_code VARCHAR(180) NOT NULL,
    policy_version VARCHAR(20) NOT NULL,
    category VARCHAR(80) NOT NULL,
    severity VARCHAR(30) NOT NULL,
    scope_json JSON NOT NULL,
    definition_json JSON NOT NULL,
    definition_hash CHAR(64) NOT NULL,
    owner_reference VARCHAR(180) NOT NULL,
    status VARCHAR(30) NOT NULL DEFAULT 'DRAFT',
    effective_from DATETIME(6) NULL,
    deprecated_at DATETIME(6) NULL,
    created_by BIGINT UNSIGNED NOT NULL,
    created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),

    PRIMARY KEY (id),
    UNIQUE KEY uq_governance_policy_version (
        policy_code,
        policy_version
    ),
    KEY idx_governance_policy_active (
        category,
        status,
        effective_from
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

### 75. Table: governance_policy_evaluations

```sql
CREATE TABLE governance_policy_evaluations (
    id CHAR(26) NOT NULL,
    policy_code VARCHAR(180) NOT NULL,
    policy_version VARCHAR(20) NOT NULL,
    artifact_type VARCHAR(80) NOT NULL,
    artifact_reference VARCHAR(255) NOT NULL,
    artifact_hash CHAR(64) NULL,
    result VARCHAR(30) NOT NULL,
    severity VARCHAR(30) NOT NULL,
    message VARCHAR(2000) NULL,
    evidence_json JSON NULL,
    exception_reference CHAR(26) NULL,
    evaluated_at DATETIME(6) NOT NULL,
    evaluator_version VARCHAR(100) NOT NULL,
    created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),

    PRIMARY KEY (id),
    KEY idx_policy_evaluation_artifact (
        artifact_type,
        artifact_reference,
        evaluated_at
    ),
    KEY idx_policy_evaluation_result (
        result,
        severity,
        evaluated_at
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

### 76. Table: governance_reviews

```sql
CREATE TABLE governance_reviews (
    id CHAR(26) NOT NULL,
    artifact_type VARCHAR(80) NOT NULL,
    artifact_reference VARCHAR(255) NOT NULL,
    review_type VARCHAR(80) NOT NULL,
    requestor_reference VARCHAR(180) NOT NULL,
    risk_level VARCHAR(30) NOT NULL,
    due_at DATETIME(6) NOT NULL,
    status VARCHAR(30) NOT NULL DEFAULT 'DRAFT',
    submitted_at DATETIME(6) NULL,
    closed_at DATETIME(6) NULL,
    next_review_at DATETIME(6) NULL,
    created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    updated_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6)
        ON UPDATE CURRENT_TIMESTAMP(6),

    PRIMARY KEY (id),
    KEY idx_governance_review_due (
        status,
        due_at
    ),
    KEY idx_governance_review_artifact (
        artifact_type,
        artifact_reference
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

### 77. Table: governance_review_assignments

```sql
CREATE TABLE governance_review_assignments (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    review_id CHAR(26) NOT NULL,
    reviewer_reference VARCHAR(180) NOT NULL,
    reviewer_role VARCHAR(100) NOT NULL,
    assigned_at DATETIME(6) NOT NULL,
    responded_at DATETIME(6) NULL,
    decision VARCHAR(30) NULL,

    PRIMARY KEY (id),
    UNIQUE KEY uq_review_assignment (
        review_id,
        reviewer_reference,
        reviewer_role
    ),
    CONSTRAINT fk_review_assignment_review
        FOREIGN KEY (review_id)
        REFERENCES governance_reviews (id)
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

### 78. Table: governance_review_findings

```sql
CREATE TABLE governance_review_findings (
    id CHAR(26) NOT NULL,
    review_id CHAR(26) NOT NULL,
    severity VARCHAR(30) NOT NULL,
    category VARCHAR(80) NOT NULL,
    description VARCHAR(3000) NOT NULL,
    recommendation VARCHAR(3000) NULL,
    owner_reference VARCHAR(180) NOT NULL,
    due_date DATE NULL,
    status VARCHAR(30) NOT NULL DEFAULT 'OPEN',
    verification_evidence_id CHAR(26) NULL,
    resolved_at DATETIME(6) NULL,
    created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),

    PRIMARY KEY (id),
    KEY idx_review_finding_status (
        review_id,
        status,
        severity
    ),
    CONSTRAINT fk_review_finding_review
        FOREIGN KEY (review_id)
        REFERENCES governance_reviews (id)
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

### 79. Table: governance_review_decisions

```sql
CREATE TABLE governance_review_decisions (
    id CHAR(26) NOT NULL,
    review_id CHAR(26) NOT NULL,
    decision VARCHAR(30) NOT NULL,
    decision_reason VARCHAR(3000) NULL,
    decided_by VARCHAR(180) NOT NULL,
    decided_at DATETIME(6) NOT NULL,
    conditions_json JSON NULL,
    artifact_snapshot_hash CHAR(64) NOT NULL,

    PRIMARY KEY (id),
    KEY idx_review_decision_review (
        review_id,
        decided_at
    ),
    CONSTRAINT fk_review_decision_review
        FOREIGN KEY (review_id)
        REFERENCES governance_reviews (id)
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

### 80. Table: governance_approvals

```sql
CREATE TABLE governance_approvals (
    id CHAR(26) NOT NULL,
    approval_type VARCHAR(80) NOT NULL,
    artifact_type VARCHAR(80) NOT NULL,
    artifact_reference VARCHAR(255) NOT NULL,
    artifact_version VARCHAR(20) NULL,
    requestor_reference VARCHAR(180) NOT NULL,
    minimum_approvers INT UNSIGNED NOT NULL DEFAULT 1,
    status VARCHAR(30) NOT NULL DEFAULT 'REQUESTED',
    snapshot_hash CHAR(64) NOT NULL,
    requested_at DATETIME(6) NOT NULL,
    expires_at DATETIME(6) NULL,
    created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),

    PRIMARY KEY (id),
    KEY idx_governance_approval_artifact (
        artifact_type,
        artifact_reference
    ),
    KEY idx_governance_approval_status (
        status,
        requested_at
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

### 81. Table: governance_approval_conditions

```sql
CREATE TABLE governance_approval_conditions (
    id CHAR(26) NOT NULL,
    approval_id CHAR(26) NOT NULL,
    condition_text VARCHAR(3000) NOT NULL,
    owner_reference VARCHAR(180) NOT NULL,
    due_date DATE NULL,
    verification_method VARCHAR(1000) NULL,
    status VARCHAR(30) NOT NULL DEFAULT 'OPEN',
    verification_evidence_id CHAR(26) NULL,

    PRIMARY KEY (id),
    KEY idx_approval_condition_status (
        approval_id,
        status
    ),
    CONSTRAINT fk_approval_condition_approval
        FOREIGN KEY (approval_id)
        REFERENCES governance_approvals (id)
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

### 82. Table: governance_exceptions

```sql
CREATE TABLE governance_exceptions (
    id CHAR(26) NOT NULL,
    policy_code VARCHAR(180) NOT NULL,
    artifact_reference VARCHAR(255) NOT NULL,
    scope_json JSON NOT NULL,
    scope_hash CHAR(64) NOT NULL,
    reason VARCHAR(3000) NOT NULL,
    risk_level VARCHAR(30) NOT NULL,
    business_impact VARCHAR(3000) NULL,
    compensating_control VARCHAR(3000) NOT NULL,
    owner_reference VARCHAR(180) NOT NULL,
    status VARCHAR(30) NOT NULL DEFAULT 'DRAFT',
    effective_from DATETIME(6) NULL,
    expires_at DATETIME(6) NOT NULL,
    created_by VARCHAR(180) NOT NULL,
    created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    updated_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6)
        ON UPDATE CURRENT_TIMESTAMP(6),

    PRIMARY KEY (id),
    KEY idx_governance_exception_active (
        policy_code,
        status,
        expires_at
    ),
    KEY idx_governance_exception_owner (
        owner_reference,
        status
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

### 83. Table: governance_exception_events

```sql
CREATE TABLE governance_exception_events (
    id CHAR(26) NOT NULL,
    exception_id CHAR(26) NOT NULL,
    event_type VARCHAR(50) NOT NULL,
    actor_reference VARCHAR(180) NOT NULL,
    reason VARCHAR(3000) NULL,
    occurred_at DATETIME(6) NOT NULL,
    metadata_json JSON NULL,

    PRIMARY KEY (id),
    KEY idx_exception_event_history (
        exception_id,
        occurred_at
    ),
    CONSTRAINT fk_exception_event_exception
        FOREIGN KEY (exception_id)
        REFERENCES governance_exceptions (id)
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

### 84. Table: governance_maturity_assessments

```sql
CREATE TABLE governance_maturity_assessments (
    id CHAR(26) NOT NULL,
    scope_type VARCHAR(50) NOT NULL,
    scope_reference VARCHAR(255) NOT NULL,
    assessment_period VARCHAR(30) NOT NULL,
    target_level DECIMAL(4,2) NOT NULL,
    overall_score DECIMAL(5,2) NULL,
    overall_level DECIMAL(4,2) NULL,
    assessor_reference VARCHAR(180) NOT NULL,
    reviewer_reference VARCHAR(180) NULL,
    status VARCHAR(30) NOT NULL DEFAULT 'DRAFT',
    assessed_at DATETIME(6) NULL,
    approved_at DATETIME(6) NULL,
    calculation_version VARCHAR(100) NOT NULL,
    created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),

    PRIMARY KEY (id),
    UNIQUE KEY uq_maturity_scope_period (
        scope_type,
        scope_reference,
        assessment_period
    ),
    KEY idx_maturity_scope (
        scope_type,
        scope_reference,
        approved_at
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

### 85. Table: governance_maturity_dimensions

```sql
CREATE TABLE governance_maturity_dimensions (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    assessment_id CHAR(26) NOT NULL,
    dimension_code VARCHAR(100) NOT NULL,
    raw_score DECIMAL(5,2) NOT NULL,
    evidence_quality_weight DECIMAL(5,4) NOT NULL,
    adjusted_score DECIMAL(5,2) NOT NULL,
    target_score DECIMAL(5,2) NOT NULL,
    gap_score DECIMAL(5,2) NOT NULL,
    critical_floor_applied TINYINT(1) NOT NULL DEFAULT 0,
    notes VARCHAR(3000) NULL,

    PRIMARY KEY (id),
    UNIQUE KEY uq_maturity_dimension (
        assessment_id,
        dimension_code
    ),
    CONSTRAINT fk_maturity_dimension_assessment
        FOREIGN KEY (assessment_id)
        REFERENCES governance_maturity_assessments (id)
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

### 86. Table: governance_scorecards

```sql
CREATE TABLE governance_scorecards (
    id CHAR(26) NOT NULL,
    scope_type VARCHAR(50) NOT NULL,
    scope_reference VARCHAR(255) NOT NULL,
    scorecard_period VARCHAR(30) NOT NULL,
    completeness DECIMAL(6,2) NULL,
    freshness DECIMAL(6,2) NULL,
    accuracy DECIMAL(6,2) NULL,
    consistency DECIMAL(6,2) NULL,
    uniqueness_score DECIMAL(6,2) NULL,
    validity DECIMAL(6,2) NULL,
    traceability DECIMAL(6,2) NULL,
    overall_score DECIMAL(6,2) NULL,
    status VARCHAR(30) NOT NULL,
    calculation_version VARCHAR(100) NOT NULL,
    source_query_hash CHAR(64) NOT NULL,
    generated_at DATETIME(6) NOT NULL,

    PRIMARY KEY (id),
    UNIQUE KEY uq_scorecard_scope_period (
        scope_type,
        scope_reference,
        scorecard_period,
        calculation_version
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

### 87. Table: governance_cost_ledger

```sql
CREATE TABLE governance_cost_ledger (
    id CHAR(26) NOT NULL,
    ledger_period VARCHAR(30) NOT NULL,
    cost_center VARCHAR(100) NOT NULL,
    service_code VARCHAR(120) NULL,
    module_code VARCHAR(120) NULL,
    tenant_id BIGINT UNSIGNED NULL,
    signal_category VARCHAR(80) NOT NULL,
    usage_quantity DECIMAL(18,4) NOT NULL,
    usage_unit VARCHAR(50) NOT NULL,
    unit_cost DECIMAL(18,6) NOT NULL,
    allocated_cost DECIMAL(18,2) NOT NULL,
    allocation_method VARCHAR(50) NOT NULL,
    currency CHAR(3) NOT NULL,
    source_reference VARCHAR(255) NOT NULL,
    source_hash CHAR(64) NOT NULL,
    created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),

    PRIMARY KEY (id),
    KEY idx_cost_ledger_scope (
        ledger_period,
        service_code,
        signal_category
    ),
    KEY idx_cost_ledger_tenant (
        ledger_period,
        tenant_id
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

### 88. Table: governance_budgets

```sql
CREATE TABLE governance_budgets (
    id CHAR(26) NOT NULL,
    budget_code VARCHAR(180) NOT NULL,
    scope_type VARCHAR(50) NOT NULL,
    scope_reference VARCHAR(255) NOT NULL,
    budget_period VARCHAR(30) NOT NULL,
    currency CHAR(3) NOT NULL,
    budget_amount DECIMAL(18,2) NOT NULL,
    warning_threshold DECIMAL(5,4) NOT NULL,
    critical_threshold DECIMAL(5,4) NOT NULL,
    owner_reference VARCHAR(180) NOT NULL,
    status VARCHAR(30) NOT NULL DEFAULT 'ACTIVE',
    created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    updated_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6)
        ON UPDATE CURRENT_TIMESTAMP(6),

    PRIMARY KEY (id),
    UNIQUE KEY uq_governance_budget (
        budget_code,
        budget_period
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

### 89. Table: governance_evidence

```sql
CREATE TABLE governance_evidence (
    id CHAR(26) NOT NULL,
    evidence_type VARCHAR(80) NOT NULL,
    source VARCHAR(180) NOT NULL,
    artifact_reference VARCHAR(255) NOT NULL,
    content_reference VARCHAR(1000) NOT NULL,
    checksum CHAR(64) NOT NULL,
    classification VARCHAR(40) NOT NULL,
    owner_reference VARCHAR(180) NOT NULL,
    collected_at DATETIME(6) NOT NULL,
    valid_until DATETIME(6) NULL,
    retention_policy_code VARCHAR(180) NOT NULL,
    legal_hold_status VARCHAR(30) NOT NULL DEFAULT 'NONE',
    status VARCHAR(30) NOT NULL DEFAULT 'ACTIVE',
    created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),

    PRIMARY KEY (id),
    KEY idx_governance_evidence_artifact (
        artifact_reference,
        collected_at
    ),
    KEY idx_governance_evidence_expiry (
        valid_until,
        status
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

### 90. Table: governance_corrective_actions

```sql
CREATE TABLE governance_corrective_actions (
    id CHAR(26) NOT NULL,
    source_type VARCHAR(80) NOT NULL,
    source_reference VARCHAR(255) NOT NULL,
    description VARCHAR(3000) NOT NULL,
    owner_reference VARCHAR(180) NOT NULL,
    priority VARCHAR(30) NOT NULL,
    due_date DATE NULL,
    status VARCHAR(30) NOT NULL DEFAULT 'OPEN',
    evidence_required TINYINT(1) NOT NULL DEFAULT 1,
    verification_method VARCHAR(1000) NULL,
    verification_evidence_id CHAR(26) NULL,
    verified_by VARCHAR(180) NULL,
    verified_at DATETIME(6) NULL,
    closed_at DATETIME(6) NULL,
    created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),

    PRIMARY KEY (id),
    KEY idx_corrective_action_due (
        status,
        due_date
    ),
    KEY idx_corrective_action_owner (
        owner_reference,
        status
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

### 91. Repository Contracts

```php
interface GovernanceCatalogRepositoryInterface
{
    public function save(
        GovernanceCatalogEntry $entry
    ): void;

    public function findActive(
        string $catalogType,
        string $artifactCode,
        \DateTimeImmutable $at
    ): ?GovernanceCatalogEntry;
}
```

---

### 92. Policy Repository Contract

```php
interface GovernancePolicyRepositoryInterface
{
    public function findActiveFor(
        GovernanceArtifact $artifact,
        \DateTimeImmutable $at
    ): array;

    public function saveEvaluation(
        GovernancePolicyEvaluation $evaluation
    ): void;
}
```

---

### 93. Review Repository Contract

```php
interface GovernanceReviewRepositoryInterface
{
    public function save(
        GovernanceReview $review
    ): void;

    public function findById(
        string $reviewId
    ): ?GovernanceReview;

    public function findOverdue(
        \DateTimeImmutable $at
    ): array;
}
```

---

### 94. Exception Repository Contract

```php
interface GovernanceExceptionRepositoryInterface
{
    public function findActiveFor(
        string $policyCode,
        GovernanceScope $scope,
        \DateTimeImmutable $at
    ): ?GovernanceException;

    public function save(
        GovernanceException $exception
    ): void;
}
```

---

### 95. Maturity Repository Contract

```php
interface MaturityAssessmentRepositoryInterface
{
    public function save(
        MaturityAssessment $assessment
    ): void;

    public function history(
        string $scopeType,
        string $scopeReference
    ): array;
}
```

---

### 96. Audit Integration

Privileged governance actions wajib menghasilkan audit.

Contoh:

```text
OBS_GOV_CATALOG_ENTRY_CREATED
OBS_GOV_CATALOG_ENTRY_ACTIVATED
OBS_GOV_POLICY_ACTIVATED
OBS_GOV_REVIEW_APPROVED
OBS_GOV_APPROVAL_GRANTED
OBS_GOV_EXCEPTION_APPROVED
OBS_GOV_EXCEPTION_EXTENDED
OBS_GOV_MATURITY_APPROVED
OBS_GOV_BUDGET_UPDATED
OBS_GOV_EVIDENCE_EXPORTED
OBS_GOV_CI_GATE_OVERRIDDEN
```

---

### 97. Structured Logging

```json
{
  "event_code": "GOV_POLICY_EVALUATION_FAILED",
  "level": "ERROR",
  "message": "Governance policy evaluation failed.",
  "policy_code": "OBS_ALERT_RUNBOOK_REQUIRED",
  "artifact_reference": "alert:patient-api-latency",
  "result": "FAIL",
  "correlation_id": "01J...",
  "classification": "INTERNAL"
}
```

---

### 98. Metrics

```text
governance_api_request_total
governance_api_error_total
governance_catalog_total
governance_policy_evaluation_total
governance_policy_failure_total
governance_review_overdue_total
governance_exception_active_total
governance_exception_expired_total
governance_maturity_score
governance_scorecard_status_total
governance_cost_variance_ratio
governance_evidence_expired_total
governance_action_overdue_total
governance_audit_integrity_failure_total
```

---

### 99. Alert Candidates

```text
critical_policy_failure
review_overdue_critical
exception_expired
exception_compensating_control_missing
maturity_critical_floor_breached
evidence_integrity_failed
evidence_expired_critical
cost_budget_critical
critical_corrective_action_overdue
governance_audit_chain_broken
governance_reconciliation_failed
```

---

### 100. Error Codes

```text
GOV_CATALOG_ENTRY_NOT_FOUND
GOV_CATALOG_ENTRY_CONFLICT
GOV_CATALOG_VERSION_INVALID
GOV_POLICY_NOT_FOUND
GOV_POLICY_EVALUATION_FAILED
GOV_POLICY_BLOCKED
GOV_REVIEW_NOT_FOUND
GOV_REVIEW_STATE_INVALID
GOV_REVIEW_APPROVAL_RULE_FAILED
GOV_APPROVAL_NOT_FOUND
GOV_APPROVAL_SELF_APPROVAL_DENIED
GOV_APPROVAL_CONDITION_UNMET
GOV_EXCEPTION_NOT_FOUND
GOV_EXCEPTION_EXPIRED
GOV_EXCEPTION_SCOPE_MISMATCH
GOV_EXCEPTION_EVIDENCE_MISSING
GOV_MATURITY_ASSESSMENT_NOT_FOUND
GOV_MATURITY_EVIDENCE_INSUFFICIENT
GOV_MATURITY_CRITICAL_FLOOR_APPLIED
GOV_EVIDENCE_NOT_FOUND
GOV_EVIDENCE_INTEGRITY_FAILED
GOV_COST_LEDGER_INVALID
GOV_COST_BUDGET_EXCEEDED
GOV_REPORT_GENERATION_FAILED
CROSS_TENANT_ACCESS_DENIED
```

---

### 101. Security Controls

Framework wajib:

- no historical approval update;
- no exception without expiry;
- no maturity approval without evidence;
- no closed corrective action without verification;
- tenant/scope enforcement;
- classification enforcement;
- CSRF untuk mutation;
- rate limiting;
- four-eyes for critical actions;
- evidence export control;
- non-public evidence storage;
- audit privileged actions;
- cross-tenant read restricted;
- no secret/PHI in governance metadata unless required and protected.

---

### 102. Four-Eyes Enforcement

Direkomendasikan untuk:

- critical exception;
- audit retention change;
- SLO downgrade;
- restricted evidence export;
- policy severity downgrade;
- CI/CD gate override;
- cost budget override above threshold.

---

### 103. Projector Masking

Projector dapat menyembunyikan:

- restricted evidence reference;
- reviewer identity where policy requires;
- security findings;
- legal hold metadata;
- cross-tenant cost details;
- internal object location;
- signing key reference.

---

### 104. Apache/XAMPP Virtual Host

```apache
<VirtualHost *:80>
    ServerName platform.local
    DocumentRoot "D:/xampp/htdocs/platform/public"

    <Directory "D:/xampp/htdocs/platform/public">
        AllowOverride All
        Require all granted
        Options -Indexes
    </Directory>

    <Directory "D:/xampp/htdocs/platform/storage/governance-evidence">
        Require all denied
        Options -Indexes
    </Directory>

    <Directory "D:/xampp/htdocs/platform/storage/governance-reports">
        Require all denied
        Options -Indexes
    </Directory>

    ErrorLog "logs/platform-error.log"
    CustomLog "logs/platform-access.log" combined
</VirtualHost>
```

---

### 105. `.htaccess`

```apache
RewriteEngine On

RewriteCond %{REQUEST_FILENAME} -f [OR]
RewriteCond %{REQUEST_FILENAME} -d
RewriteRule ^ - [L]

RewriteRule ^ index.php [QSA,L]
```

---

### 106. Route Registration

```php
$router->group('/api/internal/v1/governance', [
    'middleware' => [
        RequestIdMiddleware::class,
        AuthenticationMiddleware::class,
        RateLimitMiddleware::class,
        TenantContextMiddleware::class,
        ActiveScopeMiddleware::class,
        GovernanceClassificationMiddleware::class,
        GovernanceContextMiddleware::class,
    ],
], function ($router): void {
    $router->get('/catalogs/{catalogType}', [
        CatalogController::class,
        'index',
    ]);

    $router->post('/catalogs/{catalogType}', [
        CatalogController::class,
        'create',
    ]);

    $router->post('/policies/evaluate', [
        PolicyController::class,
        'evaluate',
    ]);

    $router->post('/reviews', [
        ReviewController::class,
        'create',
    ]);

    $router->post('/reviews/{reviewId}/approve', [
        ReviewController::class,
        'approve',
    ]);

    $router->post('/exceptions/{exceptionId}/extend', [
        ExceptionController::class,
        'extend',
    ]);

    $router->post('/maturity/assessments/{assessmentId}/calculate', [
        MaturityController::class,
        'calculate',
    ]);

    $router->post('/costs/allocate', [
        CostController::class,
        'allocate',
    ]);
});
```

---

### 107. CLI Commands

```bash
php bin/console governance:review:check-due
php bin/console governance:exception:expire
php bin/console governance:policy:evaluate
php bin/console governance:owner:coverage
php bin/console governance:scorecard:refresh
php bin/console governance:maturity:collect-evidence
php bin/console governance:cost:allocate
php bin/console governance:cost:forecast
php bin/console governance:action:check-overdue
php bin/console governance:evidence:check-expiry
php bin/console governance:report:monthly
php bin/console governance:audit:verify
php bin/console governance:reconcile
```

---

### 108. Sequence Diagram — Policy Evaluation

```mermaid
sequenceDiagram
    participant CI
    participant API
    participant Policy
    participant Catalog
    participant Exception
    participant Store
    participant Audit

    CI->>API: Evaluate artifact
    API->>Catalog: Load artifact metadata
    Catalog-->>API: Artifact
    API->>Policy: Load active policies
    Policy->>Exception: Resolve valid exception
    Exception-->>Policy: Exception/None
    Policy->>Policy: Evaluate conditions
    Policy->>Store: Save evaluation
    Policy->>Audit: Record blocking override if used
    Policy-->>API: PASS/WARN/FAIL
    API-->>CI: Gate result
```

---

### 109. Sequence Diagram — Review and Approval

```mermaid
sequenceDiagram
    participant Requestor
    participant API
    participant Review
    participant Evidence
    participant Approver
    participant Audit

    Requestor->>API: Create review
    API->>Review: Validate artifact and reviewers
    Review->>Evidence: Check required evidence
    Evidence-->>Review: Evidence status
    Review->>Approver: Assign decision
    Approver->>Review: Approve/Reject
    Review->>Audit: Record decision
    Review-->>API: Review result
    API-->>Requestor: Approved/Changes required
```

---

### 110. Sequence Diagram — Exception Lifecycle

```mermaid
sequenceDiagram
    participant Owner
    participant API
    participant Exception
    participant Risk
    participant Approval
    participant Scheduler
    participant Audit

    Owner->>API: Request exception
    API->>Exception: Validate policy and scope
    Exception->>Risk: Assess risk
    Risk-->>Exception: Risk result
    Exception->>Approval: Request approval
    Approval-->>Exception: Approved
    Exception->>Audit: Record activation
    Scheduler->>Exception: Check expiry
    alt Expired
        Exception->>Audit: Record expiry
    end
```

---

### 111. Sequence Diagram — Maturity Assessment

```mermaid
sequenceDiagram
    participant Assessor
    participant API
    participant Maturity
    participant Evidence
    participant Calculator
    participant Reviewer
    participant Audit

    Assessor->>API: Create assessment
    API->>Maturity: Initialize dimensions
    Maturity->>Evidence: Collect valid evidence
    Evidence-->>Maturity: Evidence set
    Maturity->>Calculator: Calculate scores
    Calculator-->>Maturity: Dimension and overall scores
    Maturity->>Reviewer: Submit for approval
    Reviewer-->>Maturity: Approved
    Maturity->>Audit: Record assessment approval
```

---

### 112. Sequence Diagram — Cost Allocation

```mermaid
sequenceDiagram
    participant Scheduler
    participant Cost
    participant Ledger
    participant Budget
    participant Alert
    participant Report

    Scheduler->>Cost: Allocate period
    Cost->>Ledger: Load usage and cost rows
    Ledger-->>Cost: Ledger data
    Cost->>Cost: Apply allocation method
    Cost->>Budget: Compare budget
    Budget-->>Cost: Threshold status
    alt Critical variance
        Cost->>Alert: Create cost alert
    end
    Cost->>Report: Save allocation summary
```

---

### 113. Sequence Diagram — Evidence Export

```mermaid
sequenceDiagram
    participant User
    participant API
    participant Access
    participant Evidence
    participant Workspace
    participant Audit

    User->>API: Request evidence export
    API->>Access: Check permission/classification
    Access-->>API: Allowed
    API->>Evidence: Resolve evidence and checksum
    Evidence->>Workspace: Build encrypted package
    Workspace-->>API: Expiring reference
    API->>Audit: Record export
    API-->>User: Export reference
```

---

### 114. Performance Targets

| Operation | Target |
|---|---:|
| Catalog lookup | < 100 ms |
| Policy lookup | < 100 ms |
| Policy evaluation | < 150 ms typical |
| Exception validation | < 50 ms |
| Review list | < 500 ms |
| Approval lookup | < 100 ms |
| Maturity calculate | < 10 s typical scope |
| Scorecard dashboard | < 1.5 s |
| Cost allocation enqueue | < 500 ms |
| Governance overview | < 1.5 s |
| Evidence export enqueue | < 500 ms |

---

### 115. Testing Strategy

#### Unit

- catalog validation;
- policy evaluation;
- exception scope;
- review transition;
- four-eyes;
- maturity calculation;
- critical floor;
- cost allocation;
- budget threshold;
- projector masking.

#### Integration

- PDO repositories;
- review + approval workflow;
- exception expiry;
- policy evaluation persistence;
- maturity history;
- scorecard generation;
- cost ledger import;
- evidence export;
- audit chain;
- routing.

#### Security

- cross-tenant access;
- restricted evidence;
- self-approval;
- expired exception;
- forged owner/reviewer;
- CSRF;
- rate limit;
- public evidence path;
- classification leakage.

---

### 116. UAT Part 4

#### Catalog & Policy API

- [ ] Catalog list bekerja.
- [ ] Version history tersedia.
- [ ] Duplicate code/version ditolak.
- [ ] Policy create/update bekerja.
- [ ] Policy test bekerja.
- [ ] Policy evaluation tersimpan.
- [ ] Blocking policy memblokir.
- [ ] Valid exception dapat digunakan.

#### Review & Approval

- [ ] Review create/submit bekerja.
- [ ] Assignment bekerja.
- [ ] Findings bekerja.
- [ ] Approval rules bekerja.
- [ ] Four-eyes bekerja.
- [ ] Self-approval ditolak.
- [ ] Conditional approval bekerja.
- [ ] Review history immutable.

#### Exceptions

- [ ] Exception create bekerja.
- [ ] Risk review bekerja.
- [ ] Approval bekerja.
- [ ] Extension membuat history baru.
- [ ] Expired exception invalid.
- [ ] Scope mismatch ditolak.
- [ ] Compensating evidence wajib.
- [ ] Expiry scheduler bekerja.

#### Maturity & Scorecards

- [ ] Assessment create bekerja.
- [ ] Evidence collection bekerja.
- [ ] Weighted score dihitung.
- [ ] Critical floor diterapkan.
- [ ] Approval bekerja.
- [ ] Trend tersedia.
- [ ] Gap tersedia.
- [ ] Scorecard refresh bekerja.
- [ ] UNKNOWN tidak dianggap GREEN.

#### Cost Governance

- [ ] Ledger import bekerja.
- [ ] Duplicate source ditolak.
- [ ] Allocation method bekerja.
- [ ] Budget comparison bekerja.
- [ ] Forecast bekerja.
- [ ] Cost anomaly tersedia.
- [ ] Cross-tenant detail dibatasi.
- [ ] Adjustment diaudit.

#### Evidence & Reports

- [ ] Evidence upload/register bekerja.
- [ ] Checksum verify bekerja.
- [ ] Expiry status bekerja.
- [ ] Restricted export dikontrol.
- [ ] Chain of custody tersedia.
- [ ] Monthly report bekerja.
- [ ] Maturity report reproducible.
- [ ] Cost report reproducible.

#### Scheduler

- [ ] Review due job berjalan.
- [ ] Exception expiry job berjalan.
- [ ] Policy evaluation job berjalan.
- [ ] Owner coverage job berjalan.
- [ ] Scorecard refresh job berjalan.
- [ ] Cost allocation job berjalan.
- [ ] Evidence expiry job berjalan.
- [ ] Audit verification berjalan.
- [ ] Reconciliation berjalan.
- [ ] Lock/idempotency bekerja.

#### Database

- [ ] Migration berhasil.
- [ ] Unique constraints aktif.
- [ ] Historical versions tidak tertimpa.
- [ ] Review decision append-only.
- [ ] Exception history lengkap.
- [ ] Assessment history immutable.
- [ ] Cost ledger immutable.
- [ ] Evidence references valid.
- [ ] Index mendukung query utama.

#### Security

- [ ] Tenant/scope isolation bekerja.
- [ ] Cross-tenant permission bekerja.
- [ ] Classification masking bekerja.
- [ ] CSRF aktif.
- [ ] Rate limit aktif.
- [ ] Evidence folder tidak public.
- [ ] Four-eyes enforced.
- [ ] Privileged mutation diaudit.
- [ ] No secret/PHI leakage.

#### Apache/XAMPP

- [ ] Front controller bekerja.
- [ ] Evidence folder blocked.
- [ ] Report folder blocked.
- [ ] Directory listing nonaktif.
- [ ] Internal routes bekerja.
- [ ] Error log tersedia.

---

### 117. Anti-Pattern

Hindari:

- controller menghitung maturity;
- approval hanya boolean mutable;
- exception tanpa event history;
- policy evaluation tidak disimpan;
- evidence export ke public folder;
- cost ledger dapat diedit langsung;
- scorecard tanpa calculation version;
- CI gate bypass tanpa audit;
- review tanpa artifact snapshot;
- maturity approved tanpa evidence;
- one credential for all governance workers;
- cross-tenant dashboard tanpa masking;
- scheduler tanpa lock;
- report tanpa source hash.

---

### 118. Definition of Done Part 4

Part 4 dianggap selesai bila:

- [ ] HTTP API catalog tersedia;
- [ ] request/response contracts tersedia;
- [ ] controller standard tersedia;
- [ ] application service contracts tersedia;
- [ ] middleware order tersedia;
- [ ] permission model tersedia;
- [ ] classification enforcement tersedia;
- [ ] review/approval/exception guards tersedia;
- [ ] scheduler architecture tersedia;
- [ ] policy evaluation engine tersedia;
- [ ] review engine tersedia;
- [ ] approval workflow tersedia;
- [ ] exception workflow tersedia;
- [ ] maturity calculator tersedia;
- [ ] cost allocation engine tersedia;
- [ ] dashboard assembly tersedia;
- [ ] database schema tersedia;
- [ ] repository contracts tersedia;
- [ ] audit integration tersedia;
- [ ] metrics dan alerts tersedia;
- [ ] error codes tersedia;
- [ ] security controls tersedia;
- [ ] Apache/XAMPP routing tersedia;
- [ ] sequence diagrams tersedia;
- [ ] UAT tersedia.

---

### 119. Rencana Part Berikutnya

#### Part 5

Reference implementation, sample policies, sample maturity assessment, sample scorecards and budgets, migration, deployment, rollback, simulations, operational runbooks, final UAT, Definition of Done, roadmap, dan merge guidance menjadi `SSOT-OBS-11.md`.

---

## Bagian V — Reference Implementation, Sample Policies, Maturity Assessment, Scorecards, Budgets, Deployment, Simulation, Final UAT & Operational Readiness

### 1. Executive Summary

Part 5 menutup rangkaian SSOT-OBS-11 dengan reference implementation untuk Observability Governance & Maturity Framework.

Bagian ini mencakup:

- bootstrap wiring;
- sample governance catalogs;
- sample policy-as-code;
- review dan approval workflow;
- exception lifecycle;
- maturity assessment;
- data quality scorecards;
- evidence validation;
- cost budget dan allocation;
- scheduler wiring;
- migration;
- deployment;
- rollback;
- simulations;
- operational runbooks;
- final UAT;
- Definition of Done;
- roadmap;
- merge guidance menjadi `SSOT-OBS-11.md`.

Target implementasi awal adalah governance platform yang:

- memiliki catalog terstruktur;
- memiliki policy yang dapat dievaluasi;
- memiliki review dan approval formal;
- mengelola exception dengan expiry;
- menghitung maturity berdasarkan evidence;
- memantau kualitas observability;
- mengalokasikan biaya telemetry;
- mendukung CI/CD quality gates;
- tenant/scope-aware;
- dapat diaudit dan dipulihkan.

---

### 2. Initial Implementation Scope

Initial release wajib mencakup:

```text
Governance Catalog
Policy Registry
Policy Evaluation Engine
Review Workflow
Approval Workflow
Exception Lifecycle
Maturity Assessment Engine
Evidence Registry
Data Quality Scorecard
Cost Budget
Cost Allocation
Governance Dashboard
Scheduler
Audit Integration
```

Initial governance domains:

```text
ARCHITECTURE
LOGGING
METRICS
TRACING
HEALTH
DASHBOARD
ALERTING
INCIDENT
RETENTION
PERFORMANCE
SIGNALS
SECURITY
COST
MATURITY
```

---

### 3. Final Folder Structure

```text
app/
└── Platform/
    └── Observability/
        └── Governance/
            ├── Domain/
            │   ├── GovernanceCatalogEntry.php
            │   ├── GovernancePolicy.php
            │   ├── GovernancePolicyEvaluation.php
            │   ├── GovernanceReview.php
            │   ├── GovernanceApproval.php
            │   ├── GovernanceException.php
            │   ├── MaturityAssessment.php
            │   ├── GovernanceScorecard.php
            │   ├── GovernanceEvidence.php
            │   ├── GovernanceBudget.php
            │   └── GovernanceCostLedgerEntry.php
            ├── Application/
            │   ├── GovernanceCatalogService.php
            │   ├── GovernancePolicyService.php
            │   ├── GovernanceReviewService.php
            │   ├── GovernanceApprovalService.php
            │   ├── GovernanceExceptionService.php
            │   ├── MaturityAssessmentService.php
            │   ├── GovernanceScorecardService.php
            │   ├── GovernanceEvidenceService.php
            │   ├── GovernanceCostService.php
            │   ├── GovernanceDashboardService.php
            │   └── Contracts/
            ├── Infrastructure/
            │   ├── Persistence/
            │   ├── Policy/
            │   ├── Workflow/
            │   ├── Evidence/
            │   ├── Scheduler/
            │   ├── Audit/
            │   └── Reporting/
            └── Presentation/
                ├── Http/
                └── Cli/

config/
├── governance-catalogs.php
├── governance-policies.php
├── governance-maturity.php
├── governance-scorecards.php
├── governance-costs.php
└── governance-scheduler.php

database/
└── migrations/
    └── create_observability_governance_tables.sql

resources/
├── governance/
│   ├── policies/
│   ├── scorecards/
│   ├── reports/
│   └── runbooks/
└── governance-evidence/

storage/
├── governance-evidence/
├── governance-reports/
└── governance-exports/

tests/
├── Unit/
├── Integration/
└── Uat/

tools/
├── governance-policy-validate.php
├── governance-maturity-calculate.php
├── governance-scorecard-refresh.php
├── governance-cost-allocate.php
├── governance-exception-expiry.php
└── governance-reconcile.php
```

---

### 4. Bootstrap Wiring

```php
<?php

declare(strict_types=1);

namespace App\Platform\Observability\Governance;

final class GovernanceBootstrap
{
    public static function build(
        array $config,
        object $container
    ): GovernanceKernel {
        $catalogRegistry = new GovernanceCatalogRegistry();
        $policyRegistry = new GovernancePolicyRegistry();
        $maturityModelRegistry = new MaturityModelRegistry();

        foreach ($config['catalog_registrars'] as $registrarClass) {
            $container->get($registrarClass)->register($catalogRegistry);
        }

        foreach ($config['policy_registrars'] as $registrarClass) {
            $container->get($registrarClass)->register($policyRegistry);
        }

        foreach ($config['maturity_model_registrars'] as $registrarClass) {
            $container->get($registrarClass)->register($maturityModelRegistry);
        }

        return new GovernanceKernel(
            catalogs: $catalogRegistry,
            policies: $container->get('governance.policy_service'),
            reviews: $container->get('governance.review_service'),
            approvals: $container->get('governance.approval_service'),
            exceptions: $container->get('governance.exception_service'),
            maturity: $container->get('governance.maturity_service'),
            scorecards: $container->get('governance.scorecard_service'),
            evidence: $container->get('governance.evidence_service'),
            costs: $container->get('governance.cost_service'),
            dashboards: $container->get('governance.dashboard_service')
        );
    }
}
```

---

### 5. Sample Governance Catalogs

#### 5.1 Logging Capability

```php
return [
    'catalog_type' => 'CAPABILITY',
    'artifact_code' => 'OBS_LOGGING',
    'artifact_version' => '1.0',
    'name' => 'Structured Logging',
    'owner' => 'platform_operations',
    'classification' => 'INTERNAL',
    'status' => 'ACTIVE',
    'effective_from' => '2026-07-01',
    'review_due_at' => '2026-10-01',
    'content' => [
        'current_maturity' => 2.5,
        'target_maturity' => 3.0,
        'criticality' => 'HIGH',
        'standard_reference' => 'SSOT-OBS-02',
    ],
];
```

#### 5.2 Critical Alert

```php
return [
    'catalog_type' => 'ALERT',
    'artifact_code' => 'PATIENT_API_SLO_BURN_CRITICAL',
    'artifact_version' => '1.0',
    'name' => 'Patient API Critical SLO Burn',
    'owner' => 'patient_service_owner',
    'classification' => 'INTERNAL',
    'status' => 'ACTIVE',
    'effective_from' => '2026-07-01',
    'review_due_at' => '2026-08-01',
    'content' => [
        'severity' => 'SEV1',
        'runbook_reference' => 'RB-PATIENT-SLO-BURN',
        'routing_policy' => 'platform-oncall',
        'deduplication_key' => 'patient-api-slo-burn',
        'suppression_policy' => 'maintenance-aware',
    ],
];
```

#### 5.3 SLO Catalog Entry

```php
return [
    'catalog_type' => 'SLO',
    'artifact_code' => 'PATIENT_API_AVAILABILITY_999',
    'artifact_version' => '1.0',
    'name' => 'Patient API Availability 99.9%',
    'owner' => 'patient_service_owner',
    'classification' => 'INTERNAL',
    'status' => 'ACTIVE',
    'effective_from' => '2026-07-01',
    'review_due_at' => '2026-10-01',
    'content' => [
        'service_code' => 'patient-service',
        'sli_code' => 'patient_api_availability',
        'target' => 0.999,
        'window' => '30d',
        'business_owner' => 'clinical_operations',
        'error_budget_policy' => 'critical_api_standard',
    ],
];
```

---

### 6. Sample Policy-as-Code

#### 6.1 Owner Required

```yaml
policy_code: OBS_OWNER_REQUIRED
policy_version: "1.0"
category: OWNERSHIP
severity: BLOCKING
scope:
  artifact_type_in:
    - METRIC
    - ALERT
    - DASHBOARD
    - SLO
    - SIGNAL
require:
  owner_not_empty: true
owner: platform_architecture
status: ACTIVE
```

#### 6.2 Critical Alert Runbook

```yaml
policy_code: OBS_ALERT_RUNBOOK_REQUIRED
policy_version: "1.0"
category: ALERTING
severity: BLOCKING
scope:
  artifact_type: ALERT
  severity_in:
    - SEV1
    - SEV2
require:
  runbook_reference_not_empty: true
  runbook_status: ACTIVE
owner: platform_operations
status: ACTIVE
```

#### 6.3 Audit No Sampling

```yaml
policy_code: OBS_AUDIT_NO_SAMPLING
policy_version: "1.0"
category: SECURITY
severity: CRITICAL
scope:
  signal_category: AUDIT_RECORD
require:
  sampling_policy: NONE
owner: security_governance
status: ACTIVE
```

#### 6.4 Review Not Overdue

```yaml
policy_code: OBS_REVIEW_NOT_OVERDUE
policy_version: "1.0"
category: GOVERNANCE
severity: WARNING
scope:
  status: ACTIVE
require:
  review_due_at_gte: today
owner: observability_council
status: ACTIVE
```

#### 6.5 Restricted Storage

```yaml
policy_code: OBS_RESTRICTED_STORAGE_REQUIRED
policy_version: "1.0"
category: SECURITY
severity: BLOCKING
scope:
  classification_in:
    - RESTRICTED
    - SECURITY_RESTRICTED
require:
  storage_class_in:
    - RESTRICTED
    - ENCRYPTED
owner: security_governance
status: ACTIVE
```

---

### 7. Policy Evaluation Reference

```php
final class GovernancePolicyService
{
    public function evaluate(
        PolicyEvaluationCommand $command,
        GovernanceContext $context
    ): GovernancePolicyEvaluationBatch {
        $artifact = $this->artifacts->resolve(
            type: $command->artifactType,
            reference: $command->artifactReference
        );

        $policies = $this->policies->findActiveFor(
            artifact: $artifact,
            at: $this->clock->now()
        );

        $batch = new GovernancePolicyEvaluationBatch();

        foreach ($policies as $policy) {
            $exception = $this->exceptions->findActiveFor(
                policyCode: $policy->code,
                scope: $artifact->scope(),
                at: $this->clock->now()
            );

            $result = $this->engine->evaluate(
                policy: $policy,
                artifact: $artifact,
                exception: $exception
            );

            $evaluation = GovernancePolicyEvaluation::create(
                id: $this->ids->ulid(),
                policyCode: $policy->code,
                policyVersion: $policy->version,
                artifactType: $artifact->type(),
                artifactReference: $artifact->reference(),
                artifactHash: $artifact->hash(),
                result: $result->result,
                severity: $policy->severity,
                message: $result->message,
                evidence: $result->evidence,
                exceptionReference: $exception?->id,
                evaluatedAt: $this->clock->now(),
                evaluatorVersion: $this->engine->version()
            );

            $this->evaluations->save($evaluation);
            $batch->add($evaluation);
        }

        return $batch;
    }
}
```

---

### 8. Review and Approval Reference

```php
final class GovernanceReviewService
{
    public function create(
        ReviewCreateCommand $command,
        GovernanceContext $context
    ): GovernanceReview {
        $artifact = $this->artifacts->resolve(
            $command->artifactType,
            $command->artifactReference
        );

        $review = GovernanceReview::draft(
            id: $this->ids->ulid(),
            artifactType: $artifact->type(),
            artifactReference: $artifact->reference(),
            reviewType: $command->reviewType,
            requestorReference: $context->actorReference(),
            riskLevel: $command->riskLevel,
            dueAt: $command->dueAt,
            snapshotHash: $artifact->hash()
        );

        foreach ($command->reviewers as $reviewer) {
            $review->assign(
                reviewerReference: $reviewer->reference,
                reviewerRole: $reviewer->role,
                assignedAt: $this->clock->now()
            );
        }

        $this->reviews->save($review);

        return $review;
    }
}
```

```php
final class GovernanceApprovalService
{
    public function decide(
        string $approvalId,
        ApprovalDecisionCommand $command,
        GovernanceContext $context
    ): GovernanceApproval {
        $approval = $this->approvals->findById($approvalId);

        if ($approval === null) {
            throw new GovernanceApprovalNotFoundException();
        }

        $this->guard->assertCanDecide(
            approval: $approval,
            actor: $context->actorReference()
        );

        $approval->recordDecision(
            approverReference: $context->actorReference(),
            decision: $command->decision,
            reason: $command->reason,
            conditions: $command->conditions,
            decidedAt: $this->clock->now()
        );

        $this->approvals->save($approval);

        return $approval;
    }
}
```

---

### 9. Exception Service Reference

```php
final class GovernanceExceptionService
{
    public function approve(
        string $exceptionId,
        GovernanceContext $context
    ): GovernanceException {
        $exception = $this->exceptions->findById($exceptionId);

        if ($exception === null) {
            throw new GovernanceExceptionNotFoundException();
        }

        $this->guard->assertApprovable($exception, $context);

        $evidence = $this->evidence->findActiveFor(
            artifactReference: $exception->id,
            evidenceType: 'COMPENSATING_CONTROL'
        );

        if ($evidence === null) {
            throw new GovernanceExceptionEvidenceMissingException();
        }

        $exception->approve(
            approvedBy: $context->actorReference(),
            approvedAt: $this->clock->now()
        );

        $this->exceptions->save($exception);

        return $exception;
    }
}
```

---

### 10. Maturity Calculator Reference

```php
final class MaturityCalculator
    implements MaturityCalculatorInterface
{
    public function calculate(
        MaturityAssessmentInput $input
    ): MaturityCalculationResult {
        $dimensions = [];

        foreach ($input->dimensions as $dimension) {
            $raw = (
                $dimension->policyScore * 0.15
                + $dimension->implementationScore * 0.25
                + $dimension->coverageScore * 0.20
                + $dimension->evidenceScore * 0.15
                + $dimension->automationScore * 0.10
                + $dimension->effectivenessScore * 0.15
            );

            $adjusted = $raw * $dimension->evidenceQualityWeight;

            $dimensions[] = MaturityDimensionResult::create(
                code: $dimension->code,
                rawScore: round($raw, 2),
                adjustedScore: round($adjusted, 2),
                targetScore: $dimension->targetScore
            );
        }

        $overall = $this->weights->weightedAverage($dimensions);
        $overall = $this->floors->apply($overall, $dimensions);

        return MaturityCalculationResult::create(
            dimensions: $dimensions,
            overallScore: round($overall, 2),
            level: $this->levels->fromScore($overall)
        );
    }
}
```

---

### 11. Sample Maturity Assessment

Scope:

```text
SERVICE: patient-service
Period: 2026-Q3
Target: Level 3
```

| Dimension | Raw | Evidence Weight | Adjusted | Target |
|---|---:|---:|---:|---:|
| Architecture | 3.4 | 0.9 | 3.06 | 3.0 |
| Logging | 3.2 | 0.9 | 2.88 | 3.0 |
| Metrics | 3.5 | 0.9 | 3.15 | 3.0 |
| Tracing | 2.4 | 0.7 | 1.68 | 3.0 |
| Alerting | 3.0 | 0.9 | 2.70 | 3.0 |
| Incident | 2.8 | 0.9 | 2.52 | 3.0 |
| SLO/Performance | 3.1 | 0.9 | 2.79 | 3.0 |
| Security/Privacy | 3.5 | 1.0 | 3.50 | 3.0 |
| Retention | 3.0 | 0.9 | 2.70 | 3.0 |
| Cost | 2.0 | 0.7 | 1.40 | 2.5 |

Interpretasi:

- overall belum cukup untuk Level 3;
- tracing dan cost menjadi gap utama;
- evidence quality pada tracing dan cost masih rendah;
- action plan wajib dibuat.

---

### 12. Sample Maturity Action Plan

```text
ACT-OBS-001
Dimension: Tracing
Action: Implement trace context propagation in billing integration.
Owner: billing_team
Priority: HIGH
Due: 2026-09-30
Evidence: trace propagation report
```

```text
ACT-OBS-002
Dimension: Cost
Action: Enable per-service telemetry cost allocation.
Owner: platform_finops
Priority: MEDIUM
Due: 2026-10-15
Evidence: monthly cost allocation report
```

---

### 13. Data Quality Scorecard

```php
final class GovernanceScorecardService
{
    public function generate(
        ScorecardGenerateCommand $command,
        GovernanceContext $context
    ): GovernanceScorecard {
        $data = $this->qualityData->collect(
            scope: $command->scope,
            period: $command->period
        );

        $scores = [
            'completeness' => $this->quality->completeness($data),
            'freshness' => $this->quality->freshness($data),
            'accuracy' => $this->quality->accuracy($data),
            'consistency' => $this->quality->consistency($data),
            'uniqueness' => $this->quality->uniqueness($data),
            'validity' => $this->quality->validity($data),
            'traceability' => $this->quality->traceability($data),
        ];

        $overall = $this->quality->overall($scores);
        $status = $this->thresholds->status($overall);

        $scorecard = GovernanceScorecard::create(
            id: $this->ids->ulid(),
            scope: $command->scope,
            period: $command->period,
            scores: $scores,
            overallScore: $overall,
            status: $status,
            calculationVersion: $this->quality->version(),
            sourceQueryHash: $data->sourceHash(),
            generatedAt: $this->clock->now()
        );

        $this->scorecards->save($scorecard);

        return $scorecard;
    }
}
```

Sample:

| Dimension | Score |
|---|---:|
| Completeness | 98.5 |
| Freshness | 96.0 |
| Accuracy | 94.0 |
| Consistency | 97.0 |
| Uniqueness | 99.2 |
| Validity | 95.5 |
| Traceability | 92.0 |
| Overall | 96.0 |
| Status | GREEN |

---

### 14. Evidence Service Reference

```php
final class GovernanceEvidenceService
{
    public function register(
        EvidenceRegisterCommand $command,
        GovernanceContext $context
    ): GovernanceEvidence {
        $checksum = $this->checksums->sha256(
            $command->contentReference
        );

        $evidence = GovernanceEvidence::create(
            id: $this->ids->ulid(),
            evidenceType: $command->evidenceType,
            source: $command->source,
            artifactReference: $command->artifactReference,
            contentReference: $command->contentReference,
            checksum: $checksum,
            classification: $command->classification,
            ownerReference: $context->actorReference(),
            collectedAt: $this->clock->now(),
            validUntil: $command->validUntil,
            retentionPolicyCode: $command->retentionPolicyCode
        );

        $this->evidence->save($evidence);

        return $evidence;
    }
}
```

---

### 15. Cost Governance Reference

```php
final class GovernanceCostService
{
    public function allocate(
        CostAllocationCommand $command,
        GovernanceContext $context
    ): CostAllocationResult {
        $ledger = $this->ledger->findForPeriod(
            period: $command->period,
            scope: $command->scope
        );

        $method = $this->methods->resolve(
            $command->allocationMethod
        );

        $allocation = $method->allocate(
            ledger: $ledger,
            dimensions: $command->dimensions
        );

        foreach ($allocation->entries as $entry) {
            $this->allocations->save($entry);
        }

        $budget = $this->budgets->findFor(
            scope: $command->scope,
            period: $command->period
        );

        if ($budget !== null) {
            $allocation = $allocation->withBudgetStatus(
                $this->budgetEvaluator->evaluate(
                    budget: $budget,
                    actual: $allocation->totalCost
                )
            );
        }

        return $allocation;
    }
}
```

Sample budget:

```php
return [
    'budget_code' => 'OBS-PATIENT-SERVICE-2026-07',
    'scope_type' => 'SERVICE',
    'scope_reference' => 'patient-service',
    'period' => '2026-07',
    'currency' => 'IDR',
    'budget_amount' => 15_000_000,
    'warning_threshold' => 0.80,
    'critical_threshold' => 1.00,
    'owner' => 'patient_service_owner',
    'status' => 'ACTIVE',
];
```

Sample allocation:

| Signal Category | Usage | Cost |
|---|---:|---:|
| Logs | 500 GB | IDR 5.000.000 |
| Metrics | 12 million series-hours | IDR 4.000.000 |
| Traces | 50 million spans | IDR 3.500.000 |
| Archive | 1 TB-month | IDR 1.500.000 |
| Total |  | IDR 14.000.000 |

Budget usage:

```text
93.3%
Status: WARNING
```

---

### 16. Scheduler Wiring

```php
$scheduler->dailyAt('01:00', 'governance:review:check-due', GovernanceReviewDueCheckJob::class);
$scheduler->hourly('governance:exception:expire', GovernanceExceptionExpiryJob::class);
$scheduler->dailyAt('01:30', 'governance:policy:evaluate', GovernancePolicyEvaluationJob::class);
$scheduler->dailyAt('02:00', 'governance:owner:coverage', GovernanceOwnerCoverageJob::class);
$scheduler->hourly('governance:scorecard:refresh', GovernanceScorecardRefreshJob::class);
$scheduler->dailyAt('02:30', 'governance:maturity:collect-evidence', GovernanceMaturityEvidenceCollectionJob::class);
$scheduler->dailyAt('03:00', 'governance:cost:allocate', GovernanceCostAllocationJob::class);
$scheduler->dailyAt('03:30', 'governance:cost:forecast', GovernanceCostForecastJob::class);
$scheduler->dailyAt('04:00', 'governance:action:check-overdue', GovernanceCorrectiveActionOverdueJob::class);
$scheduler->dailyAt('04:30', 'governance:evidence:check-expiry', GovernanceEvidenceExpiryJob::class);
$scheduler->monthlyOn(1, '05:00', 'governance:report:monthly', GovernanceMonthlyReportJob::class);
$scheduler->hourly('governance:audit:verify', GovernanceAuditVerificationJob::class);
$scheduler->hourly('governance:reconcile', GovernanceReconciliationJob::class);
```

Windows Task Scheduler:

```bat
D:\xampp\php\php.exe D:\xampp\htdocs\platform\bin\console scheduler:run
```

---

### 17. Initial Migration Order

```text
1. governance_catalog_entries
2. governance_catalog_versions
3. governance_policies
4. governance_policy_evaluations
5. governance_reviews
6. governance_review_assignments
7. governance_review_findings
8. governance_review_decisions
9. governance_approvals
10. governance_approval_conditions
11. governance_exceptions
12. governance_exception_events
13. governance_exception_extensions
14. governance_maturity_assessments
15. governance_maturity_dimensions
16. governance_maturity_evidence
17. governance_scorecards
18. governance_cost_ledger
19. governance_cost_adjustments
20. governance_budgets
21. governance_cost_forecasts
22. governance_corrective_actions
23. governance_evidence
24. governance_chain_of_custody
25. governance_reports
26. governance_scheduler_runs
27. governance_reconciliation_runs
```

---

### 18. Seed Permissions

```text
observability.governance.catalog.read
observability.governance.catalog.manage
observability.governance.policy.read
observability.governance.policy.manage
observability.governance.review.read
observability.governance.review.manage
observability.governance.review.approve
observability.governance.approval.read
observability.governance.approval.manage
observability.governance.exception.read
observability.governance.exception.manage
observability.governance.exception.approve
observability.governance.maturity.read
observability.governance.maturity.assess
observability.governance.maturity.approve
observability.governance.evidence.read
observability.governance.evidence.manage
observability.governance.cost.read
observability.governance.cost.manage
observability.governance.report.read
observability.governance.report.export
observability.governance.cross_tenant.read
```

---

### 19. Role Mapping

| Role | Permission Utama |
|---|---|
| Governance Admin | catalog, policy, workflow |
| Platform Architect | standards, policy, approval |
| Security Admin | restricted/security governance |
| Compliance | audit, evidence, retention |
| Service Owner | service-level catalogs/reviews |
| Cost Analyst | ledger, budget, allocation |
| Reviewer | assigned reviews |
| Approver | scoped approval |
| Auditor | approved read-only |
| Executive | summary dashboard/report |

---

### 20. Deployment Checklist

#### Pre-Deployment

- [ ] Backup database tersedia.
- [ ] Migration direview.
- [ ] Catalog seed divalidasi.
- [ ] Policy definitions divalidasi.
- [ ] Policy test cases lulus.
- [ ] Review workflow disetujui.
- [ ] Approval roles tersedia.
- [ ] Exception policy tersedia.
- [ ] Maturity model divalidasi.
- [ ] Cost allocation method tersedia.
- [ ] Evidence storage aman.
- [ ] Permissions tersedia.
- [ ] Unit test lulus.
- [ ] Integration test lulus.
- [ ] Security review lulus.

#### Deployment

1. Deploy code.
2. Jalankan migration.
3. Seed permissions.
4. Register catalogs.
5. Register policies.
6. Register maturity model.
7. Register scorecard thresholds.
8. Register cost budgets.
9. Aktifkan policy evaluation dalam SHADOW.
10. Verifikasi review workflow.
11. Verifikasi exception expiry.
12. Verifikasi maturity calculation.
13. Verifikasi scorecard generation.
14. Verifikasi cost allocation.
15. Aktifkan audit dan scheduler.
16. Aktifkan CI/CD gates bertahap.

#### Post-Deployment

- [ ] Catalog tersedia.
- [ ] Policy evaluation berjalan.
- [ ] Review create/approve bekerja.
- [ ] Four-eyes bekerja.
- [ ] Exception expiry bekerja.
- [ ] Maturity assessment dapat dihitung.
- [ ] Scorecard tersedia.
- [ ] Cost report tersedia.
- [ ] Dashboard terisi.
- [ ] Audit dan alerts aktif.

---

### 21. Activation Strategy

```text
OFF
→ SHADOW
→ MONITOR
→ WARN
→ ENFORCE
```

- **SHADOW**: policy dievaluasi tanpa blocking.
- **MONITOR**: dashboard dan informational alert aktif.
- **WARN**: violation menghasilkan warning dan deadline.
- **ENFORCE**: blocking policy dan CI/CD gate aktif.

---

### 22. Rollback Plan

1. Ubah enforcement ke SHADOW.
2. Nonaktifkan blocking CI/CD gates.
3. Hentikan scheduler bermasalah.
4. Pertahankan historical records.
5. Rollback code.
6. Restore previous policy versions.
7. Restore previous maturity model.
8. Re-run policy validation.
9. Re-run reconciliation.
10. Re-enable dalam MONITOR mode.

Jangan menghapus approval, exception, maturity, evidence, atau audit history saat rollback.

---

### 23. Simulations

#### 23.1 Policy Pass

SEV1 alert dengan active runbook.

Expected:

```text
OBS_ALERT_RUNBOOK_REQUIRED = PASS
```

#### 23.2 Policy Fail

SEV1 alert tanpa runbook.

Expected:

```text
OBS_ALERT_RUNBOOK_REQUIRED = FAIL
```

Jika enforcement aktif, deployment diblokir.

#### 23.3 Valid Exception

Expected:

```text
PASS_WITH_EXCEPTION
```

Syarat:

- scope cocok;
- expiry belum lewat;
- compensating evidence aktif;
- audit tercatat.

#### 23.4 Expired Exception

Expected:

```text
GOV_EXCEPTION_EXPIRED
```

#### 23.5 Self-Approval

Expected:

```text
GOV_APPROVAL_SELF_APPROVAL_DENIED
```

#### 23.6 Four-Eyes

Critical exception membutuhkan dua approver berbeda.

#### 23.7 Review Overdue

Expected:

- escalation;
- KPI turun;
- warning/block sesuai policy.

#### 23.8 Critical Floor

Overall raw Level 3.4, Security score 1.8.

Expected:

```text
overall maximum = Level 2
```

#### 23.9 Insufficient Evidence

Expected:

```text
GOV_MATURITY_EVIDENCE_INSUFFICIENT
```

#### 23.10 Scorecard UNKNOWN

Source unavailable.

Expected:

- status UNKNOWN;
- tidak dianggap GREEN;
- alert data quality.

#### 23.11 Cost Budget Exceeded

Budget IDR 15.000.000, actual IDR 16.500.000.

Expected:

- utilization 110%;
- CRITICAL;
- cost alert;
- optimization review.

#### 23.12 Evidence Integrity Failure

Expected:

```text
GOV_EVIDENCE_INTEGRITY_FAILED
```

Dependent approvals/assessments ditandai dan export diblokir.

#### 23.13 Cross-Tenant Access

Expected:

```text
CROSS_TENANT_ACCESS_DENIED
```

#### 23.14 CI/CD Gate

New integration event harus memiliki catalog, schema, owner, retention, privacy classification, dan compatibility result.

#### 23.15 Reconciliation

Check:

```text
active policy → evaluation exists
active exception → approval exists
approved maturity → evidence exists
closed action → verification exists
```

---

### 24. Operational Runbooks

#### 24.1 Critical Policy Failure

1. Identifikasi policy dan artifact.
2. Validasi input.
3. Cek policy version.
4. Cek exception valid.
5. Cek owner.
6. Tentukan remediation.
7. Block change bila enforcement aktif.
8. Buat review/exception bila diperlukan.
9. Verifikasi setelah fix.
10. Tutup finding dengan evidence.

#### 24.2 Expired Exception

1. Identifikasi artifact/policy.
2. Cek expiry.
3. Cek remediation status.
4. Nonaktifkan exception.
5. Jalankan policy ulang.
6. Block change bila masih gagal.
7. Ajukan extension baru hanya bila justified.
8. Audit keputusan.
9. Update risk.
10. Monitor compensating control.

#### 24.3 Review Overdue

1. Cek owner/reviewer.
2. Cek criticality.
3. Kirim escalation.
4. Validasi evidence readiness.
5. Jadwalkan review.
6. Terapkan warning/block.
7. Catat reason keterlambatan.
8. Selesaikan findings.
9. Schedule next review.
10. Update KPI.

#### 24.4 Maturity Score Drop

1. Identifikasi dimension turun.
2. Cek evidence expiry.
3. Cek policy failure.
4. Cek incident/cost impact.
5. Cek calculation version.
6. Validasi data quality.
7. Buat action plan.
8. Tetapkan owner/due date.
9. Monitor progress.
10. Reassess setelah evidence baru.

#### 24.5 Evidence Integrity Failure

1. Mark evidence SUSPECT.
2. Block dependent approval/export.
3. Verify source copy.
4. Verify storage/transfer history.
5. Check chain of custody.
6. Create security incident.
7. Replace only via new evidence record.
8. Preserve suspect record.
9. Re-run dependent assessments.
10. Audit recovery.

#### 24.6 Cost Budget Exceeded

1. Identify scope dan signal category.
2. Cek usage anomaly.
3. Cek cardinality/log volume/trace sampling.
4. Cek business event.
5. Prioritaskan safe optimization.
6. Jangan kurangi audit/security evidence.
7. Buat cost action.
8. Implement optimization.
9. Verify savings dan quality.
10. Update forecast.

#### 24.7 Governance Platform Unavailable

1. Cek database/app health.
2. Aktifkan emergency fallback bila perlu.
3. Preserve offline approval evidence.
4. Block critical change tanpa approved fallback.
5. Restore platform.
6. Reconcile offline actions.
7. Verify audit chain.
8. Re-run policy gates.
9. Close fallback.
10. Document incident.

---

### 25. Backup & Restore

Backup wajib mencakup:

- catalogs;
- policies;
- evaluations;
- reviews;
- approvals;
- exceptions;
- maturity history;
- scorecards;
- evidence metadata;
- cost ledger;
- budgets;
- corrective actions;
- audit;
- reports;
- scheduler state.

Restore validation:

- catalog versions;
- policy hashes;
- approval links;
- exception states;
- maturity history;
- evidence checksums;
- cost ledger immutability;
- audit chain;
- report reproducibility;
- tenant isolation.

---

### 26. Performance Test Plan

```text
100.000 catalog entries
1.000 policies
1.000.000 policy evaluations/month
100.000 reviews
50.000 exceptions
10.000 maturity assessments
5.000.000 cost ledger rows
10.000 evidence objects
dashboard concurrent users
monthly report generation
```

Acceptance:

| Operation | Target |
|---|---:|
| Catalog lookup p95 | < 100 ms |
| Policy evaluation p95 | < 150 ms |
| Exception validation p95 | < 50 ms |
| Review list p95 | < 500 ms |
| Approval lookup p95 | < 100 ms |
| Maturity calculation | < 10 s typical |
| Scorecard dashboard p95 | < 1.5 s |
| Cost allocation enqueue | < 500 ms |
| Governance overview p95 | < 1.5 s |
| Evidence export enqueue | < 500 ms |

---

### 27. Final UAT

#### Catalogs & Policies

- [ ] Catalog registry aktif.
- [ ] Version history tersedia.
- [ ] Owner/review date wajib.
- [ ] Policies aktif.
- [ ] Policy test cases tersedia.
- [ ] Blocking policies memblokir.
- [ ] Warning policies tidak memblokir.
- [ ] Exceptions divalidasi.
- [ ] UNKNOWN tidak dianggap PASS.
- [ ] Policy changes diaudit.

#### Reviews & Approvals

- [ ] Review workflow aktif.
- [ ] Reviewer assignment bekerja.
- [ ] Findings tersedia.
- [ ] Four-eyes bekerja.
- [ ] Self-approval ditolak.
- [ ] Conditional approval bekerja.
- [ ] Snapshot hash tersedia.
- [ ] Approval history immutable.
- [ ] Review SLA dipantau.
- [ ] Next review otomatis.

#### Exceptions

- [ ] Exception memiliki expiry.
- [ ] Risk dan business impact wajib.
- [ ] Compensating control wajib.
- [ ] Evidence wajib.
- [ ] Scope match bekerja.
- [ ] Expiry otomatis invalid.
- [ ] Extension membuat history baru.
- [ ] Critical exception four-eyes.
- [ ] Closure memerlukan remediation evidence.
- [ ] Exception events diaudit.

#### Maturity & Scorecards

- [ ] Score 0–5 bekerja.
- [ ] Weighted formula bekerja.
- [ ] Evidence quality diterapkan.
- [ ] Critical floor bekerja.
- [ ] Gap dihitung.
- [ ] Action plan tersedia.
- [ ] Assessment history immutable.
- [ ] Scorecard refresh bekerja.
- [ ] UNKNOWN tidak GREEN.
- [ ] Trend tersedia.

#### Cost Governance

- [ ] Ledger import bekerja.
- [ ] Cost allocation reproducible.
- [ ] Budget mapping bekerja.
- [ ] Warning/critical threshold bekerja.
- [ ] Forecast tersedia.
- [ ] Anomaly terdeteksi.
- [ ] Adjustment history immutable.
- [ ] Cost optimization guard bekerja.
- [ ] Per-service report tersedia.
- [ ] Cross-tenant detail dibatasi.

#### Evidence & Reporting

- [ ] Evidence register bekerja.
- [ ] Checksum diverifikasi.
- [ ] Expiry state bekerja.
- [ ] Restricted access bekerja.
- [ ] Chain of custody tersedia.
- [ ] Monthly report reproducible.
- [ ] Maturity report reproducible.
- [ ] Exception report akurat.
- [ ] Cost report akurat.
- [ ] Export terenkripsi dan expire.

#### CI/CD Gates

- [ ] Catalog validation aktif.
- [ ] Policy evaluation aktif.
- [ ] Schema compatibility aktif.
- [ ] Security/privacy checks aktif.
- [ ] SLO gate aktif.
- [ ] Alert/runbook gate aktif.
- [ ] Exception reference divalidasi.
- [ ] Gate override diaudit.
- [ ] Critical gates fail-closed.
- [ ] Result tersimpan.

#### Scheduler & Recovery

- [ ] Review due job berjalan.
- [ ] Exception expiry job berjalan.
- [ ] Policy evaluation job berjalan.
- [ ] Scorecard job berjalan.
- [ ] Maturity evidence job berjalan.
- [ ] Cost allocation job berjalan.
- [ ] Evidence expiry job berjalan.
- [ ] Audit verification berjalan.
- [ ] Reconciliation berjalan.
- [ ] Job lock/idempotency bekerja.
- [ ] Backup/restore diuji.
- [ ] Emergency fallback diuji.
- [ ] Kill switch diuji.
- [ ] Rollback diuji.

---

### 28. Production Readiness Checklist

- [ ] Governance Council aktif.
- [ ] Owners tersedia.
- [ ] Catalogs tersedia.
- [ ] Policies tersedia.
- [ ] Review/approval workflow tersedia.
- [ ] Exception process tersedia.
- [ ] Maturity model tersedia.
- [ ] Scorecards tersedia.
- [ ] Evidence storage aman.
- [ ] Cost budgets tersedia.
- [ ] CI/CD gates tersedia.
- [ ] Dashboard tersedia.
- [ ] Alerts tersedia.
- [ ] Runbooks tersedia.
- [ ] Tenant isolation diuji.
- [ ] Security review lulus.
- [ ] Compliance review lulus.
- [ ] Performance test lulus.
- [ ] Restore test lulus.
- [ ] Operations sign-off tersedia.

---

### 29. Definition of Done — SSOT-OBS-11

#### Foundation

- [ ] governance model;
- [ ] council;
- [ ] operating model;
- [ ] ownership/RACI;
- [ ] quality gates;
- [ ] exception management;
- [ ] maturity levels.

#### Controls

- [ ] governance catalogs;
- [ ] policy-as-code;
- [ ] review workflow;
- [ ] approval workflow;
- [ ] exception lifecycle;
- [ ] maturity scoring;
- [ ] evidence requirements;
- [ ] scorecards;
- [ ] cost governance;
- [ ] CI/CD gates.

#### Persistence

- [ ] catalog/policy history;
- [ ] review/approval records;
- [ ] exception register;
- [ ] maturity history;
- [ ] cost ledger;
- [ ] evidence store;
- [ ] retention/legal hold;
- [ ] audit integrity;
- [ ] reporting;
- [ ] DR.

#### Infrastructure

- [ ] HTTP API;
- [ ] controllers;
- [ ] middleware;
- [ ] database schema;
- [ ] scheduler;
- [ ] policy engine;
- [ ] review engine;
- [ ] maturity service;
- [ ] cost APIs;
- [ ] dashboard;
- [ ] security/routing.

#### Operations

- [ ] reference implementation;
- [ ] sample catalogs;
- [ ] sample policies;
- [ ] sample maturity assessment;
- [ ] sample scorecards;
- [ ] sample budgets;
- [ ] deployment;
- [ ] rollback;
- [ ] simulations;
- [ ] runbooks;
- [ ] final UAT.

---

### 30. Roadmap

#### Phase 1 — Governance Foundation

- catalog registry;
- owner registry;
- policy evaluation basic;
- review workflow;
- exception register;
- basic dashboard.

#### Phase 2 — Managed Governance

- approval workflow;
- four-eyes;
- maturity assessment;
- evidence registry;
- scorecards;
- CI/CD warnings;
- cost budgets.

#### Phase 3 — Enterprise Governance

- CI/CD blocking gates;
- automated evidence collection;
- legal hold;
- immutable audit;
- cost allocation;
- cross-tenant governance;
- executive reporting.

#### Phase 4 — Optimized & Predictive

- policy-as-code automation;
- maturity trend prediction;
- cost anomaly detection;
- automated remediation suggestions;
- dynamic risk scoring;
- AI-assisted governance review;
- predictive compliance gaps.

---

### 31. Merge Guidance

Gabungkan:

```text
SSOT-OBS-11-Part-1.md
SSOT-OBS-11-Part-2.md
SSOT-OBS-11-Part-3.md
SSOT-OBS-11-Part-4.md
SSOT-OBS-11-Part-5.md
```

menjadi:

```text
SSOT-OBS-11.md
```

Urutan:

```text
Part 1 — Vision, Governance Model, Ownership, Maturity
Part 2 — Catalogs, Policy-as-Code, Workflows, Scoring, CI/CD
Part 3 — Storage, Evidence, Approvals, Cost, Retention, DR
Part 4 — API, Scheduler, Engines, Database, Dashboard
Part 5 — Reference Implementation & Operations
```

---

### 32. Merge Quality Checklist

- [ ] heading tidak duplikat;
- [ ] governance domains konsisten;
- [ ] catalog names konsisten;
- [ ] policy codes konsisten;
- [ ] review states konsisten;
- [ ] approval states konsisten;
- [ ] exception states konsisten;
- [ ] maturity formula konsisten;
- [ ] scorecard fields konsisten;
- [ ] cost fields konsisten;
- [ ] permission names konsisten;
- [ ] table names konsisten;
- [ ] namespace konsisten;
- [ ] endpoint konsisten;
- [ ] error codes konsisten;
- [ ] duplicate section dihapus;
- [ ] daftar isi dibuat;
- [ ] metadata final diperbarui;
- [ ] status final diset Review/Approved.

---

### 33. Final Metadata

```yaml
document_code: SSOT-OBS-11
title: Observability Governance & Maturity Framework
version: 1.0
status: Draft for Review
domain: Platform Kernel
category: Observability Governance
owners:
  - Platform Architecture
  - Platform Operations
  - Security
  - Compliance
reviewers:
  - Backend Engineering
  - Frontend Engineering
  - Service Owners
  - DevOps
  - QA
  - Data Governance
  - FinOps
```

---

### 34. Approval Gate

Dokumen dapat menjadi Approved setelah:

- architecture review;
- governance council review;
- ownership/RACI review;
- policy model review;
- review/approval workflow review;
- exception process review;
- maturity model review;
- evidence model review;
- cost governance review;
- CI/CD gate review;
- database schema review;
- security review;
- compliance review;
- QA/UAT review;
- performance review;
- deployment/rollback review;
- restore/reconciliation review;
- operations sign-off.

---

### 35. Closing Statement

Observability governance harus memastikan seluruh capability observability:

- memiliki owner;
- memiliki standard;
- memiliki evidence;
- memiliki review cadence;
- memiliki quality gate;
- memiliki maturity target;
- memiliki cost accountability;
- memiliki exception control;
- dapat diaudit;
- dapat ditingkatkan secara berkelanjutan.

Framework tidak boleh:

- menjadi dokumentasi pasif;
- menerima maturity tanpa evidence;
- membiarkan exception tanpa expiry;
- membiarkan approval tanpa segregation of duties;
- mengabaikan cost;
- menganggap UNKNOWN sebagai sehat;
- membiarkan CI/CD gate di-override tanpa audit;
- membiarkan artifact tanpa owner atau review date.

Framework harus mengubah observability dari sekumpulan tools menjadi operating capability enterprise yang terukur, terkelola, aman, efisien, dan dapat dipertanggungjawabkan.

---

## Lampiran A — Sumber Penggabungan

Dokumen final ini digabung dan dinormalisasi dari:

- `SSOT-OBS-11-Part-1.md`
- `SSOT-OBS-11-Part-2.md`
- `SSOT-OBS-11-Part-3.md`
- `SSOT-OBS-11-Part-4.md`
- `SSOT-OBS-11-Part-5.md`

## Lampiran B — Approval Gate

Status dokumen dapat diubah menjadi **Approved** setelah:

- architecture review selesai;
- governance council review selesai;
- ownership dan RACI review selesai;
- governance catalog review selesai;
- policy-as-code model review selesai;
- review dan approval workflow review selesai;
- exception lifecycle review selesai;
- maturity scoring model review selesai;
- evidence and scorecard review selesai;
- cost governance review selesai;
- CI/CD quality gate review selesai;
- database schema disetujui;
- permission dan tenant/scope policy disetujui;
- security review selesai;
- compliance review selesai;
- QA/UAT review selesai;
- performance review selesai;
- deployment dan rollback review selesai;
- restore dan reconciliation review selesai;
- operations sign-off tersedia.
