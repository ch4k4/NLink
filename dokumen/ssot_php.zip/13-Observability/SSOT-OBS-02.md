
# SSOT-OBS-02 — Structured Logging Standard

## Status

| Item | Nilai |
|---|---|
| Kode | SSOT-OBS-02 |
| Nama | Structured Logging Standard |
| Versi | 1.0 |
| Status | Draft Implementation Standard |
| Domain | Observability |
| Bergantung pada | SSOT-OBS-01, SSOT-AUDIT, SSOT-API, SSOT-CODE-01 |

---

# 1. Tujuan

Dokumen ini menetapkan standar logging terstruktur (structured logging) untuk seluruh Platform Kernel.

Logging digunakan untuk:

- troubleshooting;
- debugging;
- monitoring operasional;
- analisis performa;
- investigasi insiden.

Logging **bukan** pengganti Audit Trail dan **bukan** media komunikasi bisnis (Event).

---

# 2. Prinsip

- Machine-readable (JSON/structured).
- Konsisten di seluruh modul.
- Memiliki correlation_id.
- Aman (tidak membocorkan secret).
- Mudah dicari dan difilter.

---

# 3. Arsitektur

```text
HTTP Request
    │
    ▼
Middleware
    │
    ▼
Application
    │
    ├── Log
    ├── Audit
    ├── Event
    └── Metric
```

---

# 4. Level Log

| Level | Penggunaan |
|---|---|
| DEBUG | Detail teknis saat pengembangan |
| INFO | Aktivitas normal |
| NOTICE | Kejadian penting namun normal |
| WARNING | Potensi masalah |
| ERROR | Operasi gagal |
| CRITICAL | Gangguan layanan |

---

# 5. Format Wajib

Setiap log minimal memiliki:

- timestamp
- level
- message
- correlation_id
- request_id
- module
- action
- user_id (jika ada)
- tenant_id (jika ada)
- business_entity_id (jika ada)
- ip_address
- duration_ms (jika relevan)

Contoh:

```json
{
  "timestamp":"2026-07-04T10:00:00Z",
  "level":"INFO",
  "message":"Patient created",
  "module":"Patient",
  "action":"patient.create",
  "correlation_id":"c-123",
  "request_id":"r-456"
}
```

---

# 6. Naming Convention

Gunakan pola:

```text
domain.resource.action
```

Contoh:

- iam.login.success
- patient.created
- workflow.transition
- api.request
- integration.retry

---

# 7. Context

Context disimpan sebagai objek JSON.

Contoh:

```json
{
  "patient_id":103,
  "visit_id":55,
  "duration_ms":42
}
```

---

# 8. Larangan

Jangan pernah mencatat:

- password
- OTP
- refresh token
- API key
- client secret
- private key
- data kartu pembayaran
- data medis lengkap tanpa kebutuhan operasional

---

# 9. Error Logging

Saat exception:

Catat:

- exception_class
- error_code
- message
- file (hanya debug)
- line (hanya debug)
- stack trace (debug saja)
- correlation_id

Jangan tampilkan stack trace ke pengguna.

---

# 10. HTTP Logging

Catat:

- method
- path
- status_code
- duration_ms
- authenticated_user
- response_size (opsional)

---

# 11. Background Job Logging

Setiap job wajib mencatat:

- job_name
- started_at
- finished_at
- duration_ms
- retry_count
- status

---

# 12. Integration Logging

Catat:

- provider
- endpoint
- request_id eksternal (jika ada)
- status
- latency

Jangan log payload sensitif.

---

# 13. Storage

Lokasi lokal:

```text
storage/logs/
```

Gunakan rotasi file harian.

---

# 14. Retention

Rekomendasi:

- DEBUG : 7 hari
- INFO : 30 hari
- WARNING : 90 hari
- ERROR : 180 hari
- CRITICAL : sesuai kebijakan audit

Production dapat mengarsipkan log ke penyimpanan terpisah.

---

# 15. Korelasi

Semua log yang berasal dari request yang sama wajib menggunakan correlation_id yang sama.

Background job yang dipicu dari request harus membawa correlation_id asal.

---

# 16. Anti-pattern

Hindari:

- log plaintext secret
- log tanpa level
- log tanpa timestamp
- log bebas tanpa struktur
- log memakai bahasa yang tidak konsisten
- memakai log sebagai audit trail

---

# 17. Checklist UAT

- [ ] Semua request menghasilkan log.
- [ ] correlation_id selalu tersedia.
- [ ] Secret tidak pernah tercatat.
- [ ] Exception menghasilkan ERROR/CRITICAL.
- [ ] HTTP request mencatat latency.
- [ ] Job background menghasilkan log lifecycle.

---

# 18. Definition of Done

Structured Logging dianggap memenuhi standar bila:

- format log konsisten;
- level log digunakan dengan benar;
- correlation_id tersedia;
- context berbentuk JSON;
- secret tidak tercatat;
- log dapat digunakan untuk investigasi lintas modul.
