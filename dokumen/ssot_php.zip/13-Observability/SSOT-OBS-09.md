# SSOT-OBS-09 — Performance Monitoring Framework

> Single Source of Truth untuk performance domains, metric catalog, instrumentation, baseline, anomaly detection, regression analysis, SLI/SLO, error budget, capacity forecasting, dashboard, alerting, persistence, keamanan, operasi, dan pengujian pada Platform Kernel.

## Metadata Dokumen

| Item | Nilai |
|---|---|
| Kode | SSOT-OBS-09 |
| Judul | Performance Monitoring Framework |
| Versi | 1.0 |
| Status | Draft for Review |
| Domain | Platform Kernel |
| Kategori | Observability |
| Target Stack | PHP 8.1+, PDO, MySQL 8/MariaDB, Apache/XAMPP, Modular Monolith |
| Bergantung pada | SSOT-OBS-01 sampai SSOT-OBS-08 |
| Pemilik | Platform Architecture, Platform Operations, Service Owners |
| Reviewer | Backend Engineering, Frontend Engineering, Platform Data, DevOps, QA, Security, Data Governance |

## Tujuan Dokumen

Dokumen ini menetapkan standar tunggal untuk:

- performance domains, Golden Signals, RED/USE method, ownership, tenant/scope, dan governance;
- metric catalog, naming, units, dimensions, cardinality, instrumentation, sampling, RUM, synthetic monitoring, dan profiling;
- baseline engine, anomaly detection, regression analysis, deployment comparison, SLI/SLO, error budget, burn rate, capacity forecasting, bottleneck analysis, correlation, dan reporting;
- HTTP API, controllers, middleware, permission, scheduler, database schema, dashboards, alerting, incident integration, audit, dan Apache/XAMPP routing;
- reference implementation, migration, deployment, rollback, load testing, simulations, operational runbooks, UAT, dan Definition of Done.

## Daftar Isi

1. Bagian I — Vision, Performance Domains, Golden Signals, Baselines, SLI/SLO, Ownership & Scope
2. Bagian II — Metric Catalog, Instrumentation, Domain Monitoring, Synthetic, RUM & Sampling
3. Bagian III — Baseline Engine, Anomaly Detection, Regression, SLI/SLO, Capacity Forecasting, Correlation & Reporting
4. Bagian IV — HTTP API, Controllers, Middleware, Database Schema, Scheduler, Dashboard, Alerting & Routing
5. Bagian V — Reference Implementation, Deployment, Load Testing, Simulation, Final UAT & Operational Readiness
6. Lampiran A — Sumber Penggabungan
7. Lampiran B — Approval Gate

## Status Normatif

Kata **wajib**, **harus**, dan **tidak boleh** menyatakan persyaratan normatif. Kata **direkomendasikan**, **sebaiknya**, dan **dapat** menyatakan panduan yang dapat disesuaikan melalui keputusan arsitektur terdokumentasi.

---

## Bagian I — Vision, Performance Domains, Golden Signals, Baselines, SLI/SLO, Ownership & Scope

### 1. Executive Summary

Performance Monitoring Framework menetapkan standar tunggal untuk mengukur, menganalisis, membandingkan, dan meningkatkan kinerja Platform Kernel serta seluruh module bisnis.

Framework ini menghubungkan:

```text
Metrics
Structured Logs
Distributed Tracing
Health Checks
Monitoring Dashboards
Alerting
Incident Management
Capacity Planning
```

menjadi satu model kinerja yang konsisten.

Performance Monitoring tidak hanya mengukur apakah aplikasi cepat atau lambat.

Framework juga harus menjawab:

- bagian mana yang lambat;
- sejak kapan terjadi;
- tenant atau scope mana yang terdampak;
- apakah masalah terjadi pada aplikasi, database, queue, cache, network, atau dependency;
- apakah perubahan deployment memengaruhi kinerja;
- apakah kapasitas masih aman;
- apakah SLI/SLO tercapai;
- apakah regresi sudah terjadi;
- apakah bottleneck bersifat sementara atau sistemik;
- tindakan apa yang harus dilakukan.

Tujuan akhirnya adalah:

```text
Measure
→ Compare
→ Detect
→ Diagnose
→ Improve
→ Verify
```

---

### 2. Problem Statement

Tanpa Performance Monitoring Framework yang standar, organisasi sering menghadapi:

- dashboard hanya menampilkan CPU dan memory;
- latency tidak dibedakan berdasarkan endpoint;
- average menutupi tail latency;
- query lambat tidak memiliki owner;
- tenant besar memengaruhi tenant lain;
- deployment menyebabkan regresi tanpa deteksi;
- queue backlog terlihat terlambat;
- capacity planning hanya berdasarkan asumsi;
- performance issue baru diketahui dari complaint user;
- SLO tidak terukur;
- tidak ada baseline;
- tidak ada korelasi antara trace, log, metric, dan deployment;
- optimasi dilakukan tanpa bukti.

Contoh:

```text
Average latency = 200 ms
p95 latency = 2.5 s
p99 latency = 8 s
```

Jika hanya average yang dipantau, masalah user pada tail latency tidak terlihat.

---

### 3. Tujuan Framework

Framework harus menjawab:

- Apa indikator kinerja utama?
- Bagaimana baseline ditetapkan?
- Bagaimana SLI dan SLO didefinisikan?
- Bagaimana latency diukur?
- Bagaimana throughput diukur?
- Bagaimana saturation dan utilization diukur?
- Bagaimana error rate dikorelasikan dengan performance?
- Bagaimana regresi dideteksi?
- Bagaimana tenant dan scope dibandingkan?
- Bagaimana kapasitas diproyeksikan?
- Bagaimana perubahan deployment dihubungkan dengan kinerja?
- Siapa owner setiap performance domain?
- Kapan performance issue menjadi alert atau incident?

---

### 4. Non-Goals

Part 1 tidak mendefinisikan secara detail:

- profiler implementation;
- APM vendor integration;
- database schema lengkap;
- dashboard UI final;
- alert rules final;
- scheduler implementation;
- sampling implementation;
- deployment package;
- load-test scripts final.

Hal tersebut dibahas pada Part 2–5.

---

### 5. Design Principles

#### 5.1 Measure User Experience

Prioritaskan indikator yang mencerminkan pengalaman user.

Contoh:

- page load;
- API latency;
- workflow completion;
- transaction success;
- queue wait time.

#### 5.2 Percentile Over Average

Gunakan:

```text
p50
p75
p90
p95
p99
```

untuk melihat distribusi latency.

#### 5.3 Baseline Before Alert

Alert performance harus dibandingkan dengan baseline atau target yang jelas.

#### 5.4 Performance Is Contextual

Kinerja harus dinilai berdasarkan:

- endpoint;
- tenant;
- scope;
- module;
- environment;
- workload;
- time window;
- deployment version.

#### 5.5 Correlation First

Performance signal harus dapat dikorelasikan dengan:

- trace;
- log;
- deployment;
- query;
- dependency;
- queue;
- cache;
- infrastructure.

#### 5.6 Low-Overhead Instrumentation

Monitoring tidak boleh menjadi bottleneck baru.

#### 5.7 Multi-Tenant Fairness

Satu tenant tidak boleh menghabiskan resource tanpa observability.

#### 5.8 Capacity Is Part of Performance

Performance dan capacity planning tidak boleh dipisahkan.

#### 5.9 Regression Must Be Detectable

Perubahan kinerja setelah release harus dapat dibandingkan.

#### 5.10 Evidence-Based Optimization

Optimasi wajib berbasis data sebelum dan sesudah perubahan.

---

### 6. High-Level Architecture

```text
Application / Infrastructure / Dependencies
                  │
                  ▼
Performance Instrumentation
                  │
      ┌───────────┼───────────┐
      ▼           ▼           ▼
   Metrics      Traces       Logs
      │           │           │
      └───────────┼───────────┘
                  ▼
Performance Aggregation
                  │
      ┌───────────┼────────────┐
      ▼           ▼            ▼
 Baselines      SLI/SLO      Regression
      │           │            │
      └───────────┼────────────┘
                  ▼
Dashboard / Alert / Capacity / Incident
```

---

### 7. Core Performance Domains

Framework membedakan performance berdasarkan domain:

```text
USER_EXPERIENCE
HTTP_API
APPLICATION
DATABASE
CACHE
QUEUE
SCHEDULER
WORKFLOW
INTEGRATION
STORAGE
NETWORK
INFRASTRUCTURE
FRONTEND
REPORTING
SEARCH
BACKGROUND_JOB
MULTI_TENANT
```

---

### 8. User Experience Performance

Mengukur pengalaman aktual user.

Contoh:

- page response time;
- transaction completion time;
- time to interactive;
- upload/download duration;
- search response time;
- workflow completion time.

---

### 9. HTTP API Performance

Metric utama:

```text
request_duration
request_rate
error_rate
payload_size
concurrent_requests
timeout_rate
```

Dimension:

```text
route
method
status_class
tenant
module
environment
deployment
```

---

### 10. Application Performance

Mengukur:

- service execution time;
- handler latency;
- memory usage;
- CPU time;
- object allocation;
- exception rate;
- function hot path.

---

### 11. Database Performance

Mengukur:

```text
query latency
slow query count
connection usage
connection wait
lock wait
deadlock
rows examined
rows returned
buffer/cache hit
replication lag
```

---

### 12. Cache Performance

Metric:

```text
hit rate
miss rate
eviction rate
latency
memory usage
key count
stampede rate
```

---

### 13. Queue Performance

Metric:

```text
queue depth
enqueue rate
dequeue rate
wait time
processing time
retry rate
dead-letter rate
worker utilization
```

---

### 14. Scheduler Performance

Metric:

```text
job duration
schedule delay
missed execution
overlap
failure rate
concurrency
backlog
```

---

### 15. Workflow Performance

Metric:

```text
workflow duration
step duration
transition delay
approval wait time
timeout rate
compensation rate
```

---

### 16. Integration Performance

Metric:

```text
provider latency
timeout rate
retry rate
success rate
circuit breaker state
payload size
dependency availability
```

---

### 17. Storage Performance

Metric:

```text
read latency
write latency
IOPS
throughput
queue depth
capacity usage
filesystem wait
object retrieval latency
```

---

### 18. Network Performance

Metric:

```text
DNS latency
TCP connect latency
TLS handshake latency
packet loss
bandwidth
connection reset
upstream latency
```

---

### 19. Infrastructure Performance

Metric:

```text
CPU utilization
memory utilization
swap
load average
disk utilization
disk latency
network utilization
process count
file descriptor usage
```

---

### 20. Frontend Performance

Metric kandidat:

```text
LCP
INP
CLS
TTFB
FCP
resource load time
JavaScript error rate
```

Frontend metrics harus tetap diklasifikasikan dan tidak mengirim data sensitif.

---

### 21. Reporting Performance

Metric:

```text
report generation time
rows processed
memory usage
export size
queue wait
timeout rate
```

---

### 22. Search Performance

Metric:

```text
search latency
index latency
result count
zero-result rate
index freshness
query complexity
```

---

### 23. Background Job Performance

Metric:

```text
job queue wait
execution time
retry count
resource usage
success rate
throughput
```

---

### 24. Multi-Tenant Performance

Metric:

```text
resource usage per tenant
latency per tenant
request rate per tenant
queue depth per tenant
DB usage per tenant
heavy tenant detection
fairness ratio
```

---

### 25. Golden Signals

Framework menggunakan empat Golden Signals:

```text
Latency
Traffic
Errors
Saturation
```

---

### 26. Latency

Latency adalah waktu yang dibutuhkan untuk menyelesaikan operation.

Gunakan:

```text
p50
p90
p95
p99
max
```

Pisahkan:

```text
successful latency
failed latency
timeout latency
```

---

### 27. Traffic

Traffic adalah jumlah workload.

Contoh:

```text
requests per second
jobs per minute
transactions per hour
queries per second
messages per second
```

---

### 28. Errors

Errors mencakup:

- HTTP 5xx;
- failed job;
- timeout;
- failed integration;
- business operation failure;
- partial failure.

---

### 29. Saturation

Saturation menunjukkan seberapa dekat resource ke batas.

Contoh:

```text
CPU 90%
DB connection pool 95%
queue worker utilization 100%
disk 92%
memory pressure
```

---

### 30. USE Method

Untuk infrastructure resource:

```text
Utilization
Saturation
Errors
```

---

### 31. RED Method

Untuk service:

```text
Rate
Errors
Duration
```

---

### 32. Performance Dimensions

Setiap metric dapat memiliki dimension:

```text
environment
tenant_id
scope_id
module_code
service
component
endpoint
method
status_code
deployment_version
region
provider
job_type
workflow_type
```

---

### 33. Cardinality Governance

Dimension harus dibatasi.

Jangan gunakan:

- request_id;
- patient_id;
- order_id;
- raw URL;
- random UUID;
- free-text error;
- email;
- token.

sebagai metric label.

---

### 34. Performance Metric Definition

Setiap metric wajib memiliki:

```text
code
name
description
type
unit
domain
source
dimensions
aggregation
owner
retention
sensitivity
baseline_policy
alert_policy
```

---

### 35. Metric Types

```text
COUNTER
GAUGE
HISTOGRAM
SUMMARY
TIMER
RATE
RATIO
```

---

### 36. Units

Gunakan unit eksplisit:

```text
seconds
milliseconds
microseconds
bytes
percent
requests
jobs
connections
operations_per_second
```

---

### 37. Histogram

Histogram direkomendasikan untuk latency.

Bucket harus sesuai domain.

Contoh HTTP:

```text
5 ms
10 ms
25 ms
50 ms
100 ms
250 ms
500 ms
1 s
2.5 s
5 s
10 s
```

---

### 38. Percentile

Percentile digunakan untuk:

- latency;
- queue wait;
- job duration;
- workflow duration;
- query time.

Jangan menghitung average dari percentile antar kelompok.

---

### 39. Aggregation Levels

```text
RAW
1_MINUTE
5_MINUTE
15_MINUTE
1_HOUR
1_DAY
```

---

### 40. Aggregation Policy

Raw data disimpan pendek.

Aggregated data dapat disimpan lebih lama.

Contoh:

```text
raw: 7 days
1m: 30 days
5m: 90 days
1h: 1 year
1d: 3 years
```

---

### 41. Performance Baseline

Baseline adalah nilai referensi normal.

Jenis baseline:

```text
STATIC
ROLLING
SEASONAL
DEPLOYMENT
TENANT
WORKLOAD
```

---

### 42. Static Baseline

Contoh:

```text
p95 API latency < 500 ms
```

---

### 43. Rolling Baseline

Contoh:

```text
median 7 hari terakhir
```

---

### 44. Seasonal Baseline

Membandingkan:

- jam yang sama;
- hari yang sama;
- pola weekday/weekend;
- periode billing;
- periode kampanye.

---

### 45. Deployment Baseline

Membandingkan release baru dengan release sebelumnya.

Metric:

```text
latency delta
error rate delta
CPU delta
query count delta
memory delta
```

---

### 46. Tenant Baseline

Membandingkan tenant dengan:

- baseline tenant sendiri;
- cohort tenant serupa;
- platform aggregate aman.

---

### 47. Workload Baseline

Performance dibandingkan pada workload setara.

Contoh:

```text
latency at 100 RPS
```

lebih bermakna daripada hanya latency saat traffic berbeda.

---

### 48. Baseline Window

Window umum:

```text
1 hour
24 hours
7 days
28 days
```

---

### 49. Baseline Quality

Baseline harus memiliki quality status:

```text
VALID
INSUFFICIENT_DATA
STALE
ANOMALOUS
MAINTENANCE_AFFECTED
DEPLOYMENT_AFFECTED
```

---

### 50. Baseline Exclusions

Exclude:

- maintenance;
- incident;
- load test;
- migration;
- known outage;
- invalid telemetry.

---

### 51. Service Level Indicator

SLI adalah metric yang mengukur service behavior.

Contoh:

```text
successful requests / total requests
requests under 500 ms / total requests
completed jobs under 5 min / total jobs
```

---

### 52. Service Level Objective

SLO adalah target untuk SLI.

Contoh:

```text
99.9% successful requests per 30 days
95% requests under 500 ms per 7 days
99% jobs completed under 5 minutes
```

---

### 53. Performance SLI Categories

```text
AVAILABILITY
LATENCY
THROUGHPUT
FRESHNESS
CORRECTNESS
DURABILITY
QUEUE_DELAY
WORKFLOW_COMPLETION
```

---

### 54. Latency SLI

Contoh:

```text
good events =
requests with duration <= 500 ms
```

---

### 55. Throughput SLI

Contoh:

```text
processed transactions per minute
```

---

### 56. Freshness SLI

Contoh:

```text
data synchronized within 5 minutes
```

---

### 57. Queue Delay SLI

Contoh:

```text
jobs started within 30 seconds
```

---

### 58. Error Budget

Formula:

```text
error budget = 1 - SLO
```

Untuk SLO 99.9%:

```text
error budget = 0.1%
```

---

### 59. Error Budget Consumption

Metric:

```text
burn rate
remaining budget
consumed budget
projected exhaustion
```

---

### 60. Burn Rate

Burn rate menunjukkan kecepatan konsumsi error budget.

```text
burn_rate =
actual_bad_event_rate / allowed_bad_event_rate
```

---

### 61. SLO Windows

Common windows:

```text
7 days
28 days
30 days
90 days
```

---

### 62. Multi-Window Burn Rate

Gunakan short dan long window.

Contoh:

```text
5m + 1h
30m + 6h
2h + 1d
```

---

### 63. Performance Objective Hierarchy

```text
Platform SLO
→ Service SLO
→ Module SLO
→ Endpoint SLO
→ Tenant Contract SLO
```

---

### 64. SLO Ownership

Setiap SLO wajib memiliki:

- service owner;
- technical owner;
- business owner;
- reviewer;
- effective date;
- review cadence.

---

### 65. Performance Budget

Performance budget adalah batas desain.

Contoh:

```text
API p95 < 500 ms
DB query budget < 100 ms
External call budget < 250 ms
Application processing budget < 100 ms
Network overhead < 50 ms
```

---

### 66. Request Budget Breakdown

Contoh:

```text
Total target: 500 ms

Network: 50 ms
Authentication: 50 ms
Application: 100 ms
Database: 150 ms
External dependency: 100 ms
Serialization: 50 ms
```

---

### 67. Budget Violation

Jika component melewati budget:

- record metric;
- annotate trace;
- identify owner;
- alert bila sustained;
- include in regression report.

---

### 68. Apdex

Apdex dapat digunakan sebagai summary user satisfaction.

Parameter:

```text
T = target response time
```

Classification:

```text
Satisfied <= T
Tolerating <= 4T
Frustrated > 4T
```

---

### 69. Apdex Limitation

Apdex tidak menggantikan percentile dan SLO.

---

### 70. Performance State

State awal:

```text
NORMAL
DEGRADED
CRITICAL
UNKNOWN
```

---

### 71. NORMAL

Metric berada dalam baseline dan SLO.

---

### 72. DEGRADED

Metric memburuk tetapi layanan masih berjalan.

---

### 73. CRITICAL

Performance menghambat operasi atau menghabiskan error budget cepat.

---

### 74. UNKNOWN

Telemetry tidak cukup atau stale.

UNKNOWN tidak boleh dianggap NORMAL.

---

### 75. Regression

Performance regression adalah penurunan terukur setelah perubahan.

Jenis:

```text
LATENCY_REGRESSION
THROUGHPUT_REGRESSION
MEMORY_REGRESSION
CPU_REGRESSION
QUERY_REGRESSION
ERROR_REGRESSION
```

---

### 76. Regression Threshold

Contoh:

```text
p95 latency increase > 20%
and
absolute increase > 100 ms
```

Gunakan relative dan absolute threshold.

---

### 77. Deployment Annotation

Setiap deployment harus menghasilkan annotation:

```text
deployment_id
version
commit
environment
started_at
completed_at
owner
```

---

### 78. Performance Comparison

Perbandingan:

```text
before deployment
after deployment
canary
control
tenant cohort
```

---

### 79. Capacity Monitoring

Capacity metrics:

```text
CPU headroom
memory headroom
DB connection headroom
queue worker headroom
storage headroom
network headroom
```

---

### 80. Headroom

Formula:

```text
headroom = capacity - current_usage
```

---

### 81. Capacity Thresholds

Contoh:

```text
normal: < 70%
warning: 70–85%
critical: > 85%
```

Final threshold domain-specific.

---

### 82. Forecasting

Forecast dapat menggunakan:

- linear trend;
- moving average;
- seasonal trend;
- growth rate;
- percentile peak.

---

### 83. Saturation Early Warning

Early warning harus muncul sebelum service gagal.

Contoh:

```text
DB pool usage 80%
queue wait increasing
disk usage 85%
worker utilization 90%
```

---

### 84. Performance Ownership Model

Setiap performance domain wajib memiliki:

```text
Business Owner
Service Owner
Technical Owner
Infrastructure Owner
Database Owner optional
Dependency Owner optional
```

---

### 85. Ownership Matrix

| Domain | Owner |
|---|---|
| HTTP/API | Service Owner |
| Application | Module Owner |
| Database | DBA/Platform Data |
| Cache | Platform Operations |
| Queue/Scheduler | Platform Operations |
| Workflow | Workflow Owner |
| Integration | Integration Team |
| Storage | Infrastructure Team |
| Network | Infrastructure Team |
| Frontend | Frontend Team |
| Search | Search/Data Team |
| Multi-Tenant Fairness | Platform Architecture |

---

### 86. Performance Responsibility

Owner bertanggung jawab untuk:

- metric definition;
- baseline;
- SLO;
- alert threshold;
- runbook;
- optimization backlog;
- regression review;
- capacity review.

---

### 87. Tenant Context

Performance metric tenant-aware wajib memiliki:

```text
tenant_id
scope_id optional
```

Namun cardinality harus dikendalikan.

---

### 88. Tenant Aggregation

Gunakan:

- top-N tenant;
- cohort;
- sampled tenant;
- per-tenant rollup;
- aggregate safe metric.

---

### 89. Noisy Neighbor Detection

Indikator:

```text
resource usage share
latency impact
queue share
DB query share
connection share
cache eviction contribution
```

---

### 90. Fairness Ratio

Contoh:

```text
tenant resource share /
tenant workload share
```

---

### 91. Scope Isolation

Performance data clinic/facility/business entity wajib difilter oleh scope.

---

### 92. Environment Separation

Pisahkan:

```text
local
development
testing
staging
production
```

Baseline production tidak boleh dicampur dengan load test staging.

---

### 93. Test Traffic

Test/load traffic wajib diberi marker:

```text
traffic_type = synthetic
traffic_type = load_test
```

---

### 94. Synthetic Monitoring

Synthetic monitoring dapat mengukur:

- login;
- search;
- workflow;
- API transaction;
- external dependency.

---

### 95. Real User Monitoring

RUM dapat mengukur user experience aktual.

Wajib:

- privacy control;
- sampling;
- no PHI/PII;
- bounded payload;
- consent/policy compliance.

---

### 96. Profiling

Profiling digunakan untuk diagnostic mendalam.

Mode:

```text
OFF
SAMPLED
ON_DEMAND
CONTINUOUS_LOW_RATE
```

---

### 97. Production Profiling

Wajib:

- bounded overhead;
- approval;
- sampling;
- sensitive data protection;
- expiry;
- audit.

---

### 98. Trace Sampling

Trace sampling dapat mempertimbangkan:

```text
latency
error
tenant
endpoint
incident
deployment
```

Slow/error trace dapat disampling lebih tinggi.

---

### 99. Performance Event

Performance event adalah structured record untuk perubahan penting.

Contoh:

```text
baseline_changed
SLO_breached
regression_detected
capacity_threshold_crossed
profiling_started
load_test_started
```

---

### 100. Performance Annotation

Annotation sources:

```text
deployment
configuration change
database migration
maintenance
incident
traffic campaign
tenant onboarding
load test
```

---

### 101. Data Quality

Performance data quality states:

```text
VALID
PARTIAL
STALE
DROPPED
MALFORMED
CLOCK_SKEWED
INSUFFICIENT
```

---

### 102. Clock Synchronization

Performance measurement membutuhkan clock yang konsisten.

Gunakan:

- NTP;
- monotonic clock untuk duration;
- UTC timestamp untuk event time.

---

### 103. Measurement Overhead

Setiap instrumentation harus memiliki overhead budget.

Contoh:

```text
< 1% CPU
< 1% memory
< 5 ms request overhead
```

Final target tergantung teknologi.

---

### 104. Sampling Governance

Sampling diperbolehkan untuk:

- high-volume traces;
- frontend telemetry;
- detailed profiling;
- repetitive request metrics.

Sampling tidak boleh menghilangkan:

- error count;
- critical transaction count;
- SLO denominator;
- audit/security events.

---

### 105. Performance Data Retention

Contoh:

| Data | Retention |
|---|---|
| Raw high-resolution metrics | 7–30 hari |
| 1-minute aggregates | 30–90 hari |
| 1-hour aggregates | 1 tahun |
| Daily aggregates | 3 tahun |
| Raw traces | 3–14 hari |
| Error/slow traces | 30–90 hari |
| Profiling data | 1–14 hari |
| SLO history | 1–3 tahun |

Final mengikuti SSOT-OBS-08.

---

### 106. Privacy & Security

Performance telemetry tidak boleh mengandung:

- password;
- token;
- full URL query;
- PHI;
- PII;
- raw request body;
- full SQL with sensitive literals;
- credential;
- session secret.

---

### 107. SQL Sanitization

Simpan:

```text
query fingerprint
query hash
normalized SQL
duration
rows examined
```

Bukan raw literal sensitif.

---

### 108. Endpoint Normalization

Gunakan:

```text
/patients/{id}
```

bukan:

```text
/patients/103
```

untuk metric label.

---

### 109. Permission Model

Initial permissions:

```text
observability.performance.read
observability.performance.dashboard.read
observability.performance.tenant.read
observability.performance.cross_tenant.read
observability.performance.baseline.read
observability.performance.baseline.manage
observability.performance.slo.read
observability.performance.slo.manage
observability.performance.profile.execute
observability.performance.regression.read
observability.performance.capacity.read
observability.performance.export
```

---

### 110. Role Matrix

| Role | Akses |
|---|---|
| Platform Admin | seluruh performance |
| Operations Admin | platform/infrastructure |
| DBA | database performance |
| Module Owner | module terkait |
| Tenant Admin | tenant sendiri |
| Security Admin | restricted diagnostic |
| Executive | summary SLO/capacity |
| Developer | development/staging, production terbatas |
| End User | tidak ada akses teknis |

---

### 111. Audit Policy

Wajib audit:

- baseline change;
- SLO change;
- threshold change;
- profiling activation;
- performance export;
- cross-tenant access;
- production diagnostic;
- sampling change;
- retention change;
- manual regression override.

---

### 112. Performance Export

Export wajib:

- permission;
- scope;
- time range;
- size limit;
- classification;
- expiry;
- audit.

---

### 113. Alert Integration

Performance alert candidate:

```text
latency_slo_breach
error_budget_burn_high
database_query_latency_high
queue_wait_time_high
cache_hit_rate_low
worker_saturation_high
memory_growth_detected
performance_regression_detected
capacity_headroom_low
```

---

### 114. Incident Integration

Incident dapat dibuat bila:

- widespread latency critical;
- error budget burn sangat tinggi;
- database saturation;
- queue backlog menghambat bisnis;
- deployment regression signifikan;
- noisy neighbor berdampak lintas tenant;
- performance telemetry hilang saat outage.

---

### 115. Dashboard Integration

Dashboard minimum:

- Golden Signals;
- p50/p95/p99 latency;
- throughput;
- error rate;
- saturation;
- SLO status;
- error budget;
- regression;
- capacity headroom;
- top slow endpoints;
- top slow queries;
- queue wait;
- tenant outliers.

---

### 116. Performance Review Cadence

Direkomendasikan:

```text
daily operational review
weekly regression review
monthly capacity review
quarterly SLO review
```

---

### 117. Performance Review Inputs

- SLO attainment;
- error budget;
- top bottleneck;
- regression;
- capacity trend;
- alert noise;
- incident;
- optimization result;
- upcoming workload.

---

### 118. Optimization Lifecycle

```text
Measure
→ Hypothesis
→ Change
→ Test
→ Deploy
→ Compare
→ Accept/Rollback
```

---

### 119. Before/After Evidence

Setiap optimasi penting harus mencatat:

```text
baseline
change
test condition
before metric
after metric
workload
side effects
conclusion
```

---

### 120. Anti-Pattern

Hindari:

- hanya memantau average;
- CPU dianggap satu-satunya performance metric;
- label metric memakai request ID;
- raw SQL masuk metric;
- baseline tanpa exclusion;
- SLO tanpa owner;
- threshold tanpa workload context;
- alert pada satu sample;
- profiling selalu aktif;
- performance test tanpa data production-like;
- optimasi tanpa before/after;
- tenant performance bercampur tanpa scope;
- UNKNOWN dianggap NORMAL;
- query dashboard tanpa time range.

---

### 121. UAT Part 1

#### Domain & Metrics

- [ ] Semua performance domain terdefinisi.
- [ ] Golden Signals tersedia.
- [ ] RED method tersedia.
- [ ] USE method tersedia.
- [ ] Metric memiliki unit.
- [ ] Metric memiliki owner.
- [ ] Dimension terkontrol.

#### Baseline

- [ ] Static baseline tersedia.
- [ ] Rolling baseline tersedia.
- [ ] Seasonal baseline tersedia.
- [ ] Deployment baseline tersedia.
- [ ] Baseline exclusion bekerja.
- [ ] Insufficient data ditandai.

#### SLI/SLO

- [ ] SLI dapat dihitung.
- [ ] SLO memiliki owner.
- [ ] Error budget dapat dihitung.
- [ ] Burn rate tersedia.
- [ ] SLO window eksplisit.
- [ ] Tenant contract SLO dapat dibedakan.

#### Performance Budget

- [ ] Endpoint budget tersedia.
- [ ] Component budget tersedia.
- [ ] Violation dapat dideteksi.
- [ ] Trace dapat menghubungkan budget.
- [ ] Regression dapat dibandingkan.

#### Tenant & Scope

- [ ] Tenant context tersedia.
- [ ] Scope context tersedia.
- [ ] Cross-tenant access dibatasi.
- [ ] Top-N/cohort aggregation bekerja.
- [ ] Noisy neighbor indicator tersedia.

#### Security & Privacy

- [ ] Token/password tidak tercatat.
- [ ] Endpoint dinormalisasi.
- [ ] SQL disanitasi.
- [ ] Profiling production dibatasi.
- [ ] Export diaudit.
- [ ] RUM tidak mengandung PHI/PII.

---

### 122. Definition of Done Part 1

Part 1 dianggap selesai bila:

- [ ] visi dan problem statement disepakati;
- [ ] performance domains tersedia;
- [ ] Golden Signals tersedia;
- [ ] RED/USE method tersedia;
- [ ] metric definition tersedia;
- [ ] units dan aggregation tersedia;
- [ ] baseline model tersedia;
- [ ] baseline quality tersedia;
- [ ] SLI tersedia;
- [ ] SLO tersedia;
- [ ] error budget tersedia;
- [ ] burn rate tersedia;
- [ ] performance budget tersedia;
- [ ] regression model tersedia;
- [ ] deployment annotation tersedia;
- [ ] capacity monitoring tersedia;
- [ ] ownership model tersedia;
- [ ] tenant/scope model tersedia;
- [ ] profiling/sampling governance tersedia;
- [ ] privacy/security policy tersedia;
- [ ] permission model tersedia;
- [ ] audit policy tersedia;
- [ ] UAT tersedia.

---

### 123. Rencana Part Berikutnya

#### Part 2

Metric catalog, instrumentation standard, latency histogram, throughput, saturation, database/query monitoring, cache, queue, scheduler, workflow, integration, frontend, synthetic monitoring, RUM, dan sampling.

#### Part 3

Baseline engine, anomaly detection, regression detection, SLI/SLO calculation, error budget, capacity forecasting, performance analysis, correlation, profiling, dan reporting.

#### Part 4

HTTP API, controllers, middleware, database schema, scheduler, alert integration, dashboard APIs, audit, security controls, Apache/XAMPP routing, dan sequence diagram.

#### Part 5

Reference implementation, sample metrics/SLO, migration, deployment, load testing, simulations, operational runbook, final UAT, Definition of Done, roadmap, dan merge guidance.

---

## Bagian II — Metric Catalog, Instrumentation, Domain Monitoring, Synthetic, RUM & Sampling

### 1. Executive Summary

Part 2 mendefinisikan bagaimana performance telemetry dihasilkan secara konsisten dari application, database, cache, queue, scheduler, workflow, integration, frontend, synthetic monitoring, dan Real User Monitoring.

Bagian ini menetapkan:

- metric catalog;
- naming convention;
- units;
- labels/dimensions;
- histogram buckets;
- instrumentation contracts;
- HTTP middleware instrumentation;
- database query instrumentation;
- cache instrumentation;
- queue dan scheduler instrumentation;
- workflow dan integration instrumentation;
- frontend telemetry;
- synthetic monitoring;
- RUM;
- profiling hooks;
- sampling;
- telemetry quality;
- overhead budget;
- UAT.

Tujuan utama adalah menghasilkan telemetry yang:

- konsisten;
- rendah overhead;
- aman;
- dapat diagregasi;
- dapat dibandingkan;
- dapat dikorelasikan;
- tenant-aware;
- mendukung SLI/SLO;
- tidak menimbulkan cardinality explosion.

---

### 2. Instrumentation Pipeline

```text
Operation Starts
      ↓
Capture Context
      ↓
Start Monotonic Timer
      ↓
Execute Operation
      ↓
Capture Result
      ↓
Normalize Dimensions
      ↓
Record Counter/Gauge/Histogram
      ↓
Link Trace/Log
      ↓
Export/Store
```

---

### 3. Metric Catalog

Metric Catalog menjadi sumber kebenaran untuk seluruh performance metric.

Field minimum:

```text
code
name
description
domain
type
unit
source
dimensions
aggregation
buckets
owner
sensitivity
retention
sli_usage
enabled
version
```

---

### 4. Metric Catalog Contract

```php
interface PerformanceMetricRegistryInterface
{
    public function register(
        PerformanceMetricDefinition $definition
    ): void;

    public function get(
        string $code
    ): PerformanceMetricDefinition;

    public function all(): array;

    public function active(): array;
}
```

---

### 5. Metric Definition Example

```php
return [
    'code' => 'http_server_request_duration_seconds',
    'name' => 'HTTP Server Request Duration',
    'description' => 'Server-side request duration by normalized route.',
    'domain' => 'HTTP_API',
    'type' => 'HISTOGRAM',
    'unit' => 'seconds',
    'source' => 'http_middleware',
    'dimensions' => [
        'environment',
        'route',
        'method',
        'status_class',
        'module_code',
    ],
    'aggregation' => [
        'rate',
        'p50',
        'p95',
        'p99',
    ],
    'buckets' => [
        0.005,
        0.010,
        0.025,
        0.050,
        0.100,
        0.250,
        0.500,
        1.000,
        2.500,
        5.000,
        10.000,
    ],
    'owner' => 'platform_operations',
    'sensitivity' => 'INTERNAL',
    'retention' => 'performance_standard',
    'sli_usage' => true,
    'enabled' => true,
    'version' => '1.0',
];
```

---

### 6. Metric Naming Convention

Gunakan format:

```text
<namespace>_<subsystem>_<metric>_<unit>
```

Contoh:

```text
platform_http_request_duration_seconds
platform_db_query_duration_seconds
platform_queue_wait_duration_seconds
platform_cache_hit_total
platform_worker_utilization_ratio
```

---

### 7. Naming Rules

Metric name harus:

- lowercase;
- snake_case;
- stabil;
- memiliki unit suffix bila relevan;
- tidak mengandung environment;
- tidak mengandung tenant;
- tidak mengandung vendor bila metric bersifat generic.

---

### 8. Recommended Unit Suffixes

```text
_seconds
_milliseconds
_bytes
_total
_ratio
_percent
_count
_current
```

---

### 9. Counter Rules

Counter:

- hanya naik;
- reset hanya saat process restart;
- cocok untuk total event;
- rate dihitung saat query.

Contoh:

```text
http_request_total
db_query_error_total
queue_job_processed_total
```

---

### 10. Gauge Rules

Gauge dapat naik dan turun.

Contoh:

```text
queue_depth
db_connections_current
memory_usage_bytes
worker_active_count
```

---

### 11. Histogram Rules

Histogram digunakan untuk distribusi.

Contoh:

```text
request_duration
query_duration
job_duration
payload_size
```

---

### 12. Summary Rules

Summary hanya digunakan bila kebutuhan client-side quantile jelas.

Histogram lebih direkomendasikan untuk aggregation lintas instance.

---

### 13. Ratio Rules

Ratio disimpan sebagai numerator dan denominator bila memungkinkan.

Contoh:

```text
cache_hit_total
cache_request_total
```

Lalu:

```text
cache_hit_ratio =
cache_hit_total / cache_request_total
```

---

### 14. Dimension Governance

Dimension wajib melalui allowlist.

Setiap dimension harus memiliki:

```text
name
description
allowed_values
cardinality_expectation
sensitivity
normalization_rule
```

---

### 15. Safe Dimensions

Contoh:

```text
environment
route
method
status_class
module_code
service
component
job_type
provider_code
workflow_type
deployment_version
```

---

### 16. Restricted Dimensions

Gunakan dengan kontrol:

```text
tenant_id
scope_id
region
feature_flag
```

---

### 17. Prohibited Dimensions

Jangan gunakan:

```text
request_id
trace_id
patient_id
user_id
email
phone
order_id
raw_url
raw_sql
exception_message
random_uuid
```

sebagai metric label.

---

### 18. Cardinality Budget

Setiap metric wajib memiliki cardinality budget.

Contoh:

```text
route <= 500
module_code <= 100
provider_code <= 50
status_class <= 5
environment <= 5
```

---

### 19. Cardinality Violation

Jika cardinality melebihi budget:

- reject new label value;
- map ke `other`;
- emit warning metric;
- log configuration defect;
- review instrumentation.

---

### 20. Label Normalization

Contoh:

```text
/patients/103
→ /patients/{id}
```

```text
status_code = 404
→ status_class = 4xx
```

---

### 21. Monotonic Timing

Duration wajib memakai monotonic clock.

PHP example:

```php
$startedAt = hrtime(true);

$result = $operation();

$durationSeconds = (hrtime(true) - $startedAt) / 1_000_000_000;
```

---

### 22. Instrumentation Contract

```php
interface PerformanceRecorderInterface
{
    public function increment(
        string $metricCode,
        array $dimensions = [],
        float $value = 1.0
    ): void;

    public function gauge(
        string $metricCode,
        float $value,
        array $dimensions = []
    ): void;

    public function observe(
        string $metricCode,
        float $value,
        array $dimensions = []
    ): void;
}
```

---

### 23. Timer Helper

```php
interface PerformanceTimerInterface
{
    public function stop(
        array $dimensions = []
    ): float;
}
```

---

### 24. Null Recorder

Jika monitoring dinonaktifkan, gunakan Null Object.

```php
final class NullPerformanceRecorder
    implements PerformanceRecorderInterface
{
    public function increment(
        string $metricCode,
        array $dimensions = [],
        float $value = 1.0
    ): void {
    }

    public function gauge(
        string $metricCode,
        float $value,
        array $dimensions = []
    ): void {
    }

    public function observe(
        string $metricCode,
        float $value,
        array $dimensions = []
    ): void {
    }
}
```

---

### 25. HTTP Instrumentation

Metric minimum:

```text
http_request_total
http_request_duration_seconds
http_request_in_flight
http_response_size_bytes
http_timeout_total
http_client_disconnect_total
```

---

### 26. HTTP Middleware Flow

```text
Request received
→ Normalize route
→ Increment in-flight
→ Start timer
→ Call next middleware/controller
→ Capture status
→ Observe duration
→ Record response size
→ Decrement in-flight
```

---

### 27. HTTP Middleware Example

```php
final class PerformanceHttpMiddleware
{
    public function __construct(
        private readonly PerformanceRecorderInterface $metrics,
        private readonly RouteNormalizerInterface $routes
    ) {
    }

    public function process(
        HttpRequest $request,
        callable $next
    ): HttpResponse {
        $route = $this->routes->normalize($request);

        $dimensions = [
            'environment' => $request->environment(),
            'route' => $route,
            'method' => $request->method(),
            'module_code' => $request->moduleCode(),
        ];

        $this->metrics->gauge(
            'http_request_in_flight',
            1,
            $dimensions
        );

        $startedAt = hrtime(true);

        try {
            $response = $next($request);

            $statusClass = intdiv(
                $response->statusCode(),
                100
            ) . 'xx';

            $this->metrics->increment(
                'http_request_total',
                $dimensions + [
                    'status_class' => $statusClass,
                ]
            );

            return $response;
        } finally {
            $duration = (
                hrtime(true) - $startedAt
            ) / 1_000_000_000;

            $this->metrics->observe(
                'http_request_duration_seconds',
                $duration,
                $dimensions
            );

            $this->metrics->gauge(
                'http_request_in_flight',
                -1,
                $dimensions
            );
        }
    }
}
```

---

### 28. In-Flight Gauge Note

Implementasi production sebaiknya memakai increment/decrement gauge, bukan overwrite absolut tanpa atomicity.

---

### 29. HTTP Route Normalization

Route harus berasal dari matched route template.

Jangan gunakan raw URI jika mengandung identifier.

---

### 30. HTTP Client Instrumentation

Metric:

```text
http_client_request_total
http_client_request_duration_seconds
http_client_timeout_total
http_client_retry_total
http_client_circuit_open_total
```

Dimensions:

```text
provider_code
operation
status_class
environment
```

---

### 31. Database Instrumentation

Metric minimum:

```text
db_query_total
db_query_duration_seconds
db_query_error_total
db_connection_current
db_connection_wait_seconds
db_transaction_duration_seconds
db_deadlock_total
db_rows_examined_total
db_rows_returned_total
```

---

### 32. Query Fingerprint

Gunakan normalized fingerprint.

Contoh:

```sql
SELECT * FROM patients WHERE id = ?
```

Bukan SQL dengan literal value.

---

### 33. Query Name

Setiap repository query penting sebaiknya memiliki code:

```text
patient.find_by_id
appointment.list_by_date
homecare.visit.create
```

---

### 34. Database Span Attributes

Trace dapat menyimpan:

```text
db.system
db.operation
db.query_code
db.duration
db.rows
```

Tanpa raw sensitive SQL.

---

### 35. PDO Instrumentation Wrapper

```php
final class InstrumentedPdo
{
    public function __construct(
        private readonly \PDO $pdo,
        private readonly PerformanceRecorderInterface $metrics
    ) {
    }

    public function execute(
        string $queryCode,
        string $sql,
        array $parameters = []
    ): \PDOStatement {
        $startedAt = hrtime(true);

        try {
            $statement = $this->pdo->prepare($sql);
            $statement->execute($parameters);

            $this->metrics->increment(
                'db_query_total',
                [
                    'query_code' => $queryCode,
                    'operation' => $this->operation($sql),
                    'result' => 'success',
                ]
            );

            return $statement;
        } catch (\Throwable $exception) {
            $this->metrics->increment(
                'db_query_error_total',
                [
                    'query_code' => $queryCode,
                    'error_class' => $this->classify($exception),
                ]
            );

            throw $exception;
        } finally {
            $duration = (
                hrtime(true) - $startedAt
            ) / 1_000_000_000;

            $this->metrics->observe(
                'db_query_duration_seconds',
                $duration,
                [
                    'query_code' => $queryCode,
                    'operation' => $this->operation($sql),
                ]
            );
        }
    }
}
```

---

### 36. Slow Query Threshold

Slow threshold harus domain-specific.

Contoh awal:

```text
OLTP query: > 250 ms
report query: > 2 s
migration query: separate policy
```

---

### 37. Query Plan Capture

Query plan hanya ditangkap:

- on-demand;
- slow query;
- sampled;
- sanitized;
- authorized.

---

### 38. Database Pool Monitoring

Metric:

```text
db_pool_size
db_pool_in_use
db_pool_idle
db_pool_waiters
db_pool_wait_duration_seconds
db_pool_timeout_total
```

---

### 39. Transaction Monitoring

Metric:

```text
db_transaction_total
db_transaction_duration_seconds
db_transaction_rollback_total
```

---

### 40. Lock Monitoring

Metric:

```text
db_lock_wait_seconds
db_deadlock_total
db_blocked_session_current
```

---

### 41. Cache Instrumentation

Metric minimum:

```text
cache_request_total
cache_hit_total
cache_miss_total
cache_error_total
cache_operation_duration_seconds
cache_eviction_total
cache_memory_usage_bytes
```

---

### 42. Cache Key Safety

Jangan jadikan full cache key sebagai label.

Gunakan:

```text
cache_namespace
operation
result
```

---

### 43. Cache Stampede

Metric kandidat:

```text
cache_lock_wait_seconds
cache_rebuild_total
cache_stampede_detected_total
```

---

### 44. Cache Hit Ratio

Formula:

```text
cache_hit_ratio =
cache_hit_total /
(cache_hit_total + cache_miss_total)
```

---

### 45. Queue Instrumentation

Metric minimum:

```text
queue_enqueued_total
queue_dequeued_total
queue_depth
queue_wait_duration_seconds
queue_processing_duration_seconds
queue_retry_total
queue_failed_total
queue_dead_letter_total
queue_worker_active
queue_worker_utilization_ratio
```

---

### 46. Queue Message Age

Metric:

```text
queue_oldest_message_age_seconds
```

Ini sering lebih berguna daripada depth saja.

---

### 47. Queue Context

Dimensions:

```text
queue_name
job_type
priority
environment
module_code
```

---

### 48. Job Instrumentation

```text
job_started_total
job_completed_total
job_failed_total
job_duration_seconds
job_retry_total
job_memory_peak_bytes
```

---

### 49. Scheduler Instrumentation

Metric:

```text
scheduler_job_scheduled_total
scheduler_job_started_total
scheduler_job_completed_total
scheduler_job_failed_total
scheduler_job_delay_seconds
scheduler_job_duration_seconds
scheduler_job_overlap_total
scheduler_job_missed_total
```

---

### 50. Schedule Delay

Formula:

```text
actual_start_at - scheduled_start_at
```

---

### 51. Workflow Instrumentation

Metric:

```text
workflow_started_total
workflow_completed_total
workflow_failed_total
workflow_duration_seconds
workflow_step_duration_seconds
workflow_wait_duration_seconds
workflow_timeout_total
workflow_compensation_total
```

---

### 52. Workflow Dimensions

```text
workflow_type
step_code
result
module_code
environment
```

Jangan gunakan workflow instance ID sebagai metric label.

---

### 53. Business Transaction Metric

Contoh:

```text
homecare_visit_submission_duration_seconds
claim_processing_duration_seconds
appointment_booking_duration_seconds
```

Business metric harus memiliki owner.

---

### 54. Integration Instrumentation

Metric minimum:

```text
integration_request_total
integration_request_duration_seconds
integration_timeout_total
integration_retry_total
integration_failure_total
integration_circuit_state
integration_payload_size_bytes
```

---

### 55. Provider Normalization

Gunakan stable provider code:

```text
payment_gateway_a
laboratory_partner
insurance_gateway
```

Bukan raw hostname dinamis.

---

### 56. Circuit Breaker Metrics

```text
circuit_breaker_open_total
circuit_breaker_half_open_total
circuit_breaker_state
```

---

### 57. Storage Instrumentation

Metric:

```text
storage_read_duration_seconds
storage_write_duration_seconds
storage_read_bytes_total
storage_write_bytes_total
storage_operation_error_total
storage_queue_depth
storage_capacity_bytes
storage_used_bytes
```

---

### 58. File Operation Monitoring

Jangan label dengan full path sensitif.

Gunakan:

```text
storage_area
operation
result
```

---

### 59. Search Instrumentation

Metric:

```text
search_request_total
search_duration_seconds
search_result_count
search_zero_result_total
search_index_lag_seconds
search_query_error_total
```

---

### 60. Reporting Instrumentation

Metric:

```text
report_requested_total
report_generation_duration_seconds
report_rows_processed_total
report_export_size_bytes
report_timeout_total
report_queue_wait_seconds
```

---

### 61. Frontend Performance Monitoring

Frontend metric kandidat:

```text
web_vital_lcp_seconds
web_vital_inp_seconds
web_vital_cls
web_ttfb_seconds
web_fcp_seconds
frontend_resource_duration_seconds
frontend_js_error_total
```

---

### 62. Frontend Dimensions

```text
page_template
device_class
network_class
browser_family
release_version
environment
```

Hindari full user agent sebagai label.

---

### 63. Device Class

Normalize:

```text
mobile
tablet
desktop
unknown
```

---

### 64. Network Class

Normalize:

```text
slow_2g
2g
3g
4g
wifi
unknown
```

---

### 65. RUM Event Contract

```json
{
  "event_type": "web_vital",
  "metric": "LCP",
  "value": 2.1,
  "page_template": "patient_detail",
  "device_class": "mobile",
  "release_version": "2026.07.04",
  "occurred_at": "2026-07-04T12:00:00Z"
}
```

---

### 66. RUM Privacy

RUM tidak boleh mengirim:

- URL query sensitif;
- page content;
- form value;
- patient identifier;
- user name;
- email;
- diagnosis;
- token.

---

### 67. RUM Sampling

Contoh awal:

```text
1–10% normal sessions
100% sessions with JavaScript error
higher sample for slow sessions
```

---

### 68. Synthetic Monitoring

Synthetic checks mensimulasikan user atau service operation.

Jenis:

```text
HTTP_CHECK
API_TRANSACTION
BROWSER_TRANSACTION
DNS_CHECK
TCP_CHECK
DEPENDENCY_CHECK
```

---

### 69. Synthetic Check Definition

Field:

```text
code
type
target
frequency
timeout
expected_status
assertions
environment
owner
severity
enabled
```

---

### 70. Synthetic API Transaction

Contoh:

```text
login
→ search patient
→ open patient detail
→ logout
```

Gunakan test account khusus.

---

### 71. Synthetic Data Safety

Synthetic monitoring tidak boleh menggunakan:

- production patient nyata;
- credential user nyata;
- uncontrolled write;
- destructive operation.

---

### 72. Synthetic Metrics

```text
synthetic_check_total
synthetic_check_duration_seconds
synthetic_check_failure_total
synthetic_assertion_failure_total
```

---

### 73. Synthetic Frequency

Contoh:

| Check | Frequency |
|---|---:|
| Critical API | 1 menit |
| Login flow | 5 menit |
| Search flow | 5–15 menit |
| External dependency | 1–5 menit |
| Browser transaction | 5–15 menit |

---

### 74. Synthetic Region

Jika multi-region, dimension:

```text
probe_region
```

---

### 75. Profiling Hooks

Profiler integration points:

```text
HTTP request
CLI command
queue job
scheduler job
workflow execution
report generation
```

---

### 76. Profiling Modes

```text
OFF
SAMPLED
ON_DEMAND
INCIDENT
CANARY
```

---

### 77. Profiling Sample Criteria

Sample berdasarkan:

- duration;
- error;
- route;
- deployment;
- tenant cohort;
- incident;
- random rate.

---

### 78. Profiling Data

Profiling dapat mencakup:

```text
CPU samples
function time
call count
memory allocation
I/O wait
```

---

### 79. Profiling Safety

Jangan menangkap:

- function arguments sensitif;
- local variable berisi PHI/PII;
- raw request body;
- secret.

---

### 80. Trace Integration

Metric exemplar dapat menautkan trace ID secara terbatas.

Trace ID bukan metric label.

---

### 81. Log Integration

Slow operation dapat menghasilkan structured log:

```json
{
  "event": "performance_slow_operation",
  "operation_code": "patient.search",
  "duration_ms": 1450,
  "threshold_ms": 500,
  "trace_id": "01J...",
  "tenant_id": 10
}
```

---

### 82. Metric Exemplars

Exemplar digunakan untuk menghubungkan histogram bucket dengan trace contoh.

Harus sampled dan aman.

---

### 83. Sampling Types

```text
RANDOM
RATE_LIMITED
TAIL_BASED
ERROR_BIASED
LATENCY_BIASED
TENANT_COHORT
DEPLOYMENT_CANARY
```

---

### 84. Random Sampling

Contoh:

```text
1% request traces
```

---

### 85. Rate-Limited Sampling

Contoh:

```text
maximum 100 traces/minute/service
```

---

### 86. Tail-Based Sampling

Keputusan sampling setelah operation selesai.

Prioritaskan:

- slow;
- error;
- timeout;
- rare endpoint.

---

### 87. Error-Biased Sampling

Contoh:

```text
100% errors
5% success
```

---

### 88. Latency-Biased Sampling

Contoh:

```text
100% > p99 threshold
20% > p95 threshold
1% normal
```

---

### 89. Tenant Cohort Sampling

Gunakan cohort, bukan semua tenant sebagai label pada raw telemetry.

---

### 90. Sampling Policy Fields

```text
code
telemetry_type
matchers
sample_rate
maximum_per_minute
priority
effective_from
enabled
```

---

### 91. Sampling Policy Versioning

Perubahan sample rate harus:

- versioned;
- audited;
- annotated;
- dievaluasi dampaknya pada SLI.

---

### 92. SLI and Sampling

SLI numerator/denominator tidak boleh berasal dari sampled data bila sampling mengubah representasi secara tidak terkontrol.

Gunakan unsampled counters untuk SLI.

---

### 93. Aggregation

Aggregation worker menghasilkan:

```text
count
sum
min
max
avg
p50
p90
p95
p99
rate
ratio
```

---

### 94. Percentile Calculation

Percentile sebaiknya berasal dari histogram bucket atau mergeable sketch.

Jangan average percentile.

---

### 95. Rollup

Rollup levels:

```text
1m
5m
15m
1h
1d
```

---

### 96. Aggregation Dimensions

Aggregation dapat mengurangi dimension.

Contoh:

```text
raw: route + tenant + module
rollup: route + module
daily: module only
```

---

### 97. Metric Expiration

Metric series yang tidak aktif harus dapat expired.

---

### 98. Stale Metric

Jika producer berhenti mengirim:

```text
metric_stale = true
```

UNKNOWN harus dibedakan dari zero.

---

### 99. Data Quality Metrics

```text
performance_metric_received_total
performance_metric_dropped_total
performance_metric_invalid_total
performance_metric_stale_total
performance_cardinality_rejected_total
performance_export_failure_total
performance_clock_skew_total
```

---

### 100. Clock Skew Detection

Jika event timestamp terlalu jauh dari ingestion time:

- flag;
- exclude dari baseline bila perlu;
- metric increment;
- investigate time sync.

---

### 101. Exporter Health

Metric:

```text
telemetry_export_success_total
telemetry_export_failure_total
telemetry_export_queue_depth
telemetry_export_lag_seconds
```

---

### 102. Backpressure

Jika exporter lambat:

- bounded queue;
- prioritize critical metrics;
- drop low-priority debug telemetry;
- preserve SLI counters;
- alert.

---

### 103. Priority Classes

```text
P0_SLI_SECURITY
P1_ERRORS_LATENCY
P2_OPERATIONAL
P3_DETAIL
P4_DEBUG
```

---

### 104. Instrumentation Overhead Budget

Target awal:

```text
CPU overhead < 1–2%
memory overhead < 1–2%
request latency overhead < 5 ms
```

---

### 105. Overhead Measurement

Metric:

```text
instrumentation_duration_seconds
telemetry_queue_memory_bytes
telemetry_export_cpu_seconds
```

---

### 106. Feature Flag

Instrumentation detail dapat dikontrol dengan feature flag.

Contoh:

```text
PERF_HTTP_ENABLED
PERF_DB_ENABLED
PERF_QUEUE_ENABLED
PERF_RUM_ENABLED
PERF_PROFILING_ENABLED
```

---

### 107. Dynamic Instrumentation

Dynamic instrumentation hanya untuk diagnostic terbatas.

Wajib:

- approval;
- expiry;
- target scope;
- overhead monitor;
- audit.

---

### 108. Multi-Tenant Instrumentation

Per-tenant metrics harus dibatasi.

Strategi:

- top-N;
- selected tenants;
- cohort;
- aggregate;
- on-demand diagnostic.

---

### 109. Tenant Performance Registry

Field:

```text
tenant_id
monitoring_tier
sampling_policy
slo_profile
capacity_profile
enabled
```

---

### 110. Monitoring Tiers

```text
STANDARD
ENHANCED
REGULATED
DIAGNOSTIC
```

---

### 111. STANDARD

Aggregate dan basic tenant metrics.

---

### 112. ENHANCED

Lebih banyak breakdown dan retention.

---

### 113. REGULATED

Tambahan audit dan isolation.

---

### 114. DIAGNOSTIC

Temporary high-detail monitoring dengan expiry.

---

### 115. Instrumentation Ownership

Setiap instrumentation point memiliki:

- owner;
- metric codes;
- overhead budget;
- privacy classification;
- test coverage;
- review date.

---

### 116. Instrumentation Review

Review saat:

- endpoint baru;
- query baru;
- queue baru;
- integration baru;
- workflow baru;
- release besar;
- performance incident.

---

### 117. Metric Deprecation

Lifecycle:

```text
DRAFT
ACTIVE
DEPRECATED
DISABLED
ARCHIVED
```

---

### 118. Deprecation Rules

Sebelum metric dihapus:

- dashboard migration;
- alert migration;
- SLO migration;
- query migration;
- deprecation window;
- owner approval.

---

### 119. Metric Compatibility

Breaking change membutuhkan metric code/version baru.

---

### 120. Testing Instrumentation

Test types:

```text
unit
integration
load
cardinality
privacy
overhead
failure injection
```

---

### 121. Unit Test Example

```php
public function test_records_http_duration(): void
{
    $metrics = new InMemoryPerformanceRecorder();

    $middleware = new PerformanceHttpMiddleware(
        metrics: $metrics,
        routes: new FixedRouteNormalizer('/patients/{id}')
    );

    $middleware->process(
        TestHttpRequest::get('/patients/103'),
        fn () => TestHttpResponse::ok()
    );

    self::assertTrue(
        $metrics->hasObservation(
            'http_request_duration_seconds',
            ['route' => '/patients/{id}']
        )
    );
}
```

---

### 122. Privacy Test

Test harus memastikan:

- raw URI tidak menjadi label;
- SQL literal tidak tercatat;
- request body tidak terkirim;
- user identity tidak menjadi metric label;
- RUM payload bersih.

---

### 123. Cardinality Test

Generate many dynamic IDs.

Expected:

- normalized route;
- bounded series;
- violation counter jika limit dilewati.

---

### 124. Failure Injection

Simulasikan:

- metric exporter down;
- tracing backend down;
- high queue backlog;
- invalid dimension;
- clock skew;
- slow instrumentation backend.

Application harus tetap berjalan.

---

### 125. Alert Integration

Candidate rules:

```text
telemetry_export_failed
performance_metric_stale
performance_cardinality_limit_exceeded
synthetic_check_failed
database_query_latency_high
queue_wait_time_high
cache_hit_ratio_low
frontend_lcp_degraded
```

---

### 126. Dashboard Integration

Part 2 menyediakan data untuk:

- service RED dashboard;
- resource USE dashboard;
- database dashboard;
- queue dashboard;
- frontend dashboard;
- synthetic dashboard;
- tenant performance dashboard;
- telemetry quality dashboard.

---

### 127. Permission Model

```text
observability.performance.metric.read
observability.performance.metric.manage
observability.performance.instrumentation.read
observability.performance.instrumentation.manage
observability.performance.synthetic.read
observability.performance.synthetic.manage
observability.performance.rum.read
observability.performance.rum.manage
observability.performance.profiling.execute
observability.performance.sampling.manage
observability.performance.tenant.diagnostic
```

---

### 128. Audit Events

```text
OBS_PERF_METRIC_CREATED
OBS_PERF_METRIC_UPDATED
OBS_PERF_METRIC_DEPRECATED
OBS_PERF_INSTRUMENTATION_ENABLED
OBS_PERF_INSTRUMENTATION_DISABLED
OBS_PERF_SAMPLING_CHANGED
OBS_PERF_SYNTHETIC_CREATED
OBS_PERF_SYNTHETIC_UPDATED
OBS_PERF_RUM_CONFIGURATION_CHANGED
OBS_PERF_PROFILING_STARTED
OBS_PERF_PROFILING_STOPPED
OBS_PERF_TENANT_DIAGNOSTIC_ENABLED
```

---

### 129. Security Controls

Framework wajib:

- normalize route;
- sanitize SQL;
- restrict profiling;
- protect RUM payload;
- enforce cardinality budget;
- keep SLI counters unsampled;
- avoid secret/PHI/PII;
- audit dynamic instrumentation;
- tenant/scope isolation;
- bounded exporter queue.

---

### 130. Anti-Pattern

Hindari:

- raw path sebagai label;
- user ID sebagai label;
- one metric per tenant tanpa budget;
- raw SQL metric label;
- histogram tanpa bucket governance;
- average percentile;
- instrumentation blocking request;
- exporter failure menyebabkan application failure;
- 100% trace sampling permanent;
- profiling production tanpa expiry;
- RUM mengirim form data;
- queue depth tanpa oldest age;
- database latency tanpa query code;
- synthetic memakai data pasien nyata.

---

### 131. UAT Part 2

#### Metric Catalog

- [ ] Metric code unik.
- [ ] Unit eksplisit.
- [ ] Owner tersedia.
- [ ] Dimension allowlist bekerja.
- [ ] Cardinality budget tersedia.
- [ ] Deprecation lifecycle bekerja.

#### HTTP & Application

- [ ] Route dinormalisasi.
- [ ] Request duration tercatat.
- [ ] Status class tercatat.
- [ ] In-flight tercatat.
- [ ] Exporter failure tidak menggagalkan request.
- [ ] Overhead memenuhi target.

#### Database

- [ ] Query code tersedia.
- [ ] Duration tercatat.
- [ ] Error tercatat.
- [ ] SQL literal tidak bocor.
- [ ] Pool metrics tersedia.
- [ ] Slow query dapat dikorelasikan ke trace.

#### Cache, Queue, Scheduler

- [ ] Cache hit/miss tercatat.
- [ ] Queue depth tercatat.
- [ ] Oldest message age tercatat.
- [ ] Queue wait tercatat.
- [ ] Job duration tercatat.
- [ ] Schedule delay tercatat.

#### Workflow & Integration

- [ ] Workflow duration tercatat.
- [ ] Step duration tercatat.
- [ ] Provider latency tercatat.
- [ ] Retry/timeout tercatat.
- [ ] Circuit state tersedia.
- [ ] Business transaction metric memiliki owner.

#### Frontend, RUM, Synthetic

- [ ] Web Vitals diterima.
- [ ] Payload RUM disanitasi.
- [ ] Sampling RUM bekerja.
- [ ] Synthetic check berjalan.
- [ ] Synthetic test account aman.
- [ ] Failed synthetic menghasilkan signal.

#### Sampling & Quality

- [ ] SLI counters tidak disampling.
- [ ] Error-biased sampling bekerja.
- [ ] Latency-biased sampling bekerja.
- [ ] Invalid metric ditolak.
- [ ] Stale metric terdeteksi.
- [ ] Clock skew terdeteksi.
- [ ] Backpressure melindungi critical telemetry.

#### Security

- [ ] Token/password tidak tercatat.
- [ ] Tenant isolation bekerja.
- [ ] Profiling membutuhkan permission.
- [ ] Diagnostic mode memiliki expiry.
- [ ] Sampling change diaudit.
- [ ] Cardinality violation tercatat.

---

### 132. Definition of Done Part 2

Part 2 dianggap selesai bila:

- [ ] Metric Catalog tersedia;
- [ ] naming convention tersedia;
- [ ] unit rules tersedia;
- [ ] dimension governance tersedia;
- [ ] cardinality budget tersedia;
- [ ] instrumentation contract tersedia;
- [ ] HTTP instrumentation tersedia;
- [ ] database instrumentation tersedia;
- [ ] cache instrumentation tersedia;
- [ ] queue instrumentation tersedia;
- [ ] scheduler instrumentation tersedia;
- [ ] workflow instrumentation tersedia;
- [ ] integration instrumentation tersedia;
- [ ] storage/search/report instrumentation tersedia;
- [ ] frontend telemetry tersedia;
- [ ] RUM policy tersedia;
- [ ] synthetic monitoring tersedia;
- [ ] profiling hooks tersedia;
- [ ] sampling policy tersedia;
- [ ] aggregation/rollup tersedia;
- [ ] data quality metrics tersedia;
- [ ] overhead budget tersedia;
- [ ] tenant monitoring tiers tersedia;
- [ ] permission dan audit tersedia;
- [ ] UAT tersedia.

---

### 133. Rencana Part Berikutnya

#### Part 3

Baseline engine, anomaly detection, regression detection, SLI/SLO calculation, error budget, burn rate, capacity forecasting, performance analysis, cross-signal correlation, profiling analysis, dan reporting.

#### Part 4

HTTP API, controllers, middleware, database schema, scheduler, alert integration, dashboard APIs, audit, security controls, Apache/XAMPP routing, dan sequence diagram.

#### Part 5

Reference implementation, sample metrics/SLO, migration, deployment, load testing, simulations, operational runbook, final UAT, Definition of Done, roadmap, dan merge guidance.

---

## Bagian III — Baseline Engine, Anomaly Detection, Regression, SLI/SLO, Capacity Forecasting, Correlation & Reporting

### 1. Executive Summary

Part 3 mendefinisikan intelligence layer untuk Performance Monitoring Framework.

Bagian ini menetapkan:

- baseline engine;
- baseline quality;
- anomaly detection;
- regression detection;
- deployment comparison;
- SLI calculation;
- SLO evaluation;
- error budget;
- multi-window burn rate;
- capacity forecasting;
- bottleneck analysis;
- cross-signal correlation;
- profiling analysis;
- recommendation generation;
- performance reporting;
- UAT.

Tujuan utamanya adalah mengubah telemetry mentah menjadi keputusan operasional.

```text
Telemetry
→ Baseline
→ Compare
→ Detect
→ Diagnose
→ Prioritize
→ Improve
→ Verify
```

---

### 2. Analysis Architecture

```text
Metrics / Traces / Logs / Profiles / Deployments
                    │
                    ▼
             Normalization Layer
                    │
                    ▼
               Baseline Engine
                    │
        ┌───────────┼───────────┐
        ▼           ▼           ▼
   Anomaly       Regression    SLI/SLO
   Detection     Detection     Evaluation
        │           │           │
        └───────────┼───────────┘
                    ▼
            Correlation Engine
                    │
        ┌───────────┼───────────┐
        ▼           ▼           ▼
 Capacity       Bottleneck    Reporting
 Forecast       Analysis      & Alerting
```

---

### 3. Baseline Engine

Baseline Engine menghitung expected normal behavior.

Input:

```text
metric series
dimensions
time window
seasonality
deployment annotations
maintenance annotations
incident annotations
workload level
```

Output:

```text
expected value
upper bound
lower bound
quality status
confidence
sample count
baseline version
```

---

### 4. Baseline Definition

Field minimum:

```text
baseline_id
metric_code
scope
dimensions
baseline_type
window
seasonality
aggregation
minimum_samples
confidence_level
exclusions
effective_from
version
status
owner
```

---

### 5. Baseline Types

```text
STATIC
ROLLING
SEASONAL
DEPLOYMENT
TENANT
COHORT
WORKLOAD_NORMALIZED
```

---

### 6. Static Baseline

Menggunakan fixed threshold.

Contoh:

```text
http p95 <= 500 ms
DB pool utilization <= 80%
queue wait <= 30 s
```

---

### 7. Rolling Baseline

Menggunakan historical moving window.

Contoh:

```text
median 7 hari terakhir
p95 28 hari terakhir
```

---

### 8. Seasonal Baseline

Membandingkan pola yang sama.

Contoh:

```text
Senin 09:00 dibanding Senin 09:00 sebelumnya
```

---

### 9. Deployment Baseline

Membandingkan pre-deployment dan post-deployment.

---

### 10. Tenant Baseline

Membandingkan tenant terhadap historical behavior sendiri.

---

### 11. Cohort Baseline

Tenant dibandingkan dengan cohort serupa.

Contoh cohort:

```text
small clinic
medium hospital
enterprise hospital
```

---

### 12. Workload-Normalized Baseline

Performance dinormalisasi terhadap workload.

Contoh:

```text
latency per 100 RPS
CPU per 1.000 requests
DB time per transaction
```

---

### 13. Baseline Window

Supported windows:

```text
1h
6h
24h
7d
14d
28d
90d
```

---

### 14. Minimum Sample Requirement

Baseline tidak valid bila sample terlalu sedikit.

Field:

```text
minimum_sample_count
minimum_active_periods
minimum_distinct_days
```

---

### 15. Baseline Quality States

```text
VALID
INSUFFICIENT_DATA
STALE
ANOMALOUS_HISTORY
MAINTENANCE_AFFECTED
INCIDENT_AFFECTED
DEPLOYMENT_AFFECTED
LOW_CONFIDENCE
```

---

### 16. Baseline Exclusions

Exclude window yang berisi:

- maintenance;
- outage;
- load test;
- migration;
- synthetic spike;
- known data corruption;
- telemetry gap;
- incident;
- emergency profiling.

---

### 17. Baseline Recalculation

Trigger:

- scheduled;
- deployment;
- policy change;
- significant workload shift;
- tenant tier change;
- data quality recovery.

---

### 18. Baseline Versioning

Baseline wajib versioned.

Field:

```text
version
generated_at
effective_from
source_window
algorithm
parameters
```

---

### 19. Baseline Drift

Drift adalah perubahan gradual pada normal behavior.

Metric:

```text
baseline_drift_ratio
baseline_drift_absolute
```

---

### 20. Drift Threshold

Contoh:

```text
rolling p95 meningkat 10% selama 14 hari
```

---

### 21. Anomaly Detection

Anomaly adalah penyimpangan signifikan dari expected behavior.

Jenis:

```text
POINT_ANOMALY
CONTEXTUAL_ANOMALY
COLLECTIVE_ANOMALY
TREND_ANOMALY
SEASONAL_ANOMALY
```

---

### 22. Point Anomaly

Satu titik jauh dari baseline.

---

### 23. Contextual Anomaly

Nilai abnormal hanya dalam konteks tertentu.

Contoh:

```text
CPU 70% normal saat peak
CPU 70% abnormal saat low traffic
```

---

### 24. Collective Anomaly

Rangkaian titik membentuk pola abnormal.

---

### 25. Trend Anomaly

Perubahan arah atau slope yang tidak normal.

---

### 26. Seasonal Anomaly

Pola tidak sesuai seasonality historis.

---

### 27. Anomaly Detection Methods

Initial methods:

```text
STATIC_THRESHOLD
Z_SCORE
ROBUST_Z_SCORE
IQR
MOVING_AVERAGE_DEVIATION
EWMA
PERCENTILE_BAND
SEASONAL_COMPARISON
RATE_OF_CHANGE
```

---

### 28. Static Threshold

Contoh:

```text
queue depth > 1.000
```

---

### 29. Z-Score

Formula:

```text
z = (x - mean) / standard_deviation
```

Kurang tahan terhadap outlier.

---

### 30. Robust Z-Score

Menggunakan median dan MAD.

Lebih cocok untuk telemetry dengan outlier.

---

### 31. IQR

Anomaly jika:

```text
x < Q1 - 1.5 × IQR
atau
x > Q3 + 1.5 × IQR
```

---

### 32. EWMA

Exponentially Weighted Moving Average cocok untuk perubahan gradual.

---

### 33. Percentile Band

Band dapat dibuat dari historical percentile.

Contoh:

```text
lower = p5
upper = p95
```

---

### 34. Rate of Change

Mendeteksi perubahan cepat.

Contoh:

```text
queue depth naik 300% dalam 10 menit
```

---

### 35. Anomaly Score

Normalize:

```text
0.0–1.0
```

Interpretasi awal:

```text
0.0–0.4 normal
0.4–0.7 suspicious
0.7–0.9 anomalous
0.9–1.0 critical
```

---

### 36. Anomaly Confidence

Confidence dipengaruhi oleh:

- sample count;
- baseline quality;
- telemetry quality;
- seasonality fit;
- dimension stability.

---

### 37. Anomaly Suppression

Suppress saat:

- maintenance;
- load test;
- known deployment warmup;
- active incident;
- insufficient data.

---

### 38. Anomaly Persistence

Alert tidak boleh berdasarkan satu sample kecuali critical.

Gunakan:

```text
minimum duration
minimum samples
hysteresis
```

---

### 39. Anomaly Event

Field:

```text
anomaly_id
metric_code
scope
dimensions
observed_value
expected_value
lower_bound
upper_bound
score
confidence
detected_at
status
```

---

### 40. Anomaly States

```text
OPEN
ACKNOWLEDGED
RESOLVED
SUPPRESSED
FALSE_POSITIVE
```

---

### 41. Regression Detection

Regression adalah penurunan kinerja dibanding reference.

Reference dapat berupa:

```text
previous deployment
control group
baseline period
canary
release candidate
historical best
```

---

### 42. Regression Types

```text
LATENCY
ERROR_RATE
THROUGHPUT
CPU
MEMORY
DATABASE
QUEUE
CACHE
FRONTEND
```

---

### 43. Regression Rule

Gunakan absolute dan relative threshold.

Contoh:

```text
relative increase > 20%
and
absolute increase > 100 ms
and
sample count >= 1.000
```

---

### 44. Statistical Significance

Regression dapat memakai:

- confidence interval;
- Mann–Whitney U;
- bootstrap comparison;
- proportion test.

Initial implementation boleh memakai threshold + sample guard.

---

### 45. Regression Comparison Window

Contoh:

```text
before: 30 minutes
after: 30 minutes
warmup exclusion: 5 minutes
```

---

### 46. Deployment Warmup

Exclude initial warmup jika:

- cache warming;
- JIT/process startup;
- connection pool initialization;
- index loading.

---

### 47. Canary Comparison

Bandingkan:

```text
canary vs control
```

dengan workload sebanding.

---

### 48. Regression Score

Factors:

```text
magnitude
confidence
affected traffic
SLO impact
tenant impact
duration
```

---

### 49. Regression Severity

```text
INFO
MINOR
MAJOR
CRITICAL
```

---

### 50. Regression Decision

Output:

```text
PASS
WARN
FAIL
INCONCLUSIVE
```

---

### 51. Automatic Rollback Signal

Automatic rollback hanya boleh dipertimbangkan jika:

- regression confidence tinggi;
- impact critical;
- guardrails disetujui;
- rollback aman;
- no conflicting incident.

---

### 52. SLI Calculation Engine

SLI Engine menghitung:

```text
good events
total events
bad events
valid events
excluded events
```

---

### 53. SLI Definition

Field:

```text
sli_code
name
service
metric_source
good_event_query
total_event_query
window
dimensions
exclusions
owner
version
status
```

---

### 54. Request Availability SLI

```text
good =
HTTP requests with status < 500

total =
all valid HTTP requests
```

---

### 55. Request Latency SLI

```text
good =
successful requests <= 500 ms

total =
all valid successful requests
```

---

### 56. Queue Delay SLI

```text
good =
jobs started <= 30 seconds

total =
all eligible jobs
```

---

### 57. Freshness SLI

```text
good =
records synchronized <= 5 minutes
```

---

### 58. Workflow Completion SLI

```text
good =
workflow completed within target
```

---

### 59. SLI Exclusions

Exclude:

- synthetic test if not part of contract;
- canceled user operation;
- invalid request;
- maintenance;
- tenant-requested pause;
- internal health checks.

Exclusion harus terdokumentasi.

---

### 60. SLO Definition

Field:

```text
slo_code
sli_code
target
window
evaluation_period
error_budget_policy
owner
effective_from
version
status
```

---

### 61. SLO Evaluation

Output:

```text
attainment
target
error_budget_total
error_budget_used
error_budget_remaining
burn_rate
status
```

---

### 62. SLO Status

```text
HEALTHY
AT_RISK
BREACHED
NO_DATA
```

---

### 63. Error Budget Calculation

```text
allowed_bad_events =
total_events × (1 - target)
```

---

### 64. Error Budget Remaining

```text
remaining =
allowed_bad_events - actual_bad_events
```

---

### 65. Burn Rate

```text
burn_rate =
actual_bad_event_rate /
allowed_bad_event_rate
```

---

### 66. Multi-Window Burn Rate

Example policy:

| Short Window | Long Window | Burn Rate | Action |
|---|---|---:|---|
| 5m | 1h | 14.4x | page |
| 30m | 6h | 6x | urgent |
| 2h | 1d | 3x | ticket |
| 6h | 3d | 1x | review |

---

### 67. Error Budget Policy

Policy dapat menentukan:

```text
freeze releases
require review
increase testing
reduce change rate
prioritize reliability work
```

---

### 68. SLO Hierarchy

```text
Platform
→ Service
→ Module
→ Endpoint
→ Tenant Contract
```

---

### 69. Composite SLO

Composite SLO dapat menggabungkan beberapa SLI.

Gunakan hati-hati agar tidak menutupi masalah.

---

### 70. SLO Review

Review saat:

- target terlalu longgar;
- target terlalu ketat;
- workload berubah;
- contract berubah;
- architecture berubah;
- telemetry berubah.

---

### 71. Capacity Forecasting

Forecast memproyeksikan kapan resource mencapai threshold.

Input:

```text
historical utilization
growth rate
seasonality
planned onboarding
campaign
deployment changes
capacity changes
```

---

### 72. Forecast Methods

Initial methods:

```text
LINEAR_TREND
MOVING_AVERAGE
SEASONAL_TREND
EXPONENTIAL_SMOOTHING
PERCENTILE_PEAK
```

---

### 73. Time to Exhaustion

```text
time_to_exhaustion =
(capacity - current_usage) / growth_rate
```

---

### 74. Capacity Domains

```text
CPU
MEMORY
DISK
DB_CONNECTION
QUEUE_WORKER
CACHE
NETWORK
STORAGE
SEARCH_INDEX
```

---

### 75. Capacity Forecast Output

```text
current_usage
capacity
headroom
growth_rate
forecast_7d
forecast_30d
forecast_90d
estimated_exhaustion_at
confidence
```

---

### 76. Planned Capacity Events

Annotations:

```text
new tenant onboarding
data migration
campaign
feature launch
hardware upgrade
database resize
```

---

### 77. Capacity Risk States

```text
SAFE
WATCH
AT_RISK
CRITICAL
UNKNOWN
```

---

### 78. Capacity Threshold

Contoh:

```text
WATCH = projected > 75% within 30 days
AT_RISK = projected > 85% within 14 days
CRITICAL = projected > 95% within 7 days
```

---

### 79. Forecast Confidence

Dipengaruhi oleh:

- history length;
- seasonality;
- data quality;
- workload stability;
- planned events.

---

### 80. Bottleneck Analysis

Bottleneck analysis mengidentifikasi component paling membatasi throughput atau latency.

---

### 81. Bottleneck Signals

```text
high utilization
high saturation
increasing wait time
queue buildup
lock contention
low cache hit
slow dependency
memory pressure
```

---

### 82. Critical Path Analysis

Gunakan trace untuk menghitung:

```text
total duration
self time
child time
dependency time
database time
queue wait
```

---

### 83. Component Contribution

```text
component_contribution =
component_duration / total_duration
```

---

### 84. Top Bottleneck Report

Output:

```text
component
operation
contribution
frequency
affected traffic
trend
owner
```

---

### 85. Database Bottleneck Analysis

Signals:

- query p95;
- lock wait;
- rows examined;
- pool wait;
- deadlock;
- buffer hit;
- slow query frequency.

---

### 86. Queue Bottleneck Analysis

Signals:

- oldest age;
- depth;
- worker utilization;
- processing time;
- retry rate;
- dead-letter.

---

### 87. Cache Bottleneck Analysis

Signals:

- hit ratio drop;
- eviction spike;
- rebuild latency;
- stampede;
- memory saturation.

---

### 88. Dependency Bottleneck Analysis

Signals:

- provider p95;
- timeout;
- retry;
- circuit open;
- contribution to request duration.

---

### 89. Cross-Signal Correlation

Correlation menghubungkan:

```text
metric
trace
log
deployment
incident
configuration change
tenant workload
```

---

### 90. Correlation Keys

```text
service
module
route
deployment_version
tenant cohort
time window
trace exemplar
```

---

### 91. Correlation Rules

Contoh:

```text
latency spike
+
DB query p95 spike
+
lock wait spike
=
database contention candidate
```

---

### 92. Correlation Confidence

Factors:

```text
temporal overlap
dimension overlap
magnitude
historical association
trace evidence
```

---

### 93. Root Cause Candidate

Framework boleh menghasilkan candidate, bukan final truth.

Output:

```text
candidate
confidence
evidence
affected scope
recommended checks
```

---

### 94. Correlation Event

```text
correlation_id
trigger_signal
related_signals
time_window
confidence
candidate_cause
status
```

---

### 95. Profiling Analysis

Profiling analysis mengubah sampled profile menjadi:

```text
hot functions
CPU contribution
memory allocation
call count
I/O wait
comparison by release
```

---

### 96. Flame Graph

Flame graph dapat digunakan untuk:

- CPU;
- wall time;
- memory allocation.

---

### 97. Hot Path

Hot path adalah call chain dengan contribution tinggi.

---

### 98. Self Time

Self time adalah waktu function tanpa child calls.

---

### 99. Inclusive Time

Inclusive time mencakup child calls.

---

### 100. Profile Comparison

Compare:

```text
before vs after
release A vs B
canary vs control
normal vs incident
```

---

### 101. Profile Regression

Contoh:

```text
function allocation +40%
CPU self time +25%
call count +3x
```

---

### 102. Profiling Recommendation

Recommendation dapat berupa:

- reduce repeated query;
- batch operation;
- cache lookup;
- remove N+1;
- reduce serialization;
- optimize loop;
- avoid large object allocation.

Harus tetap diverifikasi oleh engineer.

---

### 103. Performance Recommendation Engine

Recommendation sources:

```text
static rules
correlation rules
capacity forecast
regression analysis
profiling analysis
```

---

### 104. Recommendation Fields

```text
recommendation_id
category
title
evidence
confidence
impact
effort
owner
status
```

---

### 105. Recommendation Priority

```text
priority =
impact × confidence / effort
```

Formula final configurable.

---

### 106. Recommendation States

```text
OPEN
ACCEPTED
IN_PROGRESS
VERIFIED
REJECTED
STALE
```

---

### 107. Verification

Recommendation dianggap verified setelah:

- change deployed;
- comparison window selesai;
- metric membaik;
- no harmful side effect;
- result documented.

---

### 108. Performance Reporting

Report types:

```text
DAILY_OPERATIONAL
WEEKLY_REGRESSION
MONTHLY_CAPACITY
QUARTERLY_SLO
RELEASE_COMPARISON
TENANT_PERFORMANCE
INCIDENT_PERFORMANCE
```

---

### 109. Daily Operational Report

Isi:

- top degraded services;
- active anomalies;
- SLO risk;
- saturation;
- queue backlog;
- telemetry gaps.

---

### 110. Weekly Regression Report

Isi:

- release regressions;
- top slow endpoints;
- top slow queries;
- memory/CPU changes;
- unresolved bottlenecks;
- optimization results.

---

### 111. Monthly Capacity Report

Isi:

- current utilization;
- 30/90 day forecast;
- headroom;
- growth;
- required action;
- owner.

---

### 112. Quarterly SLO Report

Isi:

- attainment;
- error budget;
- breaches;
- exclusions;
- target changes;
- reliability actions.

---

### 113. Release Comparison Report

Isi:

```text
baseline version
new version
traffic comparison
latency delta
error delta
resource delta
regression status
recommendation
```

---

### 114. Tenant Performance Report

Wajib tenant isolation.

Isi:

- tenant SLO;
- latency;
- workload;
- capacity profile;
- outlier status;
- fairness indicators.

---

### 115. Report Evidence

Report harus menyimpan:

```text
generated_at
data_window
metric versions
baseline versions
exclusions
query parameters
owner
```

---

### 116. Reporting Retention

Mengikuti SSOT-OBS-08.

Summary report dapat disimpan lebih lama daripada raw metrics.

---

### 117. Dashboard Integration

Dashboard intelligence:

- baseline band;
- anomaly score;
- deployment comparison;
- SLO attainment;
- error budget;
- burn rate;
- capacity forecast;
- bottleneck ranking;
- correlation evidence;
- recommendation backlog.

---

### 118. Alert Integration

Alert candidate:

```text
performance_anomaly_detected
performance_regression_failed
slo_burn_rate_high
capacity_exhaustion_forecast
database_bottleneck_detected
queue_bottleneck_detected
telemetry_quality_low
```

---

### 119. Incident Integration

Incident candidate bila:

- SLO burn sangat tinggi;
- regression critical;
- capacity exhaustion imminent;
- broad anomaly;
- telemetry loss menghambat diagnosis;
- critical bottleneck berdampak bisnis.

---

### 120. Permission Model

```text
observability.performance.baseline.read
observability.performance.baseline.manage
observability.performance.anomaly.read
observability.performance.anomaly.manage
observability.performance.regression.read
observability.performance.slo.read
observability.performance.slo.manage
observability.performance.capacity.read
observability.performance.capacity.manage
observability.performance.correlation.read
observability.performance.profile.read
observability.performance.recommendation.manage
observability.performance.report.read
observability.performance.report.export
```

---

### 121. Audit Events

```text
OBS_PERF_BASELINE_CREATED
OBS_PERF_BASELINE_UPDATED
OBS_PERF_BASELINE_RECALCULATED
OBS_PERF_ANOMALY_SUPPRESSED
OBS_PERF_REGRESSION_OVERRIDDEN
OBS_PERF_SLI_CREATED
OBS_PERF_SLO_CREATED
OBS_PERF_SLO_UPDATED
OBS_PERF_ERROR_BUDGET_POLICY_CHANGED
OBS_PERF_CAPACITY_FORECAST_UPDATED
OBS_PERF_RECOMMENDATION_ACCEPTED
OBS_PERF_REPORT_EXPORTED
```

---

### 122. Security & Privacy

Framework wajib:

- tenant/scope filtering;
- restricted profile access;
- no raw PHI/PII;
- no raw query literals;
- bounded export;
- audit manual override;
- protect report links;
- classify profiling data;
- expire temporary analysis workspace.

---

### 123. Manual Override

Override dapat dilakukan untuk:

- false positive;
- known anomaly;
- approved maintenance;
- baseline correction;
- release exception.

Override wajib:

- reason;
- owner;
- expiry;
- audit;
- review.

---

### 124. False Positive Handling

False positive harus menjadi feedback untuk:

- threshold;
- baseline;
- seasonality;
- dimension;
- suppression;
- minimum duration.

---

### 125. Data Quality Gate

Anomaly/regression/SLO tidak boleh dianggap valid jika:

- telemetry stale;
- sample tidak cukup;
- clock skew tinggi;
- exporter failure;
- dimension mismatch.

---

### 126. Unknown State

Jika quality gate gagal:

```text
status = UNKNOWN
```

Bukan HEALTHY.

---

### 127. Performance Analysis Workspace

Diagnostic analysis dapat memakai temporary workspace.

Wajib:

- bounded;
- scoped;
- encrypted;
- auto-expire;
- audited.

---

### 128. Anti-Pattern

Hindari:

- baseline dari incident window;
- threshold hanya relative;
- SLO dari sampled counter;
- error budget tanpa exclusions;
- regression tanpa workload normalization;
- automatic rollback dengan confidence rendah;
- forecast tanpa seasonality;
- correlation dianggap root cause final;
- profiling recommendation tanpa verification;
- report tanpa data window;
- UNKNOWN dianggap healthy;
- manual override tanpa expiry.

---

### 129. UAT Part 3

#### Baseline Engine

- [ ] Static baseline bekerja.
- [ ] Rolling baseline bekerja.
- [ ] Seasonal baseline bekerja.
- [ ] Deployment baseline bekerja.
- [ ] Exclusion bekerja.
- [ ] Quality status tersedia.
- [ ] Versioning bekerja.

#### Anomaly Detection

- [ ] Point anomaly terdeteksi.
- [ ] Trend anomaly terdeteksi.
- [ ] Minimum duration bekerja.
- [ ] Confidence tersedia.
- [ ] Suppression bekerja.
- [ ] False positive dapat ditandai.

#### Regression

- [ ] Before/after comparison bekerja.
- [ ] Absolute threshold bekerja.
- [ ] Relative threshold bekerja.
- [ ] Sample guard bekerja.
- [ ] Warmup exclusion bekerja.
- [ ] Canary comparison bekerja.
- [ ] Result PASS/WARN/FAIL/INCONCLUSIVE tersedia.

#### SLI/SLO

- [ ] Good/total events dihitung.
- [ ] Exclusion diterapkan.
- [ ] SLO attainment dihitung.
- [ ] Error budget dihitung.
- [ ] Burn rate dihitung.
- [ ] Multi-window policy bekerja.
- [ ] NO_DATA state tersedia.

#### Capacity

- [ ] Current headroom dihitung.
- [ ] Growth rate dihitung.
- [ ] 30/90-day forecast tersedia.
- [ ] Planned event dapat dianotasi.
- [ ] Exhaustion date tersedia.
- [ ] Confidence tersedia.

#### Correlation & Profiling

- [ ] Metric-trace correlation bekerja.
- [ ] Deployment annotation terhubung.
- [ ] Bottleneck ranking tersedia.
- [ ] Profile comparison tersedia.
- [ ] Recommendation memiliki evidence.
- [ ] Verification lifecycle bekerja.

#### Reporting

- [ ] Daily report tersedia.
- [ ] Weekly regression report tersedia.
- [ ] Monthly capacity report tersedia.
- [ ] Quarterly SLO report tersedia.
- [ ] Tenant isolation bekerja.
- [ ] Export diaudit.

#### Security & Quality

- [ ] Restricted profiling dibatasi.
- [ ] Unknown state bekerja.
- [ ] Override membutuhkan reason.
- [ ] Override memiliki expiry.
- [ ] Quality gate memblokir keputusan invalid.
- [ ] Temporary workspace auto-expire.

---

### 130. Definition of Done Part 3

Part 3 dianggap selesai bila:

- [ ] Baseline Engine tersedia;
- [ ] baseline types tersedia;
- [ ] baseline quality tersedia;
- [ ] exclusion tersedia;
- [ ] anomaly methods tersedia;
- [ ] anomaly score/confidence tersedia;
- [ ] regression model tersedia;
- [ ] deployment comparison tersedia;
- [ ] SLI Engine tersedia;
- [ ] SLO evaluation tersedia;
- [ ] error budget tersedia;
- [ ] burn rate tersedia;
- [ ] multi-window policy tersedia;
- [ ] capacity forecasting tersedia;
- [ ] bottleneck analysis tersedia;
- [ ] cross-signal correlation tersedia;
- [ ] profiling analysis tersedia;
- [ ] recommendation lifecycle tersedia;
- [ ] report catalog tersedia;
- [ ] permission dan audit tersedia;
- [ ] quality gate tersedia;
- [ ] UAT tersedia.

---

### 131. Rencana Part Berikutnya

#### Part 4

HTTP API, controllers, middleware, database schema, scheduler, alert integration, dashboard APIs, audit, security controls, Apache/XAMPP routing, dan sequence diagram.

#### Part 5

Reference implementation, sample metrics/SLO, migration, deployment, load testing, simulations, operational runbook, final UAT, Definition of Done, roadmap, dan merge guidance.

---

## Bagian IV — HTTP API, Controllers, Middleware, Database Schema, Scheduler, Dashboard, Alerting & Routing

### 1. Executive Summary

Part 4 mendefinisikan interface dan infrastructure untuk Performance Monitoring Framework.

Bagian ini menetapkan:

- HTTP API;
- controller responsibilities;
- request/response contracts;
- middleware order;
- permission;
- tenant/scope isolation;
- metric catalog API;
- baseline API;
- anomaly API;
- regression API;
- SLI/SLO API;
- capacity API;
- dashboard API;
- scheduler jobs;
- database schema;
- alert integration;
- audit integration;
- telemetry;
- error codes;
- Apache/XAMPP routing;
- sequence diagram;
- UAT.

Tujuan utama adalah memastikan Performance Monitoring dapat:

- dikonfigurasi secara konsisten;
- diakses secara aman;
- dihitung terjadwal;
- dikorelasikan dengan deployment dan incident;
- mendukung tenant/scope isolation;
- mengaktifkan dashboard dan alert;
- menyediakan evidence untuk regression, SLO, dan capacity decision.

---

### 2. API Architecture

```text
HTTP Request
    │
    ▼
Security Middleware
    │
    ├── Authentication
    ├── Tenant Context
    ├── Active Scope
    ├── Permission
    ├── Classification
    ├── Rate Limit
    └── Audit Context
    │
    ▼
Controller
    │
    ▼
Application Service
    │
    ├── Metric Catalog Service
    ├── Baseline Service
    ├── Anomaly Service
    ├── Regression Service
    ├── SLI/SLO Service
    ├── Capacity Service
    ├── Correlation Service
    └── Dashboard Service
    │
    ▼
Repositories / Analytics / Telemetry Store
```

---

### 3. Base API Paths

```text
/api/internal/v1/performance/metrics
/api/internal/v1/performance/baselines
/api/internal/v1/performance/anomalies
/api/internal/v1/performance/regressions
/api/internal/v1/performance/slis
/api/internal/v1/performance/slos
/api/internal/v1/performance/capacity
/api/internal/v1/performance/correlations
/api/internal/v1/performance/recommendations
/api/internal/v1/performance/reports
/api/internal/v1/performance/dashboards
```

Semua endpoint internal wajib authentication.

---

### 4. Metric Catalog API

```text
GET    /api/internal/v1/performance/metrics
GET    /api/internal/v1/performance/metrics/{metricCode}
POST   /api/internal/v1/performance/metrics
PUT    /api/internal/v1/performance/metrics/{metricCode}
POST   /api/internal/v1/performance/metrics/{metricCode}/activate
POST   /api/internal/v1/performance/metrics/{metricCode}/deprecate
POST   /api/internal/v1/performance/metrics/{metricCode}/validate-cardinality
```

---

### 5. Baseline API

```text
GET    /api/internal/v1/performance/baselines
GET    /api/internal/v1/performance/baselines/{baselineId}
POST   /api/internal/v1/performance/baselines
PUT    /api/internal/v1/performance/baselines/{baselineId}
POST   /api/internal/v1/performance/baselines/{baselineId}/recalculate
POST   /api/internal/v1/performance/baselines/{baselineId}/activate
POST   /api/internal/v1/performance/baselines/{baselineId}/suspend
GET    /api/internal/v1/performance/baselines/{baselineId}/versions
```

---

### 6. Anomaly API

```text
GET  /api/internal/v1/performance/anomalies
GET  /api/internal/v1/performance/anomalies/{anomalyId}
POST /api/internal/v1/performance/anomalies/{anomalyId}/acknowledge
POST /api/internal/v1/performance/anomalies/{anomalyId}/resolve
POST /api/internal/v1/performance/anomalies/{anomalyId}/suppress
POST /api/internal/v1/performance/anomalies/{anomalyId}/mark-false-positive
GET  /api/internal/v1/performance/anomalies/{anomalyId}/evidence
```

---

### 7. Regression API

```text
GET  /api/internal/v1/performance/regressions
GET  /api/internal/v1/performance/regressions/{regressionId}
POST /api/internal/v1/performance/regressions/compare
POST /api/internal/v1/performance/regressions/{regressionId}/accept
POST /api/internal/v1/performance/regressions/{regressionId}/override
POST /api/internal/v1/performance/regressions/{regressionId}/verify
GET  /api/internal/v1/performance/regressions/{regressionId}/evidence
```

---

### 8. SLI API

```text
GET    /api/internal/v1/performance/slis
GET    /api/internal/v1/performance/slis/{sliCode}
POST   /api/internal/v1/performance/slis
PUT    /api/internal/v1/performance/slis/{sliCode}
POST   /api/internal/v1/performance/slis/{sliCode}/activate
POST   /api/internal/v1/performance/slis/{sliCode}/evaluate
```

---

### 9. SLO API

```text
GET    /api/internal/v1/performance/slos
GET    /api/internal/v1/performance/slos/{sloCode}
POST   /api/internal/v1/performance/slos
PUT    /api/internal/v1/performance/slos/{sloCode}
POST   /api/internal/v1/performance/slos/{sloCode}/activate
POST   /api/internal/v1/performance/slos/{sloCode}/evaluate
GET    /api/internal/v1/performance/slos/{sloCode}/history
GET    /api/internal/v1/performance/slos/{sloCode}/error-budget
```

---

### 10. Capacity API

```text
GET  /api/internal/v1/performance/capacity/forecasts
GET  /api/internal/v1/performance/capacity/forecasts/{forecastId}
POST /api/internal/v1/performance/capacity/forecasts
POST /api/internal/v1/performance/capacity/forecasts/{forecastId}/recalculate
GET  /api/internal/v1/performance/capacity/headroom
GET  /api/internal/v1/performance/capacity/risks
```

---

### 11. Correlation API

```text
GET  /api/internal/v1/performance/correlations
GET  /api/internal/v1/performance/correlations/{correlationId}
POST /api/internal/v1/performance/correlations/analyze
POST /api/internal/v1/performance/correlations/{correlationId}/confirm
POST /api/internal/v1/performance/correlations/{correlationId}/reject
```

---

### 12. Recommendation API

```text
GET  /api/internal/v1/performance/recommendations
GET  /api/internal/v1/performance/recommendations/{recommendationId}
POST /api/internal/v1/performance/recommendations/{recommendationId}/accept
POST /api/internal/v1/performance/recommendations/{recommendationId}/reject
POST /api/internal/v1/performance/recommendations/{recommendationId}/verify
```

---

### 13. Reporting API

```text
GET  /api/internal/v1/performance/reports
POST /api/internal/v1/performance/reports/generate
GET  /api/internal/v1/performance/reports/{reportId}
POST /api/internal/v1/performance/reports/{reportId}/export
```

---

### 14. Dashboard API

```text
GET /api/internal/v1/performance/dashboards/overview
GET /api/internal/v1/performance/dashboards/services
GET /api/internal/v1/performance/dashboards/database
GET /api/internal/v1/performance/dashboards/queues
GET /api/internal/v1/performance/dashboards/frontend
GET /api/internal/v1/performance/dashboards/slo
GET /api/internal/v1/performance/dashboards/capacity
GET /api/internal/v1/performance/dashboards/tenants
GET /api/internal/v1/performance/dashboards/telemetry-quality
```

---

### 15. Common Query Filters

```text
environment
tenant_id
scope_id
module_code
service
metric_code
route
deployment_version
time_from
time_to
aggregation
page
per_page
sort
```

---

### 16. Metric Create Request

```json
{
  "code": "http_request_duration_seconds",
  "name": "HTTP Request Duration",
  "description": "Server-side HTTP latency.",
  "domain": "HTTP_API",
  "type": "HISTOGRAM",
  "unit": "seconds",
  "source": "http_middleware",
  "dimensions": [
    "environment",
    "route",
    "method",
    "status_class"
  ],
  "aggregation": [
    "rate",
    "p50",
    "p95",
    "p99"
  ],
  "buckets": [
    0.005,
    0.01,
    0.025,
    0.05,
    0.1,
    0.25,
    0.5,
    1,
    2.5,
    5,
    10
  ],
  "owner": "platform_operations",
  "sensitivity": "INTERNAL",
  "version": "1.0"
}
```

---

### 17. Baseline Create Request

```json
{
  "metric_code": "http_request_duration_seconds",
  "baseline_type": "SEASONAL",
  "scope": {
    "environment": "production",
    "service": "patient-service",
    "route": "/patients/{id}"
  },
  "window": "28d",
  "seasonality": "day_of_week_hour",
  "aggregation": "p95",
  "minimum_samples": 1000,
  "confidence_level": 0.95,
  "exclusions": [
    "maintenance",
    "incident",
    "load_test"
  ]
}
```

---

### 18. Regression Compare Request

```json
{
  "metric_code": "http_request_duration_seconds",
  "reference": {
    "deployment_version": "2026.07.03"
  },
  "candidate": {
    "deployment_version": "2026.07.04"
  },
  "scope": {
    "environment": "production",
    "service": "patient-service"
  },
  "aggregation": "p95",
  "absolute_threshold": 0.1,
  "relative_threshold": 0.2,
  "minimum_samples": 1000
}
```

---

### 19. SLI Create Request

```json
{
  "code": "patient_api_latency",
  "name": "Patient API Latency",
  "service": "patient-service",
  "metric_source": "http_request_duration_seconds",
  "good_event_query": {
    "route_prefix": "/patients",
    "duration_lte_seconds": 0.5,
    "status_class": "2xx"
  },
  "total_event_query": {
    "route_prefix": "/patients",
    "status_class": [
      "2xx",
      "3xx",
      "4xx",
      "5xx"
    ]
  },
  "window": "30d"
}
```

---

### 20. SLO Create Request

```json
{
  "code": "patient_api_latency_95",
  "sli_code": "patient_api_latency",
  "target": 0.95,
  "window": "30d",
  "evaluation_period": "5m",
  "error_budget_policy": "standard_web_api",
  "effective_from": "2026-07-01"
}
```

---

### 21. Capacity Forecast Request

```json
{
  "resource_type": "DB_CONNECTION",
  "scope": {
    "environment": "production",
    "service": "database-primary"
  },
  "history_window": "90d",
  "forecast_horizon": "90d",
  "method": "SEASONAL_TREND",
  "capacity": 500
}
```

---

### 22. Canonical Success Envelope

```json
{
  "data": {},
  "meta": {
    "request_id": "01J...",
    "generated_at": "2026-07-04T12:00:00Z",
    "data_quality": "VALID"
  }
}
```

---

### 23. Canonical Error Envelope

```json
{
  "error": {
    "code": "PERFORMANCE_BASELINE_INSUFFICIENT_DATA",
    "message": "The baseline cannot be calculated because the sample size is insufficient.",
    "details": []
  },
  "meta": {
    "request_id": "01J...",
    "timestamp": "2026-07-04T12:00:00Z"
  }
}
```

---

### 24. HTTP Status Mapping

| Kondisi | HTTP |
|---|---:|
| success | 200 |
| created | 201 |
| accepted async | 202 |
| validation | 422 |
| unauthenticated | 401 |
| forbidden | 403 |
| not found | 404 |
| conflict | 409 |
| rate limited | 429 |
| insufficient data | 422 |
| unavailable | 503 |
| unexpected | 500 |

---

### 25. Controller Responsibilities

Controller hanya:

- parse request;
- validate DTO;
- resolve tenant/scope;
- authorize;
- call application service;
- project response;
- map exception;
- create audit context.

Controller tidak boleh:

- menghitung percentile sendiri;
- menjalankan SQL langsung;
- mengubah baseline tanpa service;
- mengakses raw profile langsung;
- mem-bypass quality gate;
- mem-bypass tenant filter;
- membuat keputusan rollback sendiri.

---

### 26. MetricCatalogController Example

```php
final class MetricCatalogController
{
    public function __construct(
        private readonly MetricCatalogServiceInterface $catalog,
        private readonly PerformanceContextFactory $contexts,
        private readonly MetricProjector $projector
    ) {
    }

    public function create(
        HttpRequest $request
    ): HttpResponse {
        $context = $this->contexts->fromRequest($request);

        $metric = $this->catalog->create(
            MetricCreateCommand::fromArray(
                $request->json()
            ),
            $context
        );

        return JsonResponse::created(
            $this->projector->metric($metric)
        );
    }
}
```

---

### 27. BaselineController Example

```php
final class BaselineController
{
    public function __construct(
        private readonly BaselineServiceInterface $baselines,
        private readonly PerformanceContextFactory $contexts,
        private readonly BaselineProjector $projector
    ) {
    }

    public function recalculate(
        HttpRequest $request,
        string $baselineId
    ): HttpResponse {
        $context = $this->contexts->fromRequest($request);

        $job = $this->baselines->recalculate(
            baselineId: $baselineId,
            context: $context
        );

        return JsonResponse::accepted(
            $this->projector->job($job)
        );
    }
}
```

---

### 28. RegressionController Example

```php
final class RegressionController
{
    public function __construct(
        private readonly RegressionServiceInterface $regressions,
        private readonly PerformanceContextFactory $contexts,
        private readonly RegressionProjector $projector
    ) {
    }

    public function compare(
        HttpRequest $request
    ): HttpResponse {
        $context = $this->contexts->fromRequest($request);

        $result = $this->regressions->compare(
            RegressionCompareCommand::fromArray(
                $request->json()
            ),
            $context
        );

        return JsonResponse::accepted(
            $this->projector->result($result)
        );
    }
}
```

---

### 29. SloController Example

```php
final class SloController
{
    public function __construct(
        private readonly SloServiceInterface $slos,
        private readonly PerformanceContextFactory $contexts,
        private readonly SloProjector $projector
    ) {
    }

    public function errorBudget(
        HttpRequest $request,
        string $sloCode
    ): HttpResponse {
        $context = $this->contexts->fromRequest($request);

        $budget = $this->slos->errorBudget(
            sloCode: $sloCode,
            context: $context
        );

        return JsonResponse::ok(
            $this->projector->errorBudget($budget)
        );
    }
}
```

---

### 30. Application Service Contracts

#### Metric Catalog

```php
interface MetricCatalogServiceInterface
{
    public function create(
        MetricCreateCommand $command,
        PerformanceContext $context
    ): PerformanceMetricDefinition;

    public function update(
        string $metricCode,
        MetricUpdateCommand $command,
        PerformanceContext $context
    ): PerformanceMetricDefinition;

    public function validateCardinality(
        string $metricCode,
        PerformanceContext $context
    ): CardinalityValidationResult;
}
```

---

### 31. Baseline Service

```php
interface BaselineServiceInterface
{
    public function create(
        BaselineCreateCommand $command,
        PerformanceContext $context
    ): PerformanceBaseline;

    public function recalculate(
        string $baselineId,
        PerformanceContext $context
    ): AnalysisJob;

    public function activate(
        string $baselineId,
        PerformanceContext $context
    ): PerformanceBaseline;
}
```

---

### 32. Anomaly Service

```php
interface AnomalyServiceInterface
{
    public function detect(
        AnomalyDetectionCriteria $criteria,
        PerformanceContext $context
    ): array;

    public function suppress(
        string $anomalyId,
        AnomalySuppressionCommand $command,
        PerformanceContext $context
    ): PerformanceAnomaly;

    public function markFalsePositive(
        string $anomalyId,
        string $reason,
        PerformanceContext $context
    ): PerformanceAnomaly;
}
```

---

### 33. Regression Service

```php
interface RegressionServiceInterface
{
    public function compare(
        RegressionCompareCommand $command,
        PerformanceContext $context
    ): RegressionAnalysis;

    public function override(
        string $regressionId,
        RegressionOverrideCommand $command,
        PerformanceContext $context
    ): RegressionAnalysis;

    public function verify(
        string $regressionId,
        PerformanceContext $context
    ): RegressionVerificationResult;
}
```

---

### 34. SLI/SLO Service

```php
interface SliServiceInterface
{
    public function evaluate(
        string $sliCode,
        SliEvaluationWindow $window,
        PerformanceContext $context
    ): SliEvaluation;
}

interface SloServiceInterface
{
    public function evaluate(
        string $sloCode,
        PerformanceContext $context
    ): SloEvaluation;

    public function errorBudget(
        string $sloCode,
        PerformanceContext $context
    ): ErrorBudgetStatus;
}
```

---

### 35. Capacity Service

```php
interface CapacityServiceInterface
{
    public function forecast(
        CapacityForecastCommand $command,
        PerformanceContext $context
    ): CapacityForecast;

    public function risks(
        CapacityRiskCriteria $criteria,
        PerformanceContext $context
    ): array;
}
```

---

### 36. Dashboard Service

```php
interface PerformanceDashboardServiceInterface
{
    public function overview(
        DashboardCriteria $criteria,
        PerformanceContext $context
    ): PerformanceOverview;

    public function serviceDashboard(
        DashboardCriteria $criteria,
        PerformanceContext $context
    ): ServicePerformanceDashboard;

    public function sloDashboard(
        DashboardCriteria $criteria,
        PerformanceContext $context
    ): SloPerformanceDashboard;
}
```

---

### 37. Middleware Order

```text
Request ID
→ Trusted Proxy
→ Security Headers
→ Authentication
→ Rate Limit
→ Tenant Context
→ Active Scope
→ Permission
→ Performance Classification
→ Audit Context
→ Controller
```

---

### 38. Authentication

Semua endpoint internal membutuhkan authenticated principal.

Service account wajib memiliki:

- identity;
- scoped credential;
- explicit permission;
- rotation;
- audit.

---

### 39. Tenant Context

Tenant context wajib tersedia untuk request tenant-aware.

Cross-tenant request membutuhkan permission khusus.

---

### 40. Active Scope

Jika platform memiliki organization/clinic/facility scope:

```text
scope_id
```

harus divalidasi sebelum dashboard, report, profile, atau export.

---

### 41. Permission Middleware

Permission utama:

```text
observability.performance.read
observability.performance.metric.read
observability.performance.metric.manage
observability.performance.baseline.read
observability.performance.baseline.manage
observability.performance.anomaly.read
observability.performance.anomaly.manage
observability.performance.regression.read
observability.performance.regression.manage
observability.performance.slo.read
observability.performance.slo.manage
observability.performance.capacity.read
observability.performance.capacity.manage
observability.performance.profile.read
observability.performance.report.read
observability.performance.report.export
observability.performance.cross_tenant.read
```

---

### 42. Classification Middleware

Classification middleware membatasi akses ke:

```text
INTERNAL
CONFIDENTIAL
RESTRICTED
SECURITY_RESTRICTED
```

Profiling data dapat memiliki klasifikasi lebih tinggi.

---

### 43. CSRF

Mutation berbasis session wajib CSRF:

- metric create/update;
- baseline create/update;
- baseline recalculation;
- anomaly suppression;
- regression override;
- SLI/SLO create/update;
- capacity forecast create;
- report export;
- profile action.

---

### 44. Rate Limiting

Rekomendasi awal:

| Endpoint | Limit |
|---|---:|
| dashboard read | 120/min/user |
| metric list | 120/min/user |
| metric mutation | 30/hour/user |
| baseline mutation | 30/hour/user |
| baseline recalculate | 20/hour/user |
| regression compare | 20/hour/user |
| SLO evaluate | 60/hour/user |
| report generate | 20/hour/user |
| report export | 10/hour/user |
| profile read | 20/hour/user |

---

### 45. Query Guard

Semua analytics query wajib memiliki:

```text
time range
row/series limit
aggregation
tenant/scope
timeout
```

---

### 46. Expensive Query Policy

Jika query terlalu luas:

- reject;
- require report workflow;
- queue analysis job;
- require approval untuk cross-tenant;
- return estimate.

---

### 47. Scheduler Architecture

```text
Scheduler
    │
    ├── Metric Rollup
    ├── Baseline Recalculation
    ├── Anomaly Detection
    ├── Regression Analysis
    ├── SLI Evaluation
    ├── SLO Evaluation
    ├── Error Budget Calculation
    ├── Capacity Forecasting
    ├── Correlation Analysis
    ├── Recommendation Refresh
    ├── Report Generation
    ├── Data Quality Check
    └── Retention Cleanup
```

---

### 48. Required Scheduler Jobs

```text
performance-metric-rollup
performance-baseline-recalculate
performance-anomaly-detect
performance-regression-analyze
performance-sli-evaluate
performance-slo-evaluate
performance-error-budget-calculate
performance-capacity-forecast
performance-correlation-analyze
performance-recommendation-refresh
performance-report-generate
performance-data-quality-check
performance-analysis-workspace-expire
```

---

### 49. Scheduler Frequency

| Job | Frequency |
|---|---:|
| Metric rollup | every 1–5 minutes |
| Baseline recalculation | hourly/daily |
| Anomaly detection | every 1–5 minutes |
| Regression analysis | after deployment + scheduled |
| SLI evaluation | every 5 minutes |
| SLO evaluation | every 5–15 minutes |
| Error budget | every 5–15 minutes |
| Capacity forecast | daily |
| Correlation analysis | every 5 minutes |
| Recommendation refresh | daily |
| Report generation | daily/weekly/monthly |
| Data quality check | every 5 minutes |
| Workspace expiry | hourly |

---

### 50. Job Locking

Lock key examples:

```text
performance-rollup:{metric}:{window}
performance-baseline:{baseline_id}
performance-anomaly:{metric}:{scope}:{window}
performance-regression:{deployment_id}
performance-slo:{slo_code}:{window}
performance-capacity:{resource}:{scope}
```

---

### 51. Job Idempotency

Idempotency keys:

```text
metric + window + aggregation
baseline_id + source_window + version
regression_id + comparison_window
slo_code + evaluation_window
forecast_id + generated_at_date
```

---

### 52. Job Retry

Retry hanya untuk transient failure.

Permanent validation failure harus:

- status FAILED;
- tidak infinite retry;
- menghasilkan alert;
- menunggu correction.

---

### 53. Job Heartbeat

Long-running job wajib memperbarui:

```text
heartbeat_at
progress_percent
processed_series
processed_samples
```

---

### 54. CLI Commands

```bash
php bin/console performance:rollup
php bin/console performance:baseline:recalculate
php bin/console performance:anomaly:detect
php bin/console performance:regression:analyze --deployment=DEP-001
php bin/console performance:sli:evaluate
php bin/console performance:slo:evaluate
php bin/console performance:capacity:forecast
php bin/console performance:correlation:analyze
php bin/console performance:report:generate --type=daily
php bin/console performance:quality:check
```

---

### 55. Database Schema Overview

Tables:

```text
performance_metric_definitions
performance_metric_dimensions
performance_metric_samples
performance_metric_rollups
performance_baselines
performance_baseline_versions
performance_anomalies
performance_regressions
performance_regression_evidence
performance_sli_definitions
performance_sli_evaluations
performance_slo_definitions
performance_slo_evaluations
performance_error_budgets
performance_capacity_forecasts
performance_correlations
performance_recommendations
performance_reports
performance_deployment_annotations
performance_maintenance_annotations
performance_analysis_jobs
performance_scheduler_runs
```

---

### 56. Table: performance_metric_definitions

```sql
CREATE TABLE performance_metric_definitions (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    code VARCHAR(180) NOT NULL,
    name VARCHAR(255) NOT NULL,
    description VARCHAR(2000) NULL,
    domain_code VARCHAR(60) NOT NULL,
    metric_type VARCHAR(30) NOT NULL,
    unit_code VARCHAR(40) NOT NULL,
    source_code VARCHAR(120) NOT NULL,
    aggregation_json JSON NOT NULL,
    buckets_json JSON NULL,
    owner_reference VARCHAR(150) NOT NULL,
    sensitivity VARCHAR(30) NOT NULL,
    retention_policy_code VARCHAR(150) NOT NULL,
    sli_usage TINYINT(1) NOT NULL DEFAULT 0,
    status VARCHAR(30) NOT NULL DEFAULT 'DRAFT',
    metric_version VARCHAR(20) NOT NULL,
    created_by BIGINT UNSIGNED NOT NULL,
    updated_by BIGINT UNSIGNED NULL,
    created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    updated_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6)
        ON UPDATE CURRENT_TIMESTAMP(6),

    PRIMARY KEY (id),
    UNIQUE KEY uq_performance_metric_code_version (
        code,
        metric_version
    ),
    KEY idx_performance_metric_active (
        status,
        domain_code
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

### 57. Table: performance_metric_dimensions

```sql
CREATE TABLE performance_metric_dimensions (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    metric_definition_id BIGINT UNSIGNED NOT NULL,
    dimension_code VARCHAR(100) NOT NULL,
    description VARCHAR(1000) NULL,
    cardinality_budget INT UNSIGNED NOT NULL,
    sensitivity VARCHAR(30) NOT NULL,
    normalization_rule VARCHAR(255) NULL,
    enabled TINYINT(1) NOT NULL DEFAULT 1,
    created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),

    PRIMARY KEY (id),
    CONSTRAINT fk_performance_metric_dimension
        FOREIGN KEY (metric_definition_id)
        REFERENCES performance_metric_definitions(id)
        ON DELETE CASCADE,

    UNIQUE KEY uq_performance_metric_dimension (
        metric_definition_id,
        dimension_code
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

### 58. Table: performance_metric_samples

```sql
CREATE TABLE performance_metric_samples (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    metric_code VARCHAR(180) NOT NULL,
    occurred_at DATETIME(6) NOT NULL,
    value_double DOUBLE NOT NULL,
    environment VARCHAR(32) NOT NULL,
    tenant_id BIGINT UNSIGNED NULL,
    scope_id BIGINT UNSIGNED NULL,
    module_code VARCHAR(100) NULL,
    service_code VARCHAR(100) NULL,
    dimensions_hash CHAR(64) NOT NULL,
    dimensions_json JSON NOT NULL,
    quality_status VARCHAR(30) NOT NULL DEFAULT 'VALID',
    deployment_version VARCHAR(100) NULL,
    created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),

    PRIMARY KEY (id, occurred_at),
    KEY idx_perf_sample_metric_time (
        metric_code,
        occurred_at
    ),
    KEY idx_perf_sample_scope_time (
        tenant_id,
        scope_id,
        occurred_at
    ),
    KEY idx_perf_sample_dimensions (
        dimensions_hash,
        occurred_at
    )
)
PARTITION BY RANGE COLUMNS (occurred_at) (
    PARTITION p2026_07 VALUES LESS THAN ('2026-08-01'),
    PARTITION p2026_08 VALUES LESS THAN ('2026-09-01'),
    PARTITION pmax VALUES LESS THAN (MAXVALUE)
);
```

---

### 59. Table: performance_metric_rollups

```sql
CREATE TABLE performance_metric_rollups (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    metric_code VARCHAR(180) NOT NULL,
    window_start DATETIME(6) NOT NULL,
    window_end DATETIME(6) NOT NULL,
    resolution_code VARCHAR(20) NOT NULL,
    environment VARCHAR(32) NOT NULL,
    tenant_id BIGINT UNSIGNED NULL,
    scope_id BIGINT UNSIGNED NULL,
    module_code VARCHAR(100) NULL,
    service_code VARCHAR(100) NULL,
    dimensions_hash CHAR(64) NOT NULL,
    dimensions_json JSON NOT NULL,
    sample_count BIGINT UNSIGNED NOT NULL,
    sum_value DOUBLE NULL,
    min_value DOUBLE NULL,
    max_value DOUBLE NULL,
    avg_value DOUBLE NULL,
    p50_value DOUBLE NULL,
    p90_value DOUBLE NULL,
    p95_value DOUBLE NULL,
    p99_value DOUBLE NULL,
    quality_status VARCHAR(30) NOT NULL DEFAULT 'VALID',
    created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),

    PRIMARY KEY (id),
    UNIQUE KEY uq_perf_rollup_window (
        metric_code,
        window_start,
        resolution_code,
        dimensions_hash
    ),
    KEY idx_perf_rollup_metric_time (
        metric_code,
        window_start,
        window_end
    ),
    KEY idx_perf_rollup_scope (
        tenant_id,
        scope_id,
        window_start
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

### 60. Table: performance_baselines

```sql
CREATE TABLE performance_baselines (
    id CHAR(26) NOT NULL,
    metric_code VARCHAR(180) NOT NULL,
    baseline_type VARCHAR(40) NOT NULL,
    scope_json JSON NOT NULL,
    window_code VARCHAR(20) NOT NULL,
    seasonality_code VARCHAR(50) NULL,
    aggregation_code VARCHAR(30) NOT NULL,
    minimum_samples BIGINT UNSIGNED NOT NULL,
    confidence_level DECIMAL(5,4) NOT NULL,
    exclusions_json JSON NOT NULL,
    owner_reference VARCHAR(150) NOT NULL,
    status VARCHAR(30) NOT NULL DEFAULT 'DRAFT',
    effective_from DATETIME(6) NOT NULL,
    created_by BIGINT UNSIGNED NOT NULL,
    created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    updated_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6)
        ON UPDATE CURRENT_TIMESTAMP(6),

    PRIMARY KEY (id),
    KEY idx_performance_baseline_metric (
        metric_code,
        status,
        effective_from
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

### 61. Table: performance_baseline_versions

```sql
CREATE TABLE performance_baseline_versions (
    id CHAR(26) NOT NULL,
    baseline_id CHAR(26) NOT NULL,
    baseline_version VARCHAR(20) NOT NULL,
    expected_value DOUBLE NULL,
    lower_bound DOUBLE NULL,
    upper_bound DOUBLE NULL,
    sample_count BIGINT UNSIGNED NOT NULL,
    quality_status VARCHAR(30) NOT NULL,
    confidence_value DECIMAL(5,4) NULL,
    source_window_start DATETIME(6) NOT NULL,
    source_window_end DATETIME(6) NOT NULL,
    algorithm_code VARCHAR(60) NOT NULL,
    parameters_json JSON NOT NULL,
    generated_at DATETIME(6) NOT NULL,
    created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),

    PRIMARY KEY (id),
    CONSTRAINT fk_perf_baseline_version_baseline
        FOREIGN KEY (baseline_id)
        REFERENCES performance_baselines(id)
        ON DELETE CASCADE,

    UNIQUE KEY uq_perf_baseline_version (
        baseline_id,
        baseline_version
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

### 62. Table: performance_anomalies

```sql
CREATE TABLE performance_anomalies (
    id CHAR(26) NOT NULL,
    metric_code VARCHAR(180) NOT NULL,
    baseline_id CHAR(26) NULL,
    scope_json JSON NOT NULL,
    dimensions_json JSON NOT NULL,
    observed_value DOUBLE NOT NULL,
    expected_value DOUBLE NULL,
    lower_bound DOUBLE NULL,
    upper_bound DOUBLE NULL,
    anomaly_score DECIMAL(6,5) NOT NULL,
    confidence_value DECIMAL(6,5) NOT NULL,
    status VARCHAR(30) NOT NULL DEFAULT 'OPEN',
    detected_at DATETIME(6) NOT NULL,
    acknowledged_at DATETIME(6) NULL,
    resolved_at DATETIME(6) NULL,
    suppression_until DATETIME(6) NULL,
    false_positive_reason VARCHAR(2000) NULL,
    created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),

    PRIMARY KEY (id),
    KEY idx_perf_anomaly_open (
        status,
        detected_at
    ),
    KEY idx_perf_anomaly_metric (
        metric_code,
        detected_at
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

### 63. Table: performance_regressions

```sql
CREATE TABLE performance_regressions (
    id CHAR(26) NOT NULL,
    metric_code VARCHAR(180) NOT NULL,
    scope_json JSON NOT NULL,
    reference_json JSON NOT NULL,
    candidate_json JSON NOT NULL,
    aggregation_code VARCHAR(30) NOT NULL,
    reference_value DOUBLE NULL,
    candidate_value DOUBLE NULL,
    absolute_delta DOUBLE NULL,
    relative_delta DOUBLE NULL,
    sample_count_reference BIGINT UNSIGNED NOT NULL,
    sample_count_candidate BIGINT UNSIGNED NOT NULL,
    confidence_value DECIMAL(6,5) NULL,
    severity VARCHAR(30) NOT NULL,
    decision VARCHAR(30) NOT NULL,
    status VARCHAR(30) NOT NULL DEFAULT 'OPEN',
    detected_at DATETIME(6) NOT NULL,
    override_reason VARCHAR(2000) NULL,
    overridden_by BIGINT UNSIGNED NULL,
    verified_at DATETIME(6) NULL,
    created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),

    PRIMARY KEY (id),
    KEY idx_perf_regression_decision (
        decision,
        detected_at
    ),
    KEY idx_perf_regression_metric (
        metric_code,
        detected_at
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

### 64. Table: performance_sli_definitions

```sql
CREATE TABLE performance_sli_definitions (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    code VARCHAR(180) NOT NULL,
    name VARCHAR(255) NOT NULL,
    service_code VARCHAR(120) NOT NULL,
    metric_source VARCHAR(180) NOT NULL,
    good_event_query_json JSON NOT NULL,
    total_event_query_json JSON NOT NULL,
    window_code VARCHAR(20) NOT NULL,
    dimensions_json JSON NOT NULL,
    exclusions_json JSON NOT NULL,
    owner_reference VARCHAR(150) NOT NULL,
    sli_version VARCHAR(20) NOT NULL,
    status VARCHAR(30) NOT NULL DEFAULT 'DRAFT',
    created_by BIGINT UNSIGNED NOT NULL,
    created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    updated_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6)
        ON UPDATE CURRENT_TIMESTAMP(6),

    PRIMARY KEY (id),
    UNIQUE KEY uq_perf_sli_code_version (
        code,
        sli_version
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

### 65. Table: performance_sli_evaluations

```sql
CREATE TABLE performance_sli_evaluations (
    id CHAR(26) NOT NULL,
    sli_code VARCHAR(180) NOT NULL,
    window_start DATETIME(6) NOT NULL,
    window_end DATETIME(6) NOT NULL,
    good_events BIGINT UNSIGNED NOT NULL,
    total_events BIGINT UNSIGNED NOT NULL,
    bad_events BIGINT UNSIGNED NOT NULL,
    excluded_events BIGINT UNSIGNED NOT NULL,
    attainment DECIMAL(10,8) NULL,
    quality_status VARCHAR(30) NOT NULL,
    evaluated_at DATETIME(6) NOT NULL,
    created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),

    PRIMARY KEY (id),
    UNIQUE KEY uq_perf_sli_eval_window (
        sli_code,
        window_start,
        window_end
    ),
    KEY idx_perf_sli_eval_time (
        sli_code,
        evaluated_at
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

### 66. Table: performance_slo_definitions

```sql
CREATE TABLE performance_slo_definitions (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    code VARCHAR(180) NOT NULL,
    sli_code VARCHAR(180) NOT NULL,
    target_value DECIMAL(10,8) NOT NULL,
    window_code VARCHAR(20) NOT NULL,
    evaluation_period_code VARCHAR(20) NOT NULL,
    error_budget_policy_code VARCHAR(150) NOT NULL,
    owner_reference VARCHAR(150) NOT NULL,
    effective_from DATETIME(6) NOT NULL,
    slo_version VARCHAR(20) NOT NULL,
    status VARCHAR(30) NOT NULL DEFAULT 'DRAFT',
    created_by BIGINT UNSIGNED NOT NULL,
    created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    updated_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6)
        ON UPDATE CURRENT_TIMESTAMP(6),

    PRIMARY KEY (id),
    UNIQUE KEY uq_perf_slo_code_version (
        code,
        slo_version
    ),
    KEY idx_perf_slo_active (
        status,
        effective_from
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

### 67. Table: performance_slo_evaluations

```sql
CREATE TABLE performance_slo_evaluations (
    id CHAR(26) NOT NULL,
    slo_code VARCHAR(180) NOT NULL,
    window_start DATETIME(6) NOT NULL,
    window_end DATETIME(6) NOT NULL,
    attainment DECIMAL(10,8) NULL,
    target_value DECIMAL(10,8) NOT NULL,
    status VARCHAR(30) NOT NULL,
    quality_status VARCHAR(30) NOT NULL,
    evaluated_at DATETIME(6) NOT NULL,
    created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),

    PRIMARY KEY (id),
    UNIQUE KEY uq_perf_slo_eval_window (
        slo_code,
        window_start,
        window_end
    ),
    KEY idx_perf_slo_eval_status (
        status,
        evaluated_at
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

### 68. Table: performance_error_budgets

```sql
CREATE TABLE performance_error_budgets (
    id CHAR(26) NOT NULL,
    slo_code VARCHAR(180) NOT NULL,
    window_start DATETIME(6) NOT NULL,
    window_end DATETIME(6) NOT NULL,
    total_events BIGINT UNSIGNED NOT NULL,
    allowed_bad_events BIGINT UNSIGNED NOT NULL,
    actual_bad_events BIGINT UNSIGNED NOT NULL,
    remaining_bad_events BIGINT SIGNED NOT NULL,
    remaining_ratio DECIMAL(10,8) NULL,
    burn_rate DECIMAL(12,6) NULL,
    status VARCHAR(30) NOT NULL,
    calculated_at DATETIME(6) NOT NULL,
    created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),

    PRIMARY KEY (id),
    UNIQUE KEY uq_perf_error_budget_window (
        slo_code,
        window_start,
        window_end
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

### 69. Table: performance_capacity_forecasts

```sql
CREATE TABLE performance_capacity_forecasts (
    id CHAR(26) NOT NULL,
    resource_type VARCHAR(50) NOT NULL,
    scope_json JSON NOT NULL,
    method_code VARCHAR(50) NOT NULL,
    current_usage DOUBLE NOT NULL,
    capacity_value DOUBLE NOT NULL,
    headroom_value DOUBLE NOT NULL,
    growth_rate DOUBLE NULL,
    forecast_7d DOUBLE NULL,
    forecast_30d DOUBLE NULL,
    forecast_90d DOUBLE NULL,
    estimated_exhaustion_at DATETIME(6) NULL,
    confidence_value DECIMAL(6,5) NULL,
    risk_status VARCHAR(30) NOT NULL,
    generated_at DATETIME(6) NOT NULL,
    created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),

    PRIMARY KEY (id),
    KEY idx_perf_capacity_risk (
        risk_status,
        generated_at
    ),
    KEY idx_perf_capacity_resource (
        resource_type,
        generated_at
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

### 70. Table: performance_correlations

```sql
CREATE TABLE performance_correlations (
    id CHAR(26) NOT NULL,
    trigger_signal_json JSON NOT NULL,
    related_signals_json JSON NOT NULL,
    scope_json JSON NOT NULL,
    window_start DATETIME(6) NOT NULL,
    window_end DATETIME(6) NOT NULL,
    candidate_cause VARCHAR(500) NULL,
    confidence_value DECIMAL(6,5) NULL,
    evidence_json JSON NOT NULL,
    status VARCHAR(30) NOT NULL DEFAULT 'OPEN',
    confirmed_by BIGINT UNSIGNED NULL,
    rejected_by BIGINT UNSIGNED NULL,
    created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    updated_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6)
        ON UPDATE CURRENT_TIMESTAMP(6),

    PRIMARY KEY (id),
    KEY idx_perf_correlation_status (
        status,
        created_at
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

### 71. Table: performance_recommendations

```sql
CREATE TABLE performance_recommendations (
    id CHAR(26) NOT NULL,
    category VARCHAR(50) NOT NULL,
    title VARCHAR(500) NOT NULL,
    evidence_json JSON NOT NULL,
    confidence_value DECIMAL(6,5) NOT NULL,
    impact_score DECIMAL(10,4) NOT NULL,
    effort_score DECIMAL(10,4) NOT NULL,
    priority_score DECIMAL(10,4) NOT NULL,
    owner_reference VARCHAR(150) NOT NULL,
    status VARCHAR(30) NOT NULL DEFAULT 'OPEN',
    verified_at DATETIME(6) NULL,
    created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    updated_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6)
        ON UPDATE CURRENT_TIMESTAMP(6),

    PRIMARY KEY (id),
    KEY idx_perf_recommendation_priority (
        status,
        priority_score
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

### 72. Table: performance_reports

```sql
CREATE TABLE performance_reports (
    id CHAR(26) NOT NULL,
    report_type VARCHAR(50) NOT NULL,
    scope_json JSON NOT NULL,
    window_start DATETIME(6) NOT NULL,
    window_end DATETIME(6) NOT NULL,
    status VARCHAR(30) NOT NULL,
    storage_reference VARCHAR(1000) NULL,
    generated_by_reference VARCHAR(150) NOT NULL,
    generated_at DATETIME(6) NULL,
    expires_at DATETIME(6) NULL,
    created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),

    PRIMARY KEY (id),
    KEY idx_perf_report_status (
        status,
        created_at
    ),
    KEY idx_perf_report_type (
        report_type,
        window_start,
        window_end
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

### 73. Table: performance_deployment_annotations

```sql
CREATE TABLE performance_deployment_annotations (
    id CHAR(26) NOT NULL,
    deployment_id VARCHAR(150) NOT NULL,
    deployment_version VARCHAR(150) NOT NULL,
    environment VARCHAR(32) NOT NULL,
    module_code VARCHAR(100) NULL,
    service_code VARCHAR(100) NULL,
    commit_reference VARCHAR(255) NULL,
    owner_reference VARCHAR(150) NOT NULL,
    started_at DATETIME(6) NOT NULL,
    completed_at DATETIME(6) NULL,
    created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),

    PRIMARY KEY (id),
    UNIQUE KEY uq_perf_deployment_annotation (
        deployment_id
    ),
    KEY idx_perf_deployment_time (
        environment,
        started_at
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

### 74. Table: performance_analysis_jobs

```sql
CREATE TABLE performance_analysis_jobs (
    id CHAR(26) NOT NULL,
    job_type VARCHAR(60) NOT NULL,
    idempotency_key VARCHAR(255) NOT NULL,
    scope_json JSON NOT NULL,
    status VARCHAR(30) NOT NULL,
    progress_percent DECIMAL(5,2) NOT NULL DEFAULT 0,
    processed_series BIGINT UNSIGNED NOT NULL DEFAULT 0,
    processed_samples BIGINT UNSIGNED NOT NULL DEFAULT 0,
    heartbeat_at DATETIME(6) NULL,
    error_code VARCHAR(100) NULL,
    error_message VARCHAR(2000) NULL,
    started_at DATETIME(6) NOT NULL,
    completed_at DATETIME(6) NULL,
    created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),

    PRIMARY KEY (id),
    UNIQUE KEY uq_perf_analysis_job_idempotency (
        idempotency_key
    ),
    KEY idx_perf_analysis_job_status (
        job_type,
        status,
        heartbeat_at
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

### 75. Repository Contracts

```php
interface PerformanceBaselineRepositoryInterface
{
    public function findById(
        string $baselineId
    ): ?PerformanceBaseline;

    public function save(
        PerformanceBaseline $baseline
    ): void;
}

interface PerformanceSloRepositoryInterface
{
    public function findActiveByCode(
        string $sloCode,
        \DateTimeImmutable $at
    ): ?PerformanceSlo;

    public function saveEvaluation(
        SloEvaluation $evaluation
    ): void;
}
```

---

### 76. Dashboard Data Contracts

Overview response:

```json
{
  "golden_signals": {
    "latency_p95_seconds": 0.42,
    "traffic_rps": 125.5,
    "error_rate": 0.004,
    "saturation": 0.71
  },
  "slo": {
    "healthy": 12,
    "at_risk": 2,
    "breached": 1,
    "no_data": 0
  },
  "capacity": {
    "safe": 8,
    "watch": 3,
    "at_risk": 1,
    "critical": 0
  },
  "active_anomalies": 4,
  "active_regressions": 2
}
```

---

### 77. Dashboard Cache

Dashboard cache key wajib mencakup:

```text
tenant
scope
environment
time range
permission profile
dashboard type
```

---

### 78. Dashboard Cache TTL

Contoh:

```text
overview: 30–60 seconds
SLO: 60 seconds
capacity: 5–15 minutes
historical report: longer
```

---

### 79. Cache Invalidation

Invalidate saat:

- SLO berubah;
- baseline berubah;
- anomaly state berubah;
- regression state berubah;
- deployment annotation baru;
- permission berubah.

---

### 80. Alert Integration

Performance alert rules dapat dibuat dari:

```text
anomaly
regression
SLO burn rate
capacity risk
data quality
synthetic failure
```

---

### 81. Alert Rule Examples

```text
performance_latency_anomaly
performance_regression_critical
performance_slo_burn_rate_high
performance_capacity_exhaustion_forecast
performance_database_bottleneck
performance_queue_bottleneck
performance_telemetry_stale
performance_synthetic_failed
```

---

### 82. Alert Severity Mapping

| Kondisi | Severity |
|---|---|
| minor anomaly | SEV4 |
| sustained degradation | SEV3 |
| SLO burn high | SEV2 |
| broad critical regression | SEV1 |
| platform-wide performance failure | SEV0/SEV1 |

---

### 83. Alert Deduplication

Fingerprint candidate:

```text
rule_code
service
metric_code
scope
environment
```

Jangan masukkan value dinamis ke fingerprint.

---

### 84. Alert Suppression

Suppress saat:

- maintenance;
- load test;
- known deployment warmup;
- active incident;
- telemetry quality invalid.

---

### 85. Incident Creation

Incident dapat dibuat otomatis bila:

- SLO burn threshold critical;
- regression critical;
- capacity exhaustion imminent;
- widespread synthetic failure;
- database saturation berdampak luas.

---

### 86. Audit Integration

Wajib audit:

- metric create/update/deprecate;
- baseline create/update/recalculate;
- anomaly suppression;
- false-positive marking;
- regression override;
- SLI/SLO create/update;
- error budget policy change;
- capacity override;
- profile access;
- report export;
- cross-tenant access;
- dashboard configuration change.

---

### 87. Audit Event Catalog

```text
OBS_PERF_METRIC_CREATED
OBS_PERF_METRIC_UPDATED
OBS_PERF_METRIC_DEPRECATED
OBS_PERF_BASELINE_CREATED
OBS_PERF_BASELINE_UPDATED
OBS_PERF_BASELINE_RECALCULATED
OBS_PERF_ANOMALY_SUPPRESSED
OBS_PERF_ANOMALY_FALSE_POSITIVE
OBS_PERF_REGRESSION_OVERRIDDEN
OBS_PERF_SLI_CREATED
OBS_PERF_SLO_CREATED
OBS_PERF_SLO_UPDATED
OBS_PERF_CAPACITY_FORECAST_OVERRIDDEN
OBS_PERF_REPORT_GENERATED
OBS_PERF_REPORT_EXPORTED
OBS_PERF_CROSS_TENANT_VIEWED
```

---

### 88. Structured Logging

```json
{
  "event": "performance_regression_detected",
  "regression_id": "01J...",
  "metric_code": "http_request_duration_seconds",
  "decision": "FAIL",
  "severity": "MAJOR",
  "relative_delta": 0.27,
  "absolute_delta": 0.18,
  "deployment_version": "2026.07.04"
}
```

---

### 89. Telemetry

```text
performance_api_request_total
performance_api_error_total
performance_analysis_job_total
performance_analysis_job_failure_total
performance_baseline_recalculation_total
performance_anomaly_detected_total
performance_regression_detected_total
performance_slo_evaluation_total
performance_capacity_forecast_total
performance_report_generation_total
performance_scheduler_stuck_total
performance_query_timeout_total
```

---

### 90. Error Codes

```text
PERFORMANCE_METRIC_NOT_FOUND
PERFORMANCE_METRIC_INVALID
PERFORMANCE_METRIC_CONFLICT
PERFORMANCE_CARDINALITY_LIMIT_EXCEEDED
PERFORMANCE_BASELINE_NOT_FOUND
PERFORMANCE_BASELINE_INSUFFICIENT_DATA
PERFORMANCE_BASELINE_INVALID
PERFORMANCE_ANOMALY_NOT_FOUND
PERFORMANCE_REGRESSION_NOT_FOUND
PERFORMANCE_REGRESSION_INCONCLUSIVE
PERFORMANCE_SLI_NOT_FOUND
PERFORMANCE_SLI_INVALID
PERFORMANCE_SLO_NOT_FOUND
PERFORMANCE_SLO_INVALID
PERFORMANCE_CAPACITY_FORECAST_FAILED
PERFORMANCE_CORRELATION_NOT_FOUND
PERFORMANCE_REPORT_NOT_FOUND
PERFORMANCE_REPORT_EXPIRED
PERFORMANCE_CROSS_TENANT_ACCESS_DENIED
PERFORMANCE_CLASSIFICATION_ACCESS_DENIED
PERFORMANCE_DATA_QUALITY_INVALID
PERFORMANCE_QUERY_TOO_EXPENSIVE
PERFORMANCE_ANALYSIS_JOB_STUCK
```

---

### 91. Security Controls

Framework wajib:

- no raw SQL from API;
- no unrestricted time range;
- no raw profile exposure;
- tenant/scope enforcement;
- classification enforcement;
- CSRF untuk mutation;
- rate limiting;
- export expiry;
- cross-tenant permission;
- data quality gate;
- audit privileged access;
- protect dashboard cache;
- no secret/PHI/PII in responses.

---

### 92. Performance Report Export

Export wajib:

- permission;
- scope;
- time range;
- classification;
- row/series limit;
- expiry;
- encryption;
- audit.

---

### 93. Signed Export URL

Jika digunakan:

- short expiry;
- one-time atau bounded use;
- no public listing;
- scoped object;
- audit generation;
- no embedded credential.

---

### 94. Cross-Tenant Access

Cross-tenant dashboard/report membutuhkan:

```text
observability.performance.cross_tenant.read
```

dan wajib diaudit.

---

### 95. Data Masking

Projector harus dapat menyembunyikan:

- tenant identity;
- internal deployment details;
- profile symbol sensitif;
- raw evidence references;
- restricted infrastructure names.

---

### 96. Apache/XAMPP Virtual Host

```apache
<VirtualHost *:80>
    ServerName platform.local
    DocumentRoot "D:/xampp/htdocs/platform/public"

    <Directory "D:/xampp/htdocs/platform/public">
        AllowOverride All
        Require all granted
        Options -Indexes
    </Directory>

    <Directory "D:/xampp/htdocs/platform/storage/performance-reports">
        Require all denied
        Options -Indexes
    </Directory>

    ErrorLog "logs/platform-error.log"
    CustomLog "logs/platform-access.log" combined
</VirtualHost>
```

---

### 97. `.htaccess`

```apache
RewriteEngine On

RewriteCond %{REQUEST_FILENAME} -f [OR]
RewriteCond %{REQUEST_FILENAME} -d
RewriteRule ^ - [L]

RewriteRule ^ index.php [QSA,L]
```

---

### 98. Route Registration

```php
$router->group('/api/internal/v1/performance', [
    'middleware' => [
        RequestIdMiddleware::class,
        AuthenticationMiddleware::class,
        RateLimitMiddleware::class,
        TenantContextMiddleware::class,
        ActiveScopeMiddleware::class,
        PerformanceClassificationMiddleware::class,
        AuditContextMiddleware::class,
    ],
], function ($router): void {
    $router->get('/metrics', [
        MetricCatalogController::class,
        'index',
    ]);

    $router->post('/metrics', [
        MetricCatalogController::class,
        'create',
    ]);

    $router->post('/baselines/{baselineId}/recalculate', [
        BaselineController::class,
        'recalculate',
    ]);

    $router->post('/regressions/compare', [
        RegressionController::class,
        'compare',
    ]);

    $router->get('/slos/{sloCode}/error-budget', [
        SloController::class,
        'errorBudget',
    ]);

    $router->get('/dashboards/overview', [
        PerformanceDashboardController::class,
        'overview',
    ]);

    $router->post('/reports/generate', [
        PerformanceReportController::class,
        'generate',
    ]);
});
```

---

### 99. Sequence Diagram — Baseline Recalculation

```mermaid
sequenceDiagram
    participant Scheduler
    participant Baseline as Baseline Service
    participant Metric as Metric Store
    participant Annotation as Annotation Service
    participant Repository as Baseline Repository
    participant Audit as Audit Service

    Scheduler->>Baseline: Recalculate baseline
    Baseline->>Metric: Query historical samples
    Metric-->>Baseline: Aggregated series
    Baseline->>Annotation: Resolve exclusions
    Annotation-->>Baseline: Maintenance/incident windows
    Baseline->>Baseline: Calculate expected band
    Baseline->>Repository: Save baseline version
    Baseline->>Audit: Record recalculation
```

---

### 100. Sequence Diagram — Regression Analysis

```mermaid
sequenceDiagram
    participant Deploy as Deployment Event
    participant Regression as Regression Service
    participant Metric as Metric Store
    participant Quality as Data Quality Service
    participant Alert as Alert Manager
    participant Audit as Audit Service

    Deploy->>Regression: Trigger comparison
    Regression->>Metric: Query reference window
    Metric-->>Regression: Reference series
    Regression->>Metric: Query candidate window
    Metric-->>Regression: Candidate series
    Regression->>Quality: Validate samples
    Quality-->>Regression: VALID
    Regression->>Regression: Calculate deltas/confidence
    alt Decision FAIL
        Regression->>Alert: Create regression alert
    end
    Regression->>Audit: Record analysis
```

---

### 101. Sequence Diagram — SLO Evaluation

```mermaid
sequenceDiagram
    participant Scheduler
    participant SLO as SLO Service
    participant SLI as SLI Service
    participant Metric as Metric Store
    participant Budget as Error Budget Service
    participant Alert as Alert Manager

    Scheduler->>SLO: Evaluate SLO
    SLO->>SLI: Evaluate source SLI
    SLI->>Metric: Query good/total events
    Metric-->>SLI: Event counts
    SLI-->>SLO: SLI attainment
    SLO->>Budget: Calculate error budget
    Budget-->>SLO: Remaining budget and burn rate
    alt Burn rate critical
        SLO->>Alert: Create burn-rate alert
    end
```

---

### 102. Sequence Diagram — Dashboard Query

```mermaid
sequenceDiagram
    participant User
    participant API as Dashboard Controller
    participant Auth as RBAC/Scope
    participant Cache as Dashboard Cache
    participant Service as Dashboard Service
    participant Metric as Metric Store
    participant SLO as SLO Repository
    participant Capacity as Capacity Repository

    User->>API: Request overview
    API->>Auth: Validate permission and scope
    Auth-->>API: Allowed
    API->>Cache: Lookup scoped cache
    alt Cache hit
        Cache-->>API: Cached dashboard
    else Cache miss
        API->>Service: Build overview
        Service->>Metric: Query Golden Signals
        Service->>SLO: Query SLO states
        Service->>Capacity: Query capacity risks
        Service-->>API: Overview
        API->>Cache: Store scoped result
    end
    API-->>User: JSON response
```

---

### 103. Performance Targets

| Operation | Target |
|---|---:|
| Metric list | < 500 ms |
| Dashboard overview | < 1 s |
| SLO status read | < 500 ms |
| Baseline read | < 500 ms |
| Anomaly list | < 750 ms |
| Regression read | < 750 ms |
| Capacity risk read | < 750 ms |
| Report request enqueue | < 500 ms |
| Cross-tenant summary | < 2 s |
| Analysis job enqueue | < 500 ms |

---

### 104. Testing Strategy

#### Unit

- metric validation;
- dimension validation;
- duration parser;
- baseline state;
- anomaly state;
- regression thresholds;
- SLI/SLO calculation;
- error budget;
- capacity risk;
- permission projection.

#### Integration

- PDO repositories;
- partitioned sample store;
- rollup job;
- scheduler locks;
- dashboard cache;
- alert creation;
- report export;
- audit emission;
- route contracts.

#### Security

- cross-tenant access;
- profile access;
- oversized query;
- CSRF;
- rate limit;
- export expiry;
- cache isolation;
- classification leakage.

---

### 105. UAT Part 4

#### Metric API

- [ ] Metric list bekerja.
- [ ] Create/update tervalidasi.
- [ ] Cardinality validation bekerja.
- [ ] Deprecation lifecycle bekerja.
- [ ] Permission diterapkan.
- [ ] Semua mutation diaudit.

#### Baseline API

- [ ] Baseline dapat dibuat.
- [ ] Recalculation dapat dienqueue.
- [ ] Version history tersedia.
- [ ] Insufficient data menghasilkan error tepat.
- [ ] Activation/suspension bekerja.
- [ ] Tenant scope diterapkan.

#### Anomaly & Regression API

- [ ] Anomaly list bekerja.
- [ ] Suppression memiliki expiry.
- [ ] False positive dapat ditandai.
- [ ] Regression compare bekerja.
- [ ] Override membutuhkan reason.
- [ ] Evidence tersedia.

#### SLI/SLO API

- [ ] SLI create/evaluate bekerja.
- [ ] SLO create/evaluate bekerja.
- [ ] Error budget tersedia.
- [ ] Burn rate tersedia.
- [ ] NO_DATA state tersedia.
- [ ] Versioning bekerja.

#### Capacity & Correlation API

- [ ] Forecast dapat dibuat.
- [ ] Risk list tersedia.
- [ ] Headroom tersedia.
- [ ] Correlation analysis dapat dienqueue.
- [ ] Candidate cause dapat dikonfirmasi/reject.
- [ ] Quality gate diterapkan.

#### Dashboard & Report

- [ ] Overview bekerja.
- [ ] Service dashboard bekerja.
- [ ] Database dashboard bekerja.
- [ ] SLO dashboard bekerja.
- [ ] Tenant dashboard terisolasi.
- [ ] Report export memiliki expiry.
- [ ] Cache key scope-aware.

#### Scheduler

- [ ] Rollup job berjalan.
- [ ] Baseline job berjalan.
- [ ] Anomaly job berjalan.
- [ ] Regression job berjalan.
- [ ] SLI/SLO job berjalan.
- [ ] Capacity job berjalan.
- [ ] Correlation job berjalan.
- [ ] Report job berjalan.
- [ ] Quality job berjalan.
- [ ] Stuck job terdeteksi.
- [ ] Lock/idempotency bekerja.

#### Database

- [ ] Migration berhasil.
- [ ] Partition aktif.
- [ ] Foreign key valid.
- [ ] Rollup uniqueness bekerja.
- [ ] Index mendukung query utama.
- [ ] Tenant/scope data terisolasi.

#### Alert & Incident

- [ ] Regression FAIL membuat alert.
- [ ] Burn rate critical membuat alert.
- [ ] Capacity critical membuat alert.
- [ ] Suppression saat maintenance bekerja.
- [ ] Deduplication bekerja.
- [ ] Incident creation policy bekerja.

#### Security

- [ ] Raw SQL ditolak.
- [ ] Raw profile tidak terekspos.
- [ ] Query tanpa range ditolak.
- [ ] CSRF aktif.
- [ ] Rate limit aktif.
- [ ] Cross-tenant permission diterapkan.
- [ ] Export terenkripsi.
- [ ] Report folder tidak dapat diakses langsung.

#### Apache/XAMPP

- [ ] Front controller bekerja.
- [ ] Report folder blocked.
- [ ] Directory listing nonaktif.
- [ ] Internal API route bekerja.
- [ ] Error log tersedia.

---

### 106. Anti-Pattern

Hindari:

- controller menghitung SLO sendiri;
- dashboard query tanpa time range;
- analytics SQL langsung dari UI;
- cache dashboard tanpa tenant key;
- regression override tanpa reason;
- baseline recalculation tanpa version;
- SLO evaluation dari sampled counter;
- report export ke public folder;
- cross-tenant view tanpa permission;
- scheduler tanpa lock;
- retry tanpa idempotency;
- pmax partition tanpa monitor;
- alert saat data quality invalid.

---

### 107. Definition of Done Part 4

Part 4 dianggap selesai bila:

- [ ] HTTP API catalog tersedia;
- [ ] request/response contracts tersedia;
- [ ] controller standard tersedia;
- [ ] application service contracts tersedia;
- [ ] middleware order tersedia;
- [ ] permission model tersedia;
- [ ] classification enforcement tersedia;
- [ ] query guard tersedia;
- [ ] scheduler architecture tersedia;
- [ ] scheduler jobs tersedia;
- [ ] lock/idempotency tersedia;
- [ ] CLI commands tersedia;
- [ ] database schema tersedia;
- [ ] repository contracts tersedia;
- [ ] dashboard contracts tersedia;
- [ ] alert integration tersedia;
- [ ] incident integration tersedia;
- [ ] audit integration tersedia;
- [ ] telemetry tersedia;
- [ ] error codes tersedia;
- [ ] security controls tersedia;
- [ ] Apache/XAMPP routing tersedia;
- [ ] sequence diagram tersedia;
- [ ] UAT tersedia.

---

### 108. Rencana Part Berikutnya

#### Part 5

Reference implementation, sample metric definitions, sample baselines, SLI/SLO, migration, deployment, rollback, load testing, performance simulations, operational runbooks, final UAT, Definition of Done, roadmap, dan merge guidance menjadi `SSOT-OBS-09.md`.

---

## Bagian V — Reference Implementation, Deployment, Load Testing, Simulation, Final UAT & Operational Readiness

### 1. Executive Summary

Part 5 menutup rangkaian SSOT-OBS-09 dengan reference implementation Performance Monitoring Framework.

Bagian ini mencakup:

- bootstrap wiring;
- sample metric definitions;
- sample baselines;
- sample SLI/SLO;
- instrumentation registration;
- baseline and anomaly engine wiring;
- regression service;
- capacity forecast service;
- dashboard assembly;
- scheduler wiring;
- migration order;
- permission seed;
- deployment;
- rollback;
- load testing;
- performance simulation;
- operational runbooks;
- final UAT;
- Definition of Done;
- roadmap;
- merge guidance menjadi `SSOT-OBS-09.md`.

Target implementasi awal adalah framework yang:

- mengumpulkan telemetry konsisten;
- menghitung percentile;
- membentuk baseline;
- mendeteksi anomaly dan regression;
- mengevaluasi SLI/SLO;
- menghitung error budget;
- memproyeksikan capacity;
- menghubungkan metric, trace, log, deployment, dan incident;
- menjaga tenant/scope isolation;
- memberikan dashboard dan alert yang dapat ditindaklanjuti.

---

### 2. Initial Implementation Scope

Initial release wajib mencakup:

```text
Metric Catalog
Performance Recorder
HTTP Instrumentation
PDO/Database Instrumentation
Queue/Scheduler Instrumentation
Metric Rollup
Baseline Engine
Anomaly Detector
Regression Analyzer
SLI/SLO Evaluator
Error Budget Calculator
Capacity Forecaster
Dashboard Service
Alert Integration
Audit Integration
```

Initial performance domains:

```text
HTTP_API
APPLICATION
DATABASE
CACHE
QUEUE
SCHEDULER
WORKFLOW
INTEGRATION
INFRASTRUCTURE
FRONTEND
MULTI_TENANT
```

---

### 3. Final Folder Structure

```text
app/
└── Platform/
    └── Observability/
        └── Performance/
            ├── Domain/
            │   ├── PerformanceMetricDefinition.php
            │   ├── PerformanceBaseline.php
            │   ├── PerformanceAnomaly.php
            │   ├── PerformanceRegression.php
            │   ├── SliDefinition.php
            │   ├── SloDefinition.php
            │   ├── ErrorBudget.php
            │   ├── CapacityForecast.php
            │   ├── PerformanceCorrelation.php
            │   └── PerformanceRecommendation.php
            │
            ├── Application/
            │   ├── MetricCatalogService.php
            │   ├── PerformanceRecorder.php
            │   ├── MetricRollupService.php
            │   ├── BaselineService.php
            │   ├── AnomalyService.php
            │   ├── RegressionService.php
            │   ├── SliService.php
            │   ├── SloService.php
            │   ├── CapacityService.php
            │   ├── CorrelationService.php
            │   ├── RecommendationService.php
            │   ├── PerformanceDashboardService.php
            │   └── Contracts/
            │
            ├── Infrastructure/
            │   ├── Metrics/
            │   ├── Persistence/
            │   ├── Instrumentation/
            │   ├── Scheduler/
            │   ├── Alerting/
            │   ├── Audit/
            │   └── Reporting/
            │
            └── Presentation/
                ├── Http/
                └── Cli/

config/
├── performance-metrics.php
├── performance-baselines.php
├── performance-sli.php
├── performance-slo.php
├── performance-sampling.php
└── performance-scheduler.php

database/
└── migrations/
    └── create_performance_monitoring_tables.sql

resources/
├── performance/
│   ├── dashboards/
│   ├── reports/
│   └── runbooks/
└── load-tests/

storage/
└── performance-reports/

tests/
├── Unit/
├── Integration/
├── Load/
└── Uat/

tools/
├── performance-simulation.php
├── performance-regression-check.php
├── performance-load-runner.php
├── performance-slo-check.php
└── performance-capacity-check.php
```

---

### 4. Bootstrap Wiring

```php
<?php

declare(strict_types=1);

namespace App\Platform\Observability\Performance;

final class PerformanceBootstrap
{
    public static function build(
        array $config,
        object $container
    ): PerformanceKernel {
        $metricRegistry = new PerformanceMetricRegistry();
        $baselineRegistry = new PerformanceBaselineRegistry();
        $sliRegistry = new SliRegistry();
        $sloRegistry = new SloRegistry();

        foreach ($config['metric_registrars'] as $registrarClass) {
            $container->get($registrarClass)->register(
                $metricRegistry
            );
        }

        foreach ($config['baseline_registrars'] as $registrarClass) {
            $container->get($registrarClass)->register(
                $baselineRegistry
            );
        }

        foreach ($config['sli_registrars'] as $registrarClass) {
            $container->get($registrarClass)->register(
                $sliRegistry
            );
        }

        foreach ($config['slo_registrars'] as $registrarClass) {
            $container->get($registrarClass)->register(
                $sloRegistry
            );
        }

        $recorder = new PerformanceRecorder(
            registry: $metricRegistry,
            exporter: $container->get(
                'performance.metric_exporter'
            ),
            normalizer: $container->get(
                'performance.dimension_normalizer'
            ),
            cardinality: $container->get(
                'performance.cardinality_guard'
            ),
            telemetry: $container->get(
                'performance.telemetry'
            )
        );

        return new PerformanceKernel(
            metrics: $metricRegistry,
            recorder: $recorder,
            rollups: $container->get(
                'performance.rollup_service'
            ),
            baselines: $container->get(
                'performance.baseline_service'
            ),
            anomalies: $container->get(
                'performance.anomaly_service'
            ),
            regressions: $container->get(
                'performance.regression_service'
            ),
            slis: $container->get(
                'performance.sli_service'
            ),
            slos: $container->get(
                'performance.slo_service'
            ),
            capacity: $container->get(
                'performance.capacity_service'
            ),
            correlations: $container->get(
                'performance.correlation_service'
            ),
            dashboards: $container->get(
                'performance.dashboard_service'
            )
        );
    }
}
```

---

### 5. Metric Registrar Contract

```php
interface PerformanceMetricRegistrarInterface
{
    public function register(
        PerformanceMetricRegistryInterface $registry
    ): void;
}
```

Module bisnis dapat mendaftarkan metric tanpa mengubah Platform Kernel.

---

### 6. Sample Metric — HTTP Request Duration

```php
return [
    'code' => 'http_request_duration_seconds',
    'name' => 'HTTP Request Duration',
    'description' => 'Server-side request latency by normalized route.',
    'domain' => 'HTTP_API',
    'type' => 'HISTOGRAM',
    'unit' => 'seconds',
    'source' => 'http_middleware',
    'dimensions' => [
        'environment',
        'route',
        'method',
        'status_class',
        'module_code',
    ],
    'aggregation' => [
        'rate',
        'p50',
        'p95',
        'p99',
    ],
    'buckets' => [
        0.005,
        0.010,
        0.025,
        0.050,
        0.100,
        0.250,
        0.500,
        1.000,
        2.500,
        5.000,
        10.000,
    ],
    'owner' => 'platform_operations',
    'sensitivity' => 'INTERNAL',
    'retention' => 'performance_standard',
    'sli_usage' => true,
    'enabled' => true,
    'version' => '1.0',
];
```

---

### 7. Sample Metric — HTTP Request Total

```php
return [
    'code' => 'http_request_total',
    'name' => 'HTTP Request Total',
    'description' => 'Total normalized HTTP requests.',
    'domain' => 'HTTP_API',
    'type' => 'COUNTER',
    'unit' => 'requests',
    'source' => 'http_middleware',
    'dimensions' => [
        'environment',
        'route',
        'method',
        'status_class',
        'module_code',
    ],
    'aggregation' => [
        'rate',
        'sum',
    ],
    'owner' => 'platform_operations',
    'sensitivity' => 'INTERNAL',
    'retention' => 'performance_standard',
    'sli_usage' => true,
    'enabled' => true,
    'version' => '1.0',
];
```

---

### 8. Sample Metric — Database Query Duration

```php
return [
    'code' => 'db_query_duration_seconds',
    'name' => 'Database Query Duration',
    'description' => 'Database query latency by stable query code.',
    'domain' => 'DATABASE',
    'type' => 'HISTOGRAM',
    'unit' => 'seconds',
    'source' => 'pdo_instrumentation',
    'dimensions' => [
        'environment',
        'query_code',
        'operation',
        'module_code',
    ],
    'aggregation' => [
        'count',
        'p50',
        'p95',
        'p99',
    ],
    'buckets' => [
        0.001,
        0.005,
        0.010,
        0.025,
        0.050,
        0.100,
        0.250,
        0.500,
        1.000,
        2.500,
        5.000,
    ],
    'owner' => 'platform_data',
    'sensitivity' => 'INTERNAL',
    'retention' => 'performance_standard',
    'sli_usage' => false,
    'enabled' => true,
    'version' => '1.0',
];
```

---

### 9. Sample Metric — Database Connection Utilization

```php
return [
    'code' => 'db_connection_utilization_ratio',
    'name' => 'Database Connection Utilization',
    'description' => 'Current database connection utilization ratio.',
    'domain' => 'DATABASE',
    'type' => 'GAUGE',
    'unit' => 'ratio',
    'source' => 'database_pool',
    'dimensions' => [
        'environment',
        'database_role',
    ],
    'aggregation' => [
        'avg',
        'max',
    ],
    'owner' => 'platform_data',
    'sensitivity' => 'INTERNAL',
    'retention' => 'performance_standard',
    'sli_usage' => false,
    'enabled' => true,
    'version' => '1.0',
];
```

---

### 10. Sample Metric — Queue Wait Duration

```php
return [
    'code' => 'queue_wait_duration_seconds',
    'name' => 'Queue Wait Duration',
    'description' => 'Time between enqueue and processing start.',
    'domain' => 'QUEUE',
    'type' => 'HISTOGRAM',
    'unit' => 'seconds',
    'source' => 'queue_worker',
    'dimensions' => [
        'environment',
        'queue_name',
        'job_type',
        'priority',
    ],
    'aggregation' => [
        'p50',
        'p95',
        'p99',
    ],
    'owner' => 'platform_operations',
    'sensitivity' => 'INTERNAL',
    'retention' => 'performance_standard',
    'sli_usage' => true,
    'enabled' => true,
    'version' => '1.0',
];
```

---

### 11. Sample Metric — Queue Oldest Message Age

```php
return [
    'code' => 'queue_oldest_message_age_seconds',
    'name' => 'Queue Oldest Message Age',
    'description' => 'Age of the oldest pending queue message.',
    'domain' => 'QUEUE',
    'type' => 'GAUGE',
    'unit' => 'seconds',
    'source' => 'queue_monitor',
    'dimensions' => [
        'environment',
        'queue_name',
    ],
    'aggregation' => [
        'max',
    ],
    'owner' => 'platform_operations',
    'sensitivity' => 'INTERNAL',
    'retention' => 'performance_standard',
    'sli_usage' => false,
    'enabled' => true,
    'version' => '1.0',
];
```

---

### 12. Sample Metric — Cache Hit Total

```php
return [
    'code' => 'cache_hit_total',
    'name' => 'Cache Hit Total',
    'description' => 'Total cache hits by namespace.',
    'domain' => 'CACHE',
    'type' => 'COUNTER',
    'unit' => 'operations',
    'source' => 'cache_adapter',
    'dimensions' => [
        'environment',
        'cache_namespace',
    ],
    'aggregation' => [
        'rate',
        'sum',
    ],
    'owner' => 'platform_operations',
    'sensitivity' => 'INTERNAL',
    'retention' => 'performance_standard',
    'sli_usage' => false,
    'enabled' => true,
    'version' => '1.0',
];
```

---

### 13. Sample Metric — Workflow Duration

```php
return [
    'code' => 'workflow_duration_seconds',
    'name' => 'Workflow Duration',
    'description' => 'End-to-end workflow completion duration.',
    'domain' => 'WORKFLOW',
    'type' => 'HISTOGRAM',
    'unit' => 'seconds',
    'source' => 'workflow_engine',
    'dimensions' => [
        'environment',
        'workflow_type',
        'result',
        'module_code',
    ],
    'aggregation' => [
        'p50',
        'p95',
        'p99',
    ],
    'owner' => 'workflow_owner',
    'sensitivity' => 'CONFIDENTIAL',
    'retention' => 'performance_standard',
    'sli_usage' => true,
    'enabled' => true,
    'version' => '1.0',
];
```

---

### 14. Sample Metric — Frontend LCP

```php
return [
    'code' => 'web_vital_lcp_seconds',
    'name' => 'Largest Contentful Paint',
    'description' => 'Real user LCP by page template and device class.',
    'domain' => 'FRONTEND',
    'type' => 'HISTOGRAM',
    'unit' => 'seconds',
    'source' => 'rum',
    'dimensions' => [
        'environment',
        'page_template',
        'device_class',
        'network_class',
        'release_version',
    ],
    'aggregation' => [
        'p50',
        'p75',
        'p95',
    ],
    'owner' => 'frontend_team',
    'sensitivity' => 'INTERNAL',
    'retention' => 'performance_rum',
    'sli_usage' => true,
    'enabled' => true,
    'version' => '1.0',
];
```

---

### 15. Sample Baseline — Patient API p95

```php
return [
    'id' => 'BASELINE-PATIENT-API-P95',
    'metric_code' => 'http_request_duration_seconds',
    'baseline_type' => 'SEASONAL',
    'scope' => [
        'environment' => 'production',
        'service' => 'patient-service',
        'route' => '/patients/{id}',
    ],
    'window' => '28d',
    'seasonality' => 'day_of_week_hour',
    'aggregation' => 'p95',
    'minimum_samples' => 1000,
    'confidence_level' => 0.95,
    'exclusions' => [
        'maintenance',
        'incident',
        'load_test',
    ],
    'owner' => 'patient_service_owner',
    'effective_from' => '2026-07-01',
    'status' => 'ACTIVE',
];
```

---

### 16. Sample Baseline — Queue Wait

```php
return [
    'id' => 'BASELINE-HIGH-PRIORITY-QUEUE-WAIT',
    'metric_code' => 'queue_wait_duration_seconds',
    'baseline_type' => 'ROLLING',
    'scope' => [
        'environment' => 'production',
        'queue_name' => 'high_priority',
    ],
    'window' => '14d',
    'seasonality' => null,
    'aggregation' => 'p95',
    'minimum_samples' => 500,
    'confidence_level' => 0.95,
    'exclusions' => [
        'maintenance',
        'load_test',
    ],
    'owner' => 'platform_operations',
    'effective_from' => '2026-07-01',
    'status' => 'ACTIVE',
];
```

---

### 17. Sample SLI — Patient API Availability

```php
return [
    'code' => 'patient_api_availability',
    'name' => 'Patient API Availability',
    'service' => 'patient-service',
    'metric_source' => 'http_request_total',
    'good_event_query' => [
        'route_prefix' => '/patients',
        'status_class' => [
            '2xx',
            '3xx',
            '4xx',
        ],
    ],
    'total_event_query' => [
        'route_prefix' => '/patients',
        'status_class' => [
            '2xx',
            '3xx',
            '4xx',
            '5xx',
        ],
    ],
    'window' => '30d',
    'dimensions' => [
        'environment',
    ],
    'exclusions' => [
        'maintenance',
        'synthetic_non_contract',
    ],
    'owner' => 'patient_service_owner',
    'version' => '1.0',
    'status' => 'ACTIVE',
];
```

---

### 18. Sample SLI — Patient API Latency

```php
return [
    'code' => 'patient_api_latency',
    'name' => 'Patient API Latency',
    'service' => 'patient-service',
    'metric_source' => 'http_request_duration_seconds',
    'good_event_query' => [
        'route_prefix' => '/patients',
        'duration_lte_seconds' => 0.5,
        'status_class' => '2xx',
    ],
    'total_event_query' => [
        'route_prefix' => '/patients',
        'status_class' => '2xx',
    ],
    'window' => '30d',
    'dimensions' => [
        'environment',
    ],
    'exclusions' => [
        'maintenance',
    ],
    'owner' => 'patient_service_owner',
    'version' => '1.0',
    'status' => 'ACTIVE',
];
```

---

### 19. Sample SLO — Patient API Availability

```php
return [
    'code' => 'patient_api_availability_999',
    'sli_code' => 'patient_api_availability',
    'target' => 0.999,
    'window' => '30d',
    'evaluation_period' => '5m',
    'error_budget_policy' => 'critical_api_standard',
    'owner' => 'patient_service_owner',
    'effective_from' => '2026-07-01',
    'version' => '1.0',
    'status' => 'ACTIVE',
];
```

---

### 20. Sample SLO — Patient API Latency

```php
return [
    'code' => 'patient_api_latency_95',
    'sli_code' => 'patient_api_latency',
    'target' => 0.95,
    'window' => '30d',
    'evaluation_period' => '5m',
    'error_budget_policy' => 'critical_api_latency',
    'owner' => 'patient_service_owner',
    'effective_from' => '2026-07-01',
    'version' => '1.0',
    'status' => 'ACTIVE',
];
```

---

### 21. Sample SLO — Queue Delay

```php
return [
    'code' => 'high_priority_queue_delay_99',
    'sli_code' => 'high_priority_queue_delay',
    'target' => 0.99,
    'window' => '7d',
    'evaluation_period' => '5m',
    'error_budget_policy' => 'queue_standard',
    'owner' => 'platform_operations',
    'effective_from' => '2026-07-01',
    'version' => '1.0',
    'status' => 'ACTIVE',
];
```

---

### 22. Performance Recorder Reference

```php
final class PerformanceRecorder
    implements PerformanceRecorderInterface
{
    public function __construct(
        private readonly PerformanceMetricRegistryInterface $registry,
        private readonly PerformanceMetricExporterInterface $exporter,
        private readonly DimensionNormalizerInterface $normalizer,
        private readonly CardinalityGuardInterface $cardinality,
        private readonly PerformanceTelemetryInterface $telemetry
    ) {
    }

    public function increment(
        string $metricCode,
        array $dimensions = [],
        float $value = 1.0
    ): void {
        $this->record(
            metricCode: $metricCode,
            value: $value,
            dimensions: $dimensions,
            operation: 'increment'
        );
    }

    public function gauge(
        string $metricCode,
        float $value,
        array $dimensions = []
    ): void {
        $this->record(
            metricCode: $metricCode,
            value: $value,
            dimensions: $dimensions,
            operation: 'gauge'
        );
    }

    public function observe(
        string $metricCode,
        float $value,
        array $dimensions = []
    ): void {
        $this->record(
            metricCode: $metricCode,
            value: $value,
            dimensions: $dimensions,
            operation: 'observe'
        );
    }

    private function record(
        string $metricCode,
        float $value,
        array $dimensions,
        string $operation
    ): void {
        try {
            $definition = $this->registry->get($metricCode);

            $normalized = $this->normalizer->normalize(
                $definition,
                $dimensions
            );

            $this->cardinality->assertAllowed(
                $definition,
                $normalized
            );

            $this->exporter->export(
                PerformanceMetricSample::create(
                    metricCode: $metricCode,
                    value: $value,
                    dimensions: $normalized,
                    occurredAt: new \DateTimeImmutable('now')
                )
            );
        } catch (\Throwable $exception) {
            $this->telemetry->recordExporterFailure(
                metricCode: $metricCode,
                operation: $operation,
                exception: $exception
            );
        }
    }
}
```

---

### 23. HTTP Middleware Reference

```php
final class PerformanceHttpMiddleware
{
    public function __construct(
        private readonly PerformanceRecorderInterface $metrics,
        private readonly RouteNormalizerInterface $routes,
        private readonly DeploymentContextInterface $deployment
    ) {
    }

    public function process(
        HttpRequest $request,
        callable $next
    ): HttpResponse {
        $route = $this->routes->normalize($request);
        $startedAt = hrtime(true);

        $baseDimensions = [
            'environment' => $request->environment(),
            'route' => $route,
            'method' => $request->method(),
            'module_code' => $request->moduleCode(),
            'deployment_version' => $this->deployment->version(),
        ];

        try {
            $response = $next($request);

            $statusClass = intdiv(
                $response->statusCode(),
                100
            ) . 'xx';

            $this->metrics->increment(
                'http_request_total',
                $baseDimensions + [
                    'status_class' => $statusClass,
                ]
            );

            return $response;
        } finally {
            $duration = (
                hrtime(true) - $startedAt
            ) / 1_000_000_000;

            $this->metrics->observe(
                'http_request_duration_seconds',
                $duration,
                $baseDimensions
            );
        }
    }
}
```

---

### 24. Rollup Service Reference

```php
final class MetricRollupService
{
    public function rollup(
        MetricRollupWindow $window
    ): MetricRollupResult {
        $definitions = $this->metrics->active();

        foreach ($definitions as $definition) {
            $series = $this->samples->query(
                MetricSampleCriteria::forRollup(
                    metricCode: $definition->code,
                    window: $window
                )
            );

            foreach ($this->aggregator->group($series) as $group) {
                $rollup = $this->aggregator->aggregate(
                    definition: $definition,
                    group: $group,
                    window: $window
                );

                $this->rollups->upsert($rollup);
            }
        }

        return MetricRollupResult::completed($window);
    }
}
```

---

### 25. Baseline Service Reference

```php
final class BaselineService
{
    public function recalculate(
        string $baselineId,
        PerformanceContext $context
    ): BaselineVersion {
        $baseline = $this->baselines->findById($baselineId);

        if ($baseline === null) {
            throw new BaselineNotFoundException();
        }

        $series = $this->rollups->query(
            $baseline->sourceCriteria()
        );

        $series = $this->exclusions->removeExcludedWindows(
            $series,
            $baseline->exclusions
        );

        if ($series->sampleCount() < $baseline->minimumSamples) {
            throw new BaselineInsufficientDataException();
        }

        $result = $this->calculator->calculate(
            baseline: $baseline,
            series: $series
        );

        $version = BaselineVersion::create(
            id: $this->ids->ulid(),
            baselineId: $baseline->id,
            version: $this->versions->next($baseline->id),
            expectedValue: $result->expected,
            lowerBound: $result->lower,
            upperBound: $result->upper,
            sampleCount: $series->sampleCount(),
            qualityStatus: $result->quality,
            confidence: $result->confidence,
            generatedAt: $this->clock->now()
        );

        $this->baselineVersions->save($version);

        return $version;
    }
}
```

---

### 26. Anomaly Service Reference

```php
final class AnomalyService
{
    public function detect(
        AnomalyDetectionCriteria $criteria,
        PerformanceContext $context
    ): array {
        $baseline = $this->baselineResolver->resolve(
            $criteria
        );

        if (!$baseline->isUsable()) {
            return [];
        }

        $observations = $this->rollups->query(
            $criteria->observationWindow()
        );

        $anomalies = [];

        foreach ($observations as $observation) {
            $result = $this->detector->evaluate(
                observation: $observation,
                baseline: $baseline
            );

            if (!$result->isAnomalous()) {
                continue;
            }

            $anomaly = PerformanceAnomaly::open(
                id: $this->ids->ulid(),
                metricCode: $observation->metricCode,
                observedValue: $observation->value,
                expectedValue: $baseline->expectedValue,
                lowerBound: $baseline->lowerBound,
                upperBound: $baseline->upperBound,
                score: $result->score,
                confidence: $result->confidence,
                detectedAt: $this->clock->now()
            );

            $this->anomalies->save($anomaly);
            $anomalies[] = $anomaly;
        }

        return $anomalies;
    }
}
```

---

### 27. Regression Service Reference

```php
final class RegressionService
{
    public function compare(
        RegressionCompareCommand $command,
        PerformanceContext $context
    ): RegressionAnalysis {
        $reference = $this->series->query(
            $command->referenceCriteria()
        );

        $candidate = $this->series->query(
            $command->candidateCriteria()
        );

        $quality = $this->quality->validateComparison(
            $reference,
            $candidate
        );

        if (!$quality->valid) {
            return RegressionAnalysis::inconclusive(
                reason: $quality->reason
            );
        }

        $result = $this->comparator->compare(
            reference: $reference,
            candidate: $candidate,
            absoluteThreshold: $command->absoluteThreshold,
            relativeThreshold: $command->relativeThreshold
        );

        $analysis = RegressionAnalysis::create(
            id: $this->ids->ulid(),
            metricCode: $command->metricCode,
            referenceValue: $result->referenceValue,
            candidateValue: $result->candidateValue,
            absoluteDelta: $result->absoluteDelta,
            relativeDelta: $result->relativeDelta,
            confidence: $result->confidence,
            severity: $result->severity,
            decision: $result->decision,
            detectedAt: $this->clock->now()
        );

        $this->regressions->save($analysis);

        return $analysis;
    }
}
```

---

### 28. SLI Evaluation Reference

```php
final class SliService
{
    public function evaluate(
        string $sliCode,
        SliEvaluationWindow $window,
        PerformanceContext $context
    ): SliEvaluation {
        $definition = $this->slis->findActiveByCode(
            $sliCode,
            $window->end
        );

        if ($definition === null) {
            throw new SliNotFoundException();
        }

        $good = $this->events->count(
            $definition->goodCriteria($window)
        );

        $total = $this->events->count(
            $definition->totalCriteria($window)
        );

        $excluded = $this->exclusions->count(
            $definition,
            $window
        );

        $validTotal = max(0, $total - $excluded);

        $attainment = $validTotal > 0
            ? $good / $validTotal
            : null;

        $evaluation = SliEvaluation::create(
            id: $this->ids->ulid(),
            sliCode: $sliCode,
            window: $window,
            goodEvents: $good,
            totalEvents: $validTotal,
            badEvents: max(0, $validTotal - $good),
            excludedEvents: $excluded,
            attainment: $attainment,
            qualityStatus: $validTotal > 0
                ? 'VALID'
                : 'NO_DATA'
        );

        $this->evaluations->save($evaluation);

        return $evaluation;
    }
}
```

---

### 29. SLO Evaluation Reference

```php
final class SloService
{
    public function evaluate(
        string $sloCode,
        PerformanceContext $context
    ): SloEvaluation {
        $slo = $this->slos->findActiveByCode(
            $sloCode,
            $this->clock->now()
        );

        if ($slo === null) {
            throw new SloNotFoundException();
        }

        $window = $slo->currentWindow(
            $this->clock->now()
        );

        $sli = $this->sliService->evaluate(
            sliCode: $slo->sliCode,
            window: $window,
            context: $context
        );

        $budget = $this->budget->calculate(
            slo: $slo,
            sli: $sli
        );

        $status = $this->statusResolver->resolve(
            slo: $slo,
            sli: $sli,
            budget: $budget
        );

        $evaluation = SloEvaluation::create(
            id: $this->ids->ulid(),
            sloCode: $sloCode,
            window: $window,
            attainment: $sli->attainment,
            target: $slo->target,
            status: $status,
            qualityStatus: $sli->qualityStatus
        );

        $this->sloEvaluations->save($evaluation);
        $this->errorBudgets->save($budget);

        return $evaluation;
    }
}
```

---

### 30. Capacity Forecast Reference

```php
final class CapacityService
{
    public function forecast(
        CapacityForecastCommand $command,
        PerformanceContext $context
    ): CapacityForecast {
        $history = $this->series->query(
            $command->historyCriteria()
        );

        if ($history->sampleCount() < $command->minimumSamples) {
            throw new CapacityForecastInsufficientDataException();
        }

        $projection = $this->forecaster->forecast(
            history: $history,
            method: $command->method,
            horizon: $command->forecastHorizon
        );

        $forecast = CapacityForecast::create(
            id: $this->ids->ulid(),
            resourceType: $command->resourceType,
            currentUsage: $projection->currentUsage,
            capacity: $command->capacity,
            headroom: $command->capacity
                - $projection->currentUsage,
            growthRate: $projection->growthRate,
            forecast7d: $projection->valueAtDays(7),
            forecast30d: $projection->valueAtDays(30),
            forecast90d: $projection->valueAtDays(90),
            exhaustionAt: $projection->exhaustionAt(
                $command->capacity
            ),
            confidence: $projection->confidence,
            riskStatus: $this->risk->resolve(
                $projection,
                $command->capacity
            ),
            generatedAt: $this->clock->now()
        );

        $this->forecasts->save($forecast);

        return $forecast;
    }
}
```

---

### 31. Dashboard Assembly Reference

```php
final class PerformanceDashboardService
{
    public function overview(
        DashboardCriteria $criteria,
        PerformanceContext $context
    ): PerformanceOverview {
        $cacheKey = $this->keys->overview(
            criteria: $criteria,
            context: $context
        );

        return $this->cache->remember(
            key: $cacheKey,
            ttlSeconds: 60,
            loader: function () use ($criteria, $context) {
                return PerformanceOverview::create(
                    goldenSignals: $this->goldenSignals->query(
                        $criteria,
                        $context
                    ),
                    sloSummary: $this->slos->summary(
                        $criteria,
                        $context
                    ),
                    capacitySummary: $this->capacity->summary(
                        $criteria,
                        $context
                    ),
                    anomalies: $this->anomalies->activeCount(
                        $criteria,
                        $context
                    ),
                    regressions: $this->regressions->activeCount(
                        $criteria,
                        $context
                    )
                );
            }
        );
    }
}
```

---

### 32. Scheduler Wiring

```php
$scheduler->everyFiveMinutes(
    'performance:rollup',
    PerformanceMetricRollupJob::class
);

$scheduler->hourly(
    'performance:baseline:recalculate',
    PerformanceBaselineRecalculationJob::class
);

$scheduler->everyFiveMinutes(
    'performance:anomaly:detect',
    PerformanceAnomalyDetectionJob::class
);

$scheduler->everyFiveMinutes(
    'performance:sli:evaluate',
    PerformanceSliEvaluationJob::class
);

$scheduler->everyFiveMinutes(
    'performance:slo:evaluate',
    PerformanceSloEvaluationJob::class
);

$scheduler->everyFifteenMinutes(
    'performance:error-budget:calculate',
    PerformanceErrorBudgetCalculationJob::class
);

$scheduler->dailyAt(
    '03:30',
    'performance:capacity:forecast',
    PerformanceCapacityForecastJob::class
);

$scheduler->everyFiveMinutes(
    'performance:correlation:analyze',
    PerformanceCorrelationAnalysisJob::class
);

$scheduler->dailyAt(
    '05:00',
    'performance:recommendation:refresh',
    PerformanceRecommendationRefreshJob::class
);

$scheduler->dailyAt(
    '06:00',
    'performance:report:daily',
    PerformanceDailyReportJob::class
);

$scheduler->everyFiveMinutes(
    'performance:quality:check',
    PerformanceDataQualityJob::class
);

$scheduler->hourly(
    'performance:workspace:expire',
    PerformanceAnalysisWorkspaceExpiryJob::class
);
```

---

### 33. Deployment Event Hook

```php
$deploymentEvents->listen(
    DeploymentCompleted::class,
    function (DeploymentCompleted $event) use ($jobs): void {
        $jobs->dispatch(
            new PerformanceRegressionAnalysisJob(
                deploymentId: $event->deploymentId
            )
        );
    }
);
```

---

### 34. Windows Task Scheduler

Untuk XAMPP/Windows:

```bat
D:\xampp\php\php.exe D:\xampp\htdocs\platform\bin\console scheduler:run
```

Schedule:

```text
Repeat task every: 1 minute
Duration: Indefinitely
Run whether user is logged on or not
```

---

### 35. Initial Migration Order

```text
1. performance_metric_definitions
2. performance_metric_dimensions
3. performance_metric_samples
4. performance_metric_rollups
5. performance_baselines
6. performance_baseline_versions
7. performance_anomalies
8. performance_regressions
9. performance_regression_evidence
10. performance_sli_definitions
11. performance_sli_evaluations
12. performance_slo_definitions
13. performance_slo_evaluations
14. performance_error_budgets
15. performance_capacity_forecasts
16. performance_correlations
17. performance_recommendations
18. performance_reports
19. performance_deployment_annotations
20. performance_maintenance_annotations
21. performance_analysis_jobs
22. performance_scheduler_runs
```

---

### 36. Seed Permissions

```text
observability.performance.read
observability.performance.dashboard.read
observability.performance.metric.read
observability.performance.metric.manage
observability.performance.instrumentation.read
observability.performance.instrumentation.manage
observability.performance.baseline.read
observability.performance.baseline.manage
observability.performance.anomaly.read
observability.performance.anomaly.manage
observability.performance.regression.read
observability.performance.regression.manage
observability.performance.slo.read
observability.performance.slo.manage
observability.performance.capacity.read
observability.performance.capacity.manage
observability.performance.correlation.read
observability.performance.profile.read
observability.performance.profile.execute
observability.performance.report.read
observability.performance.report.export
observability.performance.tenant.read
observability.performance.cross_tenant.read
```

---

### 37. Role Mapping

| Role | Permission Utama |
|---|---|
| Platform Admin | seluruh performance |
| Operations Admin | platform/infrastructure/dashboard |
| DBA | database performance |
| Module Owner | module dan endpoint terkait |
| Frontend Engineer | frontend/RUM |
| Tenant Admin | tenant sendiri |
| Security Admin | restricted profile |
| Executive | SLO/capacity summary |
| Auditor | approved read-only |
| End User | tidak ada akses teknis |

---

### 38. Deployment Checklist

#### Pre-Deployment

- [ ] Backup database tersedia.
- [ ] Migration direview.
- [ ] Metric definitions divalidasi.
- [ ] Dimension/cardinality budget divalidasi.
- [ ] Baseline config divalidasi.
- [ ] SLI/SLO config divalidasi.
- [ ] Retention policy tersedia.
- [ ] Dashboard access policy tersedia.
- [ ] Alert rules tersedia.
- [ ] Scheduler config siap.
- [ ] Unit test lulus.
- [ ] Integration test lulus.
- [ ] Load test baseline tersedia.
- [ ] Security review lulus.
- [ ] Privacy review RUM/profiling lulus.

#### Deployment

1. Deploy code.
2. Jalankan migration.
3. Seed permissions.
4. Register metric definitions.
5. Register baselines.
6. Register SLI/SLO.
7. Aktifkan instrumentation dalam monitor mode.
8. Verifikasi metric ingestion.
9. Jalankan cardinality validation.
10. Jalankan initial rollup.
11. Jalankan baseline calculation.
12. Verifikasi dashboard.
13. Aktifkan alert secara bertahap.
14. Aktifkan SLO evaluation.
15. Aktifkan regression hook.
16. Aktifkan capacity forecast.

#### Post-Deployment

- [ ] HTTP metrics masuk.
- [ ] Database metrics masuk.
- [ ] Queue/scheduler metrics masuk.
- [ ] Rollup berjalan.
- [ ] Baseline valid.
- [ ] SLO dapat dihitung.
- [ ] Error budget tersedia.
- [ ] Dashboard scope-aware.
- [ ] Alert deduplication bekerja.
- [ ] Telemetry overhead memenuhi target.
- [ ] Tidak ada PHI/PII/secret pada telemetry.

---

### 39. Activation Strategy

Tahapan:

```text
OFF
→ SHADOW
→ MONITOR
→ ALERT
→ ENFORCE_GATES
```

#### SHADOW

- instrumentation aktif;
- dashboard internal;
- tidak ada alert;
- belum dipakai release gate.

#### MONITOR

- anomaly/regression dihitung;
- alert hanya warning;
- tuning baseline dan threshold.

#### ALERT

- alert aktif;
- incident policy diterapkan;
- SLO review berjalan.

#### ENFORCE_GATES

- regression dapat memblokir release;
- error budget policy dapat membatasi release;
- memerlukan governance formal.

---

### 40. Rollback Plan

1. Nonaktifkan release gate.
2. Nonaktifkan performance alert baru.
3. Hentikan analysis jobs yang bermasalah.
4. Pertahankan metric ingestion jika aman.
5. Rollback code.
6. Restore config sebelumnya.
7. Verifikasi SLI/SLO definition.
8. Verifikasi dashboard cache.
9. Re-run data quality check.
10. Re-enable dalam SHADOW mode.

Jangan menghapus metric history atau audit evidence saat rollback.

---

### 41. Emergency Kill Switch

Config:

```text
PERFORMANCE_MONITORING_ENABLED=true
PERFORMANCE_INSTRUMENTATION_ENABLED=true
PERFORMANCE_ANALYSIS_ENABLED=true
PERFORMANCE_ALERTING_ENABLED=true
PERFORMANCE_RELEASE_GATES_ENABLED=false
PERFORMANCE_RUM_ENABLED=true
PERFORMANCE_PROFILING_ENABLED=false
```

Penggunaan kill switch wajib:

- reason;
- owner;
- expiry;
- audit;
- compensating monitoring.

---

### 42. Load Test Strategy

Load test harus mengukur:

```text
latency
throughput
error rate
resource utilization
queue behavior
database behavior
cache efficiency
telemetry overhead
```

---

### 43. Load Test Types

```text
SMOKE
BASELINE
LOAD
STRESS
SPIKE
SOAK
CAPACITY
FAILOVER
```

---

### 44. Smoke Test

Tujuan:

- memastikan script bekerja;
- memastikan metric masuk;
- memverifikasi basic correctness.

---

### 45. Baseline Test

Menetapkan reference pada workload normal.

---

### 46. Load Test

Menguji expected production workload.

---

### 47. Stress Test

Mencari breaking point.

---

### 48. Spike Test

Menguji lonjakan mendadak.

---

### 49. Soak Test

Menguji memory leak, resource leak, dan degradation jangka panjang.

---

### 50. Capacity Test

Menentukan maksimum sustainable throughput.

---

### 51. Failover Test

Menguji kinerja selama:

- database failover;
- cache loss;
- dependency outage;
- worker restart;
- storage degradation.

---

### 52. Workload Model

Workload harus mendefinisikan:

```text
virtual users
requests per second
transaction mix
payload size
think time
data distribution
tenant distribution
test duration
ramp-up
ramp-down
```

---

### 53. Sample Workload Mix

```text
40% patient search
20% patient detail
15% appointment list
10% appointment create
10% homecare visit list
5% reporting
```

---

### 54. Load Test Data

Gunakan:

- synthetic data;
- production-like distribution;
- no real PHI/PII;
- deterministic identifiers;
- controlled tenant mix.

---

### 55. Load Test Acceptance

Contoh:

```text
p95 < 500 ms
p99 < 1.5 s
error rate < 1%
CPU < 75%
DB connections < 80%
queue wait p95 < 30 s
no memory growth > 10%
```

---

### 56. Telemetry Overhead Test

Bandingkan:

```text
instrumentation OFF
vs
instrumentation ON
```

Ukur:

- latency delta;
- CPU delta;
- memory delta;
- throughput delta;
- exporter queue.

---

### 57. Overhead Acceptance

Target awal:

```text
p95 latency overhead < 5 ms
CPU overhead < 2%
memory overhead < 2%
throughput impact < 2%
```

---

### 58. Cardinality Stress Test

Generate banyak dynamic route IDs dan tenant values.

Expected:

- route dinormalisasi;
- cardinality budget diterapkan;
- rejected series tercatat;
- exporter tetap stabil;
- application tidak gagal.

---

### 59. Baseline Simulation

#### Input

28 hari historical p95 HTTP latency.

Expected:

1. Exclusion window dihapus.
2. Minimum sample dicek.
3. Seasonal baseline dihitung.
4. Lower/upper bound dibuat.
5. Quality VALID.
6. Version disimpan.
7. Dashboard menampilkan band.
8. Audit event tercatat.

---

### 60. Insufficient Data Simulation

#### Input

Metric baru dengan 20 sample.

Expected:

```text
PERFORMANCE_BASELINE_INSUFFICIENT_DATA
```

Selain itu:

- no false baseline;
- status UNKNOWN/INSUFFICIENT_DATA;
- no critical alert;
- owner diberi warning.

---

### 61. Anomaly Simulation

#### Trigger

p95 latency naik dari expected 400 ms menjadi 1.2 s selama 15 menit.

Expected:

- anomaly score tinggi;
- persistence rule terpenuhi;
- anomaly OPEN;
- evidence tersimpan;
- alert dibuat;
- trace exemplar tersedia;
- dashboard ter-update.

---

### 62. False Positive Simulation

#### Trigger

Load test terjadwal menyebabkan latency spike.

Expected:

- annotation load test ditemukan;
- anomaly suppressed;
- no production incident;
- suppression diaudit;
- baseline history tidak tercemar.

---

### 63. Regression Simulation

#### Trigger

Deployment baru menaikkan p95:

```text
before = 420 ms
after = 620 ms
```

Expected:

- absolute delta = 200 ms;
- relative delta ≈ 47.6%;
- sample guard lulus;
- decision FAIL;
- severity MAJOR/CRITICAL;
- regression alert dibuat;
- release gate dapat memblokir rollout bila enabled.

---

### 64. Inconclusive Regression Simulation

#### Trigger

Candidate hanya memiliki 20 sample.

Expected:

```text
decision = INCONCLUSIVE
```

Tidak boleh dianggap PASS.

---

### 65. SLO Simulation

#### Input

```text
target = 99.9%
total events = 1.000.000
bad events = 2.000
```

Expected:

- attainment = 99.8%;
- SLO BREACHED;
- error budget negatif;
- burn rate dihitung;
- alert sesuai policy;
- dashboard status merah.

---

### 66. Multi-Window Burn Simulation

#### Trigger

5-minute burn = 20x  
1-hour burn = 15x

Expected:

- critical burn alert;
- incident candidate;
- owner notified;
- release freeze policy dapat aktif.

---

### 67. Capacity Forecast Simulation

#### Input

DB connections:

```text
current = 360
capacity = 500
growth = 5 connections/day
```

Expected:

- headroom = 140;
- exhaustion estimate ≈ 28 hari;
- risk AT_RISK;
- monthly capacity report mencantumkan action.

---

### 68. Noisy Neighbor Simulation

#### Trigger

Tenant A menghasilkan 40% traffic dan 70% DB time.

Expected:

- fairness ratio tinggi;
- tenant outlier terdeteksi;
- tenant-specific dashboard tersedia;
- cross-tenant data tidak bocor;
- recommendation untuk quota/throttling/capacity review.

---

### 69. Database Bottleneck Simulation

#### Trigger

- DB pool 95%;
- query p95 1.5 s;
- lock wait naik;
- HTTP p95 naik.

Expected:

- correlation candidate `database_contention`;
- confidence tinggi;
- top query code tersedia;
- alert/incident candidate;
- raw SQL tidak bocor.

---

### 70. Queue Bottleneck Simulation

#### Trigger

- queue depth meningkat;
- oldest message age 900 s;
- worker utilization 100%.

Expected:

- queue bottleneck;
- capacity risk;
- queue delay SLO at risk/breached;
- recommendation menambah worker atau mengurangi processing time.

---

### 71. Telemetry Failure Simulation

#### Trigger

Metric exporter unavailable.

Expected:

- application tetap berjalan;
- bounded queue aktif;
- P0 SLI counters diprioritaskan;
- low-priority telemetry dapat didrop;
- exporter failure alert;
- data quality menjadi PARTIAL/UNKNOWN.

---

### 72. Operational Runbook — Latency Spike

1. Cek affected service/route.
2. Cek p50/p95/p99.
3. Cek traffic dan error rate.
4. Cek deployment annotation.
5. Cek database contribution.
6. Cek dependency latency.
7. Cek queue/cache.
8. Buka trace exemplar.
9. Cek tenant outlier.
10. Mitigasi atau rollback.
11. Verifikasi recovery.
12. Dokumentasikan evidence.

---

### 73. Operational Runbook — Database Saturation

1. Cek connection utilization.
2. Cek waiters.
3. Cek top query code.
4. Cek lock/deadlock.
5. Cek rows examined.
6. Cek recent deployment/migration.
7. Cek tenant workload.
8. Kurangi expensive workload.
9. Scale/tune jika perlu.
10. Verifikasi SLO recovery.

---

### 74. Operational Runbook — Queue Backlog

1. Cek depth.
2. Cek oldest age.
3. Cek enqueue/dequeue rate.
4. Cek worker utilization.
5. Cek job duration.
6. Cek retry/dead-letter.
7. Cek downstream dependency.
8. Tambah worker atau pause producer bila aman.
9. Verifikasi backlog turun.
10. Review capacity.

---

### 75. Operational Runbook — Regression Detected

1. Verifikasi data quality.
2. Cek sample size.
3. Cek workload parity.
4. Cek warmup exclusion.
5. Cek changed components.
6. Cek trace/profile comparison.
7. Tentukan rollback/canary pause.
8. Catat decision.
9. Verifikasi setelah rollback/fix.
10. Update regression evidence.

---

### 76. Operational Runbook — SLO Burn High

1. Cek short/long burn window.
2. Cek affected SLI.
3. Cek event volume.
4. Cek anomaly/regression.
5. Cek incident aktif.
6. Terapkan error budget policy.
7. Mitigasi penyebab.
8. Monitor budget recovery.
9. Review release plan.
10. Dokumentasikan.

---

### 77. Operational Runbook — Capacity Risk

1. Cek forecast confidence.
2. Cek current headroom.
3. Cek growth source.
4. Cek planned onboarding/campaign.
5. Cek seasonality.
6. Tentukan scale-up/scale-out/tuning.
7. Tetapkan owner dan due date.
8. Verifikasi forecast setelah action.
9. Update capacity report.
10. Audit override bila ada.

---

### 78. Backup & Restore

Backup:

- metric definitions;
- dimensions;
- baselines;
- baseline versions;
- SLI/SLO;
- error budgets;
- deployment annotations;
- anomaly/regression evidence;
- capacity forecasts;
- reports;
- audit records.

Raw metric retention mengikuti SSOT-OBS-08.

Restore wajib menguji:

- metric registry;
- baseline history;
- SLI/SLO version;
- tenant ownership;
- report references;
- scheduler state;
- dashboard query;
- alert integration.

---

### 79. Retention of Performance Data

| Data | Retention |
|---|---|
| Raw metrics | 7–30 hari |
| 1-minute rollup | 30–90 hari |
| 1-hour rollup | 1 tahun |
| Daily rollup | 3 tahun |
| Baseline versions | 1–3 tahun |
| Anomalies | 1–3 tahun |
| Regression evidence | 2–5 tahun |
| SLI/SLO evaluations | 1–3 tahun |
| Capacity forecasts | 1–3 tahun |
| Reports | 1–5 tahun |
| Profiling data | 1–14 hari |

---

### 80. Final UAT — Metric Catalog & Instrumentation

- [ ] Metric registry bekerja.
- [ ] Metric code unik.
- [ ] Unit valid.
- [ ] Dimension allowlist bekerja.
- [ ] Cardinality budget bekerja.
- [ ] HTTP instrumentation aktif.
- [ ] Database instrumentation aktif.
- [ ] Queue/scheduler instrumentation aktif.
- [ ] Exporter failure tidak menggagalkan aplikasi.
- [ ] Overhead memenuhi target.

---

### 81. Final UAT — Baseline & Anomaly

- [ ] Static baseline bekerja.
- [ ] Rolling baseline bekerja.
- [ ] Seasonal baseline bekerja.
- [ ] Exclusion bekerja.
- [ ] Versioning bekerja.
- [ ] Insufficient data ditangani.
- [ ] Anomaly persistence bekerja.
- [ ] Suppression bekerja.
- [ ] False positive workflow bekerja.
- [ ] Quality gate diterapkan.

---

### 82. Final UAT — Regression

- [ ] Before/after comparison bekerja.
- [ ] Absolute threshold bekerja.
- [ ] Relative threshold bekerja.
- [ ] Sample guard bekerja.
- [ ] Warmup exclusion bekerja.
- [ ] Canary comparison bekerja.
- [ ] PASS/WARN/FAIL/INCONCLUSIVE tersedia.
- [ ] Override membutuhkan reason.
- [ ] Evidence tersedia.
- [ ] Release gate dapat dinonaktifkan.

---

### 83. Final UAT — SLI/SLO

- [ ] Good/total events dihitung.
- [ ] Exclusion diterapkan.
- [ ] SLI NO_DATA tersedia.
- [ ] SLO attainment dihitung.
- [ ] Error budget dihitung.
- [ ] Burn rate dihitung.
- [ ] Multi-window policy bekerja.
- [ ] Alert dibuat sesuai threshold.
- [ ] Versioning bekerja.
- [ ] Tenant contract SLO terisolasi.

---

### 84. Final UAT — Capacity & Correlation

- [ ] Headroom dihitung.
- [ ] Growth rate dihitung.
- [ ] 7/30/90-day forecast tersedia.
- [ ] Exhaustion estimate tersedia.
- [ ] Confidence tersedia.
- [ ] Database bottleneck correlation bekerja.
- [ ] Queue bottleneck correlation bekerja.
- [ ] Candidate root cause memiliki evidence.
- [ ] Recommendation lifecycle bekerja.
- [ ] Verification bekerja.

---

### 85. Final UAT — Dashboard & Reporting

- [ ] Overview dashboard bekerja.
- [ ] Service dashboard bekerja.
- [ ] Database dashboard bekerja.
- [ ] Queue dashboard bekerja.
- [ ] Frontend dashboard bekerja.
- [ ] SLO dashboard bekerja.
- [ ] Capacity dashboard bekerja.
- [ ] Tenant dashboard terisolasi.
- [ ] Report generation bekerja.
- [ ] Report export expire.
- [ ] Dashboard cache scope-aware.

---

### 86. Final UAT — Alert & Incident

- [ ] Latency anomaly membuat alert.
- [ ] Regression FAIL membuat alert.
- [ ] Burn rate critical membuat alert.
- [ ] Capacity risk membuat alert.
- [ ] Telemetry stale membuat alert.
- [ ] Deduplication bekerja.
- [ ] Maintenance suppression bekerja.
- [ ] Incident policy bekerja.
- [ ] Recovery menutup alert.
- [ ] Audit tersedia.

---

### 87. Final UAT — Security

- [ ] Raw SQL tidak terekspos.
- [ ] PHI/PII tidak masuk telemetry.
- [ ] Route dinormalisasi.
- [ ] Tenant/scope isolation bekerja.
- [ ] Cross-tenant permission diterapkan.
- [ ] Profiling dibatasi.
- [ ] Export terenkripsi.
- [ ] Report folder tidak public.
- [ ] CSRF aktif.
- [ ] Rate limit aktif.
- [ ] Manual override diaudit.
- [ ] Diagnostic mode memiliki expiry.

---

### 88. Final UAT — Scheduler & Recovery

- [ ] Rollup job berjalan.
- [ ] Baseline job berjalan.
- [ ] Anomaly job berjalan.
- [ ] Regression hook berjalan.
- [ ] SLI/SLO job berjalan.
- [ ] Capacity job berjalan.
- [ ] Correlation job berjalan.
- [ ] Report job berjalan.
- [ ] Quality job berjalan.
- [ ] Stuck job terdeteksi.
- [ ] Lock/idempotency bekerja.
- [ ] Backup/restore diuji.
- [ ] Kill switch diuji.
- [ ] Rollback diuji.

---

### 89. Production Readiness Checklist

- [ ] Semua metric memiliki owner.
- [ ] Semua dimension memiliki budget.
- [ ] Instrumentation overhead aman.
- [ ] Baseline valid.
- [ ] SLI/SLO disetujui.
- [ ] Error budget policy tersedia.
- [ ] Deployment annotation aktif.
- [ ] Regression rule tersedia.
- [ ] Capacity forecast aktif.
- [ ] Dashboard tersedia.
- [ ] Alert tersedia.
- [ ] Runbook tersedia.
- [ ] Tenant isolation diuji.
- [ ] Privacy/security review lulus.
- [ ] Load test lulus.
- [ ] Soak test lulus.
- [ ] Rollback diuji.
- [ ] Operations sign-off tersedia.
- [ ] Service owner sign-off tersedia.

---

### 90. Ownership Matrix

| Area | Owner |
|---|---|
| Performance Framework | Platform Kernel Team |
| Metric Definitions | Service/Module Owner |
| HTTP Instrumentation | Platform Kernel Team |
| Database Instrumentation | Platform Data Team |
| Queue/Scheduler | Platform Operations |
| Frontend/RUM | Frontend Team |
| Baselines | Service Owner |
| SLI/SLO | Service + Business Owner |
| Capacity Forecast | Platform Operations |
| Regression Gates | Release Engineering |
| Alerts/Incidents | Platform Operations |
| Privacy/Security | Security & Data Governance |

---

### 91. Definition of Done — SSOT-OBS-09

#### Foundation

- [ ] performance domains;
- [ ] Golden Signals;
- [ ] RED/USE;
- [ ] metric catalog;
- [ ] ownership;
- [ ] tenant/scope;
- [ ] privacy/security.

#### Instrumentation

- [ ] HTTP;
- [ ] database;
- [ ] cache;
- [ ] queue;
- [ ] scheduler;
- [ ] workflow;
- [ ] integration;
- [ ] frontend/RUM;
- [ ] synthetic;
- [ ] sampling;
- [ ] cardinality governance.

#### Intelligence

- [ ] baseline engine;
- [ ] anomaly detection;
- [ ] regression analysis;
- [ ] SLI/SLO;
- [ ] error budget;
- [ ] burn rate;
- [ ] capacity forecasting;
- [ ] bottleneck analysis;
- [ ] correlation;
- [ ] recommendations.

#### Infrastructure

- [ ] HTTP API;
- [ ] controllers;
- [ ] middleware;
- [ ] database schema;
- [ ] scheduler;
- [ ] dashboard API;
- [ ] alert integration;
- [ ] audit;
- [ ] Apache/XAMPP routing.

#### Operations

- [ ] reference implementation;
- [ ] sample metrics;
- [ ] sample baselines;
- [ ] sample SLI/SLO;
- [ ] deployment;
- [ ] rollback;
- [ ] load testing;
- [ ] simulations;
- [ ] runbooks;
- [ ] final UAT.

---

### 92. Implementation Definition of Done

Implementasi dianggap selesai bila:

- [ ] core classes dibuat;
- [ ] migrations berhasil;
- [ ] metric registry aktif;
- [ ] instrumentation aktif;
- [ ] rollup aktif;
- [ ] baseline aktif;
- [ ] anomaly detection aktif;
- [ ] regression analysis aktif;
- [ ] SLI/SLO aktif;
- [ ] error budget aktif;
- [ ] capacity forecast aktif;
- [ ] dashboard aktif;
- [ ] alert aktif;
- [ ] audit aktif;
- [ ] scheduler aktif;
- [ ] unit test lulus;
- [ ] integration test lulus;
- [ ] load test lulus;
- [ ] UAT lulus;
- [ ] performance overhead target tercapai;
- [ ] security review lulus;
- [ ] privacy review lulus;
- [ ] deployment/rollback diuji.

---

### 93. Roadmap

#### Phase 1 — Foundation

- metric registry;
- HTTP/PDO instrumentation;
- basic dashboard;
- static baseline;
- basic SLO;
- manual load test.

#### Phase 2 — Analysis

- rolling/seasonal baseline;
- anomaly detection;
- regression comparison;
- error budget;
- capacity forecast;
- synthetic monitoring.

#### Phase 3 — Enterprise Performance

- RUM;
- profiling;
- canary comparison;
- release gates;
- tenant fairness;
- advanced correlation;
- executive reporting.

#### Phase 4 — Intelligence & Automation

- adaptive baseline;
- predictive scaling;
- automated bottleneck ranking;
- optimization recommendation;
- automated rollback guardrails;
- capacity optimization;
- AI-assisted performance analysis.

---

### 94. Future Evolution

- OpenTelemetry metrics/traces integration;
- external APM adapter;
- eBPF profiling;
- continuous profiling;
- browser RUM SDK;
- synthetic browser grid;
- multi-region probes;
- adaptive sampling;
- statistical release gates;
- automated capacity scaling;
- cost-performance optimization;
- workload-aware anomaly detection;
- tenant cohort intelligence;
- performance digital twin;
- AI-assisted root cause candidate.

---

### 95. Merge Guidance

Gabungkan:

```text
SSOT-OBS-09-Part-1.md
SSOT-OBS-09-Part-2.md
SSOT-OBS-09-Part-3.md
SSOT-OBS-09-Part-4.md
SSOT-OBS-09-Part-5.md
```

menjadi:

```text
SSOT-OBS-09.md
```

Urutan:

```text
Part 1 — Vision, Performance Domains, Baselines, SLI/SLO
Part 2 — Metric Catalog, Instrumentation, Synthetic, RUM
Part 3 — Analysis, Regression, Capacity, Correlation, Reporting
Part 4 — API, Scheduler, Database, Dashboard, Alerting
Part 5 — Reference Implementation & Operations
```

---

### 96. Merge Quality Checklist

- [ ] heading tidak duplikat;
- [ ] metric codes konsisten;
- [ ] domain codes konsisten;
- [ ] dimension names konsisten;
- [ ] baseline states konsisten;
- [ ] anomaly states konsisten;
- [ ] regression decisions konsisten;
- [ ] SLI/SLO fields konsisten;
- [ ] permission konsisten;
- [ ] table names konsisten;
- [ ] namespace konsisten;
- [ ] endpoint konsisten;
- [ ] error code konsisten;
- [ ] duplicate section dihapus;
- [ ] daftar isi dibuat;
- [ ] metadata final diperbarui;
- [ ] status final diset Review/Approved.

---

### 97. Final Metadata

```yaml
document_code: SSOT-OBS-09
title: Performance Monitoring Framework
version: 1.0
status: Draft for Review
domain: Platform Kernel
category: Observability
owners:
  - Platform Architecture
  - Platform Operations
  - Service Owners
reviewers:
  - Backend Engineering
  - Frontend Engineering
  - Platform Data
  - DevOps
  - QA
  - Security
  - Data Governance
```

---

### 98. Approval Gate

Dokumen dapat menjadi Approved setelah:

- architecture review;
- metric catalog review;
- instrumentation review;
- database performance review;
- frontend/RUM privacy review;
- SLI/SLO review;
- capacity review;
- alert/incident review;
- database schema review;
- security review;
- QA/UAT review;
- load test review;
- telemetry overhead review;
- deployment/rollback review;
- operations sign-off.

---

### 99. Closing Statement

Performance Monitoring Framework harus memastikan kinerja platform:

- terukur;
- memiliki baseline;
- memiliki target;
- dapat dibandingkan;
- dapat didiagnosis;
- dapat diproyeksikan;
- dapat dikorelasikan;
- dapat ditingkatkan secara objektif.

Framework tidak boleh:

- hanya mengandalkan average;
- membuat metric tanpa owner;
- menggunakan high-cardinality label tanpa batas;
- menghitung SLO dari sampled counter;
- menganggap UNKNOWN sebagai sehat;
- membuat regression decision tanpa data cukup;
- menjalankan profiling tanpa kontrol;
- membocorkan PHI/PII;
- menjadikan telemetry sebagai bottleneck.

Framework harus mengubah performance dari asumsi subjektif menjadi sistem pengukuran yang dapat dijalankan, diaudit, dibandingkan, dan digunakan untuk keputusan engineering serta operasional.

---

## Lampiran A — Sumber Penggabungan

Dokumen final ini digabung dan dinormalisasi dari:

- `SSOT-OBS-09-Part-1.md`
- `SSOT-OBS-09-Part-2.md`
- `SSOT-OBS-09-Part-3.md`
- `SSOT-OBS-09-Part-4.md`
- `SSOT-OBS-09-Part-5.md`

## Lampiran B — Approval Gate

Status dokumen dapat diubah menjadi **Approved** setelah:

- architecture review selesai;
- metric catalog review selesai;
- instrumentation review selesai;
- database performance review selesai;
- frontend/RUM privacy review selesai;
- SLI/SLO review selesai;
- capacity review selesai;
- alert dan incident review selesai;
- database schema disetujui;
- permission dan tenant/scope policy disetujui;
- security review selesai;
- QA/UAT review selesai;
- load test review selesai;
- telemetry overhead review selesai;
- deployment dan rollback review selesai;
- operations sign-off tersedia.
