
# SSOT-OBS-04 — Distributed Tracing

## Status

| Item | Nilai |
|---|---|
| Kode | SSOT-OBS-04 |
| Nama | Distributed Tracing |
| Versi | 1.0 |
| Status | Draft Implementation Standard |
| Domain | Observability |
| Bergantung pada | SSOT-OBS-01, SSOT-OBS-02, SSOT-OBS-03, SSOT-EVENT-01, SSOT-API-01 |

---

# 1. Tujuan

Distributed Tracing menyediakan kemampuan menelusuri satu request secara end-to-end
melewati seluruh komponen Platform Kernel.

Tracing digunakan untuk:

- menemukan bottleneck;
- menganalisis latency;
- investigasi kegagalan lintas modul;
- menghubungkan log, metric, audit, dan event.

---

# 2. Konsep

Setiap request menghasilkan:

- trace_id
- correlation_id
- request_id

Setiap operasi di dalam request menghasilkan **span**.

```text
Trace
 ├── Span: HTTP Request
 ├── Span: Authentication
 ├── Span: Scope
 ├── Span: RBAC
 ├── Span: Controller
 ├── Span: Service
 ├── Span: Repository
 ├── Span: Database
 ├── Span: Event Publish
 └── Span: Response
```

---

# 3. Arsitektur

```text
Browser / Mobile
        │
        ▼
HTTP Request
        │
        ▼
Trace Middleware
        │
        ▼
Controller
        │
        ▼
Service
        │
        ▼
Repository
        │
        ▼
Database

        │
        ├── Event
        ├── Workflow
        ├── Notification
        └── Integration
```

Semua span berada dalam trace yang sama.

---

# 4. Identifier

## trace_id

Identitas global sebuah perjalanan request.

## span_id

Identitas unik setiap operasi.

## parent_span_id

Menghubungkan span dengan induknya.

## correlation_id

Menghubungkan tracing dengan log, audit, dan event.

---

# 5. Span Minimum

Setiap request minimal memiliki span:

- HTTP
- Authentication
- Scope
- Permission
- Controller
- Service
- Repository
- Database
- Response

Tambahkan span lain bila relevan:

- Event Publish
- Notification
- Workflow
- Scheduler
- External API

---

# 6. Data Span

Minimal:

- trace_id
- span_id
- parent_span_id
- operation_name
- module
- start_time
- end_time
- duration_ms
- status
- error_flag

---

# 7. Operation Naming

Gunakan pola:

domain.component.action

Contoh:

- api.patient.create
- workflow.approval.transition
- integration.satusehat.submit
- repository.patient.insert

---

# 8. Error Tracing

Jika span gagal:

- tandai status ERROR;
- simpan exception class;
- simpan error code;
- hubungkan dengan correlation_id.

---

# 9. Integrasi

Tracing harus terhubung dengan:

- Structured Logging
- Metrics
- Audit Trail
- Event Bus
- Workflow
- Notification
- Integration

---

# 10. Background Job

Job yang berasal dari request harus membawa:

- trace_id
- correlation_id

Agar investigasi lintas asynchronous tetap memungkinkan.

---

# 11. Database

Contoh tabel:

## observability_traces

- trace_id
- correlation_id
- started_at
- finished_at
- duration_ms
- status

## observability_spans

- span_id
- trace_id
- parent_span_id
- operation_name
- module
- duration_ms
- status

---

# 12. Dashboard

Dashboard tracing minimal menyediakan:

- daftar trace terbaru
- trace dengan latency tertinggi
- trace gagal
- waterfall span
- filter berdasarkan correlation_id

---

# 13. Retention

Rekomendasi:

- trace detail: 7–30 hari
- agregasi statistik: 90 hari atau sesuai kebijakan organisasi.

---

# 14. Anti-pattern

Hindari:

- trace tanpa span
- span tanpa trace_id
- trace tidak terhubung ke log
- operasi penting tanpa tracing
- trace menyimpan data sensitif

---

# 15. UAT

- [ ] Semua request memiliki trace_id.
- [ ] Semua span saling terhubung.
- [ ] Event dan job membawa correlation_id.
- [ ] Error dapat ditelusuri sampai repository/database.
- [ ] Dashboard dapat mencari berdasarkan trace_id.

---

# 16. Definition of Done

Distributed Tracing dianggap siap apabila:

- trace_id dan span_id diterapkan konsisten;
- seluruh layer utama menghasilkan span;
- tracing terhubung dengan log, metric, audit, dan event;
- request sinkron maupun asynchronous dapat ditelusuri end-to-end.
