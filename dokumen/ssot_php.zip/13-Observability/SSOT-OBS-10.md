# SSOT-OBS-10 — Audit vs Logging vs Event Guideline

> Single Source of Truth untuk membedakan, merancang, menyimpan, mengirim, mengamankan, dan mengoperasikan audit record, application log, security event, domain event, integration event, telemetry event, trace, metric, serta incident record pada Platform Kernel.

## Metadata Dokumen

| Item | Nilai |
|---|---|
| Kode | SSOT-OBS-10 |
| Judul | Audit vs Logging vs Event Guideline |
| Versi | 1.0 |
| Status | Draft for Review |
| Domain | Platform Kernel |
| Kategori | Observability & Governance |
| Target Stack | PHP 8.1+, PDO, MySQL 8/MariaDB, Apache/XAMPP, Modular Monolith |
| Bergantung pada | SSOT-OBS-01 sampai SSOT-OBS-09 |
| Pemilik | Platform Architecture, Security, Compliance, Platform Operations |
| Reviewer | Backend Engineering, Domain Owners, Integration Engineering, DevOps, QA, Legal, Data Governance |

## Tujuan Dokumen

Dokumen ini menetapkan standar tunggal untuk:

- taxonomy dan boundary audit, logging, security event, domain event, integration event, telemetry event, trace, metric, dan incident record;
- schema, envelopes, registry, versioning, compatibility, idempotency, ordering, delivery semantics, outbox/inbox, replay, redrive, dan privacy controls;
- storage separation, append-only audit, integrity, hash chain, event persistence, broker abstraction, retention, legal hold, chain of custody, archive, disaster recovery, dan capacity;
- HTTP API, controllers, middleware, permissions, scheduler, dispatcher, outbox worker, inbox consumer, database schema, routing, security, audit, metrics, dan alerting;
- reference implementation, sample registries dan schemas, migration, deployment, rollback, simulations, runbooks, UAT, dan Definition of Done.

## Daftar Isi

1. Bagian I — Vision, Definitions, Boundaries, Decision Matrix, Ownership & Governance
2. Bagian II — Schema Standards, Event Envelopes, Registry, Compatibility, Idempotency, Outbox/Inbox, Delivery, Replay & Privacy
3. Bagian III — Storage Architecture, Audit Integrity, Append-Only, Event Persistence, Broker Abstraction, Retention, Legal Hold, Chain of Custody, DR & Performance
4. Bagian IV — HTTP API, Controllers, Middleware, Database Schema, Scheduler, Dispatcher, Outbox/Inbox Workers, Audit Integration & Routing
5. Bagian V — Reference Implementation, Sample Registries, Deployment, Simulation, Final UAT & Operational Readiness
6. Lampiran A — Sumber Penggabungan
7. Lampiran B — Approval Gate

## Status Normatif

Kata **wajib**, **harus**, dan **tidak boleh** menyatakan persyaratan normatif. Kata **direkomendasikan**, **sebaiknya**, dan **dapat** menyatakan panduan yang dapat disesuaikan melalui keputusan arsitektur terdokumentasi.

---

## Bagian I — Vision, Definitions, Boundaries, Decision Matrix, Ownership & Governance

### 1. Executive Summary

SSOT-OBS-10 menetapkan pedoman tunggal untuk membedakan dan mengelola:

```text
Audit Record
Application Log
Security Event
Domain Event
Integration Event
Telemetry Event
Distributed Trace
Metric
Incident Record
```

Tujuan utamanya adalah mencegah satu mekanisme dipakai untuk semua kebutuhan.

Contoh kesalahan umum:

- audit disimpan sebagai log biasa;
- domain event dipakai sebagai debug message;
- integration event tidak memiliki schema;
- log memuat PHI/PII berlebihan;
- trace dianggap evidence legal;
- metric memiliki label ber-cardinality tinggi;
- event penting hilang karena sampling;
- audit dapat diedit oleh application admin;
- event bus dijadikan storage permanen;
- incident record hanya bergantung pada chat atau log sementara.

Framework harus memastikan setiap signal memiliki:

- purpose;
- owner;
- durability;
- retention;
- integrity;
- access policy;
- privacy classification;
- delivery semantics;
- schema;
- storage;
- auditability;
- lifecycle.

---

### 2. Problem Statement

Tanpa guideline yang tegas, developer cenderung menggunakan satu istilah untuk banyak hal.

Contoh:

```text
"event"
```

dapat berarti:

- sesuatu terjadi di domain;
- message dikirim ke queue;
- log baris baru;
- audit action;
- telemetry signal;
- browser click;
- incident occurrence.

Ambiguitas ini menyebabkan:

- desain schema tidak konsisten;
- data sulit dicari;
- retention salah;
- bukti audit tidak dapat dipercaya;
- event delivery tidak idempotent;
- log membengkak;
- security boundary lemah;
- integrasi antar module rapuh;
- observability dan compliance bercampur.

---

### 3. Tujuan Framework

Dokumen ini harus menjawab:

- Kapan menggunakan audit?
- Kapan menggunakan log?
- Kapan menggunakan domain event?
- Kapan menggunakan integration event?
- Kapan menggunakan security event?
- Kapan menggunakan telemetry event?
- Kapan menggunakan trace?
- Kapan menggunakan metric?
- Data apa yang wajib disimpan?
- Data apa yang tidak boleh dicatat?
- Siapa owner setiap signal?
- Bagaimana retention dan integrity ditentukan?
- Apakah signal boleh disampling?
- Apakah signal boleh diubah atau dihapus?
- Bagaimana tenant/scope isolation diterapkan?
- Bagaimana schema versioning diterapkan?

---

### 4. Non-Goals

Part 1 tidak mendefinisikan secara detail:

- event bus implementation;
- outbox implementation;
- database schema lengkap;
- HTTP API;
- message broker vendor;
- audit storage engine;
- log shipping;
- tracing SDK;
- alert rules;
- migration dan deployment.

Hal tersebut dibahas pada Part 2–5.

---

### 5. Core Principle

Satu kejadian bisnis dapat menghasilkan beberapa signal berbeda.

Contoh:

```text
User memperbarui data pasien
```

Dapat menghasilkan:

```text
Audit Record
→ siapa mengubah apa, kapan, dari nilai apa ke nilai apa

Domain Event
→ PatientProfileUpdated

Application Log
→ proses update berhasil atau gagal

Security Event
→ perubahan dilakukan dari device/IP berisiko

Trace
→ durasi controller, service, repository, database

Metric
→ patient_update_total
```

Setiap signal memiliki purpose berbeda.

---

### 6. Signal Taxonomy

Framework menetapkan taxonomy:

```text
AUDIT_RECORD
APPLICATION_LOG
SECURITY_EVENT
DOMAIN_EVENT
INTEGRATION_EVENT
TELEMETRY_EVENT
TRACE_SPAN
METRIC_SAMPLE
INCIDENT_RECORD
```

---

### 7. Audit Record

Audit Record adalah bukti terstruktur mengenai tindakan, keputusan, akses, atau perubahan yang relevan terhadap governance, security, compliance, dan accountability.

Audit menjawab:

```text
Who
Did what
To which resource
When
From where
Why
What changed
What was the result
```

---

### 8. Application Log

Application Log adalah catatan operasional untuk memahami perilaku aplikasi.

Log menjawab:

```text
What happened operationally
Where it happened
Why it may have failed
How to diagnose it
```

---

### 9. Security Event

Security Event adalah kejadian yang relevan terhadap authentication, authorization, threat detection, policy violation, dan incident response.

Security event menjawab:

```text
What security-relevant activity occurred
Who or what triggered it
What asset was affected
How risky it was
What response followed
```

---

### 10. Domain Event

Domain Event adalah fakta bisnis yang sudah terjadi dalam bounded context.

Contoh:

```text
PatientRegistered
AppointmentBooked
HomecareVisitCompleted
InvoiceIssued
```

Domain event menjawab:

```text
What business fact occurred
```

---

### 11. Integration Event

Integration Event adalah message contract untuk memberitahu module atau service lain mengenai perubahan yang relevan.

Integration event menjawab:

```text
What external consumers need to know
```

---

### 12. Telemetry Event

Telemetry Event adalah signal observability terstruktur yang mendeskripsikan kejadian teknis.

Contoh:

```text
cache_stampede_detected
archive_verification_failed
performance_regression_detected
```

---

### 13. Trace Span

Trace Span adalah unit waktu dalam distributed trace.

Trace menjawab:

```text
Which operations formed the request path
How long each operation took
Where latency or failure occurred
```

---

### 14. Metric Sample

Metric Sample adalah nilai numerik teragregasi atau dapat diagregasi.

Metric menjawab:

```text
How much
How often
How fast
How saturated
```

---

### 15. Incident Record

Incident Record adalah record formal mengenai gangguan atau risiko operasional.

Incident menjawab:

```text
What impact occurred
Who coordinated the response
What decisions were made
How recovery happened
```

---

### 16. Primary Purpose Matrix

| Signal | Primary Purpose |
|---|---|
| Audit Record | Accountability & evidence |
| Application Log | Troubleshooting & operations |
| Security Event | Threat detection & security response |
| Domain Event | Internal business state propagation |
| Integration Event | Cross-boundary communication |
| Telemetry Event | Observability correlation |
| Trace Span | Request path and latency analysis |
| Metric Sample | Aggregation and trend analysis |
| Incident Record | Operational response governance |

---

### 17. Durability Matrix

| Signal | Durability |
|---|---|
| Audit Record | High |
| Application Log | Medium |
| Security Event | High |
| Domain Event | Depends on domain policy |
| Integration Event | Until delivered/retained |
| Telemetry Event | Medium |
| Trace Span | Low–Medium |
| Metric Sample | Aggregated retention |
| Incident Record | High |

---

### 18. Immutability Matrix

| Signal | Immutability |
|---|---|
| Audit Record | Append-only |
| Application Log | Append-only operationally |
| Security Event | Append-only |
| Domain Event | Immutable fact |
| Integration Event | Immutable message |
| Telemetry Event | Append-only |
| Trace Span | Append-only |
| Metric Sample | Append-only/aggregated |
| Incident Record | Versioned updates |

---

### 19. Sampling Matrix

| Signal | Sampling |
|---|---|
| Audit Record | Tidak boleh |
| Application Log | Dapat, sesuai level |
| Security Event | Critical tidak boleh |
| Domain Event | Tidak boleh bila source of truth |
| Integration Event | Tidak boleh |
| Telemetry Event | Dapat |
| Trace Span | Dapat |
| Metric Sample | Aggregation, bukan random loss untuk SLI |
| Incident Record | Tidak boleh |

---

### 20. Retention Matrix

| Signal | Retention |
|---|---|
| Audit Record | Long/regulated |
| Application Log | Short–medium |
| Security Event | Medium–long |
| Domain Event | Domain-specific |
| Integration Event | Delivery + replay window |
| Telemetry Event | Short–medium |
| Trace Span | Short |
| Metric Sample | Rollup-based |
| Incident Record | Long |

---

### 21. Schema Strictness Matrix

| Signal | Schema Strictness |
|---|---|
| Audit Record | Strict |
| Application Log | Structured but flexible |
| Security Event | Strict |
| Domain Event | Strict |
| Integration Event | Strict and versioned |
| Telemetry Event | Structured |
| Trace Span | Standard attributes |
| Metric Sample | Strict metric definition |
| Incident Record | Strict core + narrative |

---

### 22. Audit Record Characteristics

Audit record wajib:

- memiliki actor;
- memiliki action;
- memiliki resource;
- memiliki result;
- memiliki timestamp;
- tenant/scope-aware;
- immutable;
- tidak disampling;
- memiliki retention policy;
- memiliki integrity protection;
- memiliki access control;
- dapat ditelusuri ke request atau workflow.

---

### 23. Audit Record Minimum Fields

```text
audit_id
occurred_at
actor_type
actor_id
action_code
resource_type
resource_id
tenant_id
scope_id
result
reason
source_ip optional
user_agent_class optional
correlation_id
before_hash optional
after_hash optional
changes_json optional
classification
```

---

### 24. Audit Use Cases

Gunakan audit untuk:

- login/logout penting;
- failed authentication tertentu;
- role/permission change;
- patient data access;
- patient data update;
- clinical record access;
- configuration change;
- retention policy change;
- legal hold action;
- purge execution;
- export/download;
- cross-tenant access;
- privileged operation;
- approval/rejection;
- consent change;
- secret/key management action.

---

### 25. Audit Non-Use Cases

Jangan gunakan audit untuk:

- debug loop;
- setiap function call;
- health check;
- cache hit;
- routine trace span;
- high-frequency telemetry tanpa governance relevance.

---

### 26. Application Log Characteristics

Application log sebaiknya:

- structured;
- memiliki level;
- memiliki event code;
- memiliki module;
- memiliki correlation ID;
- tenant-aware bila relevan;
- disanitasi;
- bounded;
- tidak menjadi source of truth.

---

### 27. Log Levels

```text
TRACE
DEBUG
INFO
WARN
ERROR
CRITICAL
```

---

### 28. Log Use Cases

Gunakan log untuk:

- startup/shutdown;
- configuration load;
- operation success/failure;
- dependency timeout;
- retry;
- exception;
- fallback;
- circuit breaker;
- scheduler state;
- queue processing;
- archive/purge operation detail;
- performance diagnostic.

---

### 29. Log Non-Use Cases

Jangan gunakan log untuk:

- authoritative business state;
- legal evidence utama;
- integration contract;
- metric label store;
- raw request/response sensitif;
- password/token/secret;
- full PHI/PII tanpa kebutuhan.

---

### 30. Security Event Characteristics

Security event wajib:

- memiliki event code;
- actor dan subject;
- risk/severity;
- policy reference;
- source context;
- outcome;
- correlation;
- immutable;
- protected retention;
- restricted access.

---

### 31. Security Event Use Cases

- suspicious login;
- MFA failure;
- brute force;
- privilege escalation;
- access denied;
- cross-tenant attempt;
- secret access;
- policy violation;
- unusual export;
- malware/threat signal;
- tampering;
- audit integrity failure.

---

### 32. Domain Event Characteristics

Domain event:

- merepresentasikan fakta lampau;
- diberi nama past tense;
- immutable;
- memiliki aggregate reference;
- memiliki occurred_at;
- memiliki schema version;
- tidak memuat dependency-specific detail;
- diterbitkan setelah state valid.

---

### 33. Domain Event Naming

Gunakan:

```text
PatientRegistered
AppointmentScheduled
VisitCompleted
InvoicePaid
```

Hindari:

```text
RegisterPatient
UpdateAppointment
DoVisit
```

Command bukan event.

---

### 34. Domain Event Minimum Fields

```text
event_id
event_name
event_version
aggregate_type
aggregate_id
occurred_at
tenant_id
scope_id
actor_reference optional
correlation_id
causation_id
payload
```

---

### 35. Domain Event Use Cases

- aggregate state changed;
- workflow milestone;
- business decision finalized;
- business obligation created;
- resource lifecycle changed.

---

### 36. Domain Event Non-Use Cases

Jangan gunakan domain event untuk:

- debug information;
- transient technical retry;
- raw database row dump;
- request telemetry;
- UI click;
- infrastructure health.

---

### 37. Integration Event Characteristics

Integration event:

- consumer-oriented;
- versioned;
- backward compatible;
- idempotent;
- delivery-aware;
- minimal data;
- no internal implementation leakage;
- tenant-aware;
- replay-aware.

---

### 38. Integration Event Minimum Fields

```text
message_id
event_name
schema_version
published_at
producer
tenant_id
correlation_id
causation_id
idempotency_key
payload
```

---

### 39. Domain vs Integration Event

| Aspek | Domain Event | Integration Event |
|---|---|---|
| Audience | Bounded context internal | External module/service |
| Payload | Domain-rich | Consumer-safe |
| Schema | Internal versioned | Public contract versioned |
| Delivery | In-process/outbox | Broker/queue |
| Coupling | Domain | Contract |
| Privacy | Internal policy | Minimum necessary |

---

### 40. Telemetry Event Characteristics

Telemetry event digunakan untuk observability.

Contoh:

```text
performance_anomaly_detected
archive_batch_failed
cache_stampede_detected
scheduler_job_stuck
```

Telemetry event tidak otomatis menjadi audit record.

---

### 41. Trace Span Characteristics

Span wajib:

- memiliki trace ID;
- span ID;
- parent span ID optional;
- operation name;
- start/end;
- status;
- standardized attributes;
- bounded payload;
- sampling policy.

---

### 42. Metric Characteristics

Metric wajib:

- memiliki code;
- type;
- unit;
- dimensions allowlist;
- owner;
- retention;
- cardinality budget;
- aggregation semantics.

---

### 43. Incident Record Characteristics

Incident record wajib:

- incident ID;
- severity;
- status;
- impact;
- timeline;
- commander;
- responders;
- decisions;
- recovery;
- root cause;
- corrective actions;
- audit trail.

---

### 44. Decision Matrix

Gunakan pertanyaan berikut.

#### Question 1

Apakah data dibutuhkan sebagai bukti siapa melakukan apa?

```text
YES → Audit Record
```

#### Question 2

Apakah data merepresentasikan fakta bisnis yang telah terjadi?

```text
YES → Domain Event
```

#### Question 3

Apakah fakta harus dikirim ke module/service lain?

```text
YES → Integration Event
```

#### Question 4

Apakah data digunakan untuk troubleshooting teknis?

```text
YES → Application Log
```

#### Question 5

Apakah data relevan terhadap threat/security policy?

```text
YES → Security Event
```

#### Question 6

Apakah data menjelaskan jalur dan durasi request?

```text
YES → Trace Span
```

#### Question 7

Apakah data berupa nilai numerik untuk agregasi?

```text
YES → Metric
```

#### Question 8

Apakah data merupakan record koordinasi gangguan?

```text
YES → Incident Record
```

---

### 45. Multi-Signal Rule

Satu operation dapat menghasilkan lebih dari satu signal.

Contoh:

```text
User exports patient data
```

Wajib menghasilkan:

```text
Audit Record
Security Event optional
Application Log
Metric
Trace
```

Tidak cukup hanya satu log.

---

### 46. Example — Patient Update

```text
Audit:
PATIENT_PROFILE_UPDATED

Domain Event:
PatientProfileUpdated

Integration Event:
PatientProfileChangedV1

Log:
patient_profile_update_completed

Trace:
patient.update

Metric:
patient_update_total
patient_update_duration_seconds
```

---

### 47. Example — Failed Authorization

```text
Audit:
PRIVILEGED_ACTION_DENIED

Security Event:
authorization_policy_denied

Log:
authorization_denied

Metric:
authorization_denied_total

Trace:
authz.evaluate
```

---

### 48. Example — Scheduler Job

```text
Audit:
hanya jika job melakukan privileged/destructive action

Log:
scheduler_job_started
scheduler_job_completed
scheduler_job_failed

Telemetry Event:
scheduler_job_stuck

Metric:
scheduler_job_duration_seconds
scheduler_job_failed_total

Trace:
scheduler.job.execute
```

---

### 49. Example — Purge Operation

```text
Audit:
LOG_PURGE_EXECUTED

Security Event:
jika policy bypass/tampering dicoba

Domain Event:
LogPurgeCompleted optional internal

Integration Event:
LogPurgeEvidenceCreated optional

Log:
purge_batch_started/completed/failed

Metric:
purge_records_deleted_total
purge_duration_seconds

Trace:
retention.purge.execute
```

---

### 50. Source of Truth Matrix

| Data | Source of Truth |
|---|---|
| Business state | Domain database |
| Business fact history | Domain event store if adopted |
| Integration delivery | Outbox/message store |
| Accountability | Audit store |
| Troubleshooting | Log store |
| Security detection | Security event store/SIEM |
| Performance | Metric/tracing backend |
| Incident governance | Incident management store |

---

### 51. Audit Is Not Log

Audit tidak boleh hanya bergantung pada application log karena:

- log dapat disampling;
- log retention lebih pendek;
- log akses lebih luas;
- log schema lebih fleksibel;
- log dapat hilang saat exporter failure;
- log belum tentu immutable;
- log tidak selalu memuat before/after.

---

### 52. Event Is Not Log

Event tidak boleh dianggap log karena:

- event memiliki consumer;
- event memiliki contract;
- event delivery semantics;
- event idempotency;
- event versioning;
- event dapat memicu state change lain.

---

### 53. Trace Is Not Audit

Trace tidak dapat menjadi audit utama karena:

- sampling;
- retention pendek;
- diagnostic purpose;
- attribute dapat tidak lengkap;
- tidak selalu immutable;
- bukan governance evidence.

---

### 54. Metric Is Not Event History

Metric tidak dapat menjelaskan detail individual event.

Metric hanya agregasi.

---

### 55. Security Event vs Audit

Security event fokus pada detection dan response.

Audit fokus pada accountability dan evidence.

Satu kejadian dapat menghasilkan keduanya.

---

### 56. Event Delivery Semantics

Supported semantics:

```text
AT_MOST_ONCE
AT_LEAST_ONCE
EFFECTIVELY_ONCE
```

Exactly-once end-to-end tidak boleh diklaim tanpa bukti kuat.

---

### 57. Idempotency

Integration consumer wajib idempotent.

Gunakan:

```text
message_id
idempotency_key
consumer_checkpoint
```

---

### 58. Ordering

Ordering tidak boleh diasumsikan global.

Jika diperlukan:

- partition key;
- aggregate sequence;
- tenant sequence;
- explicit version.

---

### 59. Causation and Correlation

```text
correlation_id
causation_id
```

harus dibedakan.

Correlation menghubungkan satu business flow.

Causation menunjukkan event/message penyebab langsung.

---

### 60. Timestamp Semantics

Gunakan:

```text
occurred_at
recorded_at
published_at
received_at
processed_at
```

Jangan gunakan satu timestamp untuk semua makna.

---

### 61. Actor Types

```text
USER
SERVICE_ACCOUNT
SYSTEM
SCHEDULER
INTEGRATION
ANONYMOUS
```

---

### 62. Result Types

```text
SUCCESS
FAILURE
DENIED
PARTIAL
CANCELED
```

---

### 63. Data Classification

Signal dapat memiliki:

```text
PUBLIC
INTERNAL
CONFIDENTIAL
RESTRICTED
SECURITY_RESTRICTED
LEGAL_HOLD
```

---

### 64. PHI/PII Policy

Default:

```text
Do not record raw PHI/PII
```

Gunakan:

- internal reference;
- masked value;
- hash;
- classification metadata;
- minimum necessary payload.

---

### 65. Secrets Policy

Tidak boleh mencatat:

- password;
- API key;
- token;
- session secret;
- private key;
- encryption key;
- full authorization header.

---

### 66. Before/After Values

Audit before/after dapat menggunakan:

- field diff;
- hash;
- masked representation;
- protected encrypted payload.

Tidak semua field harus disimpan raw.

---

### 67. Event Payload Minimization

Integration event hanya memuat data yang dibutuhkan consumer.

Hindari database row dump.

---

### 68. Log Payload Bound

Log context wajib memiliki size limit.

Large payload harus dirujuk melalui safe reference.

---

### 69. Trace Attribute Bound

Trace attribute harus:

- bounded;
- low cardinality;
- sanitized;
- tidak memuat raw body.

---

### 70. Metric Dimension Bound

Metric dimension tidak boleh menggunakan:

- user_id;
- patient_id;
- order_id;
- request_id;
- trace_id;
- random UUID;
- raw URL.

---

### 71. Tenant Isolation

Semua tenant-aware signal wajib memiliki:

```text
tenant_id
```

atau explicit global scope.

---

### 72. Scope Isolation

Jika berlaku:

```text
scope_id
organization_id
clinic_id
facility_id
```

harus konsisten dengan active scope.

---

### 73. Cross-Tenant Signal

Cross-tenant action wajib:

- permission khusus;
- audit;
- explicit source/target tenant;
- restricted classification;
- reviewable reason.

---

### 74. Ownership Model

Setiap signal category wajib memiliki owner.

```text
Audit Owner
Logging Owner
Security Event Owner
Domain Event Owner
Integration Contract Owner
Telemetry Owner
Tracing Owner
Metric Owner
Incident Owner
```

---

### 75. Ownership Matrix

| Signal | Owner |
|---|---|
| Audit | Compliance/Security + Domain Owner |
| Application Log | Module/Service Owner |
| Security Event | Security Team |
| Domain Event | Domain Owner |
| Integration Event | Producer + Consumer Contract Owners |
| Telemetry Event | Platform Operations |
| Trace | Platform Observability |
| Metric | Service Owner |
| Incident | Incident Management Owner |

---

### 76. Registry Model

Framework memerlukan registry:

```text
Audit Event Catalog
Log Event Catalog
Security Event Catalog
Domain Event Catalog
Integration Event Catalog
Metric Catalog
Trace Attribute Standard
Incident Taxonomy
```

---

### 77. Registry Minimum Fields

```text
code
name
description
category
owner
schema_version
classification
retention
integrity
sampling
enabled
effective_from
```

---

### 78. Lifecycle States

```text
DRAFT
REVIEW
ACTIVE
DEPRECATED
DISABLED
ARCHIVED
```

---

### 79. Versioning

Breaking schema change membutuhkan version baru.

Contoh:

```text
PatientProfileChangedV1
PatientProfileChangedV2
```

---

### 80. Backward Compatibility

Integration event sebaiknya:

- menambah field optional;
- tidak mengubah semantic field;
- tidak menghapus field aktif;
- memberi deprecation window;
- mendukung parallel version bila perlu.

---

### 81. Audit Versioning

Audit code stabil.

Schema detail dapat versioned tanpa mengubah action semantic.

---

### 82. Log Event Code

Structured log harus memiliki stable event code.

Contoh:

```text
DB_CONNECTION_FAILED
HOMECARE_VISIT_CREATED
CACHE_REBUILD_FAILED
```

---

### 83. Event Naming Standard

Gunakan:

```text
DomainEvent: PascalCase past tense
IntegrationEvent: PascalCase + version
LogEvent: UPPER_SNAKE_CASE
AuditAction: UPPER_SNAKE_CASE
SecurityEvent: lower_snake_case
Metric: lower_snake_case + unit suffix
TraceOperation: lower.dot.notation
```

---

### 84. Delivery Failure

Jika integration event gagal dikirim:

- outbox tetap menyimpan;
- retry;
- dead-letter;
- alert;
- idempotency;
- audit bila critical.

---

### 85. Log Export Failure

Jika log exporter gagal:

- bounded buffer;
- fallback local;
- drop policy sesuai priority;
- preserve critical security/audit path;
- alert.

---

### 86. Audit Write Failure

Audit write failure pada privileged action harus:

- fail closed atau compensating control;
- tidak silent;
- create critical signal;
- preserve evidence;
- follow policy.

---

### 87. Security Event Write Failure

Critical security event loss harus menghasilkan:

- operational alert;
- fallback;
- incident candidate;
- health degradation.

---

### 88. Domain Event Publish Failure

Jika domain state sudah commit tetapi event belum publish:

```text
Transactional Outbox
```

direkomendasikan.

---

### 89. Dual Write Risk

Jangan melakukan:

```text
commit DB
then publish event
```

tanpa recovery mechanism.

---

### 90. Transactional Outbox

Flow:

```text
Domain transaction
→ Update aggregate
→ Insert outbox message
→ Commit
→ Dispatcher publishes
→ Mark delivered
```

---

### 91. Inbox Pattern

Consumer dapat menggunakan inbox untuk:

- duplicate detection;
- idempotent processing;
- delivery tracking.

---

### 92. Audit Outbox

Audit dengan critical consistency dapat memakai audit outbox dalam transaction yang sama.

---

### 93. Event Replay

Replay hanya boleh dilakukan jika:

- schema compatible;
- consumer idempotent;
- scope jelas;
- authorization;
- audit;
- rate control;
- side-effect policy.

---

### 94. Event Redrive

Dead-letter redrive wajib:

- reason;
- approval bila high risk;
- bounded batch;
- idempotency;
- audit;
- result report.

---

### 95. Retention Integration

Retention mengikuti SSOT-OBS-08.

Setiap registry entry harus menunjuk retention policy.

---

### 96. Observability Integration

- logs mengikuti SSOT-OBS-02;
- metrics mengikuti SSOT-OBS-03 dan SSOT-OBS-09;
- tracing mengikuti SSOT-OBS-04;
- health mengikuti SSOT-OBS-05;
- dashboards mengikuti SSOT-OBS-06;
- alert/incident mengikuti SSOT-OBS-07;
- retention mengikuti SSOT-OBS-08.

---

### 97. Decision Table — Common Scenarios

| Scenario | Audit | Log | Domain Event | Integration Event | Security Event | Trace | Metric |
|---|---:|---:|---:|---:|---:|---:|---:|
| User login success | optional/policy | yes | no | no | yes | yes | yes |
| Role changed | yes | yes | optional | optional | yes | yes | yes |
| Patient updated | yes | yes | yes | optional | optional | yes | yes |
| Cache miss | no | optional | no | no | no | optional | yes |
| DB timeout | no | yes | no | no | optional | yes | yes |
| Export patient data | yes | yes | optional | optional | yes | yes | yes |
| Queue retry | no | yes | no | no | optional | yes | yes |
| Legal hold created | yes | yes | optional | optional | yes | yes | yes |
| Purge completed | yes | yes | optional | optional | optional | yes | yes |
| Dashboard viewed | policy-based | optional | no | no | optional | yes | yes |

---

### 98. Governance Review

Review wajib saat:

- signal category baru;
- event contract baru;
- audit action baru;
- cross-tenant payload;
- PHI/PII field;
- retention change;
- schema breaking change;
- event replay feature;
- sampling change;
- high-cardinality dimension.

---

### 99. Governance Questions

- Apa primary purpose?
- Siapa consumer?
- Apa source of truth?
- Apakah harus immutable?
- Apakah boleh disampling?
- Berapa retention?
- Apakah mengandung PHI/PII?
- Apakah cross-tenant?
- Apa failure mode?
- Apa replay semantics?
- Apa owner?
- Apa schema version?

---

### 100. Permission Model

Initial permissions:

```text
observability.audit.read
observability.audit.restricted.read
observability.audit.export
observability.logging.read
observability.logging.manage
observability.security_event.read
observability.security_event.manage
observability.domain_event.read
observability.domain_event.replay
observability.integration_event.read
observability.integration_event.redrive
observability.telemetry.read
observability.trace.read
observability.metric.read
observability.incident.read
observability.signal_registry.manage
observability.cross_tenant.read
```

---

### 101. Audit of the Framework

Wajib audit:

- registry entry create/update/deprecate;
- schema version change;
- retention change;
- sampling change;
- event replay;
- dead-letter redrive;
- audit export;
- cross-tenant access;
- security event suppression;
- privileged trace/profile access.

---

### 102. Anti-Pattern

Hindari:

- semua disebut event;
- audit hanya berupa log text;
- domain event berisi command;
- integration event berisi database row dump;
- event tanpa version;
- event tanpa idempotency;
- trace dianggap source of truth;
- metric label memakai entity ID;
- log berisi secret;
- audit disampling;
- security event dapat dihapus user biasa;
- replay tanpa audit;
- event bus dianggap database permanen;
- one event for all consumers;
- cross-tenant payload tanpa explicit scope.

---

### 103. UAT Part 1

#### Classification

- [ ] Audit dapat dibedakan dari log.
- [ ] Domain event dapat dibedakan dari integration event.
- [ ] Security event dapat dibedakan dari audit.
- [ ] Trace dapat dibedakan dari audit.
- [ ] Metric dapat dibedakan dari event history.
- [ ] Incident record memiliki purpose sendiri.

#### Decision Matrix

- [ ] Patient update menghasilkan signal yang tepat.
- [ ] Privileged action menghasilkan audit.
- [ ] Cache miss tidak menghasilkan audit.
- [ ] Integration event memiliki contract.
- [ ] Performance metric tidak memakai entity ID.
- [ ] Security event memiliki severity/risk.

#### Governance

- [ ] Setiap signal memiliki owner.
- [ ] Setiap signal memiliki retention.
- [ ] Sampling policy tersedia.
- [ ] Classification tersedia.
- [ ] Schema version tersedia.
- [ ] Lifecycle state tersedia.

#### Privacy & Security

- [ ] Secret tidak tercatat.
- [ ] PHI/PII diminimalkan.
- [ ] Tenant/scope tersedia.
- [ ] Cross-tenant action diaudit.
- [ ] Restricted signal dibatasi.
- [ ] Audit tidak disampling.

#### Event Semantics

- [ ] Correlation dan causation dibedakan.
- [ ] Timestamp semantics jelas.
- [ ] Idempotency tersedia.
- [ ] Ordering tidak diasumsikan global.
- [ ] Delivery semantics eksplisit.
- [ ] Outbox direkomendasikan untuk dual-write risk.

---

### 104. Definition of Done Part 1

Part 1 dianggap selesai bila:

- [ ] signal taxonomy tersedia;
- [ ] audit definition tersedia;
- [ ] logging definition tersedia;
- [ ] security event definition tersedia;
- [ ] domain event definition tersedia;
- [ ] integration event definition tersedia;
- [ ] telemetry event definition tersedia;
- [ ] trace definition tersedia;
- [ ] metric definition tersedia;
- [ ] incident definition tersedia;
- [ ] purpose matrix tersedia;
- [ ] durability/immutability/sampling matrix tersedia;
- [ ] decision matrix tersedia;
- [ ] multi-signal rule tersedia;
- [ ] source-of-truth matrix tersedia;
- [ ] event delivery semantics tersedia;
- [ ] idempotency dan ordering tersedia;
- [ ] privacy/security policy tersedia;
- [ ] ownership dan registry tersedia;
- [ ] lifecycle/versioning tersedia;
- [ ] outbox/inbox guidance tersedia;
- [ ] permission dan audit tersedia;
- [ ] UAT tersedia.

---

### 105. Rencana Part Berikutnya

#### Part 2

Audit schema standard, structured logging schema, security event schema, domain/integration event envelope, trace/metric correlation, event registry, compatibility, idempotency, outbox/inbox, delivery, replay, redrive, dan privacy controls.

#### Part 3

Storage architecture, audit integrity, append-only model, event store/outbox persistence, log/security pipelines, message broker abstraction, retention, legal hold, chain of custody, disaster recovery, dan performance.

#### Part 4

HTTP API, controllers, middleware, database schema, scheduler, event dispatcher, outbox worker, inbox consumer, audit integration, security controls, Apache/XAMPP routing, dan sequence diagram.

#### Part 5

Reference implementation, sample catalogs, migration, deployment, rollback, simulations, operational runbooks, final UAT, Definition of Done, roadmap, dan merge guidance.

---

## Bagian II — Schema Standards, Event Envelopes, Registry, Compatibility, Idempotency, Outbox/Inbox, Delivery, Replay & Privacy

### 1. Executive Summary

Part 2 mendefinisikan schema dan delivery standard untuk seluruh signal yang dibahas pada Part 1.

Bagian ini menetapkan:

- audit record schema;
- structured log schema;
- security event schema;
- domain event envelope;
- integration event envelope;
- telemetry event schema;
- trace correlation;
- metric correlation;
- signal registry;
- schema versioning;
- compatibility policy;
- idempotency;
- ordering;
- transactional outbox;
- inbox pattern;
- retry;
- dead-letter;
- replay;
- redrive;
- privacy controls;
- UAT.

Tujuan utamanya adalah memastikan semua signal:

- memiliki struktur konsisten;
- dapat divalidasi;
- dapat dikorelasikan;
- aman untuk tenant dan scope;
- memiliki owner;
- versioned;
- dapat dikirim ulang secara terkendali;
- tidak membocorkan secret atau PHI/PII;
- dapat digunakan lintas module tanpa coupling berlebihan.

---

### 2. Canonical Signal Context

Semua signal wajib menggunakan context yang konsisten bila relevan.

```text
request_id
correlation_id
causation_id
trace_id
span_id
tenant_id
scope_id
actor_reference
module_code
service_code
environment
deployment_version
occurred_at
recorded_at
classification
```

Tidak semua field wajib pada semua signal, tetapi semantic field tidak boleh berubah.

---

### 3. Identifier Standard

Identifier direkomendasikan:

```text
ULID
UUIDv7
```

Kebutuhan:

- globally unique;
- sortable by time bila memungkinkan;
- tidak mengandung data bisnis;
- aman untuk external reference terbatas.

---

### 4. Timestamp Standard

Gunakan ISO 8601 UTC.

Contoh:

```text
2026-07-04T12:00:00.123456Z
```

Timestamp semantic:

```text
occurred_at
recorded_at
published_at
received_at
processed_at
```

---

### 5. Canonical Classification

```text
PUBLIC
INTERNAL
CONFIDENTIAL
RESTRICTED
SECURITY_RESTRICTED
LEGAL_HOLD
```

---

### 6. Canonical Result

```text
SUCCESS
FAILURE
DENIED
PARTIAL
CANCELED
UNKNOWN
```

---

### 7. Canonical Actor Type

```text
USER
SERVICE_ACCOUNT
SYSTEM
SCHEDULER
INTEGRATION
ANONYMOUS
```

---

### 8. Audit Record Schema

```json
{
  "audit_id": "01J...",
  "schema_version": "1.0",
  "occurred_at": "2026-07-04T12:00:00Z",
  "recorded_at": "2026-07-04T12:00:00.012Z",
  "tenant_id": 10,
  "scope_id": 5,
  "actor": {
    "type": "USER",
    "reference": "user:1001",
    "display_reference": "masked",
    "authentication_context": "mfa"
  },
  "action": {
    "code": "PATIENT_PROFILE_UPDATED",
    "category": "DATA_CHANGE",
    "reason": "Clinical profile correction"
  },
  "resource": {
    "type": "patient",
    "reference": "patient:103"
  },
  "result": "SUCCESS",
  "change": {
    "before_hash": "sha256:...",
    "after_hash": "sha256:...",
    "fields": [
      {
        "field": "address",
        "change_type": "UPDATED",
        "before": "***",
        "after": "***"
      }
    ]
  },
  "source": {
    "ip": "masked",
    "user_agent_class": "desktop_browser"
  },
  "correlation_id": "01J...",
  "trace_id": "01J...",
  "classification": "RESTRICTED"
}
```

---

### 9. Audit Required Fields

```text
audit_id
schema_version
occurred_at
recorded_at
actor.type
actor.reference
action.code
resource.type
resource.reference
result
classification
```

Tenant-aware operation wajib memiliki:

```text
tenant_id
scope_id optional
```

---

### 10. Audit Action Code Standard

Format:

```text
<RESOURCE>_<ACTION>
```

Contoh:

```text
PATIENT_VIEWED
PATIENT_PROFILE_UPDATED
ROLE_ASSIGNED
PERMISSION_REVOKED
LEGAL_HOLD_CREATED
LOG_PURGE_EXECUTED
PERFORMANCE_SLO_UPDATED
```

---

### 11. Audit Change Representation

Supported modes:

```text
NONE
HASH_ONLY
FIELD_DIFF_MASKED
FIELD_DIFF_ENCRYPTED
SNAPSHOT_REFERENCE
```

---

### 12. Audit Hash

Hash harus menggunakan canonicalized representation.

```text
canonical JSON
→ UTF-8
→ stable key order
→ SHA-256
```

---

### 13. Structured Log Schema

```json
{
  "timestamp": "2026-07-04T12:00:00.123Z",
  "level": "ERROR",
  "event_code": "DB_CONNECTION_FAILED",
  "message": "Database connection failed.",
  "environment": "production",
  "service": "patient-service",
  "module_code": "patient",
  "tenant_id": 10,
  "scope_id": 5,
  "request_id": "01J...",
  "correlation_id": "01J...",
  "trace_id": "01J...",
  "span_id": "01J...",
  "classification": "CONFIDENTIAL",
  "context": {
    "operation": "patient.find_by_id",
    "error_class": "timeout",
    "retryable": true
  },
  "schema_version": "1.0"
}
```

---

### 14. Log Required Fields

```text
timestamp
level
event_code
message
environment
service
classification
schema_version
```

---

### 15. Log Context Rules

Context harus:

- structured;
- bounded;
- sanitized;
- low-cardinality untuk field utama;
- tidak memuat raw secret;
- tidak memuat body penuh;
- tidak memuat stack trace berulang tanpa limit.

---

### 16. Exception Schema

```json
{
  "error_class": "DatabaseTimeoutException",
  "error_code": "DB_TIMEOUT",
  "retryable": true,
  "stack_hash": "sha256:...",
  "top_frame": "PatientRepository::findById"
}
```

Full stack trace dapat disimpan pada diagnostic store terbatas.

---

### 17. Security Event Schema

```json
{
  "event_id": "01J...",
  "event_name": "authorization_policy_denied",
  "schema_version": "1.0",
  "occurred_at": "2026-07-04T12:00:00Z",
  "tenant_id": 10,
  "scope_id": 5,
  "actor": {
    "type": "USER",
    "reference": "user:1001"
  },
  "subject": {
    "type": "resource",
    "reference": "patient:103"
  },
  "security": {
    "category": "AUTHORIZATION",
    "severity": "HIGH",
    "risk_score": 0.82,
    "policy_code": "PATIENT_CROSS_TENANT_DENY",
    "outcome": "DENIED"
  },
  "source": {
    "ip": "masked",
    "device_class": "desktop"
  },
  "correlation_id": "01J...",
  "trace_id": "01J...",
  "classification": "SECURITY_RESTRICTED"
}
```

---

### 18. Security Event Required Fields

```text
event_id
event_name
schema_version
occurred_at
security.category
security.severity
security.outcome
classification
```

---

### 19. Security Severity

```text
LOW
MEDIUM
HIGH
CRITICAL
```

---

### 20. Domain Event Envelope

```json
{
  "event_id": "01J...",
  "event_name": "PatientProfileUpdated",
  "event_version": "1.0",
  "aggregate": {
    "type": "Patient",
    "id": "103",
    "version": 12
  },
  "occurred_at": "2026-07-04T12:00:00Z",
  "tenant_id": 10,
  "scope_id": 5,
  "actor_reference": "user:1001",
  "correlation_id": "01J...",
  "causation_id": "01J...",
  "payload": {
    "changed_fields": [
      "address"
    ]
  },
  "classification": "CONFIDENTIAL"
}
```

---

### 21. Domain Event Required Fields

```text
event_id
event_name
event_version
aggregate.type
aggregate.id
occurred_at
correlation_id
payload
classification
```

---

### 22. Aggregate Version

Aggregate version digunakan untuk:

- optimistic concurrency;
- event ordering per aggregate;
- duplicate detection;
- replay validation.

---

### 23. Domain Event Payload Rule

Payload harus merepresentasikan fakta bisnis.

Jangan memasukkan:

- repository detail;
- SQL;
- HTTP request object;
- infrastructure exception;
- raw entity dump.

---

### 24. Integration Event Envelope

```json
{
  "message_id": "01J...",
  "event_name": "PatientProfileChangedV1",
  "schema_version": "1.0",
  "published_at": "2026-07-04T12:00:00Z",
  "producer": {
    "service": "patient-service",
    "module": "patient",
    "deployment_version": "2026.07.04"
  },
  "tenant_id": 10,
  "scope_id": 5,
  "correlation_id": "01J...",
  "causation_id": "01J...",
  "idempotency_key": "patient:103:version:12",
  "partition_key": "tenant:10:patient:103",
  "payload": {
    "patient_reference": "patient:103",
    "changed_fields": [
      "address"
    ],
    "effective_at": "2026-07-04T12:00:00Z"
  },
  "classification": "CONFIDENTIAL"
}
```

---

### 25. Integration Event Required Fields

```text
message_id
event_name
schema_version
published_at
producer.service
correlation_id
idempotency_key
payload
classification
```

---

### 26. Integration Payload Rule

Payload harus:

- consumer-safe;
- minimum necessary;
- backward-compatible;
- tidak memuat internal database structure;
- tidak memuat credential;
- tidak memuat full PHI/PII tanpa contract.

---

### 27. Telemetry Event Schema

```json
{
  "event_id": "01J...",
  "event_name": "performance_regression_detected",
  "schema_version": "1.0",
  "occurred_at": "2026-07-04T12:00:00Z",
  "environment": "production",
  "service": "patient-service",
  "module_code": "patient",
  "tenant_id": null,
  "scope_id": null,
  "correlation_id": "01J...",
  "trace_id": null,
  "severity": "HIGH",
  "attributes": {
    "metric_code": "http_request_duration_seconds",
    "relative_delta": 0.27,
    "decision": "FAIL"
  },
  "classification": "INTERNAL"
}
```

---

### 28. Trace Correlation Standard

Trace span attributes minimum:

```text
service.name
service.version
deployment.environment
operation.name
module.code
tenant.id optional
scope.id optional
correlation.id
```

---

### 29. Metric Correlation Standard

Metric dapat dikorelasikan melalui dimension aman:

```text
service
module_code
route
deployment_version
environment
tenant cohort
```

Trace ID tidak digunakan sebagai metric label.

---

### 30. Exemplar

Metric histogram dapat memiliki exemplar:

```text
trace_id
timestamp
value
```

Exemplar harus sampled dan bukan label utama.

---

### 31. Signal Registry Architecture

Registry terdiri dari:

```text
Audit Action Catalog
Log Event Catalog
Security Event Catalog
Domain Event Catalog
Integration Event Catalog
Telemetry Event Catalog
Metric Catalog
Trace Attribute Catalog
Incident Taxonomy
```

---

### 32. Registry Entry Schema

```json
{
  "code": "PATIENT_PROFILE_UPDATED",
  "category": "AUDIT_RECORD",
  "name": "Patient Profile Updated",
  "description": "Records a patient profile update.",
  "owner": "patient_domain",
  "schema_version": "1.0",
  "classification": "RESTRICTED",
  "retention_policy": "audit_regulated",
  "integrity_policy": "HASH_CHAIN",
  "sampling_policy": "NONE",
  "tenant_scope": "TENANT_AWARE",
  "status": "ACTIVE",
  "effective_from": "2026-07-01"
}
```

---

### 33. Registry Validation

Validation minimum:

- code uniqueness;
- owner exists;
- schema exists;
- classification valid;
- retention valid;
- sampling compatible;
- tenant policy valid;
- version format valid;
- lifecycle state valid.

---

### 34. Registry Lifecycle

```text
DRAFT
REVIEW
ACTIVE
DEPRECATED
DISABLED
ARCHIVED
```

---

### 35. Registry Change Control

Breaking change membutuhkan:

- review;
- new version;
- migration plan;
- consumer impact analysis;
- deprecation window;
- audit.

---

### 36. Schema Registry

Schema registry menyimpan:

```text
schema_id
signal_code
schema_version
schema_format
schema_definition
compatibility_mode
effective_from
status
owner
```

---

### 37. Schema Formats

Supported:

```text
JSON_SCHEMA
PHP_DTO_CONTRACT
AVRO optional
PROTOBUF optional
```

Initial implementation dapat memakai JSON Schema + PHP DTO.

---

### 38. Compatibility Modes

```text
BACKWARD
FORWARD
FULL
NONE
```

---

### 39. Backward Compatibility

Consumer lama dapat membaca event baru.

Contoh aman:

- menambah optional field;
- menambah enum value jika consumer toleran;
- memperluas payload tanpa mengubah semantic lama.

---

### 40. Forward Compatibility

Consumer baru dapat membaca event lama.

---

### 41. Full Compatibility

Backward dan forward.

---

### 42. Breaking Changes

Contoh:

- rename field;
- delete field;
- change field type;
- change semantic;
- move field;
- change enum tanpa fallback;
- change identifier format.

---

### 43. Versioning Policy

Gunakan semantic version atau major version sederhana.

Rekomendasi integration event:

```text
PatientProfileChangedV1
PatientProfileChangedV2
```

---

### 44. Schema Validation Point

Validation dilakukan:

```text
before persistence
before publish
after receive
before processing
```

---

### 45. Invalid Message Handling

Invalid message:

- reject;
- move to quarantine/dead-letter;
- record reason;
- alert jika critical;
- do not partially process;
- preserve evidence.

---

### 46. Idempotency Standard

Consumer wajib menyimpan processed message identity.

Key candidates:

```text
message_id
idempotency_key
aggregate_id + version
```

---

### 47. Idempotency Repository

```php
interface MessageInboxRepositoryInterface
{
    public function hasProcessed(
        string $consumerCode,
        string $messageId
    ): bool;

    public function markProcessed(
        string $consumerCode,
        string $messageId,
        \DateTimeImmutable $processedAt
    ): void;
}
```

---

### 48. Idempotent Consumer Flow

```text
Receive message
→ Validate schema
→ Check inbox
→ If duplicate: acknowledge
→ Begin transaction
→ Apply business action
→ Mark inbox processed
→ Commit
→ Acknowledge broker
```

---

### 49. Ordering Standard

Ordering scope harus eksplisit:

```text
GLOBAL
TENANT
AGGREGATE
PARTITION
NONE
```

---

### 50. Aggregate Ordering

Gunakan:

```text
aggregate_id
aggregate_version
```

Consumer harus mendeteksi gap.

---

### 51. Ordering Gap

Jika menerima version 14 sebelum 13:

- hold temporarily;
- retry;
- request replay;
- mark out-of-order;
- do not silently apply bila order required.

---

### 52. Delivery Semantics

Supported:

```text
AT_MOST_ONCE
AT_LEAST_ONCE
EFFECTIVELY_ONCE
```

---

### 53. At-Most-Once

Karakteristik:

- tidak ada retry;
- possible loss;
- cocok hanya untuk low-value telemetry tertentu.

---

### 54. At-Least-Once

Karakteristik:

- retry;
- duplicate possible;
- consumer wajib idempotent.

---

### 55. Effectively-Once

Dicapai melalui:

- at-least-once delivery;
- idempotent consumer;
- inbox;
- transactional state change.

---

### 56. Transactional Outbox Schema

```text
outbox_id
message_id
event_name
schema_version
aggregate_type
aggregate_id
aggregate_version
tenant_id
scope_id
correlation_id
causation_id
idempotency_key
partition_key
payload_json
classification
status
attempt_count
available_at
published_at
created_at
```

---

### 57. Outbox States

```text
PENDING
PROCESSING
PUBLISHED
FAILED
DEAD_LETTER
CANCELED
```

---

### 58. Outbox Insert Rule

Outbox message harus dibuat dalam transaction yang sama dengan domain state.

---

### 59. Outbox Dispatcher Flow

```text
Acquire batch
→ Mark PROCESSING
→ Validate schema
→ Publish
→ Record broker reference
→ Mark PUBLISHED
```

---

### 60. Outbox Locking

Gunakan:

- row lock;
- lease;
- skip locked bila didukung;
- bounded batch.

---

### 61. Outbox Retry

Retry policy:

```text
exponential backoff
maximum attempts
jitter
dead-letter threshold
```

---

### 62. Outbox Idempotency

Publisher harus aman terhadap retry setelah publish tetapi sebelum status update.

Gunakan stable `message_id`.

---

### 63. Inbox Schema

```text
consumer_code
message_id
event_name
schema_version
processed_at
result
payload_hash
correlation_id
```

Unique key:

```text
consumer_code + message_id
```

---

### 64. Dead-Letter Schema

```text
dead_letter_id
source_type
message_id
event_name
schema_version
failure_code
failure_message
attempt_count
payload_reference
classification
first_failed_at
last_failed_at
status
```

---

### 65. Dead-Letter States

```text
OPEN
INVESTIGATING
READY_FOR_REDRIVE
REDRIVING
RESOLVED
DISCARDED
```

---

### 66. Retry Classification

```text
TRANSIENT
PERMANENT
UNKNOWN
```

---

### 67. Transient Failure

Contoh:

- network timeout;
- broker unavailable;
- temporary database lock;
- rate limit.

---

### 68. Permanent Failure

Contoh:

- schema invalid;
- unsupported version;
- missing required field;
- forbidden tenant;
- business invariant violation.

---

### 69. Retry Policy Fields

```text
maximum_attempts
initial_delay
maximum_delay
backoff_multiplier
jitter
retryable_error_codes
```

---

### 70. Replay

Replay adalah mengirim ulang event historical.

Replay berbeda dari retry.

---

### 71. Replay Preconditions

- authorized;
- bounded scope;
- compatible schema;
- idempotent consumers;
- known side effects;
- dry run available;
- audit enabled;
- rollback/compensation documented.

---

### 72. Replay Scope

```text
event_name
tenant_id
aggregate_id
time range
message range
consumer
```

---

### 73. Replay Modes

```text
DRY_RUN
VALIDATE_ONLY
REPLAY_TO_ORIGINAL
REPLAY_TO_SHADOW
REPLAY_TO_NEW_CONSUMER
```

---

### 74. Shadow Replay

Shadow replay digunakan untuk:

- migration validation;
- new consumer test;
- schema compatibility;
- result comparison.

Tidak boleh memicu production side effect.

---

### 75. Redrive

Redrive adalah memproses ulang dead-letter setelah masalah diperbaiki.

---

### 76. Redrive Preconditions

- root cause diketahui;
- schema valid;
- consumer ready;
- idempotency verified;
- bounded batch;
- approval bila high-risk;
- audit.

---

### 77. Redrive Result

Wajib menghasilkan:

```text
attempted
succeeded
failed
skipped_duplicates
remaining
```

---

### 78. Replay/Redrive Audit

Audit fields:

```text
operation_id
requestor
approver optional
scope
reason
mode
started_at
completed_at
result
```

---

### 79. Event Consumer Contract

```php
interface IntegrationEventConsumerInterface
{
    public function eventName(): string;

    public function supportedVersions(): array;

    public function consume(
        IntegrationEventEnvelope $event,
        ConsumerContext $context
    ): ConsumerResult;
}
```

---

### 80. Event Publisher Contract

```php
interface IntegrationEventPublisherInterface
{
    public function publish(
        IntegrationEventEnvelope $event,
        PublishContext $context
    ): PublishResult;
}
```

---

### 81. Domain Event Dispatcher

```php
interface DomainEventDispatcherInterface
{
    public function dispatch(
        array $domainEvents,
        DomainEventDispatchContext $context
    ): void;
}
```

---

### 82. Audit Writer Contract

```php
interface AuditWriterInterface
{
    public function append(
        AuditRecord $record
    ): void;
}
```

Audit writer tidak menyediakan update/delete umum.

---

### 83. Structured Logger Contract

```php
interface StructuredLoggerInterface
{
    public function log(
        string $level,
        string $eventCode,
        string $message,
        array $context = []
    ): void;
}
```

---

### 84. Security Event Writer Contract

```php
interface SecurityEventWriterInterface
{
    public function write(
        SecurityEvent $event
    ): void;
}
```

---

### 85. Signal Context Factory

```php
interface SignalContextFactoryInterface
{
    public function current(): SignalContext;
}
```

SignalContext menyatukan:

- request;
- tenant;
- scope;
- actor;
- correlation;
- trace;
- deployment.

---

### 86. Correlation Propagation

HTTP headers/internal context:

```text
X-Request-ID
X-Correlation-ID
traceparent
tracestate
```

Jangan percaya header external tanpa validation.

---

### 87. Causation Propagation

Message child harus menggunakan:

```text
causation_id = parent message_id/event_id
correlation_id = inherited business flow id
```

---

### 88. Privacy Control Layers

```text
Schema Design
→ Field Classification
→ Sanitization
→ Masking
→ Encryption
→ Access Control
→ Retention
→ Audit
```

---

### 89. Field Classification

Setiap field dapat diberi classification:

```text
PUBLIC
INTERNAL
PII
PHI
SECRET
SECURITY
LEGAL
```

---

### 90. Field Handling Policy

| Classification | Handling |
|---|---|
| PUBLIC | normal |
| INTERNAL | authenticated access |
| PII | minimize/mask |
| PHI | strict minimize/encrypt |
| SECRET | never record |
| SECURITY | restricted |
| LEGAL | retention/hold aware |

---

### 91. Masking

Contoh:

```text
email: a***@example.com
phone: ******1234
patient reference: patient:103
IP: partial mask
```

---

### 92. Hashing

Hash dapat digunakan untuk correlation terbatas.

Harus mempertimbangkan:

- salt/HMAC;
- re-identification risk;
- rotation;
- legal/privacy policy.

---

### 93. Encryption

Encrypted field hanya bila:

- benar-benar diperlukan;
- key management tersedia;
- retrieval policy jelas;
- access audited.

---

### 94. Payload Size Limits

Rekomendasi awal:

```text
audit record: <= 64 KB
structured log: <= 32 KB
security event: <= 64 KB
domain event: <= 128 KB
integration event: <= 256 KB
telemetry event: <= 32 KB
```

Final configurable.

---

### 95. Oversized Payload

Jika melebihi limit:

- reject;
- move large data to secure object;
- include safe reference;
- record hash;
- classify reference.

---

### 96. Schema Validation Errors

Error codes:

```text
SIGNAL_SCHEMA_NOT_FOUND
SIGNAL_SCHEMA_VERSION_UNSUPPORTED
SIGNAL_SCHEMA_VALIDATION_FAILED
SIGNAL_REQUIRED_FIELD_MISSING
SIGNAL_FIELD_TYPE_INVALID
SIGNAL_PAYLOAD_TOO_LARGE
SIGNAL_CLASSIFICATION_INVALID
SIGNAL_TENANT_SCOPE_INVALID
```

---

### 97. Delivery Error Codes

```text
EVENT_PUBLISH_FAILED
EVENT_CONSUMER_FAILED
EVENT_DUPLICATE
EVENT_OUT_OF_ORDER
EVENT_RETRY_EXHAUSTED
EVENT_DEAD_LETTERED
EVENT_REPLAY_NOT_ALLOWED
EVENT_REDRIVE_NOT_ALLOWED
OUTBOX_LOCK_FAILED
INBOX_WRITE_FAILED
```

---

### 98. Signal Registry Permissions

```text
observability.signal_registry.read
observability.signal_registry.manage
observability.schema_registry.read
observability.schema_registry.manage
observability.event.replay
observability.event.redrive
observability.event.dead_letter.read
observability.audit.schema.manage
observability.security_event.schema.manage
```

---

### 99. Audit Events

```text
OBS_SIGNAL_REGISTRY_CREATED
OBS_SIGNAL_REGISTRY_UPDATED
OBS_SIGNAL_SCHEMA_CREATED
OBS_SIGNAL_SCHEMA_DEPRECATED
OBS_EVENT_REPLAY_REQUESTED
OBS_EVENT_REPLAY_EXECUTED
OBS_EVENT_REDRIVE_REQUESTED
OBS_EVENT_REDRIVE_EXECUTED
OBS_DEAD_LETTER_DISCARDED
OBS_SAMPLING_POLICY_CHANGED
OBS_PRIVACY_POLICY_CHANGED
```

---

### 100. Monitoring Metrics

```text
signal_validation_total
signal_validation_failure_total
outbox_pending_total
outbox_publish_total
outbox_publish_failure_total
outbox_oldest_age_seconds
inbox_duplicate_total
consumer_processing_duration_seconds
consumer_failure_total
dead_letter_total
replay_total
redrive_total
schema_compatibility_failure_total
```

---

### 101. Alert Candidates

```text
outbox_backlog_high
outbox_oldest_age_high
event_publish_failure_high
consumer_failure_high
dead_letter_growth
schema_validation_failure_spike
inbox_write_failure
audit_write_failure
security_event_write_failure
```

---

### 102. Data Quality

Quality states:

```text
VALID
PARTIAL
INVALID
DUPLICATE
OUT_OF_ORDER
UNSUPPORTED_VERSION
QUARANTINED
```

---

### 103. Quarantine

Quarantine digunakan untuk:

- invalid schema;
- unknown version;
- unsafe payload;
- tenant mismatch;
- failed decryption;
- tampering suspicion.

---

### 104. Quarantine Rules

- restricted access;
- no automatic processing;
- bounded retention;
- investigation required;
- audit;
- safe redrive only after validation.

---

### 105. Compatibility Test

Setiap schema change wajib diuji terhadap:

- previous producer;
- previous consumer;
- current producer;
- current consumer;
- replay sample;
- unknown optional field;
- missing optional field.

---

### 106. Contract Test

Producer test:

- output valid;
- required fields;
- classification;
- size limit;
- idempotency key.

Consumer test:

- supported version;
- duplicate;
- out-of-order;
- unknown optional field;
- retryable failure.

---

### 107. Example — Audit Builder

```php
$audit = AuditRecord::create(
    auditId: $ids->ulid(),
    occurredAt: $clock->now(),
    actor: $context->actor(),
    actionCode: 'PATIENT_PROFILE_UPDATED',
    resource: ResourceReference::patient($patientId),
    tenantId: $context->tenantId(),
    scopeId: $context->scopeId(),
    result: 'SUCCESS',
    correlationId: $context->correlationId(),
    traceId: $context->traceId(),
    classification: 'RESTRICTED'
);
```

---

### 108. Example — Domain Event

```php
$event = PatientProfileUpdated::occur(
    eventId: $ids->ulid(),
    patientId: $patient->id(),
    aggregateVersion: $patient->version(),
    changedFields: $changedFields,
    tenantId: $context->tenantId(),
    scopeId: $context->scopeId(),
    correlationId: $context->correlationId(),
    causationId: $context->causationId(),
    occurredAt: $clock->now()
);
```

---

### 109. Example — Integration Mapper

```php
final class PatientProfileUpdatedIntegrationMapper
{
    public function map(
        PatientProfileUpdated $event
    ): IntegrationEventEnvelope {
        return IntegrationEventEnvelope::create(
            messageId: $event->eventId(),
            eventName: 'PatientProfileChangedV1',
            schemaVersion: '1.0',
            publishedAt: new \DateTimeImmutable('now'),
            producerService: 'patient-service',
            tenantId: $event->tenantId(),
            scopeId: $event->scopeId(),
            correlationId: $event->correlationId(),
            causationId: $event->eventId(),
            idempotencyKey: sprintf(
                'patient:%s:version:%d',
                $event->patientId(),
                $event->aggregateVersion()
            ),
            partitionKey: sprintf(
                'tenant:%d:patient:%s',
                $event->tenantId(),
                $event->patientId()
            ),
            payload: [
                'patient_reference' => 'patient:' . $event->patientId(),
                'changed_fields' => $event->changedFields(),
            ],
            classification: 'CONFIDENTIAL'
        );
    }
}
```

---

### 110. Example — Outbox Insert

```php
$this->transaction->run(function () use ($patient, $event): void {
    $this->patients->save($patient);

    $message = $this->integrationMapper->map($event);

    $this->outbox->append(
        OutboxMessage::fromEnvelope($message)
    );
});
```

---

### 111. Example — Inbox Consumer

```php
public function consume(
    IntegrationEventEnvelope $event,
    ConsumerContext $context
): ConsumerResult {
    if ($this->inbox->hasProcessed(
        $context->consumerCode,
        $event->messageId
    )) {
        return ConsumerResult::duplicate();
    }

    return $this->transaction->run(
        function () use ($event, $context): ConsumerResult {
            $this->handler->apply($event);

            $this->inbox->markProcessed(
                $context->consumerCode,
                $event->messageId,
                new \DateTimeImmutable('now')
            );

            return ConsumerResult::success();
        }
    );
}
```

---

### 112. Anti-Pattern

Hindari:

- event tanpa envelope;
- audit tanpa actor/action/resource;
- integration event tanpa idempotency key;
- raw database row sebagai payload;
- schema validation hanya di consumer;
- replay tanpa dry run;
- redrive tanpa root cause;
- duplicate dianggap error fatal;
- global ordering assumption;
- secret disimpan di log/event;
- raw PHI di integration payload;
- outbox publisher tanpa lease;
- inbox tanpa unique constraint;
- breaking change pada version yang sama;
- trace ID sebagai metric label.

---

### 113. UAT Part 2

#### Schema

- [ ] Audit schema tervalidasi.
- [ ] Log schema tervalidasi.
- [ ] Security event schema tervalidasi.
- [ ] Domain event envelope tervalidasi.
- [ ] Integration event envelope tervalidasi.
- [ ] Payload size limit bekerja.

#### Registry & Compatibility

- [ ] Registry code unik.
- [ ] Schema version tersedia.
- [ ] Backward compatibility test bekerja.
- [ ] Breaking change ditolak pada version sama.
- [ ] Deprecation lifecycle bekerja.
- [ ] Owner dan retention tervalidasi.

#### Idempotency & Ordering

- [ ] Duplicate message tidak diproses ulang.
- [ ] Inbox unique constraint bekerja.
- [ ] Aggregate version gap terdeteksi.
- [ ] Ordering scope eksplisit.
- [ ] Idempotency key stabil.
- [ ] Effectively-once flow bekerja.

#### Outbox & Delivery

- [ ] Outbox dibuat dalam transaction domain.
- [ ] Dispatcher publish berhasil.
- [ ] Retry transient bekerja.
- [ ] Permanent failure masuk dead-letter.
- [ ] Outbox backlog dapat dipantau.
- [ ] Publisher retry tidak membuat logical duplicate.

#### Replay & Redrive

- [ ] Dry-run replay bekerja.
- [ ] Shadow replay tidak menimbulkan side effect.
- [ ] Replay membutuhkan permission.
- [ ] Redrive membutuhkan root cause resolution.
- [ ] Bounded batch diterapkan.
- [ ] Semua action diaudit.

#### Privacy & Security

- [ ] Secret ditolak.
- [ ] PHI/PII diminimalkan.
- [ ] Masking bekerja.
- [ ] Tenant/scope mismatch ditolak.
- [ ] Oversized payload ditolak atau dipindah aman.
- [ ] Quarantine restricted.

#### Correlation

- [ ] Correlation ID diwariskan.
- [ ] Causation ID benar.
- [ ] Trace context terhubung.
- [ ] Metric exemplar tidak menjadi label.
- [ ] Deployment version tersedia.
- [ ] Request header external divalidasi.

---

### 114. Definition of Done Part 2

Part 2 dianggap selesai bila:

- [ ] canonical signal context tersedia;
- [ ] audit schema tersedia;
- [ ] structured log schema tersedia;
- [ ] security event schema tersedia;
- [ ] domain event envelope tersedia;
- [ ] integration event envelope tersedia;
- [ ] telemetry event schema tersedia;
- [ ] trace/metric correlation tersedia;
- [ ] signal registry tersedia;
- [ ] schema registry tersedia;
- [ ] compatibility policy tersedia;
- [ ] idempotency tersedia;
- [ ] ordering policy tersedia;
- [ ] delivery semantics tersedia;
- [ ] outbox pattern tersedia;
- [ ] inbox pattern tersedia;
- [ ] retry/dead-letter tersedia;
- [ ] replay tersedia;
- [ ] redrive tersedia;
- [ ] privacy controls tersedia;
- [ ] payload limits tersedia;
- [ ] permissions dan audit tersedia;
- [ ] monitoring metrics tersedia;
- [ ] UAT tersedia.

---

### 115. Rencana Part Berikutnya

#### Part 3

Storage architecture, audit integrity, append-only model, event store/outbox persistence, log/security pipelines, message broker abstraction, retention, legal hold, chain of custody, disaster recovery, dan performance.

#### Part 4

HTTP API, controllers, middleware, database schema, scheduler, event dispatcher, outbox worker, inbox consumer, audit integration, security controls, Apache/XAMPP routing, dan sequence diagram.

#### Part 5

Reference implementation, sample catalogs, migration, deployment, rollback, simulations, operational runbooks, final UAT, Definition of Done, roadmap, dan merge guidance.

---

## Bagian III — Storage Architecture, Audit Integrity, Append-Only, Event Persistence, Broker Abstraction, Retention, Legal Hold, Chain of Custody, DR & Performance

### 1. Executive Summary

Part 3 mendefinisikan storage dan integrity architecture untuk seluruh signal yang dibahas pada Part 1–2.

Bagian ini menetapkan:

- storage separation;
- append-only audit model;
- audit integrity;
- hash chain;
- signed manifest;
- event store;
- transactional outbox;
- inbox persistence;
- dead-letter storage;
- log pipeline;
- security event pipeline;
- message broker abstraction;
- delivery durability;
- retention;
- legal hold;
- chain of custody;
- backup;
- restore;
- disaster recovery;
- performance;
- capacity;
- UAT.

Tujuan utamanya adalah memastikan setiap signal disimpan pada media dan lifecycle yang sesuai dengan:

- purpose;
- durability;
- integrity;
- privacy;
- retention;
- replay;
- recovery;
- operational cost;
- tenant isolation;
- compliance.

---

### 2. Storage Separation Principle

Jangan menyimpan seluruh signal pada satu table atau satu storage tanpa pemisahan.

Recommended separation:

```text
Audit Store
Application Log Store
Security Event Store
Domain Event Store optional
Integration Outbox Store
Consumer Inbox Store
Dead-Letter Store
Trace Store
Metric Store
Incident Store
Archive Store
```

---

### 3. Why Separation Matters

Pemisahan dibutuhkan karena perbedaan:

- retention;
- access;
- schema;
- performance;
- integrity;
- query pattern;
- sampling;
- durability;
- backup;
- legal hold;
- cost.

---

### 4. High-Level Storage Architecture

```text
Application
    │
    ├── Audit Writer ───────────────► Audit Store
    │                                   │
    │                                   └── Archive/WORM
    │
    ├── Structured Logger ──────────► Log Buffer
    │                                   │
    │                                   └── Log Store
    │
    ├── Security Event Writer ──────► Security Pipeline
    │                                   │
    │                                   └── Security Store/SIEM
    │
    ├── Domain Event Dispatcher ────► Domain Event Store optional
    │
    ├── Transactional Outbox ───────► Outbox Table
    │                                   │
    │                                   └── Broker
    │                                        │
    │                                        └── Consumer Inbox
    │
    ├── Trace Exporter ─────────────► Trace Store
    │
    └── Metric Exporter ────────────► Metric Store
```

---

### 5. Storage Classes

```text
HOT
WARM
COLD
ARCHIVE
QUARANTINE
```

---

### 6. HOT

Karakteristik:

- online;
- low latency;
- recent;
- frequently queried;
- higher cost.

---

### 7. WARM

Karakteristik:

- online atau nearline;
- compressed;
- moderate latency;
- lower query frequency.

---

### 8. COLD

Karakteristik:

- infrequent access;
- higher retrieval latency;
- low cost;
- strong retention.

---

### 9. ARCHIVE

Karakteristik:

- long-term;
- immutable;
- encrypted;
- manifest/checksum;
- controlled retrieval.

---

### 10. QUARANTINE

Digunakan untuk:

- invalid message;
- tampering suspicion;
- failed decryption;
- schema mismatch;
- unsafe payload;
- integrity failure.

---

### 11. Signal-to-Store Matrix

| Signal | Primary Store | Secondary Store |
|---|---|---|
| Audit Record | Audit Store | Archive/WORM |
| Application Log | Log Store | Archive optional |
| Security Event | Security Store/SIEM | Archive |
| Domain Event | Event Store optional | Archive |
| Integration Event | Outbox/Broker | Archive optional |
| Telemetry Event | Log/Event Store | Metric/Alert |
| Trace Span | Trace Store | sampled archive optional |
| Metric Sample | Metric Store | rollup archive |
| Incident Record | Incident Store | Archive |

---

### 12. Audit Store Requirements

Audit Store wajib:

- append-only;
- immutable to application users;
- tenant-aware;
- scope-aware;
- indexed;
- hash/integrity protected;
- long retention;
- legal hold aware;
- export controlled;
- backup verified.

---

### 13. Audit Append-Only Model

Application role hanya boleh:

```text
INSERT
SELECT limited
```

Tidak boleh:

```text
UPDATE
DELETE
```

Routine update/delete harus ditolak pada database permission layer.

---

### 14. Audit Correction

Jika audit salah, jangan edit record lama.

Buat correction record:

```text
AUDIT_RECORD_CORRECTED
```

yang merujuk:

```text
original_audit_id
correction_reason
corrected_fields
```

---

### 15. Audit Sequence

Audit store dapat menggunakan:

```text
sequence_no
previous_hash
record_hash
```

per partition atau per tenant.

---

### 16. Hash Chain Model

```text
record_hash =
SHA256(
    canonical_record
    + previous_hash
    + sequence_no
)
```

---

### 17. Hash Chain Scope

Scope dapat berupa:

```text
GLOBAL
TENANT
DAY
PARTITION
STREAM
```

Recommended awal:

```text
tenant + month
```

untuk balance integrity dan scalability.

---

### 18. Genesis Record

Setiap chain memiliki genesis marker.

Field:

```text
chain_id
sequence_no = 0
previous_hash = null
record_hash
created_at
```

---

### 19. Hash Chain Verification

Verification harus memastikan:

- sequence tidak gap;
- previous hash cocok;
- record hash cocok;
- canonicalization stabil;
- no duplicate sequence;
- no unauthorized replacement.

---

### 20. Signed Manifest

Untuk archive batch:

```text
manifest_id
batch_id
object_count
record_count
first_sequence
last_sequence
root_hash
created_at
signing_key_reference
signature
```

---

### 21. Merkle Root Optional

Untuk volume besar, manifest dapat menggunakan Merkle root.

Manfaat:

- partial verification;
- scalable integrity proof;
- efficient archive validation.

---

### 22. Audit Partitioning

Recommended partition key:

```text
occurred_at monthly
```

Additional logical segregation:

```text
tenant_id
classification
action_category
```

---

### 23. Audit Indexes

Indexes minimum:

```text
tenant_id + occurred_at
scope_id + occurred_at
actor_reference + occurred_at
action_code + occurred_at
resource_type + resource_reference
correlation_id
trace_id optional
```

---

### 24. Audit Query Guard

Semua query wajib memiliki:

- tenant/scope;
- time range;
- row limit;
- classification permission;
- purpose;
- audit of privileged search.

---

### 25. Audit Encryption

At rest encryption wajib.

Optional field-level encryption untuk:

- sensitive change detail;
- legal evidence;
- restricted source metadata.

---

### 26. Audit Backup

Backup wajib mencakup:

- audit records;
- hash chain metadata;
- manifests;
- signing key references;
- legal holds;
- retention policies.

---

### 27. Application Log Pipeline

```text
Application
→ In-Process Buffer
→ Local/Fallback File
→ Log Shipper
→ Central Log Store
→ Index/Rollup
→ Archive/Purge
```

---

### 28. Log Buffer

Buffer harus:

- bounded;
- non-blocking;
- priority-aware;
- flushable;
- observable;
- resilient.

---

### 29. Log Priority

```text
P0_SECURITY_AUDIT
P1_CRITICAL_ERROR
P2_OPERATIONAL
P3_INFO
P4_DEBUG_TRACE
```

Audit sebaiknya tidak bergantung pada log buffer biasa.

---

### 30. Log Backpressure

Saat downstream lambat:

- preserve critical;
- drop debug terlebih dahulu;
- spool local;
- emit drop counter;
- alert bila sustained;
- protect application latency.

---

### 31. Local Log Storage

Local fallback:

```text
storage/logs/
```

Wajib:

- outside public path;
- rotation;
- permission restrictive;
- size limit;
- no indefinite retention;
- encrypted disk recommended.

---

### 32. Log Rotation

Rotate by:

- size;
- time;
- process restart optional.

Contoh:

```text
100 MB/file
daily rotation
retain 7 days locally
```

---

### 33. Structured Log Indexing

Index hanya field penting:

```text
timestamp
level
event_code
service
module
tenant_id
scope_id
correlation_id
trace_id
classification
```

Jangan index seluruh free-text context.

---

### 34. Security Event Pipeline

```text
Security Event Writer
→ Local Durable Queue
→ Security Normalizer
→ Security Store/SIEM
→ Detection Rules
→ Alert/Incident
→ Archive
```

---

### 35. Security Event Durability

Critical security event harus:

- durable;
- no random sampling;
- fallback local;
- integrity protected;
- restricted;
- monitored.

---

### 36. Security Event Enrichment

Enrichment dapat menambah:

- asset classification;
- actor risk;
- tenant risk;
- geo coarse;
- device class;
- policy context;
- threat intelligence.

Jangan mengubah original event.

---

### 37. Security Event Original vs Enriched

Simpan:

```text
original_event
enriched_event
enrichment_version
```

---

### 38. Domain Event Store

Event Store optional.

Gunakan bila:

- event sourcing;
- replay kebutuhan kuat;
- immutable business history dibutuhkan;
- domain reconstruction dibutuhkan.

Jangan gunakan event store hanya karena ada domain event.

---

### 39. Event Store Requirements

Jika digunakan:

- append-only;
- aggregate sequence;
- optimistic concurrency;
- schema version;
- snapshot optional;
- replay control;
- legal hold aware;
- tenant isolation.

---

### 40. Event Store Record

```text
event_id
stream_id
aggregate_type
aggregate_id
aggregate_version
event_name
event_version
tenant_id
scope_id
occurred_at
payload_json
metadata_json
record_hash
```

---

### 41. Aggregate Stream

Recommended stream ID:

```text
tenant:{tenant_id}:aggregate:{type}:{id}
```

---

### 42. Optimistic Concurrency

Append harus menyertakan expected version.

Jika current version berbeda:

```text
EVENT_STORE_CONCURRENCY_CONFLICT
```

---

### 43. Snapshot

Snapshot optional untuk mempercepat rebuild.

Snapshot tidak menggantikan event history.

Field:

```text
aggregate_id
version
state_json
state_hash
created_at
```

---

### 44. Snapshot Policy

Snapshot berdasarkan:

- every N events;
- aggregate size;
- rebuild duration;
- explicit policy.

---

### 45. Transactional Outbox Persistence

Outbox adalah authoritative delivery queue sebelum broker.

Requirements:

- same DB transaction;
- append-only history;
- status transitions controlled;
- retry;
- lease;
- dead-letter;
- metrics.

---

### 46. Outbox Table Access

Application transaction boleh:

```text
INSERT
```

Dispatcher boleh:

```text
SELECT
UPDATE status
```

No arbitrary delete.

---

### 47. Outbox Status Transition

```text
PENDING
→ PROCESSING
→ PUBLISHED
```

Failure:

```text
PROCESSING
→ PENDING retry
→ DEAD_LETTER
```

---

### 48. Outbox Lease

Fields:

```text
locked_by
locked_until
heartbeat_at
```

Lease mencegah duplicate workers mengambil batch sama.

---

### 49. Outbox Cleanup

PUBLISHED messages dapat dipurge setelah:

- broker confirmation;
- replay window;
- retention policy;
- no legal hold;
- manifest/evidence if required.

---

### 50. Inbox Persistence

Inbox digunakan untuk:

- duplicate detection;
- processing evidence;
- consumer idempotency;
- replay safety.

---

### 51. Inbox Retention

Inbox retention minimal harus mencakup duplicate window terbesar.

Jika replay 90 hari, inbox jangan hanya 7 hari.

---

### 52. Consumer Processing Record

```text
consumer_code
message_id
received_at
processed_at
result
attempt_count
payload_hash
handler_version
```

---

### 53. Dead-Letter Storage

Dead-letter wajib menyimpan:

- message reference;
- reason;
- attempts;
- timestamps;
- classification;
- tenant/scope;
- payload reference or encrypted payload;
- redrive history.

---

### 54. Dead-Letter Access

Restricted.

Payload dapat mengandung data sensitif.

---

### 55. Broker Abstraction

Application tidak boleh bergantung langsung pada vendor API.

Gunakan contract:

```php
interface MessageBrokerInterface
{
    public function publish(
        BrokerMessage $message,
        PublishOptions $options
    ): BrokerPublishResult;

    public function subscribe(
        SubscriptionDefinition $subscription,
        callable $handler
    ): void;
}
```

---

### 56. Broker Capabilities

Abstraction minimal mendukung:

- publish;
- subscribe;
- ack;
- nack;
- retry;
- dead-letter;
- partition key;
- headers;
- delivery reference;
- timeout.

---

### 57. Broker Implementations

Possible adapters:

```text
Database Queue
Redis Streams
RabbitMQ
Kafka
Cloud Queue
```

Initial implementation dapat memakai database queue.

---

### 58. Database Queue Trade-Off

Kelebihan:

- sederhana;
- transactional;
- mudah pada modular monolith.

Kekurangan:

- throughput terbatas;
- database load;
- polling latency;
- scaling terbatas.

---

### 59. Broker Delivery Confirmation

Publish result harus memiliki:

```text
accepted
broker_message_id
partition optional
offset optional
published_at
```

---

### 60. Broker Failure

Jika broker gagal:

- outbox tetap PENDING;
- retry;
- no domain rollback after commit;
- alert jika backlog tinggi;
- no message loss.

---

### 61. Consumer Acknowledgement

Acknowledge hanya setelah:

- schema valid;
- business action commit;
- inbox mark processed commit.

---

### 62. Negative Acknowledgement

Nack sesuai error type:

```text
TRANSIENT → retry
PERMANENT → dead-letter
DUPLICATE → ack
```

---

### 63. Delivery Ordering

Ordering hanya dijamin sesuai broker capability dan partition key.

Application wajib tetap mendeteksi aggregate version.

---

### 64. Message Compression

Compression dapat digunakan untuk payload besar.

Wajib:

- negotiated format;
- size threshold;
- checksum;
- decompression limit;
- zip-bomb protection.

---

### 65. Message Encryption

Message payload encryption diperlukan bila:

- broker untrusted/shared;
- sensitive cross-boundary payload;
- policy requires.

Gunakan envelope encryption.

---

### 66. Key Reference

Simpan:

```text
encryption_key_reference
algorithm
key_version
```

Jangan simpan raw key.

---

### 67. Retention Architecture

Setiap signal registry entry wajib menunjuk:

```text
retention_policy_code
```

---

### 68. Retention Classes

Recommended:

```text
R0_EPHEMERAL
R1_SHORT
R2_STANDARD
R3_EXTENDED
R4_REGULATED
R5_LEGAL_HOLD
```

---

### 69. Example Retention Mapping

| Signal | Class |
|---|---|
| Debug log | R0/R1 |
| Application error log | R2 |
| Security event | R3 |
| Audit record | R4 |
| Incident record | R4 |
| Legal hold evidence | R5 |
| Trace normal | R1 |
| Slow/error trace | R2 |
| Outbox pending | until delivered |
| Dead-letter | R2/R3 |

---

### 70. Retention Start Point

Possible:

```text
occurred_at
recorded_at
published_at
processed_at
incident_closed_at
legal_hold_released_at
```

Harus eksplisit.

---

### 71. Legal Hold

Legal hold dapat berlaku pada:

- audit records;
- security events;
- logs;
- domain events;
- integration messages;
- dead-letter;
- incident records;
- archive objects.

---

### 72. Legal Hold Match Criteria

```text
tenant_id
scope_id
signal_category
signal_code
resource_type
resource_reference
actor_reference
time range
incident_id
case_id
```

---

### 73. Legal Hold Effect

Legal hold wajib:

- block purge;
- preserve archive;
- preserve chain metadata;
- preserve evidence;
- override normal retention;
- be auditable.

---

### 74. Legal Hold Does Not Mean Broad Access

Data tetap mengikuti access classification.

---

### 75. Retention Override

Override harus:

- reason;
- scope;
- duration;
- approver;
- effective period;
- audit.

---

### 76. Purge Rules

Purge hanya setelah:

- retention expired;
- no legal hold;
- no active investigation;
- archive requirement satisfied;
- integrity verified;
- approval if required;
- deletion evidence created.

---

### 77. Deletion Evidence

Field:

```text
purge_batch_id
signal_category
scope
policy_code
records_deleted
objects_deleted
verification_method
evidence_hash
executed_at
executed_by
```

---

### 78. Chain of Custody

Chain of custody mencatat transfer dan access terhadap evidence.

Events:

```text
CREATED
COLLECTED
TRANSFERRED
ARCHIVED
RETRIEVED
EXPORTED
VERIFIED
PURGED
```

---

### 79. Chain of Custody Record

```text
custody_event_id
evidence_reference
action
actor_reference
source_location
destination_location
occurred_at
reason
checksum_before
checksum_after
```

---

### 80. Evidence Package

Evidence package dapat mencakup:

- audit records;
- manifest;
- checksum;
- signature;
- chain of custody;
- export metadata;
- access log.

---

### 81. Archive Format

Recommended:

```text
NDJSON
+ compression
+ encryption
+ manifest
+ checksum
```

---

### 82. Archive Object Naming

```text
signal-category/
tenant/
year/
month/
day/
batch-id/
object-sequence.ndjson.gz.enc
```

Jangan masukkan PHI/PII ke object key.

---

### 83. Archive Manifest Fields

```text
manifest_id
signal_category
tenant_id
time_range
record_count
object_count
schema_versions
checksums
root_hash
encryption_key_reference
created_at
signature
```

---

### 84. Archive Retrieval

Retrieval wajib:

- request;
- reason;
- permission;
- approval if restricted;
- bounded scope;
- workspace;
- expiry;
- audit.

---

### 85. Retrieval Workspace

Workspace harus:

- encrypted;
- isolated;
- temporary;
- access controlled;
- auto-expire;
- no public path.

---

### 86. Backup Architecture

Backup layers:

```text
Database backup
Archive object replication
Manifest backup
Key metadata backup
Configuration backup
Registry/schema backup
```

---

### 87. Backup Scope

Wajib mencakup:

- audit store;
- event store;
- outbox/inbox metadata;
- dead-letter;
- signal registry;
- schema registry;
- legal holds;
- retention policies;
- chain of custody;
- archive manifests.

---

### 88. Backup Encryption

Backup wajib encrypted.

Key lifecycle terpisah dari backup media.

---

### 89. Restore Priority

Recommended order:

```text
1. Registry and schemas
2. Retention/legal hold
3. Audit store and chain metadata
4. Outbox/inbox
5. Event store
6. Security events
7. Logs
8. Derived indexes
```

---

### 90. Restore Validation

Validate:

- row counts;
- checksums;
- chain continuity;
- schema version;
- tenant isolation;
- legal holds;
- outbox state;
- inbox uniqueness;
- archive references.

---

### 91. Disaster Recovery

DR harus mendefinisikan:

```text
RPO
RTO
failover sequence
restore sequence
validation
fallback
communication
```

---

### 92. Recommended RPO/RTO

Initial guideline:

| Store | RPO | RTO |
|---|---:|---:|
| Audit Store | ≤ 5 min | ≤ 4 h |
| Security Event Store | ≤ 5 min | ≤ 2 h |
| Outbox | near-zero/same transaction | ≤ 1 h |
| Inbox | ≤ 5 min | ≤ 2 h |
| Domain Event Store | ≤ 5 min | ≤ 4 h |
| Application Log | ≤ 15 min | ≤ 8 h |
| Incident Store | ≤ 5 min | ≤ 2 h |

Final sesuai business impact.

---

### 93. Outbox DR

Setelah restore:

- preserve PENDING;
- preserve PROCESSING with expired lease;
- requeue safely;
- keep message IDs;
- avoid duplicate logical effect via inbox.

---

### 94. Broker DR

Jika broker state hilang:

- rebuild from outbox replay window;
- validate consumer inbox;
- redrive in bounded batches;
- audit recovery.

---

### 95. Event Store DR

Event store restore harus menjaga:

- stream order;
- aggregate version;
- event hash;
- tenant partition;
- snapshot compatibility.

---

### 96. Security Store DR

Critical security event recovery harus:

- preserve original timestamp;
- preserve integrity;
- re-run detection carefully;
- avoid duplicate incident storms.

---

### 97. Performance Requirements

Storage architecture harus mendukung:

- high append rate;
- bounded query latency;
- batch archive;
- efficient purge;
- tenant filtering;
- replay throughput;
- integrity verification.

---

### 98. Append Performance

Recommended initial targets:

```text
Audit append p95 < 100 ms
Outbox append p95 < 50 ms within domain transaction
Inbox duplicate check p95 < 25 ms
Log enqueue p95 < 5 ms
Security event enqueue p95 < 25 ms
```

---

### 99. Query Performance

Recommended:

```text
Audit search bounded p95 < 1 s
Dead-letter list p95 < 750 ms
Outbox backlog query p95 < 500 ms
Inbox duplicate check p95 < 25 ms
Registry lookup p95 < 25 ms
```

---

### 100. Throughput Planning

Plan separately:

```text
audit writes/sec
log events/sec
security events/sec
domain events/sec
outbox messages/sec
consumer messages/sec
trace spans/sec
metric samples/sec
```

---

### 101. Capacity Planning Inputs

```text
events per transaction
transactions per second
average payload size
retention duration
compression ratio
index overhead
replication factor
archive growth
```

---

### 102. Storage Estimation

Formula sederhana:

```text
daily_storage =
events_per_day
× average_record_size
× index_factor
× replication_factor
```

---

### 103. Index Factor

Initial estimate:

```text
1.2–2.0
```

tergantung jumlah index dan storage engine.

---

### 104. Partitioning Strategy

Recommended:

- audit: monthly;
- logs: daily/monthly depending volume;
- security: monthly;
- event store: hash/tenant + time;
- outbox: status + created_at;
- inbox: consumer + processed_at;
- dead-letter: status + failed_at.

---

### 105. Partition Maintenance

Scheduler harus:

- create future partitions;
- detect missing partition;
- archive old partition;
- purge eligible partition;
- monitor pmax growth.

---

### 106. Hot Partition Risk

Hindari single auto-increment hotspot pada volume ekstrem.

Possible mitigation:

- ULID;
- tenant partition;
- sharded sequence;
- batch insert.

---

### 107. Compression

Compression recommended untuk:

- archived logs;
- audit archive;
- security archive;
- event archive;
- trace archive.

---

### 108. Online Compression

Jangan gunakan compression berat pada hot write path bila mengganggu latency.

---

### 109. Integrity Verification Schedule

Recommended:

```text
daily recent batch verification
weekly random archive verification
monthly full manifest review
quarterly restore test
```

---

### 110. Integrity Failure

Jika integrity gagal:

- mark evidence SUSPECT;
- block purge;
- alert critical;
- preserve source;
- quarantine object;
- create incident;
- verify replica.

---

### 111. Replication

Replication dapat mencakup:

- database replica;
- archive object replica;
- cross-region copy;
- immutable backup.

---

### 112. Multi-Region Consideration

Jika multi-region:

- tenant data residency;
- key residency;
- replication lag;
- ordering;
- failover;
- legal jurisdiction.

---

### 113. Data Residency

Signal tidak boleh direplikasi lintas jurisdiction tanpa policy.

---

### 114. Storage Access Model

Roles:

```text
Application Writer
Audit Reader
Security Analyst
Outbox Dispatcher
Consumer Worker
Archive Operator
Legal/Compliance Reviewer
Database Administrator
```

---

### 115. Least Privilege

Contoh:

- application tidak boleh delete audit;
- dispatcher tidak boleh read arbitrary domain tables;
- consumer tidak boleh modify outbox;
- log reader tidak otomatis dapat audit;
- tenant admin tidak dapat cross-tenant archive.

---

### 116. Database Credentials

Gunakan credential terpisah:

```text
app_rw
audit_append
audit_read
outbox_dispatcher
inbox_consumer
archive_operator
report_reader
```

---

### 117. Audit Store Isolation

Recommended:

- separate schema;
- separate DB optional;
- separate credentials;
- dedicated backup;
- restricted admin access.

---

### 118. Security Store Isolation

Security event store dapat terpisah dari operational log store.

---

### 119. Event Broker Security

Wajib:

- authenticated producer;
- authenticated consumer;
- topic/queue ACL;
- encrypted transport;
- secret rotation;
- audit admin action.

---

### 120. Topic/Queue Naming

Format:

```text
<environment>.<domain>.<event-family>.v<major>
```

Contoh:

```text
production.patient.profile-changed.v1
```

---

### 121. Consumer Group Naming

```text
<service>.<purpose>.v<major>
```

---

### 122. Message Header Standard

```text
message_id
event_name
schema_version
correlation_id
causation_id
tenant_id
classification
content_type
compression
encryption_key_reference optional
```

---

### 123. Broker Retention

Broker retention bukan archival retention.

Broker hanya menyimpan sesuai delivery/replay window.

---

### 124. Replay Source

Replay source dapat berasal dari:

- broker retention;
- outbox history;
- event store;
- archive.

Harus jelas authoritative source.

---

### 125. Deletion Semantics

Delete dapat berupa:

```text
ROW_DELETE
PARTITION_DROP
OBJECT_DELETE
CRYPTO_ERASURE
TOMBSTONE
```

---

### 126. Crypto Erasure

Crypto erasure hanya valid jika:

- key unique;
- key destruction verifiable;
- no plaintext copies;
- backup handling clear;
- evidence created.

---

### 127. Tombstone

Tombstone digunakan untuk:

- logical deletion;
- downstream propagation;
- event-sourced deletion semantics.

Tombstone tidak otomatis memenuhi physical deletion requirement.

---

### 128. Legal Hold and Broker

Jika legal hold berlaku, broker retention saja tidak cukup.

Relevant message harus dipreserve ke durable archive/store.

---

### 129. Chain of Custody for Export

Setiap export restricted harus mencatat:

- requestor;
- approver;
- scope;
- checksum;
- generated_at;
- downloaded_at;
- expired_at;
- destination classification.

---

### 130. Observability of Storage Layer

Metrics:

```text
audit_append_total
audit_append_failure_total
audit_chain_verification_failure_total
log_buffer_depth
log_dropped_total
security_event_enqueue_failure_total
outbox_pending_total
outbox_oldest_age_seconds
outbox_publish_failure_total
inbox_duplicate_total
dead_letter_total
archive_integrity_failure_total
storage_capacity_ratio
restore_test_failure_total
```

---

### 131. Alert Candidates

```text
audit_write_failed
audit_chain_broken
security_event_pipeline_failed
outbox_backlog_high
outbox_oldest_age_high
dead_letter_growth
archive_integrity_failed
storage_capacity_critical
partition_missing
restore_test_failed
legal_hold_purge_attempted
```

---

### 132. Operational Health

Health endpoints internal:

```text
audit-store
log-pipeline
security-pipeline
outbox-dispatcher
broker
inbox-store
archive-store
schema-registry
```

---

### 133. Degraded Mode

Jika broker down:

```text
domain transaction continues
outbox accumulates
integration delivery delayed
health = DEGRADED
```

Jika audit store down untuk privileged action:

```text
fail closed or approved compensating mode
```

---

### 134. Compensating Mode

Compensating mode wajib:

- explicit;
- time-bounded;
- audited;
- critical alert;
- fallback evidence;
- post-recovery reconciliation.

---

### 135. Reconciliation

Reconciliation memeriksa:

- domain state vs outbox;
- outbox vs broker publish;
- broker vs inbox;
- audit expected vs recorded;
- archive catalog vs objects;
- chain sequence.

---

### 136. Reconciliation Job

Recommended cadence:

```text
hourly operational
daily full
```

---

### 137. Recovery Evidence

Setiap recovery besar harus menghasilkan:

- recovery batch ID;
- source;
- target;
- records/messages restored;
- duplicates skipped;
- failures;
- checksum;
- operator;
- timestamps.

---

### 138. Migration Strategy

Migration existing logs/events harus:

- inventory sources;
- classify signal;
- map schemas;
- sanitize;
- assign owner;
- assign retention;
- preserve timestamps;
- preserve evidence;
- validate counts.

---

### 139. Legacy Audit Migration

Jangan mengubah legacy log menjadi authoritative audit tanpa qualification.

Tandai:

```text
evidence_quality = LEGACY_INFERRED
```

---

### 140. Legacy Event Migration

Jika schema lama tidak lengkap:

- preserve raw;
- map best-effort;
- mark version;
- no silent semantic invention.

---

### 141. Storage Cost Governance

Track:

```text
cost per signal category
cost per tenant
hot/warm/archive ratio
index overhead
replication overhead
retrieval frequency
```

---

### 142. Cost Optimization

Possible:

- shorter raw retention;
- longer rollup retention;
- compression;
- fewer indexes;
- archive tier;
- sampling for trace/log;
- not for audit/integration delivery.

---

### 143. Anti-Pattern

Hindari:

- audit dan logs pada table sama;
- application user dapat update audit;
- event store tanpa concurrency control;
- outbox tanpa retry/lease;
- inbox tanpa unique key;
- dead-letter tanpa owner;
- broker retention dianggap archive;
- legal hold hanya berupa flag tanpa purge enforcement;
- archive tanpa checksum;
- backup tanpa restore test;
- encryption key disimpan bersama data;
- one credential for all stores;
- partition tanpa maintenance;
- integrity failure tidak memblokir purge;
- cross-region replication tanpa residency review.

---

### 144. UAT Part 3

#### Audit Store

- [ ] Audit append berhasil.
- [ ] Update/delete ditolak.
- [ ] Correction record bekerja.
- [ ] Hash chain terbentuk.
- [ ] Chain verification bekerja.
- [ ] Tenant/scope query terisolasi.
- [ ] Restricted audit export diaudit.

#### Log & Security Pipelines

- [ ] Log buffer bounded.
- [ ] Debug drop policy bekerja.
- [ ] Critical log preserved.
- [ ] Security event durable.
- [ ] Local fallback bekerja.
- [ ] Pipeline failure menghasilkan alert.

#### Event Store & Outbox

- [ ] Event append immutable.
- [ ] Aggregate concurrency conflict terdeteksi.
- [ ] Outbox dibuat dalam transaction sama.
- [ ] Lease mencegah double worker.
- [ ] Retry transient bekerja.
- [ ] Published cleanup mengikuti retention.

#### Inbox & Dead-Letter

- [ ] Duplicate detection bekerja.
- [ ] Inbox unique key aktif.
- [ ] Permanent failure masuk dead-letter.
- [ ] Dead-letter access restricted.
- [ ] Redrive history tersimpan.
- [ ] Inbox retention mencakup replay window.

#### Broker Abstraction

- [ ] Publisher abstraction bekerja.
- [ ] Consumer abstraction bekerja.
- [ ] Ack setelah commit.
- [ ] Nack sesuai error type.
- [ ] Partition key diterapkan.
- [ ] Broker outage tidak menghilangkan message.

#### Retention & Legal Hold

- [ ] Retention policy terhubung.
- [ ] Start point eksplisit.
- [ ] Legal hold memblokir purge.
- [ ] Retention override diaudit.
- [ ] Deletion evidence dibuat.
- [ ] Chain of custody tersedia.

#### Archive & Integrity

- [ ] Archive object terenkripsi.
- [ ] Manifest dibuat.
- [ ] Checksum diverifikasi.
- [ ] Integrity failure memblokir purge.
- [ ] Retrieval workspace auto-expire.
- [ ] Object key tidak mengandung PHI/PII.

#### Backup & DR

- [ ] Backup terenkripsi.
- [ ] Restore registry/schema berhasil.
- [ ] Restore audit chain berhasil.
- [ ] Outbox restore tidak kehilangan pending message.
- [ ] Inbox restore menjaga idempotency.
- [ ] RPO/RTO diuji.
- [ ] Broker recovery via outbox berhasil.
- [ ] Quarterly restore test tersedia.

#### Performance

- [ ] Audit append memenuhi target.
- [ ] Outbox append memenuhi target.
- [ ] Inbox lookup memenuhi target.
- [ ] Log enqueue tidak memblokir aplikasi.
- [ ] Partition maintenance bekerja.
- [ ] Capacity alert bekerja.

---

### 145. Definition of Done Part 3

Part 3 dianggap selesai bila:

- [ ] storage separation tersedia;
- [ ] storage classes tersedia;
- [ ] audit append-only model tersedia;
- [ ] hash chain tersedia;
- [ ] signed manifest tersedia;
- [ ] audit partition/index standard tersedia;
- [ ] log pipeline tersedia;
- [ ] security event pipeline tersedia;
- [ ] event store guidance tersedia;
- [ ] outbox persistence tersedia;
- [ ] inbox persistence tersedia;
- [ ] dead-letter storage tersedia;
- [ ] broker abstraction tersedia;
- [ ] delivery confirmation tersedia;
- [ ] encryption/compression guidance tersedia;
- [ ] retention mapping tersedia;
- [ ] legal hold tersedia;
- [ ] purge/deletion evidence tersedia;
- [ ] chain of custody tersedia;
- [ ] archive/retrieval tersedia;
- [ ] backup/restore tersedia;
- [ ] DR dan RPO/RTO tersedia;
- [ ] performance/capacity tersedia;
- [ ] least privilege tersedia;
- [ ] monitoring/alert tersedia;
- [ ] reconciliation tersedia;
- [ ] UAT tersedia.

---

### 146. Rencana Part Berikutnya

#### Part 4

HTTP API, controllers, middleware, database schema, scheduler, event dispatcher, outbox worker, inbox consumer, audit integration, security controls, Apache/XAMPP routing, dan sequence diagram.

#### Part 5

Reference implementation, sample catalogs, migration, deployment, rollback, simulations, operational runbooks, final UAT, Definition of Done, roadmap, dan merge guidance.

---

## Bagian IV — HTTP API, Controllers, Middleware, Database Schema, Scheduler, Dispatcher, Outbox/Inbox Workers, Audit Integration & Routing

### 1. Executive Summary

Part 4 mendefinisikan interface dan infrastructure untuk Audit, Logging, Domain Event, Integration Event, Security Event, Telemetry Event, Trace, Metric, dan Incident signal.

Bagian ini menetapkan:

- HTTP API;
- controller responsibilities;
- request/response contracts;
- middleware order;
- permission;
- tenant/scope isolation;
- signal registry API;
- schema registry API;
- audit search/export API;
- event replay/redrive API;
- dead-letter API;
- outbox/inbox API;
- scheduler jobs;
- event dispatcher;
- outbox worker;
- inbox consumer;
- database schema;
- audit integration;
- security controls;
- telemetry;
- error codes;
- Apache/XAMPP routing;
- sequence diagram;
- UAT.

Tujuan utama adalah memastikan seluruh signal dapat:

- dikonfigurasi secara konsisten;
- divalidasi sebelum disimpan atau dikirim;
- diproses idempotent;
- diaudit;
- direplay atau diredrive secara terkendali;
- dipisahkan per tenant/scope;
- dipantau secara operasional;
- diamankan dari data leakage dan privilege abuse.

---

### 2. API Architecture

```text
HTTP Request
    │
    ▼
Security Middleware
    │
    ├── Request ID
    ├── Authentication
    ├── Rate Limit
    ├── Tenant Context
    ├── Active Scope
    ├── Permission
    ├── Classification
    ├── CSRF
    └── Audit Context
    │
    ▼
Controller
    │
    ▼
Application Service
    │
    ├── Signal Registry Service
    ├── Schema Registry Service
    ├── Audit Query Service
    ├── Event Replay Service
    ├── Dead-Letter Service
    ├── Outbox Service
    ├── Inbox Service
    └── Evidence Export Service
    │
    ▼
Repositories / Dispatcher / Broker / Archive
```

---

### 3. Base API Paths

```text
/api/internal/v1/signals/registry
/api/internal/v1/signals/schemas
/api/internal/v1/signals/audit
/api/internal/v1/signals/security-events
/api/internal/v1/signals/domain-events
/api/internal/v1/signals/integration-events
/api/internal/v1/signals/outbox
/api/internal/v1/signals/inbox
/api/internal/v1/signals/dead-letters
/api/internal/v1/signals/replays
/api/internal/v1/signals/redrives
/api/internal/v1/signals/evidence
/api/internal/v1/signals/health
```

Semua endpoint internal wajib authentication.

---

### 4. Signal Registry API

```text
GET    /api/internal/v1/signals/registry
GET    /api/internal/v1/signals/registry/{code}
POST   /api/internal/v1/signals/registry
PUT    /api/internal/v1/signals/registry/{code}
POST   /api/internal/v1/signals/registry/{code}/activate
POST   /api/internal/v1/signals/registry/{code}/deprecate
POST   /api/internal/v1/signals/registry/{code}/disable
GET    /api/internal/v1/signals/registry/{code}/versions
```

---

### 5. Schema Registry API

```text
GET    /api/internal/v1/signals/schemas
GET    /api/internal/v1/signals/schemas/{schemaId}
POST   /api/internal/v1/signals/schemas
PUT    /api/internal/v1/signals/schemas/{schemaId}
POST   /api/internal/v1/signals/schemas/{schemaId}/validate
POST   /api/internal/v1/signals/schemas/{schemaId}/activate
POST   /api/internal/v1/signals/schemas/{schemaId}/deprecate
GET    /api/internal/v1/signals/schemas/{schemaId}/compatibility
```

---

### 6. Audit API

```text
GET  /api/internal/v1/signals/audit
GET  /api/internal/v1/signals/audit/{auditId}
POST /api/internal/v1/signals/audit/search
POST /api/internal/v1/signals/audit/export
GET  /api/internal/v1/signals/audit/{auditId}/integrity
GET  /api/internal/v1/signals/audit/{auditId}/chain-of-custody
```

Tidak ada endpoint umum untuk update/delete audit record.

---

### 7. Security Event API

```text
GET  /api/internal/v1/signals/security-events
GET  /api/internal/v1/signals/security-events/{eventId}
POST /api/internal/v1/signals/security-events/search
POST /api/internal/v1/signals/security-events/{eventId}/acknowledge
POST /api/internal/v1/signals/security-events/{eventId}/suppress
POST /api/internal/v1/signals/security-events/export
```

Suppression wajib reason dan expiry.

---

### 8. Domain Event API

```text
GET  /api/internal/v1/signals/domain-events
GET  /api/internal/v1/signals/domain-events/{eventId}
POST /api/internal/v1/signals/domain-events/search
POST /api/internal/v1/signals/domain-events/replay
GET  /api/internal/v1/signals/domain-events/{eventId}/stream
```

Replay hanya jika event store diadopsi dan permission tersedia.

---

### 9. Integration Event API

```text
GET  /api/internal/v1/signals/integration-events
GET  /api/internal/v1/signals/integration-events/{messageId}
POST /api/internal/v1/signals/integration-events/search
GET  /api/internal/v1/signals/integration-events/{messageId}/delivery
GET  /api/internal/v1/signals/integration-events/{messageId}/consumers
```

---

### 10. Outbox API

```text
GET  /api/internal/v1/signals/outbox
GET  /api/internal/v1/signals/outbox/{outboxId}
POST /api/internal/v1/signals/outbox/{outboxId}/retry
POST /api/internal/v1/signals/outbox/{outboxId}/cancel
GET  /api/internal/v1/signals/outbox/backlog
GET  /api/internal/v1/signals/outbox/health
```

---

### 11. Inbox API

```text
GET /api/internal/v1/signals/inbox
GET /api/internal/v1/signals/inbox/{consumerCode}/{messageId}
GET /api/internal/v1/signals/inbox/duplicates
GET /api/internal/v1/signals/inbox/health
```

Inbox bukan endpoint untuk arbitrary delete.

---

### 12. Dead-Letter API

```text
GET  /api/internal/v1/signals/dead-letters
GET  /api/internal/v1/signals/dead-letters/{deadLetterId}
POST /api/internal/v1/signals/dead-letters/{deadLetterId}/investigate
POST /api/internal/v1/signals/dead-letters/{deadLetterId}/ready
POST /api/internal/v1/signals/dead-letters/{deadLetterId}/redrive
POST /api/internal/v1/signals/dead-letters/{deadLetterId}/discard
GET  /api/internal/v1/signals/dead-letters/{deadLetterId}/history
```

---

### 13. Replay API

```text
GET  /api/internal/v1/signals/replays
GET  /api/internal/v1/signals/replays/{replayId}
POST /api/internal/v1/signals/replays
POST /api/internal/v1/signals/replays/{replayId}/approve
POST /api/internal/v1/signals/replays/{replayId}/execute
POST /api/internal/v1/signals/replays/{replayId}/cancel
GET  /api/internal/v1/signals/replays/{replayId}/result
```

---

### 14. Redrive API

```text
GET  /api/internal/v1/signals/redrives
GET  /api/internal/v1/signals/redrives/{redriveId}
POST /api/internal/v1/signals/redrives
POST /api/internal/v1/signals/redrives/{redriveId}/approve
POST /api/internal/v1/signals/redrives/{redriveId}/execute
POST /api/internal/v1/signals/redrives/{redriveId}/cancel
GET  /api/internal/v1/signals/redrives/{redriveId}/result
```

---

### 15. Evidence API

```text
GET  /api/internal/v1/signals/evidence/{evidenceId}
POST /api/internal/v1/signals/evidence/export
GET  /api/internal/v1/signals/evidence/{evidenceId}/manifest
GET  /api/internal/v1/signals/evidence/{evidenceId}/integrity
GET  /api/internal/v1/signals/evidence/{evidenceId}/custody
```

---

### 16. Common Query Filters

```text
signal_category
signal_code
schema_version
environment
tenant_id
scope_id
module_code
service_code
actor_reference
resource_type
resource_reference
correlation_id
trace_id
status
classification
time_from
time_to
page
per_page
sort
```

---

### 17. Registry Create Request

```json
{
  "code": "PATIENT_PROFILE_UPDATED",
  "category": "AUDIT_RECORD",
  "name": "Patient Profile Updated",
  "description": "Records a patient profile update.",
  "owner": "patient_domain",
  "schema_version": "1.0",
  "classification": "RESTRICTED",
  "retention_policy": "audit_regulated",
  "integrity_policy": "HASH_CHAIN",
  "sampling_policy": "NONE",
  "tenant_scope": "TENANT_AWARE",
  "effective_from": "2026-07-01"
}
```

---

### 18. Schema Create Request

```json
{
  "signal_code": "PatientProfileChangedV1",
  "schema_version": "1.0",
  "schema_format": "JSON_SCHEMA",
  "compatibility_mode": "BACKWARD",
  "definition": {
    "type": "object",
    "required": [
      "message_id",
      "event_name",
      "schema_version",
      "payload"
    ]
  },
  "effective_from": "2026-07-01"
}
```

---

### 19. Replay Create Request

```json
{
  "source": "EVENT_STORE",
  "mode": "REPLAY_TO_SHADOW",
  "scope": {
    "event_name": "PatientProfileChangedV1",
    "tenant_id": 10,
    "time_from": "2026-07-01T00:00:00Z",
    "time_to": "2026-07-02T00:00:00Z"
  },
  "target_consumer": "analytics-shadow-v2",
  "reason": "Validate new consumer compatibility",
  "maximum_events": 10000,
  "dry_run": true
}
```

---

### 20. Redrive Create Request

```json
{
  "dead_letter_ids": [
    "01J...",
    "01K..."
  ],
  "target_consumer": "billing-sync-v1",
  "reason": "Schema mapping corrected",
  "maximum_batch_size": 100,
  "dry_run": true
}
```

---

### 21. Canonical Success Envelope

```json
{
  "data": {},
  "meta": {
    "request_id": "01J...",
    "generated_at": "2026-07-04T12:00:00Z",
    "classification": "INTERNAL"
  }
}
```

---

### 22. Canonical Error Envelope

```json
{
  "error": {
    "code": "SIGNAL_SCHEMA_VALIDATION_FAILED",
    "message": "The signal payload does not match the active schema.",
    "details": [
      {
        "field": "payload.changed_fields",
        "reason": "expected array"
      }
    ]
  },
  "meta": {
    "request_id": "01J...",
    "timestamp": "2026-07-04T12:00:00Z"
  }
}
```

---

### 23. HTTP Status Mapping

| Kondisi | HTTP |
|---|---:|
| success | 200 |
| created | 201 |
| accepted async | 202 |
| validation | 422 |
| unauthenticated | 401 |
| forbidden | 403 |
| not found | 404 |
| conflict | 409 |
| rate limited | 429 |
| unavailable | 503 |
| unexpected | 500 |

---

### 24. Controller Responsibilities

Controller hanya:

- parse request;
- validate DTO;
- resolve tenant/scope;
- authorize;
- call application service;
- map exception;
- project response;
- create audit context.

Controller tidak boleh:

- menulis SQL langsung;
- publish broker langsung;
- mem-bypass schema validation;
- melakukan replay tanpa approval service;
- mengubah audit record;
- mem-bypass idempotency;
- mem-bypass tenant filter;
- mengakses raw restricted payload tanpa projector.

---

### 25. SignalRegistryController Example

```php
final class SignalRegistryController
{
    public function __construct(
        private readonly SignalRegistryServiceInterface $registry,
        private readonly SignalContextFactoryInterface $contexts,
        private readonly SignalRegistryProjector $projector
    ) {
    }

    public function create(
        HttpRequest $request
    ): HttpResponse {
        $context = $this->contexts->fromRequest($request);

        $entry = $this->registry->create(
            SignalRegistryCreateCommand::fromArray(
                $request->json()
            ),
            $context
        );

        return JsonResponse::created(
            $this->projector->entry($entry)
        );
    }
}
```

---

### 26. SchemaRegistryController Example

```php
final class SchemaRegistryController
{
    public function __construct(
        private readonly SchemaRegistryServiceInterface $schemas,
        private readonly SignalContextFactoryInterface $contexts,
        private readonly SchemaProjector $projector
    ) {
    }

    public function validate(
        HttpRequest $request,
        string $schemaId
    ): HttpResponse {
        $context = $this->contexts->fromRequest($request);

        $result = $this->schemas->validatePayload(
            schemaId: $schemaId,
            payload: $request->json('payload'),
            context: $context
        );

        return JsonResponse::ok(
            $this->projector->validation($result)
        );
    }
}
```

---

### 27. ReplayController Example

```php
final class ReplayController
{
    public function __construct(
        private readonly EventReplayServiceInterface $replays,
        private readonly SignalContextFactoryInterface $contexts,
        private readonly ReplayProjector $projector
    ) {
    }

    public function execute(
        HttpRequest $request,
        string $replayId
    ): HttpResponse {
        $context = $this->contexts->fromRequest($request);

        $job = $this->replays->execute(
            replayId: $replayId,
            context: $context
        );

        return JsonResponse::accepted(
            $this->projector->job($job)
        );
    }
}
```

---

### 28. DeadLetterController Example

```php
final class DeadLetterController
{
    public function __construct(
        private readonly DeadLetterServiceInterface $deadLetters,
        private readonly SignalContextFactoryInterface $contexts,
        private readonly DeadLetterProjector $projector
    ) {
    }

    public function redrive(
        HttpRequest $request,
        string $deadLetterId
    ): HttpResponse {
        $context = $this->contexts->fromRequest($request);

        $result = $this->deadLetters->requestRedrive(
            deadLetterId: $deadLetterId,
            command: DeadLetterRedriveCommand::fromArray(
                $request->json()
            ),
            context: $context
        );

        return JsonResponse::accepted(
            $this->projector->redrive($result)
        );
    }
}
```

---

### 29. Application Service Contracts

#### Signal Registry

```php
interface SignalRegistryServiceInterface
{
    public function create(
        SignalRegistryCreateCommand $command,
        SignalContext $context
    ): SignalRegistryEntry;

    public function update(
        string $code,
        SignalRegistryUpdateCommand $command,
        SignalContext $context
    ): SignalRegistryEntry;

    public function deprecate(
        string $code,
        string $reason,
        SignalContext $context
    ): SignalRegistryEntry;
}
```

---

### 30. Schema Registry

```php
interface SchemaRegistryServiceInterface
{
    public function register(
        SchemaRegisterCommand $command,
        SignalContext $context
    ): SignalSchema;

    public function validatePayload(
        string $schemaId,
        array $payload,
        SignalContext $context
    ): SchemaValidationResult;

    public function compatibility(
        string $schemaId,
        array $candidateSchema,
        SignalContext $context
    ): CompatibilityResult;
}
```

---

### 31. Audit Query Service

```php
interface AuditQueryServiceInterface
{
    public function search(
        AuditSearchCriteria $criteria,
        SignalContext $context
    ): AuditSearchResult;

    public function export(
        AuditExportCommand $command,
        SignalContext $context
    ): EvidenceExportJob;

    public function integrity(
        string $auditId,
        SignalContext $context
    ): AuditIntegrityResult;
}
```

---

### 32. Event Replay Service

```php
interface EventReplayServiceInterface
{
    public function create(
        ReplayCreateCommand $command,
        SignalContext $context
    ): EventReplayRequest;

    public function approve(
        string $replayId,
        SignalContext $context
    ): EventReplayRequest;

    public function execute(
        string $replayId,
        SignalContext $context
    ): ReplayJob;
}
```

---

### 33. Dead-Letter Service

```php
interface DeadLetterServiceInterface
{
    public function investigate(
        string $deadLetterId,
        string $reason,
        SignalContext $context
    ): DeadLetterRecord;

    public function requestRedrive(
        string $deadLetterId,
        DeadLetterRedriveCommand $command,
        SignalContext $context
    ): RedriveRequest;

    public function discard(
        string $deadLetterId,
        string $reason,
        SignalContext $context
    ): DeadLetterRecord;
}
```

---

### 34. Middleware Order

```text
Request ID
→ Trusted Proxy
→ Security Headers
→ Authentication
→ Rate Limit
→ Tenant Context
→ Active Scope
→ Permission
→ Classification
→ CSRF
→ Audit Context
→ Controller
```

---

### 35. Authentication

Semua endpoint internal membutuhkan authenticated principal.

Service account wajib memiliki:

- identity;
- scoped credential;
- rotation;
- explicit permission;
- audit.

---

### 36. Tenant Context

Tenant-aware request wajib memiliki tenant context valid.

Cross-tenant request membutuhkan permission khusus.

---

### 37. Active Scope

Jika berlaku:

```text
organization_id
clinic_id
facility_id
scope_id
```

harus divalidasi sebelum search, export, replay, atau redrive.

---

### 38. Permission Middleware

Permissions utama:

```text
observability.signal_registry.read
observability.signal_registry.manage
observability.schema_registry.read
observability.schema_registry.manage
observability.audit.read
observability.audit.restricted.read
observability.audit.export
observability.security_event.read
observability.security_event.manage
observability.domain_event.read
observability.domain_event.replay
observability.integration_event.read
observability.integration_event.redrive
observability.event.dead_letter.read
observability.event.dead_letter.manage
observability.event.replay
observability.event.redrive
observability.evidence.read
observability.evidence.export
observability.cross_tenant.read
```

---

### 39. Classification Middleware

Classification middleware membatasi:

```text
INTERNAL
CONFIDENTIAL
RESTRICTED
SECURITY_RESTRICTED
LEGAL_HOLD
```

Projector harus menyembunyikan field yang tidak sesuai clearance.

---

### 40. CSRF

Mutation berbasis session wajib CSRF:

- registry create/update;
- schema create/update;
- replay create/approve/execute;
- redrive create/approve/execute;
- dead-letter discard;
- security suppression;
- export request.

---

### 41. Rate Limiting

Rekomendasi awal:

| Endpoint | Limit |
|---|---:|
| registry read | 120/min/user |
| registry mutation | 30/hour/user |
| schema validation | 120/min/user |
| audit search | 60/min/user |
| audit export | 10/hour/user |
| replay create | 10/hour/user |
| replay execute | 5/hour/user |
| redrive create | 20/hour/user |
| redrive execute | 10/hour/user |
| dead-letter list | 60/min/user |
| evidence export | 10/hour/user |

---

### 42. Query Guard

Semua query wajib memiliki:

```text
time range
row limit
tenant/scope
classification permission
timeout
purpose
```

---

### 43. Replay Guard

Replay wajib memiliki:

- bounded event count;
- bounded time range;
- target consumer;
- mode;
- reason;
- dry-run;
- approval if production;
- audit;
- idempotency validation.

---

### 44. Redrive Guard

Redrive wajib memiliki:

- resolved root cause;
- bounded batch;
- target consumer;
- idempotency validation;
- approval if restricted;
- audit.

---

### 45. Scheduler Architecture

```text
Scheduler
    │
    ├── Outbox Dispatch
    ├── Outbox Lease Recovery
    ├── Inbox Cleanup
    ├── Dead-Letter Monitoring
    ├── Replay Execution
    ├── Redrive Execution
    ├── Audit Chain Verification
    ├── Signal Reconciliation
    ├── Schema Compatibility Check
    ├── Archive/Purge Coordination
    ├── Registry Cache Refresh
    └── Health/Capacity Check
```

---

### 46. Required Scheduler Jobs

```text
signal-outbox-dispatch
signal-outbox-lease-recover
signal-inbox-retention
signal-dead-letter-monitor
signal-replay-execute
signal-redrive-execute
signal-audit-chain-verify
signal-reconcile
signal-schema-compatibility-check
signal-registry-cache-refresh
signal-evidence-workspace-expire
signal-capacity-check
```

---

### 47. Scheduler Frequency

| Job | Frequency |
|---|---:|
| Outbox dispatch | every minute |
| Lease recovery | every 5 minutes |
| Inbox retention | daily |
| Dead-letter monitor | every 5 minutes |
| Replay execution | every minute |
| Redrive execution | every minute |
| Audit chain verify | hourly/daily |
| Reconciliation | hourly |
| Compatibility check | on schema change + daily |
| Registry cache refresh | every 5 minutes |
| Workspace expiry | hourly |
| Capacity check | every 15 minutes |

---

### 48. Job Locking

Lock keys:

```text
signal-outbox:{partition}
signal-replay:{replay_id}
signal-redrive:{redrive_id}
signal-audit-chain:{chain_id}
signal-reconcile:{scope}:{window}
signal-schema-check:{schema_id}
```

---

### 49. Job Idempotency

Idempotency keys:

```text
message_id
replay_id + event_id
redrive_id + dead_letter_id
chain_id + verification_window
schema_id + candidate_hash
```

---

### 50. Outbox Worker Architecture

```text
Poll eligible outbox rows
→ Acquire lease
→ Validate schema
→ Build broker message
→ Publish
→ Record broker reference
→ Mark PUBLISHED
→ Emit metric/log/audit if needed
```

---

### 51. Outbox Worker Contract

```php
interface OutboxDispatcherInterface
{
    public function dispatchBatch(
        OutboxDispatchCriteria $criteria
    ): OutboxDispatchResult;
}
```

---

### 52. Outbox Worker Reference

```php
final class OutboxDispatcher
    implements OutboxDispatcherInterface
{
    public function dispatchBatch(
        OutboxDispatchCriteria $criteria
    ): OutboxDispatchResult {
        $messages = $this->outbox->acquireBatch(
            criteria: $criteria,
            workerId: $this->workerId,
            leaseUntil: $this->clock->now()->modify('+2 minutes')
        );

        $result = new OutboxDispatchResult();

        foreach ($messages as $message) {
            try {
                $schema = $this->schemas->activeFor(
                    $message->eventName,
                    $message->schemaVersion
                );

                $this->validator->assertValid(
                    schema: $schema,
                    payload: $message->payload
                );

                $published = $this->broker->publish(
                    $message->toBrokerMessage(),
                    PublishOptions::standard()
                );

                $this->outbox->markPublished(
                    outboxId: $message->id,
                    brokerReference: $published->reference,
                    publishedAt: $this->clock->now()
                );

                $result->addPublished($message->id);
            } catch (TransientPublishException $exception) {
                $this->outbox->releaseForRetry(
                    outboxId: $message->id,
                    availableAt: $this->retry->nextAttempt(
                        $message->attemptCount
                    ),
                    errorCode: $exception->errorCode()
                );

                $result->addRetried($message->id);
            } catch (\Throwable $exception) {
                $this->outbox->moveToDeadLetter(
                    outboxId: $message->id,
                    errorCode: 'EVENT_PUBLISH_FAILED',
                    errorMessage: $exception->getMessage()
                );

                $result->addFailed($message->id);
            }
        }

        return $result;
    }
}
```

---

### 53. Inbox Consumer Architecture

```text
Receive broker message
→ Validate envelope
→ Validate schema
→ Check tenant/scope
→ Check inbox duplicate
→ Begin transaction
→ Execute handler
→ Mark inbox processed
→ Commit
→ Ack broker
```

---

### 54. Inbox Consumer Contract

```php
interface InboxConsumerInterface
{
    public function consume(
        BrokerMessage $message,
        ConsumerContext $context
    ): ConsumerResult;
}
```

---

### 55. Inbox Consumer Reference

```php
final class InboxConsumer
    implements InboxConsumerInterface
{
    public function consume(
        BrokerMessage $message,
        ConsumerContext $context
    ): ConsumerResult {
        $envelope = $this->envelopes->decode($message);

        $this->validator->assertValidEnvelope($envelope);
        $this->tenantGuard->assertAllowed($envelope, $context);

        if ($this->inbox->hasProcessed(
            $context->consumerCode,
            $envelope->messageId
        )) {
            return ConsumerResult::duplicate();
        }

        return $this->transaction->run(
            function () use ($envelope, $context): ConsumerResult {
                $handler = $this->handlers->resolve(
                    eventName: $envelope->eventName,
                    schemaVersion: $envelope->schemaVersion
                );

                $handler->consume($envelope, $context);

                $this->inbox->markProcessed(
                    consumerCode: $context->consumerCode,
                    messageId: $envelope->messageId,
                    eventName: $envelope->eventName,
                    schemaVersion: $envelope->schemaVersion,
                    processedAt: $this->clock->now(),
                    payloadHash: $envelope->payloadHash()
                );

                return ConsumerResult::success();
            }
        );
    }
}
```

---

### 56. Domain Event Dispatcher

```php
interface DomainEventDispatcherInterface
{
    public function dispatch(
        array $events,
        DomainEventDispatchContext $context
    ): DomainEventDispatchResult;
}
```

---

### 57. Dispatcher Flow

```text
Aggregate records domain events
→ Unit of Work collects
→ Domain transaction commits
→ In-process handlers execute
→ Integration mapper creates outbox message
→ Events cleared from aggregate
```

Jika integration consistency dibutuhkan, outbox insert harus dalam transaction yang sama.

---

### 58. Event Handler Registry

```php
interface EventHandlerRegistryInterface
{
    public function register(
        string $eventName,
        string $schemaVersion,
        IntegrationEventConsumerInterface $handler
    ): void;

    public function resolve(
        string $eventName,
        string $schemaVersion
    ): IntegrationEventConsumerInterface;
}
```

---

### 59. Replay Worker

Replay worker:

- membaca request approved;
- membaca source event;
- memvalidasi scope;
- memvalidasi schema;
- menerapkan mode;
- mengirim ke target;
- menyimpan result per event;
- menghormati rate limit;
- dapat dihentikan.

---

### 60. Replay Worker Contract

```php
interface ReplayExecutorInterface
{
    public function execute(
        string $replayId
    ): ReplayExecutionResult;
}
```

---

### 61. Redrive Worker

Redrive worker:

- mengambil dead-letter ready;
- memvalidasi root cause resolution;
- memvalidasi current schema;
- memastikan idempotency;
- mengirim ulang;
- menyimpan result;
- tidak menghapus original evidence.

---

### 62. Database Schema Overview

Tables:

```text
signal_registry
signal_schema_registry
audit_records
audit_chain_state
audit_chain_verifications
security_events
domain_events
integration_outbox
integration_inbox
integration_dead_letters
integration_delivery_attempts
event_replay_requests
event_replay_results
event_redrive_requests
event_redrive_results
signal_chain_of_custody
signal_evidence_exports
signal_scheduler_runs
signal_reconciliation_runs
```

---

### 63. Table: signal_registry

```sql
CREATE TABLE signal_registry (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    code VARCHAR(180) NOT NULL,
    category VARCHAR(50) NOT NULL,
    name VARCHAR(255) NOT NULL,
    description VARCHAR(2000) NULL,
    owner_reference VARCHAR(150) NOT NULL,
    schema_version VARCHAR(20) NOT NULL,
    classification VARCHAR(40) NOT NULL,
    retention_policy_code VARCHAR(150) NOT NULL,
    integrity_policy_code VARCHAR(100) NOT NULL,
    sampling_policy_code VARCHAR(100) NOT NULL,
    tenant_scope_policy VARCHAR(50) NOT NULL,
    status VARCHAR(30) NOT NULL DEFAULT 'DRAFT',
    effective_from DATETIME(6) NOT NULL,
    created_by BIGINT UNSIGNED NOT NULL,
    updated_by BIGINT UNSIGNED NULL,
    created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    updated_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6)
        ON UPDATE CURRENT_TIMESTAMP(6),

    PRIMARY KEY (id),
    UNIQUE KEY uq_signal_registry_code_version (
        code,
        schema_version
    ),
    KEY idx_signal_registry_active (
        category,
        status,
        effective_from
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

### 64. Table: signal_schema_registry

```sql
CREATE TABLE signal_schema_registry (
    id CHAR(26) NOT NULL,
    signal_code VARCHAR(180) NOT NULL,
    schema_version VARCHAR(20) NOT NULL,
    schema_format VARCHAR(40) NOT NULL,
    schema_definition_json JSON NOT NULL,
    compatibility_mode VARCHAR(30) NOT NULL,
    schema_hash CHAR(64) NOT NULL,
    status VARCHAR(30) NOT NULL DEFAULT 'DRAFT',
    effective_from DATETIME(6) NOT NULL,
    created_by BIGINT UNSIGNED NOT NULL,
    created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    updated_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6)
        ON UPDATE CURRENT_TIMESTAMP(6),

    PRIMARY KEY (id),
    UNIQUE KEY uq_signal_schema_version (
        signal_code,
        schema_version
    ),
    KEY idx_signal_schema_active (
        signal_code,
        status,
        effective_from
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

### 65. Table: audit_records

```sql
CREATE TABLE audit_records (
    id CHAR(26) NOT NULL,
    schema_version VARCHAR(20) NOT NULL,
    occurred_at DATETIME(6) NOT NULL,
    recorded_at DATETIME(6) NOT NULL,
    tenant_id BIGINT UNSIGNED NULL,
    scope_id BIGINT UNSIGNED NULL,
    actor_type VARCHAR(40) NOT NULL,
    actor_reference VARCHAR(180) NOT NULL,
    action_code VARCHAR(180) NOT NULL,
    action_category VARCHAR(80) NOT NULL,
    resource_type VARCHAR(120) NOT NULL,
    resource_reference VARCHAR(180) NOT NULL,
    result VARCHAR(30) NOT NULL,
    reason VARCHAR(2000) NULL,
    change_json JSON NULL,
    source_json JSON NULL,
    correlation_id CHAR(26) NULL,
    trace_id VARCHAR(64) NULL,
    classification VARCHAR(40) NOT NULL,
    chain_id VARCHAR(180) NOT NULL,
    sequence_no BIGINT UNSIGNED NOT NULL,
    previous_hash CHAR(64) NULL,
    record_hash CHAR(64) NOT NULL,
    created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),

    PRIMARY KEY (id, occurred_at),
    UNIQUE KEY uq_audit_chain_sequence (
        chain_id,
        sequence_no
    ),
    KEY idx_audit_tenant_time (
        tenant_id,
        occurred_at
    ),
    KEY idx_audit_scope_time (
        scope_id,
        occurred_at
    ),
    KEY idx_audit_actor_time (
        actor_reference,
        occurred_at
    ),
    KEY idx_audit_action_time (
        action_code,
        occurred_at
    ),
    KEY idx_audit_resource (
        resource_type,
        resource_reference,
        occurred_at
    ),
    KEY idx_audit_correlation (
        correlation_id
    )
)
PARTITION BY RANGE COLUMNS (occurred_at) (
    PARTITION p2026_07 VALUES LESS THAN ('2026-08-01'),
    PARTITION p2026_08 VALUES LESS THAN ('2026-09-01'),
    PARTITION pmax VALUES LESS THAN (MAXVALUE)
);
```

---

### 66. Table: audit_chain_state

```sql
CREATE TABLE audit_chain_state (
    chain_id VARCHAR(180) NOT NULL,
    tenant_id BIGINT UNSIGNED NULL,
    partition_code VARCHAR(80) NOT NULL,
    last_sequence_no BIGINT UNSIGNED NOT NULL,
    last_record_hash CHAR(64) NOT NULL,
    updated_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6)
        ON UPDATE CURRENT_TIMESTAMP(6),

    PRIMARY KEY (chain_id),
    UNIQUE KEY uq_audit_chain_partition (
        tenant_id,
        partition_code
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

### 67. Table: security_events

```sql
CREATE TABLE security_events (
    id CHAR(26) NOT NULL,
    event_name VARCHAR(180) NOT NULL,
    schema_version VARCHAR(20) NOT NULL,
    occurred_at DATETIME(6) NOT NULL,
    tenant_id BIGINT UNSIGNED NULL,
    scope_id BIGINT UNSIGNED NULL,
    actor_json JSON NULL,
    subject_json JSON NULL,
    security_json JSON NOT NULL,
    source_json JSON NULL,
    correlation_id CHAR(26) NULL,
    trace_id VARCHAR(64) NULL,
    classification VARCHAR(40) NOT NULL,
    status VARCHAR(30) NOT NULL DEFAULT 'OPEN',
    suppression_until DATETIME(6) NULL,
    created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),

    PRIMARY KEY (id),
    KEY idx_security_event_time (
        event_name,
        occurred_at
    ),
    KEY idx_security_event_status (
        status,
        occurred_at
    ),
    KEY idx_security_event_tenant (
        tenant_id,
        occurred_at
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

### 68. Table: domain_events

```sql
CREATE TABLE domain_events (
    id CHAR(26) NOT NULL,
    event_name VARCHAR(180) NOT NULL,
    event_version VARCHAR(20) NOT NULL,
    aggregate_type VARCHAR(120) NOT NULL,
    aggregate_id VARCHAR(180) NOT NULL,
    aggregate_version BIGINT UNSIGNED NOT NULL,
    stream_id VARCHAR(255) NOT NULL,
    occurred_at DATETIME(6) NOT NULL,
    tenant_id BIGINT UNSIGNED NULL,
    scope_id BIGINT UNSIGNED NULL,
    actor_reference VARCHAR(180) NULL,
    correlation_id CHAR(26) NOT NULL,
    causation_id CHAR(26) NULL,
    payload_json JSON NOT NULL,
    metadata_json JSON NOT NULL,
    classification VARCHAR(40) NOT NULL,
    record_hash CHAR(64) NULL,
    created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),

    PRIMARY KEY (id),
    UNIQUE KEY uq_domain_stream_version (
        stream_id,
        aggregate_version
    ),
    KEY idx_domain_event_time (
        event_name,
        occurred_at
    ),
    KEY idx_domain_event_aggregate (
        aggregate_type,
        aggregate_id,
        aggregate_version
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

### 69. Table: integration_outbox

```sql
CREATE TABLE integration_outbox (
    id CHAR(26) NOT NULL,
    message_id CHAR(26) NOT NULL,
    event_name VARCHAR(180) NOT NULL,
    schema_version VARCHAR(20) NOT NULL,
    aggregate_type VARCHAR(120) NULL,
    aggregate_id VARCHAR(180) NULL,
    aggregate_version BIGINT UNSIGNED NULL,
    tenant_id BIGINT UNSIGNED NULL,
    scope_id BIGINT UNSIGNED NULL,
    correlation_id CHAR(26) NOT NULL,
    causation_id CHAR(26) NULL,
    idempotency_key VARCHAR(255) NOT NULL,
    partition_key VARCHAR(255) NULL,
    payload_json JSON NOT NULL,
    classification VARCHAR(40) NOT NULL,
    status VARCHAR(30) NOT NULL DEFAULT 'PENDING',
    attempt_count INT UNSIGNED NOT NULL DEFAULT 0,
    available_at DATETIME(6) NOT NULL,
    locked_by VARCHAR(150) NULL,
    locked_until DATETIME(6) NULL,
    heartbeat_at DATETIME(6) NULL,
    broker_reference VARCHAR(255) NULL,
    published_at DATETIME(6) NULL,
    last_error_code VARCHAR(120) NULL,
    last_error_message VARCHAR(2000) NULL,
    created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    updated_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6)
        ON UPDATE CURRENT_TIMESTAMP(6),

    PRIMARY KEY (id),
    UNIQUE KEY uq_outbox_message_id (
        message_id
    ),
    UNIQUE KEY uq_outbox_idempotency (
        idempotency_key
    ),
    KEY idx_outbox_dispatch (
        status,
        available_at,
        locked_until
    ),
    KEY idx_outbox_tenant_time (
        tenant_id,
        created_at
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

### 70. Table: integration_inbox

```sql
CREATE TABLE integration_inbox (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    consumer_code VARCHAR(180) NOT NULL,
    message_id CHAR(26) NOT NULL,
    event_name VARCHAR(180) NOT NULL,
    schema_version VARCHAR(20) NOT NULL,
    tenant_id BIGINT UNSIGNED NULL,
    scope_id BIGINT UNSIGNED NULL,
    received_at DATETIME(6) NOT NULL,
    processed_at DATETIME(6) NOT NULL,
    result VARCHAR(30) NOT NULL,
    attempt_count INT UNSIGNED NOT NULL DEFAULT 1,
    payload_hash CHAR(64) NOT NULL,
    correlation_id CHAR(26) NULL,
    handler_version VARCHAR(100) NULL,
    created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),

    PRIMARY KEY (id),
    UNIQUE KEY uq_inbox_consumer_message (
        consumer_code,
        message_id
    ),
    KEY idx_inbox_consumer_time (
        consumer_code,
        processed_at
    ),
    KEY idx_inbox_tenant_time (
        tenant_id,
        processed_at
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

### 71. Table: integration_dead_letters

```sql
CREATE TABLE integration_dead_letters (
    id CHAR(26) NOT NULL,
    source_type VARCHAR(50) NOT NULL,
    source_reference VARCHAR(180) NULL,
    message_id CHAR(26) NULL,
    event_name VARCHAR(180) NOT NULL,
    schema_version VARCHAR(20) NOT NULL,
    tenant_id BIGINT UNSIGNED NULL,
    scope_id BIGINT UNSIGNED NULL,
    failure_code VARCHAR(150) NOT NULL,
    failure_message VARCHAR(2000) NOT NULL,
    attempt_count INT UNSIGNED NOT NULL,
    payload_reference VARCHAR(1000) NULL,
    payload_hash CHAR(64) NULL,
    classification VARCHAR(40) NOT NULL,
    first_failed_at DATETIME(6) NOT NULL,
    last_failed_at DATETIME(6) NOT NULL,
    status VARCHAR(30) NOT NULL DEFAULT 'OPEN',
    assigned_to VARCHAR(150) NULL,
    root_cause VARCHAR(2000) NULL,
    created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    updated_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6)
        ON UPDATE CURRENT_TIMESTAMP(6),

    PRIMARY KEY (id),
    KEY idx_dead_letter_status (
        status,
        last_failed_at
    ),
    KEY idx_dead_letter_event (
        event_name,
        last_failed_at
    ),
    KEY idx_dead_letter_tenant (
        tenant_id,
        last_failed_at
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

### 72. Table: integration_delivery_attempts

```sql
CREATE TABLE integration_delivery_attempts (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    message_id CHAR(26) NOT NULL,
    attempt_no INT UNSIGNED NOT NULL,
    worker_id VARCHAR(150) NOT NULL,
    started_at DATETIME(6) NOT NULL,
    completed_at DATETIME(6) NULL,
    result VARCHAR(30) NOT NULL,
    error_code VARCHAR(150) NULL,
    broker_reference VARCHAR(255) NULL,
    created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),

    PRIMARY KEY (id),
    UNIQUE KEY uq_delivery_attempt (
        message_id,
        attempt_no
    ),
    KEY idx_delivery_attempt_time (
        started_at
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

### 73. Table: event_replay_requests

```sql
CREATE TABLE event_replay_requests (
    id CHAR(26) NOT NULL,
    source_type VARCHAR(50) NOT NULL,
    replay_mode VARCHAR(50) NOT NULL,
    scope_json JSON NOT NULL,
    target_consumer VARCHAR(180) NOT NULL,
    reason VARCHAR(2000) NOT NULL,
    maximum_events BIGINT UNSIGNED NOT NULL,
    dry_run TINYINT(1) NOT NULL DEFAULT 1,
    status VARCHAR(30) NOT NULL DEFAULT 'DRAFT',
    requested_by BIGINT UNSIGNED NOT NULL,
    approved_by BIGINT UNSIGNED NULL,
    requested_at DATETIME(6) NOT NULL,
    approved_at DATETIME(6) NULL,
    started_at DATETIME(6) NULL,
    completed_at DATETIME(6) NULL,
    created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),

    PRIMARY KEY (id),
    KEY idx_replay_status (
        status,
        requested_at
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

### 74. Table: event_replay_results

```sql
CREATE TABLE event_replay_results (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    replay_id CHAR(26) NOT NULL,
    source_event_id CHAR(26) NOT NULL,
    result VARCHAR(30) NOT NULL,
    target_reference VARCHAR(255) NULL,
    error_code VARCHAR(150) NULL,
    processed_at DATETIME(6) NOT NULL,
    created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),

    PRIMARY KEY (id),
    UNIQUE KEY uq_replay_event (
        replay_id,
        source_event_id
    ),
    KEY idx_replay_result (
        replay_id,
        result
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

### 75. Table: event_redrive_requests

```sql
CREATE TABLE event_redrive_requests (
    id CHAR(26) NOT NULL,
    scope_json JSON NOT NULL,
    target_consumer VARCHAR(180) NOT NULL,
    reason VARCHAR(2000) NOT NULL,
    maximum_batch_size INT UNSIGNED NOT NULL,
    dry_run TINYINT(1) NOT NULL DEFAULT 1,
    status VARCHAR(30) NOT NULL DEFAULT 'DRAFT',
    requested_by BIGINT UNSIGNED NOT NULL,
    approved_by BIGINT UNSIGNED NULL,
    requested_at DATETIME(6) NOT NULL,
    approved_at DATETIME(6) NULL,
    started_at DATETIME(6) NULL,
    completed_at DATETIME(6) NULL,
    created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),

    PRIMARY KEY (id),
    KEY idx_redrive_status (
        status,
        requested_at
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

### 76. Table: signal_chain_of_custody

```sql
CREATE TABLE signal_chain_of_custody (
    id CHAR(26) NOT NULL,
    evidence_reference VARCHAR(255) NOT NULL,
    action_code VARCHAR(80) NOT NULL,
    actor_reference VARCHAR(180) NOT NULL,
    source_location VARCHAR(500) NULL,
    destination_location VARCHAR(500) NULL,
    reason VARCHAR(2000) NULL,
    checksum_before CHAR(64) NULL,
    checksum_after CHAR(64) NULL,
    occurred_at DATETIME(6) NOT NULL,
    created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),

    PRIMARY KEY (id),
    KEY idx_custody_evidence_time (
        evidence_reference,
        occurred_at
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

### 77. Repository Contracts

```php
interface OutboxRepositoryInterface
{
    public function append(
        OutboxMessage $message
    ): void;

    public function acquireBatch(
        OutboxDispatchCriteria $criteria,
        string $workerId,
        \DateTimeImmutable $leaseUntil
    ): array;

    public function markPublished(
        string $outboxId,
        string $brokerReference,
        \DateTimeImmutable $publishedAt
    ): void;
}
```

---

### 78. Audit Repository Contract

```php
interface AuditRecordRepositoryInterface
{
    public function append(
        AuditRecord $record
    ): void;

    public function findById(
        string $auditId
    ): ?AuditRecord;

    public function search(
        AuditSearchCriteria $criteria
    ): AuditSearchResult;
}
```

Tidak ada general update/delete contract.

---

### 79. Schema Repository Contract

```php
interface SignalSchemaRepositoryInterface
{
    public function findActive(
        string $signalCode,
        string $schemaVersion,
        \DateTimeImmutable $at
    ): ?SignalSchema;

    public function save(
        SignalSchema $schema
    ): void;
}
```

---

### 80. Audit Integration

Semua privileged action pada framework wajib menghasilkan audit.

Contoh:

```text
OBS_SIGNAL_REGISTRY_CREATED
OBS_SIGNAL_SCHEMA_CREATED
OBS_EVENT_REPLAY_APPROVED
OBS_EVENT_REPLAY_EXECUTED
OBS_EVENT_REDRIVE_APPROVED
OBS_EVENT_REDRIVE_EXECUTED
OBS_DEAD_LETTER_DISCARDED
OBS_AUDIT_EXPORTED
OBS_SECURITY_EVENT_SUPPRESSED
```

---

### 81. Audit Context

Audit context minimal:

```text
actor
tenant
scope
request_id
correlation_id
trace_id
source_ip masked
reason
```

---

### 82. Structured Logging

```json
{
  "event_code": "OUTBOX_DISPATCH_FAILED",
  "level": "ERROR",
  "message": "Outbox message publication failed.",
  "message_id": "01J...",
  "event_name": "PatientProfileChangedV1",
  "attempt": 4,
  "retryable": true,
  "correlation_id": "01J...",
  "classification": "INTERNAL"
}
```

---

### 83. Metrics

```text
signal_api_request_total
signal_api_error_total
signal_registry_change_total
signal_schema_validation_total
signal_schema_validation_failure_total
outbox_pending_total
outbox_oldest_age_seconds
outbox_publish_total
outbox_publish_failure_total
inbox_duplicate_total
consumer_processing_duration_seconds
consumer_failure_total
dead_letter_total
replay_total
replay_failure_total
redrive_total
redrive_failure_total
audit_chain_verification_failure_total
signal_reconciliation_failure_total
```

---

### 84. Alert Candidates

```text
audit_write_failed
audit_chain_broken
schema_validation_failure_spike
outbox_backlog_high
outbox_oldest_age_high
outbox_publish_failure_high
consumer_failure_high
dead_letter_growth
replay_failure_high
redrive_failure_high
inbox_write_failed
signal_reconciliation_failed
```

---

### 85. Error Codes

```text
SIGNAL_REGISTRY_NOT_FOUND
SIGNAL_REGISTRY_CONFLICT
SIGNAL_SCHEMA_NOT_FOUND
SIGNAL_SCHEMA_VERSION_UNSUPPORTED
SIGNAL_SCHEMA_VALIDATION_FAILED
SIGNAL_SCHEMA_INCOMPATIBLE
SIGNAL_PAYLOAD_TOO_LARGE
SIGNAL_CLASSIFICATION_ACCESS_DENIED
SIGNAL_TENANT_SCOPE_INVALID
AUDIT_RECORD_NOT_FOUND
AUDIT_INTEGRITY_FAILED
OUTBOX_MESSAGE_NOT_FOUND
OUTBOX_LOCK_FAILED
OUTBOX_PUBLISH_FAILED
INBOX_WRITE_FAILED
EVENT_DUPLICATE
EVENT_OUT_OF_ORDER
EVENT_DEAD_LETTERED
DEAD_LETTER_NOT_FOUND
EVENT_REPLAY_NOT_ALLOWED
EVENT_REPLAY_NOT_APPROVED
EVENT_REPLAY_LIMIT_EXCEEDED
EVENT_REDRIVE_NOT_ALLOWED
EVENT_REDRIVE_NOT_APPROVED
EVENT_REDRIVE_LIMIT_EXCEEDED
EVIDENCE_EXPORT_FAILED
CROSS_TENANT_ACCESS_DENIED
```

---

### 86. Security Controls

Framework wajib:

- no audit update/delete endpoint;
- no raw secret in payload;
- schema validation before publish;
- schema validation after receive;
- tenant/scope enforcement;
- classification enforcement;
- CSRF untuk mutation;
- replay/redrive approval;
- bounded replay/redrive;
- idempotency;
- rate limiting;
- export expiry;
- restricted dead-letter payload;
- audit privileged actions;
- protect local storage;
- no public evidence path.

---

### 87. Four-Eyes Approval

Direkomendasikan untuk:

- production replay;
- high-risk redrive;
- dead-letter discard;
- audit export restricted;
- schema breaking change;
- cross-tenant evidence export.

---

### 88. Data Masking

Projector harus dapat menyembunyikan:

- actor identity;
- patient/resource identity;
- source IP;
- raw payload;
- internal broker reference;
- internal object location;
- encryption key reference.

---

### 89. Evidence Export

Export wajib:

- permission;
- purpose;
- scope;
- classification;
- approval if restricted;
- checksum;
- manifest;
- encryption;
- expiry;
- audit;
- chain of custody.

---

### 90. Apache/XAMPP Virtual Host

```apache
<VirtualHost *:80>
    ServerName platform.local
    DocumentRoot "D:/xampp/htdocs/platform/public"

    <Directory "D:/xampp/htdocs/platform/public">
        AllowOverride All
        Require all granted
        Options -Indexes
    </Directory>

    <Directory "D:/xampp/htdocs/platform/storage/evidence">
        Require all denied
        Options -Indexes
    </Directory>

    <Directory "D:/xampp/htdocs/platform/storage/dead-letter">
        Require all denied
        Options -Indexes
    </Directory>

    ErrorLog "logs/platform-error.log"
    CustomLog "logs/platform-access.log" combined
</VirtualHost>
```

---

### 91. `.htaccess`

```apache
RewriteEngine On

RewriteCond %{REQUEST_FILENAME} -f [OR]
RewriteCond %{REQUEST_FILENAME} -d
RewriteRule ^ - [L]

RewriteRule ^ index.php [QSA,L]
```

---

### 92. Route Registration

```php
$router->group('/api/internal/v1/signals', [
    'middleware' => [
        RequestIdMiddleware::class,
        AuthenticationMiddleware::class,
        RateLimitMiddleware::class,
        TenantContextMiddleware::class,
        ActiveScopeMiddleware::class,
        SignalClassificationMiddleware::class,
        AuditContextMiddleware::class,
    ],
], function ($router): void {
    $router->get('/registry', [
        SignalRegistryController::class,
        'index',
    ]);

    $router->post('/registry', [
        SignalRegistryController::class,
        'create',
    ]);

    $router->post('/schemas/{schemaId}/validate', [
        SchemaRegistryController::class,
        'validate',
    ]);

    $router->post('/audit/search', [
        AuditController::class,
        'search',
    ]);

    $router->post('/replays', [
        ReplayController::class,
        'create',
    ]);

    $router->post('/replays/{replayId}/execute', [
        ReplayController::class,
        'execute',
    ]);

    $router->post('/dead-letters/{deadLetterId}/redrive', [
        DeadLetterController::class,
        'redrive',
    ]);
});
```

---

### 93. CLI Commands

```bash
php bin/console signal:outbox:dispatch
php bin/console signal:outbox:recover-leases
php bin/console signal:inbox:cleanup
php bin/console signal:dead-letter:monitor
php bin/console signal:replay:execute --id=REPLAY_ID
php bin/console signal:redrive:execute --id=REDRIVE_ID
php bin/console signal:audit:verify-chain
php bin/console signal:reconcile
php bin/console signal:schema:check-compatibility
php bin/console signal:capacity:check
```

---

### 94. Sequence Diagram — Domain Transaction and Outbox

```mermaid
sequenceDiagram
    participant User
    participant API
    participant Domain
    participant DB
    participant Outbox
    participant Worker
    participant Broker

    User->>API: Update patient profile
    API->>Domain: Execute command
    Domain->>DB: Begin transaction
    Domain->>DB: Update aggregate
    Domain->>Outbox: Insert integration message
    Domain->>DB: Commit
    API-->>User: Success
    Worker->>Outbox: Acquire pending batch
    Outbox-->>Worker: Message
    Worker->>Broker: Publish
    Broker-->>Worker: Accepted
    Worker->>Outbox: Mark PUBLISHED
```

---

### 95. Sequence Diagram — Idempotent Consumer

```mermaid
sequenceDiagram
    participant Broker
    participant Consumer
    participant Schema
    participant Inbox
    participant Handler
    participant DB

    Broker->>Consumer: Deliver message
    Consumer->>Schema: Validate envelope/schema
    Schema-->>Consumer: Valid
    Consumer->>Inbox: Has processed?
    alt Duplicate
        Inbox-->>Consumer: Yes
        Consumer->>Broker: Ack
    else New
        Inbox-->>Consumer: No
        Consumer->>DB: Begin transaction
        Consumer->>Handler: Apply event
        Handler->>DB: Update state
        Consumer->>Inbox: Mark processed
        Consumer->>DB: Commit
        Consumer->>Broker: Ack
    end
```

---

### 96. Sequence Diagram — Replay

```mermaid
sequenceDiagram
    participant Operator
    participant API
    participant Replay as Replay Service
    participant Approval
    participant Source
    participant Worker
    participant Target
    participant Audit

    Operator->>API: Create replay request
    API->>Replay: Validate scope and mode
    Replay->>Approval: Request approval
    Approval-->>Replay: Approved
    Replay->>Worker: Enqueue replay
    Worker->>Source: Read bounded events
    Source-->>Worker: Events
    Worker->>Target: Replay/Shadow publish
    Target-->>Worker: Result
    Worker->>Replay: Save per-event result
    Replay->>Audit: Record replay execution
```

---

### 97. Sequence Diagram — Dead-Letter Redrive

```mermaid
sequenceDiagram
    participant Operator
    participant API
    participant DLQ as Dead-Letter Service
    participant Approval
    participant Worker
    participant Consumer
    participant Audit

    Operator->>API: Request redrive
    API->>DLQ: Validate root cause and scope
    DLQ->>Approval: Request approval
    Approval-->>DLQ: Approved
    DLQ->>Worker: Enqueue redrive
    Worker->>Consumer: Deliver corrected message
    Consumer-->>Worker: Success/Failure
    Worker->>DLQ: Save redrive result
    DLQ->>Audit: Record redrive execution
```

---

### 98. Sequence Diagram — Audit Integrity Verification

```mermaid
sequenceDiagram
    participant Scheduler
    participant Verify as Audit Integrity Service
    participant AuditStore
    participant ChainState
    participant Alert
    participant Incident

    Scheduler->>Verify: Verify chain window
    Verify->>AuditStore: Read ordered records
    AuditStore-->>Verify: Records
    Verify->>ChainState: Read expected state
    ChainState-->>Verify: Last known hash
    Verify->>Verify: Recalculate chain
    alt Integrity failure
        Verify->>Alert: Create critical alert
        Verify->>Incident: Create incident candidate
    else Passed
        Verify->>ChainState: Save verification result
    end
```

---

### 99. Performance Targets

| Operation | Target |
|---|---:|
| Registry lookup | < 100 ms |
| Schema lookup | < 100 ms |
| Schema validation | < 50 ms typical payload |
| Audit append | < 100 ms p95 |
| Outbox append | < 50 ms p95 |
| Inbox duplicate check | < 25 ms p95 |
| Outbox batch acquire | < 500 ms |
| Dead-letter list | < 750 ms |
| Replay enqueue | < 500 ms |
| Redrive enqueue | < 500 ms |
| Audit search bounded | < 1 s |
| Evidence export enqueue | < 500 ms |

---

### 100. Testing Strategy

#### Unit

- registry validation;
- schema validation;
- compatibility;
- hash chain;
- replay state;
- redrive state;
- outbox retry;
- inbox duplicate detection;
- tenant guard;
- projector masking.

#### Integration

- PDO repositories;
- domain transaction + outbox;
- broker adapter;
- consumer transaction + inbox;
- dead-letter transition;
- replay worker;
- redrive worker;
- audit chain verification;
- export manifest;
- routing.

#### Security

- cross-tenant access;
- restricted payload access;
- audit immutability;
- replay approval;
- dead-letter discard;
- CSRF;
- rate limit;
- evidence path isolation;
- classification leakage.

---

### 101. UAT Part 4

#### Registry & Schema API

- [ ] Registry list bekerja.
- [ ] Create/update tervalidasi.
- [ ] Duplicate code/version ditolak.
- [ ] Schema validation bekerja.
- [ ] Compatibility check bekerja.
- [ ] Deprecation lifecycle bekerja.
- [ ] Mutation diaudit.

#### Audit API

- [ ] Audit search bounded.
- [ ] Tenant/scope filter bekerja.
- [ ] Restricted access dibatasi.
- [ ] Integrity endpoint bekerja.
- [ ] Export membutuhkan permission.
- [ ] Tidak ada update/delete endpoint.
- [ ] Search privileged diaudit.

#### Outbox & Inbox

- [ ] Outbox append bekerja.
- [ ] Worker acquire lease bekerja.
- [ ] Publish success menandai PUBLISHED.
- [ ] Transient retry bekerja.
- [ ] Permanent failure masuk dead-letter.
- [ ] Inbox duplicate check bekerja.
- [ ] Ack hanya setelah commit.
- [ ] Duplicate di-ack tanpa side effect.

#### Dead-Letter

- [ ] Dead-letter list bekerja.
- [ ] Restricted payload dimasking.
- [ ] Investigation state bekerja.
- [ ] Ready-for-redrive state bekerja.
- [ ] Discard membutuhkan reason.
- [ ] Semua mutation diaudit.

#### Replay & Redrive

- [ ] Replay create bekerja.
- [ ] Dry-run bekerja.
- [ ] Production replay membutuhkan approval.
- [ ] Event limit diterapkan.
- [ ] Shadow replay tidak menimbulkan side effect.
- [ ] Redrive membutuhkan root cause.
- [ ] Idempotency dijaga.
- [ ] Result per event tersedia.

#### Scheduler

- [ ] Outbox dispatch berjalan.
- [ ] Lease recovery berjalan.
- [ ] Inbox retention berjalan.
- [ ] Dead-letter monitor berjalan.
- [ ] Replay worker berjalan.
- [ ] Redrive worker berjalan.
- [ ] Audit verification berjalan.
- [ ] Reconciliation berjalan.
- [ ] Job lock/idempotency bekerja.
- [ ] Stuck job terdeteksi.

#### Database

- [ ] Migration berhasil.
- [ ] Audit partition aktif.
- [ ] Outbox unique message ID aktif.
- [ ] Inbox unique consumer/message aktif.
- [ ] Foreign key/constraint valid.
- [ ] Index mendukung query utama.
- [ ] Audit update/delete ditolak secara permission.

#### Security

- [ ] Raw secret tidak terekspos.
- [ ] Tenant/scope mismatch ditolak.
- [ ] Cross-tenant permission diterapkan.
- [ ] CSRF aktif.
- [ ] Rate limit aktif.
- [ ] Evidence folder tidak public.
- [ ] Dead-letter folder tidak public.
- [ ] Four-eyes approval bekerja.
- [ ] Projector masking bekerja.

#### Apache/XAMPP

- [ ] Front controller bekerja.
- [ ] Evidence folder blocked.
- [ ] Dead-letter folder blocked.
- [ ] Directory listing nonaktif.
- [ ] Internal routes bekerja.
- [ ] Error log tersedia.

---

### 102. Anti-Pattern

Hindari:

- controller publish broker langsung;
- replay tanpa approval;
- dead-letter discard tanpa audit;
- outbox worker tanpa lease;
- inbox consumer ack sebelum commit;
- schema validation hanya di producer;
- raw payload selalu dikembalikan API;
- audit search tanpa time range;
- dashboard/admin API tanpa tenant filter;
- evidence export ke public folder;
- one credential for all workers;
- retry tanpa idempotency;
- audit repository menyediakan delete;
- pmax partition tanpa monitor;
- compatibility check manual saja.

---

### 103. Definition of Done Part 4

Part 4 dianggap selesai bila:

- [ ] HTTP API catalog tersedia;
- [ ] request/response contracts tersedia;
- [ ] controller standard tersedia;
- [ ] application service contracts tersedia;
- [ ] middleware order tersedia;
- [ ] permission model tersedia;
- [ ] classification enforcement tersedia;
- [ ] replay/redrive guards tersedia;
- [ ] scheduler architecture tersedia;
- [ ] scheduler jobs tersedia;
- [ ] outbox dispatcher tersedia;
- [ ] inbox consumer tersedia;
- [ ] domain event dispatcher tersedia;
- [ ] replay worker tersedia;
- [ ] redrive worker tersedia;
- [ ] database schema tersedia;
- [ ] repository contracts tersedia;
- [ ] audit integration tersedia;
- [ ] metrics dan alerts tersedia;
- [ ] error codes tersedia;
- [ ] security controls tersedia;
- [ ] Apache/XAMPP routing tersedia;
- [ ] sequence diagrams tersedia;
- [ ] UAT tersedia.

---

### 104. Rencana Part Berikutnya

#### Part 5

Reference implementation, sample registries and schemas, migration, deployment, rollback, simulations, operational runbooks, final UAT, Definition of Done, roadmap, dan merge guidance menjadi `SSOT-OBS-10.md`.

---

## Bagian V — Reference Implementation, Sample Registries, Deployment, Simulation, Final UAT & Operational Readiness

### 1. Executive Summary

Part 5 menutup rangkaian SSOT-OBS-10 dengan reference implementation untuk membedakan dan mengoperasikan:

```text
Audit Record
Application Log
Security Event
Domain Event
Integration Event
Telemetry Event
Trace Span
Metric Sample
Incident Record
```

Bagian ini mencakup:

- bootstrap wiring;
- sample signal registry;
- sample schema registry;
- audit writer;
- structured logger;
- security event writer;
- domain event dispatcher;
- transactional outbox;
- inbox consumer;
- dead-letter handling;
- replay/redrive implementation;
- migration;
- deployment;
- rollback;
- simulations;
- operational runbooks;
- final UAT;
- Definition of Done;
- roadmap;
- merge guidance menjadi `SSOT-OBS-10.md`.

Tujuan utamanya adalah memastikan setiap signal:

- memiliki purpose yang tepat;
- disimpan pada storage yang tepat;
- memiliki schema yang jelas;
- memiliki retention dan integrity policy;
- tenant/scope-aware;
- aman dari PHI/PII/secret leakage;
- dapat dipantau;
- dapat diaudit;
- dapat direplay/redrive secara terkendali;
- tidak saling menggantikan secara salah.

---

### 2. Initial Implementation Scope

Initial release wajib mencakup:

```text
Signal Registry
Schema Registry
Audit Writer
Structured Logger
Security Event Writer
Domain Event Dispatcher
Integration Event Mapper
Transactional Outbox
Outbox Dispatcher
Inbox Consumer
Dead-Letter Service
Replay Service
Redrive Service
Audit Integrity Verifier
Signal Reconciliation
```

Initial signal categories:

```text
AUDIT_RECORD
APPLICATION_LOG
SECURITY_EVENT
DOMAIN_EVENT
INTEGRATION_EVENT
TELEMETRY_EVENT
TRACE_SPAN
METRIC_SAMPLE
INCIDENT_RECORD
```

---

### 3. Final Folder Structure

```text
app/
└── Platform/
    └── Observability/
        └── Signals/
            ├── Domain/
            │   ├── AuditRecord.php
            │   ├── StructuredLogEvent.php
            │   ├── SecurityEvent.php
            │   ├── DomainEvent.php
            │   ├── IntegrationEventEnvelope.php
            │   ├── SignalRegistryEntry.php
            │   ├── SignalSchema.php
            │   ├── OutboxMessage.php
            │   ├── InboxRecord.php
            │   ├── DeadLetterRecord.php
            │   ├── ReplayRequest.php
            │   └── RedriveRequest.php
            │
            ├── Application/
            │   ├── SignalRegistryService.php
            │   ├── SchemaRegistryService.php
            │   ├── AuditService.php
            │   ├── SecurityEventService.php
            │   ├── DomainEventDispatcher.php
            │   ├── OutboxDispatcher.php
            │   ├── InboxConsumer.php
            │   ├── DeadLetterService.php
            │   ├── ReplayService.php
            │   ├── RedriveService.php
            │   ├── ReconciliationService.php
            │   └── Contracts/
            │
            ├── Infrastructure/
            │   ├── Persistence/
            │   ├── Broker/
            │   ├── Logging/
            │   ├── Integrity/
            │   ├── Scheduler/
            │   ├── Audit/
            │   └── Telemetry/
            │
            └── Presentation/
                ├── Http/
                └── Cli/

config/
├── signal-registry.php
├── signal-schemas.php
├── signal-retention.php
├── signal-delivery.php
├── signal-security.php
└── signal-scheduler.php

database/
└── migrations/
    └── create_signal_governance_tables.sql

resources/
├── signal-schemas/
├── evidence/
├── replay/
└── runbooks/

storage/
├── evidence/
├── dead-letter/
├── replay/
└── logs/

tests/
├── Unit/
├── Integration/
└── Uat/

tools/
├── signal-registry-validate.php
├── signal-schema-check.php
├── audit-chain-verify.php
├── outbox-reconcile.php
├── replay-dry-run.php
└── redrive-dry-run.php
```

---

### 4. Bootstrap Wiring

```php
<?php

declare(strict_types=1);

namespace App\Platform\Observability\Signals;

final class SignalBootstrap
{
    public static function build(
        array $config,
        object $container
    ): SignalKernel {
        $signalRegistry = new SignalRegistry();
        $schemaRegistry = new SignalSchemaRegistry();

        foreach ($config['signal_registrars'] as $registrarClass) {
            $container->get($registrarClass)->register(
                $signalRegistry
            );
        }

        foreach ($config['schema_registrars'] as $registrarClass) {
            $container->get($registrarClass)->register(
                $schemaRegistry
            );
        }

        $auditWriter = new AuditWriter(
            repository: $container->get(
                'signals.audit_repository'
            ),
            chain: $container->get(
                'signals.audit_chain_service'
            ),
            validator: $container->get(
                'signals.schema_validator'
            ),
            telemetry: $container->get(
                'signals.telemetry'
            )
        );

        $outboxDispatcher = new OutboxDispatcher(
            outbox: $container->get(
                'signals.outbox_repository'
            ),
            schemas: $schemaRegistry,
            validator: $container->get(
                'signals.schema_validator'
            ),
            broker: $container->get(
                'signals.message_broker'
            ),
            retry: $container->get(
                'signals.retry_policy'
            ),
            deadLetters: $container->get(
                'signals.dead_letter_service'
            ),
            telemetry: $container->get(
                'signals.telemetry'
            )
        );

        return new SignalKernel(
            registry: $signalRegistry,
            schemas: $schemaRegistry,
            audit: $auditWriter,
            logger: $container->get(
                'signals.structured_logger'
            ),
            security: $container->get(
                'signals.security_event_writer'
            ),
            domainEvents: $container->get(
                'signals.domain_event_dispatcher'
            ),
            outbox: $outboxDispatcher,
            inbox: $container->get(
                'signals.inbox_consumer'
            ),
            deadLetters: $container->get(
                'signals.dead_letter_service'
            ),
            replays: $container->get(
                'signals.replay_service'
            ),
            redrives: $container->get(
                'signals.redrive_service'
            )
        );
    }
}
```

---

### 5. Signal Registrar Contract

```php
interface SignalRegistrarInterface
{
    public function register(
        SignalRegistryInterface $registry
    ): void;
}
```

---

### 6. Schema Registrar Contract

```php
interface SignalSchemaRegistrarInterface
{
    public function register(
        SignalSchemaRegistryInterface $registry
    ): void;
}
```

---

### 7. Sample Registry — Patient Profile Updated Audit

```php
return [
    'code' => 'PATIENT_PROFILE_UPDATED',
    'category' => 'AUDIT_RECORD',
    'name' => 'Patient Profile Updated',
    'description' => 'Records a patient profile update.',
    'owner' => 'patient_domain',
    'schema_version' => '1.0',
    'classification' => 'RESTRICTED',
    'retention_policy' => 'audit_regulated',
    'integrity_policy' => 'HASH_CHAIN',
    'sampling_policy' => 'NONE',
    'tenant_scope' => 'TENANT_AWARE',
    'effective_from' => '2026-07-01',
    'status' => 'ACTIVE',
];
```

---

### 8. Sample Registry — Database Connection Failed Log

```php
return [
    'code' => 'DB_CONNECTION_FAILED',
    'category' => 'APPLICATION_LOG',
    'name' => 'Database Connection Failed',
    'description' => 'Operational database connection failure.',
    'owner' => 'platform_data',
    'schema_version' => '1.0',
    'classification' => 'CONFIDENTIAL',
    'retention_policy' => 'application_error_standard',
    'integrity_policy' => 'CHECKSUM',
    'sampling_policy' => 'NONE_FOR_ERROR',
    'tenant_scope' => 'TENANT_OPTIONAL',
    'effective_from' => '2026-07-01',
    'status' => 'ACTIVE',
];
```

---

### 9. Sample Registry — Authorization Denied Security Event

```php
return [
    'code' => 'authorization_policy_denied',
    'category' => 'SECURITY_EVENT',
    'name' => 'Authorization Policy Denied',
    'description' => 'Records a denied authorization policy evaluation.',
    'owner' => 'security_operations',
    'schema_version' => '1.0',
    'classification' => 'SECURITY_RESTRICTED',
    'retention_policy' => 'security_event_extended',
    'integrity_policy' => 'SIGNED_MANIFEST',
    'sampling_policy' => 'NONE',
    'tenant_scope' => 'TENANT_AWARE',
    'effective_from' => '2026-07-01',
    'status' => 'ACTIVE',
];
```

---

### 10. Sample Registry — PatientProfileUpdated Domain Event

```php
return [
    'code' => 'PatientProfileUpdated',
    'category' => 'DOMAIN_EVENT',
    'name' => 'Patient Profile Updated',
    'description' => 'Domain fact emitted after patient profile update.',
    'owner' => 'patient_domain',
    'schema_version' => '1.0',
    'classification' => 'CONFIDENTIAL',
    'retention_policy' => 'domain_event_standard',
    'integrity_policy' => 'CHECKSUM',
    'sampling_policy' => 'NONE',
    'tenant_scope' => 'TENANT_AWARE',
    'effective_from' => '2026-07-01',
    'status' => 'ACTIVE',
];
```

---

### 11. Sample Registry — PatientProfileChangedV1 Integration Event

```php
return [
    'code' => 'PatientProfileChangedV1',
    'category' => 'INTEGRATION_EVENT',
    'name' => 'Patient Profile Changed V1',
    'description' => 'Consumer-safe patient profile change contract.',
    'owner' => 'patient_integration',
    'schema_version' => '1.0',
    'classification' => 'CONFIDENTIAL',
    'retention_policy' => 'integration_delivery_standard',
    'integrity_policy' => 'CHECKSUM',
    'sampling_policy' => 'NONE',
    'tenant_scope' => 'TENANT_AWARE',
    'effective_from' => '2026-07-01',
    'status' => 'ACTIVE',
];
```

---

### 12. Sample Registry — Performance Regression Telemetry

```php
return [
    'code' => 'performance_regression_detected',
    'category' => 'TELEMETRY_EVENT',
    'name' => 'Performance Regression Detected',
    'description' => 'Telemetry event for performance regression.',
    'owner' => 'platform_operations',
    'schema_version' => '1.0',
    'classification' => 'INTERNAL',
    'retention_policy' => 'telemetry_standard',
    'integrity_policy' => 'CHECKSUM',
    'sampling_policy' => 'NONE_FOR_HIGH_SEVERITY',
    'tenant_scope' => 'GLOBAL_OR_TENANT',
    'effective_from' => '2026-07-01',
    'status' => 'ACTIVE',
];
```

---

### 13. Sample Audit JSON Schema

```json
{
  "$id": "audit-record-1.0",
  "type": "object",
  "required": [
    "audit_id",
    "schema_version",
    "occurred_at",
    "actor",
    "action",
    "resource",
    "result",
    "classification"
  ],
  "properties": {
    "audit_id": {
      "type": "string"
    },
    "schema_version": {
      "const": "1.0"
    },
    "tenant_id": {
      "type": ["integer", "null"]
    },
    "scope_id": {
      "type": ["integer", "null"]
    },
    "result": {
      "enum": [
        "SUCCESS",
        "FAILURE",
        "DENIED",
        "PARTIAL",
        "CANCELED"
      ]
    }
  },
  "additionalProperties": false
}
```

---

### 14. Sample Integration Event JSON Schema

```json
{
  "$id": "PatientProfileChangedV1-1.0",
  "type": "object",
  "required": [
    "message_id",
    "event_name",
    "schema_version",
    "published_at",
    "producer",
    "correlation_id",
    "idempotency_key",
    "payload",
    "classification"
  ],
  "properties": {
    "event_name": {
      "const": "PatientProfileChangedV1"
    },
    "schema_version": {
      "const": "1.0"
    },
    "payload": {
      "type": "object",
      "required": [
        "patient_reference",
        "changed_fields"
      ],
      "properties": {
        "patient_reference": {
          "type": "string"
        },
        "changed_fields": {
          "type": "array",
          "items": {
            "type": "string"
          }
        }
      },
      "additionalProperties": false
    }
  },
  "additionalProperties": false
}
```

---

### 15. Audit Writer Reference

```php
final class AuditWriter
    implements AuditWriterInterface
{
    public function append(
        AuditRecord $record
    ): void {
        $schema = $this->schemas->activeFor(
            signalCode: $record->actionCode,
            schemaVersion: $record->schemaVersion
        );

        $this->validator->assertValid(
            schema: $schema,
            payload: $record->toArray()
        );

        $chainState = $this->chains->lock(
            $record->chainId()
        );

        $record = $record->withChain(
            sequenceNo: $chainState->nextSequence(),
            previousHash: $chainState->lastHash(),
            recordHash: $this->hashes->hash(
                record: $record,
                previousHash: $chainState->lastHash(),
                sequenceNo: $chainState->nextSequence()
            )
        );

        $this->repository->append($record);
        $this->chains->advance($record);
    }
}
```

---

### 16. Structured Logger Reference

```php
final class StructuredLogger
    implements StructuredLoggerInterface
{
    public function log(
        string $level,
        string $eventCode,
        string $message,
        array $context = []
    ): void {
        $entry = StructuredLogEvent::create(
            timestamp: $this->clock->now(),
            level: $level,
            eventCode: $eventCode,
            message: $message,
            context: $this->sanitizer->sanitize($context),
            signalContext: $this->contexts->current()
        );

        if ($entry->estimatedBytes() > $this->limits->logBytes()) {
            $entry = $entry->withTruncatedContext();
        }

        $this->buffer->enqueue($entry);
    }
}
```

---

### 17. Security Event Writer Reference

```php
final class SecurityEventWriter
    implements SecurityEventWriterInterface
{
    public function write(
        SecurityEvent $event
    ): void {
        $schema = $this->schemas->activeFor(
            $event->eventName,
            $event->schemaVersion
        );

        $this->validator->assertValid(
            $schema,
            $event->toArray()
        );

        $this->repository->append($event);
        $this->detector->evaluate($event);
    }
}
```

---

### 18. Domain Event Dispatcher Reference

```php
final class DomainEventDispatcher
    implements DomainEventDispatcherInterface
{
    public function dispatch(
        array $events,
        DomainEventDispatchContext $context
    ): DomainEventDispatchResult {
        $result = new DomainEventDispatchResult();

        foreach ($events as $event) {
            $this->schemas->assertSupported(
                signalCode: $event->eventName(),
                schemaVersion: $event->eventVersion()
            );

            foreach ($this->handlers->for($event) as $handler) {
                $handler->handle($event, $context);
            }

            foreach ($this->mappers->for($event) as $mapper) {
                $integrationEvent = $mapper->map($event);

                $this->outbox->append(
                    OutboxMessage::fromEnvelope(
                        $integrationEvent
                    )
                );
            }

            $result->addDispatched($event->eventId());
        }

        return $result;
    }
}
```

---

### 19. Outbox Dispatcher Reference

```php
final class OutboxDispatcher
{
    public function dispatchBatch(
        OutboxDispatchCriteria $criteria
    ): OutboxDispatchResult {
        $batch = $this->outbox->acquireBatch(
            criteria: $criteria,
            workerId: $this->workerId,
            leaseUntil: $this->clock->now()->modify('+2 minutes')
        );

        $result = new OutboxDispatchResult();

        foreach ($batch as $message) {
            try {
                $schema = $this->schemas->activeFor(
                    $message->eventName,
                    $message->schemaVersion
                );

                $this->validator->assertValid(
                    schema: $schema,
                    payload: $message->envelope()
                );

                $published = $this->broker->publish(
                    $message->toBrokerMessage(),
                    PublishOptions::standard()
                );

                $this->outbox->markPublished(
                    outboxId: $message->id,
                    brokerReference: $published->reference,
                    publishedAt: $this->clock->now()
                );

                $result->addPublished($message->id);
            } catch (TransientPublishException $exception) {
                $this->outbox->releaseForRetry(
                    outboxId: $message->id,
                    availableAt: $this->retry->nextAttempt(
                        $message->attemptCount
                    ),
                    errorCode: $exception->errorCode()
                );

                $result->addRetried($message->id);
            } catch (\Throwable $exception) {
                $this->deadLetters->createFromOutboxFailure(
                    message: $message,
                    exception: $exception
                );

                $this->outbox->markDeadLetter(
                    $message->id,
                    $exception->getMessage()
                );

                $result->addFailed($message->id);
            }
        }

        return $result;
    }
}
```

---

### 20. Inbox Consumer Reference

```php
final class InboxConsumer
{
    public function consume(
        BrokerMessage $message,
        ConsumerContext $context
    ): ConsumerResult {
        $envelope = $this->decoder->decode($message);

        $this->validator->assertValidEnvelope($envelope);
        $this->tenantGuard->assertAllowed($envelope, $context);

        if ($this->inbox->hasProcessed(
            $context->consumerCode,
            $envelope->messageId
        )) {
            return ConsumerResult::duplicate();
        }

        return $this->transaction->run(
            function () use ($envelope, $context): ConsumerResult {
                $handler = $this->handlers->resolve(
                    $envelope->eventName,
                    $envelope->schemaVersion
                );

                $handler->consume($envelope, $context);

                $this->inbox->markProcessed(
                    consumerCode: $context->consumerCode,
                    messageId: $envelope->messageId,
                    eventName: $envelope->eventName,
                    schemaVersion: $envelope->schemaVersion,
                    processedAt: $this->clock->now(),
                    payloadHash: $envelope->payloadHash()
                );

                return ConsumerResult::success();
            }
        );
    }
}
```

---

### 21. Replay Service Reference

```php
final class ReplayService
{
    public function execute(
        string $replayId,
        SignalContext $context
    ): ReplayExecutionResult {
        $request = $this->requests->findById($replayId);

        if ($request === null) {
            throw new ReplayRequestNotFoundException();
        }

        $this->access->assertCanExecute($request, $context);

        if (!$request->isApproved()) {
            throw new ReplayNotApprovedException();
        }

        $events = $this->source->stream(
            $request->criteria()
        );

        $result = new ReplayExecutionResult();

        foreach ($events as $event) {
            if ($result->attempted >= $request->maximumEvents) {
                break;
            }

            $validation = $this->validator->validateReplay(
                request: $request,
                event: $event
            );

            if (!$validation->allowed) {
                $result->addSkipped(
                    $event->id,
                    $validation->reason
                );
                continue;
            }

            $delivery = $this->target->deliver(
                event: $event,
                mode: $request->mode
            );

            $this->results->save(
                ReplayEventResult::from(
                    request: $request,
                    event: $event,
                    delivery: $delivery
                )
            );

            $result->add($delivery);
        }

        return $result;
    }
}
```

---

### 22. Redrive Service Reference

```php
final class RedriveService
{
    public function execute(
        string $redriveId,
        SignalContext $context
    ): RedriveExecutionResult {
        $request = $this->requests->findById($redriveId);

        if ($request === null) {
            throw new RedriveRequestNotFoundException();
        }

        $this->access->assertCanExecute($request, $context);

        if (!$request->isApproved()) {
            throw new RedriveNotApprovedException();
        }

        $records = $this->deadLetters->findReady(
            $request->scope,
            $request->maximumBatchSize
        );

        $result = new RedriveExecutionResult();

        foreach ($records as $record) {
            $this->validator->assertRedriveAllowed($record);

            $delivery = $this->target->deliver(
                $record->toIntegrationEnvelope()
            );

            $this->deadLetters->recordRedriveResult(
                deadLetterId: $record->id,
                delivery: $delivery
            );

            $result->add($delivery);
        }

        return $result;
    }
}
```

---

### 23. Signal Context Factory Reference

```php
final class SignalContextFactory
{
    public function fromRequest(
        HttpRequest $request
    ): SignalContext {
        return SignalContext::create(
            requestId: $request->requestId(),
            correlationId: $request->correlationId(),
            causationId: $request->causationId(),
            traceId: $request->traceId(),
            actor: $request->authenticatedActor(),
            tenantId: $request->tenantId(),
            scopeId: $request->scopeId(),
            moduleCode: $request->moduleCode(),
            serviceCode: $request->serviceCode(),
            environment: $request->environment(),
            deploymentVersion: $request->deploymentVersion()
        );
    }
}
```

---

### 24. Transactional Outbox Usage Example

```php
$this->transaction->run(function () use ($patient, $context): void {
    $patient->updateProfile(
        $context->command->profileData()
    );

    $this->patients->save($patient);

    foreach ($patient->releaseDomainEvents() as $event) {
        $this->domainEvents->dispatch(
            events: [$event],
            context: DomainEventDispatchContext::from(
                $context
            )
        );
    }

    $this->audit->append(
        AuditRecordFactory::patientProfileUpdated(
            patient: $patient,
            context: $context
        )
    );
});
```

Catatan:

- audit dan outbox consistency mengikuti policy;
- audit failure pada privileged action dapat memakai fail-closed;
- seluruh write yang harus atomic berada pada transaction yang sama bila storage mendukung.

---

### 25. Scheduler Wiring

```php
$scheduler->everyMinute(
    'signal:outbox:dispatch',
    SignalOutboxDispatchJob::class
);

$scheduler->everyFiveMinutes(
    'signal:outbox:recover-leases',
    SignalOutboxLeaseRecoveryJob::class
);

$scheduler->everyFiveMinutes(
    'signal:dead-letter:monitor',
    SignalDeadLetterMonitorJob::class
);

$scheduler->everyMinute(
    'signal:replay:execute',
    SignalReplayExecutionJob::class
);

$scheduler->everyMinute(
    'signal:redrive:execute',
    SignalRedriveExecutionJob::class
);

$scheduler->hourly(
    'signal:audit:verify-chain',
    SignalAuditChainVerificationJob::class
);

$scheduler->hourly(
    'signal:reconcile',
    SignalReconciliationJob::class
);

$scheduler->dailyAt(
    '01:30',
    'signal:inbox:retention',
    SignalInboxRetentionJob::class
);

$scheduler->dailyAt(
    '02:30',
    'signal:schema:compatibility-check',
    SignalSchemaCompatibilityJob::class
);

$scheduler->hourly(
    'signal:evidence:expire',
    SignalEvidenceWorkspaceExpiryJob::class
);

$scheduler->everyFifteenMinutes(
    'signal:capacity:check',
    SignalCapacityCheckJob::class
);
```

---

### 26. Windows Task Scheduler

Untuk XAMPP/Windows:

```bat
D:\xampp\php\php.exe D:\xampp\htdocs\platform\bin\console scheduler:run
```

Schedule:

```text
Repeat task every: 1 minute
Duration: Indefinitely
Run whether user is logged on or not
```

---

### 27. Initial Migration Order

```text
1. signal_registry
2. signal_schema_registry
3. audit_chain_state
4. audit_records
5. audit_chain_verifications
6. security_events
7. domain_events
8. integration_outbox
9. integration_inbox
10. integration_dead_letters
11. integration_delivery_attempts
12. event_replay_requests
13. event_replay_results
14. event_redrive_requests
15. event_redrive_results
16. signal_chain_of_custody
17. signal_evidence_exports
18. signal_reconciliation_runs
19. signal_scheduler_runs
```

---

### 28. Seed Permissions

```text
observability.signal_registry.read
observability.signal_registry.manage
observability.schema_registry.read
observability.schema_registry.manage
observability.audit.read
observability.audit.restricted.read
observability.audit.export
observability.logging.read
observability.logging.manage
observability.security_event.read
observability.security_event.manage
observability.domain_event.read
observability.domain_event.replay
observability.integration_event.read
observability.integration_event.redrive
observability.event.dead_letter.read
observability.event.dead_letter.manage
observability.event.replay
observability.event.redrive
observability.evidence.read
observability.evidence.export
observability.cross_tenant.read
```

---

### 29. Role Mapping

| Role | Permission Utama |
|---|---|
| Platform Admin | registry, schema, operations |
| Compliance | audit, evidence, retention |
| Security Admin | security events, restricted evidence |
| Operations Admin | outbox, dead-letter, replay/redrive |
| Module Owner | domain/integration signals terkait |
| Tenant Admin | tenant-specific read terbatas |
| Auditor | approved read-only |
| Developer | non-production signals terbatas |
| End User | tidak ada akses teknis |

---

### 30. Configuration

```php
return [
    'enabled' => true,

    'audit' => [
        'enabled' => true,
        'fail_closed_for_privileged_actions' => true,
        'chain_scope' => 'tenant_month',
    ],

    'outbox' => [
        'enabled' => true,
        'batch_size' => 100,
        'lease_seconds' => 120,
        'maximum_attempts' => 10,
    ],

    'inbox' => [
        'enabled' => true,
        'retention_days' => 120,
    ],

    'dead_letter' => [
        'enabled' => true,
        'maximum_payload_bytes' => 262144,
    ],

    'replay' => [
        'enabled' => true,
        'production_requires_approval' => true,
        'maximum_events' => 10000,
    ],

    'redrive' => [
        'enabled' => true,
        'production_requires_approval' => true,
        'maximum_batch_size' => 500,
    ],
];
```

---

### 31. Environment Variables

```text
SIGNALS_ENABLED=true
SIGNALS_AUDIT_ENABLED=true
SIGNALS_OUTBOX_ENABLED=true
SIGNALS_INBOX_ENABLED=true
SIGNALS_REPLAY_ENABLED=true
SIGNALS_REDRIVE_ENABLED=true
SIGNALS_AUDIT_FAIL_CLOSED=true
SIGNALS_BROKER_DRIVER=database
SIGNALS_OUTBOX_BATCH_SIZE=100
SIGNALS_OUTBOX_LEASE_SECONDS=120
SIGNALS_OUTBOX_MAX_ATTEMPTS=10
SIGNALS_REPLAY_MAX_EVENTS=10000
SIGNALS_REDRIVE_MAX_BATCH=500
```

---

### 32. Deployment Checklist

#### Pre-Deployment

- [ ] Backup database tersedia.
- [ ] Migration direview.
- [ ] Signal registry divalidasi.
- [ ] Schema registry divalidasi.
- [ ] Compatibility test lulus.
- [ ] Audit chain policy disetujui.
- [ ] Outbox/inbox config siap.
- [ ] Broker adapter diuji.
- [ ] Dead-letter storage tersedia.
- [ ] Replay/redrive approval policy tersedia.
- [ ] Permissions tersedia.
- [ ] Retention dan legal hold mapping tersedia.
- [ ] Unit test lulus.
- [ ] Integration test lulus.
- [ ] Security review lulus.

#### Deployment

1. Deploy code.
2. Jalankan migration.
3. Seed permissions.
4. Register signal catalog.
5. Register schema catalog.
6. Verifikasi audit writer.
7. Verifikasi hash chain.
8. Verifikasi outbox insert.
9. Aktifkan dispatcher dalam shadow mode.
10. Verifikasi broker delivery.
11. Aktifkan inbox consumer.
12. Verifikasi duplicate handling.
13. Aktifkan dead-letter monitor.
14. Jalankan reconciliation.
15. Aktifkan replay/redrive hanya setelah approval workflow siap.

#### Post-Deployment

- [ ] Audit record tercatat.
- [ ] Audit chain valid.
- [ ] Structured log valid.
- [ ] Security event valid.
- [ ] Domain event valid.
- [ ] Outbox dipublish.
- [ ] Inbox duplicate detection bekerja.
- [ ] Dead-letter tercatat.
- [ ] Metrics aktif.
- [ ] Alerts aktif.
- [ ] Tidak ada secret/PHI/PII leakage.

---

### 33. Activation Strategy

Tahapan:

```text
OFF
→ SHADOW
→ MONITOR
→ ENFORCE
```

#### SHADOW

- registry dan schema aktif;
- validation menghasilkan warning;
- outbox dapat menulis tetapi belum publish ke consumer production;
- replay/redrive disabled.

#### MONITOR

- validation aktif;
- metrics dan alert aktif;
- delivery non-critical berjalan;
- failure ditinjau.

#### ENFORCE

- invalid schema ditolak;
- audit fail-closed untuk privileged action;
- replay/redrive approval wajib;
- compatibility guard aktif.

---

### 34. Rollback Plan

1. Suspend new schema activation.
2. Stop replay/redrive workers.
3. Stop outbox dispatcher bila perlu.
4. Pertahankan outbox records.
5. Rollback code.
6. Restore previous registry/schema versions.
7. Re-run compatibility check.
8. Re-run reconciliation.
9. Re-enable in SHADOW mode.
10. Resume dispatcher after validation.

Jangan menghapus outbox, inbox, audit, atau dead-letter evidence saat rollback.

---

### 35. Emergency Kill Switch

```text
SIGNALS_ENABLED=true
SIGNALS_AUDIT_ENABLED=true
SIGNALS_OUTBOX_DISPATCH_ENABLED=true
SIGNALS_CONSUMER_ENABLED=true
SIGNALS_REPLAY_ENABLED=false
SIGNALS_REDRIVE_ENABLED=false
SIGNALS_SECURITY_EVENT_ENABLED=true
```

Critical notes:

- audit kill switch tidak boleh sembarang digunakan;
- privileged action dapat diblokir bila audit unavailable;
- replay/redrive default aman adalah disabled.

---

### 36. Registry Validation Simulation

#### Input

Registry entry tanpa owner.

Expected:

```text
SIGNAL_REGISTRY_INVALID_OWNER
```

Selain itu:

- status tetap DRAFT;
- activation ditolak;
- audit configuration failure tercatat.

---

### 37. Schema Validation Simulation

#### Input

`PatientProfileChangedV1` tanpa `idempotency_key`.

Expected:

```text
SIGNAL_SCHEMA_VALIDATION_FAILED
```

Selain itu:

- outbox publish tidak dilakukan;
- message masuk quarantine/dead-letter sesuai source;
- no partial consumer processing.

---

### 38. Backward Compatibility Simulation

#### Change

Menambah field optional:

```text
payload.source_channel
```

Expected:

- backward compatibility PASS;
- version minor dapat dipertahankan jika policy mengizinkan;
- consumer lama tetap dapat memproses.

---

### 39. Breaking Change Simulation

#### Change

Mengubah:

```text
changed_fields: array
```

menjadi:

```text
changed_fields: string
```

Expected:

```text
SIGNAL_SCHEMA_INCOMPATIBLE
```

Activation ditolak pada version yang sama.

---

### 40. Audit Integrity Simulation

#### Trigger

Ubah satu audit record secara manual.

Expected:

- hash chain verification FAILED;
- alert critical;
- incident candidate;
- chain ditandai SUSPECT;
- purge/archive movement diblokir;
- evidence dipertahankan.

---

### 41. Outbox Success Simulation

#### Flow

1. Domain transaction update.
2. Outbox insert.
3. Commit.
4. Dispatcher acquire.
5. Schema validation.
6. Publish.
7. Mark PUBLISHED.
8. Consumer process.
9. Inbox mark processed.
10. Broker ack.

Expected:

- one logical business effect;
- complete correlation;
- delivery attempt recorded.

---

### 42. Outbox Retry Simulation

#### Trigger

Broker timeout.

Expected:

- message kembali PENDING;
- attempt count naik;
- backoff diterapkan;
- no domain rollback;
- no duplicate logical effect;
- alert jika backlog sustained.

---

### 43. Duplicate Delivery Simulation

#### Trigger

Broker mengirim message sama dua kali.

Expected:

- inbox mendeteksi duplicate;
- second delivery di-ack;
- business handler tidak dijalankan ulang;
- duplicate metric naik.

---

### 44. Out-of-Order Simulation

#### Trigger

Aggregate version 12 tiba sebelum 11.

Expected:

- gap terdeteksi;
- message ditahan/retry/dead-letter sesuai policy;
- no silent apply;
- operational signal dibuat.

---

### 45. Dead-Letter Simulation

#### Trigger

Consumer menerima unsupported schema version.

Expected:

- message tidak diproses;
- dead-letter dibuat;
- classification dipertahankan;
- payload dimasking pada UI;
- alert sesuai severity.

---

### 46. Replay Dry-Run Simulation

#### Input

```text
PatientProfileChangedV1
tenant_id = 10
range = 1 day
target = analytics-shadow-v2
```

Expected:

- event count estimate;
- schema compatibility result;
- duplicate risk result;
- no side effect;
- audit request tercatat.

---

### 47. Production Replay Simulation

Expected:

- request created;
- approval required;
- bounded count;
- rate limit;
- per-event result;
- audit execution;
- can stop/cancel safely.

---

### 48. Redrive Simulation

#### Trigger

100 dead-letter messages setelah mapping diperbaiki.

Expected:

- dry-run first;
- root cause attached;
- approval if required;
- idempotency verified;
- success/failed/skipped report;
- original dead-letter evidence preserved.

---

### 49. Cross-Tenant Replay Simulation

Request operator tenant A untuk replay tenant B.

Expected:

```text
CROSS_TENANT_ACCESS_DENIED
```

Kecuali permission khusus dan purpose valid tersedia.

---

### 50. Secret Leakage Simulation

Payload mengandung:

```text
authorization_header
api_key
password
```

Expected:

- validation/sanitization rejects;
- quarantine;
- security event optional;
- no broker publish;
- no raw secret in log.

---

### 51. PHI Minimization Simulation

Integration mapper mencoba mengirim full patient object.

Expected:

- payload policy violation;
- mapping rejected;
- only safe patient reference and necessary fields allowed.

---

### 52. Audit Write Failure Simulation

#### Trigger

Audit store unavailable saat role assignment.

Expected:

- privileged action gagal jika fail-closed;
- critical alert;
- no silent success;
- fallback evidence/incident according policy.

---

### 53. Broker Outage Simulation

Expected:

- domain transaction tetap commit;
- outbox backlog meningkat;
- health DEGRADED;
- oldest age alert;
- delivery resumes after recovery;
- no message loss.

---

### 54. Inbox Store Failure Simulation

Expected:

- consumer tidak ack;
- business transaction rollback;
- message redelivered;
- no untracked side effect;
- critical operational alert.

---

### 55. Reconciliation Simulation

Check:

```text
domain change
→ expected outbox exists
→ published status
→ consumer inbox result
```

Expected:

- missing outbox detected;
- stuck processing detected;
- published-without-inbox reported;
- no automatic destructive correction without policy.

---

### 56. Operational Runbook — Audit Write Failure

1. Tentukan affected actions.
2. Cek audit database health.
3. Cek credential dan permission.
4. Cek chain lock.
5. Aktifkan compensating mode hanya jika approved.
6. Block privileged action bila policy fail-closed.
7. Buat incident.
8. Restore audit writer.
9. Reconcile missing evidence.
10. Verifikasi chain.
11. Tutup incident dengan evidence.

---

### 57. Operational Runbook — Audit Chain Broken

1. Stop purge/archive transition terkait.
2. Mark chain SUSPECT.
3. Identify first failing sequence.
4. Verify database/backup/replica.
5. Check unauthorized modification.
6. Preserve evidence.
7. Create security incident.
8. Restore from trusted copy if approved.
9. Re-run full verification.
10. Record chain of custody.

---

### 58. Operational Runbook — Outbox Backlog

1. Cek pending count.
2. Cek oldest age.
3. Cek broker availability.
4. Cek worker heartbeat.
5. Cek schema validation failures.
6. Cek lease expiration.
7. Scale worker bila aman.
8. Tune batch size cautiously.
9. Monitor consumer capacity.
10. Verify backlog recovery.

---

### 59. Operational Runbook — Dead-Letter Growth

1. Group by event/error code.
2. Determine transient/permanent.
3. Check schema/version.
4. Check tenant mismatch.
5. Assign owner.
6. Fix producer/consumer.
7. Run dry-run redrive.
8. Obtain approval if needed.
9. Execute bounded redrive.
10. Verify residual failures.

---

### 60. Operational Runbook — Replay Failure

1. Pause replay.
2. Check target consumer.
3. Check schema compatibility.
4. Check duplicate/idempotency.
5. Check ordering.
6. Check rate limit.
7. Review failed event subset.
8. Fix root cause.
9. Resume bounded batch.
10. Audit final result.

---

### 61. Operational Runbook — Inbox Failure

1. Stop acknowledgements.
2. Check inbox database.
3. Check unique constraint.
4. Check transaction boundaries.
5. Verify no business side effect committed without inbox.
6. Restore store.
7. Resume consumer.
8. Verify duplicate safety.
9. Reconcile affected messages.
10. Document result.

---

### 62. Operational Runbook — Schema Incompatibility

1. Stop candidate schema activation.
2. Identify incompatible fields.
3. Identify affected producers/consumers.
4. Decide new major version.
5. Create migration/deprecation plan.
6. Run compatibility tests.
7. Deploy consumers first if required.
8. Activate new schema.
9. Monitor old/new versions.
10. Retire old version after window.

---

### 63. Backup & Restore

Backup wajib mencakup:

- signal registry;
- schema registry;
- audit records;
- chain state;
- security events;
- domain events if adopted;
- outbox;
- inbox;
- dead-letter;
- replay/redrive requests and results;
- chain of custody;
- evidence exports;
- scheduler state.

---

### 64. Restore Validation

Validate:

- registry/schema hash;
- audit chain continuity;
- outbox status;
- inbox unique keys;
- dead-letter references;
- replay/redrive state;
- tenant isolation;
- retention/legal holds;
- broker recovery readiness.

---

### 65. Performance Test Plan

Scenarios:

```text
1.000 audit writes/sec
5.000 structured logs/sec
500 security events/sec
1.000 outbox messages/sec
1.000 consumer messages/sec
duplicate delivery storm
broker outage with backlog
large replay dry-run
dead-letter redrive batch
audit chain verification
```

---

### 66. Performance Acceptance

| Operation | Target |
|---|---:|
| Audit append p95 | < 100 ms |
| Structured log enqueue p95 | < 5 ms |
| Security event enqueue p95 | < 25 ms |
| Outbox append p95 | < 50 ms |
| Inbox duplicate check p95 | < 25 ms |
| Outbox acquire batch | < 500 ms |
| Registry lookup | < 100 ms |
| Schema validation | < 50 ms typical |
| Audit search bounded | < 1 s |
| Replay enqueue | < 500 ms |
| Redrive enqueue | < 500 ms |

---

### 67. Security Test Plan

- audit update/delete attempt;
- cross-tenant search;
- replay without permission;
- redrive without approval;
- raw secret injection;
- PHI-heavy payload;
- oversized payload;
- evidence path access;
- dead-letter raw payload access;
- schema downgrade attack;
- forged correlation header;
- message tampering;
- replay amplification.

---

### 68. Final UAT — Classification & Registry

- [ ] Signal taxonomy diterapkan.
- [ ] Audit tidak dipakai sebagai log biasa.
- [ ] Domain event dibedakan dari integration event.
- [ ] Registry code unik.
- [ ] Owner tersedia.
- [ ] Retention policy tersedia.
- [ ] Classification tersedia.
- [ ] Lifecycle state bekerja.
- [ ] Deprecation bekerja.
- [ ] Registry change diaudit.

---

### 69. Final UAT — Schemas

- [ ] Audit schema valid.
- [ ] Log schema valid.
- [ ] Security event schema valid.
- [ ] Domain event schema valid.
- [ ] Integration event schema valid.
- [ ] Compatibility check bekerja.
- [ ] Breaking change ditolak.
- [ ] Payload size limit bekerja.
- [ ] Secret field ditolak.
- [ ] PHI/PII minimization bekerja.

---

### 70. Final UAT — Audit

- [ ] Audit append berhasil.
- [ ] Actor/action/resource/result tersedia.
- [ ] Tenant/scope tersedia.
- [ ] Hash chain terbentuk.
- [ ] Update/delete ditolak.
- [ ] Correction record bekerja.
- [ ] Integrity verification bekerja.
- [ ] Export membutuhkan permission.
- [ ] Legal hold memblokir purge.
- [ ] Audit tidak disampling.

---

### 71. Final UAT — Outbox & Broker

- [ ] Outbox dalam transaction domain.
- [ ] Message ID unik.
- [ ] Idempotency key unik.
- [ ] Schema validation sebelum publish.
- [ ] Lease bekerja.
- [ ] Retry transient bekerja.
- [ ] Permanent failure masuk dead-letter.
- [ ] Broker outage tidak menghilangkan message.
- [ ] Delivery attempt tercatat.
- [ ] Backlog alert bekerja.

---

### 72. Final UAT — Inbox & Consumer

- [ ] Schema validation setelah receive.
- [ ] Tenant guard bekerja.
- [ ] Duplicate detection bekerja.
- [ ] Ack setelah commit.
- [ ] Failure rollback.
- [ ] Out-of-order terdeteksi.
- [ ] Unsupported version masuk dead-letter.
- [ ] Inbox retention mencakup replay window.
- [ ] Consumer metrics tersedia.
- [ ] Reconciliation bekerja.

---

### 73. Final UAT — Dead-Letter, Replay, Redrive

- [ ] Dead-letter lifecycle bekerja.
- [ ] Payload restricted.
- [ ] Root cause tercatat.
- [ ] Dry-run replay bekerja.
- [ ] Shadow replay aman.
- [ ] Production replay membutuhkan approval.
- [ ] Redrive bounded.
- [ ] Idempotency dijaga.
- [ ] Result per event tersedia.
- [ ] Original evidence dipertahankan.
- [ ] Semua action diaudit.

---

### 74. Final UAT — Security & Privacy

- [ ] Secret tidak tercatat.
- [ ] PHI/PII diminimalkan.
- [ ] Tenant/scope isolation bekerja.
- [ ] Cross-tenant permission diterapkan.
- [ ] Classification masking bekerja.
- [ ] Evidence terenkripsi.
- [ ] Dead-letter storage tidak public.
- [ ] Replay amplification dibatasi.
- [ ] Forged context ditolak.
- [ ] Four-eyes approval bekerja.

---

### 75. Final UAT — Scheduler & Recovery

- [ ] Outbox dispatcher berjalan.
- [ ] Lease recovery berjalan.
- [ ] Dead-letter monitor berjalan.
- [ ] Replay worker berjalan.
- [ ] Redrive worker berjalan.
- [ ] Audit chain verifier berjalan.
- [ ] Reconciliation berjalan.
- [ ] Registry cache refresh berjalan.
- [ ] Job lock/idempotency bekerja.
- [ ] Stuck job terdeteksi.
- [ ] Backup/restore diuji.
- [ ] Broker recovery diuji.
- [ ] Kill switch diuji.
- [ ] Rollback diuji.

---

### 76. Production Readiness Checklist

- [ ] Semua signal memiliki owner.
- [ ] Semua signal memiliki schema.
- [ ] Semua signal memiliki retention.
- [ ] Semua signal memiliki classification.
- [ ] Audit integrity aktif.
- [ ] Outbox/inbox aktif.
- [ ] Broker adapter aktif.
- [ ] Dead-letter workflow tersedia.
- [ ] Replay/redrive policy tersedia.
- [ ] Legal hold mapping tersedia.
- [ ] Permissions tersedia.
- [ ] Dashboards/alerts tersedia.
- [ ] Runbooks tersedia.
- [ ] Tenant isolation diuji.
- [ ] Security review lulus.
- [ ] Privacy review lulus.
- [ ] Performance test lulus.
- [ ] Restore test lulus.
- [ ] Operations sign-off tersedia.
- [ ] Compliance sign-off tersedia.

---

### 77. Ownership Matrix

| Area | Owner |
|---|---|
| Signal Governance | Platform Architecture |
| Audit | Compliance + Security |
| Structured Logging | Module/Service Owners |
| Security Events | Security Operations |
| Domain Events | Domain Owners |
| Integration Contracts | Producer + Consumer Owners |
| Outbox/Inbox | Platform Operations |
| Broker Adapter | Platform Infrastructure |
| Replay/Redrive | Platform Operations + Domain Owner |
| Retention/Legal Hold | Data Governance + Legal |
| Evidence/Chain of Custody | Compliance |

---

### 78. Definition of Done — SSOT-OBS-10

#### Foundation

- [ ] signal taxonomy;
- [ ] audit/log/event/trace/metric boundary;
- [ ] decision matrix;
- [ ] source-of-truth matrix;
- [ ] ownership;
- [ ] governance.

#### Schema & Delivery

- [ ] audit schema;
- [ ] log schema;
- [ ] security event schema;
- [ ] domain event envelope;
- [ ] integration event envelope;
- [ ] registry;
- [ ] compatibility;
- [ ] idempotency;
- [ ] ordering;
- [ ] outbox/inbox;
- [ ] replay/redrive.

#### Storage & Integrity

- [ ] storage separation;
- [ ] audit append-only;
- [ ] hash chain;
- [ ] event store guidance;
- [ ] dead-letter storage;
- [ ] broker abstraction;
- [ ] retention/legal hold;
- [ ] archive;
- [ ] chain of custody;
- [ ] DR.

#### Infrastructure

- [ ] HTTP API;
- [ ] controllers;
- [ ] middleware;
- [ ] database schema;
- [ ] scheduler;
- [ ] dispatcher/workers;
- [ ] audit integration;
- [ ] alerts/metrics;
- [ ] security controls;
- [ ] Apache/XAMPP routing.

#### Operations

- [ ] reference implementation;
- [ ] sample registries;
- [ ] sample schemas;
- [ ] deployment;
- [ ] rollback;
- [ ] simulations;
- [ ] runbooks;
- [ ] final UAT.

---

### 79. Implementation Definition of Done

Implementasi dianggap selesai bila:

- [ ] core classes dibuat;
- [ ] migrations berhasil;
- [ ] signal registry aktif;
- [ ] schema registry aktif;
- [ ] audit writer aktif;
- [ ] hash chain aktif;
- [ ] structured logger aktif;
- [ ] security event writer aktif;
- [ ] domain event dispatcher aktif;
- [ ] outbox dispatcher aktif;
- [ ] inbox consumer aktif;
- [ ] dead-letter aktif;
- [ ] replay/redrive aktif;
- [ ] scheduler aktif;
- [ ] metrics/alerts aktif;
- [ ] unit test lulus;
- [ ] integration test lulus;
- [ ] UAT lulus;
- [ ] security review lulus;
- [ ] privacy review lulus;
- [ ] performance target tercapai;
- [ ] deployment/rollback diuji;
- [ ] restore/reconciliation diuji.

---

### 80. Roadmap

#### Phase 1 — Foundation

- signal registry;
- schema registry;
- structured logging;
- audit writer;
- database outbox;
- inbox duplicate detection;
- dead-letter basic.

#### Phase 2 — Controlled Delivery

- broker adapter;
- schema compatibility;
- retry/backoff;
- replay dry-run;
- redrive workflow;
- audit chain verification;
- dashboards.

#### Phase 3 — Enterprise Governance

- WORM archive;
- advanced legal hold;
- chain of custody;
- multi-region broker;
- event store optional;
- signed schema artifacts;
- evidence export workflow.

#### Phase 4 — Intelligence & Automation

- automated contract compatibility;
- consumer impact analysis;
- automated reconciliation;
- anomaly detection on event flows;
- predictive backlog capacity;
- policy-as-code;
- AI-assisted schema and signal review.

---

### 81. Future Evolution

- OpenTelemetry semantic convention alignment;
- CloudEvents-compatible envelope;
- Avro/Protobuf adapters;
- Kafka/RabbitMQ/Redis Streams adapters;
- schema registry service;
- immutable audit ledger;
- Merkle tree verification;
- hardware-backed signing;
- consumer contract testing platform;
- self-service replay sandbox;
- automated event lineage;
- data residency routing;
- tenant-specific encryption keys;
- event-driven compliance evidence;
- AI-assisted event governance.

---

### 82. Merge Guidance

Gabungkan:

```text
SSOT-OBS-10-Part-1.md
SSOT-OBS-10-Part-2.md
SSOT-OBS-10-Part-3.md
SSOT-OBS-10-Part-4.md
SSOT-OBS-10-Part-5.md
```

menjadi:

```text
SSOT-OBS-10.md
```

Urutan:

```text
Part 1 — Vision, Definitions, Boundaries, Decision Matrix
Part 2 — Schemas, Registry, Compatibility, Delivery
Part 3 — Storage, Integrity, Retention, Legal Hold, DR
Part 4 — API, Scheduler, Dispatcher, Workers, Database
Part 5 — Reference Implementation & Operations
```

---

### 83. Merge Quality Checklist

- [ ] heading tidak duplikat;
- [ ] signal categories konsisten;
- [ ] schema field names konsisten;
- [ ] classification konsisten;
- [ ] retention policy references konsisten;
- [ ] audit action names konsisten;
- [ ] event names konsisten;
- [ ] permission names konsisten;
- [ ] table names konsisten;
- [ ] namespace konsisten;
- [ ] endpoint konsisten;
- [ ] error codes konsisten;
- [ ] duplicate section dihapus;
- [ ] daftar isi dibuat;
- [ ] metadata final diperbarui;
- [ ] status final diset Review/Approved.

---

### 84. Final Metadata

```yaml
document_code: SSOT-OBS-10
title: Audit vs Logging vs Event Guideline
version: 1.0
status: Draft for Review
domain: Platform Kernel
category: Observability & Governance
owners:
  - Platform Architecture
  - Security
  - Compliance
  - Platform Operations
reviewers:
  - Backend Engineering
  - Domain Owners
  - Integration Engineering
  - DevOps
  - QA
  - Legal
  - Data Governance
```

---

### 85. Approval Gate

Dokumen dapat menjadi Approved setelah:

- architecture review;
- audit/compliance review;
- logging review;
- security event review;
- domain event review;
- integration contract review;
- schema compatibility review;
- outbox/inbox review;
- broker abstraction review;
- retention/legal hold review;
- database schema review;
- security review;
- privacy review;
- QA/UAT review;
- performance review;
- deployment/rollback review;
- restore/reconciliation review;
- operations sign-off.

---

### 86. Closing Statement

Audit, log, event, trace, metric, dan incident bukan istilah yang dapat dipertukarkan.

Setiap signal harus memiliki:

- purpose yang jelas;
- schema yang tepat;
- owner yang jelas;
- retention yang sesuai;
- access control;
- privacy protection;
- integrity;
- delivery semantics;
- operational lifecycle.

Framework tidak boleh:

- menggunakan log sebagai audit utama;
- menggunakan event sebagai debug text;
- menggunakan trace sebagai legal evidence;
- menggunakan metric sebagai event history;
- mengirim integration event tanpa schema dan idempotency;
- mengizinkan replay tanpa kontrol;
- mengizinkan audit diubah;
- membocorkan secret atau PHI/PII.

Framework harus memastikan satu kejadian dapat menghasilkan beberapa signal yang tepat tanpa mencampur fungsi, durability, retention, atau governance masing-masing.

---

## Lampiran A — Sumber Penggabungan

Dokumen final ini digabung dan dinormalisasi dari:

- `SSOT-OBS-10-Part-1.md`
- `SSOT-OBS-10-Part-2.md`
- `SSOT-OBS-10-Part-3.md`
- `SSOT-OBS-10-Part-4.md`
- `SSOT-OBS-10-Part-5.md`

## Lampiran B — Approval Gate

Status dokumen dapat diubah menjadi **Approved** setelah:

- architecture review selesai;
- audit dan compliance review selesai;
- logging review selesai;
- security event review selesai;
- domain event review selesai;
- integration contract review selesai;
- schema compatibility review selesai;
- outbox/inbox review selesai;
- broker abstraction review selesai;
- retention dan legal hold review selesai;
- database schema disetujui;
- permission dan tenant/scope policy disetujui;
- security review selesai;
- privacy review selesai;
- QA/UAT review selesai;
- performance review selesai;
- deployment dan rollback review selesai;
- restore dan reconciliation review selesai;
- operations sign-off tersedia.
