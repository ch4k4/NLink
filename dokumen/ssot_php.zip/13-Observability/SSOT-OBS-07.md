# SSOT-OBS-07 — Alerting & Incident Management Framework

> Single Source of Truth untuk arsitektur, alert processing, incident management, notification delivery, on-call, API, persistence, keamanan, operasi, dan pengujian Alerting & Incident Management Framework pada Platform Kernel.

## Metadata Dokumen

| Item | Nilai |
|---|---|
| Kode | SSOT-OBS-07 |
| Judul | Alerting & Incident Management Framework |
| Versi | 1.0 |
| Status | Draft for Review |
| Domain | Platform Kernel |
| Kategori | Observability |
| Target Stack | PHP 8.1+, PDO, MySQL 8/MariaDB, Apache/XAMPP, Modular Monolith |
| Bergantung pada | SSOT-OBS-01 sampai SSOT-OBS-06 |
| Pemilik | Platform Architecture, Platform Operations, Security |
| Reviewer | Backend Engineering, DevOps, QA, Security, Compliance |

## Tujuan Dokumen

Dokumen ini menetapkan standar tunggal untuk:

- alert model, severity, state, ownership, dan fingerprint;
- rule evaluation, deduplication, grouping, suppression, routing, escalation, dan recovery;
- incident declaration, assignment, timeline, communication, runbook, SLA/OLA, postmortem, dan action items;
- notification adapters, retry, dead-letter, idempotency, dan on-call;
- HTTP API, middleware, permission, tenant/scope isolation, database schema, scheduler, dan audit;
- reference implementation, deployment, rollback, simulation, performance testing, UAT, dan Definition of Done.

## Daftar Isi

1. Bagian I — Vision, Alert Model, Severity, Incident Lifecycle & Ownership
2. Bagian II — Alert Rules, Evaluation, Deduplication, Grouping, Suppression, Routing & Escalation
3. Bagian III — Incident Management, Assignment, Timeline, Communication, SLA, Runbook & Postmortem
4. Bagian IV — Notification Adapters, On-Call, HTTP API, Database Schema, Audit & Routing
5. Bagian V — Reference Implementation, Deployment, Simulation, Final UAT & Operational Readiness
6. Lampiran A — Sumber Penggabungan
7. Lampiran B — Approval Gate

## Status Normatif

Kata **wajib**, **harus**, dan **tidak boleh** menyatakan persyaratan normatif. Kata **direkomendasikan**, **sebaiknya**, dan **dapat** menyatakan panduan yang dapat disesuaikan melalui keputusan arsitektur terdokumentasi.

---

## Bagian I — Vision, Alert Model, Severity, Incident Lifecycle & Ownership

### 1. Executive Summary

Alerting & Incident Management Framework menyediakan standar tunggal untuk mendeteksi, mengelompokkan, merutekan, menangani, dan menutup gangguan operasional pada Platform Kernel.

Framework ini menghubungkan:

```text
Metrics
Health Check
Structured Logs
Distributed Tracing
Monitoring Dashboard
Security Signals
Business Operational Signals
```

menjadi dua domain yang berbeda tetapi saling terkait:

```text
Alert
Incident
```

Alert adalah sinyal bahwa suatu kondisi melewati batas atau terdeteksi abnormal.

Incident adalah gangguan terkelola yang membutuhkan ownership, koordinasi, pemulihan, dan pencatatan.

Tidak setiap alert menjadi incident.

Tidak setiap incident berasal dari satu alert.

Framework harus mampu:

- mendeteksi kondisi abnormal;
- menilai severity;
- menghindari alert noise;
- mencegah duplikasi;
- mengelompokkan alert terkait;
- menentukan owner;
- menjalankan escalation;
- membuat incident;
- mencatat timeline;
- menghubungkan runbook;
- mendukung recovery;
- menghasilkan post-incident review;
- menjaga RBAC, tenant, scope, dan privacy.

---

### 2. Problem Statement

Tanpa framework standar, alerting sering berubah menjadi:

- notifikasi berlebihan;
- satu masalah menghasilkan ratusan alert;
- alert tanpa owner;
- severity tidak konsisten;
- incident tidak tercatat;
- recovery tidak diketahui;
- on-call menerima alert yang tidak actionable;
- masalah tenant bercampur dengan tenant lain;
- security incident terlihat oleh user yang tidak berwenang;
- tidak ada runbook;
- tidak ada escalation;
- tidak ada postmortem;
- alert ditutup tanpa bukti pemulihan.

Contoh:

```text
Database latency tinggi
→ 500 endpoint melambat
→ queue backlog naik
→ integration timeout
→ ratusan alert terpisah
```

Tanpa correlation dan grouping, operator menerima banyak gejala tetapi tidak melihat akar masalah.

---

### 3. Tujuan Framework

Framework harus menjawab:

- Kondisi apa yang menghasilkan alert?
- Seberapa parah alert tersebut?
- Apakah alert actionable?
- Apakah alert duplikat?
- Apakah alert terkait alert lain?
- Siapa owner alert?
- Kapan alert harus di-escalate?
- Kapan alert menjadi incident?
- Tenant, scope, module, dan service mana yang terdampak?
- Apakah recovery telah terverifikasi?
- Apakah postmortem wajib?
- Siapa yang boleh melihat atau mengubah alert dan incident?

---

### 4. Non-Goals

Part 1 tidak menjadikan framework sebagai:

- SIEM penuh;
- ticketing system umum;
- project management tool;
- chat platform;
- paging vendor;
- root cause analysis otomatis;
- self-healing engine;
- vulnerability scanner.

Vendor atau tool tersebut dapat diintegrasikan melalui adapter.

---

### 5. Design Principles

#### 5.1 Actionable Alerts

Alert harus mengarah pada tindakan.

Alert wajib memiliki:

- kondisi;
- severity;
- owner;
- source;
- context;
- threshold atau detection rule;
- recommended action atau runbook.

#### 5.2 Alert Is Not Incident

Alert adalah sinyal.

Incident adalah proses penanganan gangguan.

Pemisahan ini wajib dipertahankan.

#### 5.3 Noise Reduction

Framework harus mendukung:

- deduplication;
- grouping;
- suppression;
- maintenance window;
- cooldown;
- hysteresis;
- minimum samples;
- dependency awareness.

#### 5.4 Ownership First

Alert tanpa owner dianggap configuration defect.

#### 5.5 Severity Consistency

Severity harus memakai definisi tunggal lintas module dan tenant.

#### 5.6 Scope-Aware

Alert dan incident harus memiliki konteks:

- environment;
- tenant;
- organization;
- business entity;
- scope;
- module;
- component;
- service.

#### 5.7 Secure by Design

Framework tidak boleh membocorkan:

- PHI;
- PII;
- secret;
- token;
- raw stack trace;
- raw security evidence;
- tenant detail lintas scope.

#### 5.8 Immutable Timeline

Timeline incident harus append-only secara logis.

Perubahan penting tidak boleh menghapus history.

#### 5.9 Recovery Must Be Verified

Alert tidak boleh ditutup hanya karena waktu berlalu.

Recovery harus berdasarkan kondisi clear atau verifikasi operator.

#### 5.10 Vendor Independent

Framework tidak boleh bergantung penuh pada PagerDuty, Opsgenie, Slack, Teams, email, SMS, atau vendor observability tertentu.

Vendor adalah adapter.

---

### 6. High-Level Architecture

```text
Signal Sources
    │
    ├── Metrics
    ├── Health
    ├── Logs
    ├── Traces
    ├── Security
    └── Business Operations
    │
    ▼
Alert Rule Engine
    │
    ├── Threshold Evaluation
    ├── State Evaluation
    ├── Anomaly Detection
    ├── Deduplication
    ├── Grouping
    └── Suppression
    │
    ▼
Alert Manager
    │
    ├── Ownership
    ├── Routing
    ├── Escalation
    ├── Notification
    └── Recovery
    │
    ▼
Incident Manager
    │
    ├── Incident Creation
    ├── Assignment
    ├── Timeline
    ├── Runbook
    ├── Coordination
    ├── Resolution
    └── Postmortem
    │
    ▼
Dashboard / Reports / Audit
```

---

### 7. Core Components

Framework terdiri dari:

```text
AlertRule
AlertSignal
Alert
AlertState
AlertSeverity
AlertFingerprint
AlertGroup
AlertOwner
AlertRoute
AlertEscalationPolicy
Incident
IncidentState
IncidentSeverity
IncidentTimeline
IncidentOwner
IncidentRunbook
IncidentPostmortem
```

---

### 8. Alert Definition

Alert adalah record operasional yang menunjukkan kondisi abnormal atau risiko operasional.

Field minimum:

| Field | Keterangan |
|---|---|
| alert_id | identifier unik |
| rule_code | rule yang memicu |
| title | ringkasan |
| description | penjelasan aman |
| source_type | metric/health/log/trace/security/business |
| source_reference | referensi source |
| severity | tingkat keparahan |
| state | lifecycle alert |
| fingerprint | deduplication key |
| environment | local/staging/production |
| tenant_id | optional |
| scope_id | optional |
| module_code | optional |
| component | optional |
| owner_team | owner |
| triggered_at | waktu trigger |
| acknowledged_at | waktu ack |
| resolved_at | waktu recovery |
| last_seen_at | signal terakhir |
| occurrence_count | jumlah occurrence |
| runbook_reference | optional |
| incident_id | optional |

---

### 9. Alert Source Types

```text
METRIC
HEALTH
LOG
TRACE
SECURITY
BUSINESS_OPERATION
MANUAL
EXTERNAL
```

Contoh:

- `METRIC`: error rate > threshold;
- `HEALTH`: database DOWN;
- `LOG`: exception pattern meningkat;
- `TRACE`: distributed latency spike;
- `SECURITY`: privileged login anomaly;
- `BUSINESS_OPERATION`: claim submission backlog;
- `MANUAL`: operator membuat alert;
- `EXTERNAL`: vendor status outage.

---

### 10. Alert States

```text
PENDING
FIRING
ACKNOWLEDGED
SUPPRESSED
RESOLVED
CLOSED
EXPIRED
```

#### 10.1 PENDING

Kondisi terdeteksi tetapi belum memenuhi duration/minimum sample.

#### 10.2 FIRING

Kondisi aktif dan memenuhi rule.

#### 10.3 ACKNOWLEDGED

Owner telah melihat dan menerima tanggung jawab awal.

#### 10.4 SUPPRESSED

Alert sengaja tidak diteruskan karena policy:

- maintenance;
- dependency failure;
- duplicate;
- mute window;
- approved suppression.

#### 10.5 RESOLVED

Kondisi clear terverifikasi.

#### 10.6 CLOSED

Alert telah selesai secara operasional dan tidak memerlukan tindakan.

#### 10.7 EXPIRED

Alert kehilangan relevance karena TTL atau source tidak lagi berlaku.

---

### 11. Alert State Transition

```text
PENDING
  ↓
FIRING
  ├──→ ACKNOWLEDGED
  ├──→ SUPPRESSED
  └──→ RESOLVED
          ↓
        CLOSED
```

Transition invalid harus ditolak.

Contoh invalid:

```text
CLOSED → FIRING
```

Jika kondisi muncul kembali, buat alert occurrence baru atau reopen berdasarkan policy.

---

### 12. Alert Severity

Severity standar:

```text
SEV0
SEV1
SEV2
SEV3
SEV4
```

---

### 13. Severity Definitions

#### SEV0 — Catastrophic

Kondisi:

- platform luas tidak tersedia;
- risiko keselamatan/kepatuhan kritis;
- compromise keamanan aktif skala besar;
- kehilangan data kritis;
- seluruh tenant terdampak.

Response:

- immediate;
- incident commander wajib;
- executive escalation;
- security/legal/compliance dapat terlibat;
- continuous coordination.

#### SEV1 — Critical

Kondisi:

- layanan inti tidak tersedia;
- banyak tenant terdampak;
- fungsi bisnis kritis berhenti;
- security control kritis gagal;
- risiko data tinggi.

Response:

- immediate;
- on-call escalation;
- incident wajib dibuat;
- status update berkala.

#### SEV2 — Major

Kondisi:

- layanan degraded signifikan;
- satu tenant besar atau beberapa tenant terdampak;
- workaround terbatas;
- backlog meningkat cepat;
- integration penting gagal.

Response:

- urgent;
- incident biasanya dibuat;
- owner wajib acknowledge.

#### SEV3 — Minor

Kondisi:

- dampak terbatas;
- fitur non-kritis terganggu;
- workaround tersedia;
- tidak ada risiko langsung.

Response:

- business-hours atau on-call sesuai policy;
- incident optional.

#### SEV4 — Informational

Kondisi:

- awareness;
- maintenance reminder;
- capacity warning dini;
- non-actionable notification yang masih penting.

Response:

- tidak paging secara default;
- tampil pada dashboard/report.

---

### 14. Severity Determination

Severity ditentukan berdasarkan:

```text
Impact
Urgency
Scope
Criticality
Data Risk
Security Risk
Compliance Risk
Workaround
Duration
```

---

### 15. Impact Levels

```text
GLOBAL
MULTI_TENANT
TENANT
BUSINESS_ENTITY
MODULE
COMPONENT
USER_SEGMENT
SINGLE_OPERATION
```

---

### 16. Urgency Levels

```text
IMMEDIATE
URGENT
HIGH
NORMAL
LOW
```

---

### 17. Severity Matrix

Contoh:

| Impact | Urgency | Severity |
|---|---|---|
| Global | Immediate | SEV0 |
| Multi-tenant | Immediate | SEV1 |
| Tenant critical | Urgent | SEV1/SEV2 |
| Module important | High | SEV2 |
| Component optional | Normal | SEV3 |
| Informational | Low | SEV4 |

Final severity dapat di-override oleh policy, tetapi override wajib diaudit.

---

### 18. Alert Fingerprint

Fingerprint digunakan untuk deduplication.

Input rekomendasi:

```text
rule_code
environment
tenant_id
scope_id
module_code
component
normalized dimensions
```

Contoh:

```text
sha256(
  rule_code
  + environment
  + tenant
  + component
)
```

Jangan memasukkan:

- timestamp;
- request ID;
- random UUID;
- raw error message;
- patient/user identity.

---

### 19. Alert Occurrence

Satu alert dapat memiliki banyak occurrence.

Field:

```text
first_seen_at
last_seen_at
occurrence_count
current_value
peak_value
```

Tujuan:

- menghindari alert duplikat;
- menunjukkan frekuensi;
- mempertahankan context.

---

### 20. Alert Group

Alert Group mengelompokkan alert terkait.

Grouping key dapat berdasarkan:

```text
incident candidate
service
dependency
tenant
module
deployment
region
time window
```

Contoh:

```text
database DOWN
queue backlog
workflow timeout
integration failure
```

dapat dikelompokkan menjadi:

```text
Database Outage Group
```

---

### 21. Dependency Awareness

Jika dependency kritis DOWN:

```text
database = DOWN
```

alert turunan dapat:

- tetap dicatat;
- disuppress untuk notification;
- ditautkan sebagai symptom;
- tidak membuat incident terpisah.

---

### 22. Alert Owner

Setiap alert wajib memiliki owner.

Owner types:

```text
TEAM
ROLE
USER
SERVICE_OWNER
MODULE_OWNER
TENANT_OWNER
ON_CALL_ROTATION
```

Rekomendasi utama:

```text
TEAM atau ON_CALL_ROTATION
```

Jangan bergantung pada satu user permanen.

---

### 23. Ownership Resolution

Urutan:

```text
rule owner
→ component owner
→ module owner
→ service owner
→ platform operations fallback
```

Jika tidak ada owner:

```text
configuration_error
```

dan alert diarahkan ke Platform Operations.

---

### 24. Ownership Matrix

| Domain | Owner |
|---|---|
| Database | Platform/DBA |
| Queue | Platform Operations |
| Scheduler | Platform Operations |
| Workflow | Workflow Team |
| Event Bus | Platform Kernel Team |
| Notification | Communication Team |
| Integration | Integration Team |
| Search | Search/Data Team |
| IAM/RBAC/Scope | IAM Team |
| Security | Security Team |
| Tenant | Tenant Operations |
| Module | Module Owner |

---

### 25. Acknowledgement

Acknowledgement berarti:

- alert telah dilihat;
- owner menerima tanggung jawab;
- investigation dimulai atau dijadwalkan.

Acknowledgement bukan resolution.

Field:

```text
acknowledged_by
acknowledged_at
acknowledgement_note
```

---

### 26. Alert Response Targets

Contoh awal:

| Severity | Ack Target |
|---|---:|
| SEV0 | 5 menit |
| SEV1 | 10 menit |
| SEV2 | 30 menit |
| SEV3 | 4 jam kerja |
| SEV4 | tidak wajib |

Target final harus configurable.

---

### 27. Incident Definition

Incident adalah record koordinasi untuk gangguan yang membutuhkan tindakan terstruktur.

Incident dapat berasal dari:

- satu alert kritis;
- beberapa alert terkait;
- laporan user;
- security report;
- deployment failure;
- manual operator action.

---

### 28. Incident Fields

| Field | Keterangan |
|---|---|
| incident_id | identifier |
| title | ringkasan |
| description | dampak |
| severity | SEV0–SEV4 |
| state | lifecycle |
| environment | environment |
| tenant/scope | konteks |
| commander | incident commander |
| owner_team | owner |
| affected_services | layanan |
| affected_tenants | tenant |
| started_at | awal |
| detected_at | waktu deteksi |
| acknowledged_at | waktu ack |
| mitigated_at | mitigasi |
| resolved_at | recovery |
| closed_at | penutupan |
| root_cause | setelah diketahui |
| runbook | referensi |
| postmortem_required | bool |

---

### 29. Incident States

```text
DECLARED
INVESTIGATING
IDENTIFIED
MITIGATING
MONITORING
RESOLVED
CLOSED
CANCELLED
```

---

### 30. Incident Lifecycle

```text
DECLARED
   ↓
INVESTIGATING
   ↓
IDENTIFIED
   ↓
MITIGATING
   ↓
MONITORING
   ↓
RESOLVED
   ↓
CLOSED
```

Optional:

```text
DECLARED → CANCELLED
```

jika ternyata false positive atau duplicate.

---

### 31. State Definitions

#### DECLARED

Incident resmi dibuat.

#### INVESTIGATING

Tim mencari penyebab dan dampak.

#### IDENTIFIED

Penyebab utama atau area masalah telah diketahui.

#### MITIGATING

Tindakan mengurangi dampak sedang dilakukan.

#### MONITORING

Mitigasi telah diterapkan dan hasil dipantau.

#### RESOLVED

Layanan telah pulih.

#### CLOSED

Dokumentasi dan tindak lanjut minimum selesai.

#### CANCELLED

Incident tidak valid atau duplicate.

---

### 32. Incident Commander

SEV0 dan SEV1 wajib memiliki Incident Commander.

Tanggung jawab:

- mengoordinasikan response;
- menetapkan prioritas;
- memastikan komunikasi;
- memastikan timeline;
- mengelola escalation;
- memisahkan koordinasi dari technical investigation.

Incident Commander tidak harus menjadi technical lead.

---

### 33. Incident Roles

```text
Incident Commander
Technical Lead
Communications Lead
Operations Lead
Security Lead
Scribe
Subject Matter Expert
```

Role dapat dirangkap untuk incident kecil.

---

### 34. Incident Ownership

Incident wajib memiliki:

- owner team;
- incident commander;
- technical lead;
- escalation contact.

Jika tenant-specific:

- tenant owner;
- platform owner;
- module owner bila relevan.

---

### 35. Incident Severity

Incident severity menggunakan skala yang sama dengan alert.

Namun severity incident dapat lebih tinggi atau lebih rendah dari alert berdasarkan dampak aktual.

Contoh:

```text
Alert SEV2
Investigasi menemukan data risk luas
Incident dinaikkan menjadi SEV1
```

---

### 36. Incident Declaration Criteria

Incident wajib dibuat bila:

- alert SEV0;
- alert SEV1;
- multiple related SEV2;
- security control kritis gagal;
- data loss suspected;
- compliance impact suspected;
- multi-tenant impact;
- outage melewati duration threshold;
- executive/customer communication diperlukan.

---

### 37. Incident Timeline

Timeline mencatat:

```text
incident declared
owner assigned
severity changed
alert linked
investigation note
root cause hypothesis
mitigation started
deployment/rollback
service recovered
incident resolved
incident closed
```

Timeline harus append-only secara logis.

---

### 38. Timeline Event Fields

```text
event_id
incident_id
event_type
actor_type
actor_id
message
metadata_safe
occurred_at
created_at
```

---

### 39. Incident Communication

Communication audiences:

```text
internal operations
security
executive
tenant/customer
regulator/compliance
public status page
```

Pesan harus disesuaikan audience.

Jangan mengirim detail teknis sensitif ke semua audience.

---

### 40. Status Update Cadence

Contoh:

| Severity | Update |
|---|---:|
| SEV0 | 15 menit |
| SEV1 | 30 menit |
| SEV2 | 60 menit |
| SEV3 | sesuai kebutuhan |
| SEV4 | tidak wajib |

---

### 41. Runbook

Alert dan incident dapat memiliki runbook.

Runbook minimum:

```text
Purpose
Symptoms
Dependencies
Verification
Immediate Actions
Mitigation
Rollback
Recovery Validation
Escalation
Known Risks
```

---

### 42. Runbook Ownership

Runbook wajib memiliki:

- owner;
- reviewer;
- last reviewed date;
- version;
- related components;
- test status.

Runbook obsolete harus ditandai.

---

### 43. Recovery Verification

Recovery dapat diverifikasi melalui:

- health kembali UP;
- metric kembali normal;
- alert clear condition;
- synthetic check;
- transaction test;
- operator verification;
- tenant confirmation bila diperlukan.

---

### 44. Incident Resolution

Incident dapat `RESOLVED` bila:

- layanan pulih;
- dampak berhenti;
- monitoring stabil;
- workaround/mitigation valid;
- owner menyetujui.

Incident belum `CLOSED` sebelum:

- timeline minimum lengkap;
- follow-up dicatat;
- postmortem decision dibuat;
- evidence tersimpan.

---

### 45. Postmortem Requirement

Postmortem wajib untuk:

- SEV0;
- SEV1;
- data loss;
- security incident signifikan;
- compliance incident;
- repeated SEV2;
- incident dengan response failure;
- customer impact besar.

---

### 46. Blameless Principle

Postmortem fokus pada:

- system;
- process;
- control;
- detection;
- response;
- recovery.

Bukan menyalahkan individu.

---

### 47. Tenant Context

Alert/incident tenant-specific wajib memiliki:

```text
tenant_id
scope_id
business_entity_id optional
```

Global incident dapat memiliki daftar tenant terdampak.

Jangan membuat satu alert per tenant bila agregasi lebih tepat, kecuali isolation membutuhkan.

---

### 48. Multi-Tenant Isolation

Tenant admin hanya dapat melihat:

- alert tenant sendiri;
- incident tenant sendiri;
- summary yang diizinkan.

Platform admin dapat lintas tenant sesuai permission.

Security incident dapat memiliki visibility lebih ketat.

---

### 49. Data Classification

Alert dan incident diklasifikasikan:

```text
INTERNAL
CONFIDENTIAL
RESTRICTED
SECURITY_RESTRICTED
```

Contoh:

| Data | Klasifikasi |
|---|---|
| queue backlog | INTERNAL |
| tenant outage | CONFIDENTIAL |
| data exposure suspected | RESTRICTED |
| credential compromise | SECURITY_RESTRICTED |

---

### 50. Access Policy

Permission awal:

```text
observability.alert.read
observability.alert.acknowledge
observability.alert.suppress
observability.alert.resolve
observability.alert.manage
observability.incident.read
observability.incident.create
observability.incident.assign
observability.incident.update
observability.incident.resolve
observability.incident.close
observability.incident.security.read
observability.incident.cross_tenant.read
observability.incident.postmortem.manage
```

---

### 51. Role Matrix

| Role | Akses |
|---|---|
| Platform Admin | seluruh alert dan incident |
| Operations Admin | operational alert/incident |
| Security Admin | security alert/incident |
| Tenant Admin | tenant sendiri |
| Module Owner | module terkait |
| Support | read/ack terbatas |
| Executive | summary incident |
| End User | tidak ada akses teknis |

---

### 52. Audit Policy

Wajib audit:

- acknowledge;
- suppress;
- severity change;
- owner change;
- incident declaration;
- assignment;
- resolve;
- close;
- postmortem update;
- cross-tenant access;
- security incident access;
- rule change;
- maintenance suppression.

---

### 53. Alert vs Audit

Alert adalah operational signal.

Audit adalah immutable record aktivitas penting.

Contoh:

```text
Alert acknowledged
```

menghasilkan audit event.

Tetapi setiap metric evaluation tidak perlu menjadi audit.

---

### 54. Alert vs Notification

Alert adalah domain state.

Notification adalah delivery channel.

Satu alert dapat menghasilkan:

- dashboard badge;
- email;
- SMS;
- WhatsApp;
- push;
- Teams/Slack;
- paging.

Kegagalan notification tidak menghapus alert.

---

### 55. Alert vs Incident

| Alert | Incident |
|---|---|
| sinyal | proses koordinasi |
| dapat otomatis | dapat otomatis/manual |
| banyak occurrence | satu lifecycle terkelola |
| dapat tanpa manusia | membutuhkan ownership |
| dapat resolved otomatis | closure terkontrol |
| threshold/state driven | impact/response driven |

---

### 56. Alert Routing Overview

Routing mempertimbangkan:

```text
severity
owner
environment
tenant
module
component
time of day
on-call
data classification
channel availability
```

Detail routing dibahas pada Part 2 dan Part 4.

---

### 57. Escalation Overview

Escalation dipicu bila:

- belum acknowledged;
- severity meningkat;
- duration melewati target;
- notification gagal;
- owner unavailable;
- impact meluas;
- incident update terlambat.

---

### 58. Maintenance Window

Alert dapat disuppress selama maintenance yang disetujui.

Maintenance window wajib memiliki:

```text
start
end
scope
reason
owner
approved_by
affected_rules
```

Alert tetap dapat dicatat tetapi notification disuppress sesuai policy.

---

### 59. Manual Alert

Manual alert diperbolehkan untuk:

- user report;
- external provider issue;
- suspected security issue;
- operational observation.

Manual alert wajib memiliki:

- creator;
- reason;
- severity;
- owner;
- evidence/reference.

---

### 60. False Positive

Alert false positive harus ditandai.

Data ini digunakan untuk:

- rule tuning;
- noise reduction;
- threshold review;
- post-incident analysis.

---

### 61. False Negative

False negative adalah kondisi nyata yang tidak menghasilkan alert.

Harus dicatat saat incident ditemukan melalui:

- user complaint;
- manual observation;
- external report.

False negative menunjukkan detection gap.

---

### 62. Alert Quality Metrics

```text
alert_total
alert_firing_total
alert_acknowledged_total
alert_resolved_total
alert_suppressed_total
alert_false_positive_total
alert_unowned_total
alert_ack_time_seconds
alert_resolution_time_seconds
incident_created_total
incident_mttr_seconds
```

---

### 63. MTTA

Mean Time To Acknowledge:

```text
MTTA =
average(acknowledged_at - triggered_at)
```

---

### 64. MTTD

Mean Time To Detect:

```text
MTTD =
average(detected_at - actual_start_at)
```

Actual start dapat unknown.

---

### 65. MTTR

Mean Time To Resolve/Recover:

```text
MTTR =
average(resolved_at - started_at)
```

Definisi harus konsisten apakah Resolve atau Recover.

---

### 66. Alert Fatigue Indicators

```text
alerts_per_operator
duplicate_rate
suppression_rate
false_positive_rate
unacknowledged_rate
after_hours_alert_rate
```

---

### 67. Dashboard Integration

Dashboard minimum menampilkan:

- active alert;
- alert by severity;
- unacknowledged alert;
- suppressed alert;
- active incident;
- incident by severity;
- MTTA;
- MTTR;
- recent recovery;
- alert trend.

---

### 68. Health Integration

Health status transition dapat menghasilkan alert:

```text
UP → DEGRADED
UP → DOWN
DEGRADED → DOWN
UNKNOWN prolonged
```

Recovery:

```text
DOWN → UP
DEGRADED → UP
```

---

### 69. Metric Integration

Metric threshold dapat menghasilkan alert setelah:

- minimum samples;
- evaluation window;
- hysteresis;
- cooldown;
- deduplication.

---

### 70. Log Integration

Log-based alert harus memakai:

- normalized event code;
- occurrence rate;
- bounded window;
- sensitive data sanitization.

Jangan membuat alert dari raw message bebas tanpa normalization.

---

### 71. Trace Integration

Trace alert dapat berdasarkan:

- latency;
- error span rate;
- dependency failure;
- critical path degradation.

Trace ID contoh dapat disimpan terbatas untuk diagnostic, bukan pada public alert.

---

### 72. Security Signal Integration

Security alert membutuhkan:

- restricted classification;
- separate routing;
- limited visibility;
- evidence protection;
- dedicated audit.

---

### 73. Business Operational Signal

Contoh:

- claim backlog;
- order processing stuck;
- appointment sync failure;
- workflow approval overdue.

Business operational alert harus tetap terkait owner dan runbook.

---

### 74. Alert Lifecycle Example

```text
10:00 error rate meningkat
10:02 status PENDING
10:05 threshold duration terpenuhi
10:05 alert FIRING
10:07 owner menerima notification
10:09 alert ACKNOWLEDGED
10:15 incident dibuat
10:40 mitigation diterapkan
10:50 metric normal
10:55 alert RESOLVED
11:30 incident RESOLVED
14:00 incident CLOSED
```

---

### 75. Incident Lifecycle Example

```text
Alert database DOWN
→ Incident SEV1 declared
→ Commander assigned
→ Investigation
→ Root cause: disk full
→ Mitigation: free space + restart
→ Monitoring
→ Recovery verified
→ Resolved
→ Postmortem required
→ Closed
```

---

### 76. Anti-Pattern

Hindari:

- alert tanpa owner;
- semua alert memakai SEV1;
- alert langsung closed tanpa recovery;
- incident dibuat untuk setiap warning;
- notification dianggap sama dengan alert;
- suppression tanpa expiry;
- manual severity downgrade tanpa audit;
- raw PHI dalam alert;
- satu alert per request error;
- dependency symptoms membuat incident terpisah;
- postmortem menyalahkan individu;
- incident timeline dapat dihapus.

---

### 77. UAT Part 1

#### Alert Model

- [ ] Alert memiliki identifier unik.
- [ ] Alert memiliki source.
- [ ] Alert memiliki severity.
- [ ] Alert memiliki owner.
- [ ] Alert memiliki tenant/scope context bila relevan.
- [ ] Fingerprint stabil.
- [ ] Occurrence terhitung.

#### Lifecycle

- [ ] PENDING dapat menjadi FIRING.
- [ ] FIRING dapat di-acknowledge.
- [ ] Alert dapat disuppress sesuai policy.
- [ ] Recovery menghasilkan RESOLVED.
- [ ] Transition invalid ditolak.
- [ ] Closure tidak menghapus history.

#### Severity

- [ ] SEV0–SEV4 tersedia.
- [ ] Impact dan urgency memengaruhi severity.
- [ ] Override diaudit.
- [ ] Tenant impact dipertimbangkan.
- [ ] Security/data risk dipertimbangkan.

#### Ownership

- [ ] Setiap alert memiliki owner.
- [ ] Fallback owner tersedia.
- [ ] Unowned alert dianggap configuration defect.
- [ ] Incident commander wajib untuk SEV0/SEV1.
- [ ] Role incident dapat ditetapkan.

#### Incident

- [ ] Incident dapat dibuat dari alert.
- [ ] Incident dapat dibuat manual.
- [ ] Incident memiliki lifecycle.
- [ ] Timeline tercatat.
- [ ] Recovery diverifikasi.
- [ ] Postmortem policy diterapkan.

#### Security

- [ ] Tenant isolation bekerja.
- [ ] Security incident visibility dibatasi.
- [ ] Tidak ada PHI/PII/secret pada alert umum.
- [ ] Cross-tenant access diaudit.
- [ ] Suppression dan severity change diaudit.

---

### 78. Definition of Done Part 1

Part 1 dianggap selesai bila:

- [ ] vision dan problem statement disepakati;
- [ ] alert definition tersedia;
- [ ] alert source types tersedia;
- [ ] alert states tersedia;
- [ ] severity SEV0–SEV4 tersedia;
- [ ] severity matrix tersedia;
- [ ] fingerprint concept tersedia;
- [ ] grouping concept tersedia;
- [ ] dependency awareness tersedia;
- [ ] ownership model tersedia;
- [ ] acknowledgement tersedia;
- [ ] incident definition tersedia;
- [ ] incident lifecycle tersedia;
- [ ] incident roles tersedia;
- [ ] timeline tersedia;
- [ ] recovery verification tersedia;
- [ ] postmortem policy tersedia;
- [ ] access policy tersedia;
- [ ] audit policy tersedia;
- [ ] integration overview tersedia;
- [ ] UAT tersedia.

---

### 79. Rencana Part Berikutnya

#### Part 2

Alert Rules, threshold evaluation, deduplication, grouping, suppression, maintenance window, routing, escalation, cooldown, flapping control, dan recovery policy.

#### Part 3

Incident management, assignment, timeline, runbook, communication, SLA, postmortem, root cause, action item, dan reporting.

#### Part 4

Notification channels, on-call, routing adapters, HTTP API, security middleware, database schema, audit integration, dan Apache/XAMPP routing.

#### Part 5

Reference implementation, deployment, incident simulations, final UAT, Definition of Done, roadmap, dan merge guidance.

---

## Bagian II — Alert Rules, Evaluation, Deduplication, Grouping, Suppression, Routing & Escalation

### 1. Executive Summary

Part 2 mendefinisikan mekanisme bagaimana signal observability diubah menjadi alert yang actionable.

Bagian ini menetapkan standar untuk:

- AlertRule;
- evaluation window;
- threshold dan state evaluation;
- anomaly detection boundary;
- pending duration;
- minimum samples;
- hysteresis;
- cooldown;
- deduplication;
- grouping;
- dependency awareness;
- suppression;
- maintenance window;
- routing;
- escalation;
- retry;
- flapping control;
- recovery;
- silence dan mute;
- telemetry;
- UAT.

Tujuan utamanya adalah menghasilkan alert yang:

- akurat;
- tidak duplikat;
- memiliki owner;
- memiliki severity yang benar;
- tidak menimbulkan alert fatigue;
- dapat dipulihkan secara otomatis maupun manual;
- tetap aman untuk multi-tenant platform.

---

### 2. Alert Processing Pipeline

```text
Signal
  ↓
Normalize
  ↓
Validate Rule
  ↓
Evaluate
  ↓
Pending Window
  ↓
Fingerprint
  ↓
Deduplicate
  ↓
Group
  ↓
Suppress / Silence / Maintenance
  ↓
Resolve Owner
  ↓
Route
  ↓
Escalate
  ↓
Recover
```

Setiap tahap harus dapat diamati dan diuji secara terpisah.

---

### 3. Alert Rule Definition

AlertRule mendeskripsikan kondisi yang menghasilkan alert.

Field minimum:

| Field | Keterangan |
|---|---|
| code | identifier stabil |
| title | judul rule |
| description | tujuan rule |
| source_type | metric/health/log/trace/security/business |
| source_reference | metric/event/state |
| expression | kondisi evaluasi |
| evaluation_window | window |
| evaluation_interval | interval |
| pending_duration | durasi sebelum firing |
| minimum_samples | minimum sample |
| severity | default severity |
| owner | default owner |
| fingerprint_fields | deduplication fields |
| grouping_fields | grouping fields |
| cooldown | cooldown |
| hysteresis | recovery boundary |
| runbook | runbook reference |
| enabled | status |
| version | versi rule |

---

### 4. Alert Rule Example

```php
return [
    'code' => 'http_error_rate_high',
    'title' => 'HTTP Error Rate High',
    'source_type' => 'METRIC',
    'source_reference' => 'platform_error_rate',
    'expression' => [
        'comparison' => 'greater_than_or_equal',
        'warning' => 1.0,
        'critical' => 5.0,
    ],
    'evaluation_window' => '5m',
    'evaluation_interval' => '1m',
    'pending_duration' => '5m',
    'minimum_samples' => 100,
    'severity' => 'SEV2',
    'owner' => 'platform_operations',
    'fingerprint_fields' => [
        'rule_code',
        'environment',
        'tenant_id',
        'module_code',
    ],
    'grouping_fields' => [
        'service',
        'dependency',
    ],
    'cooldown' => '10m',
    'runbook' => 'runbook://platform/http-error-rate',
    'enabled' => true,
    'version' => '1.0',
];
```

---

### 5. Rule Types

Supported rule types:

```text
THRESHOLD
STATE
RATE
RATIO
ABSENCE
STALE
PATTERN
COMPOSITE
ANOMALY
MANUAL
EXTERNAL
```

---

### 6. Threshold Rule

Threshold rule membandingkan value dengan batas tertentu.

Contoh:

```text
queue_pending_jobs >= 1000
storage_usage_percent >= 90
p95_latency_ms >= 1000
```

Supported comparison:

```text
greater_than
greater_than_or_equal
less_than
less_than_or_equal
equal
not_equal
inside_range
outside_range
```

---

### 7. State Rule

State rule digunakan untuk health atau finite state.

Contoh:

```text
database_status == DOWN
scheduler_status == UNKNOWN for 10m
integration_status == DEGRADED
```

---

### 8. Rate Rule

Rate rule mengevaluasi laju perubahan atau event.

Contoh:

```text
failed_login_rate > 50/min
queue_failure_rate > 5%
notification_retry_rate > threshold
```

---

### 9. Ratio Rule

Formula:

```text
numerator / denominator
```

Contoh:

```text
error_total / request_total
failed_job_total / processed_job_total
cache_miss_total / cache_request_total
```

Denominator nol menghasilkan:

```text
INSUFFICIENT_DATA
```

bukan otomatis alert.

---

### 10. Absence Rule

Absence rule mendeteksi tidak adanya expected event.

Contoh:

```text
scheduler heartbeat tidak terlihat selama 5 menit
backup completion event tidak ada dalam 24 jam
outbox worker tidak memproses event selama 10 menit
```

---

### 11. Stale Rule

Stale rule mengevaluasi umur data.

```text
now - last_seen_at >= stale_threshold
```

Contoh:

```text
health result stale 5 menit
integration sync stale 1 jam
credential rotation status stale 7 hari
```

---

### 12. Pattern Rule

Pattern rule menggunakan normalized event code, bukan raw free-text.

Contoh:

```text
event_code = DB_CONNECTION_TIMEOUT
count >= 20 within 5m
```

Jangan membuat rule berdasarkan regex bebas terhadap raw log tanpa governance.

---

### 13. Composite Rule

Composite rule menggabungkan beberapa kondisi.

Contoh:

```text
database_latency_high
AND
database_connection_usage_high
```

atau:

```text
queue_backlog_high
AND
worker_active_total == 0
```

Composite rule harus dibatasi untuk mencegah kompleksitas berlebihan.

---

### 14. Anomaly Rule

Anomaly detection dapat digunakan sebagai supplementary signal.

Rule anomaly wajib memiliki:

- baseline;
- confidence;
- minimum data;
- seasonality policy;
- fallback threshold;
- owner;
- false-positive review.

Anomaly detection tidak boleh menjadi satu-satunya dasar SEV0/SEV1 tanpa validasi tambahan.

---

### 15. Rule Evaluation Interval

Rekomendasi awal:

| Signal | Interval |
|---|---:|
| Health critical | 15–30 detik |
| HTTP error rate | 1 menit |
| Queue backlog | 1 menit |
| Scheduler heartbeat | 1 menit |
| Storage usage | 5 menit |
| SLA/SLO | 5–15 menit |
| Capacity trend | 15–60 menit |

Interval harus seimbang antara:

- detection speed;
- cost;
- noise;
- source freshness.

---

### 16. Evaluation Window

Window standar:

```text
1m
5m
10m
15m
30m
1h
6h
24h
```

Rule wajib menyatakan window eksplisit.

---

### 17. Pending Duration

Pending duration mencegah transient spike langsung menjadi FIRING.

Contoh:

```text
condition true selama 5 menit
```

Flow:

```text
NORMAL
→ PENDING
→ FIRING
```

Jika kondisi clear saat pending:

```text
PENDING → NORMAL
```

---

### 18. Minimum Samples

Rate/ratio rule wajib memiliki minimum samples.

Contoh:

```text
error rate 50%
total requests 2
```

Tidak cukup untuk alert kritis.

Rule:

```text
minimum_samples = 100
```

---

### 19. Hysteresis

Trigger dan recovery boundary harus berbeda.

Contoh:

```text
trigger warning >= 1%
recover < 0.5%
```

Tujuan:

- mencegah flapping;
- mengurangi reopen berulang;
- menjaga stability.

---

### 20. Cooldown

Cooldown mencegah notification berulang terlalu cepat.

Contoh:

```text
cooldown = 10m
```

Cooldown tidak menghentikan occurrence counter.

Alert tetap menerima update state/value.

---

### 21. Repeat Notification

Repeat notification hanya untuk alert yang belum selesai.

Contoh:

| Severity | Repeat |
|---|---:|
| SEV0 | 5–10 menit |
| SEV1 | 15 menit |
| SEV2 | 30–60 menit |
| SEV3 | 4 jam |
| SEV4 | tidak repeat |

Final cadence configurable.

---

### 22. Alert Fingerprint

Fingerprint dibangun dari normalized fields.

```php
final class AlertFingerprint
{
    public static function from(
        AlertRule $rule,
        AlertSignal $signal
    ): string {
        $payload = [
            'rule_code' => $rule->code,
            'environment' => $signal->environment,
            'tenant_id' => $signal->tenantId,
            'scope_id' => $signal->scopeId,
            'module_code' => $signal->moduleCode,
            'component' => $signal->component,
        ];

        return hash(
            'sha256',
            json_encode($payload, JSON_THROW_ON_ERROR)
        );
    }
}
```

---

### 23. Fingerprint Rules

Fingerprint harus:

- stabil;
- deterministic;
- scope-aware;
- tenant-aware;
- bebas data sensitif;
- tidak memakai timestamp;
- tidak memakai random identifier.

---

### 24. Deduplication

Jika alert FIRING dengan fingerprint sama sudah ada:

- update last_seen_at;
- increment occurrence_count;
- update current_value;
- update peak_value;
- jangan membuat alert baru;
- jangan kirim notification baru sebelum policy mengizinkan.

---

### 25. Deduplication Window

Deduplication window menentukan berapa lama occurrence dianggap alert yang sama.

Contoh:

```text
10m
30m
1h
24h
```

Rule-specific.

---

### 26. Reopen Policy

Jika alert RESOLVED lalu kondisi muncul kembali:

Pilihan:

```text
REOPEN_EXISTING
CREATE_NEW
CREATE_NEW_AFTER_WINDOW
```

Rekomendasi:

- transient operational alert: reopen within short window;
- compliance/security incident: create new occurrence/record;
- repeated issue: create new alert dan link previous.

---

### 27. Grouping

Grouping menyatukan alert terkait pada satu operational group.

Grouping fields:

```text
service
component
dependency
tenant
module
deployment
region
incident_candidate
```

---

### 28. Grouping Example

```text
DB latency high
DB connection saturation
HTTP latency high
Queue backlog high
```

Group:

```text
database-degradation:production
```

---

### 29. Group Severity

Group severity:

```text
max member severity
```

atau policy khusus.

Contoh:

- dua SEV2 pada critical dependency dapat menaikkan group menjadi SEV1;
- banyak SEV3 tenant-specific tidak otomatis global SEV1.

---

### 30. Group Lifecycle

```text
OPEN
ACKNOWLEDGED
MITIGATING
RESOLVED
CLOSED
```

Alert member dapat resolve pada waktu berbeda.

Group ditutup setelah seluruh critical member resolved atau incident ditutup.

---

### 31. Dependency Graph

Dependency graph dapat digunakan untuk:

- root alert selection;
- symptom suppression;
- grouping;
- impact analysis;
- routing.

Contoh:

```text
API
 ├── Database
 ├── Queue
 └── External Payment
```

Jika Database DOWN, API latency alert dapat ditandai sebagai symptom.

---

### 32. Root vs Symptom Alert

Alert dapat diberi role:

```text
ROOT
SYMPTOM
CORRELATED
UNKNOWN
```

Only root alert biasanya melakukan paging utama.

Symptom tetap tercatat untuk observability.

---

### 33. Suppression

Suppression adalah keputusan untuk tidak meneruskan alert ke notification tertentu.

Alert tetap tersimpan.

Suppression types:

```text
DEPENDENCY
MAINTENANCE
DUPLICATE
MUTE
POLICY
MANUAL
```

---

### 34. Suppression Fields

```text
suppression_id
type
reason
start_at
end_at
scope
rule_codes
created_by
approved_by
created_at
```

Suppression tanpa expiry tidak diperbolehkan kecuali system policy eksplisit.

---

### 35. Silence

Silence adalah mute sementara berdasarkan matcher.

Contoh:

```text
environment=staging
component=integration-x
severity<=SEV3
```

Silence harus:

- bounded;
- memiliki reason;
- memiliki owner;
- memiliki expiry;
- diaudit.

---

### 36. Maintenance Window

Maintenance window adalah suppression terencana.

Field:

```text
code
title
start_at
end_at
environment
tenant_id
scope_id
module_code
component
rule_codes
owner
approved_by
reason
```

---

### 37. Maintenance Behavior

Selama maintenance:

- alert dapat tetap dievaluasi;
- occurrence dapat tetap dicatat;
- notification dapat disuppress;
- dashboard menunjukkan maintenance;
- severe unexpected condition dapat bypass suppression jika policy mengizinkan.

---

### 38. Suppression Precedence

Urutan rekomendasi:

```text
security override
→ emergency bypass
→ maintenance
→ dependency suppression
→ duplicate suppression
→ manual silence
→ normal routing
```

---

### 39. Suppression Safety

Tidak boleh menyuppress:

- SEV0 security incident;
- suspected data breach;
- confirmed data loss;
- life-safety risk;
- compliance-mandated notification;

kecuali policy khusus dan approval yang sesuai.

---

### 40. Routing

Routing menentukan tujuan alert.

Routing factors:

```text
severity
owner
environment
tenant
scope
module
component
time
classification
channel health
on-call schedule
```

---

### 41. Route Definition

Field minimum:

```text
code
matchers
owner
channels
escalation_policy
active_hours
fallback_route
priority
enabled
```

---

### 42. Route Example

```php
return [
    'code' => 'platform_database_critical',
    'matchers' => [
        'environment' => 'production',
        'component' => 'database',
        'severity' => ['SEV0', 'SEV1'],
    ],
    'owner' => 'platform_dba_oncall',
    'channels' => [
        'pager',
        'sms',
        'teams',
    ],
    'escalation_policy' => 'critical_platform',
    'fallback_route' => 'platform_operations',
    'priority' => 10,
    'enabled' => true,
];
```

---

### 43. Route Matching

Route matching harus deterministic.

Urutan:

```text
highest specificity
→ highest priority
→ explicit fallback
```

Duplicate/conflicting route harus gagal validation.

---

### 44. Channel Types

```text
DASHBOARD
EMAIL
SMS
PUSH
WHATSAPP
TEAMS
SLACK
PAGER
WEBHOOK
TICKET
```

Detail adapter dibahas pada Part 4.

---

### 45. Channel Selection

Contoh:

| Severity | Channel |
|---|---|
| SEV0 | pager + SMS + chat + email |
| SEV1 | pager + chat + email |
| SEV2 | chat + email |
| SEV3 | dashboard + email |
| SEV4 | dashboard/report |

---

### 46. Fallback Channel

Jika channel utama gagal:

```text
pager → SMS → phone escalation
chat → email
webhook → ticket
```

Notification failure tidak menghapus alert.

---

### 47. Escalation Policy

Escalation policy menentukan langkah jika alert belum ditangani.

Field:

```text
code
steps
ack_deadline
repeat
fallback_owner
maximum_level
```

---

### 48. Escalation Step

```text
level
delay
target
channels
condition
```

Contoh:

```text
Level 1: on-call engineer, immediately
Level 2: team lead, after 10 minutes
Level 3: operations manager, after 20 minutes
Level 4: executive/security, based on severity
```

---

### 49. Escalation Triggers

Escalation dipicu bila:

- belum acknowledged;
- severity naik;
- impact meluas;
- notification gagal;
- owner tidak tersedia;
- alert duration melewati batas;
- incident update terlambat;
- repeat occurrence tinggi.

---

### 50. Escalation Stop Conditions

Escalation berhenti bila:

- alert acknowledged;
- alert resolved;
- incident commander mengambil alih;
- approved suppression aktif;
- alert dinyatakan false positive.

---

### 51. Ack Deadline

Contoh:

| Severity | Deadline |
|---|---:|
| SEV0 | 5 menit |
| SEV1 | 10 menit |
| SEV2 | 30 menit |
| SEV3 | 4 jam kerja |
| SEV4 | optional |

---

### 52. Auto-Incident Policy

Incident dapat dibuat otomatis bila:

```text
severity in [SEV0, SEV1]
OR
grouped SEV2 count >= threshold
OR
alert duration >= threshold
OR
security/data-risk rule
```

Auto-incident harus:

- memiliki owner;
- memiliki initial severity;
- link alert;
- mencatat creation source;
- diaudit.

---

### 53. Flapping

Flapping adalah perubahan state berulang:

```text
FIRING ↔ RESOLVED
```

dalam waktu singkat.

---

### 54. Flapping Detection

Contoh:

```text
state transitions >= 4 within 15m
```

Status alert:

```text
FLAPPING
```

atau flag:

```text
is_flapping = true
```

---

### 55. Flapping Control

Strategi:

- hysteresis;
- longer pending;
- longer recovery;
- cooldown;
- transition count threshold;
- notification suppression;
- rule tuning review.

---

### 56. Recovery Condition

Recovery harus eksplisit.

Contoh:

```text
error rate < 0.5% selama 5 menit
database status == UP selama 3 probes
queue backlog < 100 selama 10 menit
```

---

### 57. Recovery Types

```text
AUTOMATIC
MANUAL
HYBRID
```

#### Automatic

Source kembali normal.

#### Manual

Operator memverifikasi.

#### Hybrid

Signal normal dan operator confirmation diperlukan.

---

### 58. Recovery Verification Window

Recovery tidak langsung setelah satu sample normal.

Contoh:

```text
3 consecutive healthy evaluations
```

atau:

```text
healthy for 5 minutes
```

---

### 59. Resolve vs Close

```text
RESOLVED
```

berarti kondisi sudah pulih.

```text
CLOSED
```

berarti alert secara operasional selesai.

Alert dapat auto-resolve, tetapi close dapat mengikuti policy.

---

### 60. Manual Resolve

Manual resolve diperbolehkan bila:

- source rusak;
- false positive;
- external condition selesai;
- operator memiliki bukti.

Wajib:

- permission;
- reason;
- actor;
- timestamp;
- audit.

---

### 61. False Positive Workflow

```text
Alert FIRING
→ operator review
→ mark false positive
→ resolve
→ tune rule task
→ owner review
```

---

### 62. Missing Signal

Jika source tidak tersedia:

```text
UNKNOWN
```

bukan otomatis normal.

Rule dapat membuat:

```text
source_unavailable alert
```

---

### 63. Rule Error

Rule evaluation error harus menghasilkan:

- structured log;
- metric;
- safe operational alert bila berulang;
- tidak membuat false firing alert.

---

### 64. Rule Validation

Sebelum aktif, rule wajib divalidasi:

- code unik;
- source terdaftar;
- expression valid;
- unit kompatibel;
- window valid;
- severity valid;
- owner tersedia;
- route tersedia;
- runbook reference valid;
- fingerprint fields aman;
- no raw SQL;
- no `eval`.

---

### 65. Rule Versioning

Breaking change menghasilkan versi baru.

Perubahan yang wajib versioning:

- formula;
- source metric;
- denominator;
- threshold semantics;
- grouping;
- fingerprint;
- recovery condition.

---

### 66. Rule Lifecycle

```text
DRAFT
REVIEW
ACTIVE
DISABLED
DEPRECATED
ARCHIVED
```

---

### 67. Rule Approval

SEV0/SEV1 rule wajib direview oleh:

- domain owner;
- platform operations;
- security bila relevan;
- QA/UAT.

---

### 68. Rule Testing

Test modes:

```text
unit test
historical replay
shadow mode
dry run
staging
production canary
```

Shadow mode mengevaluasi rule tanpa notification.

---

### 69. Historical Replay

Historical replay digunakan untuk:

- mengukur false positive;
- mengukur missed detection;
- tuning threshold;
- verifikasi grouping.

---

### 70. Dry Run

Dry run menghasilkan:

- evaluation result;
- hypothetical alert;
- no state mutation;
- no notification;
- telemetry.

---

### 71. Rule Ownership

Setiap rule wajib memiliki:

```text
business owner
technical owner
on-call owner
review date
```

---

### 72. Runbook Binding

SEV0–SEV2 rule wajib memiliki runbook atau documented action.

SEV3/SEV4 minimal memiliki remediation hint.

---

### 73. Alert Evaluation Result

```php
final readonly class AlertEvaluationResult
{
    public function __construct(
        public string $ruleCode,
        public string $status,
        public bool $conditionMatched,
        public float|int|string|null $value,
        public int $sampleCount,
        public array $dimensions,
        public array $reasons,
        public \DateTimeImmutable $evaluatedAt,
    ) {
    }
}
```

---

### 74. Alert Signal

```php
final readonly class AlertSignal
{
    public function __construct(
        public string $sourceType,
        public string $sourceReference,
        public string $environment,
        public ?int $tenantId,
        public ?int $scopeId,
        public ?string $moduleCode,
        public ?string $component,
        public mixed $value,
        public array $dimensions,
        public \DateTimeImmutable $observedAt,
    ) {
    }
}
```

---

### 75. Alert Rule Contract

```php
interface AlertRuleInterface
{
    public function code(): string;

    public function evaluate(
        AlertSignal $signal,
        AlertEvaluationContext $context
    ): AlertEvaluationResult;
}
```

---

### 76. Rule Engine Contract

```php
interface AlertRuleEngineInterface
{
    public function evaluate(
        AlertSignal $signal,
        AlertEvaluationContext $context
    ): array;
}
```

---

### 77. Alert Manager Contract

```php
interface AlertManagerInterface
{
    public function process(
        AlertRule $rule,
        AlertEvaluationResult $result,
        AlertEvaluationContext $context
    ): Alert;
}
```

---

### 78. Routing Contract

```php
interface AlertRouterInterface
{
    public function route(
        Alert $alert,
        AlertRoutingContext $context
    ): AlertRouteResult;
}
```

---

### 79. Escalation Contract

```php
interface AlertEscalationServiceInterface
{
    public function schedule(Alert $alert): void;

    public function cancel(Alert $alert): void;

    public function escalate(Alert $alert): void;
}
```

---

### 80. Telemetry

Metrics minimum:

```text
alert_rule_evaluation_total
alert_rule_evaluation_error_total
alert_rule_match_total
alert_pending_total
alert_firing_total
alert_deduplicated_total
alert_grouped_total
alert_suppressed_total
alert_routed_total
alert_escalated_total
alert_resolved_total
alert_flapping_total
alert_notification_failure_total
```

---

### 81. Structured Logging

```json
{
  "event": "alert_rule_evaluated",
  "rule_code": "http_error_rate_high",
  "matched": true,
  "status": "FIRING",
  "severity": "SEV2",
  "tenant_id": null,
  "scope_id": null,
  "fingerprint": "sha256:...",
  "duration_ms": 12
}
```

Jangan log raw sensitive dimensions.

---

### 82. Access Policy

Permission awal:

```text
observability.alert.rule.read
observability.alert.rule.create
observability.alert.rule.update
observability.alert.rule.enable
observability.alert.rule.disable
observability.alert.route.manage
observability.alert.suppression.manage
observability.alert.maintenance.manage
observability.alert.escalation.manage
observability.alert.resolve
observability.alert.false_positive.mark
```

---

### 83. Audit Events

```text
OBS_ALERT_RULE_CREATED
OBS_ALERT_RULE_UPDATED
OBS_ALERT_RULE_ENABLED
OBS_ALERT_RULE_DISABLED
OBS_ALERT_ROUTE_CHANGED
OBS_ALERT_SUPPRESSION_CREATED
OBS_ALERT_SUPPRESSION_REMOVED
OBS_ALERT_MAINTENANCE_CREATED
OBS_ALERT_ESCALATED
OBS_ALERT_MANUALLY_RESOLVED
OBS_ALERT_FALSE_POSITIVE_MARKED
OBS_ALERT_SEVERITY_CHANGED
```

---

### 84. Security Controls

Framework wajib:

- melarang raw SQL;
- melarang formula `eval`;
- memakai allowlisted source;
- memvalidasi dimensions;
- mengisolasi tenant/scope;
- membatasi suppression;
- membatasi cross-tenant routing;
- mengaudit manual override;
- melindungi security-restricted alert;
- membatasi channel berdasarkan classification.

---

### 85. Multi-Tenant Routing

Tenant-specific alert harus dirutekan ke:

- tenant operations;
- platform owner bila shared component;
- module owner bila module-specific.

Cross-tenant group hanya boleh dibuat oleh role berwenang.

---

### 86. Security Alert Routing

Security alert dapat bypass normal owner.

Routing:

```text
security on-call
→ security lead
→ incident commander
→ compliance/legal bila policy mengharuskan
```

---

### 87. Alert Storm Protection

Jika volume alert melebihi batas:

- aktifkan grouping;
- suppress duplicates;
- prioritize root alerts;
- rate-limit notification;
- tetap simpan count;
- create alert storm incident bila perlu.

---

### 88. Alert Storm Metrics

```text
alerts_per_minute
unique_fingerprint_per_minute
notification_attempt_per_minute
suppression_ratio
grouping_ratio
```

---

### 89. Backpressure

Notification pipeline harus memiliki:

- bounded queue;
- retry policy;
- dead-letter;
- priority;
- idempotency;
- channel health.

---

### 90. Anti-Pattern

Hindari:

- rule tanpa owner;
- rule tanpa recovery condition;
- threshold hardcoded di frontend;
- raw log regex bebas;
- fingerprint memakai timestamp;
- suppression permanen;
- route konflik;
- semua alert paging;
- no minimum sample;
- no hysteresis;
- average of percentiles;
- manual close tanpa audit;
- security alert ke channel publik;
- one alert per event;
- retry notification tanpa limit.

---

### 91. UAT Part 2

#### Rule Evaluation

- [ ] Threshold rule bekerja.
- [ ] State rule bekerja.
- [ ] Rate/ratio rule bekerja.
- [ ] Absence rule bekerja.
- [ ] Pending duration bekerja.
- [ ] Minimum sample bekerja.
- [ ] Hysteresis bekerja.
- [ ] Recovery window bekerja.

#### Deduplication

- [ ] Fingerprint stabil.
- [ ] Duplicate tidak membuat record baru.
- [ ] Occurrence count meningkat.
- [ ] Current/peak value diperbarui.
- [ ] Reopen policy bekerja.

#### Grouping

- [ ] Alert terkait tergabung.
- [ ] Root/symptom classification bekerja.
- [ ] Group severity benar.
- [ ] Dependency suppression bekerja.
- [ ] Group lifecycle bekerja.

#### Suppression

- [ ] Maintenance window bekerja.
- [ ] Silence memiliki expiry.
- [ ] Suppression reason wajib.
- [ ] SEV0 security tidak tersuppress tanpa policy.
- [ ] Suppression diaudit.

#### Routing

- [ ] Route paling spesifik dipilih.
- [ ] Fallback route tersedia.
- [ ] Channel sesuai severity.
- [ ] Tenant routing terisolasi.
- [ ] Restricted alert memakai restricted channel.

#### Escalation

- [ ] Ack deadline bekerja.
- [ ] Unacknowledged alert dieskalasi.
- [ ] Acknowledgement menghentikan escalation.
- [ ] Severity increase memicu escalation.
- [ ] Notification failure memicu fallback.

#### Flapping & Recovery

- [ ] Flapping terdeteksi.
- [ ] Cooldown bekerja.
- [ ] Repeat notification dibatasi.
- [ ] Automatic resolve bekerja.
- [ ] Manual resolve membutuhkan reason.
- [ ] False positive workflow bekerja.

#### Security

- [ ] Raw SQL ditolak.
- [ ] Formula eval ditolak.
- [ ] Cross-tenant rule access dibatasi.
- [ ] Manual override diaudit.
- [ ] Sensitive dimensions tidak tercatat di log umum.

---

### 92. Definition of Done Part 2

Part 2 dianggap selesai bila:

- [ ] AlertRule model tersedia;
- [ ] rule types tersedia;
- [ ] evaluation interval tersedia;
- [ ] evaluation window tersedia;
- [ ] pending duration tersedia;
- [ ] minimum samples tersedia;
- [ ] hysteresis tersedia;
- [ ] cooldown tersedia;
- [ ] fingerprint tersedia;
- [ ] deduplication tersedia;
- [ ] grouping tersedia;
- [ ] dependency awareness tersedia;
- [ ] suppression tersedia;
- [ ] maintenance window tersedia;
- [ ] routing tersedia;
- [ ] fallback channel tersedia;
- [ ] escalation policy tersedia;
- [ ] flapping detection tersedia;
- [ ] recovery policy tersedia;
- [ ] rule lifecycle tersedia;
- [ ] rule testing tersedia;
- [ ] telemetry tersedia;
- [ ] security controls tersedia;
- [ ] UAT tersedia.

---

### 93. Rencana Part Berikutnya

#### Part 3

Incident management, assignment, timeline, communication, SLA, runbook, postmortem, root cause, action item, reporting, dan incident metrics.

#### Part 4

Notification adapters, on-call schedule, HTTP API, controllers, middleware, database schema, audit integration, dan Apache/XAMPP routing.

#### Part 5

Reference implementation, deployment, simulation, final UAT, Definition of Done, roadmap, dan merge guidance.

---

## Bagian III — Incident Management, Assignment, Timeline, Communication, SLA, Runbook & Postmortem

### 1. Executive Summary

Part 3 mendefinisikan standar pengelolaan incident end-to-end setelah alert atau laporan operasional dinyatakan membutuhkan koordinasi terstruktur.

Bagian ini menetapkan:

- incident declaration;
- severity;
- assignment;
- ownership;
- incident commander;
- technical lead;
- communication;
- timeline;
- runbook;
- mitigation;
- recovery;
- SLA/OLA;
- escalation;
- postmortem;
- root cause;
- action item;
- evidence;
- reporting;
- incident metrics;
- UAT.

Tujuan utamanya adalah memastikan setiap incident:

- memiliki owner;
- memiliki severity yang benar;
- memiliki timeline;
- memiliki status yang jelas;
- memiliki komunikasi terkontrol;
- memiliki bukti recovery;
- memiliki tindak lanjut;
- tidak kehilangan konteks setelah selesai.

---

### 2. Incident Management Principles

#### 2.1 One Incident, One Coordination Record

Satu gangguan utama harus memiliki satu incident record utama.

Alert, ticket, log, trace, dan evidence ditautkan ke incident tersebut.

#### 2.2 Clear Command

SEV0 dan SEV1 wajib memiliki Incident Commander.

#### 2.3 Separate Coordination from Investigation

Incident Commander mengoordinasikan.

Technical Lead memimpin investigasi teknis.

#### 2.4 Timeline Is Mandatory

Semua keputusan penting harus dicatat.

#### 2.5 Communication Must Be Audience-Specific

Informasi untuk operator berbeda dengan informasi untuk executive, tenant, atau publik.

#### 2.6 Mitigation Before Perfection

Prioritas awal:

```text
Stop impact
→ Reduce impact
→ Restore service
→ Investigate root cause
```

#### 2.7 Recovery Must Be Proven

Incident tidak boleh resolved hanya karena tidak ada laporan baru.

#### 2.8 Blameless Follow-Up

Postmortem berfokus pada sistem, proses, control, dan keputusan.

---

### 3. Incident Creation Sources

Incident dapat dibuat dari:

```text
ALERT
ALERT_GROUP
MANUAL
USER_REPORT
SECURITY_REPORT
DEPLOYMENT_FAILURE
EXTERNAL_VENDOR
COMPLIANCE_EVENT
BUSINESS_OPERATION
```

---

### 4. Incident Declaration Criteria

Incident wajib dideklarasikan bila:

- SEV0 alert;
- SEV1 alert;
- multiple correlated SEV2;
- multi-tenant impact;
- layanan inti unavailable;
- suspected data loss;
- suspected security breach;
- compliance impact;
- customer communication dibutuhkan;
- alert melewati maximum unresolved duration;
- operator menilai koordinasi lintas tim diperlukan.

---

### 5. Incident Record

Field minimum:

| Field | Keterangan |
|---|---|
| incident_id | identifier unik |
| incident_number | human-readable number |
| title | ringkasan |
| description | dampak |
| source_type | asal incident |
| source_reference | alert/group/report |
| severity | SEV0–SEV4 |
| state | lifecycle |
| environment | environment |
| tenant_id | optional |
| scope_id | optional |
| module_code | optional |
| owner_team | owner |
| commander_user_id | incident commander |
| technical_lead_user_id | technical lead |
| communication_lead_user_id | optional |
| started_at | actual start |
| detected_at | detection |
| declared_at | declaration |
| acknowledged_at | acknowledgement |
| mitigated_at | mitigation |
| recovered_at | recovery |
| resolved_at | resolution |
| closed_at | closure |
| postmortem_required | bool |
| data_classification | classification |
| created_by | actor |
| created_at | timestamp |
| updated_at | timestamp |

---

### 6. Incident Number

Format rekomendasi:

```text
INC-YYYY-NNNNNN
```

Contoh:

```text
INC-2026-000145
```

Incident ID internal tetap dapat menggunakan UUID/ULID.

---

### 7. Incident States

```text
DECLARED
INVESTIGATING
IDENTIFIED
MITIGATING
MONITORING
RECOVERED
RESOLVED
CLOSED
CANCELLED
```

---

### 8. State Transition

```text
DECLARED
   ↓
INVESTIGATING
   ↓
IDENTIFIED
   ↓
MITIGATING
   ↓
MONITORING
   ↓
RECOVERED
   ↓
RESOLVED
   ↓
CLOSED
```

Optional:

```text
DECLARED → CANCELLED
INVESTIGATING → CANCELLED
```

---

### 9. State Semantics

#### DECLARED

Incident resmi dibuat.

#### INVESTIGATING

Tim sedang mencari penyebab dan ruang dampak.

#### IDENTIFIED

Penyebab utama atau area penyebab telah diketahui.

#### MITIGATING

Tindakan untuk mengurangi dampak sedang dilakukan.

#### MONITORING

Mitigasi telah diterapkan dan kondisi diamati.

#### RECOVERED

Layanan telah kembali berfungsi.

#### RESOLVED

Pemulihan stabil dan incident tidak aktif.

#### CLOSED

Administrasi, dokumentasi, dan tindak lanjut minimum selesai.

#### CANCELLED

Incident duplicate, false positive, atau tidak valid.

---

### 10. Invalid Transitions

Contoh invalid:

```text
CLOSED → INVESTIGATING
CANCELLED → MITIGATING
DECLARED → CLOSED
```

Jika gangguan muncul kembali setelah closed, buat incident baru atau reopen sesuai policy.

---

### 11. Reopen Policy

Incident dapat direopen bila:

- recovery belum stabil;
- same root cause muncul kembali dalam reopen window;
- incident closure terlalu dini.

Reopen wajib:

- permission;
- reason;
- actor;
- audit;
- severity reassessment.

---

### 12. Severity Model

Incident memakai:

```text
SEV0
SEV1
SEV2
SEV3
SEV4
```

Severity incident ditentukan dari dampak aktual, bukan hanya severity alert.

---

### 13. Severity Reassessment

Severity wajib ditinjau saat:

- impact meluas;
- tenant tambahan terdampak;
- data risk ditemukan;
- workaround tersedia;
- recovery tercapai;
- evidence baru muncul.

Severity change wajib dicatat pada timeline dan audit.

---

### 14. Incident Roles

```text
Incident Commander
Technical Lead
Communications Lead
Operations Lead
Security Lead
Scribe
Subject Matter Expert
Tenant Liaison
Executive Liaison
```

---

### 15. Incident Commander

Tanggung jawab:

- memimpin koordinasi;
- menjaga fokus;
- menetapkan cadence update;
- menentukan escalation;
- memastikan owner tiap action;
- memastikan timeline;
- memutuskan transisi status;
- memastikan recovery diverifikasi;
- memutuskan kapan incident resolved.

Incident Commander tidak boleh terbebani seluruh pekerjaan teknis.

---

### 16. Technical Lead

Tanggung jawab:

- memimpin investigasi;
- membentuk hypothesis;
- mengarahkan diagnostic;
- memilih mitigation;
- menilai rollback;
- memvalidasi technical recovery;
- mengidentifikasi root cause sementara.

---

### 17. Communications Lead

Tanggung jawab:

- menyusun update;
- menjaga audience separation;
- menghindari informasi sensitif;
- menjaga cadence;
- mengelola status page/customer communication;
- mencatat communication history.

---

### 18. Scribe

Tanggung jawab:

- mencatat timeline;
- mencatat keputusan;
- mencatat evidence;
- mencatat owner action;
- mencatat status update;
- menjaga timestamps.

---

### 19. Role Assignment Rules

SEV0/SEV1 wajib:

- Incident Commander;
- Technical Lead;
- Communications Lead atau assigned communicator;
- Scribe.

SEV2 minimal:

- owner;
- Technical Lead;
- coordinator.

SEV3/SEV4 dapat dikelola satu owner.

---

### 20. Ownership Resolution

Urutan:

```text
incident source owner
→ alert owner
→ service owner
→ module owner
→ platform operations fallback
```

Incident tidak boleh aktif tanpa owner team.

---

### 21. Assignment Model

Assignment types:

```text
TEAM
ROLE
USER
ON_CALL_ROTATION
EXTERNAL_PARTY
```

Assignment dapat mencakup:

- primary owner;
- secondary owner;
- watchers;
- escalation contact.

---

### 22. Incident Assignment Fields

```text
incident_id
assignment_type
assignee_reference
assignment_role
assigned_by
assigned_at
accepted_at
released_at
status
```

---

### 23. Assignment Status

```text
PENDING
ACCEPTED
ACTIVE
RELEASED
DECLINED
ESCALATED
```

---

### 24. Assignment Acceptance

Critical incident assignment wajib di-accept.

Jika tidak di-accept sebelum deadline:

- escalate;
- assign fallback;
- notify commander;
- record timeline event.

---

### 25. Incident Context

Context minimum:

```text
environment
tenant
scope
module
service
component
deployment
region
data classification
```

Context harus immutable secara historis.

---

### 26. Affected Scope

Incident dapat memengaruhi:

```text
GLOBAL
MULTI_TENANT
TENANT
BUSINESS_ENTITY
MODULE
COMPONENT
INTEGRATION
USER_SEGMENT
```

---

### 27. Impact Assessment

Impact fields:

```text
affected_tenant_count
affected_user_estimate
affected_service_count
transaction_failure_count
data_risk
security_risk
compliance_risk
workaround_available
business_criticality
```

---

### 28. Impact Updates

Impact dapat berubah selama incident.

Setiap perubahan penting harus:

- masuk timeline;
- memicu severity review;
- memicu communication review;
- memicu escalation review.

---

### 29. Incident Timeline

Timeline event types:

```text
INCIDENT_DECLARED
STATE_CHANGED
SEVERITY_CHANGED
OWNER_ASSIGNED
ROLE_ASSIGNED
ALERT_LINKED
EVIDENCE_ADDED
HYPOTHESIS_ADDED
MITIGATION_STARTED
MITIGATION_COMPLETED
ROLLBACK_STARTED
ROLLBACK_COMPLETED
RECOVERY_VERIFIED
COMMUNICATION_SENT
ACTION_ITEM_CREATED
POSTMORTEM_REQUIRED
INCIDENT_RESOLVED
INCIDENT_CLOSED
INCIDENT_REOPENED
```

---

### 30. Timeline Event Contract

```php
final readonly class IncidentTimelineEvent
{
    public function __construct(
        public string $eventId,
        public string $incidentId,
        public string $eventType,
        public string $actorType,
        public ?int $actorId,
        public string $message,
        public array $metadata,
        public \DateTimeImmutable $occurredAt,
        public \DateTimeImmutable $createdAt,
    ) {
    }
}
```

---

### 31. Timeline Immutability

Timeline event tidak dihapus.

Correction dilakukan dengan:

```text
CORRECTION event
```

yang mereferensikan event sebelumnya.

---

### 32. Evidence

Evidence types:

```text
METRIC_SNAPSHOT
LOG_REFERENCE
TRACE_REFERENCE
HEALTH_RESULT
SCREENSHOT_REFERENCE
DEPLOYMENT_REFERENCE
CONFIG_REFERENCE
EXTERNAL_STATUS_REFERENCE
MANUAL_NOTE
```

Evidence harus aman dan bounded.

---

### 33. Evidence Security

Jangan menyimpan pada incident umum:

- token;
- password;
- raw PHI;
- full authorization header;
- unrestricted stack trace;
- secret;
- private key.

Evidence sensitif disimpan pada restricted store dan incident hanya menyimpan reference.

---

### 34. Alert Linking

Incident dapat menautkan banyak alert.

Link types:

```text
PRIMARY
ROOT_CAUSE_CANDIDATE
SYMPTOM
CORRELATED
RECOVERY_SIGNAL
```

---

### 35. Duplicate Incident

Duplicate incident harus:

- ditandai duplicate;
- ditautkan ke primary incident;
- tidak dihapus;
- timeline tetap dipertahankan;
- notification dikurangi.

---

### 36. Merge Incident

Merge diperbolehkan bila dua incident memiliki root cause sama.

Merge wajib:

- pilih primary;
- transfer links;
- transfer evidence;
- transfer action items;
- preserve timeline;
- audit.

---

### 37. Split Incident

Split diperlukan bila satu incident ternyata memiliki dua root cause independen.

Split wajib:

- buat incident baru;
- link parent;
- pindahkan alert/evidence relevan;
- audit;
- severity reassessment.

---

### 38. Communication Plan

Setiap incident SEV0–SEV2 harus memiliki communication plan.

Audience:

```text
internal operations
technical team
security
executive
tenant/customer
compliance/legal
public status page
```

---

### 39. Communication Template

Update minimum:

```text
What happened
Current impact
Affected scope
What is being done
Workaround
Next update time
Reference number
```

---

### 40. Internal Update Example

```text
INC-2026-000145 — SEV1

Impact:
Platform API mengalami error rate tinggi pada production.

Scope:
Multi-tenant, terutama module appointment.

Current action:
Database connection saturation sedang dimitigasi.

Next update:
30 menit.
```

---

### 41. Customer/Tenant Update

Harus:

- singkat;
- tidak spekulatif;
- tidak membocorkan tenant lain;
- tidak membocorkan detail security;
- memberi next update time;
- menyebut workaround jika ada.

---

### 42. Communication Approval

SEV0/SEV1 external communication dapat membutuhkan approval:

- Incident Commander;
- Communications Lead;
- Security;
- Legal/Compliance;
- Executive.

---

### 43. Update Cadence

| Severity | Internal | External |
|---|---:|---:|
| SEV0 | 15 menit | 15–30 menit |
| SEV1 | 30 menit | 30–60 menit |
| SEV2 | 60 menit | sesuai dampak |
| SEV3 | sesuai kebutuhan | optional |
| SEV4 | report | tidak perlu |

---

### 44. Communication Delay Alert

Jika update terlambat:

- notify Communications Lead;
- notify Incident Commander;
- log timeline;
- escalate bila severity tinggi.

---

### 45. Runbook Model

Runbook fields:

```text
code
title
purpose
applicable_services
symptoms
verification_steps
immediate_actions
mitigation_steps
rollback_steps
recovery_checks
escalation
risks
owner
version
last_reviewed_at
tested_at
status
```

---

### 46. Runbook Status

```text
DRAFT
REVIEW
ACTIVE
DEPRECATED
ARCHIVED
```

---

### 47. Runbook Execution

Saat incident:

- pilih runbook;
- record step started;
- record step completed;
- record result;
- record deviation;
- record actor.

---

### 48. Runbook Deviation

Operator boleh menyimpang dari runbook jika:

- kondisi berbeda;
- runbook tidak relevan;
- risiko lebih besar;
- commander menyetujui.

Deviation wajib dicatat.

---

### 49. Mitigation

Mitigation adalah tindakan mengurangi dampak tanpa harus menyelesaikan root cause.

Contoh:

- failover;
- scale worker;
- disable feature;
- rollback deployment;
- switch integration endpoint;
- increase capacity;
- isolate tenant;
- activate read-only mode.

---

### 50. Mitigation Record

Field:

```text
action
owner
started_at
completed_at
result
risk
rollback_available
evidence
```

---

### 51. Recovery

Recovery berarti service kembali memenuhi kondisi minimum.

Recovery harus berdasarkan:

- health;
- metric;
- synthetic transaction;
- operational test;
- tenant verification bila perlu.

---

### 52. Recovery Checklist

- [ ] critical health UP;
- [ ] error rate normal;
- [ ] latency normal;
- [ ] queue backlog turun;
- [ ] no new critical alert;
- [ ] business transaction berhasil;
- [ ] data consistency check selesai;
- [ ] security control restored;
- [ ] tenant impact berhenti.

---

### 53. Monitoring State

Setelah mitigation:

```text
MONITORING
```

Durasi monitoring tergantung severity.

Contoh:

| Severity | Monitoring Minimum |
|---|---:|
| SEV0 | 60 menit |
| SEV1 | 30–60 menit |
| SEV2 | 15–30 menit |
| SEV3 | sesuai kebutuhan |

---

### 54. Incident SLA

Incident SLA mencakup:

```text
time to acknowledge
time to assign
time to mitigate
time to recover
time to communicate
time to close
time to postmortem
```

---

### 55. OLA

Operational Level Agreement adalah target internal antar tim.

Contoh:

```text
DBA response within 10 minutes
Security triage within 15 minutes
Communication update every 30 minutes
```

---

### 56. SLA vs OLA

```text
SLA = komitmen layanan
OLA = komitmen operasional internal
```

Incident dashboard harus membedakan keduanya.

---

### 57. Response Targets

Contoh awal:

| Severity | Ack | Assign Commander | Mitigation Start |
|---|---:|---:|---:|
| SEV0 | 5 m | 5 m | 10 m |
| SEV1 | 10 m | 10 m | 20 m |
| SEV2 | 30 m | 30 m | 60 m |
| SEV3 | 4 h kerja | optional | sesuai prioritas |
| SEV4 | optional | optional | tidak wajib |

---

### 58. SLA Breach

Jika target terlewati:

- timeline event;
- escalation;
- dashboard indicator;
- metric increment;
- postmortem input.

---

### 59. Escalation During Incident

Escalation triggers:

- no owner;
- role unaccepted;
- no progress;
- impact worsens;
- communication overdue;
- mitigation failed;
- recovery unstable;
- SLA breach;
- security/data risk discovered.

---

### 60. War Room

SEV0/SEV1 dapat menggunakan war room.

War room metadata:

```text
channel reference
meeting reference
started_at
ended_at
participants
access classification
```

Jangan menyimpan credential atau private meeting token pada public incident record.

---

### 61. Decision Log

Decision log mencatat:

```text
decision
options considered
decision owner
reason
risk
timestamp
```

Keputusan penting:

- rollback;
- failover;
- disable feature;
- notify customer;
- declare data risk;
- close incident.

---

### 62. Hypothesis Tracking

Hypothesis states:

```text
PROPOSED
TESTING
CONFIRMED
REJECTED
```

Field:

```text
description
owner
evidence
created_at
resolved_at
```

---

### 63. Root Cause

Root cause tidak wajib diketahui sebelum service recovered.

Root cause fields:

```text
category
summary
technical_details
contributing_factors
detection_gap
control_gap
confirmed_at
confirmed_by
```

---

### 64. Root Cause Categories

```text
CODE_DEFECT
CONFIGURATION
CAPACITY
DEPENDENCY
INFRASTRUCTURE
DATA
SECURITY
PROCESS
HUMAN_FACTORS
VENDOR
UNKNOWN
```

---

### 65. Contributing Factors

Incident dapat memiliki beberapa contributing factor.

Contoh:

- insufficient capacity;
- missing alert;
- unclear runbook;
- delayed escalation;
- deployment validation gap;
- single point of failure.

---

### 66. Five Whys

Five Whys dapat digunakan, tetapi tidak wajib menjadi satu-satunya metode.

Gunakan bila membantu menemukan system/process gap.

---

### 67. Postmortem

Postmortem adalah dokumen analisis setelah incident.

Field minimum:

```text
incident summary
impact
timeline
detection
response
recovery
root cause
contributing factors
what went well
what went poorly
where we got lucky
action items
owners
due dates
reviewers
```

---

### 68. Postmortem Requirement

Wajib untuk:

- SEV0;
- SEV1;
- significant security incident;
- data loss;
- compliance impact;
- repeated SEV2;
- major SLA breach;
- false negative detection;
- failed recovery;
- high customer impact.

---

### 69. Postmortem Deadline

Contoh:

| Severity | Draft |
|---|---:|
| SEV0 | 2 hari kerja |
| SEV1 | 3 hari kerja |
| SEV2 required | 5 hari kerja |

Final target configurable.

---

### 70. Blameless Language

Hindari:

```text
operator lupa
developer ceroboh
tim gagal
```

Gunakan:

```text
control tidak mencegah
proses tidak mendeteksi
runbook tidak mencakup
approval tidak jelas
```

---

### 71. Action Item

Action item fields:

```text
action_id
incident_id
title
description
category
priority
owner
due_at
status
verification
completed_at
evidence
```

---

### 72. Action Item Categories

```text
PREVENT
DETECT
MITIGATE
RECOVER
DOCUMENT
TRAIN
SECURITY
COMPLIANCE
CAPACITY
TEST
```

---

### 73. Action Item Status

```text
OPEN
IN_PROGRESS
BLOCKED
DONE
CANCELLED
OVERDUE
```

---

### 74. Action Item Quality

Action item harus:

- spesifik;
- memiliki owner;
- memiliki due date;
- dapat diverifikasi;
- terkait gap nyata;
- tidak terlalu umum.

Contoh buruk:

```text
Improve monitoring
```

Contoh baik:

```text
Tambahkan alert scheduler heartbeat stale > 5 menit sebelum 15 Juli 2026.
```

---

### 75. Postmortem Approval

Reviewer:

- Incident Commander;
- Technical Lead;
- Service Owner;
- Security/Compliance bila relevan;
- Platform Operations.

---

### 76. Incident Closure Criteria

Incident dapat closed bila:

- recovery stabil;
- timeline lengkap;
- severity final ditetapkan;
- affected scope final tercatat;
- root cause status tercatat;
- postmortem decision dibuat;
- action items dibuat;
- communication closure selesai;
- evidence reference tersedia;
- audit lengkap.

---

### 77. Close Without Root Cause

Incident boleh closed dengan root cause `UNKNOWN` hanya jika:

- recovery stabil;
- investigation bounded;
- follow-up action dibuat;
- owner menyetujui;
- reason tercatat.

---

### 78. Incident Cancellation

Incident dapat cancelled bila:

- false positive;
- duplicate;
- planned behavior;
- invalid report.

Cancellation wajib reason dan audit.

---

### 79. Incident Reporting

Report types:

```text
ACTIVE_INCIDENTS
INCIDENT_HISTORY
SEVERITY_TREND
MTTA
MTTD
MTTR
SLA_BREACH
REPEAT_INCIDENT
ROOT_CAUSE_CATEGORY
ACTION_ITEM_STATUS
TENANT_IMPACT
```

---

### 80. Incident Metrics

```text
incident_declared_total
incident_active_total
incident_resolved_total
incident_closed_total
incident_cancelled_total
incident_severity_change_total
incident_reopened_total
incident_sla_breach_total
incident_postmortem_required_total
incident_postmortem_overdue_total
incident_action_item_overdue_total
```

---

### 81. MTTA

```text
MTTA =
average(acknowledged_at - detected_at)
```

---

### 82. MTTD

```text
MTTD =
average(detected_at - started_at)
```

Bila started_at unknown, quality harus ditandai.

---

### 83. Time to Mitigate

```text
TTM =
mitigated_at - declared_at
```

---

### 84. Time to Recover

```text
TTR =
recovered_at - started_at
```

---

### 85. Time to Resolve

```text
resolution_time =
resolved_at - declared_at
```

---

### 86. Time to Close

```text
closure_time =
closed_at - resolved_at
```

---

### 87. Repeat Incident Rate

```text
repeat_incident_rate =
repeat_incident_count / total_incident_count
```

Repeat definition wajib eksplisit.

---

### 88. Incident Dashboard

Widget minimum:

- active incidents;
- incidents by severity;
- unassigned incidents;
- SLA breaches;
- MTTA;
- MTTR;
- incidents by service;
- repeated incidents;
- overdue postmortems;
- overdue action items.

---

### 89. Tenant Incident Dashboard

Tenant admin hanya melihat:

- incident tenant sendiri;
- impact tenant sendiri;
- approved communication;
- no cross-tenant detail;
- no restricted security evidence.

---

### 90. Security Incident

Security incident membutuhkan:

- restricted visibility;
- separate communication;
- evidence chain;
- security lead;
- audit lebih ketat;
- legal/compliance involvement bila diperlukan.

---

### 91. Evidence Chain

Untuk security/compliance incident, evidence harus memiliki:

```text
source
hash
collected_by
collected_at
storage_reference
access classification
```

---

### 92. Incident Data Classification

```text
INTERNAL
CONFIDENTIAL
RESTRICTED
SECURITY_RESTRICTED
LEGAL_HOLD
```

---

### 93. Legal Hold

Incident tertentu dapat memiliki legal hold.

Jika aktif:

- evidence tidak boleh dihapus;
- retention override;
- export dibatasi;
- access diaudit.

---

### 94. Retention

Rekomendasi awal:

| Data | Retention |
|---|---|
| Incident record | 5–7 tahun atau policy |
| Timeline | sama dengan incident |
| Postmortem | 5–7 tahun |
| Action item | 2–5 tahun |
| General evidence | 1–3 tahun |
| Security evidence | sesuai security/legal |
| Communication log | 1–3 tahun |

Final mengikuti compliance.

---

### 95. Incident Command Contract

```php
interface IncidentServiceInterface
{
    public function declare(
        IncidentDeclarationCommand $command,
        IncidentContext $context
    ): Incident;

    public function transition(
        string $incidentId,
        string $targetState,
        IncidentContext $context
    ): Incident;

    public function assign(
        IncidentAssignmentCommand $command,
        IncidentContext $context
    ): IncidentAssignment;

    public function resolve(
        IncidentResolutionCommand $command,
        IncidentContext $context
    ): Incident;

    public function close(
        IncidentClosureCommand $command,
        IncidentContext $context
    ): Incident;
}
```

---

### 96. Incident Repository Contract

```php
interface IncidentRepositoryInterface
{
    public function findById(string $incidentId): ?Incident;

    public function save(Incident $incident): void;

    public function findActiveByFingerprint(
        string $fingerprint
    ): ?Incident;

    public function search(
        IncidentSearchCriteria $criteria
    ): IncidentPage;
}
```

---

### 97. Timeline Repository Contract

```php
interface IncidentTimelineRepositoryInterface
{
    public function append(
        IncidentTimelineEvent $event
    ): void;

    public function findByIncident(
        string $incidentId
    ): array;
}
```

---

### 98. Postmortem Service Contract

```php
interface IncidentPostmortemServiceInterface
{
    public function create(
        string $incidentId,
        IncidentContext $context
    ): IncidentPostmortem;

    public function update(
        IncidentPostmortemUpdateCommand $command,
        IncidentContext $context
    ): IncidentPostmortem;

    public function approve(
        string $postmortemId,
        IncidentContext $context
    ): IncidentPostmortem;
}
```

---

### 99. Permission Model

```text
observability.incident.read
observability.incident.create
observability.incident.assign
observability.incident.command
observability.incident.update
observability.incident.resolve
observability.incident.close
observability.incident.reopen
observability.incident.merge
observability.incident.split
observability.incident.timeline.write
observability.incident.evidence.read
observability.incident.evidence.write
observability.incident.communication.manage
observability.incident.postmortem.manage
observability.incident.action_item.manage
observability.incident.security.read
observability.incident.cross_tenant.read
```

---

### 100. Audit Events

```text
OBS_INCIDENT_DECLARED
OBS_INCIDENT_STATE_CHANGED
OBS_INCIDENT_SEVERITY_CHANGED
OBS_INCIDENT_ROLE_ASSIGNED
OBS_INCIDENT_OWNER_CHANGED
OBS_INCIDENT_ALERT_LINKED
OBS_INCIDENT_EVIDENCE_ADDED
OBS_INCIDENT_COMMUNICATION_SENT
OBS_INCIDENT_MITIGATION_RECORDED
OBS_INCIDENT_RECOVERY_VERIFIED
OBS_INCIDENT_RESOLVED
OBS_INCIDENT_CLOSED
OBS_INCIDENT_REOPENED
OBS_INCIDENT_MERGED
OBS_INCIDENT_SPLIT
OBS_INCIDENT_POSTMORTEM_CREATED
OBS_INCIDENT_POSTMORTEM_APPROVED
OBS_INCIDENT_ACTION_ITEM_CREATED
OBS_INCIDENT_RESTRICTED_VIEWED
```

---

### 101. Structured Logging

```json
{
  "event": "incident_state_changed",
  "incident_id": "01J...",
  "incident_number": "INC-2026-000145",
  "from_state": "MITIGATING",
  "to_state": "MONITORING",
  "severity": "SEV1",
  "tenant_id": null,
  "scope_id": null,
  "actor_user_id": 10
}
```

---

### 102. Security Controls

Framework wajib:

- enforce tenant/scope;
- enforce classification;
- protect evidence;
- restrict security incident;
- audit cross-tenant access;
- prevent timeline deletion;
- validate state transition;
- require reason for override;
- sanitize communication;
- use secure references for attachments.

---

### 103. Multi-Tenant Rules

- Tenant incident hanya terlihat tenant terkait.
- Platform incident dapat memuat aggregate impact.
- Tenant list detail hanya untuk role berwenang.
- Communication tenant tidak menampilkan tenant lain.
- Cross-tenant evidence restricted.
- Cache/search result harus tenant-aware.

---

### 104. Data Privacy

Jangan menaruh:

- patient name;
- medical record number;
- phone;
- email;
- diagnosis;
- raw clinical data;

pada incident operasional umum.

Jika diperlukan untuk investigation, gunakan restricted evidence reference.

---

### 105. Anti-Pattern

Hindari:

- incident tanpa commander untuk SEV0/SEV1;
- timeline ditulis setelah incident selesai;
- komunikasi tanpa next update;
- root cause dipaksa sebelum recovery;
- action item tanpa owner;
- postmortem menyalahkan individu;
- incident closed tanpa recovery evidence;
- duplicate incident dibiarkan aktif;
- severity downgrade tanpa reason;
- PHI dalam incident title;
- evidence sensitif di public attachment;
- state transition bebas;
- action item “improve monitoring” tanpa scope.

---

### 106. UAT Part 3

#### Incident Creation

- [ ] Incident dapat dibuat dari alert.
- [ ] Incident dapat dibuat manual.
- [ ] Incident number unik.
- [ ] Owner wajib.
- [ ] Severity valid.
- [ ] Tenant/scope context valid.

#### Lifecycle

- [ ] State transition valid bekerja.
- [ ] Invalid transition ditolak.
- [ ] Reopen membutuhkan reason.
- [ ] Cancel membutuhkan reason.
- [ ] Resolve membutuhkan recovery evidence.
- [ ] Close membutuhkan closure checklist.

#### Assignment

- [ ] Commander dapat ditetapkan.
- [ ] Technical Lead dapat ditetapkan.
- [ ] Assignment acceptance bekerja.
- [ ] Assignment timeout memicu escalation.
- [ ] Owner fallback tersedia.

#### Timeline

- [ ] Timeline append-only.
- [ ] State change tercatat.
- [ ] Severity change tercatat.
- [ ] Mitigation tercatat.
- [ ] Communication tercatat.
- [ ] Correction tidak menghapus event lama.

#### Communication

- [ ] Cadence sesuai severity.
- [ ] External message disanitasi.
- [ ] Tenant message tidak bocor lintas tenant.
- [ ] Overdue update terdeteksi.
- [ ] Communication history tersimpan.

#### Runbook

- [ ] Runbook dapat ditautkan.
- [ ] Step execution dapat dicatat.
- [ ] Deviation membutuhkan reason.
- [ ] Obsolete runbook ditandai.
- [ ] Recovery checks tersedia.

#### Postmortem

- [ ] SEV0/SEV1 mewajibkan postmortem.
- [ ] Root cause dapat UNKNOWN dengan follow-up.
- [ ] Action item memiliki owner/due date.
- [ ] Approval workflow bekerja.
- [ ] Overdue postmortem terdeteksi.

#### Security

- [ ] Restricted incident dibatasi.
- [ ] Evidence sensitif memakai secure reference.
- [ ] Cross-tenant access diaudit.
- [ ] Timeline tidak dapat dihapus.
- [ ] PHI/PII tidak tampil pada incident umum.

---

### 107. Definition of Done Part 3

Part 3 dianggap selesai bila:

- [ ] incident record model tersedia;
- [ ] incident lifecycle tersedia;
- [ ] state transition policy tersedia;
- [ ] severity reassessment tersedia;
- [ ] role dan ownership tersedia;
- [ ] assignment model tersedia;
- [ ] impact assessment tersedia;
- [ ] timeline tersedia;
- [ ] evidence model tersedia;
- [ ] duplicate/merge/split policy tersedia;
- [ ] communication plan tersedia;
- [ ] runbook model tersedia;
- [ ] mitigation dan recovery tersedia;
- [ ] SLA/OLA tersedia;
- [ ] escalation tersedia;
- [ ] root cause model tersedia;
- [ ] postmortem tersedia;
- [ ] action item tersedia;
- [ ] reporting dan metrics tersedia;
- [ ] permission dan audit tersedia;
- [ ] security/privacy controls tersedia;
- [ ] UAT tersedia.

---

### 108. Rencana Part Berikutnya

#### Part 4

Notification adapters, channel routing, on-call schedule, HTTP API, controllers, middleware, database schema, audit integration, scheduler, dan Apache/XAMPP routing.

#### Part 5

Reference implementation, sample rules dan incidents, deployment, incident simulations, final UAT, Definition of Done, roadmap, dan merge guidance.

---

## Bagian IV — Notification Adapters, On-Call, HTTP API, Database Schema, Audit & Routing

### 1. Executive Summary

Part 4 mendefinisikan interface delivery dan infrastructure untuk Alerting & Incident Management Framework.

Bagian ini menetapkan:

- notification channel adapters;
- delivery policy;
- retry dan dead-letter;
- idempotency;
- on-call schedule;
- rotation;
- override;
- escalation routing;
- HTTP API;
- controller architecture;
- middleware;
- response contracts;
- database schema;
- scheduler;
- audit integration;
- Apache/XAMPP routing;
- UAT.

Tujuan utama adalah memastikan alert dan incident dapat:

- diteruskan ke channel yang benar;
- mencapai owner yang benar;
- tetap terlacak saat delivery gagal;
- tetap aman berdasarkan severity dan data classification;
- diakses melalui API yang konsisten;
- disimpan dengan tenant/scope isolation;
- dikelola secara operasional.

---

### 2. Notification Architecture

```text
Alert / Incident Event
        │
        ▼
Notification Policy Resolver
        │
        ├── Severity
        ├── Owner
        ├── Route
        ├── On-Call
        ├── Classification
        └── Maintenance/Suppression
        │
        ▼
Notification Dispatcher
        │
        ├── Idempotency
        ├── Template
        ├── Channel Adapter
        ├── Retry
        ├── Fallback
        └── Delivery Tracking
        │
        ▼
Email / SMS / Chat / Pager / Webhook / Ticket
```

---

### 3. Notification Is a Delivery Domain

Notification bukan sumber kebenaran alert atau incident.

Jika notification gagal:

- alert tetap FIRING;
- incident tetap aktif;
- delivery status dicatat;
- fallback route dapat berjalan;
- failure dapat menghasilkan alert internal.

---

### 4. Supported Channels

```text
DASHBOARD
EMAIL
SMS
PUSH
WHATSAPP
TEAMS
SLACK
PAGER
WEBHOOK
TICKET
VOICE
```

Implementasi awal direkomendasikan:

```text
DASHBOARD
EMAIL
TEAMS atau SLACK
WEBHOOK
```

SMS, WhatsApp, Pager, dan Voice dapat ditambahkan melalui adapter.

---

### 5. Notification Adapter Contract

```php
interface NotificationChannelAdapterInterface
{
    public function channel(): string;

    public function supports(
        NotificationMessage $message
    ): bool;

    public function send(
        NotificationMessage $message,
        NotificationDeliveryContext $context
    ): NotificationDeliveryResult;
}
```

---

### 6. Notification Message

```php
final readonly class NotificationMessage
{
    /**
     * @param list<string> $recipients
     * @param array<string, mixed> $metadata
     */
    public function __construct(
        public string $messageId,
        public string $eventType,
        public string $severity,
        public string $title,
        public string $body,
        public array $recipients,
        public string $classification,
        public array $metadata,
        public ?string $deduplicationKey,
        public \DateTimeImmutable $createdAt,
    ) {
    }
}
```

---

### 7. Delivery Result

```php
final readonly class NotificationDeliveryResult
{
    public function __construct(
        public string $status,
        public string $channel,
        public ?string $providerReference,
        public ?string $errorCode,
        public ?string $errorMessage,
        public \DateTimeImmutable $attemptedAt,
    ) {
    }
}
```

Supported status:

```text
PENDING
SENT
DELIVERED
FAILED
RETRYING
DEAD_LETTER
SUPPRESSED
CANCELLED
```

---

### 8. Notification Dispatcher

Tanggung jawab:

- resolve adapter;
- enforce classification;
- apply idempotency;
- render template;
- send;
- retry;
- fallback;
- persist result;
- emit telemetry;
- audit restricted delivery.

---

### 9. Idempotency

Notification wajib memiliki idempotency key.

Contoh:

```text
alert:{alert_id}:{state}:{channel}:{recipient_group}:{repeat_sequence}
```

Tujuan:

- mencegah duplicate send;
- aman terhadap retry;
- menghindari alert storm.

---

### 10. Delivery Attempt

Setiap attempt memiliki:

```text
attempt_number
started_at
completed_at
status
provider_reference
error_code
latency_ms
next_retry_at
```

---

### 11. Retry Policy

Retry hanya untuk transient failure.

Contoh transient:

- timeout;
- 429;
- 502;
- provider unavailable;
- connection reset.

Jangan retry tanpa batas untuk:

- invalid recipient;
- unauthorized credential;
- invalid template;
- classification violation.

---

### 12. Retry Schedule

Contoh:

```text
attempt 1: immediate
attempt 2: +1 minute
attempt 3: +5 minutes
attempt 4: +15 minutes
attempt 5: +30 minutes
```

Gunakan exponential backoff dengan jitter.

---

### 13. Dead-Letter

Setelah retry habis:

```text
DEAD_LETTER
```

Wajib:

- persist payload aman;
- record last error;
- notify fallback owner;
- expose dashboard metric;
- allow controlled replay;
- audit replay.

---

### 14. Fallback Routing

Contoh:

```text
Pager gagal
→ SMS
→ Voice call
→ Operations Manager
```

atau:

```text
Teams gagal
→ Email
→ Dashboard only
```

Fallback mengikuti severity dan classification.

---

### 15. Channel Health

Setiap adapter wajib memiliki health check:

```text
UP
DEGRADED
DOWN
UNKNOWN
```

Metric:

```text
notification_send_total
notification_delivery_success_total
notification_delivery_failure_total
notification_retry_total
notification_dead_letter_total
notification_latency_ms
```

---

### 16. Template Model

Template fields:

```text
code
channel
event_type
severity
locale
subject
body
classification
version
enabled
```

---

### 17. Template Variables

Allowed variables:

```text
alert_id
incident_id
title
severity
state
environment
tenant_name_safe
component
owner_team
triggered_at
runbook_url
dashboard_url
next_update_at
```

Jangan menyediakan variable raw secret atau PHI.

---

### 18. Template Safety

Template engine wajib:

- escaping;
- allowlisted variables;
- no arbitrary PHP;
- no `eval`;
- no raw SQL;
- output length limit;
- safe URL generation.

---

### 19. Channel Classification Matrix

| Classification | Allowed Channel |
|---|---|
| INTERNAL | dashboard, email, internal chat |
| CONFIDENTIAL | approved email/chat/pager |
| RESTRICTED | restricted channel, pager, approved email |
| SECURITY_RESTRICTED | security pager/chat only |
| LEGAL_HOLD | approved restricted channel only |

---

### 20. Notification Preferences

User preferences dapat mengatur:

- optional channel;
- quiet hours;
- language;
- digest;
- non-critical notifications.

User tidak boleh menonaktifkan mandatory SEV0/SEV1 delivery jika role on-call aktif.

---

### 21. Quiet Hours

Quiet hours berlaku untuk:

- SEV3;
- SEV4;
- digest;
- non-urgent reminder.

SEV0/SEV1 bypass quiet hours.

SEV2 mengikuti policy.

---

### 22. On-Call Model

On-call menentukan siapa yang aktif menerima alert pada waktu tertentu.

Core objects:

```text
OnCallSchedule
OnCallRotation
OnCallShift
OnCallOverride
OnCallEscalation
```

---

### 23. OnCallSchedule

Field:

```text
code
title
team
timezone
rotation
handover_time
escalation_policy
enabled
```

---

### 24. OnCallRotation

Rotation types:

```text
DAILY
WEEKLY
BIWEEKLY
CUSTOM
```

Field:

```text
participants
start_at
duration
order
timezone
```

---

### 25. OnCallShift

Field:

```text
schedule_id
user_id
starts_at
ends_at
role
source
status
```

Status:

```text
PLANNED
ACTIVE
COMPLETED
CANCELLED
```

---

### 26. OnCallOverride

Override digunakan untuk:

- leave;
- swap;
- emergency replacement;
- temporary coverage.

Field:

```text
schedule_id
original_user_id
replacement_user_id
starts_at
ends_at
reason
approved_by
```

---

### 27. On-Call Resolution

Urutan:

```text
active override
→ active shift
→ rotation calculation
→ team fallback
→ operations fallback
```

---

### 28. Coverage Validation

Schedule wajib divalidasi untuk:

- gap;
- overlap;
- inactive user;
- missing contact method;
- timezone issue;
- unresolved override.

---

### 29. On-Call Handover

Handover minimum:

- active incidents;
- unacknowledged alerts;
- known degradation;
- maintenance window;
- pending action;
- channel issue.

---

### 30. On-Call Privacy

Contact details tidak boleh diekspos ke dashboard umum.

Gunakan internal recipient reference.

---

### 31. On-Call Escalation

Contoh:

```text
Primary On-Call
→ Secondary On-Call
→ Team Lead
→ Operations Manager
→ Executive/Security based on severity
```

---

### 32. HTTP API Base Path

```text
/api/internal/v1/alerts
/api/internal/v1/incidents
/api/internal/v1/on-call
/api/internal/v1/notifications
```

Endpoint internal wajib authentication.

---

### 33. Alert API Catalog

```text
GET  /api/internal/v1/alerts
GET  /api/internal/v1/alerts/{alertId}
POST /api/internal/v1/alerts/{alertId}/acknowledge
POST /api/internal/v1/alerts/{alertId}/suppress
POST /api/internal/v1/alerts/{alertId}/resolve
POST /api/internal/v1/alerts/{alertId}/reopen
GET  /api/internal/v1/alerts/{alertId}/occurrences
GET  /api/internal/v1/alerts/{alertId}/deliveries
```

---

### 34. Alert Rule API Catalog

```text
GET    /api/internal/v1/alert-rules
GET    /api/internal/v1/alert-rules/{ruleCode}
POST   /api/internal/v1/alert-rules
PUT    /api/internal/v1/alert-rules/{ruleCode}
POST   /api/internal/v1/alert-rules/{ruleCode}/enable
POST   /api/internal/v1/alert-rules/{ruleCode}/disable
POST   /api/internal/v1/alert-rules/{ruleCode}/test
```

---

### 35. Suppression API

```text
GET    /api/internal/v1/alert-suppressions
POST   /api/internal/v1/alert-suppressions
DELETE /api/internal/v1/alert-suppressions/{suppressionId}
```

---

### 36. Incident API Catalog

```text
GET  /api/internal/v1/incidents
GET  /api/internal/v1/incidents/{incidentId}
POST /api/internal/v1/incidents
POST /api/internal/v1/incidents/{incidentId}/transition
POST /api/internal/v1/incidents/{incidentId}/assign
POST /api/internal/v1/incidents/{incidentId}/timeline
POST /api/internal/v1/incidents/{incidentId}/link-alert
POST /api/internal/v1/incidents/{incidentId}/resolve
POST /api/internal/v1/incidents/{incidentId}/close
POST /api/internal/v1/incidents/{incidentId}/reopen
POST /api/internal/v1/incidents/{incidentId}/merge
POST /api/internal/v1/incidents/{incidentId}/split
```

---

### 37. Postmortem API

```text
GET  /api/internal/v1/incidents/{incidentId}/postmortem
POST /api/internal/v1/incidents/{incidentId}/postmortem
PUT  /api/internal/v1/incidents/{incidentId}/postmortem
POST /api/internal/v1/incidents/{incidentId}/postmortem/approve
```

---

### 38. Action Item API

```text
GET  /api/internal/v1/incidents/{incidentId}/action-items
POST /api/internal/v1/incidents/{incidentId}/action-items
PUT  /api/internal/v1/incidents/{incidentId}/action-items/{actionId}
```

---

### 39. On-Call API

```text
GET  /api/internal/v1/on-call/schedules
GET  /api/internal/v1/on-call/schedules/{scheduleCode}
GET  /api/internal/v1/on-call/active
POST /api/internal/v1/on-call/overrides
DELETE /api/internal/v1/on-call/overrides/{overrideId}
```

---

### 40. Notification API

```text
GET  /api/internal/v1/notifications/deliveries
GET  /api/internal/v1/notifications/deliveries/{deliveryId}
POST /api/internal/v1/notifications/deliveries/{deliveryId}/retry
GET  /api/internal/v1/notifications/channels/health
```

---

### 41. Alert List Filters

```text
state
severity
source_type
environment
tenant_id
scope_id
module_code
owner_team
incident_id
triggered_from
triggered_to
search
page
per_page
sort
```

Semua filter harus allowlisted.

---

### 42. Incident List Filters

```text
state
severity
environment
tenant_id
scope_id
module_code
owner_team
commander_user_id
started_from
started_to
postmortem_required
sla_breached
search
page
per_page
sort
```

---

### 43. Alert Acknowledge Request

```json
{
  "note": "Investigation started."
}
```

Response:

```json
{
  "data": {
    "alert_id": "01J...",
    "state": "ACKNOWLEDGED",
    "acknowledged_at": "2026-07-04T19:10:00+07:00"
  }
}
```

---

### 44. Suppression Request

```json
{
  "type": "MAINTENANCE",
  "reason": "Database maintenance approved.",
  "starts_at": "2026-07-05T01:00:00+07:00",
  "ends_at": "2026-07-05T02:00:00+07:00"
}
```

Suppression tanpa end time harus ditolak kecuali special policy.

---

### 45. Incident Declaration Request

```json
{
  "title": "Production database unavailable",
  "description": "Database health check is DOWN.",
  "severity": "SEV1",
  "environment": "production",
  "owner_team": "platform_operations",
  "alert_ids": [
    "01J..."
  ]
}
```

---

### 46. Incident Transition Request

```json
{
  "target_state": "MITIGATING",
  "note": "Failover procedure started."
}
```

---

### 47. Controller Responsibilities

Controller hanya:

- parse request;
- validate DTO;
- build context;
- authorize;
- call application service;
- project response;
- map exception.

Controller tidak boleh:

- menjalankan SQL langsung;
- merender template channel;
- menghitung on-call rotation;
- mengirim notification langsung;
- mengubah state tanpa service.

---

### 48. AlertController Example

```php
final class AlertController
{
    public function __construct(
        private readonly AlertQueryService $queries,
        private readonly AlertCommandService $commands,
        private readonly AlertContextFactory $contexts,
        private readonly AlertResponseProjector $projector,
    ) {
    }

    public function acknowledge(
        HttpRequest $request,
        string $alertId
    ): HttpResponse {
        $context = $this->contexts->fromRequest($request);

        $alert = $this->commands->acknowledge(
            alertId: $alertId,
            note: $request->jsonString('note', ''),
            context: $context
        );

        return JsonResponse::ok(
            $this->projector->alert($alert)
        );
    }
}
```

---

### 49. IncidentController Example

```php
final class IncidentController
{
    public function __construct(
        private readonly IncidentServiceInterface $incidents,
        private readonly IncidentContextFactory $contexts,
        private readonly IncidentResponseProjector $projector,
    ) {
    }

    public function transition(
        HttpRequest $request,
        string $incidentId
    ): HttpResponse {
        $context = $this->contexts->fromRequest($request);

        $incident = $this->incidents->transition(
            incidentId: $incidentId,
            targetState: $request->jsonString('target_state'),
            context: $context
        );

        return JsonResponse::ok(
            $this->projector->incident($incident)
        );
    }
}
```

---

### 50. Canonical Success Envelope

```json
{
  "data": {},
  "meta": {
    "request_id": "01J...",
    "generated_at": "2026-07-04T19:00:00+07:00"
  }
}
```

---

### 51. Canonical Error Envelope

```json
{
  "error": {
    "code": "INCIDENT_TRANSITION_INVALID",
    "message": "The requested incident transition is not allowed.",
    "details": []
  },
  "meta": {
    "request_id": "01J...",
    "timestamp": "2026-07-04T19:00:00+07:00"
  }
}
```

---

### 52. HTTP Status Mapping

| Kondisi | HTTP |
|---|---:|
| success | 200 |
| created | 201 |
| accepted async | 202 |
| validation | 422 |
| unauthenticated | 401 |
| forbidden | 403 |
| not found | 404 |
| conflict | 409 |
| rate limited | 429 |
| provider unavailable | 503 |
| unexpected | 500 |

---

### 53. Middleware Order

```text
Request ID
→ Trusted Proxy
→ Security Headers
→ Authentication
→ Rate Limit
→ Tenant Context
→ Active Scope
→ Permission
→ Classification
→ Audit Context
→ Controller
```

---

### 54. Permissions

#### Alert

```text
observability.alert.read
observability.alert.acknowledge
observability.alert.suppress
observability.alert.resolve
observability.alert.reopen
observability.alert.manage
observability.alert.rule.read
observability.alert.rule.manage
observability.alert.route.manage
observability.alert.notification.retry
```

#### Incident

```text
observability.incident.read
observability.incident.create
observability.incident.assign
observability.incident.update
observability.incident.resolve
observability.incident.close
observability.incident.reopen
observability.incident.merge
observability.incident.split
observability.incident.postmortem.manage
observability.incident.action_item.manage
observability.incident.security.read
observability.incident.cross_tenant.read
```

#### On-Call

```text
observability.on_call.read
observability.on_call.manage
observability.on_call.override
```

---

### 55. Tenant Isolation

Setiap repository query wajib mempertimbangkan:

```text
tenant_id
scope_id
environment
classification
```

Global role dapat lintas tenant hanya dengan permission khusus.

---

### 56. Rate Limiting

Rekomendasi:

| Endpoint | Limit |
|---|---:|
| alert list | 120/min/user |
| alert acknowledge | 60/min/user |
| suppression create | 20/hour/user |
| incident list | 120/min/user |
| incident transition | 60/min/user |
| timeline append | 120/min/user |
| notification retry | 20/hour/user |
| on-call override | 20/hour/user |

---

### 57. CSRF

Mutation berbasis session wajib CSRF:

- acknowledge;
- suppress;
- resolve;
- declare incident;
- transition;
- assignment;
- timeline;
- postmortem;
- action item;
- on-call override;
- notification retry.

---

### 58. Audit Integration

Wajib audit:

- alert acknowledge;
- alert suppress;
- alert resolve;
- rule change;
- route change;
- delivery replay;
- incident declaration;
- incident transition;
- incident assignment;
- incident close;
- postmortem approval;
- on-call override;
- cross-tenant view;
- restricted incident view.

---

### 59. Database Schema Overview

Tables:

```text
alert_rules
alerts
alert_occurrences
alert_groups
alert_group_members
alert_suppressions
alert_routes
alert_escalation_policies
alert_escalation_steps
notification_deliveries
notification_delivery_attempts
on_call_schedules
on_call_rotations
on_call_shifts
on_call_overrides
incidents
incident_assignments
incident_timeline_events
incident_alert_links
incident_evidence
incident_postmortems
incident_action_items
```

---

### 60. Table: alert_rules

```sql
CREATE TABLE alert_rules (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    code VARCHAR(150) NOT NULL,
    title VARCHAR(200) NOT NULL,
    description VARCHAR(1000) NULL,
    source_type VARCHAR(40) NOT NULL,
    source_reference VARCHAR(200) NOT NULL,
    rule_type VARCHAR(40) NOT NULL,
    expression_json JSON NOT NULL,
    evaluation_window VARCHAR(20) NOT NULL,
    evaluation_interval_seconds INT UNSIGNED NOT NULL,
    pending_duration_seconds INT UNSIGNED NOT NULL DEFAULT 0,
    minimum_samples INT UNSIGNED NOT NULL DEFAULT 0,
    severity VARCHAR(10) NOT NULL,
    owner_team VARCHAR(100) NOT NULL,
    fingerprint_fields_json JSON NOT NULL,
    grouping_fields_json JSON NULL,
    cooldown_seconds INT UNSIGNED NOT NULL DEFAULT 0,
    recovery_json JSON NOT NULL,
    runbook_reference VARCHAR(500) NULL,
    rule_version VARCHAR(20) NOT NULL DEFAULT '1.0',
    lifecycle_status VARCHAR(20) NOT NULL DEFAULT 'DRAFT',
    enabled TINYINT(1) NOT NULL DEFAULT 0,
    created_by BIGINT UNSIGNED NULL,
    updated_by BIGINT UNSIGNED NULL,
    created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    updated_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6)
        ON UPDATE CURRENT_TIMESTAMP(6),

    PRIMARY KEY (id),
    UNIQUE KEY uq_alert_rule_code (code),
    KEY idx_alert_rule_active (
        enabled,
        lifecycle_status,
        source_type
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

### 61. Table: alerts

```sql
CREATE TABLE alerts (
    id CHAR(26) NOT NULL,
    rule_id BIGINT UNSIGNED NULL,
    fingerprint CHAR(64) NOT NULL,
    title VARCHAR(255) NOT NULL,
    description VARCHAR(2000) NULL,
    source_type VARCHAR(40) NOT NULL,
    source_reference VARCHAR(255) NULL,
    severity VARCHAR(10) NOT NULL,
    state VARCHAR(30) NOT NULL,
    environment VARCHAR(32) NOT NULL,
    tenant_id BIGINT UNSIGNED NULL,
    scope_id BIGINT UNSIGNED NULL,
    module_code VARCHAR(100) NULL,
    component_code VARCHAR(150) NULL,
    owner_team VARCHAR(100) NOT NULL,
    current_value_json JSON NULL,
    peak_value_json JSON NULL,
    occurrence_count BIGINT UNSIGNED NOT NULL DEFAULT 1,
    first_seen_at DATETIME(6) NOT NULL,
    last_seen_at DATETIME(6) NOT NULL,
    triggered_at DATETIME(6) NOT NULL,
    acknowledged_at DATETIME(6) NULL,
    acknowledged_by BIGINT UNSIGNED NULL,
    resolved_at DATETIME(6) NULL,
    resolved_by BIGINT UNSIGNED NULL,
    closed_at DATETIME(6) NULL,
    incident_id CHAR(26) NULL,
    data_classification VARCHAR(30) NOT NULL DEFAULT 'INTERNAL',
    runbook_reference VARCHAR(500) NULL,
    created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    updated_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6)
        ON UPDATE CURRENT_TIMESTAMP(6),

    PRIMARY KEY (id),
    CONSTRAINT fk_alert_rule
        FOREIGN KEY (rule_id)
        REFERENCES alert_rules(id)
        ON DELETE SET NULL,

    UNIQUE KEY uq_alert_active_fingerprint_state (
        fingerprint,
        state
    ),
    KEY idx_alert_scope_state (
        environment,
        tenant_id,
        scope_id,
        state,
        severity
    ),
    KEY idx_alert_owner (
        owner_team,
        state,
        triggered_at
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

### 62. Table: alert_occurrences

```sql
CREATE TABLE alert_occurrences (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    alert_id CHAR(26) NOT NULL,
    observed_value_json JSON NULL,
    dimensions_json JSON NULL,
    observed_at DATETIME(6) NOT NULL,
    created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),

    PRIMARY KEY (id),
    CONSTRAINT fk_alert_occurrence_alert
        FOREIGN KEY (alert_id)
        REFERENCES alerts(id)
        ON DELETE CASCADE,

    KEY idx_alert_occurrence_time (
        alert_id,
        observed_at
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

### 63. Table: alert_suppressions

```sql
CREATE TABLE alert_suppressions (
    id CHAR(26) NOT NULL,
    suppression_type VARCHAR(30) NOT NULL,
    reason VARCHAR(1000) NOT NULL,
    environment VARCHAR(32) NULL,
    tenant_id BIGINT UNSIGNED NULL,
    scope_id BIGINT UNSIGNED NULL,
    module_code VARCHAR(100) NULL,
    component_code VARCHAR(150) NULL,
    rule_codes_json JSON NULL,
    starts_at DATETIME(6) NOT NULL,
    ends_at DATETIME(6) NOT NULL,
    created_by BIGINT UNSIGNED NOT NULL,
    approved_by BIGINT UNSIGNED NULL,
    active TINYINT(1) NOT NULL DEFAULT 1,
    created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),

    PRIMARY KEY (id),
    KEY idx_alert_suppression_active (
        active,
        starts_at,
        ends_at
    ),
    KEY idx_alert_suppression_scope (
        tenant_id,
        scope_id,
        environment
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

### 64. Table: notification_deliveries

```sql
CREATE TABLE notification_deliveries (
    id CHAR(26) NOT NULL,
    idempotency_key VARCHAR(255) NOT NULL,
    event_type VARCHAR(80) NOT NULL,
    event_reference VARCHAR(64) NOT NULL,
    channel VARCHAR(30) NOT NULL,
    recipient_reference VARCHAR(255) NOT NULL,
    severity VARCHAR(10) NOT NULL,
    classification VARCHAR(30) NOT NULL,
    status VARCHAR(30) NOT NULL,
    provider_reference VARCHAR(255) NULL,
    attempt_count INT UNSIGNED NOT NULL DEFAULT 0,
    next_retry_at DATETIME(6) NULL,
    sent_at DATETIME(6) NULL,
    delivered_at DATETIME(6) NULL,
    failed_at DATETIME(6) NULL,
    last_error_code VARCHAR(100) NULL,
    last_error_message VARCHAR(1000) NULL,
    created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    updated_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6)
        ON UPDATE CURRENT_TIMESTAMP(6),

    PRIMARY KEY (id),
    UNIQUE KEY uq_notification_idempotency (idempotency_key),
    KEY idx_notification_retry (
        status,
        next_retry_at
    ),
    KEY idx_notification_event (
        event_type,
        event_reference
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

### 65. Table: notification_delivery_attempts

```sql
CREATE TABLE notification_delivery_attempts (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    delivery_id CHAR(26) NOT NULL,
    attempt_number INT UNSIGNED NOT NULL,
    status VARCHAR(30) NOT NULL,
    provider_reference VARCHAR(255) NULL,
    error_code VARCHAR(100) NULL,
    error_message VARCHAR(1000) NULL,
    latency_ms INT UNSIGNED NULL,
    started_at DATETIME(6) NOT NULL,
    completed_at DATETIME(6) NULL,
    created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),

    PRIMARY KEY (id),
    CONSTRAINT fk_notification_attempt_delivery
        FOREIGN KEY (delivery_id)
        REFERENCES notification_deliveries(id)
        ON DELETE CASCADE,

    UNIQUE KEY uq_notification_attempt (
        delivery_id,
        attempt_number
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

### 66. Table: on_call_schedules

```sql
CREATE TABLE on_call_schedules (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    code VARCHAR(120) NOT NULL,
    title VARCHAR(200) NOT NULL,
    team_code VARCHAR(100) NOT NULL,
    timezone VARCHAR(64) NOT NULL,
    rotation_type VARCHAR(30) NOT NULL,
    handover_time TIME NOT NULL,
    escalation_policy_code VARCHAR(120) NULL,
    enabled TINYINT(1) NOT NULL DEFAULT 1,
    created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    updated_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6)
        ON UPDATE CURRENT_TIMESTAMP(6),

    PRIMARY KEY (id),
    UNIQUE KEY uq_on_call_schedule_code (code)
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

### 67. Table: on_call_shifts

```sql
CREATE TABLE on_call_shifts (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    schedule_id BIGINT UNSIGNED NOT NULL,
    user_id BIGINT UNSIGNED NOT NULL,
    role_code VARCHAR(50) NOT NULL DEFAULT 'primary',
    source_type VARCHAR(30) NOT NULL DEFAULT 'rotation',
    starts_at DATETIME(6) NOT NULL,
    ends_at DATETIME(6) NOT NULL,
    status VARCHAR(20) NOT NULL DEFAULT 'PLANNED',
    created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    updated_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6)
        ON UPDATE CURRENT_TIMESTAMP(6),

    PRIMARY KEY (id),
    CONSTRAINT fk_on_call_shift_schedule
        FOREIGN KEY (schedule_id)
        REFERENCES on_call_schedules(id)
        ON DELETE CASCADE,

    KEY idx_on_call_shift_active (
        schedule_id,
        starts_at,
        ends_at,
        status
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

### 68. Table: incidents

```sql
CREATE TABLE incidents (
    id CHAR(26) NOT NULL,
    incident_number VARCHAR(32) NOT NULL,
    title VARCHAR(255) NOT NULL,
    description VARCHAR(3000) NULL,
    source_type VARCHAR(50) NOT NULL,
    source_reference VARCHAR(100) NULL,
    severity VARCHAR(10) NOT NULL,
    state VARCHAR(30) NOT NULL,
    environment VARCHAR(32) NOT NULL,
    tenant_id BIGINT UNSIGNED NULL,
    scope_id BIGINT UNSIGNED NULL,
    module_code VARCHAR(100) NULL,
    owner_team VARCHAR(100) NOT NULL,
    commander_user_id BIGINT UNSIGNED NULL,
    technical_lead_user_id BIGINT UNSIGNED NULL,
    communication_lead_user_id BIGINT UNSIGNED NULL,
    started_at DATETIME(6) NULL,
    detected_at DATETIME(6) NOT NULL,
    declared_at DATETIME(6) NOT NULL,
    mitigated_at DATETIME(6) NULL,
    recovered_at DATETIME(6) NULL,
    resolved_at DATETIME(6) NULL,
    closed_at DATETIME(6) NULL,
    postmortem_required TINYINT(1) NOT NULL DEFAULT 0,
    data_classification VARCHAR(30) NOT NULL DEFAULT 'INTERNAL',
    created_by BIGINT UNSIGNED NOT NULL,
    created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    updated_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6)
        ON UPDATE CURRENT_TIMESTAMP(6),

    PRIMARY KEY (id),
    UNIQUE KEY uq_incident_number (incident_number),
    KEY idx_incident_scope_state (
        environment,
        tenant_id,
        scope_id,
        state,
        severity
    ),
    KEY idx_incident_owner (
        owner_team,
        state,
        declared_at
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

### 69. Table: incident_timeline_events

```sql
CREATE TABLE incident_timeline_events (
    id CHAR(26) NOT NULL,
    incident_id CHAR(26) NOT NULL,
    event_type VARCHAR(80) NOT NULL,
    actor_type VARCHAR(30) NOT NULL,
    actor_id BIGINT UNSIGNED NULL,
    message VARCHAR(3000) NOT NULL,
    metadata_json JSON NULL,
    occurred_at DATETIME(6) NOT NULL,
    created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),

    PRIMARY KEY (id),
    CONSTRAINT fk_incident_timeline_incident
        FOREIGN KEY (incident_id)
        REFERENCES incidents(id)
        ON DELETE CASCADE,

    KEY idx_incident_timeline (
        incident_id,
        occurred_at
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

Timeline tidak boleh dihapus melalui API umum.

---

### 70. Table: incident_action_items

```sql
CREATE TABLE incident_action_items (
    id CHAR(26) NOT NULL,
    incident_id CHAR(26) NOT NULL,
    title VARCHAR(255) NOT NULL,
    description VARCHAR(2000) NULL,
    category VARCHAR(40) NOT NULL,
    priority VARCHAR(20) NOT NULL,
    owner_user_id BIGINT UNSIGNED NULL,
    owner_team VARCHAR(100) NULL,
    due_at DATETIME(6) NULL,
    status VARCHAR(30) NOT NULL DEFAULT 'OPEN',
    verification TEXT NULL,
    completed_at DATETIME(6) NULL,
    created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    updated_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6)
        ON UPDATE CURRENT_TIMESTAMP(6),

    PRIMARY KEY (id),
    CONSTRAINT fk_incident_action_item_incident
        FOREIGN KEY (incident_id)
        REFERENCES incidents(id)
        ON DELETE CASCADE,

    KEY idx_incident_action_due (
        status,
        due_at
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

### 71. Scheduler Jobs

Required jobs:

```text
alert-rule-evaluate
alert-escalation-process
notification-retry
notification-dead-letter-monitor
on-call-shift-materialize
on-call-coverage-validate
incident-sla-monitor
incident-communication-monitor
postmortem-overdue-monitor
action-item-overdue-monitor
suppression-expiry
```

---

### 72. Scheduler Frequency

| Job | Frequency |
|---|---:|
| Rule evaluation | 15s–5m per rule |
| Escalation process | 1 menit |
| Notification retry | 1 menit |
| Dead-letter monitor | 5 menit |
| Shift materialization | harian |
| Coverage validation | 15 menit |
| Incident SLA monitor | 1 menit |
| Communication monitor | 5 menit |
| Postmortem monitor | harian |
| Action item monitor | harian |
| Suppression expiry | 1 menit |

---

### 73. CLI Commands

```bash
php bin/console alert:evaluate --rule=http_error_rate_high
php bin/console alert:escalate
php bin/console notification:retry
php bin/console on-call:validate
php bin/console incident:sla-check
php bin/console incident:postmortem-check
```

---

### 74. Apache/XAMPP Virtual Host

```apache
<VirtualHost *:80>
    ServerName platform.local
    DocumentRoot "D:/xampp/htdocs/platform/public"

    <Directory "D:/xampp/htdocs/platform/public">
        AllowOverride All
        Require all granted
        Options -Indexes
    </Directory>

    ErrorLog "logs/platform-error.log"
    CustomLog "logs/platform-access.log" combined
</VirtualHost>
```

---

### 75. `.htaccess`

```apache
RewriteEngine On

RewriteCond %{REQUEST_FILENAME} -f [OR]
RewriteCond %{REQUEST_FILENAME} -d
RewriteRule ^ - [L]

RewriteRule ^ index.php [QSA,L]
```

---

### 76. Route Registration

```php
$router->group('/api/internal/v1', [
    'middleware' => [
        RequestIdMiddleware::class,
        AuthenticationMiddleware::class,
        RateLimitMiddleware::class,
        TenantContextMiddleware::class,
        ActiveScopeMiddleware::class,
    ],
], function ($router): void {
    $router->get('/alerts', [AlertController::class, 'index']);
    $router->get('/alerts/{alertId}', [AlertController::class, 'show']);
    $router->post('/alerts/{alertId}/acknowledge', [
        AlertController::class,
        'acknowledge',
    ]);
    $router->post('/alerts/{alertId}/suppress', [
        AlertController::class,
        'suppress',
    ]);
    $router->post('/alerts/{alertId}/resolve', [
        AlertController::class,
        'resolve',
    ]);

    $router->get('/incidents', [IncidentController::class, 'index']);
    $router->post('/incidents', [IncidentController::class, 'create']);
    $router->get('/incidents/{incidentId}', [
        IncidentController::class,
        'show',
    ]);
    $router->post('/incidents/{incidentId}/transition', [
        IncidentController::class,
        'transition',
    ]);
    $router->post('/incidents/{incidentId}/assign', [
        IncidentController::class,
        'assign',
    ]);
    $router->post('/incidents/{incidentId}/timeline', [
        IncidentTimelineController::class,
        'append',
    ]);
});
```

---

### 77. Sequence Diagram — Alert Delivery

```mermaid
sequenceDiagram
    participant Rule as Alert Rule Engine
    participant Manager as Alert Manager
    participant Route as Route Resolver
    participant OnCall as On-Call Resolver
    participant Dispatch as Notification Dispatcher
    participant Adapter as Channel Adapter
    participant Store as Delivery Store

    Rule->>Manager: FIRING result
    Manager->>Route: Resolve route
    Route->>OnCall: Resolve active owner
    OnCall-->>Route: Recipient reference
    Route-->>Manager: Route result
    Manager->>Dispatch: Dispatch notification
    Dispatch->>Store: Check idempotency
    Store-->>Dispatch: Not sent
    Dispatch->>Adapter: Send
    Adapter-->>Dispatch: Delivery result
    Dispatch->>Store: Persist delivery
```

---

### 78. Sequence Diagram — Incident Transition

```mermaid
sequenceDiagram
    participant UI as Incident UI
    participant API as IncidentController
    participant Auth as RBAC/Scope
    participant Service as IncidentService
    participant Repo as IncidentRepository
    participant Timeline as TimelineRepository
    participant Audit as Audit Service
    participant Notify as Notification Service

    UI->>API: POST transition
    API->>Auth: Validate permission and scope
    Auth-->>API: Allowed
    API->>Service: transition
    Service->>Repo: Load incident
    Repo-->>Service: Incident
    Service->>Service: Validate transition
    Service->>Repo: Save state
    Service->>Timeline: Append event
    Service->>Audit: Record transition
    Service->>Notify: Notify interested parties
    Service-->>API: Updated incident
    API-->>UI: HTTP 200
```

---

### 79. Error Codes

```text
ALERT_NOT_FOUND
ALERT_ACCESS_DENIED
ALERT_TRANSITION_INVALID
ALERT_SUPPRESSION_INVALID
ALERT_RULE_INVALID
ALERT_ROUTE_NOT_FOUND
ALERT_ROUTE_CONFLICT
ALERT_OWNER_NOT_FOUND
NOTIFICATION_ADAPTER_NOT_FOUND
NOTIFICATION_DELIVERY_FAILED
NOTIFICATION_RETRY_EXHAUSTED
NOTIFICATION_IDEMPOTENCY_CONFLICT
ON_CALL_SCHEDULE_NOT_FOUND
ON_CALL_COVERAGE_GAP
ON_CALL_OVERRIDE_INVALID
INCIDENT_NOT_FOUND
INCIDENT_ACCESS_DENIED
INCIDENT_TRANSITION_INVALID
INCIDENT_ASSIGNMENT_INVALID
INCIDENT_TIMELINE_APPEND_FAILED
INCIDENT_POSTMORTEM_REQUIRED
INCIDENT_CLOSURE_BLOCKED
```

---

### 80. Logging

```json
{
  "event": "notification_delivery_attempted",
  "delivery_id": "01J...",
  "event_type": "ALERT_FIRING",
  "channel": "TEAMS",
  "status": "SENT",
  "attempt_number": 1,
  "latency_ms": 132,
  "severity": "SEV1"
}
```

---

### 81. Telemetry

```text
notification_delivery_total
notification_delivery_success_total
notification_delivery_failure_total
notification_retry_total
notification_dead_letter_total
notification_latency_ms
on_call_coverage_gap_total
on_call_override_total
incident_api_request_total
incident_transition_error_total
alert_api_request_total
```

---

### 82. Security Controls

- Adapter credential disimpan di secret store.
- Delivery payload disanitasi.
- Restricted classification hanya ke approved channel.
- Webhook menggunakan signature.
- Retry tidak membocorkan payload ke log.
- On-call contact tidak tampil pada public response.
- API enforce tenant/scope.
- Timeline append-only.
- Notification replay membutuhkan permission.
- Dead-letter access dibatasi.

---

### 83. Webhook Security

Webhook wajib:

- HTTPS;
- signature;
- timestamp;
- replay protection;
- timeout;
- allowlist destination;
- secret rotation;
- bounded payload;
- no PHI/secret.

---

### 84. Email Security

- sender domain terverifikasi;
- TLS;
- restricted data minimal;
- no raw attachment by default;
- secure link untuk evidence;
- recipient validation.

---

### 85. Chat Adapter Security

- workspace/team allowlist;
- channel allowlist;
- bot token secret store;
- restricted incident ke private channel;
- message edit/update policy;
- rate limit.

---

### 86. Performance Targets

| Area | Target |
|---|---:|
| Alert list cached | < 500 ms |
| Alert acknowledge | < 500 ms |
| Incident list | < 750 ms |
| Incident transition | < 750 ms |
| Timeline append | < 500 ms |
| Route resolution | < 100 ms |
| On-call resolution | < 100 ms |
| Notification dispatch enqueue | < 200 ms |

Actual external delivery mengikuti provider.

---

### 87. Testing Strategy

#### Unit

- route matching;
- on-call resolution;
- idempotency;
- retry classification;
- state transitions;
- tenant scope;
- template escaping.

#### Integration

- PDO repositories;
- notification adapter;
- webhook signature;
- scheduler jobs;
- API contracts;
- audit events;
- dead-letter replay.

#### Security

- cross-tenant access;
- restricted classification;
- CSRF;
- rate limit;
- secret leakage;
- replay attack;
- webhook forgery.

---

### 88. UAT Part 4

#### Notification

- [ ] Adapter dapat didaftarkan.
- [ ] Idempotency mencegah duplicate.
- [ ] Retry transient bekerja.
- [ ] Permanent failure tidak di-retry tanpa batas.
- [ ] Dead-letter tercatat.
- [ ] Fallback channel bekerja.
- [ ] Classification membatasi channel.

#### On-Call

- [ ] Active shift dapat di-resolve.
- [ ] Override bekerja.
- [ ] Coverage gap terdeteksi.
- [ ] Inactive user ditolak.
- [ ] Fallback owner tersedia.
- [ ] Contact detail tidak bocor.

#### Alert API

- [ ] Alert list terfilter.
- [ ] Alert detail aman.
- [ ] Acknowledge bekerja.
- [ ] Suppression membutuhkan expiry.
- [ ] Resolve membutuhkan permission.
- [ ] Cross-tenant access ditolak.

#### Incident API

- [ ] Incident dapat dibuat.
- [ ] Transition valid bekerja.
- [ ] Transition invalid ditolak.
- [ ] Assignment bekerja.
- [ ] Timeline append-only.
- [ ] Close blocked jika requirement belum lengkap.

#### Database

- [ ] Migration berhasil.
- [ ] Foreign key valid.
- [ ] Index mendukung query utama.
- [ ] Tenant/scope query terisolasi.
- [ ] Timeline tidak dapat dihapus melalui API umum.
- [ ] Idempotency key unik.

#### Scheduler

- [ ] Rule evaluation berjalan.
- [ ] Escalation berjalan.
- [ ] Retry berjalan.
- [ ] Coverage validation berjalan.
- [ ] SLA monitor berjalan.
- [ ] Suppression expiry berjalan.

#### Security

- [ ] Secret tidak muncul di log.
- [ ] Webhook signature valid.
- [ ] Replay protection bekerja.
- [ ] Restricted incident hanya ke channel aman.
- [ ] Notification replay diaudit.
- [ ] CSRF dan rate limit aktif.

#### Apache/XAMPP

- [ ] Front controller route bekerja.
- [ ] Directory listing nonaktif.
- [ ] API route dapat diakses.
- [ ] Error log tersedia.
- [ ] Static files tetap berjalan.

---

### 89. Anti-Pattern

Hindari:

- controller mengirim email langsung;
- adapter credential di config plaintext;
- retry tanpa idempotency;
- delivery failure menghapus alert;
- on-call tanpa fallback;
- schedule tanpa timezone;
- suppression tanpa expiry;
- raw contact detail di API;
- timeline update/delete;
- webhook tanpa signature;
- dead-letter tanpa monitor;
- route wildcard untuk security alert;
- public URL untuk restricted evidence;
- notification payload berisi PHI.

---

### 90. Definition of Done Part 4

Part 4 dianggap selesai bila:

- [ ] notification adapter contract tersedia;
- [ ] delivery result tersedia;
- [ ] idempotency tersedia;
- [ ] retry dan dead-letter tersedia;
- [ ] fallback routing tersedia;
- [ ] template safety tersedia;
- [ ] classification matrix tersedia;
- [ ] on-call model tersedia;
- [ ] rotation dan override tersedia;
- [ ] coverage validation tersedia;
- [ ] alert API tersedia;
- [ ] incident API tersedia;
- [ ] postmortem/action item API tersedia;
- [ ] on-call API tersedia;
- [ ] controller standard tersedia;
- [ ] middleware order tersedia;
- [ ] permission tersedia;
- [ ] database schema tersedia;
- [ ] scheduler jobs tersedia;
- [ ] audit integration tersedia;
- [ ] Apache/XAMPP routing tersedia;
- [ ] sequence diagram tersedia;
- [ ] UAT tersedia.

---

### 91. Rencana Part Berikutnya

#### Part 5

Reference implementation end-to-end, sample rules, sample routes, notification adapters, incident simulation, deployment, rollback, operational runbook, performance test, final UAT, Definition of Done, roadmap, dan merge guidance menjadi `SSOT-OBS-07.md`.

---

## Bagian V — Reference Implementation, Deployment, Simulation, Final UAT & Merge Guidance

### 1. Executive Summary

Part 5 menutup rangkaian SSOT-OBS-07 dengan reference implementation Alerting & Incident Management Framework.

Bagian ini mencakup:

- bootstrap wiring;
- sample alert rules;
- sample routes;
- sample notification adapters;
- sample on-call configuration;
- alert manager;
- incident service;
- scheduler wiring;
- deployment;
- rollback;
- performance test;
- incident simulation;
- operational runbook;
- final UAT;
- Definition of Done;
- roadmap;
- merge guidance menjadi `SSOT-OBS-07.md`.

Target implementasi awal adalah framework yang:

- mendeteksi kondisi abnormal;
- mengurangi alert noise;
- menentukan owner;
- mengirim notification;
- menjalankan escalation;
- membuat incident;
- menjaga timeline;
- memvalidasi recovery;
- mendukung postmortem;
- tetap aman untuk multi-tenant platform.

---

### 2. Initial Implementation Scope

Initial release wajib mencakup:

```text
Alert Rule Registry
Alert Rule Engine
Alert Manager
Deduplication
Grouping
Suppression
Routing
Escalation
Notification Dispatcher
Email/Webhook Adapter
On-Call Resolver
Incident Service
Timeline
Postmortem
Action Items
Alert/Incident API
Scheduler Jobs
Audit Integration
```

Initial rule set:

```text
database_down
http_error_rate_high
http_p95_latency_high
queue_backlog_high
scheduler_heartbeat_stale
integration_failure_rate_high
storage_usage_critical
notification_delivery_failure
```

---

### 3. Final Folder Structure

```text
app/
└── Platform/
    └── Observability/
        └── Alerting/
            ├── Domain/
            │   ├── Alert.php
            │   ├── AlertRule.php
            │   ├── AlertSignal.php
            │   ├── AlertEvaluationResult.php
            │   ├── AlertGroup.php
            │   ├── AlertRoute.php
            │   ├── AlertSuppression.php
            │   ├── Incident.php
            │   ├── IncidentAssignment.php
            │   ├── IncidentTimelineEvent.php
            │   ├── IncidentPostmortem.php
            │   └── IncidentActionItem.php
            │
            ├── Application/
            │   ├── AlertRuleRegistry.php
            │   ├── AlertRuleEngine.php
            │   ├── AlertManager.php
            │   ├── AlertRouter.php
            │   ├── AlertEscalationService.php
            │   ├── NotificationDispatcher.php
            │   ├── OnCallResolver.php
            │   ├── IncidentService.php
            │   ├── IncidentTimelineService.php
            │   ├── IncidentPostmortemService.php
            │   └── Contracts/
            │
            ├── Infrastructure/
            │   ├── Persistence/
            │   ├── Notification/
            │   ├── Scheduler/
            │   ├── Security/
            │   ├── Audit/
            │   └── Telemetry/
            │
            └── Presentation/
                ├── Http/
                └── Cli/

config/
├── alerting.php
├── alert-rules.php
├── alert-routes.php
├── escalation-policies.php
└── on-call.php

database/
└── migrations/
    └── create_alerting_incident_tables.sql

resources/
├── notification-templates/
└── runbooks/

tests/
├── Unit/
├── Integration/
└── Uat/

tools/
├── alert-rule-replay.php
├── alert-simulation.php
└── incident-simulation.php
```

---

### 4. Bootstrap Wiring

```php
<?php

declare(strict_types=1);

namespace App\Platform\Observability\Alerting;

final class AlertingBootstrap
{
    public static function build(
        array $config,
        object $container
    ): AlertingKernel {
        $ruleRegistry = new AlertRuleRegistry();
        $routeRegistry = new AlertRouteRegistry();
        $escalationRegistry = new AlertEscalationPolicyRegistry();
        $adapterRegistry = new NotificationAdapterRegistry();

        foreach ($config['rule_registrars'] as $registrarClass) {
            $container->get($registrarClass)->register($ruleRegistry);
        }

        foreach ($config['route_registrars'] as $registrarClass) {
            $container->get($registrarClass)->register($routeRegistry);
        }

        foreach ($config['notification_adapters'] as $adapterClass) {
            $adapterRegistry->register(
                $container->get($adapterClass)
            );
        }

        $ruleEngine = new AlertRuleEngine(
            registry: $ruleRegistry,
            telemetry: $container->get('alerting.telemetry')
        );

        $router = new AlertRouter(
            routes: $routeRegistry,
            onCall: $container->get('alerting.on_call_resolver'),
            access: $container->get('alerting.access_policy')
        );

        $dispatcher = new NotificationDispatcher(
            adapters: $adapterRegistry,
            deliveries: $container->get('alerting.delivery_repository'),
            templates: $container->get('alerting.template_renderer'),
            telemetry: $container->get('alerting.telemetry')
        );

        $alertManager = new AlertManager(
            alerts: $container->get('alerting.alert_repository'),
            occurrences: $container->get('alerting.occurrence_repository'),
            fingerprint: $container->get('alerting.fingerprint_service'),
            grouping: $container->get('alerting.grouping_service'),
            suppressions: $container->get('alerting.suppression_service'),
            router: $router,
            dispatcher: $dispatcher,
            incidents: $container->get('alerting.incident_service'),
            audit: $container->get('audit.service'),
            telemetry: $container->get('alerting.telemetry')
        );

        return new AlertingKernel(
            ruleEngine: $ruleEngine,
            alertManager: $alertManager,
            incidentService: $container->get('alerting.incident_service'),
            escalationService: $container->get(
                'alerting.escalation_service'
            ),
            notificationDispatcher: $dispatcher
        );
    }
}
```

---

### 5. AlertRule Registry Contract

```php
interface AlertRuleRegistrarInterface
{
    public function register(
        AlertRuleRegistryInterface $registry
    ): void;
}
```

Module bisnis dapat mendaftarkan rule tanpa mengubah Platform Kernel.

---

### 6. Sample Rule — Database Down

```php
<?php

return [
    'code' => 'database_down',
    'title' => 'Database Unavailable',
    'description' => 'Primary database health state is DOWN.',
    'source_type' => 'HEALTH',
    'source_reference' => 'database',
    'rule_type' => 'STATE',
    'expression' => [
        'field' => 'status',
        'comparison' => 'equal',
        'value' => 'DOWN',
    ],
    'evaluation_window' => '1m',
    'evaluation_interval_seconds' => 15,
    'pending_duration_seconds' => 30,
    'minimum_samples' => 2,
    'severity' => 'SEV1',
    'owner_team' => 'platform_operations',
    'fingerprint_fields' => [
        'rule_code',
        'environment',
        'component',
    ],
    'grouping_fields' => [
        'environment',
        'dependency',
    ],
    'cooldown_seconds' => 600,
    'recovery' => [
        'status' => 'UP',
        'consecutive_samples' => 3,
    ],
    'runbook_reference' => 'runbook://database/unavailable',
    'auto_incident' => true,
    'enabled' => true,
    'version' => '1.0',
];
```

---

### 7. Sample Rule — HTTP Error Rate

```php
return [
    'code' => 'http_error_rate_high',
    'title' => 'HTTP Error Rate High',
    'source_type' => 'METRIC',
    'source_reference' => 'platform_error_rate_percent',
    'rule_type' => 'THRESHOLD',
    'expression' => [
        'comparison' => 'greater_than_or_equal',
        'warning' => 1.0,
        'critical' => 5.0,
    ],
    'evaluation_window' => '5m',
    'evaluation_interval_seconds' => 60,
    'pending_duration_seconds' => 300,
    'minimum_samples' => 100,
    'severity' => 'SEV2',
    'owner_team' => 'platform_operations',
    'fingerprint_fields' => [
        'rule_code',
        'environment',
        'tenant_id',
        'module_code',
    ],
    'grouping_fields' => [
        'service',
        'deployment',
    ],
    'cooldown_seconds' => 900,
    'recovery' => [
        'comparison' => 'less_than',
        'value' => 0.5,
        'duration_seconds' => 300,
    ],
    'runbook_reference' => 'runbook://platform/http-error-rate',
    'auto_incident' => false,
    'enabled' => true,
    'version' => '1.0',
];
```

---

### 8. Sample Rule — Scheduler Heartbeat Stale

```php
return [
    'code' => 'scheduler_heartbeat_stale',
    'title' => 'Scheduler Heartbeat Stale',
    'source_type' => 'METRIC',
    'source_reference' => 'scheduler_last_heartbeat_age_seconds',
    'rule_type' => 'STALE',
    'expression' => [
        'comparison' => 'greater_than_or_equal',
        'value' => 300,
    ],
    'evaluation_window' => '5m',
    'evaluation_interval_seconds' => 60,
    'pending_duration_seconds' => 60,
    'minimum_samples' => 1,
    'severity' => 'SEV2',
    'owner_team' => 'platform_operations',
    'fingerprint_fields' => [
        'rule_code',
        'environment',
        'scheduler',
    ],
    'grouping_fields' => [
        'environment',
        'scheduler',
    ],
    'cooldown_seconds' => 900,
    'recovery' => [
        'comparison' => 'less_than',
        'value' => 120,
        'consecutive_samples' => 2,
    ],
    'runbook_reference' => 'runbook://scheduler/heartbeat-stale',
    'enabled' => true,
    'version' => '1.0',
];
```

---

### 9. Sample Route — Critical Platform

```php
return [
    'code' => 'critical_platform',
    'matchers' => [
        'environment' => ['production'],
        'severity' => ['SEV0', 'SEV1'],
        'classification' => [
            'INTERNAL',
            'CONFIDENTIAL',
            'RESTRICTED',
        ],
    ],
    'owner_reference' => 'oncall://platform_operations',
    'channels' => [
        'PAGER',
        'TEAMS',
        'EMAIL',
    ],
    'escalation_policy' => 'critical_platform',
    'fallback_route' => 'operations_fallback',
    'priority' => 100,
    'enabled' => true,
];
```

---

### 10. Sample Route — Tenant Operational

```php
return [
    'code' => 'tenant_operational',
    'matchers' => [
        'environment' => ['production'],
        'scope_type' => ['tenant'],
        'severity' => ['SEV2', 'SEV3'],
    ],
    'owner_reference' => 'tenant_operations',
    'channels' => [
        'DASHBOARD',
        'EMAIL',
        'TEAMS',
    ],
    'escalation_policy' => 'tenant_standard',
    'fallback_route' => 'platform_operations',
    'priority' => 50,
    'enabled' => true,
];
```

---

### 11. Sample Escalation Policy

```php
return [
    'code' => 'critical_platform',
    'ack_deadline_seconds' => 600,
    'steps' => [
        [
            'level' => 1,
            'delay_seconds' => 0,
            'target' => 'oncall://platform_operations',
            'channels' => ['PAGER', 'TEAMS'],
        ],
        [
            'level' => 2,
            'delay_seconds' => 600,
            'target' => 'role://platform_operations_lead',
            'channels' => ['PAGER', 'SMS'],
        ],
        [
            'level' => 3,
            'delay_seconds' => 1200,
            'target' => 'role://operations_manager',
            'channels' => ['SMS', 'VOICE'],
        ],
    ],
    'maximum_level' => 3,
    'repeat_seconds' => 900,
];
```

---

### 12. Sample On-Call Configuration

```php
return [
    'code' => 'platform_operations',
    'title' => 'Platform Operations On-Call',
    'team_code' => 'platform_operations',
    'timezone' => 'Asia/Jakarta',
    'rotation_type' => 'WEEKLY',
    'handover_time' => '09:00:00',
    'participants' => [
        101,
        102,
        103,
    ],
    'secondary_participants' => [
        201,
        202,
    ],
    'escalation_policy' => 'critical_platform',
    'enabled' => true,
];
```

---

### 13. Sample Email Adapter

```php
final class EmailNotificationAdapter
    implements NotificationChannelAdapterInterface
{
    public function __construct(
        private readonly MailerInterface $mailer
    ) {
    }

    public function channel(): string
    {
        return 'EMAIL';
    }

    public function supports(
        NotificationMessage $message
    ): bool {
        return in_array(
            $message->classification,
            ['INTERNAL', 'CONFIDENTIAL', 'RESTRICTED'],
            true
        );
    }

    public function send(
        NotificationMessage $message,
        NotificationDeliveryContext $context
    ): NotificationDeliveryResult {
        try {
            $reference = $this->mailer->send(
                recipients: $message->recipients,
                subject: $message->title,
                body: $message->body
            );

            return new NotificationDeliveryResult(
                status: 'SENT',
                channel: 'EMAIL',
                providerReference: $reference,
                errorCode: null,
                errorMessage: null,
                attemptedAt: new \DateTimeImmutable()
            );
        } catch (TransientMailerException $exception) {
            return new NotificationDeliveryResult(
                status: 'RETRYING',
                channel: 'EMAIL',
                providerReference: null,
                errorCode: 'MAILER_TRANSIENT_FAILURE',
                errorMessage: 'Email provider is temporarily unavailable.',
                attemptedAt: new \DateTimeImmutable()
            );
        } catch (\Throwable $exception) {
            return new NotificationDeliveryResult(
                status: 'FAILED',
                channel: 'EMAIL',
                providerReference: null,
                errorCode: 'MAILER_PERMANENT_FAILURE',
                errorMessage: 'Email delivery failed.',
                attemptedAt: new \DateTimeImmutable()
            );
        }
    }
}
```

---

### 14. Sample Webhook Adapter

```php
final class SignedWebhookNotificationAdapter
    implements NotificationChannelAdapterInterface
{
    public function __construct(
        private readonly HttpClientInterface $http,
        private readonly WebhookDestinationRegistryInterface $destinations,
        private readonly WebhookSignerInterface $signer
    ) {
    }

    public function channel(): string
    {
        return 'WEBHOOK';
    }

    public function supports(
        NotificationMessage $message
    ): bool {
        return $message->classification !== 'SECURITY_RESTRICTED';
    }

    public function send(
        NotificationMessage $message,
        NotificationDeliveryContext $context
    ): NotificationDeliveryResult {
        $destination = $this->destinations->get(
            $context->destinationReference
        );

        $payload = [
            'message_id' => $message->messageId,
            'event_type' => $message->eventType,
            'severity' => $message->severity,
            'title' => $message->title,
            'body' => $message->body,
            'created_at' => $message->createdAt->format(DATE_ATOM),
        ];

        $timestamp = time();
        $body = json_encode($payload, JSON_THROW_ON_ERROR);
        $signature = $this->signer->sign($body, $timestamp);

        $response = $this->http->post(
            $destination->url,
            [
                'Content-Type' => 'application/json',
                'X-Webhook-Timestamp' => (string) $timestamp,
                'X-Webhook-Signature' => $signature,
            ],
            $body,
            timeoutSeconds: 5
        );

        return new NotificationDeliveryResult(
            status: $response->isSuccessful() ? 'SENT' : 'RETRYING',
            channel: 'WEBHOOK',
            providerReference: $response->requestId(),
            errorCode: $response->isSuccessful()
                ? null
                : 'WEBHOOK_DELIVERY_FAILED',
            errorMessage: $response->isSuccessful()
                ? null
                : 'Webhook destination did not accept the message.',
            attemptedAt: new \DateTimeImmutable()
        );
    }
}
```

---

### 15. Alert Manager Reference Flow

```php
final class AlertManager implements AlertManagerInterface
{
    public function process(
        AlertRule $rule,
        AlertEvaluationResult $result,
        AlertEvaluationContext $context
    ): Alert {
        $fingerprint = $this->fingerprint->create(
            $rule,
            $result,
            $context
        );

        $existing = $this->alerts->findActiveByFingerprint(
            $fingerprint
        );

        if ($existing !== null) {
            $alert = $existing->recordOccurrence(
                value: $result->value,
                observedAt: $result->evaluatedAt
            );
        } else {
            $alert = Alert::fire(
                rule: $rule,
                result: $result,
                context: $context,
                fingerprint: $fingerprint
            );
        }

        $suppression = $this->suppressions->resolve(
            $alert,
            $context
        );

        if ($suppression !== null) {
            $alert = $alert->suppress(
                $suppression->type,
                $suppression->reason
            );
        }

        $this->alerts->save($alert);

        if (!$alert->isSuppressed()) {
            $route = $this->router->route(
                $alert,
                AlertRoutingContext::from($context)
            );

            $this->dispatcher->dispatchAlert(
                $alert,
                $route
            );
        }

        if ($rule->autoIncident && $alert->requiresIncident()) {
            $this->incidents->declareFromAlert($alert, $context);
        }

        $this->audit->record(
            'OBS_ALERT_STATE_CHANGED',
            [
                'alert_id' => $alert->id,
                'state' => $alert->state,
                'severity' => $alert->severity,
            ]
        );

        return $alert;
    }
}
```

---

### 16. Incident Service Reference Flow

```php
final class IncidentService implements IncidentServiceInterface
{
    public function declare(
        IncidentDeclarationCommand $command,
        IncidentContext $context
    ): Incident {
        $this->access->assertCanDeclare($context);

        $incident = Incident::declare(
            id: $this->ids->ulid(),
            number: $this->numbers->next(),
            title: $command->title,
            description: $command->description,
            sourceType: $command->sourceType,
            sourceReference: $command->sourceReference,
            severity: $command->severity,
            environment: $context->environment,
            tenantId: $context->tenantId,
            scopeId: $context->scopeId,
            moduleCode: $context->moduleCode,
            ownerTeam: $command->ownerTeam,
            createdBy: $context->actorUserId
        );

        $this->incidents->save($incident);

        $this->timeline->append(
            IncidentTimelineEventFactory::declared(
                $incident,
                $context
            )
        );

        foreach ($command->alertIds as $alertId) {
            $this->links->link(
                incidentId: $incident->id,
                alertId: $alertId,
                linkType: 'PRIMARY'
            );
        }

        $this->audit->record(
            'OBS_INCIDENT_DECLARED',
            [
                'incident_id' => $incident->id,
                'incident_number' => $incident->number,
                'severity' => $incident->severity,
            ]
        );

        return $incident;
    }
}
```

---

### 17. Scheduler Wiring

```php
$scheduler->everyMinute(
    'alert:escalate',
    AlertEscalationJob::class
);

$scheduler->everyMinute(
    'notification:retry',
    NotificationRetryJob::class
);

$scheduler->everyFiveMinutes(
    'notification:dead-letter-monitor',
    NotificationDeadLetterMonitorJob::class
);

$scheduler->everyMinute(
    'incident:sla-monitor',
    IncidentSlaMonitorJob::class
);

$scheduler->everyFiveMinutes(
    'incident:communication-monitor',
    IncidentCommunicationMonitorJob::class
);

$scheduler->dailyAt(
    '00:30',
    'on-call:materialize',
    OnCallShiftMaterializationJob::class
);

$scheduler->everyFifteenMinutes(
    'on-call:coverage-check',
    OnCallCoverageValidationJob::class
);

$scheduler->dailyAt(
    '08:00',
    'incident:postmortem-overdue',
    PostmortemOverdueMonitorJob::class
);

$scheduler->dailyAt(
    '08:15',
    'incident:action-item-overdue',
    IncidentActionItemOverdueJob::class
);
```

---

### 18. Windows Task Scheduler

Untuk XAMPP/Windows:

```bat
D:\xampp\php\php.exe D:\xampp\htdocs\platform\bin\console scheduler:run
```

Schedule:

```text
Repeat task every: 1 minute
Duration: Indefinitely
Run whether user is logged on or not
```

---

### 19. Initial Migration Order

```text
1. alert_rules
2. alert_routes
3. alert_escalation_policies
4. alert_escalation_steps
5. alerts
6. alert_occurrences
7. alert_groups
8. alert_group_members
9. alert_suppressions
10. notification_deliveries
11. notification_delivery_attempts
12. on_call_schedules
13. on_call_shifts
14. on_call_overrides
15. incidents
16. incident_assignments
17. incident_timeline_events
18. incident_alert_links
19. incident_evidence
20. incident_postmortems
21. incident_action_items
```

---

### 20. Seed Permissions

```text
observability.alert.read
observability.alert.acknowledge
observability.alert.suppress
observability.alert.resolve
observability.alert.reopen
observability.alert.manage
observability.alert.rule.read
observability.alert.rule.manage
observability.alert.route.manage
observability.alert.notification.retry
observability.incident.read
observability.incident.create
observability.incident.assign
observability.incident.command
observability.incident.update
observability.incident.resolve
observability.incident.close
observability.incident.reopen
observability.incident.merge
observability.incident.split
observability.incident.timeline.write
observability.incident.evidence.read
observability.incident.evidence.write
observability.incident.communication.manage
observability.incident.postmortem.manage
observability.incident.action_item.manage
observability.incident.security.read
observability.incident.cross_tenant.read
observability.on_call.read
observability.on_call.manage
observability.on_call.override
```

---

### 21. Role Mapping

| Role | Permission Utama |
|---|---|
| Platform Admin | seluruh alert, incident, on-call |
| Operations Admin | operational alert/incident |
| Security Admin | security alert/incident |
| Tenant Admin | tenant sendiri |
| Module Owner | module terkait |
| Support | read/ack terbatas |
| Incident Commander | command/update/resolve |
| Executive | incident summary |
| End User | tidak ada akses teknis |

---

### 22. Deployment Checklist

#### Pre-Deployment

- [ ] Backup database tersedia.
- [ ] Migration direview.
- [ ] Alert rules divalidasi.
- [ ] Routes tidak konflik.
- [ ] On-call coverage lengkap.
- [ ] Notification credentials tersedia di secret store.
- [ ] Webhook destination di-allowlist.
- [ ] Runbook SEV0–SEV2 tersedia.
- [ ] Permission seed siap.
- [ ] Unit test lulus.
- [ ] Integration test lulus.
- [ ] Security review lulus.
- [ ] Dry-run rules lulus.

#### Deployment

1. Aktifkan maintenance bila diperlukan.
2. Deploy code.
3. Jalankan migration.
4. Seed permission.
5. Register rule, route, adapter, dan on-call.
6. Jalankan validation command.
7. Aktifkan rules dalam shadow mode.
8. Verifikasi scheduler.
9. Verifikasi notification channel.
10. Verifikasi tenant/scope.
11. Verifikasi incident API.
12. Aktifkan production rules bertahap.
13. Nonaktifkan maintenance.

#### Post-Deployment

- [ ] Rule evaluation berjalan.
- [ ] Tidak ada duplicate rule code.
- [ ] Tidak ada conflicting route.
- [ ] On-call resolver menghasilkan owner.
- [ ] Notification idempotency bekerja.
- [ ] Audit event tercatat.
- [ ] Alert dashboard aktif.
- [ ] Incident dashboard aktif.
- [ ] Scheduler tidak backlog.
- [ ] Tidak ada secret pada log.

---

### 23. Rule Activation Strategy

Tahapan:

```text
DRAFT
→ REVIEW
→ SHADOW
→ CANARY
→ ACTIVE
```

#### Shadow

- evaluasi berjalan;
- alert hypothetical dicatat;
- tidak ada notification.

#### Canary

- subset environment/module/tenant;
- limited delivery;
- monitoring false positive.

#### Active

- full production routing.

---

### 24. Rollback Plan

1. Disable affected rules.
2. Stop notification dispatcher bila storm terjadi.
3. Keep alert/incident data intact.
4. Rollback code.
5. Restore previous config.
6. Clear incompatible cache.
7. Restore notification adapter version.
8. Verify scheduler.
9. Verify incident access.
10. Re-enable rules in shadow mode.

Schema sebaiknya forward-compatible.

---

### 25. Emergency Kill Switch

Config:

```text
ALERTING_ENABLED=true
NOTIFICATION_ENABLED=true
AUTO_INCIDENT_ENABLED=true
ESCALATION_ENABLED=true
```

Kill switch hanya untuk emergency.

Penggunaan wajib:

- permission;
- reason;
- audit;
- expiry/review;
- compensating monitoring.

---

### 26. Performance Test Plan

Test scenarios:

```text
100 signal/menit
1.000 signal/menit
10.000 signal/menit
alert storm
notification provider latency
database degraded
cross-tenant concurrent query
```

---

### 27. Performance Acceptance

| Area | Target p95 |
|---|---:|
| Rule evaluation sederhana | < 50 ms |
| Alert deduplication | < 100 ms |
| Route resolution | < 100 ms |
| On-call resolution | < 100 ms |
| Notification enqueue | < 200 ms |
| Alert acknowledge API | < 500 ms |
| Incident transition API | < 750 ms |
| Timeline append | < 500 ms |
| Alert list | < 750 ms |
| Incident list | < 1000 ms |

External delivery mengikuti provider.

---

### 28. Alert Storm Test

Input:

```text
10.000 occurrence dengan 100 fingerprint unik
```

Expected:

- 100 active alert, bukan 10.000;
- occurrence count meningkat;
- notification rate terbatas;
- grouping aktif;
- scheduler tetap responsif;
- dead-letter terkendali;
- dashboard tetap dapat dibuka.

---

### 29. Failure Injection Test

Simulasikan:

- email provider timeout;
- webhook 500;
- database deadlock;
- cache unavailable;
- on-call schedule gap;
- invalid route;
- duplicate message;
- scheduler delay;
- cross-tenant request;
- restricted payload to public channel.

---

### 30. Simulation — Database Outage

#### Initial Condition

```text
database health = UP
alert state = none
```

#### Trigger

```text
database health = DOWN for 30 seconds
```

#### Expected Flow

1. Rule `database_down` menjadi PENDING.
2. Setelah pending duration, alert FIRING.
3. Fingerprint dibuat.
4. Route `critical_platform` dipilih.
5. Active on-call di-resolve.
6. Pager/Teams/Email dikirim.
7. Escalation timer dibuat.
8. Incident SEV1 otomatis dibuat.
9. Incident Commander ditetapkan.
10. Timeline mencatat declaration.
11. Runbook database outage ditautkan.

#### Recovery

```text
database health = UP for 3 consecutive probes
```

Expected:

- alert RESOLVED;
- incident masuk MONITORING;
- synthetic transaction berhasil;
- incident RECOVERED;
- monitoring minimum terpenuhi;
- incident RESOLVED;
- postmortem required.

---

### 31. Simulation — HTTP Error Rate

#### Trigger

```text
error rate = 6%
request count = 1.000
duration = 5 minutes
```

Expected:

- alert SEV2 FIRING;
- owner Platform Operations;
- route chat + email;
- no duplicate alert;
- occurrence updated;
- incident optional/manual.

Jika error rate naik menjadi 25% dan multi-tenant:

- severity reassessed;
- incident SEV1 dibuat;
- paging diaktifkan.

---

### 32. Simulation — Alert Storm

Trigger:

```text
database DOWN
queue backlog
HTTP latency
integration timeout
workflow failure
```

Expected:

- database alert classified ROOT;
- lainnya SYMPTOM/CORRELATED;
- alert group dibuat;
- only root paging utama;
- one incident;
- symptom alerts tetap terlihat;
- no notification flood.

---

### 33. Simulation — Notification Provider Down

Expected:

1. delivery attempt gagal;
2. status RETRYING;
3. exponential backoff;
4. fallback channel;
5. dead-letter setelah retry habis;
6. internal notification pipeline alert;
7. alert utama tetap aktif;
8. no duplicate send due to idempotency.

---

### 34. Simulation — On-Call Coverage Gap

Expected:

- coverage validator mendeteksi gap;
- alert `on_call_coverage_gap` dibuat;
- fallback owner Platform Operations Manager;
- restricted contact details tidak bocor;
- override dibuat dan diaudit.

---

### 35. Simulation — Cross-Tenant Access

Request:

```text
Tenant Admin A membuka incident Tenant B
```

Expected:

```text
HTTP 403
```

Selain itu:

- audit access denied;
- no incident metadata leaked;
- no cache leak;
- no tenant name returned.

---

### 36. Simulation — Security Incident

Trigger:

```text
privileged credential compromise suspected
```

Expected:

- classification SECURITY_RESTRICTED;
- route security on-call;
- private channel only;
- dedicated audit;
- incident SEV1;
- evidence stored in restricted store;
- tenant/general dashboard only shows sanitized status.

---

### 37. Operational Runbook — Alert Not Delivered

1. Cek alert state.
2. Cek suppression.
3. Cek resolved route.
4. Cek on-call owner.
5. Cek delivery record.
6. Cek adapter health.
7. Cek retry schedule.
8. Cek dead-letter.
9. Jalankan controlled replay.
10. Dokumentasikan result.

---

### 38. Operational Runbook — Excessive Alert Noise

1. Identifikasi top fingerprint.
2. Verifikasi root cause.
3. Cek duplicate/grouping.
4. Cek minimum samples.
5. Cek hysteresis/cooldown.
6. Aktifkan bounded suppression bila aman.
7. Tune rule di shadow mode.
8. Review owner/runbook.
9. Catat false positive.
10. Audit rule change.

---

### 39. Operational Runbook — Incident Cannot Close

1. Cek state saat ini.
2. Cek recovery evidence.
3. Cek open critical alert.
4. Cek missing timeline.
5. Cek postmortem requirement.
6. Cek communication closure.
7. Cek action items.
8. Lengkapi requirement.
9. Retry close.
10. Audit override bila policy mengizinkan.

---

### 40. Backup & Restore

Backup:

- rules;
- routes;
- escalation policies;
- suppressions;
- on-call schedules;
- alerts;
- incidents;
- timeline;
- postmortems;
- action items;
- delivery records;
- audit references.

Restore wajib menguji:

- foreign keys;
- state consistency;
- tenant ownership;
- route references;
- on-call references;
- incident links;
- timeline ordering;
- idempotency uniqueness.

---

### 41. Retention

| Data | Retention |
|---|---|
| Alert records | 1–3 tahun |
| Alert occurrences | 90 hari–1 tahun |
| Notification deliveries | 90 hari–1 tahun |
| Dead-letter payload | 7–30 hari |
| On-call shifts | 1–3 tahun |
| Incident records | 5–7 tahun |
| Timeline | sama dengan incident |
| Postmortem | 5–7 tahun |
| Action items | 2–5 tahun |
| Security evidence | policy/legal hold |

---

### 42. Final UAT — Alerting Core

- [ ] Rule Registry bekerja.
- [ ] Rule Engine bekerja.
- [ ] Pending duration bekerja.
- [ ] Minimum samples bekerja.
- [ ] Hysteresis bekerja.
- [ ] Cooldown bekerja.
- [ ] Fingerprint stabil.
- [ ] Deduplication bekerja.
- [ ] Grouping bekerja.
- [ ] Root/symptom classification bekerja.
- [ ] Suppression bekerja.
- [ ] Recovery bekerja.

---

### 43. Final UAT — Routing & Notification

- [ ] Route resolution deterministic.
- [ ] On-call resolution benar.
- [ ] Fallback owner tersedia.
- [ ] Classification membatasi channel.
- [ ] Idempotency mencegah duplicate.
- [ ] Retry transient bekerja.
- [ ] Permanent failure tidak loop.
- [ ] Dead-letter tercatat.
- [ ] Replay membutuhkan permission.
- [ ] Adapter health tersedia.

---

### 44. Final UAT — Incident

- [ ] Incident dapat dibuat otomatis.
- [ ] Incident dapat dibuat manual.
- [ ] Commander dapat ditetapkan.
- [ ] Assignment acceptance bekerja.
- [ ] State transition valid.
- [ ] Invalid transition ditolak.
- [ ] Timeline append-only.
- [ ] Alert link bekerja.
- [ ] Recovery evidence wajib.
- [ ] Resolve dan close berbeda.
- [ ] Reopen diaudit.
- [ ] Merge/split tersedia.

---

### 45. Final UAT — Postmortem

- [ ] SEV0/SEV1 mewajibkan postmortem.
- [ ] Root cause dapat dicatat.
- [ ] Contributing factors tersedia.
- [ ] Action item memiliki owner.
- [ ] Due date tersedia.
- [ ] Approval bekerja.
- [ ] Overdue monitor bekerja.
- [ ] Blameless template digunakan.

---

### 46. Final UAT — Security

- [ ] Tenant isolation aktif.
- [ ] Scope isolation aktif.
- [ ] Security incident restricted.
- [ ] Cross-tenant read membutuhkan permission.
- [ ] Evidence sensitif memakai secure reference.
- [ ] Webhook signed.
- [ ] Secret tidak muncul pada log.
- [ ] Suppression/override diaudit.
- [ ] Timeline tidak dapat dihapus.
- [ ] PHI/PII tidak tampil pada alert umum.

---

### 47. Final UAT — Scheduler

- [ ] Rule evaluation berjalan.
- [ ] Escalation job berjalan.
- [ ] Notification retry berjalan.
- [ ] Dead-letter monitor berjalan.
- [ ] On-call materialization berjalan.
- [ ] Coverage validation berjalan.
- [ ] Incident SLA monitor berjalan.
- [ ] Communication monitor berjalan.
- [ ] Postmortem monitor berjalan.
- [ ] Action item monitor berjalan.
- [ ] Suppression expiry berjalan.

---

### 48. Final UAT — Performance

- [ ] Rule evaluation memenuhi target.
- [ ] Deduplication memenuhi target.
- [ ] Alert storm terkendali.
- [ ] API p95 memenuhi target.
- [ ] Notification enqueue memenuhi target.
- [ ] Scheduler tidak backlog.
- [ ] Query menggunakan index.
- [ ] Tenant filter efisien.
- [ ] Dead-letter bounded.
- [ ] Dashboard tetap responsif saat incident besar.

---

### 49. Production Readiness Checklist

- [ ] Owner setiap rule tersedia.
- [ ] Owner setiap route tersedia.
- [ ] Runbook SEV0–SEV2 tersedia.
- [ ] On-call coverage 24/7 sesuai kebutuhan.
- [ ] Fallback route tersedia.
- [ ] Notification credential aman.
- [ ] Scheduler aktif.
- [ ] Audit aktif.
- [ ] Alert dashboard aktif.
- [ ] Incident dashboard aktif.
- [ ] Dead-letter monitor aktif.
- [ ] Backup/restore diuji.
- [ ] Simulation lulus.
- [ ] Performance test lulus.
- [ ] Security review lulus.
- [ ] Operations sign-off tersedia.

---

### 50. Ownership Matrix

| Area | Owner |
|---|---|
| Alerting Framework | Platform Kernel Team |
| Alert Rules | Domain/Service Owner |
| Route & Escalation | Platform Operations |
| Notification Adapters | Platform Integration |
| On-Call | Team Manager/Operations |
| Incident Management | Platform Operations |
| Security Incidents | Security Team |
| Postmortem Governance | Reliability/Architecture |
| Audit Integration | Security/Compliance |
| Database Schema | Platform Data Team |

---

### 51. Definition of Done — SSOT-OBS-07

#### Architecture

- [ ] alert model;
- [ ] severity;
- [ ] lifecycle;
- [ ] ownership;
- [ ] incident model;
- [ ] incident lifecycle;
- [ ] classification;
- [ ] access policy.

#### Alert Processing

- [ ] rule model;
- [ ] evaluation;
- [ ] pending/minimum sample;
- [ ] hysteresis;
- [ ] cooldown;
- [ ] deduplication;
- [ ] grouping;
- [ ] suppression;
- [ ] routing;
- [ ] escalation;
- [ ] recovery.

#### Incident Management

- [ ] assignment;
- [ ] roles;
- [ ] timeline;
- [ ] communication;
- [ ] runbook;
- [ ] SLA/OLA;
- [ ] root cause;
- [ ] postmortem;
- [ ] action items.

#### Infrastructure

- [ ] notification adapters;
- [ ] idempotency;
- [ ] retry/dead-letter;
- [ ] on-call;
- [ ] HTTP API;
- [ ] database schema;
- [ ] scheduler;
- [ ] audit;
- [ ] Apache/XAMPP routing.

#### Operations

- [ ] deployment;
- [ ] rollback;
- [ ] simulation;
- [ ] performance test;
- [ ] operational runbook;
- [ ] final UAT;
- [ ] production checklist.

---

### 52. Implementation Definition of Done

Implementasi dianggap selesai bila:

- [ ] core classes dibuat;
- [ ] migrations berhasil;
- [ ] initial rules aktif;
- [ ] routes tersedia;
- [ ] notification adapters tersedia;
- [ ] on-call schedule tersedia;
- [ ] alert API tersedia;
- [ ] incident API tersedia;
- [ ] timeline tersedia;
- [ ] postmortem tersedia;
- [ ] scheduler aktif;
- [ ] audit aktif;
- [ ] unit test lulus;
- [ ] integration test lulus;
- [ ] UAT lulus;
- [ ] simulation lulus;
- [ ] performance target tercapai;
- [ ] security review lulus;
- [ ] deployment/rollback diuji.

---

### 53. Roadmap

#### Phase 1 — Foundation

- rule registry;
- threshold/state rules;
- deduplication;
- routing;
- email/chat;
- basic incident.

#### Phase 2 — Reliability

- grouping;
- dependency awareness;
- escalation;
- on-call;
- postmortem;
- SLA monitor.

#### Phase 3 — Advanced Operations

- alert storm handling;
- service dependency graph;
- auto-incident;
- status page integration;
- ticket integration;
- runbook execution tracking.

#### Phase 4 — Intelligence

- anomaly detection;
- event correlation;
- probable root cause;
- automatic severity recommendation;
- predictive escalation;
- AI-assisted incident summary.

---

### 54. Future Evolution

- PagerDuty/Opsgenie adapter;
- Teams/Slack interactive action;
- SMS/voice provider;
- mobile push;
- incident war room automation;
- public status page;
- auto-generated postmortem timeline;
- service ownership catalog;
- multi-region on-call;
- follow-the-sun rotation;
- signed incident export;
- immutable evidence ledger;
- automated remediation with approval gates.

---

### 55. Merge Guidance

Gabungkan:

```text
SSOT-OBS-07-Part-1.md
SSOT-OBS-07-Part-2.md
SSOT-OBS-07-Part-3.md
SSOT-OBS-07-Part-4.md
SSOT-OBS-07-Part-5.md
```

menjadi:

```text
SSOT-OBS-07.md
```

Urutan:

```text
Part 1 — Vision, Models, Severity, Ownership
Part 2 — Rules, Evaluation, Noise Control, Routing
Part 3 — Incident Management, Timeline, Postmortem
Part 4 — Notification, On-Call, API, Database
Part 5 — Reference Implementation & Operations
```

---

### 56. Merge Quality Checklist

- [ ] heading tidak duplikat;
- [ ] severity konsisten;
- [ ] alert state konsisten;
- [ ] incident state konsisten;
- [ ] permission konsisten;
- [ ] table names konsisten;
- [ ] namespace konsisten;
- [ ] endpoint konsisten;
- [ ] error code konsisten;
- [ ] notification status konsisten;
- [ ] route/on-call references konsisten;
- [ ] duplicate section dihapus;
- [ ] daftar isi dibuat;
- [ ] metadata final diperbarui;
- [ ] status final diset Review/Approved.

---

### 57. Final Metadata

```yaml
document_code: SSOT-OBS-07
title: Alerting & Incident Management Framework
version: 1.0
status: Draft for Review
domain: Platform Kernel
category: Observability
owners:
  - Platform Architecture
  - Platform Operations
  - Security
reviewers:
  - Backend Engineering
  - DevOps
  - QA
  - Security
  - Compliance
```

---

### 58. Approval Gate

Dokumen dapat menjadi Approved setelah:

- architecture review;
- operations review;
- security review;
- compliance review;
- database review;
- notification channel review;
- on-call process review;
- QA/UAT review;
- performance review;
- simulation review;
- deployment/rollback review.

---

### 59. Closing Statement

Alerting & Incident Management Framework harus menghasilkan sinyal yang actionable, memiliki owner, dan dapat ditangani secara konsisten.

Framework tidak boleh:

- menjadikan semua kondisi sebagai page;
- membiarkan alert tanpa owner;
- menutup alert tanpa recovery;
- menyimpan timeline yang dapat dihapus;
- membocorkan data tenant atau data sensitif;
- mengandalkan satu notification channel;
- membuat incident tanpa koordinasi dan closure criteria.

Framework harus membantu tim mendeteksi, merespons, memulihkan, dan belajar dari gangguan secara terukur.

---

## Lampiran A — Sumber Penggabungan

Dokumen final ini digabung dan dinormalisasi dari:

- `SSOT-OBS-07-Part-1.md`
- `SSOT-OBS-07-Part-2.md`
- `SSOT-OBS-07-Part-3.md`
- `SSOT-OBS-07-Part-4.md`
- `SSOT-OBS-07-Part-5.md`

## Lampiran B — Approval Gate

Status dokumen dapat diubah menjadi **Approved** setelah:

- architecture review selesai;
- operations review selesai;
- security review selesai;
- compliance review selesai;
- database schema disetujui;
- notification channel review selesai;
- on-call process review selesai;
- permission dan tenant/scope policy disetujui;
- QA/UAT review selesai;
- performance review selesai;
- incident simulation selesai;
- deployment dan rollback review selesai.
