# SSOT-OBS-06 — Monitoring Dashboard Framework

> Single Source of Truth untuk arsitektur, metric dan KPI, implementasi, API, keamanan, frontend integration, operasi, dan pengujian Monitoring Dashboard Framework pada Platform Kernel.

## Metadata Dokumen

| Item | Nilai |
|---|---|
| Kode | SSOT-OBS-06 |
| Judul | Monitoring Dashboard Framework |
| Versi | 1.0 |
| Status | Draft for Review |
| Domain | Platform Kernel |
| Kategori | Observability |
| Target Stack | PHP 8.1+, PDO, MySQL 8/MariaDB, Apache/XAMPP, Modular Monolith |
| Bergantung pada | SSOT-OBS-01 sampai SSOT-OBS-05 |
| Pemilik | Platform Architecture, Platform Operations, Frontend Platform |
| Reviewer | Backend Engineering, Frontend Engineering, DevOps, QA, Security |

## Tujuan Dokumen

Dokumen ini menetapkan standar tunggal untuk:

- dashboard dan widget model;
- data source dan query orchestration;
- metric, KPI, threshold, aggregation, time-series, SLA/SLO, dan error budget;
- registry, caching, persistence, dan layout customization;
- HTTP API, middleware, RBAC, tenant/scope isolation, dan export;
- frontend rendering, responsive layout, accessibility, dan partial failure;
- deployment, performance testing, incident workflow, UAT, dan Definition of Done.

## Daftar Isi

1. Bagian I — Vision, Architecture, Dashboard Model, Widget Model & Access Policy
2. Bagian II — Metrics, KPI, Thresholds, Aggregation, Time-Series & SLA/SLO
3. Bagian III — Registry, Query Orchestrator, Cache, PHP Interfaces & Database Schema
4. Bagian IV — HTTP API, Controllers, Middleware, Customization, Export & Frontend Integration
5. Bagian V — Reference Implementation, Deployment, Performance Test, Incident Workflow & Final UAT
6. Lampiran A — Sumber Penggabungan
7. Lampiran B — Approval Gate

## Status Normatif

Kata **wajib**, **harus**, dan **tidak boleh** menyatakan persyaratan normatif. Kata **direkomendasikan**, **sebaiknya**, dan **dapat** menyatakan panduan yang dapat disesuaikan melalui keputusan arsitektur terdokumentasi.

---

## Bagian I — Vision, Architecture, Dashboard Model, Widget Model & Access Policy

### 1. Executive Summary

Monitoring Dashboard Framework menyediakan standar tunggal untuk menampilkan kondisi operasional Platform Kernel secara konsisten.

Framework ini bukan sekadar halaman statistik.

Framework harus mampu:

- menampilkan kesehatan platform;
- menampilkan status komponen;
- menampilkan metric dan KPI;
- menampilkan tren;
- menampilkan alert aktif;
- menampilkan incident;
- menampilkan SLA/SLO;
- menampilkan status tenant;
- menampilkan status module;
- menampilkan performa aplikasi;
- menampilkan integrasi eksternal;
- mendukung drill-down;
- menerapkan RBAC dan scope;
- menghindari kebocoran data sensitif.

Dashboard menjadi lapisan visual di atas:

```text
Structured Logging
Metrics
Distributed Tracing
Health Check
Alerting
Incident Management
Performance Monitoring
Audit
```

Dashboard tidak boleh menjadi sumber kebenaran utama.

Sumber kebenaran tetap berada pada:

- metric store;
- log store;
- trace store;
- health state;
- incident store;
- operational database.

---

### 2. Problem Statement

Tanpa framework standar, dashboard sering berkembang menjadi:

- halaman statistik yang dibuat per module;
- query database langsung dari controller;
- KPI dengan definisi berbeda;
- warna status yang tidak konsisten;
- widget tanpa ownership;
- halaman yang lambat;
- akses lintas tenant;
- informasi sensitif tampil ke user yang salah;
- dashboard yang menjadi dependency aplikasi utama;
- data yang tidak dapat ditelusuri sumbernya.

Contoh masalah:

```text
Dashboard A:
"Error Rate" = seluruh HTTP 500

Dashboard B:
"Error Rate" = seluruh exception aplikasi

Dashboard C:
"Error Rate" = failed transaction
```

Ketiganya menggunakan nama yang sama tetapi definisi berbeda.

Monitoring Dashboard Framework wajib menghilangkan ambiguitas tersebut.

---

### 3. Tujuan

Framework harus menjawab:

- Apa kondisi platform saat ini?
- Komponen mana yang bermasalah?
- Sejak kapan masalah terjadi?
- Tenant atau module mana yang terdampak?
- Metric mana yang melewati threshold?
- Alert apa yang aktif?
- Incident apa yang sedang berlangsung?
- Apakah layanan memenuhi SLA/SLO?
- Apakah performa memburuk?
- Apa hubungan antara health, metric, log, dan trace?
- Siapa yang boleh melihat data tersebut?

---

### 4. Non-Goals

Part 1 tidak menjadikan dashboard sebagai:

- business intelligence platform penuh;
- data warehouse;
- report builder umum;
- audit trail viewer lengkap;
- log search engine;
- trace analysis engine;
- alerting engine;
- incident management engine.

Dashboard hanya mengorkestrasi dan memvisualisasikan data dari domain tersebut.

---

### 5. Design Principles

#### 5.1 Source-of-Truth Separation

Dashboard tidak menyimpan ulang seluruh data observability.

Dashboard hanya:

- membaca;
- mengagregasi;
- memproyeksikan;
- menyajikan.

#### 5.2 Configurable, Not Hardcoded

Dashboard, section, widget, metric, threshold, dan permission harus dapat dikonfigurasi.

#### 5.3 Scope-Aware

Setiap query wajib mempertimbangkan:

- tenant;
- organization;
- business entity;
- clinic/facility;
- module;
- active scope;
- user permission.

#### 5.4 Role-Aware

Tampilan harus berbeda berdasarkan role.

Contoh:

```text
Platform Admin
Operations Admin
Security Admin
Tenant Admin
Module Owner
Support
Executive
```

#### 5.5 Progressive Disclosure

Level tampilan:

```text
Overview
→ Domain
→ Component
→ Metric
→ Event/Log/Trace
```

User tidak langsung dibanjiri detail teknis.

#### 5.6 Consistent Semantics

Status, warna, icon, threshold, dan waktu harus konsisten di seluruh dashboard.

#### 5.7 Fast by Default

Dashboard overview harus menggunakan:

- cached summary;
- pre-aggregated metric;
- paginated data;
- lazy loading;
- bounded time range.

#### 5.8 Secure by Design

Dashboard tidak boleh membocorkan:

- PHI;
- PII;
- token;
- secret;
- stack trace mentah;
- internal hostname yang tidak perlu;
- data tenant lain;
- log payload sensitif.

#### 5.9 Vendor Independent

Framework tidak boleh bergantung penuh pada:

- Grafana;
- Kibana;
- Datadog;
- New Relic;
- Azure Monitor;
- CloudWatch.

Vendor dapat digunakan sebagai adapter atau embedded diagnostic tool.

#### 5.10 Observable Dashboard

Dashboard sendiri harus dipantau:

- load time;
- query latency;
- widget error;
- cache hit;
- authorization failure;
- API failure.

---

### 6. High-Level Architecture

```text
Browser
   │
   ▼
Dashboard UI
   │
   ▼
Dashboard API / Controller
   │
   ▼
Dashboard Application Service
   │
   ├─────────────┬─────────────┬─────────────┐
   ▼             ▼             ▼             ▼
Widget Registry  Layout Engine  Access Policy  Query Orchestrator
   │                                           │
   ▼                                           ▼
Widget Providers                         Data Source Adapters
                                               │
                         ┌─────────────────────┼─────────────────────┐
                         ▼                     ▼                     ▼
                    Health Store          Metrics Store         Logs/Traces
                         │                     │                     │
                         └──────────────┬──────┴──────────────┬─────┘
                                        ▼                     ▼
                                  Cache/Aggregation       Alert/Incident
```

---

### 7. Core Components

Framework terdiri dari:

```text
DashboardDefinition
DashboardRegistry
DashboardLayout
DashboardSection
WidgetDefinition
WidgetRegistry
WidgetProvider
DashboardQuery
DashboardContext
DashboardAccessPolicy
DashboardDataSource
DashboardResponse
DashboardCache
DashboardTelemetry
```

---

### 8. Dashboard Definition

Dashboard Definition mendeskripsikan satu dashboard.

Contoh:

```text
platform_overview
operations
security
tenant_overview
module_health
integration
performance
executive
```

Field minimum:

| Field | Keterangan |
|---|---|
| code | identifier stabil |
| title | label UI |
| description | tujuan dashboard |
| category | grouping |
| audience | target role |
| permission | permission minimum |
| scope_type | global/tenant/entity/module |
| layout | layout reference |
| refresh_policy | interval refresh |
| time_range_policy | default dan maksimum |
| enabled | status aktif |
| version | versi definition |

Contoh konfigurasi:

```php
return [
    'code' => 'platform_overview',
    'title' => 'Platform Overview',
    'category' => 'operations',
    'permission' => 'observability.dashboard.platform.read',
    'scope_type' => 'global',
    'refresh_policy' => [
        'mode' => 'polling',
        'interval_seconds' => 30,
    ],
    'default_time_range' => '1h',
    'max_time_range' => '30d',
];
```

---

### 9. Dashboard Types

#### 9.1 Platform Overview Dashboard

Menampilkan:

- overall health;
- component status;
- active alert;
- current incident;
- request rate;
- error rate;
- response latency;
- queue backlog;
- integration status;
- resource utilization.

Audience:

```text
Platform Admin
Operations Admin
Support
```

#### 9.2 Operations Dashboard

Menampilkan:

- scheduler;
- queue;
- worker;
- outbox;
- storage;
- background job;
- deployment status;
- backup status;
- infrastructure dependency.

#### 9.3 Security Dashboard

Menampilkan:

- failed login trend;
- MFA compliance;
- privileged account status;
- audit pipeline health;
- credential expiry;
- security health;
- suspicious activity summary;
- security incident.

Detail dibatasi permission khusus.

#### 9.4 Tenant Dashboard

Menampilkan tenant tertentu:

- tenant health;
- quota;
- active user;
- module availability;
- error trend;
- integration status;
- storage utilization;
- current alert.

Tidak boleh menampilkan tenant lain.

#### 9.5 Module Dashboard

Menampilkan:

- module health;
- request volume;
- error;
- workflow;
- event;
- queue;
- module-specific KPI;
- dependency status.

#### 9.6 Integration Dashboard

Menampilkan:

- connector status;
- latency;
- success rate;
- failure rate;
- retry;
- dead letter;
- circuit breaker;
- last successful sync.

#### 9.7 Performance Dashboard

Menampilkan:

- p50/p95/p99 latency;
- throughput;
- slow endpoint;
- slow query;
- cache hit;
- memory;
- CPU bila tersedia;
- worker utilization.

#### 9.8 Executive Dashboard

Menampilkan data ringkas:

- availability;
- incident count;
- SLA/SLO;
- service trend;
- tenant impact;
- major risk.

Tidak menampilkan detail teknis berlebihan.

---

### 10. Dashboard Context

DashboardContext membawa konteks request.

```php
<?php

declare(strict_types=1);

namespace App\Platform\Observability\Dashboard\Domain;

final readonly class DashboardContext
{
    public function __construct(
        public int $actorUserId,
        public array $permissions,
        public string $environment,
        public ?int $tenantId,
        public ?int $scopeId,
        public ?string $moduleCode,
        public string $timezone,
        public string $locale,
        public string $timeRange,
        public ?string $correlationId,
    ) {
    }
}
```

Context wajib berasal dari authentication, scope, dan request validation.

Tidak boleh mempercayai:

```text
tenant_id
scope_id
role
permission
```

langsung dari query parameter tanpa authorization.

---

### 11. Dashboard Registry

DashboardRegistry menyimpan dashboard definition.

Tanggung jawab:

- register;
- validate code unik;
- filter enabled dashboard;
- filter berdasarkan audience;
- resolve dashboard;
- expose metadata aman.

Contoh kontrak:

```php
interface DashboardRegistryInterface
{
    public function register(DashboardDefinition $definition): void;

    public function get(string $code): DashboardDefinition;

    public function availableFor(
        DashboardContext $context
    ): array;
}
```

Duplicate code harus gagal saat bootstrap.

---

### 12. Layout Model

Layout terdiri dari:

```text
Dashboard
→ Section
→ Row
→ Widget
```

Contoh:

```text
Platform Overview
├── Executive Summary
│   ├── Overall Health
│   ├── Active Alerts
│   ├── Active Incidents
│   └── Availability
│
├── Traffic & Performance
│   ├── Request Rate
│   ├── Error Rate
│   └── Latency
│
└── Dependencies
    ├── Database
    ├── Queue
    ├── Integration
    └── Storage
```

---

### 13. Responsive Grid

Rekomendasi grid:

```text
12-column desktop
8-column tablet
4-column mobile
```

Widget definition:

```php
[
    'desktop' => ['x' => 0, 'y' => 0, 'w' => 4, 'h' => 2],
    'tablet' => ['x' => 0, 'y' => 0, 'w' => 4, 'h' => 2],
    'mobile' => ['x' => 0, 'y' => 0, 'w' => 4, 'h' => 2],
]
```

Aturan:

- tidak ada horizontal scroll pada mobile;
- widget critical muncul lebih dulu;
- chart kompleks dapat berubah menjadi summary card;
- table besar menggunakan responsive drill-down.

---

### 14. Widget Model

Widget adalah unit visual dan data terkecil.

Widget types:

```text
status_card
metric_card
trend_chart
time_series
bar_chart
donut_chart
table
heatmap
timeline
alert_list
incident_list
dependency_map
service_map
gauge
progress
text_summary
```

Setiap widget memiliki:

| Field | Keterangan |
|---|---|
| code | identifier stabil |
| title | label |
| type | jenis widget |
| provider | data provider |
| metric | metric reference |
| permission | permission |
| scope | scope policy |
| refresh | refresh interval |
| time_range | supported range |
| thresholds | threshold reference |
| empty_state | behavior saat kosong |
| error_state | behavior saat gagal |
| drill_down | destination |
| layout | grid definition |

---

### 15. Widget Definition Example

```php
return [
    'code' => 'platform_overall_health',
    'title' => 'Overall Health',
    'type' => 'status_card',
    'provider' => 'health.overall',
    'permission' => 'observability.dashboard.platform.read',
    'refresh_seconds' => 15,
    'supported_time_ranges' => ['now'],
    'thresholds' => 'health_status',
    'drill_down' => [
        'dashboard' => 'platform_health',
    ],
];
```

---

### 16. Widget Provider

WidgetProvider bertanggung jawab menghasilkan data untuk satu atau lebih widget.

Kontrak:

```php
interface WidgetProviderInterface
{
    public function code(): string;

    public function supports(string $widgetCode): bool;

    public function fetch(
        WidgetQuery $query,
        DashboardContext $context
    ): WidgetResult;
}
```

Provider tidak boleh menghasilkan HTML.

Provider menghasilkan data terstruktur.

---

### 17. Widget Result

Contoh:

```php
final readonly class WidgetResult
{
    public function __construct(
        public string $widgetCode,
        public string $status,
        public mixed $data,
        public array $meta,
        public array $warnings,
        public \DateTimeImmutable $generatedAt,
        public ?\DateTimeImmutable $validUntil = null,
    ) {
    }
}
```

Status widget:

```text
READY
EMPTY
DEGRADED
ERROR
UNAUTHORIZED
STALE
```

Status widget berbeda dari HealthStatus.

---

### 18. Widget Data Contract

#### 18.1 Metric Card

```json
{
  "value": 99.97,
  "unit": "percent",
  "trend": 0.12,
  "trend_direction": "up",
  "comparison_period": "previous_24h"
}
```

#### 18.2 Status Card

```json
{
  "status": "DEGRADED",
  "label": "Platform Health",
  "since": "2026-07-04T18:52:00+07:00",
  "affected_components": 1
}
```

#### 18.3 Time Series

```json
{
  "series": [
    {
      "name": "p95_latency",
      "points": [
        ["2026-07-04T18:00:00+07:00", 180],
        ["2026-07-04T18:05:00+07:00", 210]
      ]
    }
  ],
  "unit": "ms"
}
```

#### 18.4 Table

```json
{
  "columns": [
    {"key": "component", "label": "Component"},
    {"key": "status", "label": "Status"},
    {"key": "duration_ms", "label": "Latency"}
  ],
  "rows": [
    {
      "component": "database",
      "status": "UP",
      "duration_ms": 18
    }
  ],
  "pagination": {
    "page": 1,
    "per_page": 25,
    "total": 1
  }
}
```

---

### 19. Data Sources

Dashboard dapat membaca dari:

```text
Health Check Store
Metrics Store
Structured Logs
Trace Store
Alert Store
Incident Store
Audit Store
Operational Database
External Monitoring Adapter
```

Setiap data source wajib memiliki adapter.

---

### 20. Data Source Interface

```php
interface DashboardDataSourceInterface
{
    public function name(): string;

    public function query(
        DashboardQuery $query,
        DashboardContext $context
    ): DashboardDataSet;
}
```

Adapter bertanggung jawab untuk:

- query;
- timeout;
- pagination;
- sanitization;
- scope filtering;
- error mapping;
- caching hint.

---

### 21. Data Source Priority

Urutan sumber:

#### Realtime State

Gunakan untuk:

- current health;
- active alert;
- active incident;
- queue backlog terkini.

#### Aggregated Metric

Gunakan untuk:

- trend;
- p95;
- throughput;
- availability;
- SLA/SLO.

#### Raw Log/Trace

Gunakan hanya saat drill-down.

Jangan menarik raw log dalam dashboard overview.

---

### 22. Query Orchestrator

Query Orchestrator:

- menerima daftar widget;
- mengelompokkan query sejenis;
- menghindari query duplikat;
- menerapkan timeout;
- menggunakan cache;
- menjalankan query secara batch bila memungkinkan;
- menghasilkan partial response bila sebagian widget gagal.

Contoh:

```text
Widget A membutuhkan request_rate
Widget B membutuhkan error_rate
Widget C membutuhkan latency
```

Bila sumber sama, orchestrator dapat melakukan satu query agregat.

---

### 23. Time Range Model

Range standar:

```text
now
15m
1h
6h
24h
7d
30d
custom
```

Aturan:

- overview default `1h`;
- executive default `24h` atau `7d`;
- raw log maksimum lebih pendek;
- custom range dibatasi role;
- query besar harus memakai agregasi.

---

### 24. Refresh Policy

Mode:

```text
manual
polling
streaming_future
```

Rekomendasi polling:

| Widget | Interval |
|---|---:|
| Overall Health | 15 detik |
| Active Alert | 30 detik |
| Queue Backlog | 30 detik |
| Request Rate | 60 detik |
| SLA/SLO | 5 menit |
| Executive Summary | 5–15 menit |

Jangan refresh seluruh dashboard jika hanya satu widget membutuhkan update.

---

### 25. Dashboard Cache

Cache level:

```text
dashboard metadata
widget definition
widget result
aggregated query
```

Cache key:

```text
dashboard:{code}:{environment}:{tenant}:{scope}:{time_range}
widget:{code}:{environment}:{tenant}:{scope}:{time_range}
```

Aturan:

- tenant/scope wajib masuk cache key;
- permission-sensitive data tidak boleh dibagi lintas user tanpa policy;
- current health TTL pendek;
- historical aggregate TTL lebih panjang;
- stale data harus diberi label.

---

### 26. Partial Failure

Dashboard tidak boleh gagal total hanya karena satu widget gagal.

Contoh response:

```json
{
  "dashboard": "platform_overview",
  "status": "DEGRADED",
  "widgets": {
    "overall_health": {
      "status": "READY",
      "data": {}
    },
    "request_rate": {
      "status": "ERROR",
      "error_code": "DASHBOARD_DATA_SOURCE_TIMEOUT"
    }
  }
}
```

Widget gagal harus memiliki:

- safe error code;
- retry hint;
- correlation ID;
- no stack trace.

---

### 27. Dashboard Status

Status dashboard:

```text
READY
DEGRADED
ERROR
UNAUTHORIZED
EMPTY
```

Aggregation rule:

| Kondisi | Status |
|---|---|
| seluruh widget utama siap | READY |
| sebagian widget non-kritis gagal | DEGRADED |
| widget kritis gagal | ERROR |
| user tidak berwenang | UNAUTHORIZED |
| tidak ada data valid | EMPTY |

---

### 28. Critical Widget

Widget dapat memiliki criticality:

```text
critical
important
optional
```

Contoh:

| Widget | Criticality |
|---|---|
| Overall Health | critical |
| Active Incidents | critical |
| Database Status | important |
| Request Rate | important |
| Deployment History | optional |

---

### 29. Access Policy

Access policy terdiri dari:

```text
Authentication
Permission
Role
Tenant
Scope
Module Ownership
Data Classification
Time Range
Action
```

---

### 30. Permission Model

Contoh permission:

```text
observability.dashboard.read
observability.dashboard.platform.read
observability.dashboard.operations.read
observability.dashboard.security.read
observability.dashboard.tenant.read
observability.dashboard.module.read
observability.dashboard.integration.read
observability.dashboard.performance.read
observability.dashboard.executive.read
observability.dashboard.custom.manage
observability.dashboard.export
```

---

### 31. Role Matrix

| Role | Dashboard |
|---|---|
| Platform Admin | seluruh dashboard |
| Operations Admin | platform, operations, performance, integration |
| Security Admin | security, platform ringkas |
| Tenant Admin | tenant sendiri |
| Module Owner | module yang dimiliki |
| Support | ringkasan dan diagnostic terbatas |
| Executive | executive summary |
| End User | tidak ada monitoring dashboard teknis |

---

### 32. Scope Enforcement

Setiap widget provider wajib menerima DashboardContext.

Query wajib menggunakan:

```text
tenant_id
scope_id
module_code
environment
```

Tidak boleh ada query:

```sql
SELECT * FROM health_component_state;
```

tanpa scope filter pada tenant-specific dashboard.

---

### 33. Data Classification

Klasifikasi data:

```text
PUBLIC
INTERNAL
CONFIDENTIAL
RESTRICTED
```

Contoh:

| Data | Klasifikasi |
|---|---|
| overall public status | PUBLIC/INTERNAL |
| component name | INTERNAL |
| tenant usage | CONFIDENTIAL |
| security control detail | RESTRICTED |
| raw log dengan user context | RESTRICTED |

Widget definition wajib memiliki klasifikasi.

---

### 34. Security Dashboard Rule

Security dashboard tidak boleh menampilkan:

- password;
- token;
- raw authorization header;
- full IP history tanpa permission;
- raw audit payload;
- secret status detail yang dapat dieksploitasi.

Gunakan summary dan safe code.

---

### 35. Healthcare Privacy

Dashboard untuk platform kesehatan wajib:

- menghindari PHI pada overview;
- menggunakan aggregate count;
- membatasi drill-down;
- mencatat akses data sensitif;
- menerapkan minimum necessary access;
- tidak menampilkan nama pasien pada dashboard operasional;
- memisahkan operational metric dari clinical report.

---

### 36. Audit Policy

Tidak perlu audit setiap refresh widget.

Audit wajib untuk:

- membuka security dashboard detail;
- melihat tenant lain;
- export dashboard;
- membuat custom dashboard;
- mengubah layout global;
- mengubah threshold;
- mengubah widget source;
- melihat raw log/trace sensitif;
- cross-scope drill-down.

---

### 37. Health Check Integration

Health Dashboard membaca:

```text
health_component_state
health_status_transitions
health_check_reports
health_check_results
```

Widget minimum:

- overall health;
- component status;
- last transition;
- degraded component;
- down component;
- health trend;
- stale health result.

---

### 38. Health-to-Dashboard Flow

```mermaid
sequenceDiagram
    participant Provider as Health Provider
    participant Manager as Health Manager
    participant Store as Health State Store
    participant Cache as Dashboard Cache
    participant API as Dashboard API
    participant UI as Dashboard UI

    Provider->>Manager: HealthResult
    Manager->>Store: Update state and transition
    Store-->>Manager: Saved
    UI->>API: Request health widgets
    API->>Cache: Read cached widget
    alt cache hit
        Cache-->>API: WidgetResult
    else cache miss
        API->>Store: Query current state
        Store-->>API: Health data
        API->>Cache: Store WidgetResult
    end
    API-->>UI: Safe dashboard response
```

---

### 39. Dashboard API Shape

Contoh:

```text
GET /internal/dashboards
GET /internal/dashboards/{code}
GET /internal/dashboards/{code}/widgets
GET /internal/dashboards/{code}/widgets/{widgetCode}
```

Query:

```text
?time_range=1h
?tenant_id=12
?scope_id=4
?refresh=false
```

Internal endpoint wajib:

- authentication;
- permission;
- scope;
- rate limit;
- safe projection.

---

### 40. Dashboard Response Example

```json
{
  "dashboard": {
    "code": "platform_overview",
    "title": "Platform Overview",
    "status": "DEGRADED",
    "generated_at": "2026-07-04T19:00:00+07:00",
    "time_range": "1h"
  },
  "widgets": [
    {
      "code": "overall_health",
      "type": "status_card",
      "status": "READY",
      "data": {
        "status": "DEGRADED",
        "affected_components": 1
      }
    },
    {
      "code": "active_alerts",
      "type": "metric_card",
      "status": "READY",
      "data": {
        "value": 3,
        "unit": "alerts"
      }
    }
  ],
  "meta": {
    "request_id": "01J2ABCDEF1234567890",
    "duration_ms": 84
  }
}
```

---

### 41. UI Status Semantics

Status warna direkomendasikan:

| Status | Semantic Color |
|---|---|
| UP/READY | Success |
| DEGRADED | Warning |
| DOWN/ERROR | Danger |
| UNKNOWN | Neutral/Warning |
| MAINTENANCE | Info |
| STALE | Neutral |

Dokumen tidak mengikat nilai hex spesifik.

Nilai visual harus mengikuti Design Token System.

---

### 42. Accessibility

Dashboard wajib:

- tidak mengandalkan warna saja;
- memiliki text label status;
- keyboard navigable;
- chart memiliki summary;
- table memiliki header;
- focus state jelas;
- contrast memenuhi standar;
- auto-refresh tidak mengganggu screen reader;
- user dapat menghentikan refresh.

---

### 43. Mobile Behavior

Pada mobile:

- critical widget tampil pertama;
- chart kompleks dapat diringkas;
- table menggunakan card/detail view;
- filter memakai drawer;
- time range mudah diubah;
- tidak ada informasi penting hanya melalui hover;
- drill-down tetap tersedia.

---

### 44. Dashboard Telemetry

Metric minimum:

```text
dashboard_request_total
dashboard_request_duration_ms
dashboard_widget_query_total
dashboard_widget_query_error_total
dashboard_widget_cache_hit_total
dashboard_widget_cache_miss_total
dashboard_authorization_denied_total
dashboard_partial_failure_total
```

Structured log:

```json
{
  "event": "dashboard_rendered",
  "dashboard": "platform_overview",
  "widget_count": 12,
  "failed_widget_count": 1,
  "duration_ms": 84,
  "tenant_id": null,
  "scope_id": null
}
```

---

### 45. Performance Targets

| Area | Target |
|---|---:|
| Dashboard metadata | < 100 ms |
| Overview cached | < 1000 ms |
| Single widget cached | < 300 ms |
| Single widget live | < 1000 ms |
| Historical chart | < 2000 ms |
| Initial mobile render | < 2000 ms |

Target akhir harus diuji pada environment production-like.

---

### 46. Anti-Pattern

Hindari:

- query SQL langsung di view;
- satu controller untuk seluruh widget;
- widget menyimpan HTML di database;
- dashboard overview membaca raw log;
- refresh seluruh halaman setiap 5 detik;
- cache key tanpa tenant/scope;
- KPI tanpa definisi;
- chart tanpa unit;
- status hanya dibedakan warna;
- security dashboard dapat dilihat semua admin;
- widget error membuat seluruh dashboard blank;
- dashboard menjadi dependency health check;
- custom dashboard mengeksekusi query bebas.

---

### 47. UAT Part 1

#### 47.1 Registry

- [ ] Dashboard code unik.
- [ ] Widget code unik dalam dashboard.
- [ ] Duplicate definition ditolak.
- [ ] Disabled dashboard tidak tampil.

#### 47.2 Access

- [ ] Platform admin melihat platform dashboard.
- [ ] Tenant admin hanya melihat tenant sendiri.
- [ ] Security dashboard membutuhkan permission khusus.
- [ ] Cross-scope access ditolak.
- [ ] Module owner hanya melihat module yang sah.

#### 47.3 Widget

- [ ] Widget result memiliki contract konsisten.
- [ ] Empty state tampil benar.
- [ ] Partial failure tidak mematikan dashboard.
- [ ] Critical widget memengaruhi status dashboard.
- [ ] Cache key memisahkan tenant.

#### 47.4 Performance

- [ ] Overview menggunakan summary/cache.
- [ ] Query duplikat digabung.
- [ ] Time range dibatasi.
- [ ] Widget besar lazy-loaded.
- [ ] Raw logs tidak diambil otomatis.

#### 47.5 Security

- [ ] Tidak ada secret.
- [ ] Tidak ada PHI pada overview.
- [ ] Export membutuhkan permission.
- [ ] Security detail diaudit.
- [ ] Public endpoint tidak mengekspos dashboard internal.

#### 47.6 UI

- [ ] Responsive desktop/tablet/mobile.
- [ ] Status tidak hanya mengandalkan warna.
- [ ] Chart memiliki unit.
- [ ] Auto-refresh dapat dihentikan.
- [ ] Keyboard navigation berfungsi.

---

### 48. Definition of Done Part 1

Part 1 dianggap selesai bila:

- [ ] visi dan problem statement disepakati;
- [ ] architecture disepakati;
- [ ] dashboard types didefinisikan;
- [ ] DashboardDefinition didefinisikan;
- [ ] DashboardContext didefinisikan;
- [ ] layout model didefinisikan;
- [ ] widget model didefinisikan;
- [ ] WidgetProvider contract didefinisikan;
- [ ] data source model didefinisikan;
- [ ] access policy didefinisikan;
- [ ] permission model didefinisikan;
- [ ] scope dan privacy policy didefinisikan;
- [ ] health integration didefinisikan;
- [ ] partial failure policy didefinisikan;
- [ ] performance target tersedia;
- [ ] UAT tersedia.

---

### 49. Rencana Part Berikutnya

#### Part 2

Metrics, KPI, threshold, aggregation, time-series, SLA/SLO, dan dashboard data contracts.

#### Part 3

Dashboard Registry, Widget Registry, Query Orchestrator, cache, PHP interfaces, dan database schema.

#### Part 4

HTTP API, controller, security middleware, layout persistence, customization, export, dan frontend integration.

#### Part 5

Reference implementation, sample dashboards, deployment, performance test, incident workflow, final UAT, dan merge guidance.

---

## Bagian II — Metrics, KPI, Thresholds, Aggregation, Time-Series & SLA/SLO

### 1. Executive Summary

Part 2 mendefinisikan standar metric dan KPI yang digunakan oleh Monitoring Dashboard Framework.

Tujuan utama:

- memastikan setiap metric memiliki arti tunggal;
- mencegah duplikasi definisi KPI;
- menetapkan unit, dimensi, dan ownership;
- menetapkan threshold;
- menetapkan metode agregasi;
- menetapkan time-series resolution;
- menetapkan SLA, SLO, SLI, dan error budget;
- menyediakan kontrak data yang stabil untuk widget;
- menjaga performa query;
- menjaga tenant isolation;
- menghindari cardinality berlebihan.

Dashboard tidak boleh membuat definisi KPI sendiri.

Setiap KPI wajib berasal dari registry atau catalog yang disetujui.

---

### 2. Problem Statement

Tanpa standar metric dan KPI, dashboard dapat menampilkan angka yang tampak benar tetapi sebenarnya tidak konsisten.

Contoh:

```text
Request Count
```

dapat berarti:

- seluruh HTTP request;
- request sukses saja;
- request endpoint tertentu;
- request termasuk health check;
- request per tenant;
- request per user;
- request setelah filter tertentu.

Masalah lain:

- unit tidak jelas;
- denominator tidak konsisten;
- threshold di-hardcode;
- aggregation salah;
- metric counter dijumlahkan lintas waktu tanpa rate;
- p95 dihitung dari rata-rata p95;
- tenant label menghasilkan cardinality terlalu tinggi;
- historical data terlalu berat;
- widget menampilkan nilai stale tanpa label;
- SLA dan SLO dicampur.

---

### 3. Tujuan

Standar ini harus menjawab:

- Metric apa yang tersedia?
- Bagaimana metric dihitung?
- Unit apa yang digunakan?
- Dimensi apa yang diperbolehkan?
- Siapa pemilik metric?
- Berapa threshold warning dan critical?
- Bagaimana data diagregasi?
- Bagaimana metric ditampilkan lintas waktu?
- Bagaimana SLA/SLO dihitung?
- Bagaimana error budget ditentukan?
- Bagaimana metric berbeda antar tenant dan scope?
- Bagaimana widget menangani missing atau stale data?

---

### 4. Metric Taxonomy

Metric dibagi menjadi:

```text
Counter
Gauge
Histogram
Summary
State
Derived Metric
Business Operational Metric
SLA/SLO Metric
```

---

### 5. Counter

Counter hanya bertambah.

Contoh:

```text
http_request_total
http_error_total
queue_job_processed_total
queue_job_failed_total
notification_sent_total
integration_request_total
```

Aturan:

- jangan reset secara manual kecuali process restart;
- dashboard menampilkan rate atau delta;
- jangan menampilkan nilai total mentah sebagai trend utama;
- counter restart harus ditangani.

Contoh query turunan:

```text
request_rate = delta(http_request_total) / duration
```

---

### 6. Gauge

Gauge dapat naik dan turun.

Contoh:

```text
queue_pending_jobs
active_sessions
storage_usage_percent
database_connection_active
worker_active_total
health_component_status
```

Gauge cocok untuk current state.

---

### 7. Histogram

Histogram digunakan untuk distribusi.

Contoh:

```text
http_request_duration_ms
database_query_duration_ms
queue_wait_duration_ms
integration_latency_ms
```

Histogram memungkinkan:

```text
p50
p90
p95
p99
```

Jangan menghitung p95 global dengan merata-ratakan p95 per interval.

---

### 8. Summary

Summary dapat digunakan untuk statistik precomputed.

Penggunaan harus dibatasi karena:

- sulit digabung lintas instance;
- kurang fleksibel dibanding histogram;
- dapat menghasilkan interpretasi berbeda.

Histogram lebih direkomendasikan untuk distributed metrics.

---

### 9. State Metric

State merepresentasikan kondisi kategorikal.

Contoh:

```text
UP = 1
DEGRADED = 0.5
DOWN = 0
UNKNOWN = -1
MAINTENANCE = 0.25
```

Nilai numerik hanya untuk chart dan aggregation.

Response UI tetap menggunakan label status.

---

### 10. Derived Metric

Derived metric dihitung dari metric lain.

Contoh:

```text
error_rate
success_rate
availability
cache_hit_rate
queue_failure_rate
integration_success_rate
```

Setiap derived metric wajib mendokumentasikan formula.

---

### 11. Business Operational Metric

Metric operasional bisnis dapat tampil pada monitoring bila terkait reliability.

Contoh:

```text
orders_pending_total
appointments_sync_failed_total
claims_submission_failed_total
workflow_approval_backlog
```

Jangan mencampur dashboard monitoring dengan laporan bisnis umum.

---

### 12. Metric Naming Convention

Format rekomendasi:

```text
<domain>_<subject>_<measurement>_<unit_or_type>
```

Contoh:

```text
http_request_total
http_request_duration_ms
queue_pending_jobs
integration_success_rate
storage_usage_percent
```

Aturan:

- lowercase snake_case;
- nama stabil;
- jangan memakai label UI sebagai metric name;
- sertakan unit pada nama bila relevan;
- counter diakhiri `_total`;
- duration diakhiri `_ms` atau `_seconds`;
- ratio diakhiri `_ratio`;
- percent diakhiri `_percent`.

---

### 13. Unit Standard

Unit standar:

| Jenis | Unit |
|---|---|
| Duration | milliseconds atau seconds |
| Size | bytes |
| Rate | per_second atau per_minute |
| Ratio | 0–1 |
| Percent | 0–100 |
| Count | integer |
| Timestamp | ISO-8601 atau Unix time internal |
| Availability | percent |
| Throughput | requests_per_second |

Jangan mencampur:

```text
ms
seconds
microseconds
```

dalam satu metric yang sama.

---

### 14. Metric Definition

Setiap metric wajib memiliki metadata:

```text
name
title
description
type
unit
domain
owner
source
dimensions
aggregation
retention
privacy_classification
default_threshold
supported_time_ranges
version
status
```

Contoh:

```php
return [
    'name' => 'http_request_duration_ms',
    'title' => 'HTTP Request Duration',
    'description' => 'Distribution of server-side HTTP request duration.',
    'type' => 'histogram',
    'unit' => 'ms',
    'domain' => 'http',
    'owner' => 'platform_operations',
    'source' => 'metrics_store',
    'dimensions' => [
        'environment',
        'route_group',
        'method',
        'status_class',
    ],
    'aggregation' => [
        'p50',
        'p95',
        'p99',
    ],
    'privacy_classification' => 'INTERNAL',
    'version' => '1.0',
];
```

---

### 15. Metric Registry

Metric Registry menjadi katalog tunggal.

Tanggung jawab:

- registrasi metric;
- validasi nama unik;
- validasi type;
- validasi unit;
- validasi allowed dimensions;
- resolve metric;
- expose metadata;
- versioning;
- deprecation.

Kontrak:

```php
interface MetricRegistryInterface
{
    public function register(MetricDefinition $definition): void;

    public function get(string $name): MetricDefinition;

    public function all(): array;

    public function active(): array;
}
```

---

### 16. KPI Definition

KPI adalah metric atau derived metric yang memiliki tujuan operasional.

Field minimum:

```text
code
title
description
formula
source_metrics
unit
target
warning_threshold
critical_threshold
comparison
owner
scope
time_window
refresh_policy
```

Contoh:

```php
return [
    'code' => 'platform_error_rate',
    'title' => 'Platform Error Rate',
    'formula' => 'http_error_total / http_request_total',
    'unit' => 'percent',
    'target' => 0.5,
    'warning_threshold' => 1.0,
    'critical_threshold' => 5.0,
    'comparison' => 'greater_than',
    'time_window' => '5m',
    'owner' => 'platform_operations',
];
```

---

### 17. KPI Governance

Setiap KPI wajib memiliki:

- owner;
- formula;
- denominator;
- scope;
- window;
- target;
- threshold;
- source;
- version;
- reviewer;
- effective date.

KPI tidak boleh dibuat langsung dari frontend.

---

### 18. KPI Categories

#### 18.1 Availability

Contoh:

```text
service_availability_percent
ready_probe_success_rate
component_uptime_percent
```

#### 18.2 Reliability

Contoh:

```text
error_rate_percent
job_failure_rate_percent
integration_failure_rate_percent
```

#### 18.3 Performance

Contoh:

```text
http_p95_latency_ms
database_p95_latency_ms
queue_wait_p95_ms
```

#### 18.4 Capacity

Contoh:

```text
storage_usage_percent
database_connection_usage_percent
worker_utilization_percent
```

#### 18.5 Backlog

Contoh:

```text
queue_pending_jobs
outbox_pending_events
workflow_pending_approvals
dead_letter_total
```

#### 18.6 Security

Contoh:

```text
failed_login_rate
privileged_mfa_compliance_percent
expired_credential_total
```

#### 18.7 Tenant

Contoh:

```text
tenant_degraded_total
tenant_quota_usage_percent
tenant_error_rate_percent
```

---

### 19. Formula Standard

Formula harus eksplisit.

#### 19.1 Error Rate

```text
error_rate_percent =
(error_request_count / total_request_count) × 100
```

Denominator tidak boleh nol.

Jika denominator nol:

```text
status = EMPTY
```

bukan otomatis `0%`.

#### 19.2 Success Rate

```text
success_rate_percent =
(success_count / total_count) × 100
```

#### 19.3 Cache Hit Rate

```text
cache_hit_rate_percent =
(cache_hit_total / (cache_hit_total + cache_miss_total)) × 100
```

#### 19.4 Availability

```text
availability_percent =
(successful_probe_duration / total_observation_duration) × 100
```

#### 19.5 Saturation

```text
resource_usage_percent =
(current_usage / capacity) × 100
```

---

### 20. Threshold Model

Threshold level:

```text
NORMAL
WARNING
CRITICAL
UNKNOWN
```

Optional:

```text
INFO
```

Threshold dapat berbasis:

- absolute value;
- percentage;
- ratio;
- rate;
- duration;
- deviation;
- trend;
- state;
- time since event.

---

### 21. Threshold Definition

Field:

```text
code
metric
comparison
warning
critical
recovery
window
minimum_samples
cooldown
scope
environment
effective_from
version
```

Contoh:

```php
return [
    'code' => 'http_error_rate_default',
    'metric' => 'http_error_rate_percent',
    'comparison' => 'greater_than_or_equal',
    'warning' => 1.0,
    'critical' => 5.0,
    'recovery' => 0.5,
    'window' => '5m',
    'minimum_samples' => 100,
    'cooldown' => '10m',
];
```

---

### 22. Comparison Types

Supported comparison:

```text
greater_than
greater_than_or_equal
less_than
less_than_or_equal
equal
not_equal
outside_range
inside_range
state_equals
stale_for
rate_of_change
```

---

### 23. Hysteresis

Threshold recovery tidak boleh selalu sama dengan trigger.

Contoh:

```text
warning trigger = error rate >= 1%
warning recovery = error rate < 0.5%
```

Tujuan:

- mencegah status flapping;
- mengurangi alert noise;
- membuat dashboard stabil.

---

### 24. Minimum Sample

Threshold berbasis rate wajib memiliki minimum sample.

Contoh:

```text
error rate = 50%
```

tidak bermakna jika hanya ada 2 request.

Gunakan:

```text
minimum_samples = 100
```

Jika sample kurang:

```text
status = INSUFFICIENT_DATA
```

---

### 25. Threshold Scope

Threshold dapat berbeda berdasarkan:

```text
environment
service
module
tenant tier
integration connector
endpoint group
criticality
```

Contoh:

- production lebih ketat;
- local lebih longgar;
- connector critical lebih ketat;
- tenant enterprise memiliki SLA berbeda.

---

### 26. Threshold Override

Urutan resolution:

```text
global default
→ environment
→ domain/module
→ tenant tier
→ tenant-specific override
```

Override wajib:

- terdokumentasi;
- memiliki alasan;
- memiliki effective date;
- diaudit;
- memiliki owner.

---

### 27. Threshold Evaluation Result

```php
final readonly class ThresholdResult
{
    public function __construct(
        public string $status,
        public float|int|null $value,
        public float|int|null $warningThreshold,
        public float|int|null $criticalThreshold,
        public string $comparison,
        public array $reasons,
        public \DateTimeImmutable $evaluatedAt,
    ) {
    }
}
```

---

### 28. Aggregation Types

Supported aggregation:

```text
sum
count
average
min
max
rate
delta
p50
p90
p95
p99
last
first
distinct_count
weighted_average
ratio
availability
```

---

### 29. Aggregation Rules

#### 29.1 Counter

Gunakan:

```text
rate
delta
increase
```

Jangan gunakan `average(counter)`.

#### 29.2 Gauge

Gunakan:

```text
last
average
min
max
```

sesuai kebutuhan.

#### 29.3 Histogram

Gunakan:

```text
p50
p95
p99
```

dari bucket/distribution asli.

#### 29.4 State

Gunakan:

```text
last
worst
availability_by_state
```

---

### 30. Weighted Aggregation

Jika tenant memiliki traffic berbeda, global metric tidak boleh selalu rata-rata sederhana.

Contoh salah:

```text
(global_error_rate) =
average(error_rate_per_tenant)
```

Contoh benar:

```text
global_error_rate =
sum(error_count_per_tenant) /
sum(request_count_per_tenant)
```

---

### 31. Time-Series Model

Time-series terdiri dari:

```text
metric
timestamp
value
dimensions
resolution
source
quality
```

Contoh:

```json
{
  "metric": "http_request_rate",
  "resolution": "1m",
  "series": [
    {
      "timestamp": "2026-07-04T18:00:00+07:00",
      "value": 42.5
    }
  ]
}
```

---

### 32. Resolution

Rekomendasi:

| Time Range | Resolution |
|---|---|
| 15m | 10s–1m |
| 1h | 1m |
| 6h | 5m |
| 24h | 5m–15m |
| 7d | 1h |
| 30d | 6h–1d |
| >30d | daily aggregate |

Dashboard tidak boleh mengambil raw point dalam jumlah tak terbatas.

---

### 33. Downsampling

Downsampling wajib untuk historical chart.

Contoh:

```text
raw 10-second data
→ 1-minute aggregate
→ 5-minute aggregate
→ hourly aggregate
→ daily aggregate
```

Simpan metadata:

```text
aggregation
resolution
sample_count
```

---

### 34. Timezone

Storage timestamp:

```text
UTC
```

Display:

```text
DashboardContext timezone
```

Jangan menyimpan timestamp historical dalam timezone lokal per user.

---

### 35. Missing Data

Missing data dapat berarti:

- benar-benar tidak ada traffic;
- collector gagal;
- metric source gagal;
- metric belum tersedia;
- time range kosong.

Status:

```text
EMPTY
NO_TRAFFIC
STALE
SOURCE_ERROR
INSUFFICIENT_DATA
```

Jangan mengganti missing data menjadi nol tanpa aturan.

---

### 36. Stale Data

Data dianggap stale jika:

```text
now - last_data_timestamp > stale_threshold
```

Contoh:

```json
{
  "status": "STALE",
  "last_updated_at": "2026-07-04T18:45:00+07:00",
  "stale_for_seconds": 900
}
```

---

### 37. Time-Series Quality

Quality metadata:

```text
COMPLETE
PARTIAL
STALE
ESTIMATED
INSUFFICIENT_DATA
```

Widget wajib dapat menampilkan quality warning.

---

### 38. Baseline & Comparison

Comparison mode:

```text
previous_period
previous_day
previous_week
rolling_average
target
baseline
```

Contoh:

```text
current 24h vs previous 24h
```

Jangan membandingkan periode yang berbeda durasi tanpa normalisasi.

---

### 39. Trend Model

Trend fields:

```text
current
previous
absolute_change
percent_change
direction
significance
```

Contoh:

```json
{
  "current": 250,
  "previous": 200,
  "absolute_change": 50,
  "percent_change": 25,
  "direction": "up"
}
```

Untuk latency/error, arah naik biasanya buruk.

Untuk success rate, arah naik biasanya baik.

Metric definition harus memiliki:

```text
desired_direction = up/down/neutral
```

---

### 40. SLI

Service Level Indicator adalah ukuran aktual.

Contoh:

```text
availability
latency
error rate
successful transaction rate
```

SLI wajib memiliki:

- event yang dinilai;
- good event;
- total event;
- scope;
- time window;
- exclusion policy.

---

### 41. SLO

Service Level Objective adalah target internal.

Contoh:

```text
99.9% successful requests per 30 days
95% requests below 500 ms
99% scheduled jobs completed within 5 minutes
```

SLO harus:

- terukur;
- memiliki owner;
- memiliki window;
- memiliki target;
- memiliki exclusion policy;
- dapat dihitung ulang.

---

### 42. SLA

Service Level Agreement adalah komitmen formal.

SLA dapat berbeda dari SLO.

Contoh:

```text
SLO internal = 99.95%
SLA customer = 99.9%
```

Dashboard harus membedakan label:

```text
SLO
SLA
```

---

### 43. Error Budget

Formula:

```text
error_budget =
1 - SLO_target
```

Contoh:

```text
SLO = 99.9%
error budget = 0.1%
```

Untuk 30 hari:

```text
30 hari × 24 jam × 60 menit = 43,200 menit
0.1% = 43.2 menit
```

---

### 44. Error Budget Consumption

```text
consumed_percent =
actual_bad_events / allowed_bad_events × 100
```

Status:

| Consumed | Status |
|---|---|
| < 50% | NORMAL |
| 50–80% | WARNING |
| 80–100% | CRITICAL |
| >100% | EXHAUSTED |

Threshold final configurable.

---

### 45. Burn Rate

Burn rate menunjukkan kecepatan pemakaian error budget.

```text
burn_rate =
observed_error_rate / allowed_error_rate
```

Contoh:

```text
burn rate = 2
```

berarti budget terpakai dua kali lebih cepat dari rencana.

Dashboard dapat menampilkan:

```text
1h burn rate
6h burn rate
24h burn rate
```

---

### 46. Availability Calculation

Metode:

#### Request-Based

```text
good_requests / total_requests
```

#### Time-Based

```text
healthy_duration / total_duration
```

#### Probe-Based

```text
successful_probes / total_probes
```

Metode wajib dinyatakan dalam SLI definition.

---

### 47. Exclusion Policy

Exclusion contoh:

- planned maintenance;
- customer-caused invalid requests;
- unsupported client;
- force majeure bila SLA mengatur;
- synthetic test traffic;
- health endpoint traffic.

Exclusion wajib:

- eksplisit;
- diaudit;
- tidak dapat dimanipulasi bebas;
- ditampilkan pada metadata.

---

### 48. SLA/SLO Definition Example

```php
return [
    'code' => 'platform_api_availability',
    'title' => 'Platform API Availability',
    'type' => 'slo',
    'target_percent' => 99.9,
    'window' => '30d',
    'indicator' => [
        'good_events' => 'http_requests_status_2xx_3xx',
        'total_events' => 'http_requests_eligible_total',
    ],
    'exclusions' => [
        'planned_maintenance',
        'health_probe',
        'client_4xx',
    ],
    'owner' => 'platform_operations',
];
```

---

### 49. KPI Data Contract

```php
final readonly class KpiResult
{
    public function __construct(
        public string $code,
        public string $status,
        public float|int|null $value,
        public string $unit,
        public ?float $target,
        public ?float $warningThreshold,
        public ?float $criticalThreshold,
        public array $trend,
        public array $quality,
        public \DateTimeImmutable $generatedAt,
        public ?\DateTimeImmutable $validUntil = null,
    ) {
    }
}
```

---

### 50. Time-Series Data Contract

```php
final readonly class TimeSeriesResult
{
    public function __construct(
        public string $metric,
        public string $unit,
        public string $resolution,
        public array $series,
        public array $dimensions,
        public string $quality,
        public \DateTimeImmutable $from,
        public \DateTimeImmutable $to,
        public \DateTimeImmutable $generatedAt,
    ) {
    }
}
```

---

### 51. SLA/SLO Result Contract

```php
final readonly class ServiceLevelResult
{
    public function __construct(
        public string $code,
        public string $type,
        public float $targetPercent,
        public float $actualPercent,
        public float $errorBudgetPercent,
        public float $errorBudgetConsumedPercent,
        public float $burnRate,
        public string $window,
        public string $status,
        public array $exclusions,
        public \DateTimeImmutable $generatedAt,
    ) {
    }
}
```

---

### 52. Widget Mapping

Contoh:

| Widget | Source |
|---|---|
| Metric Card | KPI Result |
| Trend Chart | TimeSeriesResult |
| SLA Gauge | ServiceLevelResult |
| Error Budget Card | ServiceLevelResult |
| Health Status | Health State |
| Threshold Badge | ThresholdResult |

---

### 53. Data Source Query Contract

```php
final readonly class MetricQuery
{
    public function __construct(
        public string $metric,
        public array $dimensions,
        public string $aggregation,
        public \DateTimeImmutable $from,
        public \DateTimeImmutable $to,
        public string $resolution,
        public ?int $tenantId,
        public ?int $scopeId,
        public ?string $moduleCode,
    ) {
    }
}
```

---

### 54. Query Validation

Wajib memvalidasi:

- metric terdaftar;
- aggregation diperbolehkan;
- dimension diperbolehkan;
- time range;
- resolution;
- tenant/scope;
- permission;
- maximum series;
- maximum data points.

---

### 55. Data Point Limit

Contoh:

```text
max_points_per_series = 1000
max_series_per_widget = 20
max_dimensions = 5
```

Jika melebihi:

- naikkan resolution;
- minta filter;
- gunakan top-N;
- tolak query.

---

### 56. Top-N

Untuk cardinality tinggi:

```text
top 10 slowest endpoints
top 10 failing integrations
top 10 degraded tenants
```

Jangan mengirim seluruh series.

---

### 57. Cardinality Policy

High-cardinality label yang harus dihindari:

```text
user_id
patient_id
request_id
session_id
email
phone
raw_url
full_exception_message
```

Allowed dimension harus didefinisikan di MetricDefinition.

---

### 58. Tenant Metrics

Tenant dimension dapat mahal.

Strategi:

- aggregate tenant tier;
- top-N tenant;
- tenant-specific query saat drill-down;
- tidak membuat seluruh tenant menjadi label realtime;
- menggunakan pre-aggregation table bila perlu.

---

### 59. Privacy Classification

Metric/KPI wajib memiliki klasifikasi:

```text
PUBLIC
INTERNAL
CONFIDENTIAL
RESTRICTED
```

Contoh:

| Metric | Klasifikasi |
|---|---|
| platform availability | INTERNAL |
| tenant quota usage | CONFIDENTIAL |
| security anomaly rate | RESTRICTED |
| patient-related operational count | RESTRICTED |

---

### 60. Export Policy

Export metric/KPI membutuhkan:

```text
observability.dashboard.export
```

Aturan:

- batasi time range;
- audit export;
- mask restricted fields;
- enforce tenant/scope;
- include generation timestamp;
- include metric definition/version.

---

### 61. Metric Versioning

Breaking change membutuhkan versi baru.

Contoh:

```text
http_error_rate_v1
http_error_rate_v2
```

atau metadata version:

```text
version = 2.0
```

Jangan mengubah denominator diam-diam.

---

### 62. Deprecation

Metric deprecated harus memiliki:

```text
deprecated_at
replacement_metric
removal_after
migration_note
```

Dashboard tidak boleh memakai metric deprecated setelah removal date.

---

### 63. Data Retention

Rekomendasi awal:

| Data | Retention |
|---|---|
| Raw high-resolution metric | 7–30 hari |
| 1-minute aggregate | 30–90 hari |
| Hourly aggregate | 12–24 bulan |
| Daily aggregate | 2–5 tahun |
| SLA/SLO summary | sesuai kontrak/audit |

Retention final mengikuti kebijakan observability dan compliance.

---

### 64. Aggregation Storage

Pre-aggregation dapat disimpan dalam table:

```text
metric_hourly_aggregates
metric_daily_aggregates
slo_period_results
```

Dashboard overview tidak boleh menghitung seluruh history mentah pada setiap request.

---

### 65. Recommended Core KPI Catalog

#### Platform

```text
platform_availability_percent
platform_error_rate_percent
platform_request_rate
platform_p95_latency_ms
platform_active_alert_total
platform_active_incident_total
```

#### Database

```text
database_p95_latency_ms
database_connection_usage_percent
database_error_rate_percent
database_slow_query_total
```

#### Queue

```text
queue_pending_jobs
queue_oldest_job_seconds
queue_failure_rate_percent
queue_worker_active_total
```

#### Scheduler

```text
scheduler_last_heartbeat_age_seconds
scheduler_overdue_job_total
scheduler_failure_rate_percent
```

#### Integration

```text
integration_success_rate_percent
integration_p95_latency_ms
integration_retry_total
integration_dead_letter_total
```

#### Security

```text
security_failed_login_rate
security_privileged_mfa_compliance_percent
security_expired_credential_total
security_control_failure_total
```

---

### 66. KPI Status Evaluation

Contoh:

```text
value = 2.5%
warning = 1%
critical = 5%
```

Hasil:

```text
WARNING
```

Jika value null:

```text
UNKNOWN atau EMPTY
```

sesuai quality metadata.

---

### 67. Partial Data

Jika hanya 70% source tersedia:

```json
{
  "quality": "PARTIAL",
  "coverage_percent": 70
}
```

Dashboard wajib menampilkan warning.

---

### 68. Aggregation Across Environments

Jangan menggabungkan:

```text
local
staging
production
```

secara default.

Environment wajib dimension terpisah.

---

### 69. Aggregation Across Tenants

Global dashboard boleh menampilkan aggregate semua tenant hanya untuk role berwenang.

Tenant dashboard wajib filter satu tenant.

---

### 70. Comparison Semantics

Setiap KPI harus menentukan apakah kenaikan baik atau buruk.

Field:

```text
desired_direction
```

Nilai:

```text
up
down
neutral
```

Contoh:

- availability: up;
- error rate: down;
- queue backlog: down;
- throughput: context-dependent.

---

### 71. Visualization Guidance

#### Metric Card

Gunakan untuk:

- nilai tunggal;
- target;
- trend singkat.

#### Line Chart

Gunakan untuk:

- time-series;
- latency;
- throughput;
- error rate.

#### Bar Chart

Gunakan untuk:

- per component;
- per module;
- top-N.

#### Gauge

Gunakan terbatas untuk:

- capacity;
- SLA/SLO;
- error budget.

#### Table

Gunakan untuk:

- detail;
- ranking;
- current states.

---

### 72. Visualization Anti-Pattern

Hindari:

- pie chart terlalu banyak kategori;
- dual-axis tanpa alasan;
- chart 3D;
- warna tanpa semantic meaning;
- truncate axis yang menyesatkan;
- menampilkan average tanpa percentile;
- terlalu banyak series;
- chart tanpa timezone;
- chart tanpa unit;
- chart tanpa quality metadata.

---

### 73. Alert Threshold vs Dashboard Threshold

Dashboard threshold dan alert threshold dapat berbeda.

Contoh:

```text
Dashboard warning = 1%
Alert warning = 2% selama 5 menit
```

Dashboard memberi awareness lebih awal.

Alert membutuhkan noise control.

Definisi keduanya harus terkait tetapi tidak dipaksa identik.

---

### 74. Performance Requirements

Target:

| Query | Target |
|---|---:|
| Current KPI | < 300 ms cached |
| 1h time-series | < 1000 ms |
| 24h aggregate | < 1500 ms |
| 30d aggregate | < 2000 ms |
| SLA/SLO summary | < 1000 ms cached |

---

### 75. Caching Strategy

Cache berdasarkan:

```text
metric
aggregation
dimensions
time range
resolution
tenant
scope
module
environment
```

TTL:

| Data | TTL |
|---|---:|
| Current health/KPI | 15–30 detik |
| 1h chart | 30–60 detik |
| 24h chart | 1–5 menit |
| 30d chart | 15–60 menit |
| SLA/SLO | 5–15 menit |

---

### 76. Error Codes

```text
METRIC_NOT_REGISTERED
KPI_NOT_REGISTERED
AGGREGATION_NOT_ALLOWED
DIMENSION_NOT_ALLOWED
TIME_RANGE_INVALID
RESOLUTION_INVALID
DATA_SOURCE_TIMEOUT
INSUFFICIENT_DATA
DATA_STALE
SLO_DEFINITION_INVALID
THRESHOLD_NOT_FOUND
CARDINALITY_LIMIT_EXCEEDED
```

---

### 77. Logging

Structured log minimum:

```json
{
  "event": "dashboard_metric_query",
  "metric": "http_request_duration_ms",
  "aggregation": "p95",
  "time_range": "1h",
  "resolution": "1m",
  "duration_ms": 120,
  "cache_hit": true,
  "tenant_id": null,
  "scope_id": null
}
```

Jangan log raw sensitive dimensions.

---

### 78. Metrics About Metrics

Pantau:

```text
metric_query_total
metric_query_duration_ms
metric_query_error_total
metric_cache_hit_total
metric_cache_miss_total
metric_stale_result_total
metric_cardinality_rejected_total
slo_calculation_total
slo_calculation_error_total
```

---

### 79. Security Controls

- Metric Registry tidak dapat diubah user biasa.
- Custom KPI tidak boleh menerima formula bebas tanpa parser aman.
- Query tidak boleh menerima raw SQL.
- Dimension wajib allowlist.
- Time range wajib dibatasi.
- Tenant/scope wajib enforced.
- Export wajib diaudit.
- Restricted metric membutuhkan permission khusus.

---

### 80. Anti-Pattern

Hindari:

- KPI tanpa formula;
- denominator tidak jelas;
- average of averages;
- average of percentiles;
- missing data dianggap nol;
- threshold hardcoded di frontend;
- query raw metric untuk 30 hari;
- label high-cardinality;
- tenant ID sebagai unrestricted metric label;
- custom formula dengan `eval`;
- SLA dan SLO dianggap sama;
- maintenance tidak dieksklusi sesuai policy;
- error budget dihitung tanpa window;
- metric definition berubah tanpa versioning.

---

### 81. UAT Part 2

#### Metric Registry

- [ ] Metric name unik.
- [ ] Unit valid.
- [ ] Type valid.
- [ ] Dimension allowlist diterapkan.
- [ ] Deprecated metric terdeteksi.

#### KPI

- [ ] Formula terdokumentasi.
- [ ] Denominator nol menghasilkan EMPTY/UNKNOWN.
- [ ] Owner tersedia.
- [ ] Target dan threshold tersedia.
- [ ] Desired direction benar.

#### Threshold

- [ ] Warning dan critical bekerja.
- [ ] Recovery hysteresis bekerja.
- [ ] Minimum sample diterapkan.
- [ ] Override resolution benar.
- [ ] Perubahan threshold diaudit.

#### Aggregation

- [ ] Counter memakai rate/delta.
- [ ] Histogram percentile benar.
- [ ] Weighted aggregation benar.
- [ ] Global tenant rate tidak memakai simple average.
- [ ] Environment tidak tercampur.

#### Time-Series

- [ ] Resolution menyesuaikan range.
- [ ] Max data point diterapkan.
- [ ] Missing data tidak diubah jadi nol.
- [ ] Stale data diberi label.
- [ ] Timezone display benar.

#### SLA/SLO

- [ ] SLI terdefinisi.
- [ ] SLO target benar.
- [ ] SLA dibedakan.
- [ ] Error budget dihitung.
- [ ] Burn rate dihitung.
- [ ] Exclusion policy diterapkan.

#### Security

- [ ] Restricted metric membutuhkan permission.
- [ ] Tenant isolation bekerja.
- [ ] Raw SQL tidak diterima.
- [ ] Custom formula aman.
- [ ] Export diaudit.

---

### 82. Definition of Done Part 2

Part 2 dianggap selesai bila:

- [ ] metric taxonomy disetujui;
- [ ] naming convention disetujui;
- [ ] unit standard tersedia;
- [ ] MetricDefinition tersedia;
- [ ] Metric Registry tersedia;
- [ ] KPI Definition tersedia;
- [ ] threshold model tersedia;
- [ ] hysteresis tersedia;
- [ ] minimum sample tersedia;
- [ ] aggregation rules tersedia;
- [ ] time-series model tersedia;
- [ ] resolution policy tersedia;
- [ ] missing/stale data policy tersedia;
- [ ] trend model tersedia;
- [ ] SLI/SLO/SLA tersedia;
- [ ] error budget tersedia;
- [ ] burn rate tersedia;
- [ ] data contracts tersedia;
- [ ] cardinality policy tersedia;
- [ ] retention policy awal tersedia;
- [ ] UAT tersedia.

---

### 83. Rencana Part Berikutnya

Part 3 membahas:

- Dashboard Registry implementation;
- Widget Registry;
- Metric Registry implementation;
- Query Orchestrator;
- cache;
- provider contracts;
- PHP interfaces;
- database schema;
- layout persistence;
- widget execution policy.

---

## Bagian III — Registry, Query Orchestrator, Cache, PHP Interfaces & Database Schema

### 1. Executive Summary

Part 3 mendefinisikan implementasi inti Monitoring Dashboard Framework.

Bagian ini menetapkan kontrak untuk:

- Dashboard Registry;
- Widget Registry;
- Metric Registry;
- KPI Registry;
- Threshold Registry;
- Dashboard Service;
- Query Orchestrator;
- Widget Executor;
- Data Source Adapter;
- Cache;
- layout persistence;
- user customization;
- database schema;
- telemetry;
- error handling;
- UAT.

Tujuan utamanya adalah memastikan seluruh dashboard dan widget dapat diregistrasikan, dieksekusi, di-cache, diotorisasi, dan diproyeksikan secara konsisten.

---

### 2. Core Architecture

```text
HTTP Controller / CLI
        │
        ▼
Dashboard Application Service
        │
        ├── Dashboard Registry
        ├── Widget Registry
        ├── Metric Registry
        ├── KPI Registry
        ├── Threshold Registry
        │
        ▼
Query Orchestrator
        │
        ├── Access Policy
        ├── Query Planner
        ├── Widget Executor
        ├── Cache
        ├── Data Source Adapters
        └── Telemetry
        │
        ▼
Dashboard Result
```

---

### 3. Core Domain Objects

Core objects:

```text
DashboardDefinition
DashboardSectionDefinition
WidgetDefinition
MetricDefinition
KpiDefinition
ThresholdDefinition
DashboardContext
DashboardQuery
WidgetQuery
WidgetResult
DashboardResult
DashboardLayout
DashboardLayoutItem
```

---

### 4. DashboardDefinition

```php
<?php

declare(strict_types=1);

namespace App\Platform\Observability\Dashboard\Domain;

final readonly class DashboardDefinition
{
    /**
     * @param list<string> $audiences
     * @param list<string> $permissions
     * @param list<DashboardSectionDefinition> $sections
     */
    public function __construct(
        public string $code,
        public string $title,
        public string $description,
        public string $category,
        public array $audiences,
        public array $permissions,
        public string $scopeType,
        public string $defaultTimeRange,
        public string $maxTimeRange,
        public int $refreshSeconds,
        public array $sections,
        public bool $enabled = true,
        public string $version = '1.0',
    ) {
        if ($this->code === '') {
            throw new \InvalidArgumentException('Dashboard code cannot be empty.');
        }

        if ($this->refreshSeconds < 0) {
            throw new \InvalidArgumentException(
                'Dashboard refresh interval cannot be negative.'
            );
        }
    }
}
```

---

### 5. DashboardSectionDefinition

```php
final readonly class DashboardSectionDefinition
{
    /**
     * @param list<string> $widgetCodes
     */
    public function __construct(
        public string $code,
        public string $title,
        public int $position,
        public array $widgetCodes,
        public bool $collapsible = false,
        public bool $collapsedByDefault = false,
    ) {
    }
}
```

---

### 6. WidgetDefinition

```php
<?php

declare(strict_types=1);

namespace App\Platform\Observability\Dashboard\Domain;

final readonly class WidgetDefinition
{
    /**
     * @param list<string> $permissions
     * @param list<string> $supportedTimeRanges
     * @param array<string, mixed> $layout
     * @param array<string, mixed> $options
     */
    public function __construct(
        public string $code,
        public string $title,
        public string $type,
        public string $providerCode,
        public array $permissions,
        public string $scopeType,
        public string $criticality,
        public int $refreshSeconds,
        public array $supportedTimeRanges,
        public string $dataClassification,
        public array $layout,
        public array $options = [],
        public bool $enabled = true,
        public string $version = '1.0',
    ) {
    }
}
```

---

### 7. MetricDefinition

```php
final readonly class MetricDefinition
{
    /**
     * @param list<string> $dimensions
     * @param list<string> $aggregations
     * @param list<string> $supportedTimeRanges
     */
    public function __construct(
        public string $name,
        public string $title,
        public string $description,
        public string $type,
        public string $unit,
        public string $domain,
        public string $owner,
        public string $source,
        public array $dimensions,
        public array $aggregations,
        public array $supportedTimeRanges,
        public string $privacyClassification,
        public string $desiredDirection,
        public string $version = '1.0',
        public bool $enabled = true,
    ) {
    }
}
```

---

### 8. KpiDefinition

```php
final readonly class KpiDefinition
{
    /**
     * @param list<string> $sourceMetrics
     */
    public function __construct(
        public string $code,
        public string $title,
        public string $description,
        public string $formula,
        public array $sourceMetrics,
        public string $unit,
        public float|int|null $target,
        public float|int|null $warningThreshold,
        public float|int|null $criticalThreshold,
        public string $comparison,
        public string $timeWindow,
        public string $owner,
        public string $desiredDirection,
        public string $version = '1.0',
    ) {
    }
}
```

---

### 9. ThresholdDefinition

```php
final readonly class ThresholdDefinition
{
    public function __construct(
        public string $code,
        public string $metricOrKpiCode,
        public string $comparison,
        public float|int|null $warning,
        public float|int|null $critical,
        public float|int|null $recovery,
        public string $window,
        public int $minimumSamples,
        public int $cooldownSeconds,
        public string $scopeType,
        public ?string $environment = null,
        public ?int $tenantId = null,
        public string $version = '1.0',
    ) {
    }
}
```

---

### 10. Registry Contracts

#### 10.1 Dashboard Registry

```php
interface DashboardRegistryInterface
{
    public function register(DashboardDefinition $definition): void;

    public function get(string $code): DashboardDefinition;

    /**
     * @return list<DashboardDefinition>
     */
    public function all(): array;

    /**
     * @return list<DashboardDefinition>
     */
    public function availableFor(DashboardContext $context): array;
}
```

#### 10.2 Widget Registry

```php
interface WidgetRegistryInterface
{
    public function register(WidgetDefinition $definition): void;

    public function get(string $code): WidgetDefinition;

    /**
     * @return list<WidgetDefinition>
     */
    public function all(): array;
}
```

#### 10.3 Metric Registry

```php
interface MetricRegistryInterface
{
    public function register(MetricDefinition $definition): void;

    public function get(string $name): MetricDefinition;

    public function has(string $name): bool;

    public function all(): array;
}
```

#### 10.4 KPI Registry

```php
interface KpiRegistryInterface
{
    public function register(KpiDefinition $definition): void;

    public function get(string $code): KpiDefinition;

    public function all(): array;
}
```

#### 10.5 Threshold Registry

```php
interface ThresholdRegistryInterface
{
    public function register(ThresholdDefinition $definition): void;

    public function resolve(
        string $metricOrKpiCode,
        DashboardContext $context
    ): ?ThresholdDefinition;
}
```

---

### 11. Registry Rules

Setiap registry wajib:

- menolak code kosong;
- menolak duplicate code;
- menolak definition invalid;
- menolak provider yang tidak tersedia;
- menolak metric dengan unit/type invalid;
- menolak widget yang merujuk metric tidak terdaftar;
- menolak dashboard yang merujuk widget tidak terdaftar;
- gagal saat bootstrap pada configuration error.

---

### 12. Example Dashboard Registry

```php
final class DashboardRegistry implements DashboardRegistryInterface
{
    /** @var array<string, DashboardDefinition> */
    private array $items = [];

    public function register(DashboardDefinition $definition): void
    {
        if (isset($this->items[$definition->code])) {
            throw new \LogicException(
                sprintf(
                    'Dashboard "%s" is already registered.',
                    $definition->code
                )
            );
        }

        $this->items[$definition->code] = $definition;
    }

    public function get(string $code): DashboardDefinition
    {
        if (!isset($this->items[$code])) {
            throw new \OutOfBoundsException(
                sprintf('Dashboard "%s" is not registered.', $code)
            );
        }

        return $this->items[$code];
    }

    public function all(): array
    {
        return array_values($this->items);
    }

    public function availableFor(DashboardContext $context): array
    {
        return array_values(array_filter(
            $this->items,
            static fn (DashboardDefinition $definition): bool =>
                $definition->enabled
        ));
    }
}
```

Authorization final tetap dilakukan oleh Access Policy, bukan registry saja.

---

### 13. Widget Provider Contract

```php
interface WidgetProviderInterface
{
    public function code(): string;

    /**
     * @return list<string>
     */
    public function supportedWidgets(): array;

    public function fetch(
        WidgetQuery $query,
        DashboardContext $context
    ): WidgetResult;
}
```

---

### 14. Widget Provider Registry

```php
interface WidgetProviderRegistryInterface
{
    public function register(WidgetProviderInterface $provider): void;

    public function get(string $providerCode): WidgetProviderInterface;
}
```

Provider code harus unik.

Contoh:

```text
health.overall
health.components
metrics.kpi
metrics.timeseries
alerts.active
incidents.active
security.summary
tenant.summary
```

---

### 15. DashboardContext

```php
final readonly class DashboardContext
{
    /**
     * @param list<string> $permissions
     * @param list<string> $roles
     */
    public function __construct(
        public int $actorUserId,
        public array $permissions,
        public array $roles,
        public string $environment,
        public ?int $tenantId,
        public ?int $scopeId,
        public ?string $moduleCode,
        public string $timezone,
        public string $locale,
        public string $timeRange,
        public ?string $correlationId,
    ) {
    }
}
```

---

### 16. DashboardQuery

```php
final readonly class DashboardQuery
{
    /**
     * @param list<string> $widgetCodes
     */
    public function __construct(
        public string $dashboardCode,
        public array $widgetCodes,
        public string $timeRange,
        public bool $forceRefresh = false,
        public ?int $tenantId = null,
        public ?int $scopeId = null,
        public ?string $moduleCode = null,
    ) {
    }
}
```

---

### 17. WidgetQuery

```php
final readonly class WidgetQuery
{
    /**
     * @param array<string, mixed> $filters
     */
    public function __construct(
        public string $widgetCode,
        public string $timeRange,
        public array $filters,
        public bool $forceRefresh = false,
    ) {
    }
}
```

---

### 18. WidgetResult

```php
final readonly class WidgetResult
{
    /**
     * @param array<string, mixed> $meta
     * @param list<string> $warnings
     */
    public function __construct(
        public string $widgetCode,
        public string $status,
        public mixed $data,
        public array $meta,
        public array $warnings,
        public \DateTimeImmutable $generatedAt,
        public ?\DateTimeImmutable $validUntil = null,
        public ?string $errorCode = null,
    ) {
    }
}
```

Supported status:

```text
READY
EMPTY
DEGRADED
ERROR
UNAUTHORIZED
STALE
```

---

### 19. DashboardResult

```php
final readonly class DashboardResult
{
    /**
     * @param array<string, WidgetResult> $widgets
     */
    public function __construct(
        public string $dashboardCode,
        public string $status,
        public array $widgets,
        public int $durationMs,
        public \DateTimeImmutable $generatedAt,
        public string $requestId,
    ) {
    }
}
```

---

### 20. Access Policy Contract

```php
interface DashboardAccessPolicyInterface
{
    public function canViewDashboard(
        DashboardDefinition $dashboard,
        DashboardContext $context
    ): bool;

    public function canViewWidget(
        WidgetDefinition $widget,
        DashboardContext $context
    ): bool;

    public function assertTenantAccess(
        ?int $tenantId,
        DashboardContext $context
    ): void;

    public function assertScopeAccess(
        ?int $scopeId,
        DashboardContext $context
    ): void;
}
```

---

### 21. Query Orchestrator

Query Orchestrator adalah komponen inti yang:

1. membaca dashboard definition;
2. resolve widget;
3. memvalidasi access;
4. membuat execution plan;
5. mengelompokkan query sejenis;
6. membaca cache;
7. menjalankan provider;
8. menangani partial failure;
9. mengagregasi status dashboard;
10. mencatat telemetry.

---

### 22. Query Plan

Query plan harus berisi:

```text
dashboard
widgets
providers
data_sources
cache_keys
execution_order
dependencies
timeouts
criticality
```

Contoh:

```text
overall_health
  provider: health.overall
  source: health_store

request_rate
  provider: metrics.timeseries
  source: metrics_store

error_rate
  provider: metrics.kpi
  source: metrics_store
```

---

### 23. Query De-Duplication

Jika beberapa widget memakai source query sama:

```text
request_rate
error_rate
latency
```

orchestrator dapat membuat satu batch query.

Tujuan:

- mengurangi round trip;
- menghindari query berulang;
- meningkatkan cache reuse;
- mengurangi load.

---

### 24. Widget Execution Policy

Execution policy menentukan:

```text
timeout
cache TTL
criticality
retry
fallback
stale allowance
```

Contoh:

| Widget | Timeout | TTL | Fallback |
|---|---:|---:|---|
| Overall Health | 500 ms | 15 s | stale 60 s |
| Active Alerts | 1000 ms | 30 s | empty |
| p95 Latency | 1500 ms | 60 s | stale 5 m |
| Security Summary | 1000 ms | 60 s | error |
| Executive SLA | 2000 ms | 300 s | stale 1 h |

---

### 25. Widget Executor Contract

```php
interface WidgetExecutorInterface
{
    public function execute(
        WidgetDefinition $definition,
        WidgetQuery $query,
        DashboardContext $context
    ): WidgetResult;
}
```

Executor bertanggung jawab untuk:

- provider resolution;
- timeout;
- exception mapping;
- cache;
- sanitization;
- telemetry;
- stale fallback.

---

### 26. Dashboard Service

```php
final class DashboardService
{
    public function __construct(
        private readonly DashboardRegistryInterface $dashboards,
        private readonly WidgetRegistryInterface $widgets,
        private readonly DashboardAccessPolicyInterface $access,
        private readonly DashboardQueryPlannerInterface $planner,
        private readonly WidgetExecutorInterface $executor,
        private readonly DashboardStatusAggregatorInterface $aggregator,
        private readonly DashboardTelemetryInterface $telemetry,
    ) {
    }

    public function render(
        DashboardQuery $query,
        DashboardContext $context
    ): DashboardResult {
        $startedAt = hrtime(true);

        $dashboard = $this->dashboards->get($query->dashboardCode);

        if (!$this->access->canViewDashboard($dashboard, $context)) {
            throw new \RuntimeException('Dashboard access denied.');
        }

        $plan = $this->planner->plan($dashboard, $query, $context);
        $results = [];

        foreach ($plan->widgets as $widgetPlan) {
            $results[$widgetPlan->definition->code] =
                $this->executor->execute(
                    $widgetPlan->definition,
                    $widgetPlan->query,
                    $context
                );
        }

        $status = $this->aggregator->aggregate($results);
        $durationMs = (int) ((hrtime(true) - $startedAt) / 1_000_000);

        $result = new DashboardResult(
            dashboardCode: $dashboard->code,
            status: $status,
            widgets: $results,
            durationMs: $durationMs,
            generatedAt: new \DateTimeImmutable(),
            requestId: $context->correlationId
                ?? bin2hex(random_bytes(12)),
        );

        $this->telemetry->recordDashboard($result, $context);

        return $result;
    }
}
```

---

### 27. Dashboard Status Aggregator

Rules:

| Widget Result | Dampak |
|---|---|
| critical ERROR | Dashboard ERROR |
| critical STALE | DEGRADED/ERROR sesuai policy |
| important ERROR | DEGRADED |
| optional ERROR | tetap READY atau DEGRADED |
| seluruh widget EMPTY | EMPTY |
| unauthorized dashboard | UNAUTHORIZED |

Kontrak:

```php
interface DashboardStatusAggregatorInterface
{
    /**
     * @param array<string, WidgetResult> $results
     */
    public function aggregate(array $results): string;
}
```

---

### 28. Data Source Adapter Contract

```php
interface DashboardDataSourceInterface
{
    public function name(): string;

    public function supports(string $queryType): bool;

    public function query(
        DashboardDataQuery $query,
        DashboardContext $context
    ): DashboardDataSet;
}
```

---

### 29. DashboardDataQuery

```php
final readonly class DashboardDataQuery
{
    /**
     * @param array<string, mixed> $filters
     * @param array<string, string> $dimensions
     */
    public function __construct(
        public string $queryType,
        public string $metricOrEntity,
        public string $aggregation,
        public \DateTimeImmutable $from,
        public \DateTimeImmutable $to,
        public string $resolution,
        public array $filters,
        public array $dimensions,
        public int $limit = 1000,
    ) {
    }
}
```

---

### 30. Data Source Adapters

Initial adapters:

```text
HealthStateDataSource
MetricStoreDataSource
AlertDataSource
IncidentDataSource
LogSummaryDataSource
TraceSummaryDataSource
OperationalDatabaseDataSource
```

Raw logs dan traces tidak boleh digunakan pada overview.

---

### 31. Cache Contracts

#### 31.1 Widget Cache

```php
interface WidgetCacheInterface
{
    public function get(
        string $key
    ): ?WidgetResult;

    public function put(
        string $key,
        WidgetResult $result,
        int $ttlSeconds
    ): void;

    public function forget(string $key): void;
}
```

#### 31.2 Dashboard Metadata Cache

```php
interface DashboardMetadataCacheInterface
{
    public function get(string $dashboardCode): ?array;

    public function put(
        string $dashboardCode,
        array $metadata,
        int $ttlSeconds
    ): void;
}
```

---

### 32. Cache Key Standard

Format:

```text
dashboard:{dashboard}:{environment}:{tenant}:{scope}:{time_range}
widget:{widget}:{environment}:{tenant}:{scope}:{module}:{time_range}:{hash}
```

Contoh:

```text
widget:http_error_rate:production:tenant12:scope4:global:1h:a84d...
```

---

### 33. Cache Key Rules

Cache key wajib menyertakan:

- environment;
- tenant;
- scope;
- module;
- time range;
- aggregation/filter hash;
- widget version.

Jangan menyertakan:

- token;
- session ID;
- email;
- PHI;
- raw user input.

---

### 34. Stale-While-Revalidate

Untuk historical widget:

```text
fresh TTL = 60 detik
stale TTL = 5 menit
```

Jika data fresh tidak tersedia:

- kembalikan stale result;
- tandai status `STALE`;
- trigger refresh pada scheduled/background process;
- jangan memblokir user terlalu lama.

---

### 35. Cache Invalidation

Invalidate saat:

- dashboard definition berubah;
- widget definition berubah;
- threshold berubah;
- permission policy berubah;
- tenant scope berubah;
- metric version berubah;
- manual admin action.

Manual invalidation wajib:

- permission;
- audit;
- bounded target.

---

### 36. Layout Persistence

Layout dapat berasal dari:

```text
system default
role default
tenant default
user customization
```

Urutan resolution:

```text
system
→ role
→ tenant
→ user
```

---

### 37. DashboardLayout

```php
final readonly class DashboardLayout
{
    /**
     * @param list<DashboardLayoutItem> $items
     */
    public function __construct(
        public string $dashboardCode,
        public string $ownerType,
        public ?int $ownerId,
        public array $items,
        public int $version,
        public \DateTimeImmutable $updatedAt,
    ) {
    }
}
```

---

### 38. DashboardLayoutItem

```php
final readonly class DashboardLayoutItem
{
    public function __construct(
        public string $widgetCode,
        public int $x,
        public int $y,
        public int $width,
        public int $height,
        public string $breakpoint,
        public bool $visible = true,
    ) {
    }
}
```

---

### 39. Layout Validation

Wajib memvalidasi:

- widget terdaftar;
- width dan height valid;
- breakpoint valid;
- tidak ada duplicate item;
- user boleh melihat widget;
- user tidak dapat menambahkan restricted widget;
- posisi tidak negatif;
- maximum layout size.

---

### 40. Layout Versioning

Gunakan optimistic concurrency:

```text
layout_version
```

Saat update:

```text
WHERE id = ? AND version = ?
```

Jika version berubah:

```text
DASHBOARD_LAYOUT_CONFLICT
```

---

### 41. Database Schema Overview

Tables:

```text
dashboard_definitions
dashboard_sections
widget_definitions
dashboard_widget_assignments
dashboard_layouts
dashboard_layout_items
metric_definitions
kpi_definitions
threshold_definitions
dashboard_query_snapshots
```

Config-first tetap direkomendasikan untuk system definition.

Database digunakan untuk:

- customization;
- override;
- lifecycle;
- audit-friendly metadata;
- runtime enable/disable bila governance mengizinkan.

---

### 42. Table: dashboard_definitions

```sql
CREATE TABLE dashboard_definitions (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    code VARCHAR(100) NOT NULL,
    title VARCHAR(200) NOT NULL,
    description VARCHAR(1000) NULL,
    category VARCHAR(100) NOT NULL,
    scope_type VARCHAR(50) NOT NULL,
    permission_code VARCHAR(150) NULL,
    default_time_range VARCHAR(20) NOT NULL DEFAULT '1h',
    max_time_range VARCHAR(20) NOT NULL DEFAULT '30d',
    refresh_seconds INT UNSIGNED NOT NULL DEFAULT 60,
    definition_version VARCHAR(20) NOT NULL DEFAULT '1.0',
    enabled TINYINT(1) NOT NULL DEFAULT 1,
    source_type VARCHAR(20) NOT NULL DEFAULT 'config',
    created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    updated_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6)
        ON UPDATE CURRENT_TIMESTAMP(6),

    PRIMARY KEY (id),
    UNIQUE KEY uq_dashboard_definition_code (code),
    KEY idx_dashboard_definition_enabled (enabled, category)
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

### 43. Table: dashboard_sections

```sql
CREATE TABLE dashboard_sections (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    dashboard_definition_id BIGINT UNSIGNED NOT NULL,
    code VARCHAR(100) NOT NULL,
    title VARCHAR(200) NOT NULL,
    position INT UNSIGNED NOT NULL DEFAULT 0,
    collapsible TINYINT(1) NOT NULL DEFAULT 0,
    collapsed_by_default TINYINT(1) NOT NULL DEFAULT 0,
    created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    updated_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6)
        ON UPDATE CURRENT_TIMESTAMP(6),

    PRIMARY KEY (id),
    CONSTRAINT fk_dashboard_section_definition
        FOREIGN KEY (dashboard_definition_id)
        REFERENCES dashboard_definitions(id)
        ON DELETE CASCADE,

    UNIQUE KEY uq_dashboard_section_code (
        dashboard_definition_id,
        code
    ),
    KEY idx_dashboard_section_position (
        dashboard_definition_id,
        position
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

### 44. Table: widget_definitions

```sql
CREATE TABLE widget_definitions (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    code VARCHAR(120) NOT NULL,
    title VARCHAR(200) NOT NULL,
    widget_type VARCHAR(50) NOT NULL,
    provider_code VARCHAR(120) NOT NULL,
    permission_code VARCHAR(150) NULL,
    scope_type VARCHAR(50) NOT NULL,
    criticality VARCHAR(20) NOT NULL DEFAULT 'optional',
    data_classification VARCHAR(20) NOT NULL DEFAULT 'INTERNAL',
    refresh_seconds INT UNSIGNED NOT NULL DEFAULT 60,
    supported_time_ranges_json JSON NULL,
    layout_json JSON NULL,
    options_json JSON NULL,
    definition_version VARCHAR(20) NOT NULL DEFAULT '1.0',
    enabled TINYINT(1) NOT NULL DEFAULT 1,
    source_type VARCHAR(20) NOT NULL DEFAULT 'config',
    created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    updated_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6)
        ON UPDATE CURRENT_TIMESTAMP(6),

    PRIMARY KEY (id),
    UNIQUE KEY uq_widget_definition_code (code),
    KEY idx_widget_definition_provider (provider_code),
    KEY idx_widget_definition_enabled (enabled, widget_type)
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

### 45. Table: dashboard_widget_assignments

```sql
CREATE TABLE dashboard_widget_assignments (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    dashboard_section_id BIGINT UNSIGNED NOT NULL,
    widget_definition_id BIGINT UNSIGNED NOT NULL,
    position INT UNSIGNED NOT NULL DEFAULT 0,
    required TINYINT(1) NOT NULL DEFAULT 0,
    override_options_json JSON NULL,
    created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),

    PRIMARY KEY (id),
    CONSTRAINT fk_dashboard_widget_section
        FOREIGN KEY (dashboard_section_id)
        REFERENCES dashboard_sections(id)
        ON DELETE CASCADE,
    CONSTRAINT fk_dashboard_widget_definition
        FOREIGN KEY (widget_definition_id)
        REFERENCES widget_definitions(id)
        ON DELETE RESTRICT,

    UNIQUE KEY uq_dashboard_widget_assignment (
        dashboard_section_id,
        widget_definition_id
    ),
    KEY idx_dashboard_widget_position (
        dashboard_section_id,
        position
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

### 46. Table: dashboard_layouts

```sql
CREATE TABLE dashboard_layouts (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    dashboard_definition_id BIGINT UNSIGNED NOT NULL,
    owner_type VARCHAR(20) NOT NULL,
    owner_id BIGINT UNSIGNED NULL,
    tenant_id BIGINT UNSIGNED NULL,
    scope_id BIGINT UNSIGNED NULL,
    layout_version INT UNSIGNED NOT NULL DEFAULT 1,
    is_default TINYINT(1) NOT NULL DEFAULT 0,
    created_by BIGINT UNSIGNED NULL,
    updated_by BIGINT UNSIGNED NULL,
    created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    updated_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6)
        ON UPDATE CURRENT_TIMESTAMP(6),

    PRIMARY KEY (id),
    CONSTRAINT fk_dashboard_layout_definition
        FOREIGN KEY (dashboard_definition_id)
        REFERENCES dashboard_definitions(id)
        ON DELETE CASCADE,

    KEY idx_dashboard_layout_owner (
        owner_type,
        owner_id,
        dashboard_definition_id
    ),
    KEY idx_dashboard_layout_tenant (
        tenant_id,
        scope_id,
        dashboard_definition_id
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

### 47. Table: dashboard_layout_items

```sql
CREATE TABLE dashboard_layout_items (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    dashboard_layout_id BIGINT UNSIGNED NOT NULL,
    widget_definition_id BIGINT UNSIGNED NOT NULL,
    breakpoint VARCHAR(20) NOT NULL,
    grid_x INT UNSIGNED NOT NULL DEFAULT 0,
    grid_y INT UNSIGNED NOT NULL DEFAULT 0,
    grid_width INT UNSIGNED NOT NULL,
    grid_height INT UNSIGNED NOT NULL,
    visible TINYINT(1) NOT NULL DEFAULT 1,
    created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    updated_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6)
        ON UPDATE CURRENT_TIMESTAMP(6),

    PRIMARY KEY (id),
    CONSTRAINT fk_dashboard_layout_item_layout
        FOREIGN KEY (dashboard_layout_id)
        REFERENCES dashboard_layouts(id)
        ON DELETE CASCADE,
    CONSTRAINT fk_dashboard_layout_item_widget
        FOREIGN KEY (widget_definition_id)
        REFERENCES widget_definitions(id)
        ON DELETE RESTRICT,

    UNIQUE KEY uq_dashboard_layout_item (
        dashboard_layout_id,
        widget_definition_id,
        breakpoint
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

### 48. Table: metric_definitions

```sql
CREATE TABLE metric_definitions (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    name VARCHAR(150) NOT NULL,
    title VARCHAR(200) NOT NULL,
    description VARCHAR(1000) NULL,
    metric_type VARCHAR(30) NOT NULL,
    unit VARCHAR(30) NOT NULL,
    domain_code VARCHAR(100) NOT NULL,
    owner_code VARCHAR(100) NOT NULL,
    source_code VARCHAR(100) NOT NULL,
    allowed_dimensions_json JSON NULL,
    allowed_aggregations_json JSON NULL,
    supported_time_ranges_json JSON NULL,
    privacy_classification VARCHAR(20) NOT NULL DEFAULT 'INTERNAL',
    desired_direction VARCHAR(20) NOT NULL DEFAULT 'neutral',
    definition_version VARCHAR(20) NOT NULL DEFAULT '1.0',
    enabled TINYINT(1) NOT NULL DEFAULT 1,
    deprecated_at DATETIME(6) NULL,
    replacement_metric VARCHAR(150) NULL,
    created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    updated_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6)
        ON UPDATE CURRENT_TIMESTAMP(6),

    PRIMARY KEY (id),
    UNIQUE KEY uq_metric_definition_name (name),
    KEY idx_metric_definition_domain (domain_code, enabled)
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

### 49. Table: kpi_definitions

```sql
CREATE TABLE kpi_definitions (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    code VARCHAR(150) NOT NULL,
    title VARCHAR(200) NOT NULL,
    description VARCHAR(1000) NULL,
    formula_expression VARCHAR(2000) NOT NULL,
    source_metrics_json JSON NOT NULL,
    unit VARCHAR(30) NOT NULL,
    target_value DECIMAL(20,6) NULL,
    warning_threshold DECIMAL(20,6) NULL,
    critical_threshold DECIMAL(20,6) NULL,
    comparison_operator VARCHAR(50) NOT NULL,
    time_window VARCHAR(20) NOT NULL,
    owner_code VARCHAR(100) NOT NULL,
    desired_direction VARCHAR(20) NOT NULL DEFAULT 'neutral',
    definition_version VARCHAR(20) NOT NULL DEFAULT '1.0',
    enabled TINYINT(1) NOT NULL DEFAULT 1,
    created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    updated_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6)
        ON UPDATE CURRENT_TIMESTAMP(6),

    PRIMARY KEY (id),
    UNIQUE KEY uq_kpi_definition_code (code),
    KEY idx_kpi_definition_owner (owner_code, enabled)
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

### 50. Table: threshold_definitions

```sql
CREATE TABLE threshold_definitions (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    code VARCHAR(150) NOT NULL,
    metric_or_kpi_code VARCHAR(150) NOT NULL,
    comparison_operator VARCHAR(50) NOT NULL,
    warning_value DECIMAL(20,6) NULL,
    critical_value DECIMAL(20,6) NULL,
    recovery_value DECIMAL(20,6) NULL,
    evaluation_window VARCHAR(20) NOT NULL,
    minimum_samples INT UNSIGNED NOT NULL DEFAULT 0,
    cooldown_seconds INT UNSIGNED NOT NULL DEFAULT 0,
    scope_type VARCHAR(50) NOT NULL DEFAULT 'global',
    environment VARCHAR(32) NULL,
    tenant_id BIGINT UNSIGNED NULL,
    effective_from DATETIME(6) NULL,
    effective_until DATETIME(6) NULL,
    definition_version VARCHAR(20) NOT NULL DEFAULT '1.0',
    enabled TINYINT(1) NOT NULL DEFAULT 1,
    created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    updated_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6)
        ON UPDATE CURRENT_TIMESTAMP(6),

    PRIMARY KEY (id),
    UNIQUE KEY uq_threshold_definition_code (code),
    KEY idx_threshold_resolution (
        metric_or_kpi_code,
        environment,
        tenant_id,
        enabled
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

### 51. Table: dashboard_query_snapshots

Optional table untuk snapshot expensive query.

```sql
CREATE TABLE dashboard_query_snapshots (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    cache_key_hash CHAR(64) NOT NULL,
    dashboard_code VARCHAR(100) NULL,
    widget_code VARCHAR(120) NOT NULL,
    environment VARCHAR(32) NOT NULL,
    tenant_id BIGINT UNSIGNED NULL,
    scope_id BIGINT UNSIGNED NULL,
    time_range_code VARCHAR(20) NOT NULL,
    result_status VARCHAR(20) NOT NULL,
    result_json JSON NOT NULL,
    generated_at DATETIME(6) NOT NULL,
    valid_until DATETIME(6) NULL,
    created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),

    PRIMARY KEY (id),
    UNIQUE KEY uq_dashboard_snapshot_hash (cache_key_hash),
    KEY idx_dashboard_snapshot_widget (
        widget_code,
        generated_at
    ),
    KEY idx_dashboard_snapshot_expiry (valid_until)
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

Jangan gunakan table ini untuk setiap request bila file/Redis cache tersedia.

---

### 52. Definition Source Strategy

Source types:

```text
config
database
module
generated
```

Rekomendasi:

- core dashboards: config;
- module dashboards: module registration;
- tenant/user layout: database;
- custom approved dashboard: database;
- runtime free-form query: tidak diperbolehkan.

---

### 53. Bootstrap Registration

Contoh:

```php
$dashboardRegistry->register(
    $platformOverviewDashboardDefinition
);

$widgetRegistry->register(
    $overallHealthWidgetDefinition
);

$metricRegistry->register(
    $httpRequestDurationMetric
);

$kpiRegistry->register(
    $platformErrorRateKpi
);
```

Module dapat mendaftar definition melalui registrar:

```php
interface DashboardModuleRegistrarInterface
{
    public function registerDashboards(
        DashboardRegistryInterface $dashboards,
        WidgetRegistryInterface $widgets,
        MetricRegistryInterface $metrics
    ): void;
}
```

---

### 54. Validation Service

```php
interface DashboardDefinitionValidatorInterface
{
    public function validateDashboard(
        DashboardDefinition $dashboard
    ): void;

    public function validateWidget(
        WidgetDefinition $widget
    ): void;

    public function validateMetric(
        MetricDefinition $metric
    ): void;
}
```

Validation errors harus menggagalkan deployment sebelum traffic diterima.

---

### 55. Query Orchestrator Failure Policy

| Failure | Result |
|---|---|
| provider timeout | widget ERROR/STALE |
| cache unavailable | fallback live query |
| source unavailable | stale/ERROR |
| unauthorized | UNAUTHORIZED |
| empty dataset | EMPTY |
| invalid metric | ERROR |
| cardinality limit | ERROR |
| partial batch failure | partial result |

---

### 56. Error Codes

```text
DASHBOARD_NOT_REGISTERED
WIDGET_NOT_REGISTERED
WIDGET_PROVIDER_NOT_REGISTERED
METRIC_NOT_REGISTERED
KPI_NOT_REGISTERED
THRESHOLD_NOT_REGISTERED
DASHBOARD_ACCESS_DENIED
WIDGET_ACCESS_DENIED
DASHBOARD_QUERY_INVALID
DASHBOARD_DATA_SOURCE_TIMEOUT
DASHBOARD_DATA_SOURCE_ERROR
DASHBOARD_CACHE_ERROR
DASHBOARD_RESULT_STALE
DASHBOARD_CARDINALITY_LIMIT
DASHBOARD_LAYOUT_CONFLICT
DASHBOARD_LAYOUT_INVALID
```

---

### 57. Telemetry Contract

```php
interface DashboardTelemetryInterface
{
    public function recordDashboard(
        DashboardResult $result,
        DashboardContext $context
    ): void;

    public function recordWidget(
        WidgetResult $result,
        WidgetDefinition $definition,
        DashboardContext $context
    ): void;
}
```

Metrics:

```text
dashboard_render_total
dashboard_render_duration_ms
widget_execution_total
widget_execution_duration_ms
widget_error_total
widget_stale_total
widget_cache_hit_total
widget_cache_miss_total
dashboard_access_denied_total
dashboard_layout_update_total
```

---

### 58. Structured Logging

Example:

```json
{
  "event": "dashboard_widget_executed",
  "dashboard": "platform_overview",
  "widget": "platform_error_rate",
  "provider": "metrics.kpi",
  "status": "READY",
  "duration_ms": 84,
  "cache_hit": true,
  "tenant_id": null,
  "scope_id": null,
  "request_id": "01J..."
}
```

Jangan log:

- raw query;
- token;
- PHI;
- raw restricted filters;
- sensitive payload.

---

### 59. Transaction Policy

Layout update menggunakan transaction:

```text
update layout version
delete/replace layout items
insert new layout items
audit event
commit
```

Dashboard rendering tidak menggunakan transaction panjang.

---

### 60. Layout Repository Contract

```php
interface DashboardLayoutRepositoryInterface
{
    public function resolve(
        string $dashboardCode,
        DashboardContext $context
    ): ?DashboardLayout;

    public function save(
        DashboardLayout $layout,
        int $expectedVersion,
        DashboardContext $context
    ): DashboardLayout;

    public function reset(
        string $dashboardCode,
        DashboardContext $context
    ): void;
}
```

---

### 61. Permission Requirements

Minimum:

```text
observability.dashboard.read
observability.dashboard.platform.read
observability.dashboard.operations.read
observability.dashboard.security.read
observability.dashboard.tenant.read
observability.dashboard.module.read
observability.dashboard.performance.read
observability.dashboard.layout.manage
observability.dashboard.layout.global.manage
observability.dashboard.custom.manage
observability.dashboard.export
```

---

### 62. Audit Events

```text
OBS_DASHBOARD_LAYOUT_UPDATED
OBS_DASHBOARD_LAYOUT_RESET
OBS_DASHBOARD_DEFINITION_CHANGED
OBS_WIDGET_DEFINITION_CHANGED
OBS_METRIC_DEFINITION_CHANGED
OBS_KPI_DEFINITION_CHANGED
OBS_THRESHOLD_CHANGED
OBS_DASHBOARD_RESTRICTED_VIEWED
OBS_DASHBOARD_EXPORTED
OBS_DASHBOARD_CACHE_INVALIDATED
```

---

### 63. Security Rules

Framework wajib:

- enforce registry allowlist;
- melarang raw SQL dari UI;
- melarang class name dari request;
- melarang formula dengan `eval`;
- enforce tenant/scope;
- sanitize result;
- limit time range;
- limit data points;
- limit series;
- audit restricted access;
- validate layout widgets.

---

### 64. Performance Strategy

- load registry saat bootstrap;
- cache metadata;
- batch query;
- deduplicate query;
- lazy-load optional widget;
- use pre-aggregation;
- short timeout;
- partial failure;
- stale fallback;
- pagination;
- top-N.

---

### 65. Folder Structure

```text
app/
└── Platform/
    └── Observability/
        └── Dashboard/
            ├── Domain/
            │   ├── DashboardDefinition.php
            │   ├── DashboardSectionDefinition.php
            │   ├── WidgetDefinition.php
            │   ├── MetricDefinition.php
            │   ├── KpiDefinition.php
            │   ├── ThresholdDefinition.php
            │   ├── DashboardContext.php
            │   ├── DashboardQuery.php
            │   ├── WidgetQuery.php
            │   ├── WidgetResult.php
            │   ├── DashboardResult.php
            │   ├── DashboardLayout.php
            │   └── DashboardLayoutItem.php
            │
            ├── Application/
            │   ├── Contracts/
            │   ├── DashboardService.php
            │   ├── DashboardRegistry.php
            │   ├── WidgetRegistry.php
            │   ├── MetricRegistry.php
            │   ├── KpiRegistry.php
            │   ├── ThresholdRegistry.php
            │   ├── DashboardQueryPlanner.php
            │   ├── WidgetExecutor.php
            │   └── DashboardStatusAggregator.php
            │
            ├── Infrastructure/
            │   ├── Cache/
            │   ├── Persistence/
            │   ├── DataSources/
            │   ├── Providers/
            │   ├── Security/
            │   └── Telemetry/
            │
            └── Presentation/
                ├── Http/
                └── Cli/
```

---

### 66. Unit Test Scope

Wajib menguji:

- duplicate registry;
- invalid definition;
- metric aggregation validation;
- permission;
- tenant scope;
- cache key isolation;
- stale fallback;
- query deduplication;
- layout version conflict;
- dashboard status aggregation;
- cardinality limit;
- restricted widget access.

---

### 67. Integration Test Scope

Wajib menguji:

- registry bootstrap;
- PDO repositories;
- layout persistence;
- widget cache;
- data source adapter;
- partial failure;
- metric/KPI resolution;
- threshold override;
- cross-tenant isolation.

---

### 68. UAT Part 3

#### Registry

- [ ] Dashboard registry aktif.
- [ ] Widget registry aktif.
- [ ] Metric registry aktif.
- [ ] KPI registry aktif.
- [ ] Threshold registry aktif.
- [ ] Duplicate code ditolak.

#### Query Orchestrator

- [ ] Query plan dibuat.
- [ ] Duplicate query digabung.
- [ ] Provider dipanggil sesuai widget.
- [ ] Partial failure bekerja.
- [ ] Critical widget memengaruhi status.

#### Cache

- [ ] Cache key memuat tenant/scope.
- [ ] Fresh cache digunakan.
- [ ] Stale fallback bekerja.
- [ ] Manual invalidation diaudit.
- [ ] Restricted cache tidak bocor lintas user/scope.

#### Layout

- [ ] System layout tersedia.
- [ ] Tenant layout dapat override.
- [ ] User layout dapat override.
- [ ] Invalid widget ditolak.
- [ ] Optimistic locking bekerja.
- [ ] Reset layout bekerja.

#### Database

- [ ] Definition dapat dimigrasikan.
- [ ] Layout dapat disimpan.
- [ ] Layout item konsisten.
- [ ] Metric/KPI/threshold definition valid.
- [ ] Snapshot query dapat disimpan bila diaktifkan.

#### Security

- [ ] Raw SQL ditolak.
- [ ] Formula tidak memakai eval.
- [ ] Tenant isolation aktif.
- [ ] Restricted widget dibatasi.
- [ ] Audit event tercatat.

---

### 69. Anti-Pattern

Hindari:

- controller membaca database metric langsung;
- registry dibangun ulang setiap request;
- widget provider mengembalikan HTML;
- raw SQL disimpan dalam widget definition;
- cache key tanpa scope;
- user bebas membuat formula PHP;
- seluruh layout disimpan sebagai blob tanpa validation;
- query berat dijalankan tanpa limit;
- seluruh widget gagal karena satu source down;
- DB menjadi satu-satunya source definition untuk core dashboard tanpa fallback.

---

### 70. Definition of Done Part 3

Part 3 dianggap selesai bila:

- [ ] DashboardDefinition tersedia.
- [ ] WidgetDefinition tersedia.
- [ ] MetricDefinition tersedia.
- [ ] KpiDefinition tersedia.
- [ ] ThresholdDefinition tersedia.
- [ ] seluruh registry contract tersedia.
- [ ] DashboardService tersedia.
- [ ] Query Orchestrator tersedia.
- [ ] Widget Executor tersedia.
- [ ] Data Source contract tersedia.
- [ ] cache contract tersedia.
- [ ] stale policy tersedia.
- [ ] layout persistence tersedia.
- [ ] optimistic locking tersedia.
- [ ] database schema tersedia.
- [ ] telemetry tersedia.
- [ ] permission dan audit tersedia.
- [ ] UAT tersedia.

---

### 71. Rencana Part Berikutnya

Part 4 membahas:

- HTTP API;
- controllers;
- middleware;
- response projection;
- frontend integration;
- dashboard customization;
- export;
- layout API;
- security;
- Apache/XAMPP routing;
- sequence diagram;
- API UAT.

---

## Bagian IV — HTTP API, Controllers, Middleware, Customization, Export & Frontend Integration

### 1. Executive Summary

Part 4 mendefinisikan bagaimana Monitoring Dashboard Framework diekspos melalui HTTP API dan digunakan oleh frontend.

Bagian ini mencakup:

- endpoint dashboard;
- endpoint widget;
- endpoint metric/KPI;
- endpoint layout;
- customization;
- export;
- controller architecture;
- middleware order;
- authentication;
- permission;
- tenant dan scope isolation;
- response projection;
- pagination;
- filtering;
- rate limiting;
- Apache/XAMPP routing;
- frontend integration;
- sequence diagram;
- API UAT.

Tujuan utama adalah memastikan dashboard dapat diakses secara konsisten, aman, cepat, dan tidak membocorkan data antar tenant atau role.

---

### 2. API Design Goals

API dashboard harus:

- resource-oriented;
- stabil;
- versionable;
- scope-aware;
- permission-aware;
- mobile-friendly;
- mendukung partial response;
- mendukung lazy loading;
- mendukung caching;
- mendukung customization;
- mendukung export yang terkontrol;
- tidak menerima raw SQL;
- tidak mengeksekusi formula bebas;
- menghasilkan error contract konsisten.

---

### 3. Base Path

Rekomendasi:

```text
/api/internal/v1/dashboards
```

Endpoint internal tidak boleh dipublikasikan tanpa authentication.

Probe kesehatan tetap terpisah dari dashboard API.

---

### 4. Endpoint Catalog

#### Dashboard Discovery

```text
GET /api/internal/v1/dashboards
GET /api/internal/v1/dashboards/{dashboardCode}
```

#### Dashboard Rendering

```text
GET /api/internal/v1/dashboards/{dashboardCode}/render
```

#### Widget Rendering

```text
GET /api/internal/v1/dashboards/{dashboardCode}/widgets
GET /api/internal/v1/dashboards/{dashboardCode}/widgets/{widgetCode}
```

#### Layout

```text
GET    /api/internal/v1/dashboards/{dashboardCode}/layout
PUT    /api/internal/v1/dashboards/{dashboardCode}/layout
DELETE /api/internal/v1/dashboards/{dashboardCode}/layout
```

#### Export

```text
POST /api/internal/v1/dashboards/{dashboardCode}/exports
GET  /api/internal/v1/dashboards/{dashboardCode}/exports/{exportId}
```

#### Metric/KPI Metadata

```text
GET /api/internal/v1/metrics
GET /api/internal/v1/metrics/{metricName}
GET /api/internal/v1/kpis
GET /api/internal/v1/kpis/{kpiCode}
```

---

### 5. Dashboard Discovery Endpoint

#### Request

```text
GET /api/internal/v1/dashboards
```

#### Tujuan

Mengembalikan dashboard yang dapat diakses actor.

#### Response

```json
{
  "data": [
    {
      "code": "platform_overview",
      "title": "Platform Overview",
      "category": "operations",
      "scope_type": "global",
      "default_time_range": "1h",
      "refresh_seconds": 30
    }
  ],
  "meta": {
    "request_id": "01J...",
    "generated_at": "2026-07-04T19:00:00+07:00"
  }
}
```

Registry tidak boleh mengembalikan dashboard yang tidak berwenang dilihat actor.

---

### 6. Dashboard Definition Endpoint

```text
GET /api/internal/v1/dashboards/{dashboardCode}
```

Mengembalikan metadata aman:

- title;
- description;
- section;
- widget metadata;
- layout constraints;
- supported time range;
- refresh policy;
- allowed actions.

Tidak mengembalikan:

- raw provider class;
- SQL;
- secret config;
- internal source credential.

---

### 7. Render Dashboard Endpoint

#### Request

```text
GET /api/internal/v1/dashboards/platform_overview/render?time_range=1h
```

Optional query:

```text
tenant_id
scope_id
module_code
time_range
refresh
widgets
```

#### Validation

- dashboard terdaftar;
- time range diizinkan;
- tenant/scope dapat diakses;
- widget filter valid;
- refresh permission bila bypass cache;
- maximum widget count;
- query complexity limit.

---

### 8. Render Response

```json
{
  "data": {
    "dashboard": {
      "code": "platform_overview",
      "title": "Platform Overview",
      "status": "DEGRADED",
      "time_range": "1h",
      "generated_at": "2026-07-04T19:00:00+07:00"
    },
    "sections": [
      {
        "code": "executive_summary",
        "title": "Executive Summary",
        "widgets": [
          {
            "code": "overall_health",
            "type": "status_card",
            "status": "READY",
            "data": {
              "status": "DEGRADED",
              "affected_components": 1
            },
            "meta": {
              "generated_at": "2026-07-04T19:00:00+07:00",
              "valid_until": "2026-07-04T19:00:15+07:00"
            }
          }
        ]
      }
    ]
  },
  "meta": {
    "request_id": "01J...",
    "duration_ms": 84,
    "partial": false
  }
}
```

---

### 9. Partial Response

Jika sebagian widget gagal:

```json
{
  "meta": {
    "partial": true,
    "failed_widgets": 1
  }
}
```

Widget error:

```json
{
  "code": "request_rate",
  "status": "ERROR",
  "error": {
    "code": "DASHBOARD_DATA_SOURCE_TIMEOUT",
    "message": "Widget data is temporarily unavailable."
  }
}
```

Jangan menggagalkan seluruh dashboard bila widget non-kritis gagal.

---

### 10. Single Widget Endpoint

```text
GET /api/internal/v1/dashboards/platform_overview/widgets/overall_health
```

Digunakan untuk:

- lazy loading;
- refresh parsial;
- retry widget;
- mobile detail;
- drill-down.

Query context harus tetap divalidasi.

---

### 11. Widget List Endpoint

```text
GET /api/internal/v1/dashboards/{dashboardCode}/widgets
```

Mengembalikan widget yang:

- terdaftar;
- aktif;
- berada pada dashboard;
- dapat dilihat actor;
- sesuai scope.

---

### 12. Metric Metadata Endpoint

```text
GET /api/internal/v1/metrics
```

Filter:

```text
domain
type
unit
enabled
search
page
per_page
```

Endpoint metadata tidak mengembalikan raw metric data.

---

### 13. KPI Metadata Endpoint

```text
GET /api/internal/v1/kpis
```

Mengembalikan:

- code;
- title;
- description;
- unit;
- target;
- owner;
- desired direction;
- version.

Formula detail dapat dibatasi untuk role tertentu bila dianggap sensitif.

---

### 14. Layout Read Endpoint

```text
GET /api/internal/v1/dashboards/{dashboardCode}/layout
```

Resolution:

```text
system
→ role
→ tenant
→ user
```

Response:

```json
{
  "data": {
    "dashboard_code": "platform_overview",
    "owner_type": "user",
    "version": 4,
    "items": [
      {
        "widget_code": "overall_health",
        "breakpoint": "desktop",
        "x": 0,
        "y": 0,
        "width": 4,
        "height": 2,
        "visible": true
      }
    ]
  }
}
```

---

### 15. Layout Update Endpoint

```text
PUT /api/internal/v1/dashboards/{dashboardCode}/layout
```

Request:

```json
{
  "version": 4,
  "items": [
    {
      "widget_code": "overall_health",
      "breakpoint": "desktop",
      "x": 0,
      "y": 0,
      "width": 4,
      "height": 2,
      "visible": true
    }
  ]
}
```

Wajib:

- authentication;
- permission;
- optimistic locking;
- widget validation;
- scope validation;
- audit.

---

### 16. Layout Conflict

Jika version berubah:

```http
409 Conflict
```

Response:

```json
{
  "error": {
    "code": "DASHBOARD_LAYOUT_CONFLICT",
    "message": "Dashboard layout has been modified by another session."
  }
}
```

Frontend harus reload layout terbaru.

---

### 17. Layout Reset Endpoint

```text
DELETE /api/internal/v1/dashboards/{dashboardCode}/layout
```

Menghapus user override dan kembali ke inherited layout.

Tidak menghapus:

- system default;
- role default;
- tenant default.

---

### 18. Custom Dashboard

Custom dashboard hanya boleh dibuat bila policy mengizinkan.

Permission:

```text
observability.dashboard.custom.manage
```

Custom dashboard tidak boleh:

- menerima raw SQL;
- menerima class name;
- menerima raw PHP;
- memakai formula `eval`;
- menggunakan metric tidak terdaftar;
- memakai restricted widget tanpa permission.

---

### 19. Custom Dashboard Definition API

Optional future endpoint:

```text
POST /api/internal/v1/dashboards/custom
PUT  /api/internal/v1/dashboards/custom/{code}
DELETE /api/internal/v1/dashboards/custom/{code}
```

Rekomendasi tahap awal:

- hanya admin;
- menggunakan approved widget catalog;
- tidak mendukung arbitrary query;
- semua perubahan diaudit.

---

### 20. Export Endpoint

#### Create Export

```text
POST /api/internal/v1/dashboards/{dashboardCode}/exports
```

Request:

```json
{
  "format": "csv",
  "time_range": "24h",
  "widgets": [
    "platform_error_rate",
    "platform_p95_latency"
  ]
}
```

Supported format awal:

```text
csv
json
```

PDF dapat ditambahkan setelah reporting/export framework tersedia.

---

### 21. Export Security

Export wajib:

- permission `observability.dashboard.export`;
- tenant/scope validation;
- restricted metric permission;
- maximum time range;
- maximum row count;
- audit;
- expiry;
- secure temporary storage.

Jangan mengirim export sensitif melalui URL publik permanen.

---

### 22. Export Result

Synchronous untuk data kecil.

Asynchronous untuk data besar.

Response asynchronous:

```json
{
  "data": {
    "export_id": "exp_01J...",
    "status": "PENDING",
    "expires_at": "2026-07-04T20:00:00+07:00"
  }
}
```

---

### 23. Export Download

```text
GET /api/internal/v1/dashboards/{dashboardCode}/exports/{exportId}
```

Policy:

- owner atau role berwenang;
- tenant/scope tetap divalidasi;
- file belum expired;
- one-time or short-lived access;
- audit download.

---

### 24. Controller Architecture

Controller hanya:

1. membaca request;
2. membuat validated DTO;
3. membangun DashboardContext;
4. menjalankan authorization;
5. memanggil application service;
6. menjalankan projector;
7. mengembalikan HTTP response.

Controller tidak boleh:

- query SQL;
- menjalankan widget provider langsung;
- menghitung KPI;
- menyimpan layout tanpa repository;
- membangun permission sendiri.

---

### 25. DashboardController Example

```php
final class DashboardController
{
    public function __construct(
        private readonly DashboardService $service,
        private readonly DashboardContextFactory $contexts,
        private readonly DashboardResponseProjector $projector,
    ) {
    }

    public function render(
        HttpRequest $request,
        string $dashboardCode
    ): HttpResponse {
        $context = $this->contexts->fromRequest($request);

        $query = new DashboardQuery(
            dashboardCode: $dashboardCode,
            widgetCodes: $request->queryList('widgets'),
            timeRange: $request->queryString('time_range', '1h'),
            forceRefresh: $request->queryBool('refresh', false),
            tenantId: $request->queryIntOrNull('tenant_id'),
            scopeId: $request->queryIntOrNull('scope_id'),
            moduleCode: $request->queryStringOrNull('module_code'),
        );

        $result = $this->service->render($query, $context);

        return JsonResponse::ok(
            $this->projector->dashboard($result)
        );
    }
}
```

---

### 26. LayoutController Example

```php
final class DashboardLayoutController
{
    public function __construct(
        private readonly DashboardLayoutService $service,
        private readonly DashboardContextFactory $contexts,
    ) {
    }

    public function update(
        HttpRequest $request,
        string $dashboardCode
    ): HttpResponse {
        $context = $this->contexts->fromRequest($request);

        $command = DashboardLayoutUpdateCommand::fromArray(
            dashboardCode: $dashboardCode,
            payload: $request->json(),
        );

        $layout = $this->service->update(
            $command,
            $context
        );

        return JsonResponse::ok([
            'data' => DashboardLayoutResource::from($layout),
        ]);
    }
}
```

---

### 27. Response Projector

Kontrak:

```php
interface DashboardResponseProjectorInterface
{
    public function dashboard(DashboardResult $result): array;

    public function widget(WidgetResult $result): array;

    public function layout(DashboardLayout $layout): array;

    public function dashboardList(array $definitions): array;
}
```

Projection memisahkan domain object dari HTTP contract.

---

### 28. Canonical Success Envelope

```json
{
  "data": {},
  "meta": {
    "request_id": "01J...",
    "generated_at": "2026-07-04T19:00:00+07:00",
    "duration_ms": 84
  }
}
```

---

### 29. Canonical Error Envelope

```json
{
  "error": {
    "code": "DASHBOARD_ACCESS_DENIED",
    "message": "You are not authorized to access this dashboard.",
    "details": []
  },
  "meta": {
    "request_id": "01J...",
    "timestamp": "2026-07-04T19:00:00+07:00"
  }
}
```

Tidak boleh menampilkan:

- stack trace;
- class path;
- SQL;
- raw provider response;
- secret;
- PHI.

---

### 30. HTTP Status Mapping

| Kondisi | HTTP |
|---|---:|
| success | 200 |
| export created | 202 |
| invalid input | 422 |
| unauthenticated | 401 |
| forbidden | 403 |
| not found | 404 |
| layout conflict | 409 |
| rate limit | 429 |
| source unavailable | 503 |
| unexpected framework error | 500 |

Widget error di dalam dashboard partial response tidak otomatis membuat HTTP 500.

---

### 31. Middleware Order

Rekomendasi:

```text
Request ID
→ Trusted Proxy
→ Security Headers
→ Authentication
→ Rate Limiting
→ Tenant Context
→ Active Scope
→ Permission
→ Data Classification
→ Audit Context
→ Controller
```

---

### 32. Authentication

Supported:

- web session;
- internal API token;
- service account;
- future mTLS.

API dashboard tidak boleh menerima anonymous access secara default.

---

### 33. Permission Enforcement

Enforcement dilakukan pada:

- dashboard;
- widget;
- metric/KPI;
- data classification;
- export;
- layout update;
- custom dashboard.

Permission tidak cukup hanya di menu.

Backend wajib memvalidasi setiap request.

---

### 34. Tenant Isolation

Context tenant berasal dari:

- authenticated tenant context;
- active scope;
- permitted explicit tenant parameter.

Rule:

- tenant admin tidak dapat memilih tenant lain;
- global admin dapat lintas tenant sesuai permission;
- widget cache terpisah per tenant;
- export terpisah per tenant;
- layout tenant tidak bocor.

---

### 35. Scope Enforcement

Scope validation wajib dilakukan sebelum query.

Query provider menerima scope yang telah disahkan.

Jangan hanya mengandalkan filter frontend.

---

### 36. Data Classification Middleware

Middleware dapat menolak widget berdasarkan classification:

```text
PUBLIC
INTERNAL
CONFIDENTIAL
RESTRICTED
```

Contoh:

- role support dapat INTERNAL;
- tenant admin dapat CONFIDENTIAL milik tenant;
- security admin dapat RESTRICTED security;
- executive hanya summary.

---

### 37. Rate Limiting

Rekomendasi awal:

| Endpoint | Limit |
|---|---:|
| dashboard list | 60/min/user |
| dashboard render | 60/min/user |
| single widget | 120/min/user |
| layout update | 20/15min/user |
| export create | 10/hour/user |
| custom dashboard update | 20/hour/user |

Limit final configurable.

---

### 38. Request Complexity Limit

Dashboard request dibatasi berdasarkan:

```text
widget count
time range
series count
data point
filter count
export row count
```

Contoh:

```text
max widgets per render = 30
max time range live = 30d
max series = 20/widget
max points = 1000/series
```

---

### 39. Pagination

Endpoint list wajib pagination:

```text
page
per_page
```

Maximum:

```text
per_page = 100
```

Response:

```json
{
  "meta": {
    "page": 1,
    "per_page": 25,
    "total": 120,
    "total_pages": 5
  }
}
```

---

### 40. Filtering

Filter hanya dari allowlist.

Contoh metric list:

```text
domain
type
unit
owner
enabled
```

Jangan meneruskan nama field mentah ke SQL.

---

### 41. Sorting

Sorting allowlist:

```text
title
code
updated_at
category
```

Direction:

```text
asc
desc
```

---

### 42. Cache Headers

Dashboard API:

```http
Cache-Control: private, no-store
```

Application cache tetap digunakan.

Metadata dashboard dapat memakai ETag bila tidak mengandung data sensitif.

---

### 43. ETag

Dashboard definition/layout read dapat menggunakan ETag.

Contoh:

```http
ETag: "layout-platform-overview-v4"
```

Update dapat memakai:

```http
If-Match: "layout-platform-overview-v4"
```

Ini melengkapi optimistic locking.

---

### 44. CORS

Endpoint internal:

- explicit allowlist;
- tidak memakai wildcard;
- credential hanya trusted origin;
- method dibatasi;
- header dibatasi.

---

### 45. CSRF

Session-based mutation wajib CSRF:

```text
PUT layout
DELETE layout
POST export
POST/PUT custom dashboard
```

Token-based API mengikuti authentication mechanism yang aman.

---

### 46. Security Headers

```http
Content-Type: application/json; charset=utf-8
X-Content-Type-Options: nosniff
X-Frame-Options: DENY
Referrer-Policy: no-referrer
Content-Security-Policy: default-src 'none'; frame-ancestors 'none'
```

Frontend page memiliki CSP sendiri sesuai asset policy.

---

### 47. Audit Events

Wajib audit:

```text
OBS_DASHBOARD_RESTRICTED_VIEWED
OBS_DASHBOARD_LAYOUT_UPDATED
OBS_DASHBOARD_LAYOUT_RESET
OBS_DASHBOARD_EXPORTED
OBS_DASHBOARD_EXPORT_DOWNLOADED
OBS_DASHBOARD_CUSTOM_CREATED
OBS_DASHBOARD_CUSTOM_UPDATED
OBS_DASHBOARD_CUSTOM_DELETED
OBS_DASHBOARD_CACHE_BYPASSED
OBS_DASHBOARD_CROSS_TENANT_VIEWED
```

Tidak perlu audit setiap refresh biasa.

---

### 48. Frontend Architecture

Rekomendasi layer:

```text
Dashboard Page
→ Dashboard Store/State
→ Dashboard API Client
→ Widget Renderer
→ Widget Components
→ Chart/Table Components
→ Design Token System
```

Frontend tidak menghitung KPI kritis sendiri.

Formula dan threshold berasal dari backend.

---

### 49. Frontend Rendering Contract

Widget renderer memilih component berdasarkan:

```text
type
```

Contoh mapping:

```text
status_card → StatusCard
metric_card → MetricCard
time_series → TimeSeriesChart
table → DataTable
alert_list → AlertList
incident_list → IncidentList
```

Unknown widget type:

```text
UnsupportedWidget
```

Jangan crash seluruh dashboard.

---

### 50. Frontend State

State minimum:

```text
dashboard metadata
layout
widget results
loading state
error state
filters
time range
refresh state
last updated
```

---

### 51. Lazy Loading

Prioritas:

1. critical summary widget;
2. visible viewport widget;
3. important widget;
4. optional widget;
5. drill-down data.

Tujuan:

- mempercepat first render;
- mengurangi query;
- mobile-friendly.

---

### 52. Auto Refresh

Frontend wajib:

- refresh per widget;
- pause saat tab hidden bila memungkinkan;
- exponential backoff saat error;
- menyediakan manual refresh;
- menampilkan last updated;
- menghormati server refresh policy.

---

### 53. Error State UI

Widget error menampilkan:

- status;
- pesan aman;
- retry;
- correlation/request ID bila support perlu;
- last successful data bila tersedia.

Tidak menampilkan stack trace.

---

### 54. Empty State UI

Empty state harus membedakan:

```text
No data
No traffic
Insufficient data
Not configured
Not authorized
```

---

### 55. Stale State UI

Tampilkan:

```text
Data may be outdated
Last updated: ...
```

Status visual berbeda dari error total.

---

### 56. Layout Customization UI

User dapat:

- drag;
- resize;
- show/hide;
- reset;
- reorder.

User tidak dapat:

- menambahkan widget yang tidak berwenang;
- mengubah provider;
- mengubah SQL;
- mengubah data classification;
- memperluas scope.

---

### 57. Mobile Frontend

Pada mobile:

- layout satu kolom;
- critical widgets pertama;
- chart disederhanakan;
- filter dalam drawer;
- table menjadi card list;
- auto-refresh lebih hemat;
- export dapat dibatasi.

---

### 58. Accessibility

Wajib:

- keyboard navigation;
- focus indicator;
- chart summary;
- ARIA label;
- tidak mengandalkan warna;
- status text;
- reduced motion;
- auto-refresh announcement terkontrol;
- responsive zoom.

---

### 59. Frontend Security

Jangan menyimpan restricted dashboard result di:

- localStorage tanpa encryption/policy;
- URL query;
- browser console;
- analytics payload;
- client error report mentah.

Gunakan memory/session state sesuai classification.

---

### 60. Export Frontend Flow

```text
User memilih export
→ frontend validasi dasar
→ POST export
→ status PENDING/READY
→ polling bounded
→ secure download
→ expiry
```

---

### 61. Apache/XAMPP Routing

#### Virtual Host

```apache
<VirtualHost *:80>
    ServerName platform.local
    DocumentRoot "D:/xampp/htdocs/platform/public"

    <Directory "D:/xampp/htdocs/platform/public">
        AllowOverride All
        Require all granted
        Options -Indexes
    </Directory>

    ErrorLog "logs/platform-error.log"
    CustomLog "logs/platform-access.log" combined
</VirtualHost>
```

#### `.htaccess`

```apache
RewriteEngine On

RewriteCond %{REQUEST_FILENAME} -f [OR]
RewriteCond %{REQUEST_FILENAME} -d
RewriteRule ^ - [L]

RewriteRule ^ index.php [QSA,L]
```

---

### 62. Route Registration

```php
$router->group('/api/internal/v1/dashboards', [
    'middleware' => [
        RequestIdMiddleware::class,
        AuthenticationMiddleware::class,
        RateLimitMiddleware::class,
        TenantContextMiddleware::class,
        ActiveScopeMiddleware::class,
    ],
], function ($router): void {
    $router->get('', [DashboardController::class, 'index']);
    $router->get('/{dashboardCode}', [DashboardController::class, 'show']);
    $router->get('/{dashboardCode}/render', [
        DashboardController::class,
        'render',
    ]);
    $router->get('/{dashboardCode}/widgets', [
        DashboardWidgetController::class,
        'index',
    ]);
    $router->get('/{dashboardCode}/widgets/{widgetCode}', [
        DashboardWidgetController::class,
        'show',
    ]);
    $router->get('/{dashboardCode}/layout', [
        DashboardLayoutController::class,
        'show',
    ]);
    $router->put('/{dashboardCode}/layout', [
        DashboardLayoutController::class,
        'update',
    ]);
    $router->delete('/{dashboardCode}/layout', [
        DashboardLayoutController::class,
        'reset',
    ]);
});
```

Route export sebaiknya didefinisikan sebelum generic wildcard bila router sensitif urutan.

---

### 63. Sequence Diagram — Dashboard Render

```mermaid
sequenceDiagram
    participant UI as Dashboard UI
    participant API as DashboardController
    participant Auth as Auth/RBAC/Scope
    participant DS as DashboardService
    participant Reg as Registries
    participant Plan as Query Planner
    participant Exec as Widget Executor
    participant Cache as Widget Cache
    participant Source as Data Sources
    participant Proj as Response Projector

    UI->>API: GET dashboard render
    API->>Auth: Validate actor, tenant, scope
    Auth-->>API: Allowed
    API->>DS: render(query, context)
    DS->>Reg: Resolve dashboard and widgets
    Reg-->>DS: Definitions
    DS->>Plan: Build execution plan
    Plan-->>DS: Widget plans

    loop each widget
        DS->>Exec: execute(widget)
        Exec->>Cache: get(cache key)
        alt cache hit
            Cache-->>Exec: WidgetResult
        else cache miss
            Exec->>Source: query data
            Source-->>Exec: DataSet
            Exec->>Cache: put result
        end
        Exec-->>DS: WidgetResult
    end

    DS-->>API: DashboardResult
    API->>Proj: Project response
    Proj-->>API: Safe JSON
    API-->>UI: HTTP 200
```

---

### 64. Sequence Diagram — Layout Update

```mermaid
sequenceDiagram
    participant UI as Dashboard UI
    participant API as LayoutController
    participant Auth as RBAC/Scope
    participant Service as LayoutService
    participant Validator as LayoutValidator
    participant Repo as LayoutRepository
    participant Audit as Audit Service

    UI->>API: PUT layout(version, items)
    API->>Auth: Authorize layout manage
    Auth-->>API: Allowed
    API->>Service: update(command, context)
    Service->>Validator: validate widgets and grid
    Validator-->>Service: Valid
    Service->>Repo: save expected version
    alt version conflict
        Repo-->>Service: Conflict
        Service-->>API: Layout conflict
        API-->>UI: HTTP 409
    else saved
        Repo-->>Service: New layout
        Service->>Audit: Record layout update
        Service-->>API: Layout
        API-->>UI: HTTP 200
    end
```

---

### 65. Sequence Diagram — Export

```mermaid
sequenceDiagram
    participant UI as Dashboard UI
    participant API as ExportController
    participant Auth as RBAC/Scope
    participant Export as Export Service
    participant Queue as Job Queue
    participant Store as Secure File Store
    participant Audit as Audit Service

    UI->>API: POST export
    API->>Auth: Validate export permission
    Auth-->>API: Allowed
    API->>Export: create export request
    Export->>Queue: enqueue export job
    Export->>Audit: Record export requested
    Export-->>API: export_id, PENDING
    API-->>UI: HTTP 202

    Queue->>Export: execute job
    Export->>Store: save generated file
    Store-->>Export: secure reference
```

---

### 66. API Versioning

Base:

```text
/api/internal/v1
```

Breaking changes:

```text
v2
```

Non-breaking additions tidak memerlukan version baru.

---

### 67. Idempotency

Layout update dengan version adalah idempotent secara conditional.

Export create dapat memakai:

```text
Idempotency-Key
```

untuk mencegah duplicate job.

---

### 68. Request Validation Error

```json
{
  "error": {
    "code": "VALIDATION_FAILED",
    "message": "The request contains invalid values.",
    "details": [
      {
        "field": "time_range",
        "code": "TIME_RANGE_INVALID"
      }
    ]
  }
}
```

---

### 69. Error Codes

```text
DASHBOARD_NOT_FOUND
DASHBOARD_ACCESS_DENIED
WIDGET_NOT_FOUND
WIDGET_ACCESS_DENIED
DASHBOARD_QUERY_INVALID
TIME_RANGE_INVALID
DASHBOARD_REFRESH_FORBIDDEN
DASHBOARD_LAYOUT_INVALID
DASHBOARD_LAYOUT_CONFLICT
DASHBOARD_EXPORT_FORBIDDEN
DASHBOARD_EXPORT_TOO_LARGE
DASHBOARD_EXPORT_NOT_FOUND
DASHBOARD_DATA_SOURCE_TIMEOUT
DASHBOARD_PARTIAL_RESULT
RATE_LIMIT_EXCEEDED
```

---

### 70. Logging

Log request dashboard:

```json
{
  "event": "dashboard_http_request",
  "dashboard": "platform_overview",
  "actor_user_id": 10,
  "tenant_id": null,
  "scope_id": null,
  "time_range": "1h",
  "widget_count": 12,
  "status": "DEGRADED",
  "duration_ms": 84,
  "request_id": "01J..."
}
```

Jangan log raw restricted data.

---

### 71. Performance Targets

| API | Target p95 |
|---|---:|
| list dashboard | < 300 ms |
| dashboard metadata | < 300 ms |
| render cached | < 1000 ms |
| single widget cached | < 300 ms |
| layout read | < 300 ms |
| layout update | < 1000 ms |
| export create | < 500 ms |

---

### 72. Frontend Performance Targets

- critical content visible < 2 detik;
- initial payload bounded;
- lazy load optional widget;
- no full page reload;
- chart points dibatasi;
- avoid duplicate API calls;
- cache metadata client-side secara aman.

---

### 73. Testing Strategy

#### Contract Test

- endpoint;
- response envelope;
- error envelope;
- HTTP mapping;
- API version;
- partial result.

#### Security Test

- unauthenticated;
- forbidden role;
- cross-tenant;
- cross-scope;
- restricted widget;
- export permission;
- CSRF;
- rate limit.

#### Layout Test

- valid update;
- invalid widget;
- conflict;
- reset;
- inherited layout.

#### Frontend Test

- lazy loading;
- widget error;
- stale state;
- mobile layout;
- accessibility;
- auto-refresh pause.

---

### 74. UAT Part 4

#### Dashboard API

- [ ] Dashboard list hanya menampilkan yang berwenang.
- [ ] Dashboard metadata valid.
- [ ] Render endpoint menghasilkan sections dan widgets.
- [ ] Partial widget failure tidak menggagalkan seluruh response.
- [ ] Single widget endpoint berfungsi.
- [ ] Query parameter tervalidasi.

#### Security

- [ ] Authentication wajib.
- [ ] Permission diterapkan di backend.
- [ ] Tenant isolation bekerja.
- [ ] Scope isolation bekerja.
- [ ] Restricted metric dibatasi.
- [ ] CORS aman.
- [ ] CSRF diterapkan pada mutation.
- [ ] Rate limiting aktif.

#### Layout

- [ ] Layout read mengikuti inheritance.
- [ ] Layout update tersimpan.
- [ ] Optimistic locking menghasilkan 409.
- [ ] Invalid widget ditolak.
- [ ] Reset kembali ke inherited layout.
- [ ] Update diaudit.

#### Export

- [ ] Export membutuhkan permission.
- [ ] Tenant/scope tetap diterapkan.
- [ ] Row/time-range limit bekerja.
- [ ] Export request diaudit.
- [ ] File expired tidak dapat diakses.
- [ ] Duplicate export dapat dicegah dengan idempotency key.

#### Frontend

- [ ] Critical widget tampil pertama.
- [ ] Lazy loading bekerja.
- [ ] Error state jelas.
- [ ] Empty state benar.
- [ ] Stale state jelas.
- [ ] Auto-refresh dapat dihentikan.
- [ ] Mobile layout berfungsi.
- [ ] Keyboard navigation berfungsi.

#### Apache/XAMPP

- [ ] Route API berjalan melalui front controller.
- [ ] File statis tetap dapat diakses.
- [ ] Directory listing nonaktif.
- [ ] Virtual host bekerja.
- [ ] Error log tersedia.

---

### 75. Anti-Pattern

Hindari:

- anonymous access ke internal dashboard;
- permission hanya di frontend;
- raw SQL dari query parameter;
- satu endpoint mengembalikan seluruh data tanpa limit;
- update layout tanpa version;
- export tanpa expiry;
- export menyimpan restricted file di public directory;
- refresh semua widget sekaligus;
- frontend menghitung KPI utama;
- localStorage menyimpan data restricted;
- wildcard CORS;
- widget error menghasilkan HTTP 500 seluruh dashboard;
- controller langsung memanggil repository metric.

---

### 76. Definition of Done Part 4

Part 4 dianggap selesai bila:

- [ ] endpoint catalog tersedia;
- [ ] dashboard discovery tersedia;
- [ ] render endpoint tersedia;
- [ ] single widget endpoint tersedia;
- [ ] layout API tersedia;
- [ ] export API tersedia;
- [ ] metric/KPI metadata API tersedia;
- [ ] controller standard tersedia;
- [ ] response projector tersedia;
- [ ] HTTP status mapping tersedia;
- [ ] middleware order tersedia;
- [ ] authentication dan permission tersedia;
- [ ] tenant/scope isolation tersedia;
- [ ] rate limit tersedia;
- [ ] CORS/CSRF/security headers tersedia;
- [ ] frontend contract tersedia;
- [ ] mobile dan accessibility tersedia;
- [ ] Apache/XAMPP routing tersedia;
- [ ] sequence diagram tersedia;
- [ ] UAT tersedia.

---

### 77. Rencana Part Berikutnya

Part 5 membahas:

- reference implementation end-to-end;
- sample dashboard definitions;
- sample widget providers;
- bootstrap wiring;
- SQL migration package;
- deployment;
- monitoring dashboard performance test;
- incident workflow;
- final UAT;
- Definition of Done;
- merge guidance menjadi `SSOT-OBS-06.md`.

---

## Bagian V — Reference Implementation, Deployment, Performance Test, Incident Workflow & Final UAT

### 1. Executive Summary

Part 5 menutup rangkaian SSOT-OBS-06 dengan reference implementation Monitoring Dashboard Framework.

Bagian ini mencakup:

- bootstrap wiring;
- sample dashboard definitions;
- sample widget definitions;
- sample widget providers;
- response projector;
- controller wiring;
- layout persistence;
- SQL migration package;
- seed awal;
- deployment;
- rollback;
- performance test;
- incident workflow;
- final UAT;
- Definition of Done;
- roadmap;
- merge guidance menjadi `SSOT-OBS-06.md`.

Target implementasi awal adalah dashboard operasional yang:

- aman;
- cepat;
- scope-aware;
- role-aware;
- mendukung partial failure;
- mendukung cache;
- mendukung customization;
- dapat diperluas module.

---

### 2. Reference Implementation Scope

Initial release wajib mencakup:

```text
Platform Overview Dashboard
Operations Dashboard
Tenant Overview Dashboard
Performance Dashboard
```

Initial widget:

```text
Overall Health
Component Health
Active Alerts
Active Incidents
Request Rate
Error Rate
p95 Latency
Queue Backlog
Scheduler Heartbeat
Integration Status
Storage Usage
SLA/SLO Summary
```

---

### 3. Final Folder Structure

```text
app/
└── Platform/
    └── Observability/
        └── Dashboard/
            ├── Domain/
            ├── Application/
            │   ├── Contracts/
            │   ├── DashboardService.php
            │   ├── DashboardRegistry.php
            │   ├── WidgetRegistry.php
            │   ├── MetricRegistry.php
            │   ├── KpiRegistry.php
            │   ├── ThresholdRegistry.php
            │   ├── DashboardQueryPlanner.php
            │   ├── WidgetExecutor.php
            │   └── DashboardStatusAggregator.php
            │
            ├── Infrastructure/
            │   ├── Cache/
            │   ├── Persistence/
            │   ├── DataSources/
            │   ├── Providers/
            │   ├── Security/
            │   └── Telemetry/
            │
            └── Presentation/
                ├── Http/
                └── Cli/

config/
└── dashboards.php

database/
└── migrations/
    └── create_monitoring_dashboard_tables.sql

resources/
└── dashboards/
    ├── platform_overview.php
    ├── operations.php
    ├── tenant_overview.php
    └── performance.php

public/
└── assets/
    └── dashboard/

tests/
├── Unit/
└── Integration/

tools/
└── dashboard-warmup.php
```

---

### 4. Bootstrap Wiring

```php
<?php

declare(strict_types=1);

namespace App\Platform\Observability\Dashboard;

use App\Platform\Observability\Dashboard\Application\DashboardRegistry;
use App\Platform\Observability\Dashboard\Application\WidgetRegistry;
use App\Platform\Observability\Dashboard\Application\MetricRegistry;
use App\Platform\Observability\Dashboard\Application\KpiRegistry;
use App\Platform\Observability\Dashboard\Application\ThresholdRegistry;
use App\Platform\Observability\Dashboard\Application\DashboardService;
use App\Platform\Observability\Dashboard\Application\DashboardQueryPlanner;
use App\Platform\Observability\Dashboard\Application\WidgetExecutor;
use App\Platform\Observability\Dashboard\Application\DashboardStatusAggregator;

final class DashboardBootstrap
{
    public static function build(array $config, object $container): DashboardService
    {
        $dashboardRegistry = new DashboardRegistry();
        $widgetRegistry = new WidgetRegistry();
        $metricRegistry = new MetricRegistry();
        $kpiRegistry = new KpiRegistry();
        $thresholdRegistry = new ThresholdRegistry();

        foreach ($config['registrars'] as $registrarClass) {
            $registrar = $container->get($registrarClass);

            $registrar->register(
                $dashboardRegistry,
                $widgetRegistry,
                $metricRegistry,
                $kpiRegistry,
                $thresholdRegistry
            );
        }

        $planner = new DashboardQueryPlanner(
            dashboards: $dashboardRegistry,
            widgets: $widgetRegistry,
            access: $container->get('dashboard.access_policy')
        );

        $executor = new WidgetExecutor(
            providers: $container->get('dashboard.widget_provider_registry'),
            cache: $container->get('dashboard.widget_cache'),
            telemetry: $container->get('dashboard.telemetry'),
            sanitizer: $container->get('dashboard.result_sanitizer')
        );

        return new DashboardService(
            dashboards: $dashboardRegistry,
            widgets: $widgetRegistry,
            access: $container->get('dashboard.access_policy'),
            planner: $planner,
            executor: $executor,
            aggregator: new DashboardStatusAggregator(),
            telemetry: $container->get('dashboard.telemetry')
        );
    }
}
```

---

### 5. Dashboard Registrar Contract

```php
interface DashboardRegistrarInterface
{
    public function register(
        DashboardRegistryInterface $dashboards,
        WidgetRegistryInterface $widgets,
        MetricRegistryInterface $metrics,
        KpiRegistryInterface $kpis,
        ThresholdRegistryInterface $thresholds
    ): void;
}
```

Module dapat mendaftarkan dashboard sendiri tanpa mengubah kernel.

---

### 6. Sample Platform Overview Dashboard

```php
<?php

use App\Platform\Observability\Dashboard\Domain\DashboardDefinition;
use App\Platform\Observability\Dashboard\Domain\DashboardSectionDefinition;

return new DashboardDefinition(
    code: 'platform_overview',
    title: 'Platform Overview',
    description: 'Ringkasan kondisi operasional Platform Kernel.',
    category: 'operations',
    audiences: [
        'platform_admin',
        'operations_admin',
        'support'
    ],
    permissions: [
        'observability.dashboard.platform.read'
    ],
    scopeType: 'global',
    defaultTimeRange: '1h',
    maxTimeRange: '30d',
    refreshSeconds: 30,
    sections: [
        new DashboardSectionDefinition(
            code: 'executive_summary',
            title: 'Executive Summary',
            position: 10,
            widgetCodes: [
                'overall_health',
                'active_alerts',
                'active_incidents',
                'platform_availability'
            ]
        ),
        new DashboardSectionDefinition(
            code: 'traffic_performance',
            title: 'Traffic & Performance',
            position: 20,
            widgetCodes: [
                'request_rate',
                'error_rate',
                'p95_latency'
            ]
        ),
        new DashboardSectionDefinition(
            code: 'dependencies',
            title: 'Dependencies',
            position: 30,
            widgetCodes: [
                'component_health',
                'queue_backlog',
                'integration_status',
                'storage_usage'
            ]
        ),
    ],
    enabled: true,
    version: '1.0'
);
```

---

### 7. Sample Widget Definition

```php
<?php

use App\Platform\Observability\Dashboard\Domain\WidgetDefinition;

return new WidgetDefinition(
    code: 'overall_health',
    title: 'Overall Health',
    type: 'status_card',
    providerCode: 'health.overall',
    permissions: [
        'observability.dashboard.platform.read'
    ],
    scopeType: 'global',
    criticality: 'critical',
    refreshSeconds: 15,
    supportedTimeRanges: ['now'],
    dataClassification: 'INTERNAL',
    layout: [
        'desktop' => ['w' => 3, 'h' => 2],
        'tablet' => ['w' => 4, 'h' => 2],
        'mobile' => ['w' => 4, 'h' => 2],
    ],
    options: [
        'show_since' => true,
        'show_affected_components' => true,
    ]
);
```

---

### 8. Sample Metric Definition

```php
$metrics->register(new MetricDefinition(
    name: 'http_request_duration_ms',
    title: 'HTTP Request Duration',
    description: 'Distribusi durasi request HTTP server-side.',
    type: 'histogram',
    unit: 'ms',
    domain: 'http',
    owner: 'platform_operations',
    source: 'metrics_store',
    dimensions: [
        'environment',
        'route_group',
        'method',
        'status_class',
    ],
    aggregations: [
        'p50',
        'p95',
        'p99',
    ],
    supportedTimeRanges: [
        '15m',
        '1h',
        '6h',
        '24h',
        '7d',
        '30d',
    ],
    privacyClassification: 'INTERNAL',
    desiredDirection: 'down',
    version: '1.0'
));
```

---

### 9. Sample KPI Definition

```php
$kpis->register(new KpiDefinition(
    code: 'platform_error_rate',
    title: 'Platform Error Rate',
    description: 'Persentase request eligible yang menghasilkan server error.',
    formula: 'http_error_total / http_request_total * 100',
    sourceMetrics: [
        'http_error_total',
        'http_request_total',
    ],
    unit: 'percent',
    target: 0.5,
    warningThreshold: 1.0,
    criticalThreshold: 5.0,
    comparison: 'greater_than_or_equal',
    timeWindow: '5m',
    owner: 'platform_operations',
    desiredDirection: 'down',
    version: '1.0'
));
```

---

### 10. Sample Health Widget Provider

```php
<?php

declare(strict_types=1);

final class OverallHealthWidgetProvider implements WidgetProviderInterface
{
    public function __construct(
        private readonly HealthStateRepositoryInterface $healthStates
    ) {
    }

    public function code(): string
    {
        return 'health.overall';
    }

    public function supportedWidgets(): array
    {
        return ['overall_health'];
    }

    public function fetch(
        WidgetQuery $query,
        DashboardContext $context
    ): WidgetResult {
        $state = $this->healthStates->findOverallState(
            environment: $context->environment,
            tenantId: $context->tenantId,
            scopeId: $context->scopeId
        );

        if ($state === null) {
            return new WidgetResult(
                widgetCode: $query->widgetCode,
                status: 'EMPTY',
                data: null,
                meta: [],
                warnings: ['Health state is not available.'],
                generatedAt: new \DateTimeImmutable()
            );
        }

        return new WidgetResult(
            widgetCode: $query->widgetCode,
            status: 'READY',
            data: [
                'status' => $state->status,
                'since' => $state->changedAt->format(DATE_ATOM),
                'affected_components' => $state->affectedComponentCount,
            ],
            meta: [
                'source' => 'health_component_state',
            ],
            warnings: [],
            generatedAt: new \DateTimeImmutable(),
            validUntil: new \DateTimeImmutable('+15 seconds')
        );
    }
}
```

---

### 11. Sample KPI Widget Provider

```php
final class KpiWidgetProvider implements WidgetProviderInterface
{
    public function __construct(
        private readonly KpiRegistryInterface $kpis,
        private readonly MetricQueryServiceInterface $metrics,
        private readonly ThresholdEvaluatorInterface $thresholds
    ) {
    }

    public function code(): string
    {
        return 'metrics.kpi';
    }

    public function supportedWidgets(): array
    {
        return [
            'error_rate',
            'platform_availability',
            'queue_failure_rate'
        ];
    }

    public function fetch(
        WidgetQuery $query,
        DashboardContext $context
    ): WidgetResult {
        $kpiCode = (string) ($query->filters['kpi_code'] ?? '');

        $definition = $this->kpis->get($kpiCode);

        $result = $this->metrics->calculateKpi(
            definition: $definition,
            context: $context,
            timeRange: $query->timeRange
        );

        $threshold = $this->thresholds->evaluate(
            code: $definition->code,
            value: $result->value,
            sampleCount: $result->sampleCount,
            context: $context
        );

        return new WidgetResult(
            widgetCode: $query->widgetCode,
            status: $result->quality === 'COMPLETE'
                ? 'READY'
                : 'DEGRADED',
            data: [
                'value' => $result->value,
                'unit' => $definition->unit,
                'threshold_status' => $threshold->status,
                'target' => $definition->target,
                'trend' => $result->trend,
            ],
            meta: [
                'quality' => $result->quality,
                'sample_count' => $result->sampleCount,
            ],
            warnings: $result->warnings,
            generatedAt: new \DateTimeImmutable(),
            validUntil: new \DateTimeImmutable('+60 seconds')
        );
    }
}
```

---

### 12. Sample Dashboard Access Policy

```php
final class DashboardAccessPolicy
    implements DashboardAccessPolicyInterface
{
    public function canViewDashboard(
        DashboardDefinition $dashboard,
        DashboardContext $context
    ): bool {
        foreach ($dashboard->permissions as $permission) {
            if (!in_array($permission, $context->permissions, true)) {
                return false;
            }
        }

        return $this->scopeAllowed(
            $dashboard->scopeType,
            $context
        );
    }

    public function canViewWidget(
        WidgetDefinition $widget,
        DashboardContext $context
    ): bool {
        foreach ($widget->permissions as $permission) {
            if (!in_array($permission, $context->permissions, true)) {
                return false;
            }
        }

        return $this->classificationAllowed(
            $widget->dataClassification,
            $context
        );
    }

    public function assertTenantAccess(
        ?int $tenantId,
        DashboardContext $context
    ): void {
        if (
            $tenantId !== null
            && $context->tenantId !== null
            && $tenantId !== $context->tenantId
            && !in_array(
                'observability.dashboard.cross_tenant.read',
                $context->permissions,
                true
            )
        ) {
            throw new DomainException('Cross-tenant access denied.');
        }
    }

    public function assertScopeAccess(
        ?int $scopeId,
        DashboardContext $context
    ): void {
        if (
            $scopeId !== null
            && $context->scopeId !== null
            && $scopeId !== $context->scopeId
        ) {
            throw new DomainException('Scope access denied.');
        }
    }

    private function scopeAllowed(
        string $scopeType,
        DashboardContext $context
    ): bool {
        return match ($scopeType) {
            'global' => in_array(
                'observability.dashboard.platform.read',
                $context->permissions,
                true
            ),
            'tenant' => $context->tenantId !== null,
            'module' => $context->moduleCode !== null,
            default => false,
        };
    }

    private function classificationAllowed(
        string $classification,
        DashboardContext $context
    ): bool {
        if ($classification !== 'RESTRICTED') {
            return true;
        }

        return in_array(
            'observability.dashboard.restricted.read',
            $context->permissions,
            true
        );
    }
}
```

---

### 13. Response Projector Example

```php
final class DashboardResponseProjector
{
    public function dashboard(DashboardResult $result): array
    {
        $widgets = [];

        foreach ($result->widgets as $code => $widget) {
            $widgets[$code] = $this->widget($widget);
        }

        return [
            'data' => [
                'dashboard' => [
                    'code' => $result->dashboardCode,
                    'status' => $result->status,
                    'generated_at' => $result->generatedAt->format(DATE_ATOM),
                ],
                'widgets' => $widgets,
            ],
            'meta' => [
                'request_id' => $result->requestId,
                'duration_ms' => $result->durationMs,
                'partial' => $result->status === 'DEGRADED',
            ],
        ];
    }

    public function widget(WidgetResult $result): array
    {
        $payload = [
            'code' => $result->widgetCode,
            'status' => $result->status,
            'data' => $result->data,
            'meta' => array_merge(
                $result->meta,
                [
                    'generated_at' =>
                        $result->generatedAt->format(DATE_ATOM),
                    'valid_until' =>
                        $result->validUntil?->format(DATE_ATOM),
                ]
            ),
            'warnings' => $result->warnings,
        ];

        if ($result->errorCode !== null) {
            $payload['error'] = [
                'code' => $result->errorCode,
                'message' => 'Widget data is temporarily unavailable.',
            ];
        }

        return $payload;
    }
}
```

---

### 14. Sample Route Wiring

```php
$router->group('/api/internal/v1/dashboards', [
    'middleware' => [
        RequestIdMiddleware::class,
        AuthenticationMiddleware::class,
        RateLimitMiddleware::class,
        TenantContextMiddleware::class,
        ActiveScopeMiddleware::class,
    ],
], function ($router): void {
    $router->get('', [DashboardController::class, 'index']);
    $router->get('/{dashboardCode}', [DashboardController::class, 'show']);
    $router->get('/{dashboardCode}/render', [
        DashboardController::class,
        'render',
    ]);
    $router->get('/{dashboardCode}/widgets/{widgetCode}', [
        DashboardWidgetController::class,
        'show',
    ]);
    $router->get('/{dashboardCode}/layout', [
        DashboardLayoutController::class,
        'show',
    ]);
    $router->put('/{dashboardCode}/layout', [
        DashboardLayoutController::class,
        'update',
    ]);
    $router->delete('/{dashboardCode}/layout', [
        DashboardLayoutController::class,
        'reset',
    ]);
});
```

---

### 15. SQL Migration Package

File:

```text
database/migrations/create_monitoring_dashboard_tables.sql
```

```sql
START TRANSACTION;

CREATE TABLE dashboard_definitions (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    code VARCHAR(100) NOT NULL,
    title VARCHAR(200) NOT NULL,
    description VARCHAR(1000) NULL,
    category VARCHAR(100) NOT NULL,
    scope_type VARCHAR(50) NOT NULL,
    permission_code VARCHAR(150) NULL,
    default_time_range VARCHAR(20) NOT NULL DEFAULT '1h',
    max_time_range VARCHAR(20) NOT NULL DEFAULT '30d',
    refresh_seconds INT UNSIGNED NOT NULL DEFAULT 60,
    definition_version VARCHAR(20) NOT NULL DEFAULT '1.0',
    enabled TINYINT(1) NOT NULL DEFAULT 1,
    source_type VARCHAR(20) NOT NULL DEFAULT 'config',
    created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    updated_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6)
        ON UPDATE CURRENT_TIMESTAMP(6),

    PRIMARY KEY (id),
    UNIQUE KEY uq_dashboard_definition_code (code)
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;

CREATE TABLE widget_definitions (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    code VARCHAR(120) NOT NULL,
    title VARCHAR(200) NOT NULL,
    widget_type VARCHAR(50) NOT NULL,
    provider_code VARCHAR(120) NOT NULL,
    permission_code VARCHAR(150) NULL,
    scope_type VARCHAR(50) NOT NULL,
    criticality VARCHAR(20) NOT NULL DEFAULT 'optional',
    data_classification VARCHAR(20) NOT NULL DEFAULT 'INTERNAL',
    refresh_seconds INT UNSIGNED NOT NULL DEFAULT 60,
    supported_time_ranges_json JSON NULL,
    layout_json JSON NULL,
    options_json JSON NULL,
    definition_version VARCHAR(20) NOT NULL DEFAULT '1.0',
    enabled TINYINT(1) NOT NULL DEFAULT 1,
    source_type VARCHAR(20) NOT NULL DEFAULT 'config',
    created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    updated_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6)
        ON UPDATE CURRENT_TIMESTAMP(6),

    PRIMARY KEY (id),
    UNIQUE KEY uq_widget_definition_code (code)
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;

CREATE TABLE dashboard_layouts (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    dashboard_definition_id BIGINT UNSIGNED NOT NULL,
    owner_type VARCHAR(20) NOT NULL,
    owner_id BIGINT UNSIGNED NULL,
    tenant_id BIGINT UNSIGNED NULL,
    scope_id BIGINT UNSIGNED NULL,
    layout_version INT UNSIGNED NOT NULL DEFAULT 1,
    is_default TINYINT(1) NOT NULL DEFAULT 0,
    created_by BIGINT UNSIGNED NULL,
    updated_by BIGINT UNSIGNED NULL,
    created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    updated_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6)
        ON UPDATE CURRENT_TIMESTAMP(6),

    PRIMARY KEY (id),
    CONSTRAINT fk_dashboard_layout_definition
        FOREIGN KEY (dashboard_definition_id)
        REFERENCES dashboard_definitions(id)
        ON DELETE CASCADE,

    KEY idx_dashboard_layout_owner (
        owner_type,
        owner_id,
        dashboard_definition_id
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;

CREATE TABLE dashboard_layout_items (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    dashboard_layout_id BIGINT UNSIGNED NOT NULL,
    widget_definition_id BIGINT UNSIGNED NOT NULL,
    breakpoint VARCHAR(20) NOT NULL,
    grid_x INT UNSIGNED NOT NULL DEFAULT 0,
    grid_y INT UNSIGNED NOT NULL DEFAULT 0,
    grid_width INT UNSIGNED NOT NULL,
    grid_height INT UNSIGNED NOT NULL,
    visible TINYINT(1) NOT NULL DEFAULT 1,
    created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    updated_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6)
        ON UPDATE CURRENT_TIMESTAMP(6),

    PRIMARY KEY (id),
    CONSTRAINT fk_dashboard_layout_item_layout
        FOREIGN KEY (dashboard_layout_id)
        REFERENCES dashboard_layouts(id)
        ON DELETE CASCADE,
    CONSTRAINT fk_dashboard_layout_item_widget
        FOREIGN KEY (widget_definition_id)
        REFERENCES widget_definitions(id)
        ON DELETE RESTRICT,

    UNIQUE KEY uq_dashboard_layout_item (
        dashboard_layout_id,
        widget_definition_id,
        breakpoint
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;

CREATE TABLE metric_definitions (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    name VARCHAR(150) NOT NULL,
    title VARCHAR(200) NOT NULL,
    description VARCHAR(1000) NULL,
    metric_type VARCHAR(30) NOT NULL,
    unit VARCHAR(30) NOT NULL,
    domain_code VARCHAR(100) NOT NULL,
    owner_code VARCHAR(100) NOT NULL,
    source_code VARCHAR(100) NOT NULL,
    allowed_dimensions_json JSON NULL,
    allowed_aggregations_json JSON NULL,
    supported_time_ranges_json JSON NULL,
    privacy_classification VARCHAR(20) NOT NULL DEFAULT 'INTERNAL',
    desired_direction VARCHAR(20) NOT NULL DEFAULT 'neutral',
    definition_version VARCHAR(20) NOT NULL DEFAULT '1.0',
    enabled TINYINT(1) NOT NULL DEFAULT 1,
    created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    updated_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6)
        ON UPDATE CURRENT_TIMESTAMP(6),

    PRIMARY KEY (id),
    UNIQUE KEY uq_metric_definition_name (name)
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;

CREATE TABLE kpi_definitions (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    code VARCHAR(150) NOT NULL,
    title VARCHAR(200) NOT NULL,
    description VARCHAR(1000) NULL,
    formula_expression VARCHAR(2000) NOT NULL,
    source_metrics_json JSON NOT NULL,
    unit VARCHAR(30) NOT NULL,
    target_value DECIMAL(20,6) NULL,
    warning_threshold DECIMAL(20,6) NULL,
    critical_threshold DECIMAL(20,6) NULL,
    comparison_operator VARCHAR(50) NOT NULL,
    time_window VARCHAR(20) NOT NULL,
    owner_code VARCHAR(100) NOT NULL,
    desired_direction VARCHAR(20) NOT NULL DEFAULT 'neutral',
    definition_version VARCHAR(20) NOT NULL DEFAULT '1.0',
    enabled TINYINT(1) NOT NULL DEFAULT 1,
    created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    updated_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6)
        ON UPDATE CURRENT_TIMESTAMP(6),

    PRIMARY KEY (id),
    UNIQUE KEY uq_kpi_definition_code (code)
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;

COMMIT;
```

---

### 16. Seed Permissions

```text
observability.dashboard.read
observability.dashboard.platform.read
observability.dashboard.operations.read
observability.dashboard.security.read
observability.dashboard.tenant.read
observability.dashboard.module.read
observability.dashboard.integration.read
observability.dashboard.performance.read
observability.dashboard.executive.read
observability.dashboard.layout.manage
observability.dashboard.layout.global.manage
observability.dashboard.custom.manage
observability.dashboard.export
observability.dashboard.cross_tenant.read
observability.dashboard.restricted.read
```

---

### 17. Role Mapping

| Role | Permission Utama |
|---|---|
| Platform Admin | seluruh dashboard permission |
| Operations Admin | platform, operations, integration, performance |
| Security Admin | security, restricted read |
| Tenant Admin | tenant dashboard milik tenant |
| Module Owner | module dashboard |
| Support | overview terbatas |
| Executive | executive dashboard |
| End User | tidak ada dashboard teknis |

---

### 18. Cache Warmup

CLI:

```bash
php tools/dashboard-warmup.php --dashboard=platform_overview
php tools/dashboard-warmup.php --dashboard=operations
php tools/dashboard-warmup.php --all
```

Warmup cocok untuk:

- dashboard overview;
- SLA/SLO;
- historical trend;
- expensive aggregate.

---

### 19. Scheduler

Rekomendasi:

```text
setiap 1 menit:
  warm current operational widget

setiap 5 menit:
  warm performance and integration widget

setiap 15 menit:
  calculate SLA/SLO summary

setiap 1 jam:
  warm executive dashboard
```

---

### 20. Deployment Checklist

#### Pre-Deployment

- [ ] Backup database tersedia.
- [ ] Migration direview.
- [ ] Permission disiapkan.
- [ ] Registry definitions tervalidasi.
- [ ] Widget providers tersedia.
- [ ] Cache directory tersedia.
- [ ] Public directory tidak berisi export sensitif.
- [ ] Unit test lulus.
- [ ] Integration test lulus.
- [ ] Security review lulus.

#### Deployment

1. Aktifkan maintenance bila diperlukan.
2. Deploy code.
3. Jalankan migration.
4. Jalankan registry validation.
5. Seed permission.
6. Warm cache dashboard utama.
7. Verifikasi route.
8. Verifikasi role access.
9. Verifikasi tenant isolation.
10. Verifikasi layout.
11. Verifikasi export policy.
12. Nonaktifkan maintenance.

#### Post-Deployment

- [ ] Platform overview dapat dibuka.
- [ ] Tidak ada duplicate registry.
- [ ] Tidak ada missing provider.
- [ ] Cache hit meningkat.
- [ ] Dashboard p95 sesuai target.
- [ ] Tidak ada restricted data bocor.
- [ ] Audit event tercatat.
- [ ] Scheduler warmup aktif.

---

### 21. Rollback Plan

1. Aktifkan maintenance.
2. Hentikan warmup/export job.
3. Rollback code.
4. Restore config.
5. Hapus incompatible cache.
6. Rollback schema hanya bila aman.
7. Verifikasi dashboard lama.
8. Verifikasi permission.
9. Nonaktifkan maintenance.

Prefer forward-compatible schema.

---

### 22. Performance Test Plan

#### Test Scenario

```text
10 concurrent users
50 concurrent users
100 concurrent users
```

Test:

- dashboard list;
- platform overview cached;
- platform overview cold cache;
- single widget;
- 24h chart;
- layout read;
- layout update;
- export create.

---

### 23. Performance Acceptance

| Scenario | Target p95 |
|---|---:|
| Dashboard list | < 300 ms |
| Overview cached | < 1000 ms |
| Overview cold | < 2000 ms |
| Single widget cached | < 300 ms |
| 24h chart | < 1500 ms |
| Layout read | < 300 ms |
| Layout update | < 1000 ms |
| Export create | < 500 ms |

---

### 24. Load Test Safety

Jangan menjalankan load test:

- terhadap production tanpa approval;
- dengan export unrestricted;
- dengan cross-tenant query;
- dengan raw log drill-down besar;
- tanpa rate limit.

---

### 25. Incident Scenario — Widget Provider Timeout

Expected:

```text
widget = ERROR atau STALE
dashboard = DEGRADED
HTTP = 200
```

Action:

1. Cek source latency.
2. Cek cache.
3. Cek timeout.
4. Cek query plan.
5. Cek cardinality.
6. Aktifkan stale fallback.
7. Pulihkan provider.

---

### 26. Incident Scenario — Metrics Store Down

Expected:

- health widget tetap tampil;
- metric widget menjadi STALE/ERROR;
- dashboard menjadi DEGRADED;
- alert operations;
- tidak ada total dashboard failure.

---

### 27. Incident Scenario — Cross-Tenant Cache Leak

Ini adalah incident security kritis.

Action:

1. Nonaktifkan dashboard cache.
2. Hentikan akses endpoint terdampak.
3. Rotasi cache namespace.
4. Audit tenant yang terdampak.
5. Perbaiki cache key.
6. Jalankan security review.
7. Dokumentasikan breach assessment.

---

### 28. Incident Scenario — Layout Corruption

Expected:

- fallback ke inherited/system layout;
- user customization tidak mematikan dashboard;
- audit error;
- layout invalid dikarantina.

---

### 29. Incident Scenario — Export File Exposed

Action:

1. Hapus akses publik.
2. Cabut file.
3. Audit download.
4. Rotasi secure link.
5. Review classification.
6. Review export storage policy.
7. Jalankan incident response.

---

### 30. Incident Workflow Integration

Dashboard dapat menampilkan incident dan membuka drill-down.

Flow:

```text
Metric/Health anomaly
→ Alert
→ Incident created
→ Dashboard marks affected widgets
→ Operator drill-down
→ Recovery
→ Incident resolved
```

Dashboard tidak membuat incident secara langsung tanpa Alerting/Incident policy.

---

### 31. Dashboard Degraded Mode

Saat data source bermasalah:

- gunakan cached result;
- label STALE;
- sembunyikan optional widget bila perlu;
- pertahankan navigation;
- tampilkan safe status banner;
- jangan memblokir seluruh UI.

---

### 32. Backup & Restore

Backup:

- dashboard definitions bila DB-backed;
- layout;
- metric definitions;
- KPI definitions;
- threshold definitions;
- audit references.

Restore wajib menguji:

- foreign key;
- layout version;
- widget code;
- permission;
- tenant ownership.

---

### 33. Retention

| Data | Retention |
|---|---|
| User layout | selama user aktif + policy |
| Deleted layout history | 30–90 hari |
| Export file | 1–24 jam |
| Query snapshot | 1–24 jam |
| Definition history | 12–24 bulan |
| Audit event | sesuai compliance |

---

### 34. Final UAT — Core

- [ ] Dashboard Registry bekerja.
- [ ] Widget Registry bekerja.
- [ ] Metric Registry bekerja.
- [ ] KPI Registry bekerja.
- [ ] Threshold Registry bekerja.
- [ ] Dashboard Service bekerja.
- [ ] Query Planner bekerja.
- [ ] Widget Executor bekerja.
- [ ] Partial failure bekerja.
- [ ] Cache bekerja.
- [ ] Telemetry bekerja.

---

### 35. Final UAT — Dashboard

- [ ] Platform Overview tampil.
- [ ] Operations tampil.
- [ ] Tenant Overview tampil.
- [ ] Performance tampil.
- [ ] Section dan widget sesuai definition.
- [ ] Widget critical tampil pertama.
- [ ] Empty/error/stale state benar.

---

### 36. Final UAT — Security

- [ ] Authentication wajib.
- [ ] Backend permission aktif.
- [ ] Tenant isolation aktif.
- [ ] Scope isolation aktif.
- [ ] Restricted dashboard dibatasi.
- [ ] Cross-tenant read membutuhkan permission.
- [ ] Cache terisolasi.
- [ ] Export aman.
- [ ] Audit event tercatat.
- [ ] Tidak ada PHI/PII/secret pada overview.

---

### 37. Final UAT — Layout

- [ ] Default layout tersedia.
- [ ] Role override tersedia.
- [ ] Tenant override tersedia.
- [ ] User override tersedia.
- [ ] Invalid widget ditolak.
- [ ] Conflict menghasilkan 409.
- [ ] Reset bekerja.
- [ ] Mobile layout valid.

---

### 38. Final UAT — Performance

- [ ] Cached overview memenuhi target.
- [ ] Cold overview memenuhi target.
- [ ] Query deduplication aktif.
- [ ] Max series diterapkan.
- [ ] Max points diterapkan.
- [ ] 30d chart memakai aggregate.
- [ ] Lazy loading aktif.
- [ ] Cache hit metric tersedia.

---

### 39. Final UAT — Failure

- [ ] Widget timeout tidak mematikan dashboard.
- [ ] Data source down menghasilkan stale/error.
- [ ] Cache down fallback bekerja.
- [ ] Invalid layout fallback bekerja.
- [ ] Missing metric menghasilkan safe error.
- [ ] Export failure tidak mematikan dashboard.
- [ ] Framework error memiliki correlation ID.

---

### 40. Production Readiness Checklist

- [ ] Registry validation otomatis.
- [ ] Dashboard owner tersedia.
- [ ] Widget owner tersedia.
- [ ] KPI owner tersedia.
- [ ] Threshold owner tersedia.
- [ ] Runbook tersedia.
- [ ] Alert dashboard failure tersedia.
- [ ] Cache monitoring tersedia.
- [ ] Export cleanup job tersedia.
- [ ] Audit aktif.
- [ ] Backup/restore diuji.
- [ ] Performance test lulus.
- [ ] Security review lulus.
- [ ] Accessibility review lulus.

---

### 41. Ownership Matrix

| Area | Owner |
|---|---|
| Dashboard Framework | Platform Kernel Team |
| Platform Dashboard | Platform Operations |
| Security Dashboard | Security Team |
| Tenant Dashboard | Tenant Operations |
| Module Dashboard | Module Owner |
| Metric Registry | Observability Team |
| KPI Registry | Domain Owner |
| Threshold | Operations + Domain Owner |
| Frontend Components | Frontend Platform Team |
| Export | Reporting/Platform Team |

---

### 42. Definition of Done — SSOT-OBS-06

Dokumentasi dianggap selesai bila:

#### Architecture

- [ ] vision;
- [ ] dashboard model;
- [ ] widget model;
- [ ] data source;
- [ ] access policy;
- [ ] partial failure;
- [ ] cache;
- [ ] responsive layout.

#### Metrics & KPI

- [ ] taxonomy;
- [ ] registry;
- [ ] KPI governance;
- [ ] threshold;
- [ ] aggregation;
- [ ] time-series;
- [ ] SLI/SLO/SLA;
- [ ] error budget.

#### Core Implementation

- [ ] registries;
- [ ] query orchestrator;
- [ ] widget executor;
- [ ] data source adapters;
- [ ] layout persistence;
- [ ] database schema;
- [ ] telemetry.

#### Interface

- [ ] dashboard API;
- [ ] widget API;
- [ ] layout API;
- [ ] export API;
- [ ] frontend contract;
- [ ] Apache/XAMPP routing.

#### Operations

- [ ] deployment;
- [ ] rollback;
- [ ] performance test;
- [ ] incident scenarios;
- [ ] final UAT;
- [ ] production checklist.

---

### 43. Implementation Definition of Done

Implementasi dianggap selesai bila:

- [ ] core classes dibuat;
- [ ] migration berhasil;
- [ ] initial dashboard tersedia;
- [ ] initial widget tersedia;
- [ ] endpoint tersedia;
- [ ] layout customization tersedia;
- [ ] permission tersedia;
- [ ] audit tersedia;
- [ ] cache tersedia;
- [ ] unit test lulus;
- [ ] integration test lulus;
- [ ] UAT lulus;
- [ ] performance target tercapai;
- [ ] security review lulus;
- [ ] accessibility review lulus;
- [ ] deployment dan rollback diuji.

---

### 44. Roadmap

#### Phase 1 — Foundation

- registries;
- platform overview;
- health widgets;
- metric cards;
- basic layout;
- RBAC/scope.

#### Phase 2 — Operations

- queue;
- scheduler;
- integration;
- alert;
- incident;
- performance charts.

#### Phase 3 — Customization

- tenant layout;
- user layout;
- export;
- custom approved dashboard.

#### Phase 4 — Advanced Observability

- distributed trace drill-down;
- service map;
- anomaly detection;
- SLO burn-rate;
- predictive dashboard;
- incident collaboration.

---

### 45. Future Evolution

- real-time streaming;
- WebSocket/SSE;
- Redis cache;
- distributed query;
- multi-region dashboard;
- embedded Grafana adapter;
- status page;
- AI-assisted anomaly summary;
- automatic dashboard recommendation;
- dashboard-as-code validation;
- signed export;
- mobile native dashboard.

---

### 46. Merge Guidance

Gabungkan:

```text
SSOT-OBS-06-Part-1.md
SSOT-OBS-06-Part-2.md
SSOT-OBS-06-Part-3.md
SSOT-OBS-06-Part-4.md
SSOT-OBS-06-Part-5.md
```

menjadi:

```text
SSOT-OBS-06.md
```

Urutan:

```text
Part 1 — Vision & Architecture
Part 2 — Metrics, KPI, Threshold, SLA/SLO
Part 3 — Registry, Orchestrator, Cache, Database
Part 4 — HTTP API, Security, Frontend
Part 5 — Reference Implementation & Operations
```

---

### 47. Merge Quality Checklist

- [ ] heading tidak duplikat;
- [ ] terminology konsisten;
- [ ] registry names konsisten;
- [ ] permission konsisten;
- [ ] table names konsisten;
- [ ] namespace konsisten;
- [ ] endpoint konsisten;
- [ ] error code konsisten;
- [ ] metric/KPI names konsisten;
- [ ] duplicate section dihapus;
- [ ] daftar isi dibuat;
- [ ] metadata final diperbarui;
- [ ] link internal diperbarui;
- [ ] status final diset Review/Approved.

---

### 48. Final Metadata

```yaml
document_code: SSOT-OBS-06
title: Monitoring Dashboard Framework
version: 1.0
status: Draft for Review
domain: Platform Kernel
category: Observability
owners:
  - Platform Architecture
  - Platform Operations
  - Frontend Platform
reviewers:
  - Backend Engineering
  - Frontend Engineering
  - DevOps
  - QA
  - Security
```

---

### 49. Approval Gate

Dokumen dapat menjadi Approved setelah:

- architecture review;
- security review;
- frontend review;
- operations review;
- QA/UAT review;
- performance review;
- accessibility review;
- database review;
- permission review;
- export policy review.

---

### 50. Closing Statement

Monitoring Dashboard Framework harus menjadi lapisan visual yang cepat, aman, konsisten, dan dapat dipercaya.

Dashboard tidak boleh:

- mengubah definisi metric;
- melewati RBAC/scope;
- menjadi sumber data utama;
- menyembunyikan stale/error state;
- membocorkan data sensitif;
- menjadi dependency dari Health Check Framework.

Dashboard harus membantu operator memahami kondisi platform, menemukan masalah, dan melakukan drill-down tanpa menciptakan risiko operasional baru.

---

## Lampiran A — Sumber Penggabungan

Dokumen final ini digabung dan dinormalisasi dari:

- `SSOT-OBS-06-Part-1.md`
- `SSOT-OBS-06-Part-2.md`
- `SSOT-OBS-06-Part-3.md`
- `SSOT-OBS-06-Part-4.md`
- `SSOT-OBS-06-Part-5.md`

## Lampiran B — Approval Gate

Status dokumen dapat diubah menjadi **Approved** setelah:

- architecture review selesai;
- security review selesai;
- frontend review selesai;
- operations review selesai;
- QA/UAT review selesai;
- performance review selesai;
- accessibility review selesai;
- database schema disetujui;
- permission dan scope policy disetujui;
- export policy disetujui;
- implementation feasibility disetujui.
