# SSOT-OBS-08 — Log Retention & Archiving Framework

> Single Source of Truth untuk klasifikasi log, kebijakan retention, legal hold, archiving, purging, integrity, storage architecture, retrieval, API, persistence, keamanan, operasi, dan pengujian pada Platform Kernel.

## Metadata Dokumen

| Item | Nilai |
|---|---|
| Kode | SSOT-OBS-08 |
| Judul | Log Retention & Archiving Framework |
| Versi | 1.0 |
| Status | Draft for Review |
| Domain | Platform Kernel |
| Kategori | Observability |
| Target Stack | PHP 8.1+, PDO, MySQL 8/MariaDB, Apache/XAMPP, Modular Monolith |
| Bergantung pada | SSOT-OBS-01 sampai SSOT-OBS-07 |
| Pemilik | Platform Architecture, Platform Operations, Security, Data Governance |
| Reviewer | Backend Engineering, DevOps, QA, Security, Compliance, Legal |

## Tujuan Dokumen

Dokumen ini menetapkan standar tunggal untuk:

- klasifikasi domain, sensitivity, criticality, purpose, retention class, dan storage class;
- ownership, tenant/scope isolation, privacy, PHI/PII handling, dan security boundary;
- retention policy, policy versioning, override, legal hold, exception, dan conflict resolution;
- archiving tiers, archive manifest, checksum, chain of custody, purge workflow, dan deletion evidence;
- storage topology, partitioning, indexing, compression, encryption, key management, metadata catalog, retrieval, backup, dan disaster recovery;
- HTTP API, controllers, middleware, permission, scheduler, database schema, audit, dan Apache/XAMPP routing;
- reference implementation, deployment, rollback, simulation, performance test, UAT, dan Definition of Done.

## Daftar Isi

1. Bagian I — Vision, Log Classification, Retention Principles, Ownership & Scope
2. Bagian II — Retention Policy, Legal Hold, Archiving Tiers, Purging, Integrity & Chain of Custody
3. Bagian III — Storage Architecture, Partitioning, Indexing, Compression, Encryption, Archive Format & Disaster Recovery
4. Bagian IV — HTTP API, Controllers, Middleware, Scheduler, Database Schema, Audit & Routing
5. Bagian V — Reference Implementation, Deployment, Simulation, Final UAT & Operational Readiness
6. Lampiran A — Sumber Penggabungan
7. Lampiran B — Approval Gate

## Status Normatif

Kata **wajib**, **harus**, dan **tidak boleh** menyatakan persyaratan normatif. Kata **direkomendasikan**, **sebaiknya**, dan **dapat** menyatakan panduan yang dapat disesuaikan melalui keputusan arsitektur terdokumentasi.

---

## Bagian I — Vision, Log Classification, Retention Principles, Ownership & Scope

### 1. Executive Summary

Log Retention & Archiving Framework menetapkan standar tunggal untuk mengelola lifecycle log sejak dibuat hingga dihapus secara aman.

Framework ini mencakup:

```text
Create
→ Classify
→ Store
→ Index
→ Retain
→ Archive
→ Retrieve
→ Place on Legal Hold
→ Purge
→ Verify
```

Tujuan utama framework:

- memastikan log disimpan sesuai nilai operasional;
- mencegah penyimpanan berlebihan;
- mengurangi biaya;
- menjaga integritas;
- mendukung audit dan incident investigation;
- memenuhi privacy dan compliance;
- mencegah penghapusan sebelum waktunya;
- mencegah penyimpanan data sensitif tanpa batas;
- menjaga tenant dan scope isolation;
- menyediakan ownership yang jelas.

Framework tidak hanya mengatur berapa lama log disimpan.

Framework juga mengatur:

- jenis log;
- klasifikasi;
- lokasi penyimpanan;
- akses;
- enkripsi;
- legal hold;
- archiving tier;
- retrieval;
- purge;
- verification;
- auditability.

---

### 2. Problem Statement

Tanpa standar retention dan archiving, log dapat berkembang menjadi:

- disimpan tanpa batas;
- dihapus terlalu cepat;
- bercampur antara audit, application, security, dan debug;
- mengandung PHI, PII, secret, atau token;
- tidak memiliki owner;
- tidak memiliki legal hold;
- tidak dapat dicari saat incident;
- membebani database produksi;
- tidak memiliki bukti penghapusan;
- bocor lintas tenant;
- kehilangan integritas;
- tidak konsisten antar module.

Contoh:

```text
Application log disimpan 5 tahun
Debug log disimpan 5 tahun
Security log hanya 7 hari
Audit log bercampur dengan error log
```

Kondisi tersebut tidak efisien dan berisiko.

---

### 3. Tujuan Framework

Framework harus menjawab:

- Log apa yang tersedia?
- Log tersebut termasuk klasifikasi apa?
- Siapa owner-nya?
- Berapa lama disimpan?
- Di storage tier mana?
- Siapa yang boleh mengakses?
- Apakah log mengandung data sensitif?
- Apakah log berada dalam legal hold?
- Kapan log diarsipkan?
- Kapan log dipurge?
- Bagaimana integritas diverifikasi?
- Bagaimana tenant dan scope dipisahkan?
- Bagaimana retrieval dilakukan saat incident atau audit?

---

### 4. Non-Goals

Part 1 tidak mendefinisikan secara detail:

- implementasi object storage;
- compression algorithm final;
- database partition SQL lengkap;
- scheduler purge;
- legal hold workflow lengkap;
- API retrieval;
- disaster recovery;
- migration package final.

Hal tersebut dibahas pada Part 2–5.

---

### 5. Design Principles

#### 5.1 Retain Only What Is Needed

Log tidak boleh disimpan tanpa tujuan.

Setiap log harus memiliki:

- purpose;
- owner;
- classification;
- retention;
- access policy.

#### 5.2 Classification Before Retention

Retention ditentukan setelah klasifikasi.

Bukan sebaliknya.

#### 5.3 Minimum Necessary

Simpan hanya data minimum yang diperlukan untuk:

- operations;
- troubleshooting;
- security;
- compliance;
- audit;
- incident response.

#### 5.4 Privacy by Design

Log tidak boleh menjadi tempat pembuangan data aplikasi.

#### 5.5 Immutable Where Required

Audit dan security evidence tertentu membutuhkan immutability lebih kuat.

#### 5.6 Tenant Isolation

Log tenant tidak boleh bocor ke tenant lain.

#### 5.7 Tiered Storage

Log aktif, warm, cold, dan archive dipisahkan berdasarkan akses dan biaya.

#### 5.8 Retention Is Enforced

Retention bukan dokumentasi pasif.

Retention harus dapat dijalankan dan diverifikasi.

#### 5.9 Legal Hold Overrides Purge

Legal hold yang sah menghentikan penghapusan sampai hold dilepas.

#### 5.10 Deletion Must Be Provable

Purge harus memiliki evidence dan audit trail.

---

### 6. High-Level Lifecycle

```text
Log Event Created
        ↓
Normalization & Sanitization
        ↓
Classification
        ↓
Routing to Storage Class
        ↓
Active Retention
        ↓
Warm/Cold Archiving
        ↓
Legal Hold Check
        ↓
Purge Eligibility
        ↓
Secure Purge
        ↓
Deletion Verification
```

---

### 7. Log Domains

Framework membedakan log berdasarkan domain:

```text
APPLICATION
ACCESS
SECURITY
AUDIT
INTEGRATION
DATABASE
INFRASTRUCTURE
PERFORMANCE
WORKFLOW
NOTIFICATION
SCHEDULER
QUEUE
HEALTH
INCIDENT
DEBUG
```

---

### 8. Application Log

Application log mencatat:

- application event;
- exception;
- validation failure;
- module operation;
- service behavior.

Tidak boleh menjadi audit log utama.

Contoh:

```text
order_processing_failed
appointment_sync_failed
workflow_transition_error
```

---

### 9. Access Log

Access log mencatat:

- HTTP method;
- route;
- status code;
- duration;
- client/network metadata aman;
- actor reference terbatas.

Jangan mencatat:

- authorization header;
- password;
- token;
- full sensitive query string.

---

### 10. Security Log

Security log mencatat:

- authentication failure;
- privilege change;
- suspicious activity;
- security control failure;
- credential lifecycle event;
- access denial;
- policy violation.

Security log memiliki akses lebih terbatas.

---

### 11. Audit Log

Audit log mencatat tindakan penting yang membutuhkan accountability.

Contoh:

- role assignment;
- patient record access;
- permission change;
- configuration change;
- incident close;
- export data;
- legal hold change.

Audit log berbeda dari application log.

---

### 12. Integration Log

Integration log mencatat:

- outbound request;
- inbound callback;
- retry;
- provider response code;
- timeout;
- circuit breaker state.

Payload harus disanitasi.

---

### 13. Database Log

Database log dapat mencakup:

- slow query;
- connection failure;
- deadlock;
- replication status;
- migration event.

Raw SQL sensitif harus dibatasi.

---

### 14. Infrastructure Log

Infrastructure log mencakup:

- web server;
- operating system;
- process manager;
- container;
- filesystem;
- backup;
- network proxy.

---

### 15. Performance Log

Performance log mencatat:

- latency;
- memory;
- CPU;
- slow operation;
- bottleneck;
- resource saturation.

Metric store biasanya lebih tepat untuk aggregation jangka panjang.

---

### 16. Workflow Log

Workflow log mencatat:

- workflow start;
- transition;
- failure;
- timeout;
- retry;
- compensation.

Workflow log tidak menggantikan workflow state.

---

### 17. Notification Log

Notification log mencatat:

- send attempt;
- channel;
- status;
- provider reference;
- retry;
- failure.

Jangan menyimpan isi sensitif tanpa kebutuhan.

---

### 18. Scheduler Log

Scheduler log mencatat:

- job start;
- job completion;
- failure;
- duration;
- overlap;
- missed schedule.

---

### 19. Queue Log

Queue log mencatat:

- enqueue;
- dequeue;
- processing;
- retry;
- dead-letter;
- wait time.

---

### 20. Health Log

Health log mencatat:

- health check result;
- status transition;
- dependency state;
- execution duration.

Current health state tidak hanya bergantung pada log.

---

### 21. Incident Log

Incident log mencatat:

- declaration;
- transition;
- assignment;
- mitigation;
- resolution;
- closure;
- communication event.

Incident timeline tetap menjadi sumber kebenaran incident.

---

### 22. Debug Log

Debug log:

- sangat detail;
- bersifat sementara;
- hanya untuk diagnostic;
- retention pendek;
- tidak boleh aktif terus-menerus di production tanpa approval.

---

### 23. Log Classification Dimensions

Setiap log diklasifikasikan berdasarkan:

```text
Domain
Sensitivity
Criticality
Purpose
Tenant Scope
Retention Class
Storage Class
Integrity Requirement
Access Level
```

---

### 24. Sensitivity Classification

```text
PUBLIC
INTERNAL
CONFIDENTIAL
RESTRICTED
SECURITY_RESTRICTED
LEGAL_HOLD
```

---

### 25. PUBLIC

Data yang aman untuk publik.

Dalam praktik, sangat sedikit operational log yang PUBLIC.

---

### 26. INTERNAL

Log operasional umum.

Contoh:

- route latency;
- component health;
- generic error code;
- queue count.

---

### 27. CONFIDENTIAL

Log yang mengandung:

- tenant-specific data;
- user reference;
- business operation detail;
- integration metadata sensitif.

---

### 28. RESTRICTED

Log yang mengandung:

- PII;
- PHI;
- sensitive audit context;
- restricted business data;
- detailed access evidence.

---

### 29. SECURITY_RESTRICTED

Log yang mengandung:

- security evidence;
- authentication anomaly;
- credential event;
- threat intelligence;
- compromise indicator.

---

### 30. LEGAL_HOLD

LEGAL_HOLD bukan klasifikasi isi utama.

Ini adalah retention override yang menahan log dari purge.

---

### 31. Criticality Classification

```text
CRITICAL
HIGH
MEDIUM
LOW
TEMPORARY
```

---

### 32. CRITICAL

Contoh:

- security event;
- audit event;
- incident timeline;
- data access event;
- privileged action.

---

### 33. HIGH

Contoh:

- production error;
- integration failure;
- database failure;
- scheduler failure.

---

### 34. MEDIUM

Contoh:

- warning;
- retry;
- degraded performance;
- non-critical workflow issue.

---

### 35. LOW

Contoh:

- informational operational event;
- normal completion;
- routine health detail.

---

### 36. TEMPORARY

Contoh:

- debug;
- trace-level diagnostic;
- temporary feature instrumentation.

---

### 37. Purpose Classification

```text
OPERATIONS
SECURITY
AUDIT
COMPLIANCE
INCIDENT_RESPONSE
PERFORMANCE
DEBUGGING
BUSINESS_CONTINUITY
```

---

### 38. Retention Classes

Initial retention class:

```text
R0_EPHEMERAL
R1_SHORT
R2_STANDARD
R3_EXTENDED
R4_REGULATED
R5_LEGAL_HOLD
```

---

### 39. R0_EPHEMERAL

Contoh:

- trace/debug temporary;
- local development log;
- temporary diagnostic.

Retention indikatif:

```text
hours to 7 days
```

---

### 40. R1_SHORT

Contoh:

- verbose application log;
- notification delivery detail;
- high-volume access log.

Retention indikatif:

```text
7–30 days
```

---

### 41. R2_STANDARD

Contoh:

- application error;
- integration failure;
- scheduler/queue operational history.

Retention indikatif:

```text
30–90 days
```

---

### 42. R3_EXTENDED

Contoh:

- security log;
- incident log;
- privileged operational event.

Retention indikatif:

```text
1–3 years
```

---

### 43. R4_REGULATED

Contoh:

- audit trail;
- compliance-required event;
- legally required access history.

Retention mengikuti:

- regulation;
- contract;
- jurisdiction;
- organizational policy.

---

### 44. R5_LEGAL_HOLD

Tidak dapat dipurge sampai legal hold dilepas.

---

### 45. Storage Classes

```text
HOT
WARM
COLD
ARCHIVE
PURGED
```

---

### 46. HOT

Karakteristik:

- aktif dicari;
- indexed;
- low-latency query;
- biaya tinggi;
- retention pendek.

---

### 47. WARM

Karakteristik:

- masih cukup sering diakses;
- partial index;
- compressed;
- query lebih lambat.

---

### 48. COLD

Karakteristik:

- jarang diakses;
- highly compressed;
- retrieval lebih lambat;
- biaya lebih rendah.

---

### 49. ARCHIVE

Karakteristik:

- long-term preservation;
- offline/nearline;
- retrieval terkontrol;
- integrity proof;
- access sangat terbatas.

---

### 50. PURGED

Data telah dihapus sesuai policy.

Purge bukan storage tier aktif.

---

### 51. Example Classification Matrix

| Log | Sensitivity | Criticality | Retention | Storage |
|---|---|---|---|---|
| Debug | INTERNAL | TEMPORARY | R0 | HOT |
| Access | CONFIDENTIAL | MEDIUM | R1/R2 | HOT→WARM |
| Application Error | INTERNAL/CONFIDENTIAL | HIGH | R2 | HOT→WARM |
| Security | SECURITY_RESTRICTED | CRITICAL | R3/R4 | HOT→WARM→ARCHIVE |
| Audit | RESTRICTED | CRITICAL | R4 | WARM→ARCHIVE |
| Incident Timeline | RESTRICTED | CRITICAL | R3/R4 | HOT→WARM→ARCHIVE |
| Integration | CONFIDENTIAL | HIGH | R2 | HOT→WARM |
| Health | INTERNAL | MEDIUM | R1/R2 | HOT→WARM |

---

### 52. Log Definition

Setiap log stream wajib memiliki metadata:

```text
code
domain
description
owner
producer
sensitivity
criticality
purpose
retention_class
storage_class
tenant_scope
schema_version
integrity_requirement
access_policy
legal_hold_eligible
enabled
```

---

### 53. Example Log Stream Definition

```php
return [
    'code' => 'platform_application_error',
    'domain' => 'APPLICATION',
    'description' => 'Normalized production application errors.',
    'owner' => 'platform_operations',
    'producer' => 'platform_logger',
    'sensitivity' => 'CONFIDENTIAL',
    'criticality' => 'HIGH',
    'purpose' => [
        'OPERATIONS',
        'INCIDENT_RESPONSE',
    ],
    'retention_class' => 'R2_STANDARD',
    'storage_class' => 'HOT',
    'tenant_scope' => 'TENANT_AWARE',
    'schema_version' => '1.0',
    'integrity_requirement' => 'STANDARD',
    'legal_hold_eligible' => true,
    'enabled' => true,
];
```

---

### 54. Log Registry

Log Registry menjadi katalog tunggal untuk seluruh log stream.

Tanggung jawab:

- registrasi stream;
- validasi code;
- validasi owner;
- validasi retention;
- validasi classification;
- resolve policy;
- expose metadata aman;
- versioning;
- deprecation.

---

### 55. Registry Contract

```php
interface LogStreamRegistryInterface
{
    public function register(
        LogStreamDefinition $definition
    ): void;

    public function get(
        string $code
    ): LogStreamDefinition;

    public function all(): array;

    public function active(): array;
}
```

---

### 56. Ownership Model

Setiap log wajib memiliki:

```text
Business Owner
Technical Owner
Security Owner optional
Data Steward optional
Retention Approver
```

---

### 57. Business Owner

Menentukan:

- purpose;
- business necessity;
- retention need;
- access need.

---

### 58. Technical Owner

Menentukan:

- producer;
- schema;
- storage;
- indexing;
- operational availability.

---

### 59. Security Owner

Diperlukan untuk:

- security log;
- restricted log;
- credential-related log;
- threat evidence.

---

### 60. Data Steward

Diperlukan bila log mengandung:

- PII;
- PHI;
- regulated data;
- cross-border data concern.

---

### 61. Retention Approver

Retention period harus disetujui oleh pihak yang sesuai:

- owner;
- security;
- compliance;
- legal;
- data governance.

---

### 62. Ownership Matrix

| Domain | Owner Utama |
|---|---|
| Application | Module/Service Owner |
| Access | Platform Operations |
| Security | Security Team |
| Audit | Security/Compliance |
| Integration | Integration Team |
| Database | DBA/Platform Data |
| Infrastructure | Platform Operations |
| Performance | Observability Team |
| Workflow | Workflow Owner |
| Notification | Communication Team |
| Scheduler/Queue | Platform Operations |
| Health | Platform Kernel Team |
| Incident | Platform Operations |
| Debug | Technical Owner |

---

### 63. Tenant Scope Classification

```text
GLOBAL
TENANT_AWARE
TENANT_ISOLATED
SCOPE_ISOLATED
CROSS_TENANT_AGGREGATE
```

---

### 64. GLOBAL

Log platform-level tanpa tenant-specific payload.

---

### 65. TENANT_AWARE

Log memiliki tenant context dan wajib difilter.

---

### 66. TENANT_ISOLATED

Log disimpan atau dipartisi terpisah secara kuat.

Digunakan untuk:

- high-risk tenant;
- regulated workload;
- contractual isolation.

---

### 67. SCOPE_ISOLATED

Log terkait clinic, facility, business entity, atau organization scope.

---

### 68. CROSS_TENANT_AGGREGATE

Hanya berisi aggregate aman.

Tidak mengandung tenant detail tanpa authorization.

---

### 69. Required Context Fields

Log tenant-aware minimal memiliki:

```text
tenant_id
scope_id optional
module_code
environment
correlation_id
event_code
occurred_at
```

---

### 70. Prohibited Log Content

Tidak boleh dicatat:

- password;
- raw access token;
- refresh token;
- API key;
- private key;
- session secret;
- full payment card;
- full medical record;
- unmasked national ID;
- raw authorization header;
- database credential;
- encryption key.

---

### 71. Sensitive Data Handling

Bila data sensitif benar-benar diperlukan:

- tokenize;
- mask;
- hash;
- redact;
- truncate;
- reference secure store;
- classify as restricted;
- reduce retention.

---

### 72. PHI/PII Policy

Operational log sebaiknya menggunakan:

```text
patient_reference
user_reference
transaction_reference
```

bukan:

```text
patient_name
diagnosis
phone
email
medical_record_number
```

---

### 73. Correlation Without Identity Leakage

Gunakan:

```text
correlation_id
request_id
trace_id
event_id
tenant_id
module_code
```

Bukan raw identity.

---

### 74. Log Schema

Minimum common fields:

```text
timestamp
event_code
level
message
domain
environment
tenant_id
scope_id
module_code
correlation_id
trace_id
actor_reference
resource_reference
classification
schema_version
```

---

### 75. Event Code

Event code harus stabil.

Contoh:

```text
DB_CONNECTION_FAILED
AUTH_LOGIN_FAILED
ALERT_ACKNOWLEDGED
INCIDENT_CLOSED
EXPORT_CREATED
```

Message boleh berubah.

Event code tidak boleh berubah tanpa versioning.

---

### 76. Log Level

```text
TRACE
DEBUG
INFO
NOTICE
WARNING
ERROR
CRITICAL
ALERT
EMERGENCY
```

Retention tidak ditentukan hanya dari level.

Audit INFO dapat disimpan lebih lama daripada application ERROR.

---

### 77. Integrity Requirements

```text
STANDARD
HASHED
CHAINED
IMMUTABLE
WORM
```

---

### 78. STANDARD

Storage normal dengan access control dan backup.

---

### 79. HASHED

Batch/file memiliki checksum.

---

### 80. CHAINED

Log record atau batch memiliki hash chain.

---

### 81. IMMUTABLE

Data tidak dapat diubah setelah ditulis melalui interface biasa.

---

### 82. WORM

Write Once Read Many.

Cocok untuk regulated archive tertentu.

---

### 83. Access Levels

```text
OPERATIONS
SECURITY
COMPLIANCE
AUDITOR
TENANT_ADMIN
MODULE_OWNER
LEGAL
SYSTEM
```

---

### 84. Access Principles

- Least privilege.
- Need to know.
- Tenant/scope enforcement.
- Sensitive query diaudit.
- Export dibatasi.
- Bulk retrieval membutuhkan approval.
- Legal hold access dibatasi.

---

### 85. Retention Decision Factors

Retention ditentukan dari:

```text
Operational Value
Security Value
Audit Value
Compliance Requirement
Legal Requirement
Investigation Need
Data Sensitivity
Volume
Cost
Retrieval Frequency
Contractual Requirement
```

---

### 86. Retention Conflict Resolution

Jika beberapa policy berlaku:

```text
legal hold
→ legal/regulatory requirement
→ contractual requirement
→ security requirement
→ business requirement
→ default retention
```

Retention terpanjang tidak otomatis selalu benar.

Privacy minimization tetap dipertimbangkan.

---

### 87. Retention Start Point

Retention dapat dihitung dari:

```text
event timestamp
ingestion timestamp
incident closure
contract termination
user/account deletion
legal hold release
```

Start point wajib eksplisit.

---

### 88. Time Source

Timestamp internal disimpan dalam UTC.

Display menggunakan user/context timezone.

---

### 89. Retention Extension

Extension diperbolehkan untuk:

- active incident;
- security investigation;
- audit;
- legal hold;
- regulatory request;
- approved troubleshooting.

Extension wajib:

- reason;
- scope;
- owner;
- approval;
- expiry;
- audit.

---

### 90. Retention Reduction

Retention reduction dapat dilakukan bila:

- data terlalu sensitif;
- operational value rendah;
- volume tinggi;
- privacy requirement;
- policy berubah.

Perubahan tidak boleh menghapus data yang berada dalam legal hold.

---

### 91. Archive Eligibility

Log eligible untuk archive bila:

- tidak sering diakses;
- retention masih aktif;
- schema valid;
- integrity verified;
- legal hold status diketahui;
- export batch lengkap.

---

### 92. Purge Eligibility

Log eligible dipurge bila:

- retention expired;
- tidak dalam legal hold;
- tidak dalam active investigation;
- tidak ada regulatory freeze;
- integrity metadata tidak dibutuhkan lagi;
- purge approval/policy valid.

---

### 93. Legal Hold Overview

Legal hold menghentikan purge untuk data tertentu.

Scope legal hold dapat berdasarkan:

```text
tenant
user reference
incident
date range
event type
module
case reference
```

Detail workflow dibahas pada Part 2.

---

### 94. Archiving Overview

Archiving memindahkan log ke storage lebih murah.

Archiving tidak berarti menghapus.

Archive harus tetap:

- searchable melalui metadata;
- retrievable;
- integrity-verifiable;
- access-controlled;
- retention-aware.

---

### 95. Purging Overview

Purge berarti penghapusan permanen sesuai policy.

Purge harus:

- deterministic;
- scoped;
- idempotent;
- logged;
- verified;
- legal-hold aware.

---

### 96. Deletion Evidence

Deletion evidence minimal:

```text
policy
scope
range
record count
storage object count
started_at
completed_at
actor/job
verification result
```

Evidence tidak boleh menyimpan ulang data yang telah dipurge.

---

### 97. Retrieval Overview

Archive retrieval harus memiliki:

- requestor;
- purpose;
- scope;
- approval bila perlu;
- time range;
- expiry;
- audit.

---

### 98. Log Export

Export log adalah aktivitas berisiko.

Wajib:

- permission;
- tenant/scope;
- classification check;
- row/size limit;
- expiry;
- audit;
- secure storage;
- encryption.

---

### 99. Privacy Requests

Data subject request dapat memengaruhi log.

Namun penghapusan log tidak selalu langsung dilakukan jika:

- legal obligation;
- security requirement;
- audit requirement;
- fraud prevention;
- legal hold.

Keputusan wajib melibatkan privacy/legal policy.

---

### 100. Cross-Border Consideration

Log storage location dapat dipengaruhi oleh:

- residency;
- jurisdiction;
- tenant contract;
- healthcare regulation;
- security policy.

Log Registry sebaiknya memiliki field:

```text
residency_policy
```

---

### 101. Environment Separation

Log dari:

```text
local
development
testing
staging
production
```

tidak boleh tercampur tanpa label dan access policy.

Production log memiliki policy lebih ketat.

---

### 102. Development Log

Development log:

- boleh lebih verbose;
- tidak boleh memakai production PHI/PII;
- retention pendek;
- tidak boleh menjadi sumber audit.

---

### 103. Production Debug Logging

Production debug logging hanya boleh:

- bounded time;
- approved;
- scoped;
- monitored;
- auto-expire;
- sanitized;
- diaudit.

---

### 104. Log Volume Governance

Setiap stream harus memiliki:

```text
expected_events_per_day
expected_bytes_per_day
maximum_event_size
maximum_daily_volume
```

Jika melebihi:

- alert;
- sampling;
- throttling;
- review;
- storage expansion;
- schema optimization.

---

### 105. Sampling

Sampling diperbolehkan untuk:

- high-volume access log;
- debug;
- repetitive INFO event;
- performance detail.

Sampling tidak diperbolehkan untuk:

- audit;
- security-critical;
- legal hold;
- incident timeline;
- privileged action.

---

### 106. Redaction

Redaction harus dilakukan sebelum persistent storage jika memungkinkan.

Contoh:

```text
Authorization: Bearer ***
email: j***@example.com
phone: ******1234
```

---

### 107. Normalization

Normalization mencakup:

- event code;
- field naming;
- timestamp;
- environment;
- tenant;
- schema version;
- classification.

---

### 108. Log Quality

Quality indicators:

```text
VALID
PARTIAL
MALFORMED
DROPPED
REDACTED
DUPLICATE
LATE
```

---

### 109. Malformed Log

Malformed log harus:

- tidak merusak pipeline;
- masuk quarantine;
- dihitung;
- memberi alert bila berulang;
- tidak langsung dibuang tanpa telemetry.

---

### 110. Late Log

Late log adalah event yang diterima terlambat.

Policy harus menentukan:

- accepted lateness;
- storage partition;
- retention start;
- ordering.

---

### 111. Duplicate Log

Duplicate dapat terjadi karena retry.

Gunakan:

```text
event_id
idempotency key
producer sequence
```

jika domain membutuhkan deduplication.

---

### 112. Log Loss

Log loss adalah incident observability.

Metric:

```text
log_ingestion_failed_total
log_dropped_total
log_pipeline_backlog
log_delivery_lag_seconds
```

---

### 113. Observability of Retention System

Framework harus memantau:

```text
log_volume_bytes
log_event_total
archive_job_total
archive_job_failure_total
purge_job_total
purge_job_failure_total
legal_hold_total
retrieval_request_total
retention_policy_violation_total
storage_usage_percent
```

---

### 114. Dashboard Integration

Dashboard minimum:

- log volume by domain;
- storage usage;
- archive backlog;
- purge backlog;
- legal hold count;
- retention violation;
- ingestion failure;
- malformed log count;
- archive retrieval status.

---

### 115. Alert Integration

Alert contoh:

```text
log ingestion failure
archive job failed
purge job failed
retention policy violation
storage usage high
legal hold conflict
checksum mismatch
archive retrieval failure
```

---

### 116. Incident Integration

Incident dapat dibuat bila:

- widespread log loss;
- audit log integrity failure;
- unauthorized purge;
- archive corruption;
- security log unavailable;
- cross-tenant log exposure;
- legal hold violation.

---

### 117. Permission Model

Initial permissions:

```text
observability.log.read
observability.log.search
observability.log.restricted.read
observability.log.security.read
observability.log.export
observability.log.retention.read
observability.log.retention.manage
observability.log.archive.read
observability.log.archive.manage
observability.log.purge.execute
observability.log.legal_hold.read
observability.log.legal_hold.manage
observability.log.cross_tenant.read
```

---

### 118. Role Matrix

| Role | Akses |
|---|---|
| Platform Admin | operational log |
| Operations Admin | application/infrastructure |
| Security Admin | security log |
| Compliance | audit/retention/legal hold |
| Tenant Admin | tenant log terbatas |
| Module Owner | module log |
| Auditor | read-only approved scope |
| Legal | legal hold |
| End User | tidak ada akses teknis |

---

### 119. Audit Policy

Wajib audit:

- restricted log search;
- bulk export;
- retention policy change;
- legal hold create/release;
- archive retrieval;
- manual purge;
- purge override;
- cross-tenant access;
- security log access;
- retention extension.

---

### 120. Security Boundary

Framework tidak boleh:

- memberi direct DB access ke user;
- menerima raw SQL dari UI;
- menyimpan archive di public directory;
- menaruh secret pada log;
- mengizinkan purge tanpa policy;
- mengizinkan legal hold dihapus tanpa audit;
- mencampur tenant pada export;
- menyimpan restricted log tanpa encryption.

---

### 121. Encryption Overview

Rekomendasi:

```text
in transit encryption
at rest encryption
archive encryption
key rotation
key separation
```

Detail dibahas pada Part 3.

---

### 122. Integrity Overview

Audit/security archive dapat menggunakan:

- checksum;
- signed manifest;
- hash chain;
- immutable storage;
- WORM.

---

### 123. Backup vs Archive

Backup dan archive berbeda.

| Backup | Archive |
|---|---|
| recovery sistem | long-term retention |
| snapshot | record lifecycle |
| short/medium-term | policy-driven |
| restore whole dataset | retrieve scoped data |
| tidak menggantikan archive | tidak menggantikan backup |

---

### 124. Source of Truth

Log tidak selalu menjadi sumber kebenaran bisnis.

Contoh:

- order state ada di operational database;
- incident state ada di incident store;
- audit event ada di audit store;
- log adalah evidence/supporting context.

---

### 125. Policy Hierarchy

```text
Enterprise Policy
→ Security/Privacy Policy
→ Compliance/Legal Requirement
→ Domain Policy
→ Log Stream Policy
→ Tenant Contract Override
```

Override harus terdokumentasi.

---

### 126. Policy Versioning

Retention policy wajib memiliki:

```text
version
effective_from
effective_until
approved_by
change_reason
```

---

### 127. Default Deny

Jika log stream tidak memiliki policy valid:

- ingestion dapat masuk quarantine;
- archive tidak dijalankan;
- purge tidak dijalankan;
- owner diberi alert.

Lebih aman daripada purge tanpa policy.

---

### 128. Anti-Pattern

Hindari:

- semua log disimpan selamanya;
- retention hanya berdasarkan level;
- audit log dicampur dengan debug;
- debug aktif permanen di production;
- raw payload integration disimpan;
- PHI/PII tanpa masking;
- archive tanpa checksum;
- purge tanpa legal hold check;
- export ke public folder;
- tenant ID tidak ada;
- owner tidak ada;
- policy tanpa version;
- backup dianggap archive;
- log database produksi menjadi storage observability utama.

---

### 129. UAT Part 1

#### Classification

- [ ] Semua log stream memiliki domain.
- [ ] Sensitivity tersedia.
- [ ] Criticality tersedia.
- [ ] Purpose tersedia.
- [ ] Retention class tersedia.
- [ ] Storage class tersedia.
- [ ] Integrity requirement tersedia.

#### Ownership

- [ ] Business owner tersedia.
- [ ] Technical owner tersedia.
- [ ] Security owner tersedia bila perlu.
- [ ] Retention approver tersedia.
- [ ] Stream tanpa owner ditolak.

#### Tenant & Scope

- [ ] Tenant-aware log memiliki tenant_id.
- [ ] Scope-isolated log memiliki scope_id.
- [ ] Cross-tenant aggregate disanitasi.
- [ ] Tenant admin tidak melihat tenant lain.
- [ ] Cache/export terisolasi.

#### Privacy & Security

- [ ] Password/token tidak tercatat.
- [ ] PHI/PII dimasking atau direferensikan.
- [ ] Restricted log dibatasi.
- [ ] Production debug memiliki expiry.
- [ ] Restricted export diaudit.

#### Retention

- [ ] Retention start point eksplisit.
- [ ] Legal hold override dipahami.
- [ ] Archive eligibility tersedia.
- [ ] Purge eligibility tersedia.
- [ ] Retention conflict resolution tersedia.

#### Integrity

- [ ] Integrity requirement ditentukan.
- [ ] Audit/security stream tidak dapat dimodifikasi bebas.
- [ ] Checksum/hash policy tersedia.
- [ ] Deletion evidence requirement tersedia.

---

### 130. Definition of Done Part 1

Part 1 dianggap selesai bila:

- [ ] visi dan problem statement disepakati;
- [ ] log domains tersedia;
- [ ] sensitivity classification tersedia;
- [ ] criticality classification tersedia;
- [ ] purpose classification tersedia;
- [ ] retention classes tersedia;
- [ ] storage classes tersedia;
- [ ] log definition tersedia;
- [ ] Log Registry tersedia;
- [ ] ownership model tersedia;
- [ ] tenant/scope model tersedia;
- [ ] prohibited content policy tersedia;
- [ ] PHI/PII policy tersedia;
- [ ] common schema tersedia;
- [ ] integrity requirement tersedia;
- [ ] access model tersedia;
- [ ] retention decision factors tersedia;
- [ ] legal hold overview tersedia;
- [ ] archive/purge overview tersedia;
- [ ] permission model tersedia;
- [ ] audit policy tersedia;
- [ ] security boundary tersedia;
- [ ] UAT tersedia.

---

### 131. Rencana Part Berikutnya

#### Part 2

Retention policy, legal hold, retention override, archiving tiers, purge workflow, deletion verification, integrity manifest, chain of custody, dan exception handling.

#### Part 3

Storage architecture, partitioning, indexing, compression, encryption, object storage, archive format, metadata catalog, retrieval, dan disaster recovery.

#### Part 4

HTTP API, controllers, middleware, scheduler, database schema, audit integration, security controls, Apache/XAMPP routing, dan sequence diagram.

#### Part 5

Reference implementation, sample policies, migration, deployment, rollback, retention simulation, final UAT, Definition of Done, roadmap, dan merge guidance.

---

## Bagian II — Retention Policy, Legal Hold, Archiving Tiers, Purging, Integrity & Chain of Custody

### 1. Executive Summary

Part 2 mendefinisikan kebijakan retention dan archiving secara operasional.

Bagian ini menetapkan:

- RetentionPolicy;
- retention start point;
- retention override;
- legal hold;
- maintenance hold;
- investigation hold;
- archive eligibility;
- storage tier transition;
- purge eligibility;
- purge approval;
- secure deletion;
- deletion verification;
- integrity manifest;
- checksum;
- chain of custody;
- exception handling;
- policy versioning;
- UAT.

Tujuan utamanya adalah memastikan log:

- disimpan selama diperlukan;
- tidak disimpan tanpa batas;
- tidak dihapus sebelum waktunya;
- dapat ditahan melalui legal hold;
- dapat dipindahkan ke archive secara aman;
- dapat dipurge secara terukur;
- memiliki bukti integritas dan penghapusan.

---

### 2. Retention Policy Model

RetentionPolicy mendeskripsikan lifecycle satu log stream atau log class.

Field minimum:

```text
code
title
description
log_stream
retention_class
start_point
hot_duration
warm_duration
cold_duration
archive_duration
purge_after
legal_hold_eligible
integrity_requirement
owner
approver
effective_from
effective_until
version
status
```

---

### 3. Example Retention Policy

```php
return [
    'code' => 'application_error_standard',
    'title' => 'Application Error Standard Retention',
    'log_stream' => 'platform_application_error',
    'retention_class' => 'R2_STANDARD',
    'start_point' => 'event_timestamp',
    'hot_duration' => '30d',
    'warm_duration' => '60d',
    'cold_duration' => '0d',
    'archive_duration' => '0d',
    'purge_after' => '90d',
    'legal_hold_eligible' => true,
    'integrity_requirement' => 'HASHED',
    'owner' => 'platform_operations',
    'approver' => 'security_compliance',
    'effective_from' => '2026-07-01',
    'version' => '1.0',
    'status' => 'ACTIVE',
];
```

---

### 4. Policy Lifecycle

```text
DRAFT
REVIEW
APPROVED
ACTIVE
SUSPENDED
DEPRECATED
ARCHIVED
```

---

### 5. Policy Approval

Retention policy wajib direview oleh pihak yang relevan:

- business owner;
- technical owner;
- security;
- privacy;
- compliance;
- legal;
- data governance.

---

### 6. Policy Versioning

Breaking change membutuhkan versi baru.

Contoh breaking change:

- retention period berubah;
- start point berubah;
- legal hold eligibility berubah;
- storage tier berubah;
- integrity requirement berubah;
- purge method berubah.

---

### 7. Effective Date

Policy wajib memiliki:

```text
effective_from
effective_until optional
```

Policy lama tidak boleh ditimpa tanpa history.

---

### 8. Retention Start Point

Supported start point:

```text
EVENT_TIMESTAMP
INGESTION_TIMESTAMP
INCIDENT_CLOSED_AT
CASE_CLOSED_AT
ACCOUNT_TERMINATED_AT
CONTRACT_ENDED_AT
LEGAL_HOLD_RELEASED_AT
CUSTOM_DOMAIN_EVENT
```

---

### 9. Event Timestamp

Umum untuk operational log.

```text
retention_end =
event_timestamp + retention_duration
```

---

### 10. Ingestion Timestamp

Digunakan bila event timestamp tidak dapat dipercaya.

---

### 11. Incident Closure Start

Cocok untuk:

- incident timeline;
- evidence;
- postmortem support log.

---

### 12. Legal Hold Release Start

Untuk data yang sebelumnya berada dalam legal hold.

Setelah hold dilepas, policy menentukan apakah retention:

- dilanjutkan dari original start;
- dihitung ulang dari release;
- memakai grace period.

---

### 13. Retention Duration Syntax

Format rekomendasi:

```text
1h
24h
7d
30d
90d
1y
7y
```

Jangan memakai teks bebas.

---

### 14. Tier Duration

Retention total dapat dibagi:

```text
HOT
WARM
COLD
ARCHIVE
```

Contoh:

```text
HOT 30d
WARM 60d
ARCHIVE 1y
PURGE after 455d
```

---

### 15. Total Retention

Total retention dihitung dari seluruh tier.

Policy harus konsisten.

Contoh invalid:

```text
purge_after = 90d
archive_duration = 1y
```

---

### 16. Retention Override Types

```text
LEGAL_HOLD
SECURITY_INVESTIGATION
INCIDENT_EXTENSION
AUDIT_EXTENSION
REGULATORY_FREEZE
CONTRACT_OVERRIDE
MANUAL_APPROVED_EXTENSION
```

---

### 17. Override Priority

```text
LEGAL_HOLD
→ REGULATORY_FREEZE
→ SECURITY_INVESTIGATION
→ AUDIT_EXTENSION
→ INCIDENT_EXTENSION
→ CONTRACT_OVERRIDE
→ DEFAULT_POLICY
```

---

### 18. Retention Override Fields

```text
override_id
type
scope
reason
starts_at
ends_at
created_by
approved_by
case_reference
status
```

---

### 19. Override Scope

Scope dapat berdasarkan:

```text
log_stream
tenant
scope
module
event_code
date_range
incident
case
resource_reference
actor_reference
```

---

### 20. Override Safety

Override tidak boleh:

- tanpa reason;
- tanpa owner;
- tanpa approval;
- tanpa expiry kecuali legal hold;
- lebih luas dari kebutuhan;
- mengurangi retention di bawah requirement legal.

---

### 21. Legal Hold

Legal hold menahan data dari purge.

Legal hold dapat berlaku pada:

- specific log stream;
- tenant;
- incident;
- case;
- date range;
- user/resource reference;
- security evidence set.

---

### 22. Legal Hold States

```text
DRAFT
ACTIVE
RELEASE_PENDING
RELEASED
CANCELLED
```

---

### 23. Legal Hold Record

Field minimum:

```text
hold_id
case_reference
title
reason
scope
data_classes
starts_at
released_at
owner
approved_by
classification
status
created_at
updated_at
```

---

### 24. Legal Hold Creation

Wajib:

- authorized requester;
- case reference;
- defined scope;
- approval;
- audit;
- immediate purge block;
- notification to data owner.

---

### 25. Legal Hold Release

Release wajib:

- authorized approver;
- reason;
- release timestamp;
- audit;
- post-release retention evaluation;
- purge grace period bila perlu.

---

### 26. Legal Hold Conflict

Jika purge job menemukan matching legal hold:

```text
skip purge
record hold conflict
increment metric
```

---

### 27. Legal Hold Verification

Sebelum purge:

1. resolve all active holds;
2. evaluate scope overlap;
3. verify hold status;
4. block purge if any match;
5. persist decision evidence.

---

### 28. Investigation Hold

Investigation hold adalah temporary retention extension.

Contoh:

- active security investigation;
- incident root cause analysis;
- fraud investigation;
- audit sampling.

Harus memiliki expiry.

---

### 29. Maintenance Hold

Maintenance hold dapat digunakan saat:

- migration;
- archive re-indexing;
- storage repair;
- retention policy rollout.

Maintenance hold tidak boleh dipakai untuk menghindari purge tanpa alasan.

---

### 30. Archive Eligibility

Log eligible untuk archive jika:

- active query frequency rendah;
- retention masih berlaku;
- no active mutation;
- schema valid;
- integrity verified;
- archive format tersedia;
- metadata lengkap;
- hold status diketahui.

---

### 31. Archive Transition

```text
HOT → WARM → COLD → ARCHIVE
```

Transition dapat melewati tier tertentu jika policy mengizinkan.

---

### 32. HOT to WARM

Dilakukan bila:

- age melewati hot_duration;
- log tidak lagi membutuhkan low-latency access;
- index dapat dikurangi;
- compression dapat ditingkatkan.

---

### 33. WARM to COLD

Dilakukan bila:

- query jarang;
- retention masih cukup panjang;
- restore delay dapat diterima.

---

### 34. COLD to ARCHIVE

Dilakukan bila:

- long-term retention;
- legal/compliance;
- low retrieval frequency;
- immutable preservation dibutuhkan.

---

### 35. Archive Batch

Archive diproses dalam batch.

Field:

```text
batch_id
policy_code
log_stream
scope
from_timestamp
to_timestamp
record_count
object_count
manifest_reference
checksum
status
started_at
completed_at
```

---

### 36. Archive Batch States

```text
PLANNED
EXPORTING
VERIFYING
COMPLETED
FAILED
CANCELLED
```

---

### 37. Archive Manifest

Manifest berisi:

```text
batch_id
source
policy_version
schema_version
record_count
object_list
object_hashes
created_at
created_by_job
encryption_metadata
retention_end
legal_hold_status
```

---

### 38. Manifest Integrity

Manifest dapat:

- di-hash;
- ditandatangani;
- disimpan immutable;
- direplikasi.

---

### 39. Checksum

Supported checksum:

```text
SHA-256
SHA-512
```

Checksum digunakan untuk:

- object;
- file;
- batch;
- manifest.

---

### 40. Archive Verification

Verification minimum:

- object exists;
- checksum match;
- record count match;
- schema version valid;
- manifest valid;
- encryption metadata valid;
- retrieval test optional.

---

### 41. Source Deletion After Archive

Source log tidak boleh dihapus sebelum:

- archive completed;
- verification passed;
- manifest persisted;
- hold check passed;
- grace period passed jika policy mengharuskan.

---

### 42. Archive Grace Period

Contoh:

```text
7 days
```

Selama grace period:

- source tetap tersedia;
- archive diverifikasi;
- retrieval test dapat dijalankan.

---

### 43. Archive Failure

Jika archive gagal:

- source tidak dihapus;
- batch status FAILED;
- retry bounded;
- alert dibuat;
- owner diberi notification;
- audit dicatat.

---

### 44. Archive Retry

Retry policy:

```text
immediate
+5m
+30m
+2h
manual review
```

Gunakan idempotency per batch.

---

### 45. Purge Eligibility

Log eligible dipurge bila:

- retention expired;
- archive requirement selesai;
- no active legal hold;
- no investigation hold;
- no regulatory freeze;
- no pending retrieval;
- no integrity failure;
- policy active;
- scope valid.

---

### 46. Purge Plan

Purge plan berisi:

```text
plan_id
policy_code
scope
eligible_range
estimated_records
estimated_objects
hold_check_result
approval_required
scheduled_at
status
```

---

### 47. Purge Modes

```text
AUTOMATIC
APPROVAL_REQUIRED
MANUAL_ONLY
```

---

### 48. Automatic Purge

Cocok untuk:

- low-risk high-volume log;
- short retention;
- no legal sensitivity;
- stable policy.

---

### 49. Approval-Required Purge

Cocok untuk:

- restricted log;
- security log;
- archive objects;
- large batch;
- tenant termination;
- regulated data.

---

### 50. Manual-Only Purge

Cocok untuk:

- legal hold release;
- exceptional correction;
- security evidence;
- regulated archive.

---

### 51. Purge Workflow

```text
Identify Eligible Data
→ Resolve Policy
→ Check Holds
→ Build Purge Plan
→ Approve if Required
→ Execute
→ Verify
→ Record Evidence
→ Close
```

---

### 52. Purge Execution

Purge harus:

- bounded;
- batched;
- idempotent;
- resumable;
- tenant-aware;
- scope-aware;
- rate-limited;
- audited.

---

### 53. Purge Batch

Field:

```text
batch_id
plan_id
scope
record_count
object_count
started_at
completed_at
status
error_code
verification_status
```

---

### 54. Purge States

```text
PLANNED
APPROVED
RUNNING
VERIFYING
COMPLETED
FAILED
PARTIAL
CANCELLED
```

---

### 55. Secure Deletion

Secure deletion depends on storage technology.

Methods:

- database row deletion;
- partition drop;
- object deletion;
- cryptographic erasure;
- key destruction;
- storage lifecycle delete.

---

### 56. Cryptographic Erasure

Jika archive dienkripsi dengan dedicated key:

```text
destroy key
```

dapat menjadi bagian secure deletion.

Tetap harus mempertimbangkan:

- backup copies;
- replicated copies;
- key escrow;
- legal hold.

---

### 57. Partition Drop

Untuk time-partitioned log:

```text
DROP PARTITION
```

lebih efisien daripada row-by-row delete.

Harus memastikan:

- partition scope tepat;
- no active hold;
- archive complete;
- manifest tersedia.

---

### 58. Object Deletion

Object storage purge harus:

- delete object;
- delete versions sesuai policy;
- delete replicas;
- verify non-existence;
- record object references.

---

### 59. Backup Copies

Purge policy harus menjelaskan backup.

Pilihan:

- expire naturally;
- targeted purge jika teknis memungkinkan;
- cryptographic erasure;
- documented delayed deletion.

---

### 60. Deletion Verification

Verification dapat mencakup:

- record count before/after;
- object listing;
- partition existence check;
- retrieval negative test;
- checksum catalog update;
- storage inventory reconciliation.

---

### 61. Deletion Evidence

Field minimum:

```text
evidence_id
purge_batch_id
policy_code
scope
time_range
records_deleted
objects_deleted
verification_method
verification_result
executed_by
started_at
completed_at
evidence_hash
```

---

### 62. Evidence Immutability

Deletion evidence tidak boleh menyimpan raw deleted log.

Hanya metadata dan proof.

---

### 63. Partial Purge

Jika sebagian gagal:

```text
status = PARTIAL
```

Wajib:

- identify remaining scope;
- prevent duplicate deletion error;
- retry safely;
- alert owner;
- retain evidence.

---

### 64. Purge Failure

Purge failure tidak boleh:

- dianggap selesai;
- menghapus manifest;
- menutup legal hold check;
- diabaikan tanpa alert.

---

### 65. Chain of Custody

Chain of custody diperlukan untuk:

- security evidence;
- audit evidence;
- legal hold;
- regulated archive;
- incident evidence.

---

### 66. Chain of Custody Events

```text
COLLECTED
TRANSFERRED
ARCHIVED
RETRIEVED
VIEWED
EXPORTED
RETURNED
PURGED
HOLD_APPLIED
HOLD_RELEASED
```

---

### 67. Chain of Custody Record

```text
event_id
evidence_reference
event_type
actor
timestamp
source
destination
reason
hash_before
hash_after
approval_reference
```

---

### 68. Retrieval Request

Archive retrieval request harus memiliki:

```text
request_id
requestor
purpose
scope
time_range
classification
approval
expires_at
status
```

---

### 69. Retrieval States

```text
REQUESTED
APPROVED
RESTORING
AVAILABLE
EXPIRED
REJECTED
FAILED
```

---

### 70. Retrieval Security

Retrieval wajib:

- least privilege;
- bounded scope;
- secure temporary storage;
- expiry;
- access logging;
- no public URL;
- tenant isolation;
- classification enforcement.

---

### 71. Temporary Restore

Archive dapat direstore ke temporary search store.

Temporary store harus:

- encrypted;
- isolated;
- auto-expire;
- no unrestricted export;
- query audited.

---

### 72. Retrieval Completion

Setelah selesai:

- temporary data dipurge;
- access log dipertahankan;
- request ditutup;
- evidence dicatat.

---

### 73. Integrity Levels

```text
STANDARD
CHECKSUM
SIGNED_MANIFEST
HASH_CHAIN
IMMUTABLE_STORAGE
WORM
```

---

### 74. Integrity Policy by Log Class

| Log | Integrity |
|---|---|
| Debug | STANDARD |
| Application Error | CHECKSUM |
| Security | SIGNED_MANIFEST/HASH_CHAIN |
| Audit | IMMUTABLE_STORAGE/WORM |
| Incident Evidence | SIGNED_MANIFEST |
| Access | CHECKSUM |
| Archive | SIGNED_MANIFEST |

---

### 75. Hash Chain

Hash chain dapat menggunakan:

```text
hash_n = SHA256(hash_{n-1} + canonical_record_n)
```

Cocok untuk tamper evidence.

---

### 76. Canonical Serialization

Hash membutuhkan canonical format:

- field order tetap;
- normalized timestamp;
- UTF-8;
- no insignificant whitespace;
- schema version included.

---

### 77. Integrity Verification Schedule

Contoh:

| Tier | Frequency |
|---|---:|
| HOT critical | daily |
| WARM | weekly |
| COLD | monthly |
| ARCHIVE | quarterly |
| WORM | periodic sample |

---

### 78. Integrity Failure

Jika checksum mismatch:

- stop purge;
- stop source deletion;
- mark archive suspect;
- create SEV1/SEV2 alert;
- start incident if critical;
- preserve evidence;
- investigate.

---

### 79. Policy Exception

Exception diperlukan bila standard policy tidak dapat dipenuhi.

Field:

```text
exception_id
policy_code
scope
reason
risk
compensating_control
owner
approved_by
starts_at
ends_at
status
```

---

### 80. Exception States

```text
REQUESTED
APPROVED
ACTIVE
EXPIRED
REJECTED
CLOSED
```

---

### 81. Exception Rules

Exception wajib:

- bounded;
- memiliki expiry;
- memiliki compensating control;
- diaudit;
- direview;
- tidak boleh melanggar legal hold.

---

### 82. Common Exceptions

- storage migration;
- archive provider outage;
- legal review pending;
- tenant contract transition;
- incident investigation;
- temporary debug retention;
- system limitation.

---

### 83. Exception Expiry

Expired exception harus:

- otomatis inactive;
- memicu alert;
- memulihkan standard policy;
- diaudit.

---

### 84. Policy Conflict

Jika dua policy overlap:

1. resolve highest-priority policy;
2. record conflict;
3. block destructive action jika ambigu;
4. alert owner;
5. require manual review.

---

### 85. Orphaned Log Stream

Log stream tanpa policy:

```text
ORPHANED
```

Action:

- block purge;
- quarantine archive transition;
- alert owner;
- assign fallback policy only if explicitly configured.

---

### 86. Policy Simulation

Sebelum aktif, policy harus dapat disimulasikan.

Simulation output:

```text
records affected
bytes affected
tier transitions
purge estimate
hold conflicts
exceptions
projected cost
```

---

### 87. Dry Run Purge

Dry run tidak menghapus data.

Output:

- eligible count;
- excluded count;
- hold count;
- estimated storage reclaimed;
- sample identifiers;
- validation errors.

---

### 88. Approval Workflow

Purge approval dapat melibatkan:

- technical owner;
- security;
- compliance;
- legal;
- tenant representative;
- platform operations.

---

### 89. Four-Eyes Principle

Untuk high-risk purge:

```text
requestor != approver
```

---

### 90. Policy Enforcement Modes

```text
MONITOR
WARN
ENFORCE
BLOCK
```

#### MONITOR

Hanya observasi.

#### WARN

Menghasilkan warning.

#### ENFORCE

Menjalankan transition/purge sesuai policy.

#### BLOCK

Menolak operasi yang melanggar policy.

---

### 91. Retention SLA

Framework dapat menetapkan SLA:

```text
archive completed within 24h after eligibility
purge completed within 7d after expiry
legal hold applied within 1h
retrieval available within 4h
```

---

### 92. Retention Breach

Contoh breach:

- expired log belum dipurge;
- log dipurge terlalu cepat;
- hold tidak diterapkan;
- archive missing;
- manifest invalid;
- deletion evidence tidak ada.

---

### 93. Breach Response

- alert;
- incident bila critical;
- stop destructive jobs;
- preserve evidence;
- notify owner;
- compliance review;
- remediation plan.

---

### 94. Metrics

```text
retention_policy_total
retention_policy_conflict_total
archive_batch_total
archive_batch_failure_total
archive_bytes_total
purge_plan_total
purge_batch_total
purge_failure_total
purge_partial_total
legal_hold_active_total
legal_hold_conflict_total
retrieval_request_total
retrieval_failure_total
integrity_check_failure_total
retention_exception_total
orphaned_log_stream_total
```

---

### 95. Dashboard

Widget minimum:

- active legal holds;
- archive backlog;
- purge backlog;
- failed archive batches;
- failed purge batches;
- policy conflicts;
- integrity failures;
- orphaned streams;
- storage by tier;
- retention SLA breaches.

---

### 96. Alert Rules

Contoh:

```text
archive_batch_failed
purge_batch_failed
integrity_check_failed
legal_hold_conflict
orphaned_log_stream
retention_sla_breached
archive_storage_capacity_high
purge_partial_detected
```

---

### 97. Permission Model

```text
observability.log.retention.read
observability.log.retention.manage
observability.log.retention.approve
observability.log.archive.execute
observability.log.archive.verify
observability.log.purge.plan
observability.log.purge.approve
observability.log.purge.execute
observability.log.legal_hold.read
observability.log.legal_hold.manage
observability.log.retrieval.request
observability.log.retrieval.approve
observability.log.retrieval.access
observability.log.integrity.verify
observability.log.exception.manage
```

---

### 98. Audit Events

```text
OBS_RETENTION_POLICY_CREATED
OBS_RETENTION_POLICY_UPDATED
OBS_RETENTION_POLICY_APPROVED
OBS_RETENTION_OVERRIDE_CREATED
OBS_LEGAL_HOLD_CREATED
OBS_LEGAL_HOLD_RELEASED
OBS_ARCHIVE_BATCH_STARTED
OBS_ARCHIVE_BATCH_COMPLETED
OBS_ARCHIVE_BATCH_FAILED
OBS_PURGE_PLAN_CREATED
OBS_PURGE_APPROVED
OBS_PURGE_EXECUTED
OBS_PURGE_VERIFIED
OBS_PURGE_FAILED
OBS_ARCHIVE_RETRIEVAL_REQUESTED
OBS_ARCHIVE_RETRIEVAL_APPROVED
OBS_ARCHIVE_RETRIEVED
OBS_INTEGRITY_FAILURE_DETECTED
OBS_RETENTION_EXCEPTION_CREATED
```

---

### 99. Security Controls

Framework wajib:

- legal hold check sebelum purge;
- four-eyes untuk high-risk purge;
- tenant/scope enforcement;
- no raw SQL from UI;
- signed manifest untuk critical archive;
- encrypted archive;
- restricted retrieval;
- purge evidence immutable;
- exception expiry;
- audit seluruh destructive action.

---

### 100. Anti-Pattern

Hindari:

- retention tanpa owner;
- purge tanpa dry run;
- purge tanpa hold check;
- legal hold tanpa scope;
- legal hold tanpa case reference;
- archive tanpa manifest;
- source deletion sebelum verification;
- exception tanpa expiry;
- direct object deletion manual;
- purge job tanpa idempotency;
- policy overlap ambigu;
- retrieval ke public folder;
- deletion evidence berisi raw log;
- checksum tidak pernah diverifikasi.

---

### 101. UAT Part 2

#### Retention Policy

- [ ] Policy memiliki code unik.
- [ ] Start point valid.
- [ ] Tier duration konsisten.
- [ ] Purge_after valid.
- [ ] Versioning bekerja.
- [ ] Approval workflow bekerja.

#### Legal Hold

- [ ] Hold dapat dibuat.
- [ ] Scope hold valid.
- [ ] Purge terblokir oleh hold.
- [ ] Release membutuhkan approval.
- [ ] Post-release retention dihitung benar.
- [ ] Semua perubahan diaudit.

#### Archive

- [ ] Archive eligibility bekerja.
- [ ] Batch dibuat.
- [ ] Manifest dibuat.
- [ ] Checksum valid.
- [ ] Verification lulus sebelum source deletion.
- [ ] Retry aman dan idempotent.

#### Purge

- [ ] Purge eligibility benar.
- [ ] Dry run bekerja.
- [ ] Approval-required mode bekerja.
- [ ] Partial purge terdeteksi.
- [ ] Verification tersedia.
- [ ] Deletion evidence dibuat.

#### Retrieval

- [ ] Request membutuhkan purpose.
- [ ] Approval diterapkan.
- [ ] Temporary restore terenkripsi.
- [ ] Tenant isolation bekerja.
- [ ] Data auto-expire.
- [ ] Access diaudit.

#### Integrity

- [ ] Hash/checksum dapat diverifikasi.
- [ ] Manifest immutable.
- [ ] Integrity failure memblokir purge.
- [ ] Chain of custody tercatat.
- [ ] Signed manifest tersedia untuk critical archive.

#### Exception

- [ ] Exception memiliki expiry.
- [ ] Compensating control tersedia.
- [ ] Expired exception otomatis inactive.
- [ ] Legal hold tidak dapat dioverride.
- [ ] Conflict menghasilkan block/manual review.

---

### 102. Definition of Done Part 2

Part 2 dianggap selesai bila:

- [ ] RetentionPolicy model tersedia;
- [ ] policy lifecycle tersedia;
- [ ] start point tersedia;
- [ ] tier duration tersedia;
- [ ] override types tersedia;
- [ ] legal hold model tersedia;
- [ ] hold verification tersedia;
- [ ] archive eligibility tersedia;
- [ ] archive batch tersedia;
- [ ] manifest tersedia;
- [ ] checksum tersedia;
- [ ] archive verification tersedia;
- [ ] purge eligibility tersedia;
- [ ] purge plan tersedia;
- [ ] purge modes tersedia;
- [ ] deletion verification tersedia;
- [ ] deletion evidence tersedia;
- [ ] chain of custody tersedia;
- [ ] retrieval workflow tersedia;
- [ ] integrity levels tersedia;
- [ ] exception handling tersedia;
- [ ] dry run/simulation tersedia;
- [ ] permission dan audit tersedia;
- [ ] UAT tersedia.

---

### 103. Rencana Part Berikutnya

#### Part 3

Storage architecture, partitioning, indexing, compression, encryption, archive format, object storage, metadata catalog, retrieval store, disaster recovery, dan performance.

#### Part 4

HTTP API, controllers, middleware, scheduler, database schema, audit integration, security controls, Apache/XAMPP routing, dan sequence diagram.

#### Part 5

Reference implementation, sample policies, migration, deployment, rollback, retention simulation, final UAT, Definition of Done, roadmap, dan merge guidance.

---

## Bagian III — Storage Architecture, Partitioning, Indexing, Compression, Encryption, Archive Format & Disaster Recovery

### 1. Executive Summary

Part 3 mendefinisikan arsitektur penyimpanan untuk lifecycle log dari HOT sampai ARCHIVE.

Bagian ini menetapkan:

- storage topology;
- active store;
- warm store;
- cold store;
- archive store;
- metadata catalog;
- partitioning;
- indexing;
- compression;
- encryption;
- key management;
- archive format;
- object naming;
- manifest;
- retrieval store;
- cache;
- disaster recovery;
- backup;
- restore;
- capacity planning;
- performance target;
- UAT.

Tujuan utama arsitektur ini adalah memastikan log:

- dapat ditulis secara efisien;
- dapat dicari sesuai kebutuhan;
- tidak membebani database transaksi;
- dapat dipindahkan antar storage tier;
- tetap terenkripsi;
- dapat diverifikasi integritasnya;
- dapat dipulihkan;
- dapat dipurge sesuai policy;
- tetap tenant-aware dan scope-aware.

---

### 2. Storage Architecture Principles

#### 2.1 Separate Operational and Transactional Storage

Log observability tidak boleh menjadi beban utama database transaksi bisnis.

#### 2.2 Tiered Storage

Gunakan storage sesuai frekuensi akses dan nilai data.

#### 2.3 Metadata Before Payload

Metadata catalog harus tetap tersedia walaupun payload berada di archive.

#### 2.4 Immutable Where Required

Audit, security, legal hold, dan evidence membutuhkan storage dengan kontrol lebih kuat.

#### 2.5 Bounded Query

Query log harus selalu dibatasi oleh:

- waktu;
- tenant;
- scope;
- stream;
- size;
- pagination.

#### 2.6 Encryption by Default

Semua storage tier harus dienkripsi sesuai sensitivity.

#### 2.7 Recoverability

Archive tanpa kemampuan restore bukan archive yang dapat dioperasikan.

#### 2.8 Storage Independence

Domain tidak boleh bergantung pada satu vendor storage.

---

### 3. High-Level Topology

```text
Log Producers
    │
    ▼
Ingestion Pipeline
    │
    ├── Normalize
    ├── Sanitize
    ├── Classify
    ├── Enrich Context
    └── Validate Schema
    │
    ▼
HOT Store
    │
    ├── Search Index
    ├── Active Metadata
    └── Short-Term Retention
    │
    ▼
WARM Store
    │
    ├── Compressed Partitions
    ├── Reduced Index
    └── Medium-Term Retention
    │
    ▼
COLD Store
    │
    ├── Immutable Batches
    ├── Minimal Search Metadata
    └── Low-Frequency Access
    │
    ▼
ARCHIVE Store
    │
    ├── Encrypted Objects
    ├── Signed Manifest
    ├── Integrity Proof
    └── Long-Term Retention
```

---

### 4. Core Storage Components

```text
LogIngestionStore
HotLogStore
WarmLogStore
ColdLogStore
ArchiveObjectStore
ArchiveMetadataCatalog
RetrievalWorkspace
IntegrityStore
KeyManagementService
RetentionIndex
```

---

### 5. HOT Store

HOT store digunakan untuk:

- active troubleshooting;
- recent incident;
- dashboard;
- live search;
- short-term correlation.

Karakteristik:

- low-latency;
- indexed;
- high write throughput;
- bounded retention;
- higher cost.

---

### 6. WARM Store

WARM store digunakan untuk:

- historical search;
- incident follow-up;
- audit sampling;
- trend verification.

Karakteristik:

- compressed;
- fewer indexes;
- slower query;
- lower cost.

---

### 7. COLD Store

COLD store digunakan untuk:

- infrequent retrieval;
- long retention sebelum archive;
- historical investigation.

Karakteristik:

- object/file based;
- minimal live indexing;
- high compression;
- restore required for detailed query.

---

### 8. ARCHIVE Store

ARCHIVE store digunakan untuk:

- regulated retention;
- legal hold;
- immutable evidence;
- long-term preservation.

Karakteristik:

- encrypted object;
- signed manifest;
- restricted access;
- retrieval workflow;
- optional WORM.

---

### 9. Metadata Catalog

Metadata catalog menyimpan informasi tanpa harus membuka archive payload.

Field minimum:

```text
archive_object_id
batch_id
log_stream
tenant_id
scope_id
time_range
record_count
byte_size
schema_version
compression
encryption_key_reference
checksum
manifest_reference
storage_location
retention_end
legal_hold_status
integrity_status
```

---

### 10. Storage Boundary

Domain application hanya mengetahui interface.

Contoh:

```php
interface LogStorageInterface
{
    public function append(
        LogRecordBatch $batch
    ): LogStorageWriteResult;

    public function search(
        LogSearchCriteria $criteria
    ): LogSearchPage;

    public function export(
        LogExportCriteria $criteria
    ): LogExportReference;
}
```

---

### 11. Archive Object Store Contract

```php
interface ArchiveObjectStoreInterface
{
    public function put(
        ArchiveObject $object,
        ArchiveWriteContext $context
    ): ArchiveObjectReference;

    public function get(
        ArchiveObjectReference $reference,
        ArchiveReadContext $context
    ): ArchiveObjectStream;

    public function exists(
        ArchiveObjectReference $reference
    ): bool;

    public function delete(
        ArchiveObjectReference $reference,
        ArchiveDeleteContext $context
    ): void;
}
```

---

### 12. Metadata Catalog Contract

```php
interface ArchiveMetadataCatalogInterface
{
    public function register(
        ArchiveCatalogEntry $entry
    ): void;

    public function find(
        ArchiveSearchCriteria $criteria
    ): ArchiveCatalogPage;

    public function updateIntegrityStatus(
        string $archiveObjectId,
        string $status
    ): void;

    public function markPurged(
        string $archiveObjectId,
        \DateTimeImmutable $purgedAt
    ): void;
}
```

---

### 13. Storage Selection

Storage tier ditentukan oleh:

```text
retention policy
log age
sensitivity
criticality
query frequency
volume
cost
integrity requirement
legal hold
```

---

### 14. Recommended Initial Architecture

Untuk implementasi awal berbasis PHP/XAMPP:

```text
HOT:
MySQL partitioned log tables

WARM:
MySQL compressed/archive tables atau file batch terkompresi

COLD:
Filesystem/object-compatible storage

ARCHIVE:
Encrypted object storage + manifest catalog in MySQL
```

---

### 15. Production Evolution

Untuk skala lebih besar:

```text
HOT:
dedicated search/log platform

WARM:
lower-cost search tier

COLD:
object storage

ARCHIVE:
immutable/WORM object storage
```

Domain contract tetap sama.

---

### 16. MySQL as HOT Store

MySQL dapat digunakan untuk fase awal bila:

- volume terkendali;
- retention pendek;
- partitioning diterapkan;
- write path dibatasi;
- index terukur;
- archive berjalan rutin.

---

### 17. Avoid Transaction DB Coupling

Hindari menyimpan seluruh log pada schema transaksi utama tanpa:

- table partitioning;
- separate connection;
- separate storage quota;
- maintenance policy;
- archive job.

---

### 18. Separate Database Connection

Konfigurasi:

```php
return [
    'observability' => [
        'dsn' => getenv('OBSERVABILITY_DB_DSN'),
        'username' => getenv('OBSERVABILITY_DB_USERNAME'),
        'password' => getenv('OBSERVABILITY_DB_PASSWORD'),
    ],
];
```

---

### 19. Partitioning Strategy

Partitioning utama:

```text
TIME
TENANT
STREAM
HYBRID
```

---

### 20. Time Partitioning

Direkomendasikan untuk volume tinggi.

Contoh:

```text
daily partition
weekly partition
monthly partition
```

Pemilihan tergantung:

- volume;
- purge frequency;
- query range;
- operational complexity.

---

### 21. Daily Partition

Cocok untuk:

- high-volume access log;
- debug;
- event-heavy stream.

Kelebihan:

- purge cepat;
- bounded partition size.

Kekurangan:

- banyak partition;
- metadata management lebih kompleks.

---

### 22. Monthly Partition

Cocok untuk:

- audit;
- incident;
- moderate-volume application log.

Kelebihan:

- lebih sederhana;
- lebih sedikit partition.

Kekurangan:

- purge kurang granular.

---

### 23. Tenant Partitioning

Physical tenant partitioning hanya digunakan bila:

- contractual isolation;
- regulated tenant;
- very large tenant;
- operational necessity.

Jangan membuat partition per tenant tanpa kebutuhan karena jumlah partition dapat meledak.

---

### 24. Hybrid Partitioning

Contoh:

```text
partition by month
subpartition/hash by tenant
```

Gunakan hanya jika didukung dan benar-benar dibutuhkan.

---

### 25. Partition Naming

Format:

```text
p2026_07
p2026_07_04
```

Nama harus deterministic.

---

### 26. Partition Lifecycle

```text
CREATE AHEAD
ACTIVE
READ_ONLY
ARCHIVED
DROPPED
```

---

### 27. Create-Ahead Policy

Partition harus dibuat sebelum periode aktif.

Contoh:

```text
create next 3 monthly partitions
```

---

### 28. Partition Guard

Jika partition target tidak ada:

- jangan tulis ke default catch-all tanpa alert;
- gunakan fallback terkontrol;
- create alert;
- log configuration defect.

---

### 29. Partition Drop

Partition hanya boleh di-drop bila:

- retention expired;
- archive verified;
- no legal hold;
- purge plan approved;
- deletion evidence siap.

---

### 30. Sample Partitioned Table

```sql
CREATE TABLE observability_logs (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    occurred_at DATETIME(6) NOT NULL,
    event_code VARCHAR(120) NOT NULL,
    log_level VARCHAR(20) NOT NULL,
    domain_code VARCHAR(50) NOT NULL,
    environment VARCHAR(32) NOT NULL,
    tenant_id BIGINT UNSIGNED NULL,
    scope_id BIGINT UNSIGNED NULL,
    module_code VARCHAR(100) NULL,
    correlation_id VARCHAR(64) NULL,
    trace_id VARCHAR(64) NULL,
    classification VARCHAR(30) NOT NULL,
    message VARCHAR(2000) NOT NULL,
    context_json JSON NULL,
    schema_version VARCHAR(20) NOT NULL,
    created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),

    PRIMARY KEY (id, occurred_at),
    KEY idx_logs_time_stream (
        occurred_at,
        domain_code,
        event_code
    ),
    KEY idx_logs_tenant_time (
        tenant_id,
        scope_id,
        occurred_at
    ),
    KEY idx_logs_correlation (
        correlation_id,
        occurred_at
    )
)
PARTITION BY RANGE COLUMNS (occurred_at) (
    PARTITION p2026_07 VALUES LESS THAN ('2026-08-01'),
    PARTITION p2026_08 VALUES LESS THAN ('2026-09-01'),
    PARTITION pmax VALUES LESS THAN (MAXVALUE)
);
```

---

### 31. Catch-All Partition

`pmax` dapat digunakan sementara.

Namun wajib ada monitor agar data tidak menumpuk tanpa partition lifecycle.

---

### 32. Indexing Principles

Index harus mendukung query nyata.

Jangan mengindeks semua field.

---

### 33. Core Indexes

Direkomendasikan:

```text
occurred_at
tenant_id + occurred_at
scope_id + occurred_at
event_code + occurred_at
domain_code + occurred_at
correlation_id + occurred_at
trace_id + occurred_at
classification + occurred_at
```

---

### 34. Composite Index Ordering

Filter paling selektif dan paling sering digunakan berada lebih awal.

Contoh:

```text
tenant_id, scope_id, occurred_at
```

---

### 35. Search Fields

Structured field lebih baik daripada full-text message.

Prioritaskan:

- event_code;
- correlation_id;
- actor reference;
- resource reference;
- module;
- tenant;
- timestamp.

---

### 36. Full-Text Search

Full-text dapat digunakan untuk message yang disanitasi.

Jangan mengandalkan full-text untuk semua investigasi.

---

### 37. JSON Indexing

Jangan menyimpan seluruh field penting hanya di JSON.

Promosikan field yang sering difilter menjadi kolom.

---

### 38. Index Lifecycle

HOT memiliki index lebih banyak.

WARM dapat mengurangi:

- full-text;
- secondary index;
- low-value dimension.

---

### 39. Index Cost Monitoring

Metric:

```text
index_size_bytes
index_write_latency
query_scan_rows
query_latency_ms
unused_index_total
```

---

### 40. Compression Principles

Compression mengurangi biaya storage dan transfer.

Trade-off:

```text
CPU
latency
compression ratio
restore speed
```

---

### 41. Compression Levels

```text
NONE
FAST
BALANCED
MAXIMUM
```

---

### 42. Recommended Compression

```text
HOT: NONE/FAST
WARM: BALANCED
COLD: BALANCED/MAXIMUM
ARCHIVE: MAXIMUM
```

---

### 43. Archive Compression Algorithms

Supported candidate:

```text
gzip
zstd
```

Zstandard direkomendasikan untuk balance compression dan decompression bila tersedia.

---

### 44. Compression Metadata

Manifest wajib mencatat:

```text
algorithm
level
uncompressed_size
compressed_size
```

---

### 45. Compression Bomb Protection

Retrieval harus membatasi:

- maximum decompressed size;
- compression ratio;
- object count;
- extraction path.

---

### 46. Archive Format

Archive format harus:

- deterministic;
- streamable;
- versioned;
- self-describing;
- integrity-verifiable.

---

### 47. Recommended Archive Layout

```text
archive-batch/
├── manifest.json
├── records-00001.ndjson.zst
├── records-00002.ndjson.zst
└── checksums.sha256
```

---

### 48. NDJSON

NDJSON cocok karena:

- streamable;
- line-oriented;
- sederhana;
- schema-friendly;
- mudah diverifikasi.

---

### 49. Archive Record

```json
{
  "occurred_at": "2026-07-04T12:00:00Z",
  "event_code": "DB_CONNECTION_FAILED",
  "level": "ERROR",
  "domain": "APPLICATION",
  "environment": "production",
  "tenant_id": 10,
  "scope_id": 5,
  "module_code": "appointment",
  "correlation_id": "01J...",
  "classification": "CONFIDENTIAL",
  "message": "Database connection failed.",
  "context": {
    "error_code": "DB_TIMEOUT"
  },
  "schema_version": "1.0"
}
```

---

### 50. Archive Canonicalization

Sebelum hashing:

- UTF-8;
- normalized newline;
- stable field order;
- ISO 8601 UTC timestamp;
- no transient whitespace;
- explicit schema version.

---

### 51. Archive Object Naming

Format rekomendasi:

```text
logs/{environment}/{stream}/{yyyy}/{mm}/{dd}/{batch_id}/records-00001.ndjson.zst
```

---

### 52. Object Naming Safety

Object key tidak boleh berisi:

- patient name;
- email;
- raw tenant name;
- user identity;
- secret;
- case detail sensitif.

Gunakan identifier internal.

---

### 53. Object Size

Rekomendasi awal:

```text
100 MB–1 GB compressed per object
```

Tergantung:

- provider limits;
- retrieval pattern;
- upload reliability;
- restore time.

---

### 54. Small Object Problem

Terlalu banyak object kecil menyebabkan:

- biaya metadata;
- listing lambat;
- retrieval kompleks.

Gunakan batching.

---

### 55. Large Object Problem

Object terlalu besar menyebabkan:

- retry mahal;
- restore lambat;
- partial retrieval sulit.

Gunakan bounded chunk size.

---

### 56. Encryption in Transit

Wajib:

- TLS;
- certificate validation;
- no plaintext object upload;
- secure internal connection.

---

### 57. Encryption at Rest

Storage tier wajib memakai encryption at rest.

---

### 58. Envelope Encryption

Model:

```text
Data Encryption Key
encrypted by
Key Encryption Key
```

---

### 59. Key References

Archive metadata hanya menyimpan:

```text
key_reference
key_version
algorithm
```

Bukan raw key.

---

### 60. Encryption Algorithms

Rekomendasi:

```text
AES-256-GCM
```

atau algorithm approved organisasi.

---

### 61. Per-Tenant Key

Per-tenant key dapat dipertimbangkan untuk:

- regulated tenant;
- cryptographic erasure;
- contractual isolation.

---

### 62. Per-Batch Key

Per-batch key meningkatkan granularitas erasure tetapi meningkatkan kompleksitas.

---

### 63. Key Rotation

Key rotation harus mendukung:

- new write with new key;
- old object decrypt;
- re-encryption schedule;
- audit;
- key retirement.

---

### 64. Key Destruction

Key destruction hanya boleh dilakukan jika:

- retention expired;
- no legal hold;
- all object references known;
- approval valid;
- destruction evidence dibuat.

---

### 65. Key Availability

Archive tidak dapat direstore jika key hilang.

Key backup dan recovery harus diuji.

---

### 66. Secrets Management

Jangan simpan:

- access key;
- encryption key;
- provider secret;

di repository atau database plaintext.

---

### 67. Metadata Catalog Schema

```sql
CREATE TABLE log_archive_objects (
    id CHAR(26) NOT NULL,
    batch_id CHAR(26) NOT NULL,
    log_stream_code VARCHAR(150) NOT NULL,
    environment VARCHAR(32) NOT NULL,
    tenant_id BIGINT UNSIGNED NULL,
    scope_id BIGINT UNSIGNED NULL,
    range_start DATETIME(6) NOT NULL,
    range_end DATETIME(6) NOT NULL,
    record_count BIGINT UNSIGNED NOT NULL,
    uncompressed_bytes BIGINT UNSIGNED NOT NULL,
    compressed_bytes BIGINT UNSIGNED NOT NULL,
    object_key VARCHAR(1000) NOT NULL,
    storage_class VARCHAR(30) NOT NULL,
    compression_algorithm VARCHAR(30) NOT NULL,
    encryption_algorithm VARCHAR(50) NOT NULL,
    encryption_key_reference VARCHAR(255) NOT NULL,
    checksum_algorithm VARCHAR(30) NOT NULL,
    checksum_value VARCHAR(256) NOT NULL,
    manifest_reference VARCHAR(1000) NOT NULL,
    schema_version VARCHAR(20) NOT NULL,
    retention_end_at DATETIME(6) NOT NULL,
    legal_hold_status VARCHAR(30) NOT NULL DEFAULT 'NONE',
    integrity_status VARCHAR(30) NOT NULL DEFAULT 'PENDING',
    archived_at DATETIME(6) NOT NULL,
    purged_at DATETIME(6) NULL,
    created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),

    PRIMARY KEY (id),
    UNIQUE KEY uq_archive_object_key (object_key),
    KEY idx_archive_stream_time (
        log_stream_code,
        range_start,
        range_end
    ),
    KEY idx_archive_scope (
        tenant_id,
        scope_id,
        range_start
    ),
    KEY idx_archive_retention (
        retention_end_at,
        legal_hold_status,
        purged_at
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

### 68. Archive Batch Schema

```sql
CREATE TABLE log_archive_batches (
    id CHAR(26) NOT NULL,
    policy_code VARCHAR(150) NOT NULL,
    log_stream_code VARCHAR(150) NOT NULL,
    environment VARCHAR(32) NOT NULL,
    tenant_id BIGINT UNSIGNED NULL,
    scope_id BIGINT UNSIGNED NULL,
    range_start DATETIME(6) NOT NULL,
    range_end DATETIME(6) NOT NULL,
    status VARCHAR(30) NOT NULL,
    record_count BIGINT UNSIGNED NOT NULL DEFAULT 0,
    object_count INT UNSIGNED NOT NULL DEFAULT 0,
    source_deleted TINYINT(1) NOT NULL DEFAULT 0,
    verification_status VARCHAR(30) NOT NULL DEFAULT 'PENDING',
    error_code VARCHAR(100) NULL,
    error_message VARCHAR(1000) NULL,
    started_at DATETIME(6) NOT NULL,
    completed_at DATETIME(6) NULL,
    created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),

    PRIMARY KEY (id),
    KEY idx_archive_batch_status (
        status,
        started_at
    ),
    KEY idx_archive_batch_scope (
        log_stream_code,
        tenant_id,
        scope_id,
        range_start
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

### 69. Metadata Catalog Search

Search harus mendukung:

```text
stream
tenant
scope
time range
storage class
legal hold
integrity status
retention end
```

---

### 70. Metadata Catalog Availability

Catalog sebaiknya memiliki availability lebih tinggi daripada archive payload.

---

### 71. Retrieval Workspace

Retrieval workspace adalah temporary store untuk membuka archive.

Lifecycle:

```text
REQUESTED
→ RESTORING
→ INDEXING
→ AVAILABLE
→ EXPIRED
→ PURGED
```

---

### 72. Retrieval Workspace Requirements

- isolated;
- encrypted;
- temporary;
- bounded;
- access-controlled;
- tenant-aware;
- auto-expire;
- audited.

---

### 73. Retrieval Workspace Schema

```text
workspace_id
request_id
requestor
scope
classification
storage_location
expires_at
status
created_at
purged_at
```

---

### 74. Retrieval Process

```text
Resolve catalog
→ Authorize
→ Fetch archive objects
→ Verify checksum
→ Decrypt
→ Decompress
→ Validate schema
→ Load temporary index
→ Grant bounded access
```

---

### 75. Retrieval Failure

Jika gagal:

- no partial public access;
- workspace isolated;
- status FAILED;
- evidence dicatat;
- temporary data dipurge;
- owner diberi alert.

---

### 76. Cache

Metadata query dapat dicache.

Payload archive tidak dicache secara global.

---

### 77. Cache Key

Harus mencakup:

```text
tenant
scope
permission context
classification
query
time range
```

---

### 78. Cache Invalidation

Invalidate ketika:

- legal hold berubah;
- object purged;
- integrity status berubah;
- classification berubah;
- permission berubah.

---

### 79. Storage Quota

Quota dapat ditentukan per:

```text
environment
tenant
stream
storage tier
```

---

### 80. Quota Actions

Jika mendekati limit:

- warning;
- archive acceleration;
- sampling review;
- capacity expansion;
- retention policy review.

Jangan langsung purge di luar policy.

---

### 81. Capacity Planning

Formula dasar:

```text
daily volume
× retention days
× compression ratio
× replication factor
× growth factor
```

---

### 82. Growth Factor

Gunakan buffer:

```text
1.2–2.0
```

tergantung variability.

---

### 83. Capacity Metrics

```text
storage_used_bytes
storage_available_bytes
storage_growth_bytes_per_day
archive_compression_ratio
partition_size_bytes
object_count
retrieval_workspace_bytes
```

---

### 84. Storage Alert Thresholds

Contoh:

| Threshold | Severity |
|---|---|
| 70% | SEV4 |
| 80% | SEV3 |
| 90% | SEV2 |
| 95% | SEV1 |

Final configurable.

---

### 85. Query Architecture

Search flow:

```text
Query Request
→ Authorization
→ Scope Resolution
→ Tier Planner
→ HOT/WARM Search
→ Catalog Search
→ Archive Retrieval if Needed
→ Merge Result Metadata
```

---

### 86. Tier Planner

Tier planner menentukan data berada di mana berdasarkan:

- requested time range;
- stream policy;
- archive metadata;
- purge status.

---

### 87. Search Pagination

Gunakan cursor pagination untuk volume besar.

Hindari deep offset.

---

### 88. Query Limits

Wajib:

```text
maximum time range
maximum rows
maximum bytes
timeout
maximum archive objects
```

---

### 89. Expensive Query Protection

Jika query terlalu luas:

- reject;
- require export workflow;
- require approval;
- queue async retrieval.

---

### 90. Search Projection

Return only needed fields.

Jangan selalu return full context payload.

---

### 91. Performance Target

| Operation | Target |
|---|---:|
| HOT append batch | < 500 ms |
| HOT bounded search | < 1 s |
| WARM search | < 3 s |
| Metadata catalog search | < 500 ms |
| Archive plan | < 1 s |
| Archive retrieval start | < 5 s |
| Integrity verification per object | throughput-based |
| Partition maintenance | bounded window |

---

### 92. Write Batching

Gunakan batch insert untuk throughput.

Contoh:

```text
100–1000 records per batch
```

tergantung event size.

---

### 93. Write Idempotency

Gunakan:

```text
event_id
producer_id
sequence
```

jika duplicate tidak dapat diterima.

---

### 94. Backpressure

Jika ingestion lebih cepat daripada storage:

- queue;
- bounded buffer;
- rate limit;
- drop policy hanya untuk non-critical;
- alert;
- preserve audit/security priority.

---

### 95. Priority Classes

```text
P0_AUDIT_SECURITY
P1_INCIDENT_ERROR
P2_OPERATIONAL
P3_INFO
P4_DEBUG
```

---

### 96. Drop Policy

Tidak boleh drop:

- audit;
- security-critical;
- legal hold;
- incident timeline.

Debug/info dapat disampling atau didrop secara terkontrol.

---

### 97. Storage Health

Health checks:

```text
write test
read test
catalog test
object existence test
key access test
integrity sample
capacity check
```

---

### 98. Backup Strategy

Backup mencakup:

- metadata catalog;
- policy;
- legal hold;
- manifest;
- key metadata;
- retrieval requests;
- archive configuration.

Payload archive dapat direplikasi terpisah.

---

### 99. Backup Frequency

Contoh:

| Data | Frequency |
|---|---:|
| Policy/catalog DB | daily + binlog |
| Legal hold | near-real-time |
| Manifest | per archive batch |
| Archive objects | replication |
| Keys metadata | secure backup |
| Retrieval workspace | tidak perlu long-term |

---

### 100. Restore Priority

```text
1. Key management access
2. Legal hold records
3. Metadata catalog
4. Retention policy
5. Archive manifests
6. Archive objects
7. Search indexes
```

---

### 101. Disaster Recovery Objectives

Define:

```text
RPO
RTO
```

---

### 102. RPO

Recommended initial:

```text
catalog/policy: 15 minutes–24 hours
archive object: zero after confirmed upload
legal hold: near-zero
```

---

### 103. RTO

Recommended initial:

```text
catalog: 4 hours
archive retrieval: 8–24 hours
critical legal hold access: 4 hours
```

---

### 104. Archive Replication

Archive object dapat direplikasi:

- cross-disk;
- cross-zone;
- cross-region;
- offline copy.

Harus mempertimbangkan data residency.

---

### 105. DR Site

DR site harus memiliki:

- catalog restore;
- key access;
- manifest access;
- object access;
- documented retrieval procedure.

---

### 106. Restore Test

Restore test wajib berkala.

Test:

- sample object;
- checksum;
- decrypt;
- decompress;
- schema validate;
- query;
- cleanup.

---

### 107. Restore Frequency

Contoh:

```text
monthly sample restore
quarterly full workflow test
annual DR exercise
```

---

### 108. Corrupted Archive

Jika archive corrupt:

- mark SUSPECT;
- block purge source jika masih ada;
- use replica;
- create incident;
- preserve evidence;
- rebuild if possible.

---

### 109. Lost Encryption Key

Jika key hilang:

- archive dianggap unavailable;
- create critical incident;
- investigate backup/escrow;
- notify compliance/legal if required;
- do not silently purge catalog.

---

### 110. Schema Evolution

Archive record memiliki schema version.

Retrieval harus mendukung:

- current schema;
- backward-compatible reader;
- migration adapter;
- rejection with clear error.

---

### 111. Schema Registry

Schema registry menyimpan:

```text
stream_code
schema_version
field definitions
classification
effective date
compatibility
```

---

### 112. Compatibility Modes

```text
BACKWARD
FORWARD
FULL
NONE
```

---

### 113. Archive Repack

Archive repack dapat dilakukan untuk:

- better compression;
- schema normalization;
- encryption rotation.

Wajib:

- preserve original integrity evidence;
- create new manifest;
- audit;
- no data loss.

---

### 114. Re-Encryption

Process:

```text
retrieve
verify
decrypt old key
encrypt new key
write new object
verify
switch catalog reference
retire old object
```

---

### 115. Storage Migration

Migrasi provider/storage harus:

- dual-write atau copy-verify;
- checksum;
- manifest update;
- rollback;
- no premature delete;
- legal hold aware.

---

### 116. File System Storage for Local/XAMPP

Untuk local development:

```text
storage/log-archive/
```

Production tidak boleh memakai public web directory.

---

### 117. Local Archive Layout

```text
storage/
└── log-archive/
    ├── manifests/
    ├── objects/
    ├── quarantine/
    └── retrieval/
```

---

### 118. Filesystem Permissions

- web user hanya akses minimum;
- no directory listing;
- archive tidak berada di `public/`;
- key terpisah;
- restricted ACL.

---

### 119. Apache Protection

```apache
<Directory "D:/xampp/htdocs/platform/storage/log-archive">
    Require all denied
    Options -Indexes
</Directory>
```

---

### 120. Quarantine Store

Quarantine untuk:

- malformed archive;
- checksum mismatch;
- unknown schema;
- failed decrypt;
- unsafe object.

---

### 121. Quarantine Rules

- no general search;
- restricted access;
- bounded retention;
- investigation required;
- no purge source until resolved.

---

### 122. Quarantine Metrics

```text
archive_quarantine_total
archive_quarantine_bytes
archive_quarantine_age_seconds
```

---

### 123. Observability

Metrics minimum:

```text
log_storage_write_total
log_storage_write_failure_total
log_storage_query_total
log_storage_query_latency_ms
log_partition_total
log_partition_create_failure_total
log_archive_object_total
log_archive_bytes_total
log_archive_compression_ratio
log_archive_integrity_failure_total
log_retrieval_workspace_total
log_retrieval_failure_total
log_key_access_failure_total
log_storage_capacity_percent
```

---

### 124. Structured Logging

```json
{
  "event": "log_archive_object_created",
  "batch_id": "01J...",
  "stream": "platform_application_error",
  "record_count": 125000,
  "compressed_bytes": 8742231,
  "compression": "zstd",
  "encryption": "AES-256-GCM",
  "integrity_status": "VERIFIED"
}
```

---

### 125. Alert Rules

```text
log_storage_write_failed
log_partition_missing
log_archive_object_failed
log_archive_integrity_failed
log_encryption_key_unavailable
log_retrieval_failed
log_storage_capacity_high
log_backup_failed
log_restore_test_failed
```

---

### 126. Permission Model

```text
observability.log.storage.read
observability.log.storage.manage
observability.log.archive.catalog.read
observability.log.archive.object.read
observability.log.archive.object.manage
observability.log.archive.retrieve
observability.log.archive.reencrypt
observability.log.partition.manage
observability.log.integrity.verify
observability.log.key.reference.read
observability.log.dr.execute
```

---

### 127. Audit Events

```text
OBS_LOG_ARCHIVE_OBJECT_CREATED
OBS_LOG_ARCHIVE_OBJECT_VERIFIED
OBS_LOG_ARCHIVE_OBJECT_RETRIEVED
OBS_LOG_ARCHIVE_OBJECT_REENCRYPTED
OBS_LOG_ARCHIVE_OBJECT_MOVED
OBS_LOG_ARCHIVE_OBJECT_PURGED
OBS_LOG_PARTITION_CREATED
OBS_LOG_PARTITION_DROPPED
OBS_LOG_RETRIEVAL_WORKSPACE_CREATED
OBS_LOG_RETRIEVAL_WORKSPACE_PURGED
OBS_LOG_DR_RESTORE_EXECUTED
OBS_LOG_KEY_REFERENCE_CHANGED
```

---

### 128. Security Controls

Framework wajib:

- no public archive path;
- encryption in transit;
- encryption at rest;
- key separation;
- tenant/scope filter;
- signed manifest for critical archive;
- checksum verification;
- bounded retrieval;
- restricted workspace;
- access audit;
- no raw key in metadata;
- no sensitive identity in object name.

---

### 129. Anti-Pattern

Hindari:

- seluruh log di database transaksi;
- no partitioning untuk high-volume table;
- semua field di-index;
- archive tanpa catalog;
- archive tanpa manifest;
- object kecil dalam jumlah ekstrem;
- one giant archive object;
- plaintext archive;
- key disimpan di source code;
- restore tidak pernah diuji;
- retrieval workspace tanpa expiry;
- pmax partition dibiarkan tanpa monitor;
- drop partition tanpa hold check;
- archive di folder public.

---

### 130. UAT Part 3

#### Storage Tier

- [ ] HOT store menerima batch.
- [ ] WARM transition bekerja.
- [ ] COLD transition bekerja.
- [ ] ARCHIVE object dibuat.
- [ ] Catalog entry dibuat.
- [ ] Tier planner mengembalikan lokasi benar.

#### Partitioning

- [ ] Partition dibuat sebelum periode aktif.
- [ ] Query menggunakan partition pruning.
- [ ] Missing partition menghasilkan alert.
- [ ] Partition drop diblokir oleh legal hold.
- [ ] Partition lifecycle diaudit.

#### Indexing

- [ ] Query utama memakai index.
- [ ] Tenant/time index bekerja.
- [ ] Correlation search bekerja.
- [ ] Deep offset tidak digunakan.
- [ ] Unused index dapat diidentifikasi.

#### Compression

- [ ] Archive terkompresi.
- [ ] Compression metadata tersimpan.
- [ ] Decompression size dibatasi.
- [ ] Compression ratio tercatat.
- [ ] Object dapat direstore.

#### Encryption

- [ ] Object terenkripsi.
- [ ] Key reference tersimpan.
- [ ] Raw key tidak tersimpan.
- [ ] Rotation bekerja.
- [ ] Lost key menghasilkan alert/incident.

#### Archive Format

- [ ] NDJSON valid.
- [ ] Manifest valid.
- [ ] Checksum valid.
- [ ] Object naming aman.
- [ ] Schema version tersedia.
- [ ] Canonicalization konsisten.

#### Retrieval

- [ ] Catalog search bekerja.
- [ ] Workspace isolated.
- [ ] Checksum diverifikasi.
- [ ] Decrypt dan decompress berhasil.
- [ ] Workspace auto-expire.
- [ ] Tenant isolation bekerja.

#### Disaster Recovery

- [ ] Catalog dapat direstore.
- [ ] Key access dapat dipulihkan.
- [ ] Sample archive dapat direstore.
- [ ] Replica digunakan saat primary corrupt.
- [ ] Restore evidence tercatat.
- [ ] RPO/RTO diuji.

#### Performance

- [ ] Batch write memenuhi target.
- [ ] HOT search memenuhi target.
- [ ] Catalog search memenuhi target.
- [ ] Archive object size sesuai policy.
- [ ] Storage capacity alert bekerja.
- [ ] Backpressure melindungi critical logs.

---

### 131. Definition of Done Part 3

Part 3 dianggap selesai bila:

- [ ] storage topology tersedia;
- [ ] HOT/WARM/COLD/ARCHIVE definition tersedia;
- [ ] storage contracts tersedia;
- [ ] partitioning strategy tersedia;
- [ ] partition lifecycle tersedia;
- [ ] indexing policy tersedia;
- [ ] compression policy tersedia;
- [ ] archive format tersedia;
- [ ] object naming tersedia;
- [ ] encryption policy tersedia;
- [ ] key rotation tersedia;
- [ ] metadata catalog tersedia;
- [ ] retrieval workspace tersedia;
- [ ] capacity planning tersedia;
- [ ] performance target tersedia;
- [ ] backup strategy tersedia;
- [ ] RPO/RTO tersedia;
- [ ] restore test tersedia;
- [ ] schema evolution tersedia;
- [ ] local/XAMPP storage guidance tersedia;
- [ ] security controls tersedia;
- [ ] UAT tersedia.

---

### 132. Rencana Part Berikutnya

#### Part 4

HTTP API, controllers, middleware, scheduler, database schema, audit integration, retention jobs, security controls, Apache/XAMPP routing, dan sequence diagram.

#### Part 5

Reference implementation, sample policies, migration, deployment, rollback, retention simulation, final UAT, Definition of Done, roadmap, dan merge guidance.

---

## Bagian IV — HTTP API, Controllers, Middleware, Scheduler, Database Schema, Audit & Routing

### 1. Executive Summary

Part 4 mendefinisikan interface dan infrastructure untuk Log Retention & Archiving Framework.

Bagian ini menetapkan:

- HTTP API;
- controller responsibilities;
- request/response contracts;
- middleware order;
- permission;
- tenant/scope isolation;
- scheduler jobs;
- retention evaluator;
- archive processor;
- purge processor;
- legal hold service;
- retrieval service;
- database schema;
- audit integration;
- error codes;
- Apache/XAMPP routing;
- sequence diagram;
- UAT.

Tujuan utama adalah memastikan retention dan archiving dapat:

- dikonfigurasi secara konsisten;
- dijalankan secara terjadwal;
- diaudit;
- diakses secara aman;
- memblokir purge bila legal hold aktif;
- menyediakan retrieval terkontrol;
- menjaga tenant dan scope isolation;
- menghasilkan evidence untuk archive dan purge.

---

### 2. API Architecture

```text
HTTP Request
    │
    ▼
Security Middleware
    │
    ├── Authentication
    ├── Tenant Context
    ├── Active Scope
    ├── Permission
    ├── Classification
    └── Audit Context
    │
    ▼
Controller
    │
    ▼
Application Service
    │
    ├── Retention Policy Service
    ├── Legal Hold Service
    ├── Archive Service
    ├── Purge Service
    ├── Retrieval Service
    └── Integrity Service
    │
    ▼
Repositories / Storage Adapters
```

---

### 3. Base API Paths

```text
/api/internal/v1/log-retention
/api/internal/v1/log-archives
/api/internal/v1/log-purge
/api/internal/v1/log-legal-holds
/api/internal/v1/log-retrievals
/api/internal/v1/log-integrity
```

Semua endpoint bersifat internal dan wajib authentication.

---

### 4. Retention Policy API

```text
GET    /api/internal/v1/log-retention/policies
GET    /api/internal/v1/log-retention/policies/{policyCode}
POST   /api/internal/v1/log-retention/policies
PUT    /api/internal/v1/log-retention/policies/{policyCode}
POST   /api/internal/v1/log-retention/policies/{policyCode}/approve
POST   /api/internal/v1/log-retention/policies/{policyCode}/activate
POST   /api/internal/v1/log-retention/policies/{policyCode}/suspend
POST   /api/internal/v1/log-retention/policies/{policyCode}/simulate
```

---

### 5. Retention Override API

```text
GET    /api/internal/v1/log-retention/overrides
POST   /api/internal/v1/log-retention/overrides
GET    /api/internal/v1/log-retention/overrides/{overrideId}
POST   /api/internal/v1/log-retention/overrides/{overrideId}/approve
POST   /api/internal/v1/log-retention/overrides/{overrideId}/expire
```

---

### 6. Legal Hold API

```text
GET    /api/internal/v1/log-legal-holds
POST   /api/internal/v1/log-legal-holds
GET    /api/internal/v1/log-legal-holds/{holdId}
POST   /api/internal/v1/log-legal-holds/{holdId}/activate
POST   /api/internal/v1/log-legal-holds/{holdId}/release
POST   /api/internal/v1/log-legal-holds/{holdId}/cancel
GET    /api/internal/v1/log-legal-holds/{holdId}/matches
```

---

### 7. Archive API

```text
GET  /api/internal/v1/log-archives/batches
GET  /api/internal/v1/log-archives/batches/{batchId}
POST /api/internal/v1/log-archives/plan
POST /api/internal/v1/log-archives/execute
POST /api/internal/v1/log-archives/batches/{batchId}/verify
POST /api/internal/v1/log-archives/batches/{batchId}/retry
GET  /api/internal/v1/log-archives/catalog
GET  /api/internal/v1/log-archives/catalog/{archiveObjectId}
```

---

### 8. Purge API

```text
GET  /api/internal/v1/log-purge/plans
GET  /api/internal/v1/log-purge/plans/{planId}
POST /api/internal/v1/log-purge/plans
POST /api/internal/v1/log-purge/plans/{planId}/approve
POST /api/internal/v1/log-purge/plans/{planId}/execute
POST /api/internal/v1/log-purge/batches/{batchId}/verify
POST /api/internal/v1/log-purge/batches/{batchId}/retry
GET  /api/internal/v1/log-purge/evidence/{evidenceId}
```

---

### 9. Retrieval API

```text
GET  /api/internal/v1/log-retrievals
POST /api/internal/v1/log-retrievals
GET  /api/internal/v1/log-retrievals/{requestId}
POST /api/internal/v1/log-retrievals/{requestId}/approve
POST /api/internal/v1/log-retrievals/{requestId}/restore
POST /api/internal/v1/log-retrievals/{requestId}/expire
GET  /api/internal/v1/log-retrievals/{requestId}/workspace
```

---

### 10. Integrity API

```text
GET  /api/internal/v1/log-integrity/checks
POST /api/internal/v1/log-integrity/checks
GET  /api/internal/v1/log-integrity/checks/{checkId}
POST /api/internal/v1/log-integrity/checks/{checkId}/retry
```

---

### 11. Retention Policy List Filters

```text
status
log_stream
retention_class
owner
effective_from
effective_to
legal_hold_eligible
page
per_page
sort
```

---

### 12. Legal Hold List Filters

```text
status
case_reference
tenant_id
scope_id
log_stream
starts_from
starts_to
classification
page
per_page
sort
```

---

### 13. Archive Catalog Filters

```text
log_stream
environment
tenant_id
scope_id
range_start
range_end
storage_class
legal_hold_status
integrity_status
retention_end_from
retention_end_to
page
per_page
sort
```

---

### 14. Retention Policy Create Request

```json
{
  "code": "application_error_standard",
  "title": "Application Error Standard Retention",
  "log_stream": "platform_application_error",
  "retention_class": "R2_STANDARD",
  "start_point": "EVENT_TIMESTAMP",
  "hot_duration": "30d",
  "warm_duration": "60d",
  "cold_duration": "0d",
  "archive_duration": "0d",
  "purge_after": "90d",
  "legal_hold_eligible": true,
  "integrity_requirement": "HASHED",
  "owner": "platform_operations",
  "effective_from": "2026-07-01",
  "version": "1.0"
}
```

---

### 15. Legal Hold Create Request

```json
{
  "case_reference": "CASE-2026-00125",
  "title": "Security Investigation Hold",
  "reason": "Preserve logs related to active investigation.",
  "scope": {
    "tenant_id": 10,
    "log_streams": [
      "security_event",
      "access_event"
    ],
    "range_start": "2026-06-01T00:00:00Z",
    "range_end": "2026-07-31T23:59:59Z"
  },
  "classification": "SECURITY_RESTRICTED"
}
```

---

### 16. Purge Plan Request

```json
{
  "policy_code": "application_error_standard",
  "scope": {
    "environment": "production",
    "tenant_id": 10,
    "range_end": "2026-04-01T00:00:00Z"
  },
  "mode": "APPROVAL_REQUIRED",
  "dry_run": true
}
```

---

### 17. Retrieval Request

```json
{
  "purpose": "Incident investigation INC-2026-000145",
  "scope": {
    "log_stream": "platform_application_error",
    "tenant_id": 10,
    "range_start": "2026-06-28T00:00:00Z",
    "range_end": "2026-06-29T00:00:00Z"
  },
  "expires_at": "2026-07-08T00:00:00Z"
}
```

---

### 18. Canonical Success Envelope

```json
{
  "data": {},
  "meta": {
    "request_id": "01J...",
    "generated_at": "2026-07-04T12:00:00Z"
  }
}
```

---

### 19. Canonical Error Envelope

```json
{
  "error": {
    "code": "LOG_PURGE_BLOCKED_BY_LEGAL_HOLD",
    "message": "The purge operation is blocked by an active legal hold.",
    "details": []
  },
  "meta": {
    "request_id": "01J...",
    "timestamp": "2026-07-04T12:00:00Z"
  }
}
```

---

### 20. HTTP Status Mapping

| Kondisi | HTTP |
|---|---:|
| success | 200 |
| created | 201 |
| accepted async | 202 |
| validation | 422 |
| unauthenticated | 401 |
| forbidden | 403 |
| not found | 404 |
| conflict | 409 |
| rate limited | 429 |
| unavailable | 503 |
| unexpected | 500 |

---

### 21. Controller Responsibilities

Controller hanya:

- parse request;
- validate DTO;
- build context;
- authorize;
- call application service;
- project response;
- map exception.

Controller tidak boleh:

- menjalankan SQL langsung;
- mengakses filesystem archive langsung;
- menghitung legal hold match sendiri;
- menghapus data langsung;
- membaca key material;
- mem-bypass policy.

---

### 22. RetentionPolicyController Example

```php
final class RetentionPolicyController
{
    public function __construct(
        private readonly RetentionPolicyServiceInterface $policies,
        private readonly RetentionContextFactory $contexts,
        private readonly RetentionPolicyProjector $projector
    ) {
    }

    public function create(
        HttpRequest $request
    ): HttpResponse {
        $context = $this->contexts->fromRequest($request);

        $policy = $this->policies->create(
            RetentionPolicyCreateCommand::fromArray(
                $request->json()
            ),
            $context
        );

        return JsonResponse::created(
            $this->projector->policy($policy)
        );
    }
}
```

---

### 23. LegalHoldController Example

```php
final class LegalHoldController
{
    public function __construct(
        private readonly LegalHoldServiceInterface $holds,
        private readonly RetentionContextFactory $contexts,
        private readonly LegalHoldProjector $projector
    ) {
    }

    public function release(
        HttpRequest $request,
        string $holdId
    ): HttpResponse {
        $context = $this->contexts->fromRequest($request);

        $hold = $this->holds->release(
            holdId: $holdId,
            reason: $request->jsonString('reason'),
            context: $context
        );

        return JsonResponse::ok(
            $this->projector->hold($hold)
        );
    }
}
```

---

### 24. PurgeController Example

```php
final class PurgeController
{
    public function __construct(
        private readonly LogPurgeServiceInterface $purge,
        private readonly RetentionContextFactory $contexts,
        private readonly PurgeProjector $projector
    ) {
    }

    public function execute(
        HttpRequest $request,
        string $planId
    ): HttpResponse {
        $context = $this->contexts->fromRequest($request);

        $batch = $this->purge->execute(
            planId: $planId,
            context: $context
        );

        return JsonResponse::accepted(
            $this->projector->batch($batch)
        );
    }
}
```

---

### 25. Application Service Contracts

#### Retention Policy

```php
interface RetentionPolicyServiceInterface
{
    public function create(
        RetentionPolicyCreateCommand $command,
        RetentionContext $context
    ): RetentionPolicy;

    public function approve(
        string $policyCode,
        RetentionContext $context
    ): RetentionPolicy;

    public function activate(
        string $policyCode,
        RetentionContext $context
    ): RetentionPolicy;

    public function simulate(
        string $policyCode,
        RetentionSimulationCriteria $criteria,
        RetentionContext $context
    ): RetentionSimulationResult;
}
```

---

### 26. Legal Hold Service

```php
interface LegalHoldServiceInterface
{
    public function create(
        LegalHoldCreateCommand $command,
        RetentionContext $context
    ): LegalHold;

    public function activate(
        string $holdId,
        RetentionContext $context
    ): LegalHold;

    public function release(
        string $holdId,
        string $reason,
        RetentionContext $context
    ): LegalHold;

    public function matches(
        LegalHoldMatchCriteria $criteria
    ): array;
}
```

---

### 27. Archive Service

```php
interface LogArchiveServiceInterface
{
    public function plan(
        ArchivePlanCommand $command,
        RetentionContext $context
    ): ArchivePlan;

    public function execute(
        string $planId,
        RetentionContext $context
    ): ArchiveBatch;

    public function verify(
        string $batchId,
        RetentionContext $context
    ): ArchiveVerificationResult;
}
```

---

### 28. Purge Service

```php
interface LogPurgeServiceInterface
{
    public function plan(
        PurgePlanCommand $command,
        RetentionContext $context
    ): PurgePlan;

    public function approve(
        string $planId,
        RetentionContext $context
    ): PurgePlan;

    public function execute(
        string $planId,
        RetentionContext $context
    ): PurgeBatch;

    public function verify(
        string $batchId,
        RetentionContext $context
    ): PurgeVerificationResult;
}
```

---

### 29. Retrieval Service

```php
interface LogRetrievalServiceInterface
{
    public function request(
        RetrievalRequestCommand $command,
        RetentionContext $context
    ): RetrievalRequest;

    public function approve(
        string $requestId,
        RetentionContext $context
    ): RetrievalRequest;

    public function restore(
        string $requestId,
        RetentionContext $context
    ): RetrievalWorkspace;
}
```

---

### 30. Middleware Order

```text
Request ID
→ Trusted Proxy
→ Security Headers
→ Authentication
→ Rate Limit
→ Tenant Context
→ Active Scope
→ Permission
→ Classification
→ Legal Hold Context
→ Audit Context
→ Controller
```

---

### 31. Authentication

Semua endpoint internal membutuhkan authenticated principal.

Service account wajib memiliki:

- identity;
- scoped credential;
- explicit permission;
- rotation;
- audit.

---

### 32. Tenant Context

Tenant context wajib tersedia untuk request tenant-aware.

Cross-tenant request membutuhkan permission khusus.

---

### 33. Active Scope

Jika platform memiliki organization/clinic/facility scope:

```text
scope_id
```

harus divalidasi sebelum search, archive, purge, atau retrieval.

---

### 34. Permission Middleware

Permission utama:

```text
observability.log.retention.read
observability.log.retention.manage
observability.log.retention.approve
observability.log.archive.read
observability.log.archive.execute
observability.log.archive.verify
observability.log.purge.plan
observability.log.purge.approve
observability.log.purge.execute
observability.log.legal_hold.read
observability.log.legal_hold.manage
observability.log.retrieval.request
observability.log.retrieval.approve
observability.log.retrieval.access
observability.log.integrity.verify
observability.log.cross_tenant.read
```

---

### 35. Classification Middleware

Classification middleware membatasi akses berdasarkan:

```text
INTERNAL
CONFIDENTIAL
RESTRICTED
SECURITY_RESTRICTED
LEGAL_HOLD
```

---

### 36. Legal Hold Context Middleware

Middleware ini tidak menentukan keputusan final purge.

Fungsinya:

- menambahkan hold context;
- menolak request destructive yang jelas melanggar hold;
- menyediakan metadata ke application service.

Final hold check tetap dilakukan dalam domain service.

---

### 37. CSRF

Mutation berbasis session wajib CSRF:

- create/update policy;
- approve policy;
- create/release hold;
- plan/approve/execute purge;
- request/approve retrieval;
- manual archive retry;
- integrity retry.

---

### 38. Rate Limiting

Rekomendasi:

| Endpoint | Limit |
|---|---:|
| policy list | 120/min/user |
| policy mutation | 30/hour/user |
| legal hold mutation | 20/hour/user |
| archive execute | 20/hour/user |
| purge plan | 20/hour/user |
| purge execute | 10/hour/user |
| retrieval request | 20/hour/user |
| catalog search | 120/min/user |
| integrity retry | 20/hour/user |

---

### 39. Four-Eyes Enforcement

Untuk high-risk action:

```text
requestor_user_id != approver_user_id
```

Berlaku pada:

- high-risk purge;
- legal hold release;
- regulated archive deletion;
- key destruction;
- bulk export.

---

### 40. Scheduler Architecture

```text
Scheduler
    │
    ├── Policy Evaluator
    ├── Archive Planner
    ├── Archive Executor
    ├── Archive Verifier
    ├── Purge Planner
    ├── Purge Executor
    ├── Purge Verifier
    ├── Legal Hold Reconciler
    ├── Retrieval Expiry
    ├── Integrity Checker
    └── Partition Maintainer
```

---

### 41. Required Scheduler Jobs

```text
log-retention-policy-evaluate
log-archive-plan
log-archive-execute
log-archive-verify
log-purge-plan
log-purge-execute
log-purge-verify
log-legal-hold-reconcile
log-retrieval-expire
log-integrity-check
log-partition-create
log-partition-drop-plan
log-retention-exception-expire
log-storage-capacity-check
```

---

### 42. Scheduler Frequency

| Job | Frequency |
|---|---:|
| Policy evaluation | hourly |
| Archive planning | daily |
| Archive execution | every 15 minutes |
| Archive verification | every 15 minutes |
| Purge planning | daily |
| Purge execution | daily/approved window |
| Purge verification | every 15 minutes |
| Hold reconciliation | every 5 minutes |
| Retrieval expiry | hourly |
| Integrity check | daily/weekly |
| Partition create | daily |
| Partition drop plan | daily |
| Exception expiry | hourly |
| Capacity check | every 15 minutes |

---

### 43. Job Locking

Setiap destructive atau stateful job wajib memiliki distributed lock.

Contoh key:

```text
log-archive:{stream}:{range}
log-purge:{policy}:{range}
log-integrity:{object_id}
```

---

### 44. Job Idempotency

Job harus aman dijalankan ulang.

Idempotency keys:

```text
archive plan id
archive batch id
purge plan id
purge batch id
integrity check id
```

---

### 45. Job Retry

Retry hanya untuk transient failure.

Permanent validation failure harus:

- status FAILED;
- no infinite retry;
- alert owner;
- require manual correction.

---

### 46. Job Heartbeat

Long-running job wajib memperbarui:

```text
heartbeat_at
progress_percent
processed_records
processed_bytes
```

---

### 47. Stuck Job Detection

Jika heartbeat stale:

- mark suspected stuck;
- alert;
- stop conflicting job;
- require recovery action.

---

### 48. CLI Commands

```bash
php bin/console log-retention:evaluate
php bin/console log-archive:plan
php bin/console log-archive:execute --batch=01J...
php bin/console log-archive:verify --batch=01J...
php bin/console log-purge:plan
php bin/console log-purge:execute --plan=01J...
php bin/console log-purge:verify --batch=01J...
php bin/console log-legal-hold:reconcile
php bin/console log-integrity:check
php bin/console log-partition:maintain
```

---

### 49. Database Schema Overview

Tables:

```text
log_stream_definitions
log_retention_policies
log_retention_policy_versions
log_retention_overrides
log_legal_holds
log_legal_hold_scopes
log_archive_plans
log_archive_batches
log_archive_objects
log_archive_manifests
log_purge_plans
log_purge_batches
log_purge_evidence
log_retrieval_requests
log_retrieval_workspaces
log_integrity_checks
log_chain_of_custody_events
log_retention_exceptions
log_scheduler_runs
```

---

### 50. Table: log_stream_definitions

```sql
CREATE TABLE log_stream_definitions (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    code VARCHAR(150) NOT NULL,
    domain_code VARCHAR(50) NOT NULL,
    description VARCHAR(1000) NULL,
    business_owner VARCHAR(100) NOT NULL,
    technical_owner VARCHAR(100) NOT NULL,
    security_owner VARCHAR(100) NULL,
    sensitivity VARCHAR(30) NOT NULL,
    criticality VARCHAR(30) NOT NULL,
    purpose_json JSON NOT NULL,
    retention_class VARCHAR(30) NOT NULL,
    storage_class VARCHAR(30) NOT NULL,
    tenant_scope VARCHAR(30) NOT NULL,
    schema_version VARCHAR(20) NOT NULL,
    integrity_requirement VARCHAR(30) NOT NULL,
    access_policy_code VARCHAR(150) NOT NULL,
    legal_hold_eligible TINYINT(1) NOT NULL DEFAULT 0,
    enabled TINYINT(1) NOT NULL DEFAULT 1,
    created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    updated_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6)
        ON UPDATE CURRENT_TIMESTAMP(6),

    PRIMARY KEY (id),
    UNIQUE KEY uq_log_stream_code (code),
    KEY idx_log_stream_active (
        enabled,
        domain_code,
        sensitivity
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

### 51. Table: log_retention_policies

```sql
CREATE TABLE log_retention_policies (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    code VARCHAR(150) NOT NULL,
    log_stream_id BIGINT UNSIGNED NOT NULL,
    title VARCHAR(200) NOT NULL,
    description VARCHAR(1000) NULL,
    retention_class VARCHAR(30) NOT NULL,
    start_point VARCHAR(50) NOT NULL,
    hot_duration_seconds BIGINT UNSIGNED NOT NULL DEFAULT 0,
    warm_duration_seconds BIGINT UNSIGNED NOT NULL DEFAULT 0,
    cold_duration_seconds BIGINT UNSIGNED NOT NULL DEFAULT 0,
    archive_duration_seconds BIGINT UNSIGNED NOT NULL DEFAULT 0,
    purge_after_seconds BIGINT UNSIGNED NOT NULL,
    legal_hold_eligible TINYINT(1) NOT NULL DEFAULT 0,
    integrity_requirement VARCHAR(30) NOT NULL,
    owner_reference VARCHAR(150) NOT NULL,
    approver_reference VARCHAR(150) NOT NULL,
    policy_version VARCHAR(20) NOT NULL,
    status VARCHAR(30) NOT NULL DEFAULT 'DRAFT',
    effective_from DATETIME(6) NOT NULL,
    effective_until DATETIME(6) NULL,
    created_by BIGINT UNSIGNED NOT NULL,
    updated_by BIGINT UNSIGNED NULL,
    created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    updated_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6)
        ON UPDATE CURRENT_TIMESTAMP(6),

    PRIMARY KEY (id),
    CONSTRAINT fk_log_retention_stream
        FOREIGN KEY (log_stream_id)
        REFERENCES log_stream_definitions(id),

    UNIQUE KEY uq_log_retention_code_version (
        code,
        policy_version
    ),
    KEY idx_log_retention_active (
        status,
        effective_from,
        effective_until
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

### 52. Table: log_retention_overrides

```sql
CREATE TABLE log_retention_overrides (
    id CHAR(26) NOT NULL,
    override_type VARCHAR(40) NOT NULL,
    reason VARCHAR(2000) NOT NULL,
    scope_json JSON NOT NULL,
    case_reference VARCHAR(150) NULL,
    starts_at DATETIME(6) NOT NULL,
    ends_at DATETIME(6) NULL,
    status VARCHAR(30) NOT NULL DEFAULT 'DRAFT',
    created_by BIGINT UNSIGNED NOT NULL,
    approved_by BIGINT UNSIGNED NULL,
    created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    updated_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6)
        ON UPDATE CURRENT_TIMESTAMP(6),

    PRIMARY KEY (id),
    KEY idx_log_retention_override_active (
        status,
        starts_at,
        ends_at
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

### 53. Table: log_legal_holds

```sql
CREATE TABLE log_legal_holds (
    id CHAR(26) NOT NULL,
    case_reference VARCHAR(150) NOT NULL,
    title VARCHAR(255) NOT NULL,
    reason VARCHAR(3000) NOT NULL,
    classification VARCHAR(30) NOT NULL,
    status VARCHAR(30) NOT NULL DEFAULT 'DRAFT',
    starts_at DATETIME(6) NULL,
    released_at DATETIME(6) NULL,
    owner_reference VARCHAR(150) NOT NULL,
    created_by BIGINT UNSIGNED NOT NULL,
    approved_by BIGINT UNSIGNED NULL,
    released_by BIGINT UNSIGNED NULL,
    created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    updated_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6)
        ON UPDATE CURRENT_TIMESTAMP(6),

    PRIMARY KEY (id),
    UNIQUE KEY uq_log_legal_hold_case (
        case_reference,
        id
    ),
    KEY idx_log_legal_hold_active (
        status,
        starts_at,
        released_at
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

### 54. Table: log_legal_hold_scopes

```sql
CREATE TABLE log_legal_hold_scopes (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    legal_hold_id CHAR(26) NOT NULL,
    log_stream_code VARCHAR(150) NULL,
    environment VARCHAR(32) NULL,
    tenant_id BIGINT UNSIGNED NULL,
    scope_id BIGINT UNSIGNED NULL,
    module_code VARCHAR(100) NULL,
    event_code VARCHAR(120) NULL,
    resource_reference VARCHAR(255) NULL,
    actor_reference VARCHAR(255) NULL,
    range_start DATETIME(6) NULL,
    range_end DATETIME(6) NULL,
    created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),

    PRIMARY KEY (id),
    CONSTRAINT fk_log_hold_scope_hold
        FOREIGN KEY (legal_hold_id)
        REFERENCES log_legal_holds(id)
        ON DELETE CASCADE,

    KEY idx_log_hold_scope_match (
        log_stream_code,
        tenant_id,
        scope_id,
        range_start,
        range_end
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

### 55. Table: log_archive_plans

```sql
CREATE TABLE log_archive_plans (
    id CHAR(26) NOT NULL,
    policy_id BIGINT UNSIGNED NOT NULL,
    log_stream_code VARCHAR(150) NOT NULL,
    environment VARCHAR(32) NOT NULL,
    tenant_id BIGINT UNSIGNED NULL,
    scope_id BIGINT UNSIGNED NULL,
    range_start DATETIME(6) NOT NULL,
    range_end DATETIME(6) NOT NULL,
    estimated_records BIGINT UNSIGNED NOT NULL DEFAULT 0,
    estimated_bytes BIGINT UNSIGNED NOT NULL DEFAULT 0,
    hold_check_status VARCHAR(30) NOT NULL,
    status VARCHAR(30) NOT NULL DEFAULT 'PLANNED',
    created_by BIGINT UNSIGNED NULL,
    scheduled_at DATETIME(6) NULL,
    created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),

    PRIMARY KEY (id),
    CONSTRAINT fk_log_archive_plan_policy
        FOREIGN KEY (policy_id)
        REFERENCES log_retention_policies(id),

    KEY idx_log_archive_plan_status (
        status,
        scheduled_at
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

### 56. Table: log_archive_batches

```sql
CREATE TABLE log_archive_batches (
    id CHAR(26) NOT NULL,
    archive_plan_id CHAR(26) NOT NULL,
    status VARCHAR(30) NOT NULL,
    record_count BIGINT UNSIGNED NOT NULL DEFAULT 0,
    object_count INT UNSIGNED NOT NULL DEFAULT 0,
    processed_bytes BIGINT UNSIGNED NOT NULL DEFAULT 0,
    progress_percent DECIMAL(5,2) NOT NULL DEFAULT 0,
    verification_status VARCHAR(30) NOT NULL DEFAULT 'PENDING',
    source_deleted TINYINT(1) NOT NULL DEFAULT 0,
    heartbeat_at DATETIME(6) NULL,
    error_code VARCHAR(100) NULL,
    error_message VARCHAR(2000) NULL,
    started_at DATETIME(6) NOT NULL,
    completed_at DATETIME(6) NULL,
    created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),

    PRIMARY KEY (id),
    CONSTRAINT fk_log_archive_batch_plan
        FOREIGN KEY (archive_plan_id)
        REFERENCES log_archive_plans(id),

    KEY idx_log_archive_batch_status (
        status,
        heartbeat_at
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

### 57. Table: log_archive_manifests

```sql
CREATE TABLE log_archive_manifests (
    id CHAR(26) NOT NULL,
    archive_batch_id CHAR(26) NOT NULL,
    manifest_reference VARCHAR(1000) NOT NULL,
    checksum_algorithm VARCHAR(30) NOT NULL,
    checksum_value VARCHAR(256) NOT NULL,
    signature_algorithm VARCHAR(50) NULL,
    signature_value TEXT NULL,
    schema_version VARCHAR(20) NOT NULL,
    record_count BIGINT UNSIGNED NOT NULL,
    object_count INT UNSIGNED NOT NULL,
    integrity_status VARCHAR(30) NOT NULL DEFAULT 'PENDING',
    created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    verified_at DATETIME(6) NULL,

    PRIMARY KEY (id),
    CONSTRAINT fk_log_archive_manifest_batch
        FOREIGN KEY (archive_batch_id)
        REFERENCES log_archive_batches(id)
        ON DELETE CASCADE,

    UNIQUE KEY uq_log_archive_manifest_batch (
        archive_batch_id
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

### 58. Table: log_purge_plans

```sql
CREATE TABLE log_purge_plans (
    id CHAR(26) NOT NULL,
    policy_id BIGINT UNSIGNED NOT NULL,
    scope_json JSON NOT NULL,
    mode VARCHAR(30) NOT NULL,
    estimated_records BIGINT UNSIGNED NOT NULL DEFAULT 0,
    estimated_objects BIGINT UNSIGNED NOT NULL DEFAULT 0,
    hold_check_status VARCHAR(30) NOT NULL,
    approval_required TINYINT(1) NOT NULL DEFAULT 0,
    requested_by BIGINT UNSIGNED NOT NULL,
    approved_by BIGINT UNSIGNED NULL,
    scheduled_at DATETIME(6) NULL,
    status VARCHAR(30) NOT NULL DEFAULT 'PLANNED',
    created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    updated_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6)
        ON UPDATE CURRENT_TIMESTAMP(6),

    PRIMARY KEY (id),
    CONSTRAINT fk_log_purge_plan_policy
        FOREIGN KEY (policy_id)
        REFERENCES log_retention_policies(id),

    KEY idx_log_purge_plan_status (
        status,
        scheduled_at
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

### 59. Table: log_purge_batches

```sql
CREATE TABLE log_purge_batches (
    id CHAR(26) NOT NULL,
    purge_plan_id CHAR(26) NOT NULL,
    status VARCHAR(30) NOT NULL,
    records_deleted BIGINT UNSIGNED NOT NULL DEFAULT 0,
    objects_deleted BIGINT UNSIGNED NOT NULL DEFAULT 0,
    verification_status VARCHAR(30) NOT NULL DEFAULT 'PENDING',
    heartbeat_at DATETIME(6) NULL,
    error_code VARCHAR(100) NULL,
    error_message VARCHAR(2000) NULL,
    started_at DATETIME(6) NOT NULL,
    completed_at DATETIME(6) NULL,
    created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),

    PRIMARY KEY (id),
    CONSTRAINT fk_log_purge_batch_plan
        FOREIGN KEY (purge_plan_id)
        REFERENCES log_purge_plans(id),

    KEY idx_log_purge_batch_status (
        status,
        heartbeat_at
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

### 60. Table: log_purge_evidence

```sql
CREATE TABLE log_purge_evidence (
    id CHAR(26) NOT NULL,
    purge_batch_id CHAR(26) NOT NULL,
    policy_code VARCHAR(150) NOT NULL,
    scope_json JSON NOT NULL,
    range_start DATETIME(6) NULL,
    range_end DATETIME(6) NULL,
    records_deleted BIGINT UNSIGNED NOT NULL,
    objects_deleted BIGINT UNSIGNED NOT NULL,
    verification_method VARCHAR(100) NOT NULL,
    verification_result VARCHAR(30) NOT NULL,
    evidence_hash VARCHAR(256) NOT NULL,
    executed_by_reference VARCHAR(150) NOT NULL,
    started_at DATETIME(6) NOT NULL,
    completed_at DATETIME(6) NOT NULL,
    created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),

    PRIMARY KEY (id),
    CONSTRAINT fk_log_purge_evidence_batch
        FOREIGN KEY (purge_batch_id)
        REFERENCES log_purge_batches(id),

    UNIQUE KEY uq_log_purge_evidence_batch (
        purge_batch_id
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

### 61. Table: log_retrieval_requests

```sql
CREATE TABLE log_retrieval_requests (
    id CHAR(26) NOT NULL,
    purpose VARCHAR(2000) NOT NULL,
    scope_json JSON NOT NULL,
    classification VARCHAR(30) NOT NULL,
    requested_by BIGINT UNSIGNED NOT NULL,
    approved_by BIGINT UNSIGNED NULL,
    expires_at DATETIME(6) NOT NULL,
    status VARCHAR(30) NOT NULL DEFAULT 'REQUESTED',
    created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    updated_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6)
        ON UPDATE CURRENT_TIMESTAMP(6),

    PRIMARY KEY (id),
    KEY idx_log_retrieval_status (
        status,
        expires_at
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

### 62. Table: log_retrieval_workspaces

```sql
CREATE TABLE log_retrieval_workspaces (
    id CHAR(26) NOT NULL,
    retrieval_request_id CHAR(26) NOT NULL,
    storage_reference VARCHAR(1000) NOT NULL,
    classification VARCHAR(30) NOT NULL,
    status VARCHAR(30) NOT NULL,
    record_count BIGINT UNSIGNED NOT NULL DEFAULT 0,
    byte_size BIGINT UNSIGNED NOT NULL DEFAULT 0,
    expires_at DATETIME(6) NOT NULL,
    created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    purged_at DATETIME(6) NULL,

    PRIMARY KEY (id),
    CONSTRAINT fk_log_retrieval_workspace_request
        FOREIGN KEY (retrieval_request_id)
        REFERENCES log_retrieval_requests(id)
        ON DELETE CASCADE,

    KEY idx_log_retrieval_workspace_expiry (
        status,
        expires_at
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

### 63. Table: log_integrity_checks

```sql
CREATE TABLE log_integrity_checks (
    id CHAR(26) NOT NULL,
    target_type VARCHAR(30) NOT NULL,
    target_reference VARCHAR(255) NOT NULL,
    check_type VARCHAR(40) NOT NULL,
    expected_value VARCHAR(500) NULL,
    actual_value VARCHAR(500) NULL,
    status VARCHAR(30) NOT NULL,
    error_code VARCHAR(100) NULL,
    checked_by_reference VARCHAR(150) NOT NULL,
    checked_at DATETIME(6) NOT NULL,
    created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),

    PRIMARY KEY (id),
    KEY idx_log_integrity_target (
        target_type,
        target_reference,
        checked_at
    ),
    KEY idx_log_integrity_failure (
        status,
        checked_at
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

### 64. Table: log_chain_of_custody_events

```sql
CREATE TABLE log_chain_of_custody_events (
    id CHAR(26) NOT NULL,
    evidence_reference VARCHAR(255) NOT NULL,
    event_type VARCHAR(50) NOT NULL,
    actor_reference VARCHAR(150) NOT NULL,
    source_reference VARCHAR(1000) NULL,
    destination_reference VARCHAR(1000) NULL,
    reason VARCHAR(2000) NOT NULL,
    hash_before VARCHAR(256) NULL,
    hash_after VARCHAR(256) NULL,
    approval_reference VARCHAR(255) NULL,
    occurred_at DATETIME(6) NOT NULL,
    created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),

    PRIMARY KEY (id),
    KEY idx_log_custody_reference (
        evidence_reference,
        occurred_at
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

### 65. Table: log_scheduler_runs

```sql
CREATE TABLE log_scheduler_runs (
    id CHAR(26) NOT NULL,
    job_code VARCHAR(150) NOT NULL,
    idempotency_key VARCHAR(255) NOT NULL,
    status VARCHAR(30) NOT NULL,
    progress_percent DECIMAL(5,2) NOT NULL DEFAULT 0,
    processed_records BIGINT UNSIGNED NOT NULL DEFAULT 0,
    processed_bytes BIGINT UNSIGNED NOT NULL DEFAULT 0,
    heartbeat_at DATETIME(6) NULL,
    error_code VARCHAR(100) NULL,
    error_message VARCHAR(2000) NULL,
    started_at DATETIME(6) NOT NULL,
    completed_at DATETIME(6) NULL,
    created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),

    PRIMARY KEY (id),
    UNIQUE KEY uq_log_scheduler_idempotency (
        idempotency_key
    ),
    KEY idx_log_scheduler_status (
        job_code,
        status,
        heartbeat_at
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

### 66. Repository Contract

```php
interface RetentionPolicyRepositoryInterface
{
    public function findActiveByStream(
        string $logStreamCode,
        \DateTimeImmutable $at
    ): ?RetentionPolicy;

    public function save(
        RetentionPolicy $policy
    ): void;
}
```

---

### 67. Legal Hold Repository

```php
interface LegalHoldRepositoryInterface
{
    public function findActiveMatches(
        LegalHoldMatchCriteria $criteria
    ): array;

    public function save(
        LegalHold $hold
    ): void;
}
```

---

### 68. Archive Repository

```php
interface ArchiveBatchRepositoryInterface
{
    public function findById(
        string $batchId
    ): ?ArchiveBatch;

    public function save(
        ArchiveBatch $batch
    ): void;
}
```

---

### 69. Purge Repository

```php
interface PurgePlanRepositoryInterface
{
    public function findById(
        string $planId
    ): ?PurgePlan;

    public function save(
        PurgePlan $plan
    ): void;
}
```

---

### 70. Audit Integration

Wajib audit:

- policy create/update/approve/activate;
- override create/approve/expire;
- legal hold create/activate/release/cancel;
- archive plan/execute/verify;
- purge plan/approve/execute/verify;
- retrieval request/approve/restore;
- integrity check failure;
- chain-of-custody event;
- cross-tenant access;
- restricted export;
- manual retry;
- partition drop.

---

### 71. Audit Event Catalog

```text
OBS_LOG_POLICY_CREATED
OBS_LOG_POLICY_UPDATED
OBS_LOG_POLICY_APPROVED
OBS_LOG_POLICY_ACTIVATED
OBS_LOG_OVERRIDE_CREATED
OBS_LOG_OVERRIDE_APPROVED
OBS_LOG_LEGAL_HOLD_CREATED
OBS_LOG_LEGAL_HOLD_ACTIVATED
OBS_LOG_LEGAL_HOLD_RELEASED
OBS_LOG_ARCHIVE_PLAN_CREATED
OBS_LOG_ARCHIVE_EXECUTED
OBS_LOG_ARCHIVE_VERIFIED
OBS_LOG_PURGE_PLAN_CREATED
OBS_LOG_PURGE_APPROVED
OBS_LOG_PURGE_EXECUTED
OBS_LOG_PURGE_VERIFIED
OBS_LOG_RETRIEVAL_REQUESTED
OBS_LOG_RETRIEVAL_APPROVED
OBS_LOG_RETRIEVAL_RESTORED
OBS_LOG_INTEGRITY_FAILED
OBS_LOG_PARTITION_DROPPED
OBS_LOG_RESTRICTED_VIEWED
```

---

### 72. Structured Logging

```json
{
  "event": "log_purge_execution_completed",
  "purge_batch_id": "01J...",
  "policy_code": "application_error_standard",
  "records_deleted": 125000,
  "objects_deleted": 4,
  "verification_status": "VERIFIED",
  "tenant_id": 10,
  "scope_id": null
}
```

Jangan mencatat raw deleted payload.

---

### 73. Telemetry

```text
log_retention_api_request_total
log_retention_api_error_total
log_archive_job_total
log_archive_job_failure_total
log_archive_verification_failure_total
log_purge_job_total
log_purge_job_failure_total
log_purge_verification_failure_total
log_legal_hold_match_total
log_retrieval_job_total
log_retrieval_job_failure_total
log_integrity_failure_total
log_scheduler_stuck_total
log_partition_maintenance_failure_total
```

---

### 74. Error Codes

```text
LOG_STREAM_NOT_FOUND
LOG_POLICY_NOT_FOUND
LOG_POLICY_INVALID
LOG_POLICY_CONFLICT
LOG_POLICY_NOT_ACTIVE
LOG_OVERRIDE_NOT_FOUND
LOG_OVERRIDE_INVALID
LOG_LEGAL_HOLD_NOT_FOUND
LOG_LEGAL_HOLD_INVALID
LOG_LEGAL_HOLD_RELEASE_BLOCKED
LOG_ARCHIVE_PLAN_INVALID
LOG_ARCHIVE_BATCH_NOT_FOUND
LOG_ARCHIVE_VERIFICATION_FAILED
LOG_PURGE_PLAN_INVALID
LOG_PURGE_APPROVAL_REQUIRED
LOG_PURGE_BLOCKED_BY_LEGAL_HOLD
LOG_PURGE_EXECUTION_FAILED
LOG_PURGE_VERIFICATION_FAILED
LOG_RETRIEVAL_REQUEST_NOT_FOUND
LOG_RETRIEVAL_APPROVAL_REQUIRED
LOG_RETRIEVAL_EXPIRED
LOG_INTEGRITY_CHECK_FAILED
LOG_CROSS_TENANT_ACCESS_DENIED
LOG_CLASSIFICATION_ACCESS_DENIED
LOG_SCHEDULER_JOB_STUCK
```

---

### 75. Security Controls

Framework wajib:

- no raw SQL from API;
- no direct filesystem path exposure;
- no archive object key exposure untuk unauthorized user;
- tenant/scope enforcement;
- classification enforcement;
- four-eyes untuk high-risk purge;
- legal hold check sebelum destructive action;
- signed URL dengan expiry bila digunakan;
- retrieval workspace auto-expire;
- no raw encryption key;
- audit seluruh privileged access;
- CSRF untuk session mutation;
- rate limiting;
- secure error response.

---

### 76. Archive Download Policy

Jika archive perlu diunduh:

- permission khusus;
- approval;
- bounded object set;
- expiring link;
- download audit;
- encryption;
- no public URL;
- tenant isolation.

---

### 77. Signed URL

Signed URL wajib:

- short expiry;
- one-time atau bounded use;
- scoped object;
- no directory listing;
- no embedded secret;
- audit generation.

---

### 78. Export Limits

Config:

```text
maximum_rows
maximum_bytes
maximum_time_range
maximum_archive_objects
maximum_concurrent_exports
```

---

### 79. Cross-Tenant Access

Cross-tenant retrieval atau archive search membutuhkan:

```text
observability.log.cross_tenant.read
```

dan wajib diaudit.

---

### 80. Data Masking

API projector harus dapat menyembunyikan:

- object key;
- internal path;
- key reference;
- actor identity;
- sensitive case reference;
- tenant detail lain.

---

### 81. Apache/XAMPP Virtual Host

```apache
<VirtualHost *:80>
    ServerName platform.local
    DocumentRoot "D:/xampp/htdocs/platform/public"

    <Directory "D:/xampp/htdocs/platform/public">
        AllowOverride All
        Require all granted
        Options -Indexes
    </Directory>

    <Directory "D:/xampp/htdocs/platform/storage/log-archive">
        Require all denied
        Options -Indexes
    </Directory>

    ErrorLog "logs/platform-error.log"
    CustomLog "logs/platform-access.log" combined
</VirtualHost>
```

---

### 82. `.htaccess`

```apache
RewriteEngine On

RewriteCond %{REQUEST_FILENAME} -f [OR]
RewriteCond %{REQUEST_FILENAME} -d
RewriteRule ^ - [L]

RewriteRule ^ index.php [QSA,L]
```

---

### 83. Route Registration

```php
$router->group('/api/internal/v1', [
    'middleware' => [
        RequestIdMiddleware::class,
        AuthenticationMiddleware::class,
        RateLimitMiddleware::class,
        TenantContextMiddleware::class,
        ActiveScopeMiddleware::class,
        ClassificationMiddleware::class,
        AuditContextMiddleware::class,
    ],
], function ($router): void {
    $router->get('/log-retention/policies', [
        RetentionPolicyController::class,
        'index',
    ]);

    $router->post('/log-retention/policies', [
        RetentionPolicyController::class,
        'create',
    ]);

    $router->post('/log-legal-holds', [
        LegalHoldController::class,
        'create',
    ]);

    $router->post('/log-legal-holds/{holdId}/release', [
        LegalHoldController::class,
        'release',
    ]);

    $router->post('/log-archives/plan', [
        ArchiveController::class,
        'plan',
    ]);

    $router->post('/log-purge/plans', [
        PurgeController::class,
        'plan',
    ]);

    $router->post('/log-purge/plans/{planId}/execute', [
        PurgeController::class,
        'execute',
    ]);

    $router->post('/log-retrievals', [
        RetrievalController::class,
        'request',
    ]);
});
```

---

### 84. Sequence Diagram — Archive Flow

```mermaid
sequenceDiagram
    participant Scheduler
    participant Policy as Retention Policy Service
    participant Hold as Legal Hold Service
    participant Archive as Archive Service
    participant Source as HOT/WARM Store
    participant Object as Archive Object Store
    participant Catalog as Metadata Catalog
    participant Integrity as Integrity Service
    participant Audit as Audit Service

    Scheduler->>Policy: Resolve eligible range
    Policy->>Hold: Check active holds
    Hold-->>Policy: No blocking hold
    Policy->>Archive: Create archive plan
    Archive->>Source: Read bounded batch
    Source-->>Archive: Log records
    Archive->>Object: Write encrypted object
    Object-->>Archive: Object reference
    Archive->>Catalog: Register object metadata
    Archive->>Integrity: Verify checksum/manifest
    Integrity-->>Archive: VERIFIED
    Archive->>Audit: Record archive completion
```

---

### 85. Sequence Diagram — Purge Flow

```mermaid
sequenceDiagram
    participant User
    participant API as PurgeController
    participant Auth as RBAC/Scope
    participant Purge as Purge Service
    participant Hold as Legal Hold Service
    participant Archive as Archive Catalog
    participant Store as Source/Object Store
    participant Evidence as Evidence Repository
    participant Audit as Audit Service

    User->>API: Execute approved purge plan
    API->>Auth: Validate permission and scope
    Auth-->>API: Allowed
    API->>Purge: Execute plan
    Purge->>Hold: Final legal hold check
    Hold-->>Purge: No active match
    Purge->>Archive: Verify archive/retention state
    Archive-->>Purge: Eligible
    Purge->>Store: Delete bounded batch
    Store-->>Purge: Delete result
    Purge->>Evidence: Persist deletion evidence
    Purge->>Audit: Record destructive action
    Purge-->>API: Accepted/completed
```

---

### 86. Sequence Diagram — Retrieval Flow

```mermaid
sequenceDiagram
    participant User
    participant API as RetrievalController
    participant Auth as RBAC/Scope
    participant Retrieval as Retrieval Service
    participant Catalog as Metadata Catalog
    participant Object as Archive Object Store
    participant Integrity as Integrity Service
    participant Workspace as Retrieval Workspace
    participant Audit as Audit Service

    User->>API: Request archive retrieval
    API->>Auth: Validate permission and scope
    Auth-->>API: Allowed
    API->>Retrieval: Create request
    Retrieval->>Catalog: Find archive objects
    Catalog-->>Retrieval: Object references
    Retrieval->>Object: Read encrypted objects
    Object-->>Retrieval: Object streams
    Retrieval->>Integrity: Verify checksums
    Integrity-->>Retrieval: VERIFIED
    Retrieval->>Workspace: Restore temporary data
    Retrieval->>Audit: Record retrieval access
    Retrieval-->>API: Workspace reference
```

---

### 87. Performance Targets

| Operation | Target |
|---|---:|
| Policy list | < 500 ms |
| Policy mutation | < 750 ms |
| Legal hold create | < 750 ms |
| Hold match check | < 200 ms |
| Archive plan | < 2 s |
| Purge dry run | workload-based |
| Purge execute enqueue | < 500 ms |
| Catalog search | < 750 ms |
| Retrieval request | < 750 ms |
| Integrity check enqueue | < 500 ms |

---

### 88. Testing Strategy

#### Unit

- policy validation;
- duration parser;
- hold matching;
- tier calculation;
- purge eligibility;
- four-eyes rule;
- classification projection;
- state transitions.

#### Integration

- PDO repositories;
- scheduler locks;
- archive object adapter;
- manifest creation;
- purge evidence;
- retrieval workspace;
- audit emission;
- route contracts.

#### Security

- cross-tenant access;
- restricted classification;
- legal hold bypass;
- object path traversal;
- CSRF;
- rate limit;
- signed URL expiry;
- key reference leakage.

---

### 89. UAT Part 4

#### Policy API

- [ ] Policy list bekerja.
- [ ] Policy create tervalidasi.
- [ ] Approval workflow bekerja.
- [ ] Activation bekerja.
- [ ] Simulation menghasilkan estimasi.
- [ ] Policy conflict ditolak.

#### Legal Hold API

- [ ] Hold dapat dibuat.
- [ ] Scope match bekerja.
- [ ] Activation bekerja.
- [ ] Release membutuhkan permission.
- [ ] Release four-eyes diterapkan bila diwajibkan.
- [ ] Semua perubahan diaudit.

#### Archive API

- [ ] Archive plan dapat dibuat.
- [ ] Execution menghasilkan batch.
- [ ] Manifest tersimpan.
- [ ] Verification bekerja.
- [ ] Retry idempotent.
- [ ] Catalog dapat dicari.

#### Purge API

- [ ] Dry run bekerja.
- [ ] Approval-required mode bekerja.
- [ ] Legal hold memblokir purge.
- [ ] Execute menghasilkan batch.
- [ ] Verification menghasilkan evidence.
- [ ] Partial failure dapat di-retry.

#### Retrieval API

- [ ] Request memiliki purpose.
- [ ] Approval diterapkan.
- [ ] Workspace isolated.
- [ ] Expiry bekerja.
- [ ] Cross-tenant access ditolak.
- [ ] Restricted access diaudit.

#### Scheduler

- [ ] Policy evaluator berjalan.
- [ ] Archive planner berjalan.
- [ ] Archive verifier berjalan.
- [ ] Purge planner berjalan.
- [ ] Purge verifier berjalan.
- [ ] Hold reconciler berjalan.
- [ ] Retrieval expiry berjalan.
- [ ] Integrity checker berjalan.
- [ ] Partition maintainer berjalan.
- [ ] Stuck job terdeteksi.

#### Database

- [ ] Migration berhasil.
- [ ] Foreign key valid.
- [ ] Index mendukung query utama.
- [ ] Idempotency key unik.
- [ ] Tenant/scope data terisolasi.
- [ ] Evidence tidak menyimpan raw log.

#### Security

- [ ] Raw SQL ditolak.
- [ ] Direct path tidak terekspos.
- [ ] Four-eyes bekerja.
- [ ] CSRF aktif.
- [ ] Rate limit aktif.
- [ ] Signed URL expire.
- [ ] Archive folder tidak dapat diakses langsung.
- [ ] Legal hold tidak dapat dibypass.

#### Apache/XAMPP

- [ ] Front controller bekerja.
- [ ] Archive folder blocked.
- [ ] Directory listing nonaktif.
- [ ] Internal API route bekerja.
- [ ] Error log tersedia.

---

### 90. Anti-Pattern

Hindari:

- controller menghapus data langsung;
- purge tanpa application service;
- legal hold check hanya di UI;
- scheduler tanpa lock;
- retry tanpa idempotency;
- object path dikirim ke user;
- key reference tampil pada response umum;
- evidence menyimpan raw deleted log;
- cross-tenant query tanpa permission;
- signed URL tanpa expiry;
- retrieval workspace permanen;
- archive folder di bawah public;
- manual partition drop tanpa purge plan.

---

### 91. Definition of Done Part 4

Part 4 dianggap selesai bila:

- [ ] HTTP API catalog tersedia;
- [ ] request/response contracts tersedia;
- [ ] controller standard tersedia;
- [ ] application service contracts tersedia;
- [ ] middleware order tersedia;
- [ ] permission model tersedia;
- [ ] classification enforcement tersedia;
- [ ] four-eyes enforcement tersedia;
- [ ] scheduler architecture tersedia;
- [ ] scheduler jobs tersedia;
- [ ] lock/idempotency tersedia;
- [ ] CLI commands tersedia;
- [ ] database schema tersedia;
- [ ] repository contracts tersedia;
- [ ] audit integration tersedia;
- [ ] telemetry tersedia;
- [ ] error codes tersedia;
- [ ] security controls tersedia;
- [ ] Apache/XAMPP routing tersedia;
- [ ] sequence diagram tersedia;
- [ ] UAT tersedia.

---

### 92. Rencana Part Berikutnya

#### Part 5

Reference implementation, sample policies, migration, deployment, rollback, retention simulation, performance test, operational runbook, final UAT, Definition of Done, roadmap, dan merge guidance menjadi `SSOT-OBS-08.md`.

---

## Bagian V — Reference Implementation, Deployment, Simulation, Final UAT & Operational Readiness

### 1. Executive Summary

Part 5 menutup rangkaian SSOT-OBS-08 dengan reference implementation Log Retention & Archiving Framework.

Bagian ini mencakup:

- bootstrap wiring;
- sample log stream definitions;
- sample retention policies;
- archive implementation;
- legal hold resolver;
- purge implementation;
- retrieval implementation;
- scheduler wiring;
- migration order;
- permission seed;
- deployment;
- rollback;
- simulation;
- performance test;
- operational runbook;
- final UAT;
- Definition of Done;
- roadmap;
- merge guidance menjadi `SSOT-OBS-08.md`.

Target implementasi awal adalah framework yang:

- mengklasifikasikan log;
- menetapkan retention;
- memindahkan data antar tier;
- membuat archive terenkripsi;
- memverifikasi checksum;
- memblokir purge saat legal hold aktif;
- menghasilkan deletion evidence;
- menyediakan retrieval terkontrol;
- menjaga tenant/scope isolation;
- tetap dapat diaudit.

---

### 2. Initial Implementation Scope

Initial release wajib mencakup:

```text
Log Stream Registry
Retention Policy Registry
Retention Evaluator
Legal Hold Resolver
Archive Planner
Archive Executor
Archive Verifier
Metadata Catalog
Purge Planner
Purge Executor
Purge Verifier
Retrieval Service
Integrity Service
Scheduler Jobs
HTTP API
Audit Integration
```

Initial log streams:

```text
platform_application_error
platform_access_log
platform_security_event
platform_audit_event
platform_integration_log
platform_scheduler_log
platform_queue_log
platform_incident_log
platform_debug_log
```

---

### 3. Final Folder Structure

```text
app/
└── Platform/
    └── Observability/
        └── Retention/
            ├── Domain/
            │   ├── LogStreamDefinition.php
            │   ├── RetentionPolicy.php
            │   ├── RetentionOverride.php
            │   ├── LegalHold.php
            │   ├── ArchivePlan.php
            │   ├── ArchiveBatch.php
            │   ├── ArchiveManifest.php
            │   ├── PurgePlan.php
            │   ├── PurgeBatch.php
            │   ├── PurgeEvidence.php
            │   ├── RetrievalRequest.php
            │   └── IntegrityCheck.php
            │
            ├── Application/
            │   ├── LogStreamRegistry.php
            │   ├── RetentionPolicyRegistry.php
            │   ├── RetentionPolicyService.php
            │   ├── RetentionEvaluator.php
            │   ├── LegalHoldService.php
            │   ├── ArchiveService.php
            │   ├── PurgeService.php
            │   ├── RetrievalService.php
            │   ├── IntegrityService.php
            │   └── Contracts/
            │
            ├── Infrastructure/
            │   ├── Persistence/
            │   ├── Archive/
            │   ├── Encryption/
            │   ├── Scheduler/
            │   ├── Audit/
            │   └── Telemetry/
            │
            └── Presentation/
                ├── Http/
                └── Cli/

config/
├── log-streams.php
├── retention-policies.php
├── archive-storage.php
└── retention-scheduler.php

database/
└── migrations/
    └── create_log_retention_tables.sql

resources/
├── retention/
├── archive-schemas/
└── runbooks/

storage/
└── log-archive/
    ├── manifests/
    ├── objects/
    ├── quarantine/
    └── retrieval/

tests/
├── Unit/
├── Integration/
└── Uat/

tools/
├── retention-simulation.php
├── archive-verify.php
├── purge-dry-run.php
└── archive-restore-test.php
```

---

### 4. Bootstrap Wiring

```php
<?php

declare(strict_types=1);

namespace App\Platform\Observability\Retention;

final class RetentionBootstrap
{
    public static function build(
        array $config,
        object $container
    ): RetentionKernel {
        $streamRegistry = new LogStreamRegistry();
        $policyRegistry = new RetentionPolicyRegistry();

        foreach ($config['stream_registrars'] as $registrarClass) {
            $container->get($registrarClass)->register(
                $streamRegistry
            );
        }

        foreach ($config['policy_registrars'] as $registrarClass) {
            $container->get($registrarClass)->register(
                $policyRegistry
            );
        }

        $holdResolver = new LegalHoldResolver(
            repository: $container->get(
                'retention.legal_hold_repository'
            )
        );

        $integrity = new IntegrityService(
            manifestRepository: $container->get(
                'retention.manifest_repository'
            ),
            signer: $container->get(
                'retention.manifest_signer'
            ),
            telemetry: $container->get(
                'retention.telemetry'
            )
        );

        $archive = new ArchiveService(
            sourceStore: $container->get(
                'retention.source_log_store'
            ),
            objectStore: $container->get(
                'retention.archive_object_store'
            ),
            catalog: $container->get(
                'retention.archive_catalog'
            ),
            manifests: $container->get(
                'retention.manifest_repository'
            ),
            holds: $holdResolver,
            integrity: $integrity,
            encryption: $container->get(
                'retention.encryption_service'
            ),
            audit: $container->get('audit.service'),
            telemetry: $container->get(
                'retention.telemetry'
            )
        );

        $purge = new PurgeService(
            sourceStore: $container->get(
                'retention.source_log_store'
            ),
            objectStore: $container->get(
                'retention.archive_object_store'
            ),
            catalog: $container->get(
                'retention.archive_catalog'
            ),
            holds: $holdResolver,
            evidence: $container->get(
                'retention.purge_evidence_repository'
            ),
            audit: $container->get('audit.service'),
            telemetry: $container->get(
                'retention.telemetry'
            )
        );

        return new RetentionKernel(
            streams: $streamRegistry,
            policies: $policyRegistry,
            evaluator: $container->get(
                'retention.policy_evaluator'
            ),
            legalHolds: $container->get(
                'retention.legal_hold_service'
            ),
            archive: $archive,
            purge: $purge,
            retrieval: $container->get(
                'retention.retrieval_service'
            ),
            integrity: $integrity
        );
    }
}
```

---

### 5. Log Stream Registrar

```php
interface LogStreamRegistrarInterface
{
    public function register(
        LogStreamRegistryInterface $registry
    ): void;
}
```

Module bisnis dapat mendaftarkan log stream tanpa mengubah Platform Kernel.

---

### 6. Retention Policy Registrar

```php
interface RetentionPolicyRegistrarInterface
{
    public function register(
        RetentionPolicyRegistryInterface $registry
    ): void;
}
```

---

### 7. Sample Stream — Application Error

```php
return [
    'code' => 'platform_application_error',
    'domain' => 'APPLICATION',
    'description' => 'Normalized production application errors.',
    'business_owner' => 'platform_operations',
    'technical_owner' => 'platform_kernel',
    'security_owner' => null,
    'sensitivity' => 'CONFIDENTIAL',
    'criticality' => 'HIGH',
    'purpose' => [
        'OPERATIONS',
        'INCIDENT_RESPONSE',
    ],
    'retention_class' => 'R2_STANDARD',
    'storage_class' => 'HOT',
    'tenant_scope' => 'TENANT_AWARE',
    'schema_version' => '1.0',
    'integrity_requirement' => 'CHECKSUM',
    'access_policy_code' => 'operations_log_access',
    'legal_hold_eligible' => true,
    'enabled' => true,
];
```

---

### 8. Sample Stream — Security Event

```php
return [
    'code' => 'platform_security_event',
    'domain' => 'SECURITY',
    'description' => 'Security-relevant normalized events.',
    'business_owner' => 'security',
    'technical_owner' => 'platform_security',
    'security_owner' => 'security_operations',
    'sensitivity' => 'SECURITY_RESTRICTED',
    'criticality' => 'CRITICAL',
    'purpose' => [
        'SECURITY',
        'INCIDENT_RESPONSE',
        'COMPLIANCE',
    ],
    'retention_class' => 'R3_EXTENDED',
    'storage_class' => 'HOT',
    'tenant_scope' => 'TENANT_AWARE',
    'schema_version' => '1.0',
    'integrity_requirement' => 'SIGNED_MANIFEST',
    'access_policy_code' => 'security_log_access',
    'legal_hold_eligible' => true,
    'enabled' => true,
];
```

---

### 9. Sample Stream — Audit Event

```php
return [
    'code' => 'platform_audit_event',
    'domain' => 'AUDIT',
    'description' => 'Immutable platform audit events.',
    'business_owner' => 'compliance',
    'technical_owner' => 'platform_kernel',
    'security_owner' => 'security',
    'sensitivity' => 'RESTRICTED',
    'criticality' => 'CRITICAL',
    'purpose' => [
        'AUDIT',
        'COMPLIANCE',
    ],
    'retention_class' => 'R4_REGULATED',
    'storage_class' => 'WARM',
    'tenant_scope' => 'TENANT_ISOLATED',
    'schema_version' => '1.0',
    'integrity_requirement' => 'WORM',
    'access_policy_code' => 'audit_log_access',
    'legal_hold_eligible' => true,
    'enabled' => true,
];
```

---

### 10. Sample Stream — Debug

```php
return [
    'code' => 'platform_debug_log',
    'domain' => 'DEBUG',
    'description' => 'Temporary diagnostic log.',
    'business_owner' => 'platform_engineering',
    'technical_owner' => 'platform_kernel',
    'security_owner' => null,
    'sensitivity' => 'INTERNAL',
    'criticality' => 'TEMPORARY',
    'purpose' => [
        'DEBUGGING',
    ],
    'retention_class' => 'R0_EPHEMERAL',
    'storage_class' => 'HOT',
    'tenant_scope' => 'TENANT_AWARE',
    'schema_version' => '1.0',
    'integrity_requirement' => 'STANDARD',
    'access_policy_code' => 'debug_log_access',
    'legal_hold_eligible' => false,
    'enabled' => false,
];
```

---

### 11. Sample Policy — Application Error

```php
return [
    'code' => 'application_error_standard',
    'title' => 'Application Error Standard Retention',
    'log_stream' => 'platform_application_error',
    'retention_class' => 'R2_STANDARD',
    'start_point' => 'EVENT_TIMESTAMP',
    'hot_duration' => '30d',
    'warm_duration' => '60d',
    'cold_duration' => '0d',
    'archive_duration' => '0d',
    'purge_after' => '90d',
    'legal_hold_eligible' => true,
    'integrity_requirement' => 'CHECKSUM',
    'owner' => 'platform_operations',
    'approver' => 'security_compliance',
    'effective_from' => '2026-07-01',
    'version' => '1.0',
    'status' => 'ACTIVE',
];
```

---

### 12. Sample Policy — Security Event

```php
return [
    'code' => 'security_event_extended',
    'title' => 'Security Event Extended Retention',
    'log_stream' => 'platform_security_event',
    'retention_class' => 'R3_EXTENDED',
    'start_point' => 'EVENT_TIMESTAMP',
    'hot_duration' => '90d',
    'warm_duration' => '275d',
    'cold_duration' => '0d',
    'archive_duration' => '2y',
    'purge_after' => '3y',
    'legal_hold_eligible' => true,
    'integrity_requirement' => 'SIGNED_MANIFEST',
    'owner' => 'security_operations',
    'approver' => 'security_compliance',
    'effective_from' => '2026-07-01',
    'version' => '1.0',
    'status' => 'ACTIVE',
];
```

---

### 13. Sample Policy — Audit Event

```php
return [
    'code' => 'audit_event_regulated',
    'title' => 'Audit Event Regulated Retention',
    'log_stream' => 'platform_audit_event',
    'retention_class' => 'R4_REGULATED',
    'start_point' => 'EVENT_TIMESTAMP',
    'hot_duration' => '0d',
    'warm_duration' => '1y',
    'cold_duration' => '0d',
    'archive_duration' => '6y',
    'purge_after' => '7y',
    'legal_hold_eligible' => true,
    'integrity_requirement' => 'WORM',
    'owner' => 'compliance',
    'approver' => 'legal_compliance',
    'effective_from' => '2026-07-01',
    'version' => '1.0',
    'status' => 'ACTIVE',
];
```

---

### 14. Sample Policy — Debug

```php
return [
    'code' => 'debug_ephemeral',
    'title' => 'Debug Ephemeral Retention',
    'log_stream' => 'platform_debug_log',
    'retention_class' => 'R0_EPHEMERAL',
    'start_point' => 'INGESTION_TIMESTAMP',
    'hot_duration' => '3d',
    'warm_duration' => '0d',
    'cold_duration' => '0d',
    'archive_duration' => '0d',
    'purge_after' => '3d',
    'legal_hold_eligible' => false,
    'integrity_requirement' => 'STANDARD',
    'owner' => 'platform_engineering',
    'approver' => 'platform_operations',
    'effective_from' => '2026-07-01',
    'version' => '1.0',
    'status' => 'ACTIVE',
];
```

---

### 15. Retention Evaluator Reference Flow

```php
final class RetentionEvaluator
{
    public function evaluate(
        LogStreamDefinition $stream,
        RetentionEvaluationContext $context
    ): RetentionDecision {
        $policy = $this->policies->findActiveByStream(
            $stream->code,
            $context->evaluatedAt
        );

        if ($policy === null) {
            return RetentionDecision::blocked(
                reason: 'NO_ACTIVE_POLICY'
            );
        }

        $override = $this->overrides->resolve(
            $stream,
            $context
        );

        $effectivePolicy = $override !== null
            ? $policy->withOverride($override)
            : $policy;

        return $this->calculator->calculate(
            stream: $stream,
            policy: $effectivePolicy,
            context: $context
        );
    }
}
```

---

### 16. Legal Hold Resolver Reference Flow

```php
final class LegalHoldResolver
{
    public function __construct(
        private readonly LegalHoldRepositoryInterface $repository
    ) {
    }

    public function resolve(
        LegalHoldMatchCriteria $criteria
    ): LegalHoldResolution {
        $matches = $this->repository->findActiveMatches(
            $criteria
        );

        if ($matches === []) {
            return LegalHoldResolution::clear();
        }

        return LegalHoldResolution::blocked($matches);
    }
}
```

---

### 17. Archive Service Reference Flow

```php
final class ArchiveService
{
    public function execute(
        string $planId,
        RetentionContext $context
    ): ArchiveBatch {
        $plan = $this->plans->findById($planId);

        if ($plan === null) {
            throw new ArchivePlanNotFoundException();
        }

        $hold = $this->holds->resolve(
            LegalHoldMatchCriteria::fromArchivePlan($plan)
        );

        if ($hold->isBlocked()) {
            throw new ArchiveBlockedByLegalHoldException();
        }

        $batch = ArchiveBatch::start(
            id: $this->ids->ulid(),
            planId: $plan->id,
            startedAt: $this->clock->now()
        );

        $this->batches->save($batch);

        $records = $this->sourceStore->stream(
            $plan->sourceCriteria()
        );

        $archiveObjects = $this->writer->write(
            records: $records,
            batch: $batch,
            policy: $plan->policy
        );

        $manifest = $this->manifestFactory->create(
            batch: $batch,
            objects: $archiveObjects
        );

        $this->manifests->save($manifest);

        $verification = $this->integrity->verifyManifest(
            $manifest
        );

        if (!$verification->passed) {
            $batch = $batch->fail(
                code: 'ARCHIVE_VERIFICATION_FAILED',
                message: 'Archive verification failed.'
            );

            $this->batches->save($batch);

            throw new ArchiveVerificationException();
        }

        $batch = $batch->complete(
            recordCount: $manifest->recordCount,
            objectCount: $manifest->objectCount,
            completedAt: $this->clock->now()
        );

        $this->batches->save($batch);

        $this->audit->record(
            'OBS_LOG_ARCHIVE_EXECUTED',
            [
                'archive_batch_id' => $batch->id,
                'record_count' => $batch->recordCount,
                'object_count' => $batch->objectCount,
            ]
        );

        return $batch;
    }
}
```

---

### 18. Purge Service Reference Flow

```php
final class PurgeService
{
    public function execute(
        string $planId,
        RetentionContext $context
    ): PurgeBatch {
        $plan = $this->plans->findById($planId);

        if ($plan === null) {
            throw new PurgePlanNotFoundException();
        }

        $this->access->assertCanExecute($plan, $context);

        if ($plan->approvalRequired && !$plan->isApproved()) {
            throw new PurgeApprovalRequiredException();
        }

        $hold = $this->holds->resolve(
            LegalHoldMatchCriteria::fromPurgePlan($plan)
        );

        if ($hold->isBlocked()) {
            throw new PurgeBlockedByLegalHoldException();
        }

        $eligibility = $this->eligibility->evaluate($plan);

        if (!$eligibility->eligible) {
            throw new PurgePlanInvalidException(
                $eligibility->reason
            );
        }

        $batch = PurgeBatch::start(
            id: $this->ids->ulid(),
            planId: $plan->id,
            startedAt: $this->clock->now()
        );

        $this->batches->save($batch);

        $result = $this->executor->delete(
            $plan->scope,
            $plan->policy
        );

        $verification = $this->verifier->verify(
            $plan,
            $result
        );

        $evidence = PurgeEvidence::create(
            id: $this->ids->ulid(),
            batchId: $batch->id,
            policyCode: $plan->policyCode,
            scope: $plan->scope,
            recordsDeleted: $result->recordsDeleted,
            objectsDeleted: $result->objectsDeleted,
            verificationMethod: $verification->method,
            verificationResult: $verification->status,
            evidenceHash: $verification->evidenceHash,
            executedBy: $context->actorReference,
            startedAt: $batch->startedAt,
            completedAt: $this->clock->now()
        );

        $this->evidence->save($evidence);

        $batch = $batch->complete(
            recordsDeleted: $result->recordsDeleted,
            objectsDeleted: $result->objectsDeleted,
            verificationStatus: $verification->status,
            completedAt: $this->clock->now()
        );

        $this->batches->save($batch);

        $this->audit->record(
            'OBS_LOG_PURGE_EXECUTED',
            [
                'purge_batch_id' => $batch->id,
                'records_deleted' => $result->recordsDeleted,
                'objects_deleted' => $result->objectsDeleted,
            ]
        );

        return $batch;
    }
}
```

---

### 19. Archive Writer Reference

```php
final class NdjsonArchiveWriter
{
    public function write(
        iterable $records,
        ArchiveBatch $batch,
        RetentionPolicy $policy
    ): array {
        $objects = [];
        $buffer = new ArchiveBuffer(
            maximumUncompressedBytes: 256 * 1024 * 1024
        );

        foreach ($records as $record) {
            $buffer->append(
                $this->canonicalizer->toNdjsonLine($record)
            );

            if ($buffer->isFull()) {
                $objects[] = $this->flush(
                    $buffer,
                    $batch,
                    $policy
                );
            }
        }

        if (!$buffer->isEmpty()) {
            $objects[] = $this->flush(
                $buffer,
                $batch,
                $policy
            );
        }

        return $objects;
    }
}
```

---

### 20. Archive Object Creation

```php
private function flush(
    ArchiveBuffer $buffer,
    ArchiveBatch $batch,
    RetentionPolicy $policy
): ArchiveObjectReference {
    $compressed = $this->compressor->compress(
        $buffer->contents()
    );

    $encrypted = $this->encryption->encrypt(
        plaintext: $compressed,
        keyPolicy: $policy->encryptionPolicy()
    );

    $checksum = hash('sha256', $encrypted->ciphertext);

    return $this->objectStore->put(
        ArchiveObject::create(
            batchId: $batch->id,
            ciphertext: $encrypted->ciphertext,
            checksum: $checksum,
            encryptionKeyReference: $encrypted->keyReference
        ),
        ArchiveWriteContext::system()
    );
}
```

---

### 21. Retrieval Service Reference Flow

```php
final class RetrievalService
{
    public function restore(
        string $requestId,
        RetentionContext $context
    ): RetrievalWorkspace {
        $request = $this->requests->findById($requestId);

        if ($request === null) {
            throw new RetrievalRequestNotFoundException();
        }

        $this->access->assertCanRestore($request, $context);

        if (!$request->isApproved()) {
            throw new RetrievalApprovalRequiredException();
        }

        if ($request->isExpired($this->clock->now())) {
            throw new RetrievalExpiredException();
        }

        $entries = $this->catalog->find(
            ArchiveSearchCriteria::fromRequest($request)
        );

        $workspace = RetrievalWorkspace::create(
            id: $this->ids->ulid(),
            requestId: $request->id,
            classification: $request->classification,
            expiresAt: $request->expiresAt
        );

        $this->workspaces->save($workspace);

        foreach ($entries as $entry) {
            $stream = $this->objectStore->get(
                $entry->objectReference(),
                ArchiveReadContext::from($context)
            );

            $this->integrity->verifyStream(
                $stream,
                $entry->checksum
            );

            $plaintext = $this->encryption->decrypt(
                $stream,
                $entry->encryptionKeyReference
            );

            $decompressed = $this->compressor->decompress(
                $plaintext
            );

            $this->workspaceLoader->load(
                $workspace,
                $decompressed
            );
        }

        $workspace = $workspace->markAvailable();

        $this->workspaces->save($workspace);

        return $workspace;
    }
}
```

---

### 22. Scheduler Wiring

```php
$scheduler->hourly(
    'log-retention:evaluate',
    LogRetentionPolicyEvaluationJob::class
);

$scheduler->dailyAt(
    '00:15',
    'log-archive:plan',
    LogArchivePlanningJob::class
);

$scheduler->everyFifteenMinutes(
    'log-archive:execute',
    LogArchiveExecutionJob::class
);

$scheduler->everyFifteenMinutes(
    'log-archive:verify',
    LogArchiveVerificationJob::class
);

$scheduler->dailyAt(
    '01:00',
    'log-purge:plan',
    LogPurgePlanningJob::class
);

$scheduler->dailyAt(
    '02:00',
    'log-purge:execute',
    LogPurgeExecutionJob::class
);

$scheduler->everyFifteenMinutes(
    'log-purge:verify',
    LogPurgeVerificationJob::class
);

$scheduler->everyFiveMinutes(
    'log-legal-hold:reconcile',
    LogLegalHoldReconciliationJob::class
);

$scheduler->hourly(
    'log-retrieval:expire',
    LogRetrievalExpiryJob::class
);

$scheduler->dailyAt(
    '03:00',
    'log-integrity:check',
    LogArchiveIntegrityCheckJob::class
);

$scheduler->dailyAt(
    '23:00',
    'log-partition:maintain',
    LogPartitionMaintenanceJob::class
);

$scheduler->everyFifteenMinutes(
    'log-storage:capacity-check',
    LogStorageCapacityCheckJob::class
);
```

---

### 23. Windows Task Scheduler

Untuk XAMPP/Windows:

```bat
D:\xampp\php\php.exe D:\xampp\htdocs\platform\bin\console scheduler:run
```

Schedule:

```text
Repeat task every: 1 minute
Duration: Indefinitely
Run whether user is logged on or not
```

---

### 24. Initial Migration Order

```text
1. log_stream_definitions
2. log_retention_policies
3. log_retention_policy_versions
4. log_retention_overrides
5. log_legal_holds
6. log_legal_hold_scopes
7. log_archive_plans
8. log_archive_batches
9. log_archive_objects
10. log_archive_manifests
11. log_purge_plans
12. log_purge_batches
13. log_purge_evidence
14. log_retrieval_requests
15. log_retrieval_workspaces
16. log_integrity_checks
17. log_chain_of_custody_events
18. log_retention_exceptions
19. log_scheduler_runs
```

---

### 25. Seed Permissions

```text
observability.log.read
observability.log.search
observability.log.restricted.read
observability.log.security.read
observability.log.export
observability.log.retention.read
observability.log.retention.manage
observability.log.retention.approve
observability.log.archive.read
observability.log.archive.execute
observability.log.archive.verify
observability.log.purge.plan
observability.log.purge.approve
observability.log.purge.execute
observability.log.legal_hold.read
observability.log.legal_hold.manage
observability.log.retrieval.request
observability.log.retrieval.approve
observability.log.retrieval.access
observability.log.integrity.verify
observability.log.exception.manage
observability.log.cross_tenant.read
```

---

### 26. Role Mapping

| Role | Permission Utama |
|---|---|
| Platform Admin | operational retention |
| Operations Admin | archive dan operational purge |
| Security Admin | security log dan legal hold |
| Compliance | audit retention dan approval |
| Legal | legal hold create/release |
| Tenant Admin | tenant-specific metadata terbatas |
| Module Owner | stream module terkait |
| Auditor | approved read-only access |
| End User | tidak ada akses teknis |

---

### 27. Deployment Checklist

#### Pre-Deployment

- [ ] Backup database tersedia.
- [ ] Migration direview.
- [ ] Stream definitions divalidasi.
- [ ] Retention policies divalidasi.
- [ ] Archive folder/object storage tersedia.
- [ ] Encryption key reference tersedia.
- [ ] Legal hold permission tersedia.
- [ ] Scheduler config siap.
- [ ] Storage quota tersedia.
- [ ] Unit test lulus.
- [ ] Integration test lulus.
- [ ] Security review lulus.
- [ ] Dry-run archive dan purge lulus.

#### Deployment

1. Aktifkan maintenance bila diperlukan.
2. Deploy code.
3. Jalankan migration.
4. Seed permissions.
5. Register stream definitions.
6. Register retention policies.
7. Verifikasi archive storage.
8. Verifikasi encryption.
9. Jalankan policy simulation.
10. Jalankan archive dry run.
11. Jalankan purge dry run.
12. Aktifkan scheduler.
13. Aktifkan policy secara bertahap.
14. Nonaktifkan maintenance.

#### Post-Deployment

- [ ] Policy evaluator berjalan.
- [ ] Archive planner berjalan.
- [ ] Archive object dapat dibuat.
- [ ] Manifest dapat diverifikasi.
- [ ] Legal hold memblokir purge.
- [ ] Purge evidence dapat dibuat.
- [ ] Retrieval workspace auto-expire.
- [ ] Audit event tercatat.
- [ ] Capacity metric aktif.
- [ ] Tidak ada secret pada log.

---

### 28. Policy Activation Strategy

Tahapan:

```text
DRAFT
→ REVIEW
→ SIMULATION
→ MONITOR
→ ENFORCE
```

#### Simulation

- tidak mengubah data;
- menghitung tier transition;
- menghitung purge eligibility;
- menampilkan hold conflict.

#### Monitor

- policy aktif sebagai warning;
- tidak melakukan destructive action.

#### Enforce

- archive dan purge berjalan sesuai policy.

---

### 29. Rollback Plan

1. Suspend affected retention policies.
2. Stop purge scheduler.
3. Keep archive scheduler optional.
4. Preserve all metadata and evidence.
5. Rollback code.
6. Restore previous policy config.
7. Restore previous scheduler config.
8. Verify legal holds.
9. Verify archive catalog.
10. Re-run policy simulation.
11. Re-enable in monitor mode.

Jangan rollback dengan menghapus archive atau evidence.

---

### 30. Emergency Kill Switch

Config:

```text
LOG_RETENTION_ENABLED=true
LOG_ARCHIVE_ENABLED=true
LOG_PURGE_ENABLED=true
LOG_RETRIEVAL_ENABLED=true
LOG_INTEGRITY_CHECK_ENABLED=true
```

`LOG_PURGE_ENABLED=false` adalah emergency stop utama untuk destructive action.

Penggunaan wajib:

- permission;
- reason;
- audit;
- review;
- compensating monitoring.

---

### 31. Performance Test Plan

Test scenarios:

```text
100.000 records/day
1.000.000 records/day
10.000.000 records/day
high tenant concurrency
archive large batch
purge large partition
catalog search
retrieval restore
integrity verification
legal hold overlap
```

---

### 32. Performance Acceptance

| Area | Target |
|---|---:|
| Stream registry lookup | < 10 ms |
| Policy resolution | < 25 ms |
| Legal hold match | < 200 ms |
| Archive plan | < 2 s |
| Archive throughput | workload-based |
| Manifest verification | workload-based |
| Purge plan | < 5 s bounded scope |
| Purge enqueue | < 500 ms |
| Catalog search | < 750 ms |
| Retrieval request | < 750 ms |
| Workspace metadata query | < 500 ms |

---

### 33. Archive Throughput Target

Initial target:

```text
minimum 50–200 MB/minute
```

tergantung:

- compression;
- encryption;
- disk;
- object storage;
- CPU;
- network.

---

### 34. Purge Throughput Target

Partition drop jauh lebih cepat daripada row delete.

Target harus dibedakan:

```text
partition drop
row batch delete
object delete
cryptographic erasure
```

---

### 35. Archive Stress Test

Input:

```text
10 million normalized log records
```

Expected:

- bounded batches;
- object size sesuai policy;
- no memory exhaustion;
- manifest valid;
- checksum valid;
- source tidak dihapus sebelum verification;
- scheduler heartbeat aktif;
- retry idempotent.

---

### 36. Legal Hold Simulation

#### Trigger

Legal hold aktif untuk:

```text
tenant_id = 10
stream = platform_security_event
range = June 2026
```

Expected:

- archive tetap dapat berjalan jika policy mengizinkan;
- purge diblokir;
- hold conflict tercatat;
- metric meningkat;
- audit tersedia;
- no data deletion.

---

### 37. Archive Simulation

#### Input

```text
platform_application_error
age > 30 days
```

Expected:

1. Policy ditemukan.
2. Data eligible HOT→WARM/archive.
3. Archive plan dibuat.
4. Hold check lulus.
5. Data dibaca dalam batch.
6. NDJSON dibuat.
7. Compression dijalankan.
8. Encryption dijalankan.
9. Object disimpan.
10. Manifest dibuat.
11. Checksum diverifikasi.
12. Catalog entry dibuat.
13. Source deletion menunggu policy/grace period.

---

### 38. Purge Simulation

#### Input

```text
platform_debug_log
age > 3 days
no legal hold
```

Expected:

1. Purge plan dibuat.
2. Dry run menghasilkan estimate.
3. Hold check clear.
4. Purge dieksekusi.
5. Data tidak dapat ditemukan.
6. Deletion evidence dibuat.
7. Audit event tercatat.
8. Storage usage turun.

---

### 39. Purge Blocked Simulation

#### Input

```text
audit log age > retention
active legal hold
```

Expected:

```text
LOG_PURGE_BLOCKED_BY_LEGAL_HOLD
```

Selain itu:

- no deletion;
- hold reference tercatat aman;
- alert optional;
- audit tersedia.

---

### 40. Integrity Failure Simulation

#### Trigger

Checksum object diubah.

Expected:

- verification FAILED;
- archive status SUSPECT;
- purge source diblokir;
- alert SEV1/SEV2;
- incident bila critical;
- object dipindahkan ke quarantine bila perlu;
- evidence dipertahankan.

---

### 41. Retrieval Simulation

#### Input

Approved retrieval request untuk archived application logs.

Expected:

1. Catalog menemukan object.
2. Access dan tenant scope valid.
3. Object diambil.
4. Checksum diverifikasi.
5. Object didekripsi.
6. Object didekompresi.
7. Schema divalidasi.
8. Workspace dibuat.
9. Access diaudit.
10. Workspace auto-expire.

---

### 42. Cross-Tenant Access Simulation

Request:

```text
Tenant Admin A mengakses archive Tenant B
```

Expected:

```text
HTTP 403
```

Selain itu:

- no metadata leak;
- no object key leak;
- no tenant name leak;
- audit access denied.

---

### 43. Storage Failure Simulation

Simulasikan:

- disk full;
- object storage timeout;
- permission denied;
- encryption key unavailable;
- catalog database unavailable.

Expected:

- no source deletion;
- batch FAILED;
- retry bounded;
- alert;
- audit;
- recoverable state.

---

### 44. Operational Runbook — Archive Failed

1. Cek archive batch.
2. Cek error code.
3. Cek storage availability.
4. Cek key access.
5. Cek source data.
6. Cek legal hold conflict.
7. Cek object partial upload.
8. Jalankan retry idempotent.
9. Verifikasi manifest.
10. Dokumentasikan hasil.

---

### 45. Operational Runbook — Purge Blocked

1. Cek legal hold matches.
2. Cek retention override.
3. Cek regulatory freeze.
4. Cek policy status.
5. Cek approval.
6. Cek integrity state.
7. Jangan bypass hold.
8. Eskalasi ke Legal/Compliance jika perlu.
9. Re-run dry run setelah clear.
10. Audit keputusan.

---

### 46. Operational Runbook — Integrity Failure

1. Stop source deletion.
2. Mark archive SUSPECT.
3. Verify checksum ulang.
4. Cek manifest signature.
5. Cek replica.
6. Cek encryption/decryption.
7. Pindahkan ke quarantine bila perlu.
8. Buat incident.
9. Rebuild archive jika source tersedia.
10. Catat chain of custody.

---

### 47. Operational Runbook — Retrieval Failure

1. Cek request approval.
2. Cek request expiry.
3. Cek catalog entry.
4. Cek object existence.
5. Cek key reference.
6. Cek checksum.
7. Cek compression format.
8. Cek workspace capacity.
9. Cleanup partial restore.
10. Retry atau eskalasi.

---

### 48. Backup & Restore

Backup:

- stream definitions;
- retention policies;
- legal holds;
- overrides;
- archive catalog;
- manifests;
- purge evidence;
- retrieval requests;
- integrity checks;
- chain of custody;
- scheduler state;
- key metadata reference.

Restore wajib menguji:

- foreign keys;
- policy history;
- legal hold scope;
- object reference;
- manifest checksum;
- tenant ownership;
- evidence immutability;
- key accessibility.

---

### 49. Retention of Retention Metadata

| Data | Retention |
|---|---|
| Policy history | permanent/long-term |
| Legal hold records | 7+ years or legal |
| Archive manifests | same as archive + buffer |
| Purge evidence | 5–7 years |
| Retrieval requests | 1–3 years |
| Integrity checks | 1–3 years |
| Scheduler runs | 90 days–1 year |
| Exceptions | 2–5 years |

---

### 50. Final UAT — Registry & Policy

- [ ] Stream registry bekerja.
- [ ] Stream code unik.
- [ ] Policy registry bekerja.
- [ ] Active policy dapat di-resolve.
- [ ] Duration parser bekerja.
- [ ] Policy versioning bekerja.
- [ ] Simulation bekerja.
- [ ] Orphaned stream terdeteksi.
- [ ] Policy conflict diblokir.
- [ ] Monitor→Enforce transition bekerja.

---

### 51. Final UAT — Legal Hold

- [ ] Hold dapat dibuat.
- [ ] Hold dapat diaktifkan.
- [ ] Hold scope match akurat.
- [ ] Purge diblokir.
- [ ] Release membutuhkan approval.
- [ ] Four-eyes bekerja.
- [ ] Post-release policy dihitung ulang.
- [ ] Hold changes diaudit.
- [ ] Cross-tenant hold dibatasi.
- [ ] Regulatory freeze diprioritaskan.

---

### 52. Final UAT — Archive

- [ ] Archive plan dibuat.
- [ ] Batch bounded.
- [ ] NDJSON valid.
- [ ] Compression berhasil.
- [ ] Encryption berhasil.
- [ ] Object naming aman.
- [ ] Manifest dibuat.
- [ ] Checksum diverifikasi.
- [ ] Catalog entry dibuat.
- [ ] Source tidak dihapus sebelum verification.
- [ ] Retry idempotent.
- [ ] Failed object masuk quarantine bila perlu.

---

### 53. Final UAT — Purge

- [ ] Dry run bekerja.
- [ ] Eligibility benar.
- [ ] Approval-required mode bekerja.
- [ ] Four-eyes diterapkan.
- [ ] Legal hold final check bekerja.
- [ ] Partial purge terdeteksi.
- [ ] Retry aman.
- [ ] Deletion verification bekerja.
- [ ] Evidence dibuat.
- [ ] Evidence tidak menyimpan raw log.
- [ ] Partition drop diaudit.
- [ ] Object versions diproses sesuai policy.

---

### 54. Final UAT — Retrieval

- [ ] Request memiliki purpose.
- [ ] Approval bekerja.
- [ ] Catalog search tepat.
- [ ] Object checksum diverifikasi.
- [ ] Decrypt/decompress berhasil.
- [ ] Schema validation bekerja.
- [ ] Workspace isolated.
- [ ] Workspace auto-expire.
- [ ] Access diaudit.
- [ ] Cross-tenant access ditolak.

---

### 55. Final UAT — Security

- [ ] Archive tidak berada di public path.
- [ ] Encryption in transit aktif.
- [ ] Encryption at rest aktif.
- [ ] Raw key tidak tersimpan.
- [ ] Object key tidak bocor.
- [ ] Signed URL expire.
- [ ] Restricted archive dibatasi.
- [ ] Legal hold tidak dapat dibypass.
- [ ] CSRF aktif.
- [ ] Rate limit aktif.
- [ ] Privileged actions diaudit.
- [ ] PHI/PII tidak muncul pada metadata umum.

---

### 56. Final UAT — Scheduler

- [ ] Policy evaluator berjalan.
- [ ] Archive planner berjalan.
- [ ] Archive executor berjalan.
- [ ] Archive verifier berjalan.
- [ ] Purge planner berjalan.
- [ ] Purge executor berjalan.
- [ ] Purge verifier berjalan.
- [ ] Hold reconciler berjalan.
- [ ] Retrieval expiry berjalan.
- [ ] Integrity checker berjalan.
- [ ] Partition maintainer berjalan.
- [ ] Capacity monitor berjalan.
- [ ] Stuck job terdeteksi.
- [ ] Job lock bekerja.
- [ ] Idempotency bekerja.

---

### 57. Final UAT — Performance & Recovery

- [ ] Archive throughput memenuhi target.
- [ ] No memory exhaustion.
- [ ] Catalog search memenuhi target.
- [ ] Legal hold match memenuhi target.
- [ ] Purge bounded.
- [ ] Capacity alert bekerja.
- [ ] Restore test berhasil.
- [ ] Replica archive dapat digunakan.
- [ ] Key recovery diuji.
- [ ] RPO/RTO diuji.
- [ ] Rollback berhasil.
- [ ] Emergency kill switch diuji.

---

### 58. Production Readiness Checklist

- [ ] Semua stream memiliki owner.
- [ ] Semua stream memiliki policy.
- [ ] Retention periods disetujui.
- [ ] Legal hold workflow tersedia.
- [ ] Archive storage tersedia.
- [ ] Encryption dan key management siap.
- [ ] Manifest signing siap.
- [ ] Purge evidence siap.
- [ ] Retrieval workspace siap.
- [ ] Scheduler aktif.
- [ ] Audit aktif.
- [ ] Capacity dashboard aktif.
- [ ] Backup/restore diuji.
- [ ] Simulation lulus.
- [ ] Performance test lulus.
- [ ] Security review lulus.
- [ ] Compliance sign-off tersedia.
- [ ] Operations sign-off tersedia.

---

### 59. Ownership Matrix

| Area | Owner |
|---|---|
| Retention Framework | Platform Kernel Team |
| Stream Definitions | Module/Service Owner |
| Retention Policy | Data Governance/Owner |
| Legal Hold | Legal/Compliance |
| Archive Storage | Platform Operations |
| Encryption/Keys | Security Team |
| Purge Operations | Platform Operations |
| Integrity Verification | Security/Compliance |
| Retrieval | Operations + Data Owner |
| Audit Integration | Security/Compliance |
| Database Schema | Platform Data Team |

---

### 60. Definition of Done — SSOT-OBS-08

#### Architecture

- [ ] log classification;
- [ ] retention classes;
- [ ] storage classes;
- [ ] ownership;
- [ ] tenant/scope model;
- [ ] privacy/security boundary.

#### Retention & Legal Hold

- [ ] policy model;
- [ ] versioning;
- [ ] start point;
- [ ] override;
- [ ] legal hold;
- [ ] conflict resolution;
- [ ] exception handling.

#### Archive & Purge

- [ ] tier transition;
- [ ] archive plan;
- [ ] archive batch;
- [ ] manifest;
- [ ] checksum;
- [ ] purge plan;
- [ ] deletion verification;
- [ ] purge evidence;
- [ ] chain of custody.

#### Storage

- [ ] partitioning;
- [ ] indexing;
- [ ] compression;
- [ ] encryption;
- [ ] key management;
- [ ] metadata catalog;
- [ ] retrieval workspace;
- [ ] backup/DR.

#### Infrastructure

- [ ] HTTP API;
- [ ] controllers;
- [ ] middleware;
- [ ] permission;
- [ ] database schema;
- [ ] scheduler;
- [ ] audit;
- [ ] Apache/XAMPP routing.

#### Operations

- [ ] reference implementation;
- [ ] sample policies;
- [ ] deployment;
- [ ] rollback;
- [ ] simulation;
- [ ] performance test;
- [ ] operational runbooks;
- [ ] final UAT.

---

### 61. Implementation Definition of Done

Implementasi dianggap selesai bila:

- [ ] core classes dibuat;
- [ ] migrations berhasil;
- [ ] stream definitions aktif;
- [ ] retention policies aktif;
- [ ] legal hold service aktif;
- [ ] archive storage aktif;
- [ ] encryption aktif;
- [ ] archive manifest aktif;
- [ ] purge service aktif;
- [ ] purge evidence aktif;
- [ ] retrieval service aktif;
- [ ] scheduler aktif;
- [ ] audit aktif;
- [ ] unit test lulus;
- [ ] integration test lulus;
- [ ] UAT lulus;
- [ ] simulation lulus;
- [ ] performance target tercapai;
- [ ] security review lulus;
- [ ] compliance review lulus;
- [ ] deployment/rollback diuji.

---

### 62. Roadmap

#### Phase 1 — Foundation

- stream registry;
- retention policy;
- local archive;
- checksum;
- basic purge;
- legal hold basic.

#### Phase 2 — Controlled Operations

- signed manifest;
- retrieval workflow;
- approval workflow;
- partition automation;
- deletion evidence;
- dashboards.

#### Phase 3 — Enterprise Archive

- object storage;
- WORM;
- per-tenant encryption;
- cross-region replication;
- legal hold advanced;
- chain of custody.

#### Phase 4 — Intelligence & Optimization

- cost forecasting;
- adaptive tiering;
- retention recommendation;
- policy anomaly detection;
- predictive capacity;
- automated compliance evidence.

---

### 63. Future Evolution

- S3-compatible object storage;
- immutable bucket/WORM;
- hardware-backed key management;
- per-tenant encryption key;
- automatic schema migration on retrieval;
- policy-as-code validation;
- compliance retention packs;
- storage cost dashboard;
- legal hold case integration;
- automated signed deletion certificate;
- archive integrity ledger;
- cross-region archive replication;
- AI-assisted retention policy review.

---

### 64. Merge Guidance

Gabungkan:

```text
SSOT-OBS-08-Part-1.md
SSOT-OBS-08-Part-2.md
SSOT-OBS-08-Part-3.md
SSOT-OBS-08-Part-4.md
SSOT-OBS-08-Part-5.md
```

menjadi:

```text
SSOT-OBS-08.md
```

Urutan:

```text
Part 1 — Vision, Classification, Principles, Ownership
Part 2 — Retention, Legal Hold, Archive, Purge, Integrity
Part 3 — Storage Architecture, Encryption, Retrieval, DR
Part 4 — API, Scheduler, Database, Audit, Security
Part 5 — Reference Implementation & Operations
```

---

### 65. Merge Quality Checklist

- [ ] heading tidak duplikat;
- [ ] classification konsisten;
- [ ] retention class konsisten;
- [ ] storage class konsisten;
- [ ] legal hold state konsisten;
- [ ] archive/purge state konsisten;
- [ ] permission konsisten;
- [ ] table names konsisten;
- [ ] namespace konsisten;
- [ ] endpoint konsisten;
- [ ] error code konsisten;
- [ ] policy field konsisten;
- [ ] duplicate section dihapus;
- [ ] daftar isi dibuat;
- [ ] metadata final diperbarui;
- [ ] status final diset Review/Approved.

---

### 66. Final Metadata

```yaml
document_code: SSOT-OBS-08
title: Log Retention & Archiving Framework
version: 1.0
status: Draft for Review
domain: Platform Kernel
category: Observability
owners:
  - Platform Architecture
  - Platform Operations
  - Security
  - Data Governance
reviewers:
  - Backend Engineering
  - DevOps
  - QA
  - Security
  - Compliance
  - Legal
```

---

### 67. Approval Gate

Dokumen dapat menjadi Approved setelah:

- architecture review;
- storage architecture review;
- security review;
- privacy review;
- compliance review;
- legal review;
- database review;
- key management review;
- archive/retrieval review;
- QA/UAT review;
- performance review;
- deployment/rollback review;
- restore simulation review;
- purge verification review.

---

### 68. Closing Statement

Log Retention & Archiving Framework harus memastikan data log:

- tersedia saat dibutuhkan;
- tidak disimpan lebih lama dari kebutuhan;
- tidak dihapus sebelum waktunya;
- dapat ditahan melalui legal hold;
- tetap terenkripsi;
- dapat diverifikasi integritasnya;
- dapat dipurge dengan bukti;
- tidak bocor lintas tenant.

Framework tidak boleh:

- menyimpan seluruh log selamanya;
- menjalankan purge tanpa hold check;
- menghapus source sebelum archive terverifikasi;
- menyimpan archive pada public path;
- membocorkan raw key;
- mengabaikan privacy;
- membuat legal hold yang dapat dibypass;
- menghasilkan deletion evidence yang tidak dapat diaudit.

Framework harus mengubah retention dari kebijakan tertulis menjadi lifecycle yang dapat dijalankan, diamati, diverifikasi, dan diaudit.

---

## Lampiran A — Sumber Penggabungan

Dokumen final ini digabung dan dinormalisasi dari:

- `SSOT-OBS-08-Part-1.md`
- `SSOT-OBS-08-Part-2.md`
- `SSOT-OBS-08-Part-3.md`
- `SSOT-OBS-08-Part-4.md`
- `SSOT-OBS-08-Part-5.md`

## Lampiran B — Approval Gate

Status dokumen dapat diubah menjadi **Approved** setelah:

- architecture review selesai;
- storage architecture review selesai;
- security review selesai;
- privacy review selesai;
- compliance review selesai;
- legal review selesai;
- database schema disetujui;
- key management review selesai;
- archive dan retrieval review selesai;
- permission dan tenant/scope policy disetujui;
- QA/UAT review selesai;
- performance review selesai;
- restore simulation selesai;
- purge verification review selesai;
- deployment dan rollback review selesai.
