
# SSOT-OBS-01 — Observability Architecture

## Status

| Item | Nilai |
|---|---|
| Kode | SSOT-OBS-01 |
| Versi | 1.0 |
| Domain | Platform Kernel / Observability |
| Status | Draft Architecture |
| Bergantung pada | SSOT-AUDIT, SSOT-EVENT, SSOT-API, SSOT-WF, SSOT-INTEGRATION |

---

# 1. Tujuan

Observability memastikan kondisi platform dapat dipahami berdasarkan data operasional yang dihasilkan aplikasi.

Observability **bukan hanya logging**, tetapi kemampuan menjawab:

- Apa yang terjadi?
- Mengapa terjadi?
- Siapa yang terdampak?
- Di mana kegagalan terjadi?
- Kapan mulai terjadi?
- Bagaimana cara mereproduksi masalah?

---

# 2. Pilar Observability

Platform menggunakan lima pilar:

1. Structured Logging
2. Metrics
3. Tracing
4. Health Check
5. Audit Trail

Audit Trail tetap menjadi domain kepatuhan, bukan pengganti log teknis.

---

# 3. Arsitektur

```text
Browser / Mobile
        │
        ▼
 API / Web
        │
        ▼
Middleware
        │
        ▼
Application Service
        │
        ├──────────────┐
        ▼              ▼
 Repository        Audit Logger
        │              │
        ▼              ▼
 Database        Audit Store
        │
        ▼
Domain Event
        │
        ├──────────────┐
        ▼              ▼
Metrics        Structured Log
        │              │
        └──────┬───────┘
               ▼
      Monitoring Dashboard
```

---

# 4. Correlation ID

Setiap request wajib memiliki:

- correlation_id
- request_id

Correlation ID harus diteruskan ke:

- log
- audit
- event
- integration
- notification
- background job

---

# 5. Logging Rule

Seluruh log harus berbentuk structured log.

Minimal field:

- timestamp
- level
- message
- correlation_id
- request_id
- tenant_id
- business_entity_id
- user_id
- module
- action
- duration_ms

Jangan mencatat password, token, OTP, atau secret.

---

# 6. Metric Rule

Metric digunakan untuk pengukuran.

Contoh:

- api_request_total
- login_success_total
- login_failed_total
- workflow_transition_total
- integration_retry_total
- homecare_visit_completed_total

---

# 7. Tracing Rule

Trace menggambarkan perjalanan request.

Contoh:

```text
Request
→ Auth
→ Scope
→ RBAC
→ Controller
→ Service
→ Repository
→ Database
→ Event
→ Response
```

---

# 8. Health Check

Health check minimum:

- aplikasi hidup
- database
- storage
- queue
- scheduler
- file storage

Endpoint internal:

```text
GET /health
```

Response:

```json
{
  "status":"ok",
  "database":"ok",
  "storage":"ok"
}
```

---

# 9. Severity

Gunakan level:

- DEBUG
- INFO
- NOTICE
- WARNING
- ERROR
- CRITICAL

---

# 10. Dashboard

Dashboard minimum menampilkan:

- request per menit
- error rate
- latency
- login gagal
- integration failure
- queue backlog
- scheduler status

---

# 11. Database

## observability_logs

Minimal:

- id
- correlation_id
- request_id
- level
- module
- action
- message
- context_json
- created_at

## observability_metrics

Minimal:

- metric_name
- metric_value
- labels_json
- collected_at

---

# 12. Integrasi

Observability harus terhubung dengan:

- Audit
- Workflow
- Notification
- Event Bus
- Integration Framework
- Search
- File Storage

---

# 13. Alert

Alert dipicu untuk:

- ERROR berulang
- CRITICAL
- database gagal
- queue macet
- retry melebihi batas
- storage hampir penuh

---

# 14. Anti-pattern

Hindari:

- log plaintext password
- log tanpa correlation_id
- memakai audit sebagai log teknis
- memakai log sebagai event bisnis
- metric tanpa definisi
- trace tidak lengkap

---

# 15. UAT

- Semua request memiliki correlation_id.
- Log terhubung dengan audit dan event.
- Health check mengembalikan status benar.
- Dashboard menampilkan metric utama.
- Alert aktif pada kondisi kritis.

---

# 16. Definition of Done

Observability dianggap siap bila:

- structured logging aktif;
- correlation ID diterapkan;
- metrics tersedia;
- health check tersedia;
- tracing dapat dilakukan;
- dashboard tersedia;
- alert terdokumentasi;
- seluruh komponen kernel menghasilkan data observability secara konsisten.
