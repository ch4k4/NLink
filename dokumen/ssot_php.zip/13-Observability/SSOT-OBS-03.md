
# SSOT-OBS-03 — Metrics & KPI Framework

## Status

| Item | Nilai |
|---|---|
| Kode | SSOT-OBS-03 |
| Nama | Metrics & KPI Framework |
| Versi | 1.0 |
| Status | Draft Implementation Standard |
| Domain | Observability |
| Bergantung pada | SSOT-OBS-01, SSOT-OBS-02, SSOT-EVENT-01, SSOT-WF-01 |

---

# 1. Tujuan

Dokumen ini menetapkan standar pengumpulan metric dan Key Performance Indicator (KPI)
untuk Platform Kernel sehingga kondisi aplikasi dapat diukur secara objektif.

Metric digunakan untuk:

- memonitor kesehatan sistem;
- mengukur performa;
- mendeteksi anomali;
- mengevaluasi SLA;
- menjadi dasar dashboard dan alert.

---

# 2. Prinsip

- Semua metric memiliki definisi yang jelas.
- Metric dapat direproduksi.
- Metric tidak mengandung data sensitif.
- Gunakan satuan yang konsisten.
- KPI dibangun dari metric, bukan sebaliknya.

---

# 3. Kategori Metric

## Platform

- uptime
- request_total
- active_sessions
- concurrent_users

## API

- api_request_total
- api_error_total
- api_latency_ms
- api_timeout_total

## Database

- db_query_total
- db_query_duration_ms
- db_transaction_total
- db_deadlock_total

## Workflow

- workflow_started_total
- workflow_completed_total
- workflow_failed_total
- approval_duration_ms

## Event

- event_published_total
- event_failed_total
- outbox_pending_total

## Notification

- notification_sent_total
- notification_failed_total
- notification_retry_total

## Integration

- integration_request_total
- integration_success_total
- integration_failure_total
- integration_latency_ms

## File

- upload_total
- download_total
- upload_failed_total
- storage_used_bytes

## Scheduler

- scheduled_job_total
- scheduled_job_failed_total
- average_job_duration_ms

---

# 4. Naming Convention

Gunakan:

```text
domain.metric_name.unit
```

Contoh:

- api.request.total
- api.latency.ms
- workflow.completed.total
- integration.retry.total

---

# 5. Metric Type

| Jenis | Contoh |
|---|---|
| Counter | request_total |
| Gauge | active_sessions |
| Histogram | api_latency_ms |
| Timer | job_duration_ms |

---

# 6. KPI

## Availability

- uptime >= 99.5%

## API

- success rate
- average latency
- error rate

## Workflow

- completion rate
- approval lead time

## Integration

- success rate
- retry rate

## Background Job

- success rate
- average duration

---

# 7. Dashboard

Dashboard minimum harus menampilkan:

- request per menit
- response time
- error rate
- login gagal
- workflow backlog
- queue backlog
- integration failure
- scheduler status
- storage usage

---

# 8. Collection Interval

Rekomendasi:

- Counter : real-time
- Gauge : 30 detik
- Dashboard refresh : 30–60 detik
- KPI harian : setiap malam

---

# 9. Label

Label diperbolehkan:

- module
- route
- status
- provider
- job_name

Hindari label dengan cardinality tinggi seperti:

- email
- nama pasien
- nomor rekam medis

---

# 10. Penyimpanan

Contoh struktur tabel:

## observability_metrics

- id
- metric_name
- metric_type
- metric_value
- labels_json
- collected_at

Agregasi jangka panjang dapat dipindahkan ke data warehouse atau time-series database
saat platform berkembang.

---

# 11. SLA & SLO

Contoh target:

| Area | Target |
|---|---:|
| API Availability | 99.5% |
| Login Success | >99% |
| Workflow Completion | >98% |
| Background Job Success | >99% |
| Integration Success | >97% |

Nilai ini dapat disesuaikan oleh organisasi.

---

# 12. Anti-pattern

Hindari:

- metric tanpa definisi
- metric yang tidak pernah dipakai
- KPI berdasarkan data manual
- label berlebihan
- menyimpan data sensitif pada metric

---

# 13. UAT

- [ ] Semua metric utama terkumpul.
- [ ] Dashboard menampilkan metric.
- [ ] KPI dapat dihitung otomatis.
- [ ] Error rate sesuai hasil log.
- [ ] Workflow dan integration menghasilkan metric.

---

# 14. Definition of Done

Framework Metrics dianggap siap apabila:

- kategori metric telah ditentukan;
- naming convention konsisten;
- KPI terdokumentasi;
- dashboard dapat menggunakan metric tersebut;
- metric tidak mengandung data sensitif;
- mendukung monitoring seluruh Platform Kernel.
