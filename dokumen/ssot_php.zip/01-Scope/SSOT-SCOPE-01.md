# SSOT-SCOPE-01 — Tenant, Organization, Facility & Resource Scope Governance

> **Catatan resolusi 2026-07-07 (ADR-0001, lihat `nerslink-mvp/ADR-0001-scope-hierarchy-authority.md`)**: dokumen ini SUPERSEDED untuk urusan hierarchy dan schema oleh `SSOT-SCOPE-01A` (+ SCOPE-02/03/04), yang menjadi basis nyata `nerslink-mvp` (45 migrasi, 10 level hierarchy, sudah diuji end-to-end). Model 6-level dan skema `scope_registry` polymorphic di dokumen ini TIDAK diimplementasikan dan tidak akan menggantikan yang sudah dibangun tanpa keputusan arsitek baru. Konsep governance dokumen ini yang BELUM ada di SCOPE-01A/02/03/04 (tenant lifecycle mutation, reconciliation/drift detection, scope versioning/snapshot, delegation/impersonation formal) tetap relevan sebagai backlog kernel masa depan -- lihat ADR-0001 bagian "Backlog" -- untuk dibangun sebagai lapisan tambahan di atas hierarchy yang ada, bukan diadopsi utuh menggantikan hierarchy tersebut.

## Status Dokumen

| Item | Nilai |
|---|---|
| Kode | SSOT-SCOPE-01 |
| Judul | Tenant, Organization, Facility & Resource Scope Governance |
| Versi | 1.0 |
| Status | Draft Architecture |
| Domain | Platform Kernel |
| Kategori | Multi-Tenancy, Organizational Scope, Resource Ownership & Isolation |
| Cakupan | Tenant, Organization, Facility, Clinic, Department, Team, Resource Scope, Inheritance, Resolution, Mutation, Reconciliation |
| Bergantung pada | SSOT-GOV-01, SSOT-GOV-04, SSOT-GOV-05, SSOT-IAM-01..08, SSOT-RBAC-05..11, SSOT-AUDIT-01, SSOT-DATA-06, SSOT-API-06, SSOT-TEST-01 |
| Target Stack | PHP 8.1+, REST/JSON, PDO, MySQL 8/MariaDB |
| Target Evolusi | Central Scope Service, Relationship-Based Authorization, Federated Tenancy, Continuous Scope Assurance |

# 1. Executive Summary

SSOT-SCOPE-01 menetapkan governance resmi untuk tenant, organization, facility, clinic, department, team, resource ownership, scope inheritance, scope resolution, scope mutation, dan scope reconciliation.

Dokumen ini memastikan setiap identity, role assignment, resource, API request, workflow task, report, file, dan event memiliki konteks scope yang:

- eksplisit;
- dapat dipercaya;
- konsisten;
- tenant-isolated;
- dapat diwariskan secara terkendali;
- dapat diaudit;
- dapat direkonsiliasi.

# 2. Objectives

Framework harus:

- menyediakan canonical scope hierarchy;
- menyediakan tenant isolation;
- menetapkan resource ownership;
- mengatur inheritance;
- mengatur cross-scope access;
- menyediakan scope resolver;
- mengatur scope mutation;
- mendukung tenant provisioning/suspension;
- menyediakan reconciliation;
- menghasilkan evidence.

# 3. Core Principles

```text
Every Request Has a Scope
Every Resource Has an Owner
Tenant Isolation Is Mandatory
Scope Is Never Trusted From User Input Alone
Inheritance Is Explicit
Cross-Scope Access Requires Policy
Scope Changes Are Auditable
Global Resources Are Exceptional
Authorization Uses Authoritative Scope
Every Scope Relationship Is Reconciled
```

# 4. Scope

Berlaku untuk:

```text
Users
Service Accounts
Roles
Permissions
Patients
Practitioners
Organizations
Clinics
Facilities
Departments
Teams
Resources
Files
Workflows
Reports
Events
Integrations
```

# 5. Canonical Scope Hierarchy

Recommended:

```text
PLATFORM
└── TENANT
    └── ORGANIZATION
        └── FACILITY / CLINIC
            └── DEPARTMENT
                └── TEAM
                    └── RESOURCE
```

# 6. Scope Types

```text
PLATFORM
TENANT
ORGANIZATION
FACILITY
CLINIC
DEPARTMENT
TEAM
SELF
RESOURCE
```

# 7. Scope Registry

Minimum:

```text
scope_id
scope_type
scope_code
name
parent_scope_id
tenant_id
owner
status
effective dates
```

# 8. Scope Identity

Setiap scope memiliki identifier opaque dan immutable.

# 9. Scope Code

Scope code bersifat human-readable tetapi tidak boleh menjadi primary authorization identifier.

# 10. Scope Lifecycle

```text
PROPOSED
ACTIVE
SUSPENDED
MIGRATING
MERGED
SPLIT
CLOSED
RETIRED
```

# 11. Tenant

Tenant adalah boundary utama data, identity, configuration, billing, dan policy.

# 12. Tenant Isolation

Default:

```text
No cross-tenant read
No cross-tenant write
No cross-tenant search
No cross-tenant aggregation
No cross-tenant cache reuse
No cross-tenant background job execution
```

# 13. Organization

Organization adalah legal/business entity di bawah tenant.

# 14. Facility and Clinic

Facility/clinic adalah operating unit dengan:

- location;
- service capability;
- staff scope;
- scheduling scope;
- resource ownership;
- reporting boundary.

# 15. Department

Department adalah functional operating unit.

# 16. Team

Team adalah assignment/operational grouping dan dapat bersifat temporal.

# 17. Self Scope

Self scope mengikat identity dengan resource personalnya.

# 18. Resource Scope

Resource scope adalah ownership boundary paling granular.

# 19. Resource Ownership

Setiap resource harus memiliki minimum:

```text
tenant_id
organization_id
facility_or_clinic_id
resource_owner_type
resource_owner_id
```

# 20. Resource Ownership Models

```text
TENANT_OWNED
ORGANIZATION_OWNED
FACILITY_OWNED
CLINIC_OWNED
DEPARTMENT_OWNED
TEAM_OWNED
USER_OWNED
SHARED_SCOPED
PLATFORM_OWNED
```

# 21. Platform-Owned Resources

Hanya untuk:

- global code systems;
- platform configuration;
- shared infrastructure metadata;
- approved global reference data.

# 22. Global Resource Restrictions

Platform-owned resource tidak otomatis dapat diubah oleh tenant.

# 23. Parent-Child Relationships

Every non-platform scope must have a valid parent according to hierarchy policy.

# 24. Relationship Validity

Must define:

```text
valid_from
valid_to
status
relationship_type
```

# 25. Multiple Parents

Default prohibited unless explicitly modeled as approved relationship graph.

# 26. Scope Inheritance

Inheritance direction:

```text
Parent may govern child
Child does not automatically govern parent
Sibling access is not inherited
```

# 27. Permission Inheritance

Permission inheritance must be explicit and role-assignment-aware.

# 28. Scope Binding

Role/permission assignment must include scope binding.

# 29. Assignment Binding

Minimum:

```text
principal
role
scope_type
scope_id
validity
status
```

# 30. Effective Scope

Effective scope is the intersection of:

```text
identity tenant
role assignment scope
resource scope
request context
policy restrictions
purpose
```

# 31. Scope Resolution Flow

```text
Authenticate
→ Resolve Identity Tenant
→ Resolve Active Assignments
→ Resolve Requested Scope
→ Resolve Resource Ownership
→ Apply Inheritance
→ Apply Restrictions
→ Produce Effective Scope
```

# 32. Trusted Scope Sources

Allowed:

- authenticated session;
- signed token claims;
- authoritative identity registry;
- server-side resource lookup;
- approved service context.

# 33. Untrusted Scope Sources

Never trust directly:

- query parameters;
- form fields;
- request headers;
- client-supplied tenant ID;
- path identifiers without resource validation.

# 34. Scope Context

Minimum:

```text
tenant_id
organization_id
facility_id
clinic_id
department_id
team_id
resource_id
scope_source
scope_version
```

# 35. Scope Resolver Contract

```php
interface ScopeResolverInterface
{
    public function resolve(
        ScopeResolutionRequest $request
    ): EffectiveScope;
}
```

# 36. Resource Scope Resolver

```php
interface ResourceScopeResolverInterface
{
    public function resolveResourceScope(
        string $resourceType,
        string $resourceId
    ): ResourceScope;
}
```

# 37. Scope Validation

Validation includes:

- scope exists;
- scope active;
- parent valid;
- tenant consistent;
- assignment active;
- resource inside scope;
- no forbidden cross-tenant relation.

# 38. Scope Precedence

Recommended:

```text
Explicit deny
→ Resource restriction
→ Assignment restriction
→ Tenant boundary
→ Inherited allow
→ Default deny
```

# 39. Default Deny

Unknown or unresolved scope must deny access.

# 40. Cross-Scope Access

Requires explicit policy.

# 41. Cross-Organization Access

May be allowed only if same tenant and permission explicitly permits.

# 42. Cross-Clinic Access

Requires explicit assignment, shared-service policy, or approved operational role.

# 43. Cross-Team Access

Team membership alone does not imply sibling-team access.

# 44. Cross-Tenant Access

Default prohibited.

# 45. Platform Support Access

Requires:

- platform support role;
- approved purpose;
- time-bound session;
- ticket/incident reference;
- elevated audit;
- optional masking;
- post-review.

# 46. Delegated Access

Must preserve:

- delegator;
- delegate;
- scope;
- purpose;
- validity;
- revocation;
- audit trail.

# 47. Impersonation

Only for approved support/admin scenarios with explicit user-visible and audit controls.

# 48. Break-Glass Scope

Emergency access must:

- be narrow;
- be time-bound;
- require reason;
- generate alert;
- require review.

# 49. Service Accounts

Service accounts must be bound to:

- tenant;
- environment;
- workload;
- allowed scopes;
- owner;
- expiry/review.

# 50. Scope Mutation

Scope mutation includes:

```text
create
activate
suspend
rename
move
merge
split
close
retire
```

# 51. Create Scope

Requires:

- valid parent;
- owner;
- tenant binding;
- unique code;
- effective date;
- audit.

# 52. Move Scope

Moving organization/facility/clinic requires impact analysis.

# 53. Move Impact

Review:

- role assignments;
- resources;
- workflows;
- reporting;
- billing;
- integrations;
- files;
- events;
- search indexes;
- caches.

# 54. Merge Scope

Scope merge requires:

- surviving scope;
- alias/redirect;
- resource migration;
- assignment reconciliation;
- downstream update;
- audit;
- rollback plan.

# 55. Split Scope

Scope split requires deterministic allocation of:

- resources;
- users;
- assignments;
- workflows;
- reports;
- integrations;
- records.

# 56. Scope Closure

Closure must prevent new activity while preserving required records.

# 57. Scope Suspension

Suspension may block:

- login;
- API access;
- writes;
- integrations;
- background jobs;
- billing operations.

# 58. Tenant Provisioning

Provisioning flow:

```text
Tenant Proposal
→ Approval
→ Tenant Registry
→ Default Organization
→ Default Scope Policies
→ Initial Admin
→ Configuration
→ Activation
```

# 59. Tenant Suspension

Must define:

- access impact;
- background processing;
- data retention;
- billing;
- support;
- reactivation path.

# 60. Tenant Offboarding

Includes:

- revoke access;
- stop integrations;
- export where required;
- retention/legal hold check;
- archival/disposition;
- evidence;
- final reconciliation.

# 61. Organization Transfer

Cross-tenant organization transfer is exceptional and requires controlled migration.

# 62. Cross-Tenant Transfer

Requires:

- legal approval;
- data owner approval;
- identity migration;
- resource migration;
- reference remapping;
- audit;
- no temporary dual ownership unless explicitly governed.

# 63. Resource Reassignment

Every resource reassignment must validate new scope and downstream dependencies.

# 64. Scope Versioning

Material hierarchy/policy changes should increment scope version.

# 65. Scope Snapshot

Long-running operations may record scope snapshot for evidence.

# 66. Authorization Freshness

Scope changes must invalidate:

- sessions where required;
- permission caches;
- API caches;
- report caches;
- workflow assignments;
- service tokens where required.

# 67. Scope Cache Key

Must include:

```text
principal
tenant
scope
assignment version
resource ownership version
policy version
```

# 68. Search Scope

Search indexes must partition/filter by tenant and authorized scope.

# 69. Analytics Scope

Reports must enforce row-level scope and prevent cross-tenant aggregation unless approved.

# 70. File Scope

Files inherit or explicitly bind to parent resource scope.

# 71. Workflow Scope

Workflow instance and tasks inherit scope from originating resource/process.

# 72. Event Scope

Events must carry tenant and relevant scope context.

# 73. Integration Scope

Partner/client access must be tenant- and environment-bound.

# 74. Background Job Scope

Every job must execute with explicit tenant/scope context.

# 75. Scope Propagation

Propagation must be:

- explicit;
- immutable per message/request;
- validated at each boundary;
- never inferred from payload alone.

# 76. Database Query Guard

Repositories must require tenant/scope context for scoped entities.

# 77. Scoped Repository Contract

```php
interface ScopedRepositoryInterface
{
    public function withScope(
        EffectiveScope $scope
    ): static;
}
```

# 78. Database Constraints

Use foreign keys and unique constraints where feasible to preserve scope integrity.

# 79. Compound Uniqueness

Tenant-scoped uniqueness should include tenant ID.

# 80. IDOR Prevention

Resource IDs must always resolve together with authoritative scope.

# 81. Scope Enumeration Protection

Unauthorized scope/resource existence must not leak.

# 82. Scope Audit Events

```text
SCOPE_CREATED
SCOPE_ACTIVATED
SCOPE_SUSPENDED
SCOPE_MOVED
SCOPE_MERGED
SCOPE_SPLIT
SCOPE_CLOSED
SCOPE_ASSIGNMENT_CREATED
SCOPE_ASSIGNMENT_REVOKED
SCOPE_RESOLUTION_DENIED
CROSS_SCOPE_ACCESS_USED
CROSS_TENANT_ACCESS_ATTEMPTED
```

# 83. Audit Evidence

Minimum:

```text
actor
principal
tenant
source scope
target scope
resource
action
reason
policy version
correlation ID
timestamp
```

# 84. Scope Reconciliation

Compare:

- scope registry;
- parent-child hierarchy;
- tenant registry;
- role assignments;
- resource ownership;
- workflow assignments;
- search indexes;
- analytics dimensions;
- files;
- integrations;
- caches.

# 85. Reconciliation Findings

```text
ORPHAN_SCOPE
INVALID_PARENT
TENANT_MISMATCH
RESOURCE_WITHOUT_SCOPE
RESOURCE_SCOPE_MISMATCH
ASSIGNMENT_TO_INACTIVE_SCOPE
CROSS_TENANT_RELATION
BROKEN_SCOPE_ALIAS
SEARCH_SCOPE_DRIFT
ANALYTICS_SCOPE_DRIFT
CACHE_SCOPE_DRIFT
```

# 86. Auto-Remediation

Examples:

- invalidate stale cache;
- repair derived scope index;
- disable invalid assignment;
- republish scope-change event;
- repair alias.

# 87. Manual Remediation

Required for:

- cross-tenant ownership;
- ambiguous resource ownership;
- failed merge/split;
- clinical/financial impact;
- legal transfer;
- large-scale scope drift.

# 88. Metrics

```text
scope_total
scope_active_total
scope_resolution_denied_total
scope_cross_tenant_attempt_total
scope_orphan_total
scope_assignment_invalid_total
scope_resource_mismatch_total
scope_reconciliation_failure_total
scope_cache_invalidation_failure_total
```

# 89. KPIs

```text
Resources without tenant scope = 0
Cross-tenant ownership relations = 0
Active assignments to inactive scopes = 0
Requests with unresolved scope allowed = 0
Background jobs without tenant context = 0
Cross-tenant data exposure = 0
```

# 90. KRIs

```text
Cross-scope access growth
Invalid assignments
Orphan scopes
Scope-move frequency
Merge/split failures
Cache invalidation failures
Search/report scope drift
Support-access usage
```

# 91. Database Direction

Potential tables:

```text
scope_registry
scope_relationships
scope_aliases
scope_assignments
scope_resource_bindings
scope_mutation_requests
scope_mutation_history
scope_snapshots
scope_reconciliation_runs
scope_reconciliation_findings
```

# 92. Table: scope_registry

```sql
CREATE TABLE scope_registry (
    id CHAR(26) NOT NULL,
    scope_code VARCHAR(180) NOT NULL,
    scope_name VARCHAR(255) NOT NULL,
    scope_type VARCHAR(40) NOT NULL,
    tenant_id CHAR(26) NULL,
    parent_scope_id CHAR(26) NULL,
    owner_reference VARCHAR(180) NOT NULL,
    status VARCHAR(30) NOT NULL,
    scope_version BIGINT NOT NULL DEFAULT 1,
    valid_from DATETIME(6) NOT NULL,
    valid_to DATETIME(6) NULL,

    PRIMARY KEY (id),
    UNIQUE KEY uq_scope_code (
        tenant_id,
        scope_code
    ),
    KEY idx_scope_parent (
        parent_scope_id,
        status
    ),
    KEY idx_scope_tenant_type (
        tenant_id,
        scope_type,
        status
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

# 93. Table: scope_assignments

```sql
CREATE TABLE scope_assignments (
    id CHAR(26) NOT NULL,
    principal_type VARCHAR(40) NOT NULL,
    principal_id CHAR(26) NOT NULL,
    role_code VARCHAR(180) NOT NULL,
    scope_id CHAR(26) NOT NULL,
    status VARCHAR(30) NOT NULL,
    valid_from DATETIME(6) NOT NULL,
    valid_to DATETIME(6) NULL,
    assigned_by CHAR(26) NOT NULL,

    PRIMARY KEY (id),
    UNIQUE KEY uq_scope_assignment (
        principal_type,
        principal_id,
        role_code,
        scope_id,
        valid_from
    ),
    KEY idx_scope_assignment_active (
        principal_id,
        scope_id,
        status,
        valid_to
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

# 94. Table: scope_resource_bindings

```sql
CREATE TABLE scope_resource_bindings (
    id CHAR(26) NOT NULL,
    resource_type VARCHAR(100) NOT NULL,
    resource_id CHAR(26) NOT NULL,
    scope_id CHAR(26) NOT NULL,
    ownership_type VARCHAR(40) NOT NULL,
    status VARCHAR(30) NOT NULL,
    valid_from DATETIME(6) NOT NULL,
    valid_to DATETIME(6) NULL,

    PRIMARY KEY (id),
    UNIQUE KEY uq_scope_resource_binding (
        resource_type,
        resource_id,
        scope_id,
        valid_from
    ),
    KEY idx_scope_resource_active (
        resource_type,
        resource_id,
        status
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

# 95. Table: scope_mutation_history

```sql
CREATE TABLE scope_mutation_history (
    id CHAR(26) NOT NULL,
    scope_id CHAR(26) NOT NULL,
    mutation_type VARCHAR(40) NOT NULL,
    previous_state_json JSON NULL,
    new_state_json JSON NOT NULL,
    reason_text VARCHAR(2000) NOT NULL,
    requested_by CHAR(26) NOT NULL,
    approved_by CHAR(26) NULL,
    policy_version VARCHAR(100) NOT NULL,
    created_at DATETIME(6) NOT NULL,

    PRIMARY KEY (id),
    KEY idx_scope_mutation_history (
        scope_id,
        created_at
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

# 96. API Direction

```text
GET  /api/internal/v1/scopes
POST /api/internal/v1/scopes
GET  /api/internal/v1/scopes/{scopeId}
POST /api/internal/v1/scopes/{scopeId}/activate
POST /api/internal/v1/scopes/{scopeId}/suspend
POST /api/internal/v1/scopes/{scopeId}/move
POST /api/internal/v1/scopes/{scopeId}/merge
POST /api/internal/v1/scopes/{scopeId}/split
POST /api/internal/v1/scopes/{scopeId}/close
GET  /api/internal/v1/scopes/{scopeId}/assignments
POST /api/internal/v1/scopes/reconciliation/runs
```

# 97. SDK Contracts

```text
ScopeRegistryInterface
ScopeResolverInterface
ResourceScopeResolverInterface
ScopeAssignmentServiceInterface
ScopeMutationServiceInterface
ScopeReconciliationServiceInterface
```

# 98. Registry Contract

```php
interface ScopeRegistryInterface
{
    public function find(
        string $scopeId
    ): ?Scope;

    public function requireActive(
        string $scopeId
    ): Scope;
}
```

# 99. Assignment Contract

```php
interface ScopeAssignmentServiceInterface
{
    public function assign(
        ScopeAssignmentRequest $request
    ): ScopeAssignment;

    public function revoke(
        ScopeAssignmentRevocationRequest $request
    ): void;
}
```

# 100. Error Codes

```text
SCOPE_NOT_FOUND
SCOPE_NOT_ACTIVE
SCOPE_PARENT_INVALID
SCOPE_TENANT_MISMATCH
SCOPE_ASSIGNMENT_INVALID
SCOPE_RESOURCE_MISMATCH
SCOPE_CROSS_TENANT_DENIED
SCOPE_MOVE_NOT_ALLOWED
SCOPE_MERGE_NOT_ALLOWED
SCOPE_SPLIT_NOT_ALLOWED
SCOPE_RESOLUTION_FAILED
SCOPE_RECONCILIATION_FAILED
```

# 101. Scope Registration Checklist

- [ ] Scope type valid.
- [ ] Tenant binding valid.
- [ ] Parent valid.
- [ ] Owner assigned.
- [ ] Code unique.
- [ ] Effective dates valid.
- [ ] Default policies attached.
- [ ] Audit generated.

# 102. Assignment Checklist

- [ ] Principal active.
- [ ] Role valid.
- [ ] Scope active.
- [ ] Tenant consistent.
- [ ] Validity bounded.
- [ ] Conflicting assignment checked.
- [ ] Approval complete.
- [ ] Audit generated.

# 103. UAT — Hierarchy & Resolution

- [ ] Tenant resolves.
- [ ] Organization resolves under tenant.
- [ ] Clinic resolves under organization.
- [ ] Department resolves under clinic.
- [ ] Team resolves under department.
- [ ] Invalid parent rejected.
- [ ] Sibling access not inherited.
- [ ] Unknown scope denied.
- [ ] Scope version recorded.

# 104. UAT — Tenant Isolation

- [ ] Tenant A cannot access Tenant B resource.
- [ ] User-supplied tenant ID cannot override identity.
- [ ] Search results remain tenant-filtered.
- [ ] Analytics remain tenant-filtered.
- [ ] Background jobs require tenant context.
- [ ] Cache key includes tenant/scope.
- [ ] Cross-tenant relationship rejected.
- [ ] Resource lookup does not leak existence.
- [ ] Audit complete.

# 105. UAT — Assignment & Inheritance

- [ ] Tenant-level role inherits to allowed children.
- [ ] Organization role does not inherit to parent.
- [ ] Clinic role does not access sibling clinic.
- [ ] Explicit deny overrides inherited allow.
- [ ] Expired assignment denied.
- [ ] Suspended scope assignment denied.
- [ ] Team assignment works.
- [ ] Self scope works.
- [ ] Assignment revocation invalidates cache.

# 106. UAT — Resource Ownership

- [ ] Resource binds to tenant.
- [ ] Resource binds to organization/clinic.
- [ ] Wrong-scope resource denied.
- [ ] Shared-scoped resource follows policy.
- [ ] Platform-owned resource is read-only where required.
- [ ] Reassignment updates downstream bindings.
- [ ] Orphan resource detected.
- [ ] Ownership history retained.
- [ ] Audit complete.

# 107. UAT — Scope Mutation

- [ ] Scope creation works.
- [ ] Move requires impact analysis.
- [ ] Merge creates alias.
- [ ] Split allocates resources deterministically.
- [ ] Closure blocks new activity.
- [ ] Suspension blocks configured operations.
- [ ] Cache invalidated after mutation.
- [ ] Events published.
- [ ] Rollback/recovery evidence retained.

# 108. UAT — Support & Emergency Access

- [ ] Support access requires ticket.
- [ ] Cross-tenant support access is time-bound.
- [ ] Purpose required.
- [ ] Break-glass expires.
- [ ] Elevated audit generated.
- [ ] Post-review required.
- [ ] Unauthorized impersonation denied.
- [ ] Masking applies where configured.
- [ ] Notification emitted.

# 109. UAT — Reconciliation

- [ ] Orphan scope detected.
- [ ] Invalid parent detected.
- [ ] Tenant mismatch detected.
- [ ] Resource without scope detected.
- [ ] Resource-scope mismatch detected.
- [ ] Assignment to inactive scope detected.
- [ ] Cross-tenant relation detected.
- [ ] Broken alias detected.
- [ ] Search-scope drift detected.
- [ ] Analytics-scope drift detected.
- [ ] Cache-scope drift detected.

# 110. Definition of Done — SSOT-SCOPE-01

SSOT-SCOPE-01 dianggap selesai bila:

- [ ] canonical hierarchy tersedia;
- [ ] scope types tersedia;
- [ ] scope registry tersedia;
- [ ] tenant isolation tersedia;
- [ ] ownership models tersedia;
- [ ] parent-child validity tersedia;
- [ ] inheritance rules tersedia;
- [ ] scope binding tersedia;
- [ ] effective-scope model tersedia;
- [ ] resolver tersedia;
- [ ] trusted/untrusted sources tersedia;
- [ ] cross-scope rules tersedia;
- [ ] support/delegation/break-glass tersedia;
- [ ] service-account scope tersedia;
- [ ] mutation lifecycle tersedia;
- [ ] tenant provisioning/suspension/offboarding tersedia;
- [ ] organization transfer tersedia;
- [ ] cache invalidation tersedia;
- [ ] search/analytics/file/workflow/event scope tersedia;
- [ ] database query guard tersedia;
- [ ] reconciliation tersedia;
- [ ] audit and metrics tersedia;
- [ ] database direction tersedia;
- [ ] API direction tersedia;
- [ ] SDK contracts tersedia;
- [ ] UAT and DoD tersedia.

# 111. Implementation Roadmap

## Phase 1 — Scope Registry Foundation

- scope registry;
- hierarchy;
- tenant binding;
- ownership;
- lifecycle;
- administrative APIs.

## Phase 2 — Resolution & Assignment

- effective scope resolver;
- assignment service;
- inheritance;
- resource binding;
- query guards;
- cache strategy.

## Phase 3 — Mutation & Tenant Operations

- create/move/merge/split/close;
- tenant provisioning;
- suspension;
- offboarding;
- organization transfer;
- impact analysis.

## Phase 4 — Cross-Scope Assurance

- support access;
- delegation;
- break-glass;
- cross-scope policy;
- abuse detection;
- audit dashboards.

## Phase 5 — Continuous Scope Platform

- centralized scope service;
- relationship-based access;
- federated tenancy;
- scope graph;
- continuous reconciliation;
- scope governance dashboard.

# 112. Initial Implementation Backlog

```text
SCOPE01-001 Scope Registry
SCOPE01-002 Scope Hierarchy
SCOPE01-003 Tenant Isolation Guard
SCOPE01-004 Effective Scope Resolver
SCOPE01-005 Scope Assignment Service
SCOPE01-006 Resource Binding Service
SCOPE01-007 Scoped Repository Guard
SCOPE01-008 Cache Invalidation
SCOPE01-009 Tenant Provisioning
SCOPE01-010 Scope Mutation Workflow
SCOPE01-011 Merge/Split Service
SCOPE01-012 Support/Break-Glass Scope
SCOPE01-013 Scope Event Publisher
SCOPE01-014 Scope Drift Detection
SCOPE01-015 Reconciliation Engine
SCOPE01-016 Scope Governance Dashboard
```

# 113. Approval Gate

Dokumen dapat menjadi Approved setelah:

- Platform Architecture review;
- IAM/RBAC review;
- Tenant Architecture review;
- Data Architecture review;
- API Architecture review;
- Security Architecture review;
- Operations/SRE review;
- Audit/Compliance review;
- Quality Engineering review;
- UAT review.

# 114. Closing Statement

Scope bukan sekadar kolom `tenant_id`.

Scope adalah kontrak ownership, hierarchy, authorization, inheritance, isolation, dan lifecycle.

Setiap request dan resource harus memiliki scope yang authoritative.

Cross-tenant access harus menjadi pengecualian yang sangat terkendali.

Setiap perubahan scope harus dapat ditelusuri dan direkonsiliasi.
