
# SSOT-DEPENDENCY-MATRIX.md
# Enterprise Platform Kernel - Dependency Matrix

**Version:** 1.0

---

# Tujuan

Dokumen ini menjadi acuan resmi hubungan ketergantungan (dependency) antar SSOT sehingga implementasi dilakukan dengan urutan yang benar dan setiap developer mengetahui fondasi yang wajib tersedia sebelum membangun fitur atau modul.

---

# Tingkatan Arsitektur

| Layer | Tujuan |
|---|---|
| L0 | Governance & Vision |
| L1 | Identity & Security Foundation |
| L2 | Data Foundation |
| L3 | Process Foundation |
| L4 | Communication Foundation |
| L5 | Platform Services |
| L6 | SDK |
| L6.3 | Enterprise UI Architecture |
| L6.4 | Business Module Architecture |
| L6.5 | Master & Reference Data (MDM) |
| L7 | Business Modules |
| — | Implementation & Coding Standards (cross-cutting, tidak diberi nomor layer) |

Catatan (2026-07-05): L6.5 ditambahkan karena SSOT-MDM-01 secara eksplisit mendeklarasikan dependency ke SSOT-SDK-01, sehingga MDM berada setelah SDK, bukan sejajar dengan Platform Services (L5).

Catatan (2026-07-06, dikonfirmasi ulang 2026-07-07 setelah file ini sempat ditimpa proses konsolidasi otomatis eksternal): "Implementation & Coding Standards" (SSOT-STACK-01, SSOT-CODE-01, SSOT-DEV-01, SSOT-IMPLEMENTATION-01, SSOT-MYSQL-01) sengaja tidak diberi nomor layer L0-L7 -- dokumen-dokumen ini menjelaskan HOW to build setiap layer, bukan runtime dependency gate. Dikutip lintas semua layer sejak modul pertama (`Router.php`, `CsrfMiddleware.php`).

Catatan (2026-07-07): L6.3/L6.4 ditambahkan untuk SSOT-UI-01 dan SSOT-MODULE-01 yang muncul di paket SSOT bersamaan dengan ~43 dokumen baru lainnya di luar kendali sesi kerja ini -- lihat SSOT-ROADMAP.md "Catatan Besar — Perluasan Paket SSOT 2026-07-07" untuk ringkasan lengkap dan 2 temuan yang butuh keputusan arsitek (konflik SSOT-SCOPE-01 vs SCOPE-01A; dependency SSOT-MODULE-01 yang mengarah ke kode tidak ada). Detail ~43 dokumen baru lain (RBAC-04..11, DATA-06..09, dst.) sudah tercakup di blok "Addition" di bawah dokumen ini (ditambahkan oleh proses konsolidasi otomatis) -- tidak diulang di bagian atas ini untuk menghindari duplikasi.

---

# Dependency Matrix

| Domain | Bergantung pada |
|---|---|
| Governance | - |
| Scope | Governance |
| IAM | Scope |
| RBAC | IAM, Scope |
| Audit | IAM, RBAC, Scope |
| Data | Audit |
| Workflow | Data, RBAC, Scope |
| Notification | Workflow, IAM |
| API | IAM, RBAC, Scope, Audit |
| Event | API, Workflow, Audit |
| File | IAM, RBAC, Scope, Audit |
| Search | Event, File |
| Integration | API, Event, Notification |
| Observability | API, Event, Integration |
| Security | IAM, API, Audit |
| Deployment | Security, Observability |
| SDK | Governance, Deployment, Security |
| Enterprise UI Architecture | Governance, RBAC (Policy Enforcement), Menu Registry/Projection/Navigation, Testing, Module Architecture |
| Business Module Architecture | Scope, IAM, RBAC, Audit, Governance, SDK (seluruh 01-05), Testing |
| Master & Reference Data (MDM) | Governance, SDK, Deployment, Security |
| Testing | Governance (GOV-01/03/04/05/06), Data (DATA-01/02), API-01, Security (SEC-01/02), Observability (OBS-01), Deployment (DEPLOY-01) -- direvisi 2026-07-07, sebelumnya "belum ada dokumen" |
| Business Modules | SDK, MDM + seluruh Kernel |

Catatan (2026-07-05): baris SDK dan MDM diperbarui dari deskripsi generik ("Kernel selesai") menjadi dependency konkret, dikutip dari field "Bergantung pada" di SSOT-SDK-01 dan SSOT-MDM-01.

Catatan (2026-07-07): baris Enterprise UI Architecture, Business Module Architecture, dan Testing ditambahkan/direvisi mengikuti dependency yang dideklarasikan SSOT-UI-01, SSOT-MODULE-01, dan SSOT-TEST-01 sendiri (dikutip dari field "Bergantung pada" masing-masing). Dependency SSOT-MODULE-01 sendiri mengandung kode yang tidak ada di paket manapun (`SSOT-01, SSOT-02, SSOT-03A/B/C, SSOT-04`) -- baris di atas menggunakan interpretasi masuk akal berdasarkan konteks (Scope/IAM/RBAC/Audit), BUKAN kutipan literal dari field aslinya yang cacat. Lihat SSOT-ROADMAP.md Phase 14C.

---

# Dependency Graph

```text
Governance
    │
    ▼
Scope
    │
    ▼
IAM
    │
    ▼
RBAC
    │
    ├──────────────┐
    ▼              │
Audit             API
    │              │
    ▼              ▼
Data          Notification
    │              │
    ▼              │
Workflow ──────────┘
    │
    ▼
Event
 ├──► File
 ├──► Search
 └──► Integration
          │
          ▼
Observability
          │
          ▼
Security
          │
          ▼
Deployment
          │
          ▼
Platform SDK
          │
          ▼
Master & Reference Data (MDM)
          │
          ▼
Testing
          │
          ▼
Business Modules
```

Catatan (2026-07-05): urutan Testing dan Platform SDK ditukar dari versi sebelumnya (dulu Testing → SDK) karena tidak ada dokumen SDK yang mendeklarasikan dependency ke Testing, sedangkan MDM secara eksplisit bergantung pada SDK. Testing tetap ditempatkan mendekati akhir karena mengacu ke seluruh domain di atasnya (lihat Dependency Matrix).

Catatan (2026-07-07): diagram ASCII di atas belum digambar ulang untuk menyisipkan Enterprise UI Architecture dan Business Module Architecture (keduanya masuk di antara Platform SDK dan Master & Reference Data (MDM), lihat baris tabel Dependency Matrix di atas dan SSOT-ROADMAP.md untuk urutan lengkap) -- dihindari untuk mengurangi risiko kesalahan ASCII-art pada re-check singkat ini; tabel di atas sudah otoritatif untuk urutan yang benar.

---

# Dependency per Modul

| Modul | SSOT Minimum |
|---|---|
| Patient | Scope, IAM, RBAC, Audit, Data, API, Event |
| Appointment | Patient + Workflow + Notification |
| Encounter | Appointment + Workflow + File |
| EMR | Encounter + File + Search + Integration |
| Homecare | Patient + Workflow + Notification + File + Event |
| Woundcare | Homecare + File + Search |
| Billing | Event + Workflow + API + Integration |
| Pharmacy | Billing + Search |
| Laboratory | Encounter + File + Integration |
| CRM | IAM + Workflow + Notification + Search |
| ERP | Workflow + Event + Integration |
| Inventory | Data + Workflow + Event |
| Finance | Billing + Integration + Audit |

Catatan (2026-07-05): seluruh modul bisnis di atas kemungkinan besar juga akan bergantung pada Master & Reference Data (MDM) untuk code set, taxonomy, dan reference data (mis. status pasien, kode diagnosis, satuan). Baris di atas belum diperbarui per-modul karena dokumen modul bisnisnya sendiri belum dibuat — menambahkan "+ MDM" di sini sekarang berisiko menebak detail yang belum terverifikasi. Tinjau ulang tabel ini saat modul bisnis pertama mulai didesain.

---

# Dampak Perubahan

| Jika berubah | Domain terdampak |
|---|---|
| Scope | Hampir seluruh platform |
| IAM | RBAC, API, Security |
| RBAC | API, Workflow, Modul Bisnis |
| Event | Notification, Search, Integration |
| API | Mobile, Web, Partner, SDK |
| File | EMR, Homecare, Woundcare |
| Integration | SATUSEHAT, BPJS, Payment, ERP |

---

# Aturan Implementasi

1. Jangan mengimplementasikan modul bila dependency belum selesai.
2. Jangan melewati layer dependency.
3. Perubahan SSOT wajib mengevaluasi seluruh domain yang bergantung.
4. Semua dependency harus tercermin pada roadmap dan sprint.

---

# Checklist Sebelum Memulai Modul

- [ ] Dependency SSOT selesai
- [ ] Permission tersedia
- [ ] Scope tersedia
- [ ] Audit tersedia
- [ ] API standar tersedia
- [ ] Event tersedia
- [ ] Workflow tersedia (jika diperlukan)
- [ ] UAT disiapkan

---

# Governance

Perubahan dependency wajib:

- memperbarui SSOT-DEPENDENCY-MATRIX.md
- memperbarui SSOT-ROADMAP.md
- memperbarui SSOT-INDEX.md
- dicatat pada SSOT-CHANGELOG.md
- direview oleh arsitek platform


## Testing Governance Addition

| SSOT | Depends On | Used By |
|---|---|---|
| SSOT-TEST-01 | GOV-01, GOV-03, GOV-04, GOV-05, GOV-06, DATA-01, DATA-02, API-01, SEC-01, SEC-02, OBS-01, DEPLOY-01 | Platform Kernel, SDK, Business Modules, Deployment, UAT, Release Governance |

`SSOT-TEST-01` menjadi quality-governance dependency untuk seluruh implementasi baru, migration, module certification, dan production release.


## Business Module Architecture Addition

| SSOT | Depends On | Used By |
|---|---|---|
| SSOT-MODULE-01 | Core Architecture, Governance, SDK-01..05, TEST-01 | All Business Modules, Industry Packs, Module Deployment, Module Certification, Service Extraction |

`SSOT-MODULE-01` menjadi normative lifecycle dan boundary contract untuk seluruh business module.


## Enterprise UI Architecture Addition

| SSOT | Depends On | Used By |
|---|---|---|
| SSOT-UI-01 | GOV-01..03, RBAC-05, MENU-02..04, TEST-01, MODULE-01 | Platform Shell, Admin UI, Portals, Business Module UI, Tenant Branding, Component Library |

`SSOT-UI-01` menjadi normative design-system dan frontend architecture contract untuk seluruh user-facing application.


## Secrets, Keys & Certificates Addition

| SSOT | Depends On | Used By |
|---|---|---|
| SSOT-SEC-03 | GOV-01, GOV-04, GOV-05, IAM-03, IAM-04, RBAC-05, RBAC-08, AUDIT-01, SEC-01, SEC-02, DEPLOY-01, DEPLOY-SEC-01, OBS-01, TEST-01 | Deployment, Integrations, Encryption, Signing, Certificates, Privileged Operations, Backup/Recovery |

`SSOT-SEC-03` menjadi normative lifecycle dan governance contract untuk seluruh secret, cryptographic key, credential, dan certificate.


## Data Classification & Privacy Addition

| SSOT | Depends On | Used By |
|---|---|---|
| SSOT-DATA-06 | GOV-01, GOV-04, GOV-05, SCOPE-01, IAM-01, RBAC-05, RBAC-06, AUDIT-01, DATA-01..05, SEC-01, SEC-03, TEST-01 | APIs, Reports, Search, Files, Events, Integrations, Analytics, Privacy Operations |

`SSOT-DATA-06` menjadi normative classification, privacy, purpose, consent, field-access, masking, retention, export, dan deletion contract.


## Identity Lifecycle Addition

| SSOT | Depends On | Used By |
|---|---|---|
| SSOT-IAM-07 | GOV-01, GOV-04, GOV-05, SCOPE-01, IAM-01..06, RBAC-04, RBAC-05, RBAC-07, RBAC-08, AUDIT-01, EVENT-01, WF-01, NOTIFY-01, TEST-01 | Joiner-Mover-Leaver, Tenant Administration, HRIS/SCIM Integration, Access Reconciliation, Deprovisioning |

`SSOT-IAM-07` menjadi normative identity lifecycle, provisioning, mover, suspension, termination, deprovisioning, dan reconciliation contract.


## Identity Risk, Recovery & Proofing Addition

| SSOT | Depends On | Used By |
|---|---|---|
| SSOT-IAM-08 | GOV-01, GOV-04, GOV-05, IAM-01..07, RBAC-05, RBAC-08, AUDIT-01, SEC-01..03, OBS-01, NOTIFY-01, TEST-01 | Authentication, Account Recovery, Privileged Recovery, Adaptive Access, Compromise Response |

`SSOT-IAM-08` menjadi normative identity assurance, proofing, risk evaluation, recovery, fraud resistance, dan compromised-account response contract.


## Access Review & Certification Addition

| SSOT | Depends On | Used By |
|---|---|---|
| SSOT-RBAC-09 | GOV-01, GOV-04, GOV-05, SCOPE-01, IAM-07, IAM-08, RBAC-04..08, AUDIT-01, WF-01, WF-03, NOTIFY-01, TEST-01 | Periodic Certification, Privileged Review, Service Account Review, External User Review, Access Remediation |

`SSOT-RBAC-09` menjadi normative access review campaign, reviewer assignment, certification, remediation, exception, evidence, dan continuous review contract.


## Role Catalog & Lifecycle Addition

| SSOT | Depends On | Used By |
|---|---|---|
| SSOT-RBAC-10 | GOV-01, GOV-04, GOV-05, SCOPE-01, IAM-07, RBAC-04..09, AUDIT-01, TEST-01 | Role Design, Assignment, Eligibility, Certification, Menu Projection, Module Contributions |

`SSOT-RBAC-10` menjadi normative role catalog, composition, inheritance, eligibility, versioning, deprecation, retirement, dan reconciliation contract.


## Authorization Reconciliation Addition

| SSOT | Depends On | Used By |
|---|---|---|
| SSOT-RBAC-11 | GOV-01, GOV-04, GOV-05, SCOPE-01, SCOPE-04, IAM-07, RBAC-04..10, MENU-03, MENU-04, AUDIT-01, EVENT-01, OBS-01, TEST-01 | Continuous Authorization Assurance, Drift Detection, Auto-Remediation, Runtime Verification |

`SSOT-RBAC-11` menjadi normative desired-state, actual-state, authorization drift, remediation, exception, evidence, dan continuous reconciliation contract.


## File Security Addition

| SSOT | Depends On | Used By |
|---|---|---|
| SSOT-FILE-02 | GOV-01, GOV-04, GOV-05, SCOPE-01, RBAC-05, RBAC-06, AUDIT-01, DATA-06, SEC-01, SEC-03, FILE-01, OBS-01, TEST-01 | Uploads, Attachments, Clinical Documents, Exports, Integrations, Secure Downloads |

`SSOT-FILE-02` menjadi normative upload validation, malware scanning, quarantine, secure storage, preview, sharing, dan file-access contract.


## File Retention & Evidence Addition

| SSOT | Depends On | Used By |
|---|---|---|
| SSOT-FILE-03 | GOV-01, GOV-04, GOV-05, AUDIT-01, DATA-06, SEC-03, FILE-01, FILE-02, OBS-01, TEST-01 | Records Management, Legal Hold, Archival, Evidence Export, Backup/Restore, Disposal |

`SSOT-FILE-03` menjadi normative file versioning, retention, archival, legal hold, chain-of-custody, evidence integrity, restore, dan disposal contract.


## Search Authorization Addition

| SSOT | Depends On | Used By |
|---|---|---|
| SSOT-SEARCH-02 | GOV-01, GOV-04, GOV-05, SCOPE-01, RBAC-05, RBAC-06, RBAC-11, AUDIT-01, DATA-06, SEARCH-01, EVENT-01, OBS-01, TEST-01 | Global Search, Module Search, Autocomplete, Facets, Search Exports, Secure Indexing |

`SSOT-SEARCH-02` menjadi normative tenant-aware indexing, document authorization, field projection, secure query, cache isolation, dan deletion propagation contract.


## Search Reindexing & Lifecycle Addition

| SSOT | Depends On | Used By |
|---|---|---|
| SSOT-SEARCH-03 | GOV-01, GOV-04, GOV-05, SEARCH-01, SEARCH-02, EVENT-01..03, OBS-01, DATA-06, FILE-03, TEST-01 | Search Operations, Reindexing, Blue-Green Cutover, Rollback, DR, Consistency Verification |

`SSOT-SEARCH-03` menjadi normative versioned-index, reindex, alias switch, deletion replay, rollback, stale-index, recovery, dan consistency contract.


## Integration Credential & Connection Addition

| SSOT | Depends On | Used By |
|---|---|---|
| SSOT-INTEGRATION-02 | GOV-01, GOV-04, GOV-05, SEC-03, IAM-07, RBAC-05, AUDIT-01, INTEGRATION-01, OBS-01, TEST-01 | Partner Connections, OAuth Clients, mTLS, SFTP/SSH, Database Connections, Provider Integrations |

`SSOT-INTEGRATION-02` menjadi normative connection registry, ownership, environment/tenant binding, credential lifecycle, rotation, revocation, health, dan reconciliation contract.


## Webhook, Callback & Partner Security Addition

| SSOT | Depends On | Used By |
|---|---|---|
| SSOT-INTEGRATION-03 | GOV-01, GOV-04, GOV-05, SEC-03, IAM-08, RBAC-05, AUDIT-01, INTEGRATION-01, INTEGRATION-02, EVENT-01, OBS-01, TEST-01 | Inbound Webhooks, Outbound Webhooks, Payment Callbacks, OAuth Callbacks, Partner Event Push |

`SSOT-INTEGRATION-03` menjadi normative partner trust, signature verification, replay protection, callback validation, outbound signing, key rotation, dan webhook incident contract.


## Integration Reliability & Reconciliation Addition

| SSOT | Depends On | Used By |
|---|---|---|
| SSOT-INTEGRATION-04 | GOV-01, GOV-04, GOV-05, AUDIT-01, INTEGRATION-01..03, EVENT-01..03, OBS-01, TEST-01 | API Calls, Webhooks, Message Brokers, Payments, Notifications, Batch Integrations, Partner Transactions |

`SSOT-INTEGRATION-04` menjadi normative retry, timeout, idempotency, circuit breaker, dead-letter, saga, compensation, reconciliation, replay, dan recovery contract.


## Notification Delivery & Failure Addition

| SSOT | Depends On | Used By |
|---|---|---|
| SSOT-NOTIFY-04 | GOV-01, GOV-04, GOV-05, AUDIT-01, INTEGRATION-02, INTEGRATION-04, NOTIFY-01..03, OBS-01, TEST-01 | Email, SMS, Push, In-App, Chat Provider, Batch and Transactional Notifications |

`SSOT-NOTIFY-04` menjadi normative notification delivery lifecycle, routing, retry, fallback, receipt, suppression, dead-letter, dan reconciliation contract.


## Notification Consent & Compliance Addition

| SSOT | Depends On | Used By |
|---|---|---|
| SSOT-NOTIFY-05 | GOV-01, GOV-04, GOV-05, DATA-06, AUDIT-01, IAM-07, NOTIFY-01..04, TEST-01 | Preference Center, Marketing, Transactional Messaging, Quiet Hours, Frequency Caps, Suppression Compliance |

`SSOT-NOTIFY-05` menjadi normative consent, lawful basis, opt-in/opt-out, preference, quiet-hours, frequency-cap, suppression, dan communication-eligibility contract.


## Event Schema Registry & Compatibility Addition

| SSOT | Depends On | Used By |
|---|---|---|
| SSOT-EVENT-04 | GOV-01, GOV-04, GOV-05, AUDIT-01, EVENT-01..03, DATA-06, MODULE-01, TEST-01 | Domain Events, Integration Events, Contract Tests, Module Manifests, Event Catalog |

`SSOT-EVENT-04` menjadi normative event naming, schema registry, compatibility, versioning, publication, consumer impact, deprecation, dan retirement contract.


## Event Replay, Recovery & Dead-Letter Addition

| SSOT | Depends On | Used By |
|---|---|---|
| SSOT-EVENT-05 | GOV-01, GOV-04, GOV-05, AUDIT-01, EVENT-01..04, INTEGRATION-04, OBS-01, TEST-01 | Dead-Letter Processing, Selective Replay, Consumer Recovery, Snapshot Restore, Disaster Recovery, Event Reconciliation |

`SSOT-EVENT-05` menjadi normative dead-letter lifecycle, replay scope, idempotency, ordering, checkpoint recovery, snapshot restore, reconciliation, dan event-recovery contract.


## Workflow Definition Registry & Versioning Addition

| SSOT | Depends On | Used By |
|---|---|---|
| SSOT-WF-05 | GOV-01, GOV-04, GOV-05, AUDIT-01, EVENT-04, EVENT-05, MODULE-01, RBAC-05, TEST-01 | Approval Flows, Clinical Workflows, Case Management, Task Routing, Workflow Migration |

`SSOT-WF-05` menjadi normative workflow definition, ownership, validation, publication, versioning, compatibility, migration, rollback, dan retirement contract.


## Human Task, Inbox & Assignment Addition

| SSOT | Depends On | Used By |
|---|---|---|
| SSOT-WF-06 | GOV-01, GOV-04, GOV-05, AUDIT-01, RBAC-05, RBAC-06, SCOPE-01, WF-05, NOTIFY-04, OBS-01, TEST-01 | Approval Tasks, Clinical Tasks, Case Work, Team Inbox, Delegation, SLA and Escalation |

`SSOT-WF-06` menjadi normative human-task lifecycle, inbox, assignment, claiming, delegation, SLA, escalation, workload, dan reconciliation contract.


## Workflow Recovery, Compensation & Reconciliation Addition

| SSOT | Depends On | Used By |
|---|---|---|
| SSOT-WF-07 | GOV-01, GOV-04, GOV-05, AUDIT-01, EVENT-05, INTEGRATION-04, WF-05, WF-06, OBS-01, TEST-01 | Workflow Recovery, Stuck Instance Handling, Compensation, Rollback, Task/Timer/Event Repair |

`SSOT-WF-07` menjadi normative stuck-instance detection, workflow recovery, compensation, rollback, manual intervention, checkpoint, dan reconciliation contract.


## API Authorization, Scope & Resource Binding Addition

| SSOT | Depends On | Used By |
|---|---|---|
| SSOT-API-06 | GOV-01, GOV-04, GOV-05, IAM-07, IAM-08, RBAC-05, RBAC-06, RBAC-11, SCOPE-01, DATA-06, AUDIT-01, API-01..05, TEST-01 | REST APIs, Portals, Mobile APIs, Partner APIs, Bulk APIs, File/Search/Workflow APIs |

`SSOT-API-06` menjadi normative API permission, tenant/scope enforcement, resource ownership, field authorization, denial semantics, step-up, break-glass, dan policy-reconciliation contract.


## API Idempotency, Concurrency & Request Safety Addition

| SSOT | Depends On | Used By |
|---|---|---|
| SSOT-API-07 | GOV-01, GOV-04, GOV-05, AUDIT-01, API-01..06, INTEGRATION-04, EVENT-05, OBS-01, TEST-01 | Mutating APIs, Workflow Actions, Bulk APIs, Payment-Like Operations, Mobile and Partner Retries |

`SSOT-API-07` menjadi normative idempotency, request fingerprinting, optimistic concurrency, HTTP preconditions, lock safety, duplicate handling, dan request-reconciliation contract.


## API Consumer, Client Registration & Credential Addition

| SSOT | Depends On | Used By |
|---|---|---|
| SSOT-API-08 | GOV-01, GOV-04, GOV-05, IAM-07, IAM-08, SEC-03, AUDIT-01, API-01..07, INTEGRATION-02, OBS-01, TEST-01 | First-Party Apps, Mobile/Web Clients, Service Accounts, Partner APIs, CLI and Batch Clients |

`SSOT-API-08` menjadi normative API client registration, ownership, credential binding, environment and tenant access, scopes, quotas, lifecycle, suspension, revocation, dan reconciliation contract.


## API Consumer Certification & Conformance Addition

| SSOT | Depends On | Used By |
|---|---|---|
| SSOT-API-09 | GOV-01, GOV-04, GOV-05, IAM-08, SEC-03, AUDIT-01, API-01..08, INTEGRATION-03, INTEGRATION-04, TEST-01 | First-Party Apps, Partner Integrations, Third-Party Consumers, Mobile/Web/Service Clients |

`SSOT-API-09` menjadi normative consumer onboarding test, contract certification, security conformance, compatibility validation, production readiness, renewal, suspension, dan continuous-conformance contract.


## SDK Certification, Compatibility & Release Addition

| SSOT | Depends On | Used By |
|---|---|---|
| SSOT-SDK-03 | GOV-01, GOV-04, GOV-05, API-01..09, EVENT-04, MODULE-01, TEST-01, AUDIT-01 | Official SDKs, Generated Clients, Internal SDKs, Partner SDKs, Consumer Migration |

`SSOT-SDK-03` menjadi normative SDK certification, compatibility, runtime support, release channels, supply-chain assurance, deprecation, migration, dan reconciliation contract.


## Data Exchange, Canonical Mapping & Transformation Addition

| SSOT | Depends On | Used By |
|---|---|---|
| SSOT-DATA-07 | GOV-01, GOV-04, GOV-05, DATA-01..06, MDM-01, EVENT-04, INTEGRATION-01..04, API-01..09, AUDIT-01, TEST-01 | API/Event/File Exchanges, Partner Integrations, Batch Imports, Canonical Models, Data Reconciliation |

`SSOT-DATA-07` menjadi normative canonical exchange, mapping ownership, transformation versioning, validation, quarantine, lineage, reprocessing, dan reconciliation contract.


## Analytics, Metrics & Semantic Layer Addition

| SSOT | Depends On | Used By |
|---|---|---|
| SSOT-ANALYTICS-01 | GOV-01, GOV-04, GOV-05, DATA-01..07, MDM-01, AUDIT-01, API-01..09, TEST-01 | Operational Dashboards, Executive Reports, Regulatory/Financial/Clinical Reporting, Self-Service Analytics |

`SSOT-ANALYTICS-01` menjadi normative metric definition, KPI ownership, semantic modeling, conformed dimensions, certification, lineage, freshness, quality, dan reporting-reconciliation contract.


## Data Quality Operations, Issue Management & Remediation Addition

| SSOT | Depends On | Used By |
|---|---|---|
| SSOT-DATA-08 | GOV-01, GOV-04, GOV-05, DATA-01..07, MDM-01, ANALYTICS-01, AUDIT-01, OBS-01, TEST-01 | Master Data, Exchange Pipelines, Operational Data, Analytics Datasets, Reports, Remediation Operations |

`SSOT-DATA-08` menjadi normative data-quality rules, monitoring, issue lifecycle, SLA, quarantine, root cause, remediation, verification, correction lineage, dan reconciliation contract.


## Tenant, Organization, Facility & Resource Scope Addition

| SSOT | Depends On | Used By |
|---|---|---|
| SSOT-SCOPE-01 | GOV-01, GOV-04, GOV-05, IAM-01..08, RBAC-05..11, AUDIT-01, DATA-06, API-06, TEST-01 | IAM, RBAC, API Authorization, Workflows, Files, Search, Analytics, MDM, Integrations, Background Jobs |

`SSOT-SCOPE-01` menjadi normative tenant hierarchy, organization/facility/clinic scope, resource ownership, assignment binding, inheritance, effective-scope resolution, mutation, isolation, dan reconciliation contract.


## Records, Retention, Legal Hold & Defensible Disposition Addition

| SSOT | Depends On | Used By |
|---|---|---|
| SSOT-RECORDS-01 | GOV-01, GOV-04, GOV-05, DATA-01..08, FILE-02..03, EVENT-04..05, AUDIT-01, SCOPE-01, SEC-03, TEST-01 | Databases, Files, Events, Audit Logs, Reports, Clinical/Financial/Legal Records, Archives, Backups |

`SSOT-RECORDS-01` menjadi normative records classification, retention schedules, legal hold, preservation, archival, chain of custody, defensible disposition, secure destruction, evidence, dan reconciliation contract.


## Privacy Operations, Data Subject Rights & Request Fulfillment Addition

| SSOT | Depends On | Used By |
|---|---|---|
| SSOT-PRIVACY-01 | GOV-01, GOV-04, GOV-05, DATA-01..08, RECORDS-01, SCOPE-01, IAM-01..08, AUDIT-01, FILE-02..03, API-06..09, SEC-03, TEST-01 | Privacy Operations, Data Subject Requests, Portal Services, Data Discovery, Deletion/Restriction Orchestration, Processor Management |

`SSOT-PRIVACY-01` menjadi normative privacy-request intake, identity verification, rights assessment, discovery, correction, deletion, restriction, portability, exemptions, secure delivery, evidence, dan reconciliation contract.


## Data Lifecycle Enforcement, Archival & Secure Disposal Addition

| SSOT | Depends On | Used By |
|---|---|---|
| SSOT-DATA-09 | GOV-01, GOV-04, GOV-05, DATA-01..08, RECORDS-01, PRIVACY-01, FILE-02..03, EVENT-04..05, AUDIT-01, SCOPE-01, SEC-03, TEST-01 | Databases, Files, Search, Analytics, Events, Archives, Backups, External Processors, Tenant Offboarding |

`SSOT-DATA-09` menjadi normative lifecycle-policy execution, archival, restriction, deletion propagation, tombstones, backup re-deletion, secure disposal, evidence, dan reconciliation contract.


## SSOT Repository Integrity, Document Identity & Dependency Validation Addition

| SSOT | Depends On | Used By |
|---|---|---|
| SSOT-GOV-07 | GOV-01..06, AUDIT-01, TEST-01 | Seluruh SSOT, Architecture Governance, CI/CD, Release Management, Audit |

`SSOT-GOV-07` menjadi normative document identity, canonical folder taxonomy, deduplication, index integrity, dependency validation, package manifest, integrity report, dan release-gate contract.
