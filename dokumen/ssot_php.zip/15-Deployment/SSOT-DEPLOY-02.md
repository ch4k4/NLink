# SSOT-DEPLOY-02 — Environment & Configuration Management

---

## Status Dokumen

| Item | Nilai |
|---|---|
| Kode | SSOT-DEPLOY-02 |
| Judul | Environment & Configuration Management |
| Versi | 1.0 |
| Status | Draft for Review |
| Domain | Platform Kernel |
| Kategori | Deployment, Runtime Configuration & Environment Governance |
| Cakupan | Environment Separation, Configuration Hierarchy, Secrets, Feature Flags, Tenant Settings, Validation, Drift, Promotion, Audit, Rollback |
| Bergantung pada | SSOT-DEPLOY-01, SSOT-GOV-06, SSOT-SEC-01, SSOT-SEC-02 |
| Target Stack | PHP 8.1+, Apache/XAMPP, MySQL 8/MariaDB, Modular Monolith |

---

# 1. Executive Summary

SSOT-DEPLOY-02 menetapkan standar resmi untuk environment dan configuration management pada Platform Kernel serta seluruh module bisnis.

Dokumen ini mengatur:

- environment classification;
- environment ownership;
- configuration hierarchy;
- configuration schema;
- defaults;
- environment overrides;
- secrets references;
- tenant configuration;
- module configuration;
- feature flags;
- validation;
- promotion;
- drift detection;
- configuration change governance;
- rollback;
- audit;
- metrics;
- UAT;
- Definition of Done.

Tujuan akhirnya adalah memastikan konfigurasi:

- konsisten;
- tervalidasi;
- aman;
- dapat diaudit;
- tidak tersebar secara ad hoc;
- terpisah dari source code;
- dapat dipromosikan;
- dapat dipulihkan;
- tidak menyebabkan configuration drift;
- mendukung multi-tenant dan multi-module.

---

# 2. Objectives

Framework harus:

- memisahkan code dari configuration;
- mencegah secret leakage;
- menjaga environment parity;
- mengontrol runtime overrides;
- mendukung tenant/module-specific settings;
- mengelola feature flags;
- memastikan config validation;
- mendeteksi drift;
- menjaga rollback;
- menyediakan audit trail.

---

# 3. Core Principles

```text
Configuration Is Code-Like
Secrets Are References, Not Values
Fail Fast on Critical Misconfiguration
Explicit Precedence
No Hidden Defaults
Environment Isolation
Tenant-Safe Overrides
Versioned Changes
Auditable Runtime State
Rollback Ready
```

---

# 4. Scope

Framework berlaku untuk:

```text
Application Configuration
Platform Kernel Configuration
Module Configuration
Environment Variables
Secrets References
Tenant Settings
Clinic Settings
Feature Flags
Runtime Toggles
Integration Endpoints
Scheduler Settings
Worker Settings
Security Policies
Observability Settings
```

---

# 5. Environment Model

```text
LOCAL
TEST
STAGING
PREPROD
PRODUCTION
```

---

# 6. Environment Purpose

## LOCAL

- development;
- debugging;
- local feature testing;
- no production secrets.

## TEST

- automated testing;
- integration testing;
- security testing;
- migration validation.

## STAGING

- production-like validation;
- UAT;
- release rehearsal;
- config promotion validation.

## PREPROD

- optional final gate;
- production-like security;
- final performance/readiness.

## PRODUCTION

- live workload;
- restricted access;
- approved changes only.

---

# 7. Environment Isolation

Each environment must have separate:

- database;
- credentials;
- secret namespace;
- storage;
- cache;
- queues;
- scheduler state;
- logs;
- external endpoints;
- feature flag state.

---

# 8. Environment Identifier

Recommended:

```text
local
test
staging
preprod
production
```

---

# 9. Environment Metadata

Minimum:

```text
environment_code
purpose
owner
criticality
data_classification
internet_exposure
change_policy
backup_policy
```

---

# 10. Environment Owner

Responsible for:

- readiness;
- access;
- configuration baseline;
- drift remediation;
- evidence;
- lifecycle.

---

# 11. Configuration Architecture

Configuration layers:

```text
Code Defaults
→ Platform Defaults
→ Environment Configuration
→ Secret References
→ Module Configuration
→ Tenant/Clinic Overrides
→ Runtime Feature Flags
```

---

# 12. Precedence Rules

Highest priority wins only where override is allowed.

Recommended order:

```text
1. Runtime Emergency Override
2. Tenant/Clinic Override
3. Module Override
4. Environment Override
5. Platform Default
6. Code Default
```

---

# 13. Override Policy

Not every key may be overridden at every layer.

---

# 14. Configuration Categories

```text
STATIC
ENVIRONMENT_SPECIFIC
SECRET_REFERENCE
TENANT_OVERRIDABLE
MODULE_OVERRIDABLE
RUNTIME_TOGGLE
IMMUTABLE_AT_RUNTIME
```

---

# 15. Configuration Key Naming

Use:

```text
UPPER_SNAKE_CASE
```

for environment variables.

Use dotted keys internally:

```text
security.session.idle_timeout
homecare.visit.max_daily_assignments
observability.log.level
```

---

# 16. Configuration Schema

Every configuration key should define:

```text
key
type
required
default
allowed_values
min
max
sensitive
override_scope
restart_required
owner
description
```

---

# 17. Configuration Types

```text
STRING
INTEGER
BOOLEAN
DECIMAL
ENUM
DURATION
URL
PATH
JSON
SECRET_REFERENCE
```

---

# 18. Required Configuration

Critical required config must fail application startup when missing or invalid.

---

# 19. Optional Configuration

Optional configuration must have explicit safe default.

---

# 20. Hidden Defaults

Avoid undocumented implicit defaults.

---

# 21. Configuration Registry

Recommended fields:

```text
config_key
category
type
default_value
required
sensitive
owner
allowed_override_scope
validation_rule
status
```

---

# 22. Configuration Status

```text
DRAFT
ACTIVE
DEPRECATED
RETIRED
```

---

# 23. Configuration Ownership

Every key must have an owner.

---

# 24. Configuration Documentation

Each key should document:

- purpose;
- type;
- default;
- allowed range;
- security impact;
- restart requirement;
- environment applicability.

---

# 25. Configuration Source

Allowed sources:

```text
ENVIRONMENT_VARIABLE
CONFIG_FILE
DATABASE_CONFIG
SECRET_STORE_REFERENCE
FEATURE_FLAG_SERVICE
```

---

# 26. Source Control Rules

Allowed in source control:

- defaults;
- templates;
- schema;
- non-sensitive examples.

Not allowed:

- production secrets;
- real credentials;
- private keys;
- unrestricted tokens.

---

# 27. .env Rules

`.env` may be used locally, but:

- must be gitignored;
- must not contain shared production secrets;
- must have `.env.example`;
- must be validated.

---

# 28. .env.example

Must contain:

- key names;
- safe examples;
- comments;
- no real secret.

---

# 29. Secret References

Configuration should reference secrets by logical identifier.

Example:

```dotenv
DB_PASSWORD_SECRET_REF=secret://platform/production/database/password
```

---

# 30. Secret Handling

Secrets must:

- be encrypted at rest;
- be access-controlled;
- be rotated;
- not appear in logs;
- not appear in error messages;
- not be returned by config APIs.

---

# 31. Secret Resolution

Secret resolution should occur at controlled runtime boundary.

---

# 32. Secret Cache

If cached:

- short TTL;
- encrypted memory where feasible;
- no disk persistence;
- rotation-aware.

---

# 33. Secret Rotation

Rotation must support:

- staged replacement;
- overlap period;
- validation;
- revocation;
- evidence.

---

# 34. Environment-Specific Configuration

Examples:

```text
APP_URL
DB_HOST
CACHE_DRIVER
QUEUE_DRIVER
LOG_LEVEL
MAIL_ENDPOINT
INTEGRATION_BASE_URL
```

---

# 35. Configuration Promotion

Configuration promotion should move:

```text
Schema/Intent
→ Staging Value Set
→ Validation
→ Production Value Set
```

Values may differ, but key set and constraints should remain consistent.

---

# 36. Promotion Rules

Promotion requires:

- schema compatibility;
- validation pass;
- approval;
- secret references resolvable;
- no deprecated key;
- rollback snapshot.

---

# 37. Configuration Package

Recommended contents:

```text
environment_code
config_version
key_values
secret_references
feature_flags
schema_version
checksum
approved_by
```

---

# 38. Configuration Versioning

Use immutable version identifiers.

Example:

```text
CFG-PROD-2026-07-05-001
```

---

# 39. Configuration Snapshot

Snapshot should capture effective configuration without exposing secret values.

---

# 40. Effective Configuration

Effective config is the resolved result after all allowed layers.

---

# 41. Effective Config Inspection

Internal tools may expose:

- key;
- source layer;
- masked value;
- version;
- owner.

---

# 42. Sensitive Value Masking

Examples:

```text
********
secret://...
hash:abc123
```

---

# 43. Configuration Validation

Validation stages:

```text
Syntax
→ Type
→ Range
→ Dependency
→ Security
→ Environment
→ Runtime Readiness
```

---

# 44. Syntax Validation

Examples:

- valid JSON;
- valid URL;
- valid path;
- valid enum.

---

# 45. Dependency Validation

Example:

```text
QUEUE_ENABLED=true
requires
QUEUE_DRIVER != none
```

---

# 46. Security Validation

Examples:

- production debug false;
- secure cookies true;
- trusted proxy list valid;
- secret refs used instead of plaintext;
- tenant isolation enabled.

---

# 47. Environment Validation

Example:

```text
APP_ENV=production
must not use
MAIL_ENDPOINT=localhost-test
```

---

# 48. Runtime Readiness Validation

Checks:

- database reachable;
- storage writable;
- secret refs resolvable;
- required directories exist;
- scheduler config valid.

---

# 49. Fail-Fast Policy

Critical misconfiguration should block startup/deployment.

---

# 50. Warning Policy

Non-critical config issue may emit warning with owner and remediation deadline.

---

# 51. Validation Result

```text
PASS
PASS_WITH_WARNING
FAIL
UNKNOWN
```

---

# 52. Configuration Drift

Drift occurs when actual config differs from approved expected state.

---

# 53. Drift Sources

- manual file edit;
- direct database update;
- untracked env var change;
- emergency override;
- outdated node;
- incomplete promotion;
- secret ref mismatch.

---

# 54. Drift Detection

Compare:

```text
Expected Snapshot
vs
Runtime Effective Configuration
```

---

# 55. Drift Severity

```text
LOW
MEDIUM
HIGH
CRITICAL
```

---

# 56. Critical Drift Examples

- debug enabled in production;
- tenant isolation disabled;
- insecure cookie setting;
- wrong database target;
- production using test secret;
- logging of sensitive data enabled.

---

# 57. Drift Response

```text
Detect
→ Classify
→ Alert
→ Reconcile
→ Verify
→ Record
```

---

# 58. Drift Tolerance

Some dynamic fields may be excluded by policy.

---

# 59. Configuration Change Governance

Every production config change is a governed change.

---

# 60. Config Change Record

Minimum:

```text
change_id
config_key
old_source
new_source
reason
risk
owner
approver
effective_at
rollback_version
```

---

# 61. Configuration Change Types

```text
STANDARD
NORMAL
HIGH_RISK
EMERGENCY
```

---

# 62. High-Risk Configuration

Examples:

- authentication policy;
- authorization mode;
- tenant isolation;
- encryption;
- secrets;
- database connection;
- external endpoints;
- log redaction;
- backup target.

---

# 63. Emergency Override

Emergency overrides must:

- be time-bound;
- have owner;
- have expiry;
- be audited;
- have reconciliation plan.

---

# 64. Runtime Override

Runtime overrides should be limited to approved keys.

---

# 65. Override Expiry

Every temporary override must have expiry.

---

# 66. Feature Flag Architecture

Feature flags are runtime controls, not permanent configuration substitutes.

---

# 67. Feature Flag Types

```text
RELEASE
EXPERIMENT
OPERATIONAL
PERMISSION
KILL_SWITCH
```

---

# 68. Release Flag

Controls staged rollout of new functionality.

---

# 69. Experiment Flag

Controls controlled experiment.

Must respect privacy and consent where applicable.

---

# 70. Operational Flag

Controls runtime behavior.

---

# 71. Permission Flag

Must not replace authorization checks.

---

# 72. Kill Switch

Used to rapidly disable risky functionality.

---

# 73. Feature Flag Record

```text
flag_key
type
owner
default
environments
targeting
created_at
review_due_at
expires_at
status
```

---

# 74. Feature Flag Status

```text
DRAFT
ACTIVE
PAUSED
EXPIRED
RETIRED
```

---

# 75. Flag Targeting

Potential scopes:

```text
GLOBAL
ENVIRONMENT
TENANT
CLINIC
USER_SEGMENT
USER
```

---

# 76. Tenant-Safe Targeting

Tenant/clinic targeting must use trusted server-side context.

---

# 77. Flag Default

Safe default should be explicit.

---

# 78. Flag Expiry

Release and experiment flags should have removal date.

---

# 79. Flag Cleanup

Expired flags must be removed from code and registry.

---

# 80. Flag Audit

Audit:

- created;
- enabled;
- disabled;
- targeting changed;
- expired;
- retired.

---

# 81. Tenant Configuration

Tenant configuration may control approved business behavior.

---

# 82. Tenant Configuration Examples

```text
branding
business hours
notification preferences
module enablement
service limits
locale
```

---

# 83. Tenant Configuration Restrictions

Tenant config must not disable mandatory security or compliance controls.

---

# 84. Clinic Configuration

Clinic-level overrides may exist where approved.

---

# 85. Tenant/Clinic Precedence

Recommended:

```text
Tenant Default
→ Clinic Override
```

---

# 86. Module Configuration

Each module should define:

- owned keys;
- defaults;
- validation;
- override scopes;
- restart behavior.

---

# 87. Module Enablement

Module enablement should be:

- licensed/authorized;
- tenant-scoped;
- dependency-validated;
- auditable.

---

# 88. Dynamic Menu Configuration

Dynamic menu may depend on:

- module enablement;
- permissions;
- tenant config;
- feature flags.

Menu visibility must not replace authorization.

---

# 89. Configuration Dependency Graph

Config registry should support dependencies between keys.

---

# 90. Circular Dependencies

Circular config dependencies are prohibited.

---

# 91. Restart Requirement

Each key should define:

```text
NO_RESTART
APPLICATION_RELOAD
WORKER_RESTART
FULL_RESTART
```

---

# 92. Hot Reload

Hot reload allowed only for approved keys with safe semantics.

---

# 93. Configuration Cache

Cache must be:

- version-aware;
- invalidation-aware;
- tenant-safe;
- restart-safe.

---

# 94. Cache Key Scope

Include:

```text
environment
tenant
clinic
module
config_version
```

where applicable.

---

# 95. Configuration API

Internal configuration APIs must:

- authenticate;
- authorize;
- validate;
- audit;
- mask secrets;
- enforce scope.

---

# 96. Read API

Potential:

```text
GET /api/internal/v1/config/effective
GET /api/internal/v1/config/schema
GET /api/internal/v1/config/versions
```

---

# 97. Write API

Potential:

```text
POST /api/internal/v1/config/changes
POST /api/internal/v1/config/validate
POST /api/internal/v1/config/promote
POST /api/internal/v1/config/rollback
```

---

# 98. Database Direction

Potential tables:

```text
cfg_definitions
cfg_environment_values
cfg_module_values
cfg_tenant_values
cfg_clinic_values
cfg_versions
cfg_change_requests
cfg_snapshots
cfg_drift_events
cfg_feature_flags
cfg_feature_flag_targets
```

---

# 99. Table: cfg_definitions

```sql
CREATE TABLE cfg_definitions (
    id CHAR(26) NOT NULL,
    config_key VARCHAR(255) NOT NULL,
    category VARCHAR(50) NOT NULL,
    value_type VARCHAR(30) NOT NULL,
    default_value_text LONGTEXT NULL,
    required_flag TINYINT(1) NOT NULL DEFAULT 0,
    sensitive_flag TINYINT(1) NOT NULL DEFAULT 0,
    tenant_overridable_flag TINYINT(1) NOT NULL DEFAULT 0,
    clinic_overridable_flag TINYINT(1) NOT NULL DEFAULT 0,
    restart_requirement VARCHAR(30) NOT NULL,
    owner_reference VARCHAR(180) NOT NULL,
    validation_rule_text LONGTEXT NULL,
    status VARCHAR(30) NOT NULL,

    PRIMARY KEY (id),
    UNIQUE KEY uq_cfg_definition_key (
        config_key
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

# 100. Table: cfg_environment_values

```sql
CREATE TABLE cfg_environment_values (
    id CHAR(26) NOT NULL,
    definition_id CHAR(26) NOT NULL,
    environment_code VARCHAR(30) NOT NULL,
    value_text LONGTEXT NULL,
    secret_reference VARCHAR(1000) NULL,
    config_version VARCHAR(100) NOT NULL,
    status VARCHAR(30) NOT NULL,
    effective_from DATETIME(6) NULL,
    effective_until DATETIME(6) NULL,

    PRIMARY KEY (id),
    UNIQUE KEY uq_cfg_environment_value (
        definition_id,
        environment_code,
        config_version
    ),
    CONSTRAINT fk_cfg_environment_definition
        FOREIGN KEY (definition_id)
        REFERENCES cfg_definitions (id)
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

# 101. Table: cfg_tenant_values

```sql
CREATE TABLE cfg_tenant_values (
    id CHAR(26) NOT NULL,
    definition_id CHAR(26) NOT NULL,
    tenant_id CHAR(26) NOT NULL,
    value_text LONGTEXT NULL,
    config_version VARCHAR(100) NOT NULL,
    status VARCHAR(30) NOT NULL,
    effective_from DATETIME(6) NULL,
    effective_until DATETIME(6) NULL,

    PRIMARY KEY (id),
    UNIQUE KEY uq_cfg_tenant_value (
        definition_id,
        tenant_id,
        config_version
    ),
    CONSTRAINT fk_cfg_tenant_definition
        FOREIGN KEY (definition_id)
        REFERENCES cfg_definitions (id)
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

# 102. Table: cfg_feature_flags

```sql
CREATE TABLE cfg_feature_flags (
    id CHAR(26) NOT NULL,
    flag_key VARCHAR(255) NOT NULL,
    flag_type VARCHAR(30) NOT NULL,
    owner_reference VARCHAR(180) NOT NULL,
    default_enabled_flag TINYINT(1) NOT NULL DEFAULT 0,
    status VARCHAR(30) NOT NULL,
    review_due_at DATETIME(6) NULL,
    expires_at DATETIME(6) NULL,
    created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),

    PRIMARY KEY (id),
    UNIQUE KEY uq_cfg_feature_flag_key (
        flag_key
    ),
    KEY idx_cfg_feature_flag_status (
        status,
        expires_at
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

# 103. Configuration Event Codes

```text
CFG_DEFINITION_CREATED
CFG_VALUE_CHANGED
CFG_VALIDATION_FAILED
CFG_VERSION_APPROVED
CFG_PROMOTED
CFG_ROLLED_BACK
CFG_DRIFT_DETECTED
CFG_EMERGENCY_OVERRIDE_CREATED
CFG_EMERGENCY_OVERRIDE_EXPIRED
CFG_FEATURE_FLAG_ENABLED
CFG_FEATURE_FLAG_DISABLED
CFG_FEATURE_FLAG_EXPIRED
```

---

# 104. Configuration Error Codes

```text
CFG_KEY_NOT_FOUND
CFG_VALUE_INVALID
CFG_REQUIRED_VALUE_MISSING
CFG_OVERRIDE_NOT_ALLOWED
CFG_SECRET_REFERENCE_INVALID
CFG_ENVIRONMENT_MISMATCH
CFG_DEPENDENCY_INVALID
CFG_PROMOTION_BLOCKED
CFG_ROLLBACK_FAILED
CFG_DRIFT_DETECTED
CFG_FEATURE_FLAG_EXPIRED
```

---

# 105. Configuration Metrics

```text
config_change_total
config_validation_failure_total
config_drift_total
config_drift_critical_total
config_rollback_total
secret_reference_failure_total
feature_flag_active_total
feature_flag_expired_total
temporary_override_active_total
```

---

# 106. Initial KPIs

```text
Production secrets committed = 0
Critical config validation failures unresolved = 0
Critical drift unresolved = 0
Expired temporary overrides = 0
Feature flags without owner = 0
Configuration rollback availability = 100%
```

---

# 107. Configuration Dashboard

Recommended views:

- config changes by environment;
- drift events;
- validation failures;
- secret resolution failures;
- active overrides;
- feature flags near expiry;
- tenant overrides;
- rollback history.

---

# 108. Access Matrix

| Role | Read Effective Config | Change Non-Prod | Change Prod | Read Secrets |
|---|---|---|---|---|
| Developer | Yes | Limited | No | No |
| QA | Yes | Limited | No | No |
| Release Engineer | Yes | Yes | Approved only | No |
| Operations | Yes | Yes | Approved only | Restricted |
| Security | Review | Review | Review | Restricted |
| Tenant Admin | Tenant scope | Tenant scope | Tenant scope | No |

---

# 109. Segregation of Duties

Critical config changes should separate:

- requester;
- approver;
- implementer;
- verifier.

---

# 110. Configuration Backup

Back up:

- config definitions;
- approved values;
- snapshots;
- feature flags;
- override records;
- audit history.

---

# 111. Configuration Rollback

Rollback should restore a prior approved version.

---

# 112. Rollback Preconditions

- prior version exists;
- schema compatible;
- secret refs valid;
- owner approved;
- validation passes.

---

# 113. Rollback Process

```text
Select Version
→ Validate
→ Approve
→ Apply
→ Reload/Restart
→ Verify
→ Record
```

---

# 114. Configuration Recovery

Disaster recovery must include configuration repository and secret references.

---

# 115. Reference `.env.example`

```dotenv
APP_ENV=local
APP_DEBUG=true
APP_URL=http://platform.local

DB_HOST=127.0.0.1
DB_PORT=3306
DB_DATABASE=platform_db
DB_USERNAME=platform_app
DB_PASSWORD_SECRET_REF=secret://local/database/password

SECURITY_POLICY_MODE=SHADOW
SEC_SDLC_MODE=SHADOW

LOG_LEVEL=debug
FEATURE_FLAGS_PROVIDER=database
CONFIG_VERSION=CFG-LOCAL-001
```

---

# 116. Reference Configuration Definition

```yaml
key: security.session.idle_timeout
type: DURATION
required: true
default: 1800
min: 300
max: 28800
sensitive: false
override_scope:
  - environment
restart_required: false
owner: platform_security
```

---

# 117. Reference Feature Flag

```yaml
flag_key: homecare.new_visit_workflow
type: RELEASE
owner: homecare_module_owner
default: false
environments:
  staging: true
  production: false
targeting:
  tenants:
    - tenant_demo
review_due_at: 2026-08-01
expires_at: 2026-09-01
status: ACTIVE
```

---

# 118. Pre-Deployment Configuration Checklist

- [ ] Config schema valid.
- [ ] Required keys present.
- [ ] Secret refs resolve.
- [ ] Environment endpoints correct.
- [ ] Debug policy correct.
- [ ] Security settings correct.
- [ ] Feature flags reviewed.
- [ ] Tenant overrides validated.
- [ ] Snapshot created.
- [ ] Rollback version available.

---

# 119. Post-Deployment Configuration Checklist

- [ ] Effective config matches expected.
- [ ] No critical drift.
- [ ] Secret resolution healthy.
- [ ] Feature flags correct.
- [ ] Tenant scopes correct.
- [ ] Scheduler/worker config correct.
- [ ] Audit event recorded.
- [ ] Rollback remains available.

---

# 120. UAT — Environment Management

- [ ] Environment list defined.
- [ ] Owners assigned.
- [ ] Credentials separated.
- [ ] Databases separated.
- [ ] Storage separated.
- [ ] External endpoints separated.
- [ ] Production data excluded from local/test.

---

# 121. UAT — Configuration Registry

- [ ] Keys registered.
- [ ] Types defined.
- [ ] Defaults documented.
- [ ] Owners assigned.
- [ ] Sensitive keys marked.
- [ ] Override scopes defined.
- [ ] Restart requirements defined.
- [ ] Deprecated keys tracked.

---

# 122. UAT — Validation

- [ ] Syntax validation works.
- [ ] Type validation works.
- [ ] Range validation works.
- [ ] Dependency validation works.
- [ ] Security validation works.
- [ ] Environment validation works.
- [ ] Critical failures block startup/deployment.
- [ ] Warnings are visible.

---

# 123. UAT — Secrets

- [ ] Secrets absent from source.
- [ ] Secret references resolve.
- [ ] Secrets masked.
- [ ] Logs exclude secrets.
- [ ] Rotation works.
- [ ] Revocation works.
- [ ] Environment separation works.

---

# 124. UAT — Tenant & Module Configuration

- [ ] Tenant overrides allowed only for approved keys.
- [ ] Clinic overrides scoped correctly.
- [ ] Security controls cannot be disabled by tenant.
- [ ] Module dependencies validated.
- [ ] Dynamic menu does not replace authorization.
- [ ] Cache keys are tenant-safe.

---

# 125. UAT — Feature Flags

- [ ] Flag types defined.
- [ ] Owner required.
- [ ] Safe default required.
- [ ] Targeting works.
- [ ] Tenant targeting is trusted.
- [ ] Expiry works.
- [ ] Audit trail works.
- [ ] Retired flags can be removed.

---

# 126. UAT — Promotion & Drift

- [ ] Config versioning works.
- [ ] Snapshots work.
- [ ] Promotion validation works.
- [ ] Drift detection works.
- [ ] Critical drift alerts.
- [ ] Reconciliation works.
- [ ] Emergency overrides expire.
- [ ] Rollback works.

---

# 127. UAT — Governance & Audit

- [ ] Production config changes require approval.
- [ ] High-risk keys trigger review.
- [ ] Segregation of duties works.
- [ ] Change records complete.
- [ ] Audit events complete.
- [ ] Metrics available.
- [ ] Dashboards defined.
- [ ] Backup/recovery covers config.

---

# 128. Definition of Done — SSOT-DEPLOY-02

SSOT-DEPLOY-02 dianggap selesai bila:

- [ ] objectives/principles tersedia;
- [ ] environment model tersedia;
- [ ] environment isolation tersedia;
- [ ] environment ownership tersedia;
- [ ] configuration hierarchy tersedia;
- [ ] precedence rules tersedia;
- [ ] schema/registry tersedia;
- [ ] ownership/documentation tersedia;
- [ ] source control rules tersedia;
- [ ] `.env` rules tersedia;
- [ ] secret references/rotation tersedia;
- [ ] environment configuration tersedia;
- [ ] promotion/versioning/snapshots tersedia;
- [ ] validation model tersedia;
- [ ] fail-fast/warning policy tersedia;
- [ ] drift model tersedia;
- [ ] change governance tersedia;
- [ ] emergency override tersedia;
- [ ] feature flag architecture tersedia;
- [ ] tenant/clinic config tersedia;
- [ ] module configuration tersedia;
- [ ] dependency/restart/cache rules tersedia;
- [ ] API/database direction tersedia;
- [ ] event/error codes tersedia;
- [ ] metrics/KPI/dashboard tersedia;
- [ ] access matrix/SoD tersedia;
- [ ] backup/rollback/recovery tersedia;
- [ ] reference examples tersedia;
- [ ] checklists/UAT tersedia.

---

# 129. Implementation Roadmap

## Phase 1 — Registry Foundation

- define environment inventory;
- create config registry;
- define schemas;
- create `.env.example`;
- assign owners.

## Phase 2 — Validation & Promotion

- implement config validator;
- implement snapshots;
- implement versioning;
- add deployment validation;
- create rollback flow.

## Phase 3 — Secrets & Overrides

- integrate secret references;
- implement tenant/module overrides;
- add feature flag registry;
- add expiry and audit.

## Phase 4 — Drift & Governance

- runtime drift detection;
- dashboards;
- approval routing;
- emergency override management;
- config evidence.

## Phase 5 — Optimization

- centralized config service;
- automated promotion;
- policy-as-code validation;
- continuous compliance;
- multi-node config convergence.

---

# 130. Approval Gate

Dokumen dapat menjadi Approved setelah:

- Platform Governance review;
- Architecture Review Board review;
- Security Governance review;
- Release Engineering review;
- Operations review;
- Module Owner review;
- Multi-tenant configuration review;
- secret management review;
- validation/drift review;
- rollback/recovery review.

---

# 131. Closing Statement

Environment dan configuration management harus memastikan setiap environment dan configuration state:

- memiliki owner;
- memiliki schema;
- memiliki source;
- memiliki version;
- tervalidasi;
- aman;
- tenant-safe;
- dapat dipromosikan;
- dapat dibandingkan;
- dapat dipulihkan;
- dapat diaudit.

Configuration tidak boleh menjadi kumpulan nilai tersebar yang hanya diketahui oleh individu tertentu.

Configuration harus dikelola sebagai controlled runtime asset yang aman, versioned, observable, dan siap mendukung scale platform.
