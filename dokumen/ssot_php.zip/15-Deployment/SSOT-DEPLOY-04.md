# SSOT-DEPLOY-04 — Backup, Restore & Disaster Recovery

---

## Status Dokumen

| Item | Nilai |
|---|---|
| Kode | SSOT-DEPLOY-04 |
| Judul | Backup, Restore & Disaster Recovery |
| Versi | 1.0 |
| Status | Draft for Review |
| Domain | Platform Kernel |
| Kategori | Resilience, Continuity & Recovery |
| Cakupan | Backup Policy, Retention, Encryption, Restore, PITR, RTO/RPO, DR Tiers, Testing, Evidence, Business Continuity |
| Bergantung pada | SSOT-DEPLOY-01, SSOT-DEPLOY-02, SSOT-DEPLOY-03, SSOT-GOV-04, SSOT-GOV-06, SSOT-SEC-01 |
| Target Stack | PHP 8.1+, Apache/XAMPP, MySQL 8/MariaDB, Windows/XAMPP baseline |

---

# 1. Executive Summary

SSOT-DEPLOY-04 menetapkan standar resmi untuk backup, restore, dan disaster recovery pada Platform Kernel serta seluruh module bisnis.

Dokumen ini mengatur:

- backup scope;
- backup classification;
- backup frequency;
- retention;
- encryption;
- integrity;
- backup storage;
- restore;
- point-in-time recovery;
- disaster recovery tiers;
- recovery time objective;
- recovery point objective;
- business continuity;
- DR activation;
- failover;
- recovery testing;
- evidence;
- metrics;
- UAT;
- Definition of Done.

Tujuan akhirnya adalah memastikan platform:

- dapat memulihkan data;
- dapat memulihkan konfigurasi;
- dapat memulihkan artifact;
- dapat memulihkan service;
- memiliki recovery target yang jelas;
- memiliki tested restore;
- memiliki tested DR;
- memiliki evidence;
- tidak menganggap backup sukses hanya karena file backup tersedia.

---

# 2. Objectives

Framework harus:

- mencegah permanent data loss;
- memastikan recoverability;
- menjaga backup integrity;
- mengurangi recovery time;
- mengendalikan retention;
- mendukung incident recovery;
- mendukung ransomware recovery;
- mendukung audit;
- mendukung business continuity;
- meningkatkan operational resilience.

---

# 3. Core Principles

```text
Backup Is Not Recovery Until Tested
Restore Must Be Repeatable
Recovery Targets Must Be Explicit
Critical Backups Must Be Off-Host
Encryption Must Be End-to-End
Backup Access Must Be Restricted
Evidence Must Be Retained
Recovery Must Be Practiced
No Single Point of Recovery
Business Priority Drives Recovery Order
```

---

# 4. Scope

Framework berlaku untuk:

```text
Database
Application Artifacts
Configuration
Secrets Metadata
Private Files
Audit Logs
Security Evidence
Release Evidence
Scheduler Definitions
Infrastructure Configuration
Documentation
```

---

# 5. Backup Categories

```text
DATABASE_BACKUP
FILE_BACKUP
CONFIGURATION_BACKUP
ARTIFACT_BACKUP
LOG_BACKUP
EVIDENCE_BACKUP
SECRET_METADATA_BACKUP
SYSTEM_IMAGE_BACKUP
```

---

# 6. Backup Criticality

```text
CRITICAL
HIGH
MEDIUM
LOW
```

---

# 7. Critical Backup Examples

- production database;
- tenant-restricted files;
- security evidence;
- approved production configuration;
- release artifacts;
- encryption/key metadata references;
- audit records.

---

# 8. Backup Inventory

Minimum fields:

```text
backup_asset_id
asset_type
system
owner
criticality
data_classification
backup_method
frequency
retention
encryption
storage_location
restore_method
rto
rpo
status
```

---

# 9. Backup Ownership

Every backup asset must have:

- system owner;
- backup operator;
- restore owner;
- evidence owner;
- reviewer.

---

# 10. Backup Policy

Policy must define:

```text
What Is Backed Up
How Often
Where Stored
How Long Retained
How Encrypted
How Verified
How Restored
Who Owns It
```

---

# 11. Backup Types

```text
FULL
INCREMENTAL
DIFFERENTIAL
SNAPSHOT
TRANSACTION_LOG
EXPORT
IMAGE
```

---

# 12. Full Backup

Contains complete selected dataset.

---

# 13. Incremental Backup

Contains changes since last backup.

---

# 14. Differential Backup

Contains changes since last full backup.

---

# 15. Snapshot

Captures point-in-time state.

---

# 16. Transaction Log Backup

Supports point-in-time recovery.

For MySQL/MariaDB, this may involve binary logs where supported and configured.

---

# 17. Export Backup

Logical export such as SQL dump.

---

# 18. System Image

Captures full host or runtime image where appropriate.

---

# 19. Backup Strategy

Recommended layered strategy:

```text
Daily Full or Logical Backup
+ Frequent Incremental/Binlog
+ Configuration Snapshot per Change
+ Artifact Retention per Release
+ Off-Host Copy
```

---

# 20. 3-2-1 Principle

Recommended:

```text
3 copies
2 different media/storage types
1 copy off-site/off-host
```

---

# 21. Enhanced 3-2-1-1-0

Recommended for critical systems:

```text
3 copies
2 media
1 off-site
1 immutable/offline
0 unverified errors
```

---

# 22. Backup Frequency

Example baseline:

| Asset | Frequency |
|---|---:|
| Production database full | daily |
| Transaction/binlog | 5–15 minutes or continuous |
| Configuration snapshot | every approved change |
| Release artifacts | every release |
| Private files | daily/incremental |
| Audit/security evidence | daily or continuous |
| Documentation | every change |

---

# 23. Backup Window

Backup window should avoid peak workload where possible.

---

# 24. Online Backup

Online backup must minimize lock impact.

---

# 25. Quiesced Backup

Use when application consistency requires controlled pause.

---

# 26. Application-Consistent Backup

Backup should preserve application-level consistency.

---

# 27. Crash-Consistent Backup

May be acceptable for lower-risk assets but must be documented.

---

# 28. Database Backup Baseline

For MySQL/MariaDB:

```text
Logical Dump
Physical/Snapshot Backup
Binary Log Retention
Restore Validation
```

---

# 29. Logical Backup Example

```bat
D:\xampp\mysql\bin\mysqldump.exe ^
  -u platform_backup ^
  -p ^
  --single-transaction ^
  --routines ^
  --triggers ^
  --events ^
  platform_db ^
  > D:\backup\platform_db_YYYYMMDD_HHMMSS.sql
```

---

# 30. Backup Account

Use dedicated database account.

---

# 31. Backup Account Permissions

Grant only required privileges.

---

# 32. Database Backup Content

Include where applicable:

- schema;
- data;
- routines;
- triggers;
- events;
- migration ledger;
- scheduler state.

---

# 33. Binary Log Strategy

Binary logs should support PITR where supported.

---

# 34. Binlog Retention

Retention must exceed required RPO and recovery investigation window.

---

# 35. File Backup

Private file backup should preserve:

- path/reference;
- tenant ownership;
- checksum;
- metadata;
- classification.

---

# 36. Configuration Backup

Backup:

- config definitions;
- approved values;
- snapshots;
- feature flags;
- environment mappings;
- change history.

---

# 37. Artifact Backup

Retain:

```text
Current
Previous
Last-Known-Good
Critical Historical Releases
```

---

# 38. Evidence Backup

Audit, security, and compliance evidence must follow retention and immutability rules.

---

# 39. Secret Metadata Backup

Backup secret metadata and references, not raw secrets unless governed by approved secret backup design.

---

# 40. Key Management Backup

Cryptographic key recovery must be governed separately and securely.

---

# 41. Backup Storage Tiers

```text
PRIMARY_BACKUP
SECONDARY_BACKUP
OFFSITE_BACKUP
IMMUTABLE_BACKUP
ARCHIVE
```

---

# 42. Backup Location Separation

Backup should not reside only on the same host or disk as production.

---

# 43. Immutable Backup

Critical backup should have immutable or write-once protection where feasible.

---

# 44. Offline Backup

Offline backup may protect against ransomware and destructive compromise.

---

# 45. Backup Encryption

Backups containing confidential/restricted data must be encrypted at rest and in transit.

---

# 46. Encryption Key Separation

Backup encryption keys must be stored separately from backup files.

---

# 47. Backup Access Control

Access must follow least privilege.

---

# 48. Backup Access Roles

```text
Backup Operator
Restore Operator
Backup Reviewer
Security Reviewer
Auditor
```

---

# 49. Separation of Duties

Critical restore should require approval separate from backup operator where feasible.

---

# 50. Backup Naming

Format:

```text
{system}_{asset}_{environment}_{timestamp}_{version}
```

Example:

```text
platform_database_production_20260705_010000_v1.sql.enc
```

---

# 51. Backup Metadata

Minimum:

```text
backup_id
asset_id
started_at
completed_at
size
checksum
encryption
storage_location
status
operator
retention_until
```

---

# 52. Backup Status

```text
SCHEDULED
RUNNING
SUCCEEDED
SUCCEEDED_WITH_WARNING
FAILED
CORRUPTED
EXPIRED
DELETED
```

---

# 53. Backup Integrity

Validate:

- file exists;
- size non-zero;
- checksum;
- encryption;
- readable format;
- expected objects/files;
- restore test.

---

# 54. Backup Verification

Verification levels:

```text
LEVEL 1 — File Presence
LEVEL 2 — Checksum
LEVEL 3 — Structure Validation
LEVEL 4 — Partial Restore
LEVEL 5 — Full Restore and Application Validation
```

---

# 55. Backup Failure

Failure must:

- alert;
- assign owner;
- retry if safe;
- record evidence;
- escalate based on criticality.

---

# 56. Backup Retry

Retries should be bounded and monitored.

---

# 57. Missed Backup

Missed critical backup requires immediate assessment against RPO.

---

# 58. Backup Retention

Retention depends on:

- legal requirements;
- contracts;
- audit;
- business need;
- incident investigation;
- storage cost;
- data minimization.

---

# 59. Example Retention Policy

```text
Daily: 30 days
Weekly: 12 weeks
Monthly: 12 months
Annual: 5–7 years where required
```

---

# 60. Retention Expiry

Expired backups should be securely deleted unless legal hold applies.

---

# 61. Legal Hold

Legal hold overrides normal deletion.

---

# 62. Secure Deletion

Deletion should be auditable and appropriate to storage technology.

---

# 63. Backup Catalog

A searchable backup catalog should exist.

---

# 64. Restore Architecture

Restore is the controlled recovery of data, configuration, files, or runtime state.

---

# 65. Restore Types

```text
FULL_RESTORE
PARTIAL_RESTORE
POINT_IN_TIME_RESTORE
FILE_RESTORE
CONFIG_RESTORE
ARTIFACT_RESTORE
SYSTEM_RESTORE
```

---

# 66. Restore Request

Minimum fields:

```text
restore_id
asset
reason
requested_point
target_environment
requester
approver
operator
status
validation_plan
```

---

# 67. Restore Status

```text
REQUESTED
APPROVED
PREPARING
RESTORING
VALIDATING
COMPLETED
FAILED
CANCELLED
```

---

# 68. Restore Preconditions

- approved request;
- correct backup selected;
- checksum valid;
- key available;
- target isolated;
- capacity sufficient;
- validation plan ready.

---

# 69. Restore Safety

Restore to isolated environment first when feasible.

---

# 70. Production Restore

Production restore requires:

- incident/change authorization;
- impact assessment;
- backup verification;
- communication;
- validation;
- audit trail.

---

# 71. Partial Restore

Partial restore requires dependency and consistency analysis.

---

# 72. Tenant-Specific Restore

Tenant-level restore is high risk.

Must avoid:

- cross-tenant contamination;
- duplicate IDs;
- broken references;
- stale permissions;
- overwritten shared data.

---

# 73. File Restore

Must restore:

- file;
- metadata;
- tenant ownership;
- checksum;
- access rules.

---

# 74. Configuration Restore

Restore prior approved configuration version.

---

# 75. Artifact Restore

Use previously verified release artifact.

---

# 76. Restore Validation

Validate:

- data integrity;
- schema;
- row counts;
- application startup;
- authentication;
- authorization;
- tenant isolation;
- critical business flows;
- audit continuity.

---

# 77. Restore Evidence

Record:

```text
backup_id
restore_id
operator
target
duration
validation
result
issues
approved_by
```

---

# 78. Point-in-Time Recovery

PITR restores data to a specific timestamp or transaction point.

---

# 79. PITR Requirements

- full base backup;
- continuous/log backups;
- timestamp synchronization;
- tested procedure;
- sufficient retention;
- transaction ordering.

---

# 80. PITR Risks

- timezone mismatch;
- missing log segment;
- inconsistent external systems;
- replaying unwanted transaction;
- partial application state.

---

# 81. PITR Validation

Validate:

- target timestamp;
- schema version;
- migration state;
- business data;
- external integration reconciliation.

---

# 82. Recovery Time Objective

RTO defines maximum acceptable recovery duration.

---

# 83. Recovery Point Objective

RPO defines maximum acceptable data loss interval.

---

# 84. Recovery Service Level

Each critical service must define RTO and RPO.

---

# 85. Example Recovery Tiers

| Tier | Criticality | RTO | RPO |
|---|---|---:|---:|
| Tier 0 | Mission critical | < 1 hour | < 15 minutes |
| Tier 1 | Critical | < 4 hours | < 1 hour |
| Tier 2 | Important | < 24 hours | < 24 hours |
| Tier 3 | Non-critical | < 72 hours | < 48 hours |

---

# 86. Recovery Dependency Mapping

Recovery order must account for:

```text
Network
Identity
Secrets/Keys
Database
Storage
Application
Workers/Schedulers
Integrations
Observability
```

---

# 87. Recovery Priority

Business priority should determine recovery sequence.

---

# 88. Disaster Definition

A disaster is an event that exceeds normal incident recovery capability.

---

# 89. Disaster Examples

- host loss;
- database corruption;
- ransomware;
- data center outage;
- widespread credential compromise;
- destructive deployment;
- prolonged infrastructure failure;
- major natural disaster.

---

# 90. Disaster Recovery Lifecycle

```text
Detect
→ Assess
→ Declare
→ Activate
→ Recover
→ Validate
→ Resume
→ Stabilize
→ Review
```

---

# 91. DR Activation Authority

Must be defined.

Potential roles:

```text
Incident Commander
Operations Lead
Platform Owner
Security Lead
Executive Sponsor
```

---

# 92. DR Declaration Criteria

Examples:

- RTO at risk;
- production host unavailable;
- primary database unrecoverable;
- active destructive attack;
- critical storage loss;
- prolonged network failure.

---

# 93. DR Levels

```text
DR-1 — Local Restore
DR-2 — Replacement Host
DR-3 — Alternate Site
DR-4 — Automated Failover
```

---

# 94. DR-1 Local Restore

Restore on same infrastructure after localized failure.

---

# 95. DR-2 Replacement Host

Restore to replacement host in same location.

---

# 96. DR-3 Alternate Site

Restore service in alternate location/site.

---

# 97. DR-4 Automated Failover

Automated or near-automated failover to standby environment.

---

# 98. DR Architecture — Current Baseline

```text
Primary Windows/XAMPP Host
        │
        ├── Local Backup
        ├── Off-Host Database Backup
        ├── Off-Host File Backup
        ├── Artifact Repository
        └── Replacement Host Procedure
```

---

# 99. DR Architecture — Future

```text
Primary Site
├── App Nodes
├── Database Primary
├── Storage
└── Observability
        │
        ▼
Secondary Site
├── Standby App
├── Database Replica/Backups
├── Replicated Storage
└── Recovery Automation
```

---

# 100. Failover

Failover switches service to alternate environment.

---

# 101. Failback

Failback returns service to primary environment after stabilization.

---

# 102. Failback Risks

- data divergence;
- DNS/cache delay;
- replication lag;
- incomplete reconciliation;
- configuration drift.

---

# 103. DR Runbook

Must define:

```text
Purpose
Scope
Activation Criteria
Authority
Contacts
Dependencies
Recovery Sequence
Backup Sources
Restore Steps
Validation
Communication
Failback
Evidence
```

---

# 104. Crisis Communication

Must define communication for:

- internal leadership;
- operations;
- security;
- module owners;
- customers/tenants where applicable;
- vendors;
- regulators where required.

---

# 105. Business Continuity

Business continuity may include:

- manual procedures;
- degraded service;
- alternate communication;
- read-only mode;
- delayed processing;
- service prioritization.

---

# 106. Minimum Viable Service

Define minimum service that must return first.

---

# 107. Degraded Mode

System may operate with reduced functionality if approved and safe.

---

# 108. Recovery Validation

Post-recovery validation should cover:

- version;
- configuration;
- database;
- files;
- identities;
- permissions;
- tenant isolation;
- integrations;
- scheduler/workers;
- logs/metrics.

---

# 109. Recovery Data Reconciliation

Reconcile:

- missing transactions;
- duplicate transactions;
- external system state;
- queue state;
- scheduled jobs;
- file references.

---

# 110. DR Testing

Test types:

```text
TABLETOP
BACKUP_RESTORE
PARTIAL_RECOVERY
TECHNICAL_FAILOVER
FULL_DR_EXERCISE
```

---

# 111. Tabletop Exercise

Walk through scenario and responsibilities.

---

# 112. Backup Restore Test

Restore selected backup and validate.

---

# 113. Partial Recovery Test

Recover one component or service.

---

# 114. Technical Failover Test

Switch to alternate environment.

---

# 115. Full DR Exercise

Simulate full disaster recovery.

---

# 116. Test Frequency

Recommended:

| Test | Frequency |
|---|---:|
| Backup verification | daily/weekly |
| Partial restore | monthly/quarterly |
| Full database restore | quarterly |
| Tabletop DR | semiannual |
| Full DR exercise | annual |

---

# 117. Test Record

Minimum:

```text
test_id
scenario
scope
date
participants
target_rto
target_rpo
actual_rto
actual_rpo
result
findings
actions
```

---

# 118. Test Result

```text
PASS
PASS_WITH_FINDINGS
FAIL
CANCELLED
```

---

# 119. Recovery Gap

A recovery gap occurs when:

- backup missing;
- restore fails;
- RTO exceeded;
- RPO exceeded;
- runbook outdated;
- dependency undocumented;
- key unavailable;
- evidence incomplete.

---

# 120. Recovery Finding

Must enter risk/control/findings workflow.

---

# 121. Ransomware Recovery

Strategy should include:

- immutable backup;
- offline copy;
- credential reset;
- environment rebuild;
- malware-free validation;
- clean restore point;
- evidence preservation.

---

# 122. Cyber Recovery

Cyber recovery differs from normal DR because restored state must be trusted.

---

# 123. Clean Room Recovery

High-risk compromise may require isolated clean environment.

---

# 124. Backup Compromise

If backup integrity is suspect:

- quarantine backup;
- identify clean restore point;
- verify checksum;
- validate malware exposure;
- assess key compromise.

---

# 125. Data Privacy in Backup

Backup retention and restore must respect:

- data minimization;
- deletion obligations;
- legal hold;
- access controls;
- tenant isolation.

---

# 126. Right-to-Delete Complexity

Deleted data may remain in immutable backups until lifecycle expiry if policy/legal basis allows.

---

# 127. Backup Expiry and Data Deletion

Deletion workflow should document how backup copies age out.

---

# 128. Monitoring

Monitor:

```text
backup_success
backup_failure
backup_duration
backup_size
backup_age
restore_test_status
rpo_gap
rto_test_result
dr_test_status
```

---

# 129. Metrics

```text
backup_success_rate
backup_failure_total
critical_backup_age
restore_success_rate
restore_duration
restore_test_pass_rate
rto_compliance_rate
rpo_compliance_rate
dr_test_completion_rate
recovery_finding_overdue_total
```

---

# 130. KPIs

Initial targets:

```text
Critical backup success rate >= 99%
Critical backup unverified = 0
Quarterly restore test completion = 100%
Critical RTO/RPO breaches = 0
Annual DR exercise completion = 100%
Critical recovery findings overdue = 0
```

---

# 131. KRIs

```text
Backup age beyond policy
Failed backup streak
Restore test failure rate
Missing offsite copy
Expired encryption key
DR runbook overdue
RTO/RPO test breach
```

---

# 132. Dashboard Views

Recommended:

- backup status by asset;
- failed backups;
- backup age;
- restore test status;
- RTO/RPO performance;
- DR exercise status;
- recovery findings;
- retention expiry;
- storage capacity.

---

# 133. Alerts

Critical alerts:

- backup failed;
- backup missed;
- backup corrupted;
- restore test failed;
- offsite copy unavailable;
- RPO gap exceeded;
- DR dependency unavailable.

---

# 134. Audit Trail

Audit:

```text
Backup Started
Backup Completed
Backup Failed
Backup Deleted
Restore Requested
Restore Approved
Restore Started
Restore Completed
DR Declared
Failover Started
Failover Completed
Failback Completed
```

---

# 135. Evidence

Minimum:

```text
backup logs
checksums
storage records
restore logs
validation results
DR test reports
RTO/RPO evidence
approvals
communications
findings
```

---

# 136. Evidence Retention

Evidence retention should align with audit and incident requirements.

---

# 137. API Direction

Potential endpoints:

```text
/api/internal/v1/recovery/backups
/api/internal/v1/recovery/restores
/api/internal/v1/recovery/tests
/api/internal/v1/recovery/dr-events
/api/internal/v1/recovery/metrics
/api/internal/v1/recovery/dashboard
```

---

# 138. Database Direction

Potential tables:

```text
bkp_assets
bkp_policies
bkp_jobs
bkp_runs
bkp_files
bkp_checksums
rst_requests
rst_runs
dr_plans
dr_events
dr_tests
dr_findings
```

---

# 139. Table: bkp_assets

```sql
CREATE TABLE bkp_assets (
    id CHAR(26) NOT NULL,
    asset_code VARCHAR(80) NOT NULL,
    asset_type VARCHAR(50) NOT NULL,
    system_reference VARCHAR(180) NOT NULL,
    owner_reference VARCHAR(180) NOT NULL,
    criticality VARCHAR(30) NOT NULL,
    data_classification VARCHAR(30) NOT NULL,
    backup_method VARCHAR(50) NOT NULL,
    frequency VARCHAR(50) NOT NULL,
    retention_days INT UNSIGNED NOT NULL,
    rto_minutes INT UNSIGNED NULL,
    rpo_minutes INT UNSIGNED NULL,
    status VARCHAR(30) NOT NULL,

    PRIMARY KEY (id),
    UNIQUE KEY uq_bkp_asset_code (
        asset_code
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

# 140. Table: bkp_runs

```sql
CREATE TABLE bkp_runs (
    id CHAR(26) NOT NULL,
    asset_id CHAR(26) NOT NULL,
    backup_code VARCHAR(100) NOT NULL,
    backup_type VARCHAR(30) NOT NULL,
    storage_reference VARCHAR(1000) NOT NULL,
    size_bytes BIGINT UNSIGNED NULL,
    checksum_sha256 CHAR(64) NULL,
    encryption_status VARCHAR(30) NOT NULL,
    status VARCHAR(30) NOT NULL,
    started_at DATETIME(6) NOT NULL,
    completed_at DATETIME(6) NULL,
    retention_until DATETIME(6) NULL,
    operator_reference VARCHAR(180) NULL,

    PRIMARY KEY (id),
    UNIQUE KEY uq_bkp_run_code (
        backup_code
    ),
    KEY idx_bkp_run_status (
        status,
        started_at
    ),
    CONSTRAINT fk_bkp_run_asset
        FOREIGN KEY (asset_id)
        REFERENCES bkp_assets (id)
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

# 141. Table: rst_requests

```sql
CREATE TABLE rst_requests (
    id CHAR(26) NOT NULL,
    restore_code VARCHAR(100) NOT NULL,
    asset_id CHAR(26) NOT NULL,
    backup_run_id CHAR(26) NOT NULL,
    restore_type VARCHAR(30) NOT NULL,
    target_environment VARCHAR(30) NOT NULL,
    requested_by VARCHAR(180) NOT NULL,
    approved_by VARCHAR(180) NULL,
    operator_reference VARCHAR(180) NULL,
    reason_text LONGTEXT NOT NULL,
    status VARCHAR(30) NOT NULL,
    requested_at DATETIME(6) NOT NULL,
    completed_at DATETIME(6) NULL,

    PRIMARY KEY (id),
    UNIQUE KEY uq_rst_request_code (
        restore_code
    ),
    KEY idx_rst_request_status (
        status,
        requested_at
    ),
    CONSTRAINT fk_rst_request_asset
        FOREIGN KEY (asset_id)
        REFERENCES bkp_assets (id),
    CONSTRAINT fk_rst_request_backup
        FOREIGN KEY (backup_run_id)
        REFERENCES bkp_runs (id)
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

# 142. Table: dr_tests

```sql
CREATE TABLE dr_tests (
    id CHAR(26) NOT NULL,
    test_code VARCHAR(100) NOT NULL,
    test_type VARCHAR(50) NOT NULL,
    scenario_text LONGTEXT NOT NULL,
    target_rto_minutes INT UNSIGNED NULL,
    target_rpo_minutes INT UNSIGNED NULL,
    actual_rto_minutes INT UNSIGNED NULL,
    actual_rpo_minutes INT UNSIGNED NULL,
    result VARCHAR(30) NOT NULL,
    findings_text LONGTEXT NULL,
    tested_at DATETIME(6) NOT NULL,
    owner_reference VARCHAR(180) NOT NULL,

    PRIMARY KEY (id),
    UNIQUE KEY uq_dr_test_code (
        test_code
    ),
    KEY idx_dr_test_result (
        result,
        tested_at
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

# 143. Event Codes

```text
BKP_BACKUP_SCHEDULED
BKP_BACKUP_STARTED
BKP_BACKUP_SUCCEEDED
BKP_BACKUP_FAILED
BKP_BACKUP_CORRUPTED
BKP_BACKUP_EXPIRED
RST_RESTORE_REQUESTED
RST_RESTORE_APPROVED
RST_RESTORE_STARTED
RST_RESTORE_SUCCEEDED
RST_RESTORE_FAILED
DR_DISASTER_DECLARED
DR_FAILOVER_STARTED
DR_FAILOVER_COMPLETED
DR_FAILBACK_COMPLETED
DR_TEST_COMPLETED
```

---

# 144. Error Codes

```text
BKP_ASSET_NOT_FOUND
BKP_POLICY_NOT_FOUND
BKP_BACKUP_FAILED
BKP_CHECKSUM_INVALID
BKP_ENCRYPTION_INVALID
BKP_RETENTION_INVALID
RST_BACKUP_NOT_FOUND
RST_BACKUP_CORRUPTED
RST_APPROVAL_REQUIRED
RST_RESTORE_FAILED
RST_VALIDATION_FAILED
DR_RTO_EXCEEDED
DR_RPO_EXCEEDED
DR_RUNBOOK_MISSING
DR_FAILOVER_FAILED
DR_FAILBACK_FAILED
```

---

# 145. Sample Backup Policy

```yaml
asset_code: BKP-PROD-DB
asset_type: DATABASE
system: platform_production
criticality: CRITICAL
backup_method:
  full: daily
  binlog: continuous
retention:
  daily: 30_days
  weekly: 12_weeks
  monthly: 12_months
encryption: required
offsite_copy: required
immutable_copy: required
rto: 240_minutes
rpo: 15_minutes
owner: platform_operations
```

---

# 146. Sample Restore Test

```yaml
test_code: DRTEST-2026-Q3-001
test_type: FULL_DATABASE_RESTORE
scenario: Restore latest production database backup into isolated staging environment.
target_rto_minutes: 240
target_rpo_minutes: 15
actual_rto_minutes: 150
actual_rpo_minutes: 10
result: PASS
```

---

# 147. Sample DR Scenario

```yaml
scenario: Primary production host unavailable
dr_level: DR-2
recovery_target: replacement_host
recovery_sequence:
  - provision_host
  - install_runtime
  - restore_configuration
  - restore_database
  - restore_private_files
  - deploy_last_known_good_artifact
  - validate
  - switch_endpoint
```

---

# 148. Backup Checklist

- [ ] Asset registered.
- [ ] Owner assigned.
- [ ] Criticality defined.
- [ ] Frequency defined.
- [ ] Retention defined.
- [ ] Encryption enabled.
- [ ] Off-host copy available.
- [ ] Checksum generated.
- [ ] Backup log retained.
- [ ] Restore method documented.

---

# 149. Restore Checklist

- [ ] Request approved.
- [ ] Correct backup selected.
- [ ] Checksum valid.
- [ ] Encryption key available.
- [ ] Target isolated.
- [ ] Capacity sufficient.
- [ ] Restore steps ready.
- [ ] Validation plan ready.
- [ ] Audit capture active.
- [ ] Communication ready.

---

# 150. DR Activation Checklist

- [ ] Disaster criteria met.
- [ ] Authority confirms activation.
- [ ] Incident command active.
- [ ] Recovery tier selected.
- [ ] Dependencies mapped.
- [ ] Backup source selected.
- [ ] Communication initiated.
- [ ] Recovery runbook started.
- [ ] RTO/RPO clock started.
- [ ] Evidence capture active.

---

# 151. Post-Recovery Checklist

- [ ] Version correct.
- [ ] Configuration correct.
- [ ] Database consistent.
- [ ] Files available.
- [ ] Authentication works.
- [ ] Authorization works.
- [ ] Tenant isolation works.
- [ ] Integrations reconciled.
- [ ] Scheduler/workers active.
- [ ] Logs/metrics active.
- [ ] Users informed.
- [ ] Findings recorded.

---

# 152. UAT — Backup Governance

- [ ] Backup inventory exists.
- [ ] Criticality defined.
- [ ] Owners assigned.
- [ ] Backup policy defined.
- [ ] Frequencies configured.
- [ ] Retention configured.
- [ ] Encryption enabled.
- [ ] Off-host copy exists.
- [ ] Immutable/offline copy exists for critical assets.
- [ ] Backup catalog works.

---

# 153. UAT — Backup Integrity

- [ ] Backup file exists.
- [ ] Size non-zero.
- [ ] Checksum valid.
- [ ] Encryption valid.
- [ ] Structure validation passes.
- [ ] Failed backup alerts.
- [ ] Missed backup alerts.
- [ ] Expired backups deleted according policy.
- [ ] Legal hold blocks deletion.

---

# 154. UAT — Restore

- [ ] Restore request workflow works.
- [ ] Approval required.
- [ ] Correct backup selection works.
- [ ] Isolated restore works.
- [ ] Database restore succeeds.
- [ ] File restore succeeds.
- [ ] Config restore succeeds.
- [ ] Validation succeeds.
- [ ] Restore evidence retained.
- [ ] Failed restore escalates.

---

# 155. UAT — PITR

- [ ] Base backup available.
- [ ] Log chain complete.
- [ ] Target timestamp accepted.
- [ ] PITR completes.
- [ ] Schema version valid.
- [ ] Business data reconciled.
- [ ] External systems reconciled.
- [ ] RPO measured.

---

# 156. UAT — Disaster Recovery

- [ ] DR levels defined.
- [ ] Activation authority defined.
- [ ] Declaration criteria defined.
- [ ] Runbook exists.
- [ ] Replacement host procedure works.
- [ ] Alternate site procedure defined.
- [ ] Recovery order works.
- [ ] Failover tested.
- [ ] Failback tested.
- [ ] Communications tested.

---

# 157. UAT — RTO/RPO

- [ ] Critical services classified.
- [ ] RTO defined.
- [ ] RPO defined.
- [ ] Actual values measured.
- [ ] Breaches visible.
- [ ] Recovery gaps create findings.
- [ ] Targets reviewed periodically.

---

# 158. UAT — Cyber Recovery

- [ ] Immutable backup available.
- [ ] Offline backup available.
- [ ] Clean restore point identifiable.
- [ ] Compromised credentials rotated.
- [ ] Clean-room recovery procedure defined.
- [ ] Malware validation included.
- [ ] Evidence preservation included.

---

# 159. UAT — Metrics & Evidence

- [ ] Metrics defined.
- [ ] Dashboard defined.
- [ ] Alerts work.
- [ ] Audit trail complete.
- [ ] DR test evidence retained.
- [ ] Restore test evidence retained.
- [ ] Findings tracked.
- [ ] KPIs/KRIs defined.

---

# 160. Definition of Done — SSOT-DEPLOY-04

SSOT-DEPLOY-04 dianggap selesai bila:

- [ ] objectives/principles tersedia;
- [ ] backup categories tersedia;
- [ ] criticality model tersedia;
- [ ] inventory/ownership tersedia;
- [ ] backup policy tersedia;
- [ ] backup types tersedia;
- [ ] layered strategy tersedia;
- [ ] frequency/window tersedia;
- [ ] database/file/config/artifact backup tersedia;
- [ ] storage tiers tersedia;
- [ ] off-host/immutable/offline strategy tersedia;
- [ ] encryption/access control tersedia;
- [ ] naming/metadata/status tersedia;
- [ ] integrity/verification tersedia;
- [ ] failure/retry/missed backup tersedia;
- [ ] retention/legal hold/deletion tersedia;
- [ ] restore architecture tersedia;
- [ ] restore request/status/preconditions tersedia;
- [ ] partial/tenant/file/config/artifact restore tersedia;
- [ ] PITR tersedia;
- [ ] RTO/RPO tersedia;
- [ ] dependency/recovery priority tersedia;
- [ ] disaster definition/lifecycle tersedia;
- [ ] activation authority/criteria tersedia;
- [ ] DR levels tersedia;
- [ ] failover/failback tersedia;
- [ ] DR runbook tersedia;
- [ ] business continuity/degraded mode tersedia;
- [ ] reconciliation tersedia;
- [ ] testing model/frequency tersedia;
- [ ] ransomware/cyber recovery tersedia;
- [ ] privacy/retention consideration tersedia;
- [ ] monitoring/metrics/KPI/KRI tersedia;
- [ ] alerts/audit/evidence tersedia;
- [ ] API/database direction tersedia;
- [ ] event/error codes tersedia;
- [ ] samples/checklists tersedia;
- [ ] UAT tersedia.

---

# 161. Implementation Roadmap

## Phase 1 — Backup Foundation

- create backup inventory;
- assign owners;
- define policies;
- configure database backup;
- configure off-host copy;
- enable checksums and encryption.

## Phase 2 — Restore Readiness

- document restore procedures;
- implement restore requests;
- test database restore;
- test file/config restore;
- create evidence templates.

## Phase 3 — PITR & Retention

- enable binary log strategy;
- test PITR;
- implement retention;
- implement legal hold handling;
- monitor backup age.

## Phase 4 — Disaster Recovery

- define RTO/RPO;
- create DR runbook;
- establish replacement host;
- run tabletop;
- run technical recovery exercise.

## Phase 5 — Advanced Resilience

- immutable/offline backups;
- alternate site;
- automated recovery;
- clean-room cyber recovery;
- continuous recovery testing.

---

# 162. Approval Gate

Dokumen dapat menjadi Approved setelah:

- Platform Governance review;
- Operations review;
- Security Governance review;
- Database review;
- Data/Privacy review;
- Risk & Compliance review;
- Business Continuity review;
- restore testing review;
- RTO/RPO approval;
- DR runbook and exercise review;
- evidence and metrics review.

---

# 163. Closing Statement

Backup, restore, dan disaster recovery harus memastikan setiap critical asset:

- diketahui;
- memiliki owner;
- memiliki backup;
- memiliki retention;
- terenkripsi;
- diverifikasi;
- dapat direstore;
- memiliki RTO/RPO;
- memiliki recovery runbook;
- diuji secara berkala;
- dapat diaudit.

Backup tidak boleh dianggap berhasil hanya karena job selesai.

Backup baru bernilai ketika data, konfigurasi, artifact, dan service benar-benar dapat dipulihkan dalam target waktu dan target kehilangan data yang telah disetujui.
