# SSOT-DEPLOY-01 — Deployment Architecture

---

## Status Dokumen

| Item | Nilai |
|---|---|
| Kode | SSOT-DEPLOY-01 |
| Judul | Deployment Architecture |
| Versi | 1.0 |
| Status | Draft for Review |
| Domain | Platform Kernel |
| Kategori | Deployment & Runtime Architecture |
| Cakupan | Environments, Topology, Artifacts, Promotion, Configuration, Database Migration, Observability, Security, Rollback, DR |
| Bergantung pada | SSOT-GOV-06, SSOT-SEC-01, SSOT-SEC-02, DEPLOY-SEC-01 |
| Target Stack | PHP 8.1+, Apache/XAMPP, MySQL 8/MariaDB, Modular Monolith |
| Target Evolusi | Container-ready, Cloud-ready, Microservice-ready |

---

# 1. Executive Summary

SSOT-DEPLOY-01 menetapkan arsitektur deployment resmi untuk Platform Kernel dan seluruh module bisnis.

Dokumen ini mendefinisikan:

- environment model;
- deployment topology;
- runtime components;
- artifact lifecycle;
- promotion model;
- configuration model;
- secrets handling;
- database migration architecture;
- scheduler and worker deployment;
- observability integration;
- security controls;
- rollback and roll-forward;
- backup and disaster recovery;
- health checks;
- release evidence;
- UAT;
- Definition of Done.

Tujuan akhirnya adalah memastikan deployment:

- repeatable;
- auditable;
- secure;
- reversible;
- environment-consistent;
- artifact-driven;
- observable;
- resilient;
- scalable;
- ready for future automation.

---

# 2. Deployment Vision

Deployment architecture harus:

```text
Build Once
Promote the Same Artifact
Separate Configuration from Code
Validate Before Activate
Observe Every Deployment
Rollback Safely
Recover Predictably
Minimize Manual Production Changes
```

---

# 3. Objectives

Deployment architecture harus:

- mengurangi configuration drift;
- mencegah untracked production changes;
- menjaga artifact integrity;
- mengontrol database migrations;
- mendukung staged rollout;
- menyediakan rollback;
- memisahkan environment;
- mendukung audit;
- menyediakan health validation;
- mendukung future containerization.

---

# 4. Core Principles

```text
Immutable Artifacts
Environment Parity
Configuration Externalization
Least Privilege
Automated Validation
Controlled Promotion
Observable Runtime
Safe Migration
Recoverability
Separation of Duties
```

---

# 5. Scope

Deployment architecture berlaku untuk:

```text
Platform Kernel
Business Modules
Shared Libraries
Public Web Application
Internal APIs
CLI Tools
Scheduled Jobs
Background Workers
Database Migrations
Static Assets
Configuration
Security Controls
```

---

# 6. Environment Model

Recommended:

```text
LOCAL
→ TEST
→ STAGING
→ PRE-PRODUCTION
→ PRODUCTION
```

Minimum implementation:

```text
LOCAL/TEST
→ STAGING
→ PRODUCTION
```

---

# 7. Local Environment

Purpose:

- development;
- debugging;
- developer testing;
- local migrations;
- feature validation.

Characteristics:

- isolated;
- synthetic data;
- debug enabled;
- no production secrets;
- no production data.

---

# 8. Test Environment

Purpose:

- automated tests;
- integration tests;
- security tests;
- contract tests;
- migration validation.

Characteristics:

- disposable where feasible;
- deterministic;
- seeded test data;
- CI-compatible.

---

# 9. Staging Environment

Purpose:

- production-like validation;
- UAT;
- deployment rehearsal;
- security scanning;
- migration rehearsal.

Characteristics:

- production-like topology;
- sanitized data only;
- production-like config structure;
- same artifact as production candidate.

---

# 10. Pre-Production Environment

Optional for high-risk systems.

Purpose:

- final readiness;
- performance testing;
- production configuration validation;
- disaster/rollback rehearsal.

---

# 11. Production Environment

Purpose:

- live operational workload.

Characteristics:

- restricted access;
- hardened runtime;
- debug disabled;
- monitored;
- backed up;
- auditable;
- approved changes only.

---

# 12. Environment Isolation

Each environment must have separate:

- database;
- credentials;
- secrets;
- storage;
- logs;
- cache namespace;
- queue/scheduler state;
- external integration configuration.

---

# 13. Environment Naming

Recommended:

```text
local
test
staging
preprod
production
```

---

# 14. Deployment Topology — Baseline

```text
Client
  │
  ▼
Apache HTTP Server
  │
  ▼
PHP Application
  │
  ├── Platform Kernel
  ├── Business Modules
  ├── Scheduler/CLI
  └── Background Workers
  │
  ▼
MySQL/MariaDB
```

---

# 15. Deployment Topology — Production Recommended

```text
Load Balancer / Reverse Proxy
        │
        ▼
Web Tier
├── Application Node 1
├── Application Node 2
└── Application Node N
        │
        ├── Shared Cache
        ├── Queue/Worker
        ├── Secure File Storage
        ├── Observability Stack
        └── Database Tier
```

---

# 16. XAMPP Baseline

For current implementation:

```text
D:\xampp\apache
D:\xampp\php
D:\xampp\mysql
D:\xampp\htdocs\platform
```

Document root must point to:

```text
D:\xampp\htdocs\platform\public
```

---

# 17. Runtime Components

```text
Apache
PHP Runtime
Application Code
Composer Dependencies
Database
Scheduler
Workers
Storage
Logs
Monitoring
Backup
```

---

# 18. Application Directory Structure

```text
platform/
├── app/
├── bin/
├── config/
├── database/
├── public/
├── resources/
├── storage/
├── tests/
├── tools/
├── vendor/
├── composer.json
├── composer.lock
└── .env
```

---

# 19. Public Root Rule

Only public assets and front controller may be exposed.

The following must not be public:

- `.env`;
- source code;
- logs;
- SQL files;
- backups;
- restricted files;
- internal documentation;
- private keys.

---

# 20. Artifact Model

A release artifact should contain:

```text
Application Code
Vendor Dependencies
Compiled/Prepared Assets
Migration Metadata
Version Metadata
Release Manifest
Checksums
```

---

# 21. Artifact Exclusions

Do not include:

- `.git`;
- local `.env`;
- development logs;
- database dumps;
- local caches;
- test secrets;
- temporary files;
- editor metadata.

---

# 22. Immutable Artifact

Once built and approved, artifact must not be modified.

---

# 23. Build Once, Promote Many

The same artifact must move across environments:

```text
TEST
→ STAGING
→ PRE-PRODUCTION
→ PRODUCTION
```

---

# 24. Artifact Identity

Minimum metadata:

```text
artifact_id
version
commit_sha
build_id
sha256
signature
sbom_reference
built_at
builder
```

---

# 25. Release Manifest

Example:

```yaml
version: 1.8.0
commit_sha: abcdef123456
build_id: build-2026-07-05-01
artifact_sha256: ...
sbom_reference: sbom-1.8.0.json
migrations:
  - 202607050001_create_security_tables.sql
  - 202607050002_seed_permissions.sql
```

---

# 26. Artifact Integrity

Validate:

- checksum;
- signature;
- provenance;
- SBOM;
- expected file list.

---

# 27. Artifact Storage

Artifact repository should support:

- versioning;
- immutability;
- retention;
- access control;
- download audit;
- integrity validation.

---

# 28. Source-to-Artifact Flow

```text
Source Commit
→ CI Validation
→ Dependency Install
→ Test
→ Security Scan
→ Package
→ Sign
→ Store Artifact
```

---

# 29. Promotion Flow

```text
Artifact Approved
→ Deploy Test
→ Validate
→ Promote Staging
→ UAT
→ Promote Pre-Prod
→ Final Gate
→ Promote Production
```

---

# 30. Promotion Rules

Promotion requires:

- source environment success;
- same artifact hash;
- valid approvals;
- no blocking findings;
- valid configuration;
- target readiness;
- valid exception status.

---

# 31. Configuration Architecture

Configuration must be external to immutable artifact where environment-specific.

---

# 32. Configuration Layers

Recommended precedence:

```text
Code Defaults
→ Environment Configuration
→ Secret References
→ Tenant Configuration
→ Runtime Overrides
```

---

# 33. Configuration Rules

Configuration must:

- be schema-validated;
- have explicit defaults;
- fail fast for critical missing values;
- be versioned where practical;
- avoid secrets in source control.

---

# 34. Environment Configuration

Examples:

```text
APP_ENV
APP_URL
DB_HOST
DB_DATABASE
CACHE_DRIVER
QUEUE_DRIVER
LOG_LEVEL
SECURITY_POLICY_MODE
```

---

# 35. Secret Management

Secrets must:

- not be committed;
- not be embedded in artifact;
- be injected securely;
- be rotated;
- be audited;
- use least privilege.

---

# 36. Configuration Drift

Detect differences between:

- expected config;
- actual runtime config;
- approved release config;
- schema state;
- scheduler state.

---

# 37. Drift Response

```text
Detect
→ Assess
→ Reconcile
→ Record
→ Verify
```

---

# 38. Database Architecture

Baseline:

```text
Application Runtime Account
Migration Account
Read-Only Reporting Account
Backup Account
Administrative Account
```

---

# 39. Database Account Separation

Runtime account must not have unrestricted DDL privileges.

Migration account should be used only during deployment.

---

# 40. Migration Architecture

Migrations must be:

- versioned;
- ordered;
- idempotency-aware;
- tested;
- auditable;
- compatible with rollout strategy.

---

# 41. Migration Phases

```text
Pre-Deployment Migration
Application Deployment
Post-Deployment Migration
Data Backfill
Cleanup/Contract
```

---

# 42. Expand-Migrate-Contract

Recommended for breaking changes:

```text
Expand Schema
→ Deploy Compatible Code
→ Migrate Data
→ Verify
→ Remove Legacy Structure Later
```

---

# 43. Migration Locking

Migration runner should prevent concurrent migration execution.

---

# 44. Migration Ledger

Track:

```text
migration_id
version
checksum
applied_at
applied_by
duration
status
```

---

# 45. Migration Validation

Before production:

- syntax validation;
- dry run where possible;
- staging rehearsal;
- row count estimate;
- lock impact;
- rollback/restore plan;
- compatibility review.

---

# 46. Destructive Migration

Requires:

- explicit approval;
- backup;
- tested restore;
- data retention review;
- rollback or forward-fix plan.

---

# 47. Data Backfill

Backfill should be:

- restartable;
- idempotent;
- observable;
- bounded;
- tenant-aware;
- resumable.

---

# 48. Scheduler Architecture

Schedulers may run:

- session cleanup;
- key/secret rotation checks;
- vulnerability SLA checks;
- artifact verification;
- drift detection;
- notification dispatch.

---

# 49. Scheduler Deployment

Scheduler tasks must use:

- absolute paths;
- dedicated identity;
- logs;
- lock;
- timeout;
- exit codes.

---

# 50. Background Worker Architecture

Workers should be:

- idempotent;
- retry-bounded;
- observable;
- tenant-aware;
- horizontally scalable where possible.

---

# 51. Worker Deployment

Workers should be restarted or reloaded after compatible deployment if code changed.

---

# 52. File Storage Architecture

Restricted files must be stored outside public root.

---

# 53. Storage Types

```text
Public Static Assets
Private Application Files
Quarantine Files
Evidence Files
Backups
Artifacts
```

---

# 54. Storage Controls

- access control;
- encryption where required;
- checksum;
- retention;
- audit;
- tenant isolation.

---

# 55. Static Asset Deployment

Static assets should be:

- versioned;
- cache-busted;
- immutable;
- compatible with application version.

---

# 56. Web Server Architecture

Apache should provide:

- virtual host isolation;
- secure headers;
- directory protection;
- request limits;
- TLS termination or secure reverse proxy integration.

---

# 57. PHP Runtime Architecture

Production:

```text
display_errors = Off
log_errors = On
expose_php = Off
session.use_strict_mode = 1
```

---

# 58. Runtime Hardening

Recommended:

- disable directory listing;
- deny sensitive file extensions;
- restrict upload size;
- secure session cookies;
- disable unsafe PHP features where feasible;
- restrict filesystem permissions.

---

# 59. TLS Architecture

Production traffic must use HTTPS.

---

# 60. Reverse Proxy / Load Balancer

Future-ready production architecture may use:

- TLS termination;
- request routing;
- health checks;
- rate limiting;
- load balancing;
- maintenance routing.

---

# 61. Health Check Architecture

Minimum endpoints:

```text
/live
/ready
/version
```

---

# 62. Liveness

Checks that process/application is running.

---

# 63. Readiness

Checks critical dependencies:

- database;
- storage;
- configuration;
- migration state;
- queue/worker dependencies where required.

---

# 64. Version Endpoint

Should expose non-sensitive:

```text
version
build_id
commit_sha
environment
```

---

# 65. Health Check Security

Health endpoints must not expose:

- secrets;
- internal stack traces;
- full configuration;
- sensitive dependency details.

---

# 66. Observability Architecture

Deployment must integrate:

- logs;
- metrics;
- traces where applicable;
- health checks;
- deployment events;
- release annotations.

---

# 67. Deployment Event

Every deployment should emit:

```text
DEPLOYMENT_STARTED
DEPLOYMENT_SUCCEEDED
DEPLOYMENT_FAILED
ROLLBACK_STARTED
ROLLBACK_SUCCEEDED
```

---

# 68. Deployment Metrics

```text
deployment_total
deployment_success_total
deployment_failure_total
deployment_duration_seconds
rollback_total
migration_duration_seconds
health_check_failure_total
```

---

# 69. Release Annotation

Observability dashboards should mark deployment time and version.

---

# 70. Monitoring After Deployment

Monitor:

- error rate;
- latency;
- resource use;
- authentication failures;
- authorization denials;
- tenant isolation denials;
- queue failures;
- scheduler failures;
- database errors.

---

# 71. Security Architecture

Deployment controls must include:

- least privilege;
- signed artifacts;
- secret separation;
- hardened runtime;
- restricted production access;
- audit trail;
- secure file handling;
- change authorization.

---

# 72. Production Access

Production access must be:

- approved;
- role-based;
- time-bound for privileged access;
- logged;
- reviewed.

---

# 73. Deployment Identity

Use a dedicated deployment identity separate from developer accounts.

---

# 74. Manual Production Changes

Manual changes must be exceptional.

They require:

- reason;
- approval;
- operator;
- commands/actions;
- reconciliation;
- evidence.

---

# 75. Deployment Strategies

```text
IN_PLACE
BLUE_GREEN
CANARY
ROLLING
MAINTENANCE_WINDOW
```

---

# 76. In-Place Deployment

Suitable for current XAMPP baseline.

Risks:

- partial state;
- downtime;
- difficult rollback if files overwritten.

Mitigation:

- release directories;
- atomic switch;
- backup;
- maintenance mode.

---

# 77. Release Directory Pattern

Recommended:

```text
D:\releases\
├── platform-1.7.0\
├── platform-1.8.0\
└── current -> platform-1.8.0
```

On Windows, use controlled directory switch or deployment script.

---

# 78. Blue-Green Deployment

Two production environments:

```text
BLUE
GREEN
```

Traffic switches after validation.

---

# 79. Canary Deployment

Small percentage of traffic/users receives new release first.

---

# 80. Rolling Deployment

Application nodes updated gradually.

---

# 81. Maintenance Mode

Use when:

- incompatible migration;
- unavoidable downtime;
- high-risk change;
- data consistency requires exclusive access.

---

# 82. Rollback Architecture

Rollback must address:

```text
Application Artifact
Configuration
Database Schema
Data Changes
Workers
Scheduler
Static Assets
```

---

# 83. Rollback Preconditions

- previous artifact retained;
- config snapshot available;
- schema compatibility known;
- rollback decision authority defined;
- health tests available.

---

# 84. Rollback Triggers

Examples:

- application unavailable;
- authentication failure;
- authorization regression;
- tenant isolation failure;
- migration failure;
- critical error spike;
- severe performance degradation;
- data integrity issue.

---

# 85. Rollback vs Roll-Forward

Use rollback when safe.

Use roll-forward when:

- schema cannot safely reverse;
- prior version is vulnerable;
- data transformation is irreversible;
- forward fix is lower risk.

---

# 86. Rollback Procedure Model

```text
Detect
→ Decide
→ Stabilize
→ Restore Artifact/Config
→ Handle Database
→ Restart Services
→ Verify
→ Communicate
→ Review
```

---

# 87. Backup Architecture

Backup categories:

```text
Database Backup
Configuration Backup
Artifact Backup
Evidence Backup
Private File Backup
```

---

# 88. Backup Principles

- encrypted where required;
- access-controlled;
- monitored;
- retained;
- tested;
- separate from primary system.

---

# 89. Backup Schedule

Example:

```text
Database full: daily
Database incremental/binlog: frequent where supported
Configuration snapshot: every approved change
Artifacts: every release
Private files: daily/incremental
```

---

# 90. Restore Testing

Backups are not trusted until restore is tested.

---

# 91. Disaster Recovery

DR must define:

```text
RTO
RPO
Recovery Site
Recovery Procedure
Communication
Testing
```

---

# 92. Recovery Time Objective

Maximum acceptable service restoration time.

---

# 93. Recovery Point Objective

Maximum acceptable data loss interval.

---

# 94. DR Levels

```text
LEVEL 1 — Restore on Same Host
LEVEL 2 — Restore on Replacement Host
LEVEL 3 — Alternate Site
LEVEL 4 — Automated Failover
```

---

# 95. DR Testing

Recommended:

- tabletop;
- backup restore;
- partial failover;
- full recovery exercise.

---

# 96. Business Continuity

Deployment architecture should support critical service continuity.

---

# 97. Capacity Architecture

Track:

- CPU;
- memory;
- disk;
- database connections;
- storage growth;
- queue depth;
- request volume.

---

# 98. Scaling Model

Baseline:

```text
Vertical Scaling
```

Future:

```text
Horizontal Web Nodes
Separate Workers
Shared Cache
Database Replication
```

---

# 99. Session Architecture

For multi-node deployments, sessions should use shared server-side storage.

---

# 100. Cache Architecture

Cache keys must include tenant scope where applicable.

---

# 101. Queue Architecture

Queue deployment must define:

- broker/storage;
- worker count;
- retry;
- dead-letter handling;
- visibility;
- tenant context.

---

# 102. External Integration Architecture

Each environment must use appropriate external endpoints.

---

# 103. Integration Safety

Non-production must not accidentally call production services unless explicitly approved.

---

# 104. DNS and Endpoint Management

Endpoints should be environment-specific and documented.

---

# 105. Deployment Access Matrix

| Role | Test | Staging | Production |
|---|---|---|---|
| Developer | Deploy/Read | Limited | No direct |
| QA | Read/Test | Test | Read-only evidence |
| Release Engineer | Deploy | Deploy | Deploy approved release |
| Operations | Operate | Operate | Operate |
| Security | Review | Review | Review/Audit |

---

# 106. Separation of Duties

Critical production deployment should separate:

- code author;
- approver;
- deployer;
- verifier.

---

# 107. Deployment Evidence

Minimum:

```text
release_id
artifact_hash
approvals
environment
deployment_start
deployment_end
operator
migration_result
health_result
smoke_test_result
rollback_status
```

---

# 108. Deployment Audit Trail

Audit:

- artifact selected;
- config changed;
- deployment started;
- migration executed;
- health check result;
- deployment completed/failed;
- rollback executed.

---

# 109. Release Notes

Must include:

- version;
- included changes;
- migrations;
- known issues;
- rollback notes;
- support contact.

---

# 110. Deployment Runbook

Every production deployment should use a runbook.

---

# 111. Runbook Sections

```text
Purpose
Scope
Preconditions
Backup
Artifact Verification
Deployment Steps
Migration Steps
Validation
Rollback
Communication
Evidence
```

---

# 112. Pre-Deployment Checklist

- [ ] Release approved.
- [ ] Artifact verified.
- [ ] SBOM available.
- [ ] Configuration validated.
- [ ] Database backup verified.
- [ ] Migration tested.
- [ ] Rollback ready.
- [ ] Monitoring ready.
- [ ] Maintenance window approved.
- [ ] On-call available.

---

# 113. Deployment Checklist

- [ ] Maintenance mode applied if needed.
- [ ] Artifact deployed.
- [ ] Config injected.
- [ ] Migration completed.
- [ ] Cache handled.
- [ ] Scheduler/workers handled.
- [ ] Health checks passed.
- [ ] Security smoke tests passed.
- [ ] Release annotation created.
- [ ] User access restored.

---

# 114. Post-Deployment Checklist

- [ ] Error rate normal.
- [ ] Authentication works.
- [ ] Authorization works.
- [ ] Tenant isolation works.
- [ ] Jobs running.
- [ ] Logs available.
- [ ] Backups remain active.
- [ ] Release evidence complete.
- [ ] Stakeholders informed.
- [ ] Hypercare active if required.

---

# 115. Reference Architecture — XAMPP Local/Test

```text
Windows Host
├── Apache
├── PHP
├── MySQL/MariaDB
├── Platform Application
├── Windows Task Scheduler
└── Local Storage
```

---

# 116. Reference Architecture — Staging

```text
Staging Host
├── Hardened Apache/PHP
├── Staging Database
├── Staging Storage
├── Scheduler/Worker
├── Monitoring
└── Backup
```

---

# 117. Reference Architecture — Production Baseline

```text
Production Host
├── Reverse Proxy/Apache
├── PHP Application
├── Production Database
├── Private Storage
├── Scheduler/Worker
├── Monitoring/Alerting
├── Backup
└── Release/Artifact Storage
```

---

# 118. Reference Architecture — Future Scalable

```text
Load Balancer
├── App Node 1
├── App Node 2
├── App Node N
├── Shared Session/Cache
├── Worker Pool
├── Queue
├── Database Primary/Replica
├── Object/File Storage
├── Observability
└── Backup/DR
```

---

# 119. Deployment Error Codes

```text
DEPLOY_ARTIFACT_NOT_FOUND
DEPLOY_ARTIFACT_HASH_INVALID
DEPLOY_SIGNATURE_INVALID
DEPLOY_CONFIG_INVALID
DEPLOY_ENVIRONMENT_NOT_READY
DEPLOY_MIGRATION_FAILED
DEPLOY_HEALTH_CHECK_FAILED
DEPLOY_ROLLBACK_REQUIRED
DEPLOY_ROLLBACK_FAILED
DEPLOY_DRIFT_DETECTED
```

---

# 120. Deployment Event Codes

```text
DEPLOYMENT_REQUESTED
DEPLOYMENT_APPROVED
DEPLOYMENT_STARTED
DEPLOYMENT_ARTIFACT_VERIFIED
DEPLOYMENT_MIGRATION_STARTED
DEPLOYMENT_MIGRATION_COMPLETED
DEPLOYMENT_HEALTH_CHECK_PASSED
DEPLOYMENT_SUCCEEDED
DEPLOYMENT_FAILED
DEPLOYMENT_ROLLBACK_STARTED
DEPLOYMENT_ROLLBACK_SUCCEEDED
DEPLOYMENT_DRIFT_DETECTED
```

---

# 121. Deployment Metrics

```text
deployment_frequency
deployment_success_rate
deployment_failure_rate
deployment_duration
rollback_rate
change_failure_rate
mean_time_to_recover
migration_failure_rate
health_check_failure_rate
config_drift_total
```

---

# 122. Initial KPIs

```text
Unsigned production artifact = 0
Production deployment without approval = 0
Critical deployment without rollback plan = 0
Deployment evidence completeness = 100%
Production health check pass after deployment = 100%
Restore test completion per schedule = 100%
```

---

# 123. UAT — Environment Architecture

- [ ] Environment list defined.
- [ ] Environment isolation implemented.
- [ ] Separate credentials used.
- [ ] Production data prohibited in local/test.
- [ ] Environment parity documented.
- [ ] Endpoint separation verified.

---

# 124. UAT — Artifact & Promotion

- [ ] Artifact immutable.
- [ ] Version metadata available.
- [ ] Checksum valid.
- [ ] Signature valid.
- [ ] SBOM linked.
- [ ] Same artifact promoted.
- [ ] Promotion approvals work.
- [ ] Expired exception blocks promotion.

---

# 125. UAT — Configuration & Secrets

- [ ] Config externalized.
- [ ] Config schema validated.
- [ ] Critical missing config fails fast.
- [ ] Secrets not committed.
- [ ] Secrets separated by environment.
- [ ] Drift detection works.
- [ ] Config changes are audited.

---

# 126. UAT — Database & Migration

- [ ] Runtime/migration accounts separated.
- [ ] Migration ledger works.
- [ ] Migration lock works.
- [ ] Staging rehearsal completed.
- [ ] Destructive migration approval required.
- [ ] Backfill restartable.
- [ ] Backup verified.
- [ ] Rollback/forward-fix documented.

---

# 127. UAT — Runtime & Operations

- [ ] Document root points to public.
- [ ] Restricted files inaccessible.
- [ ] Scheduler runs.
- [ ] Workers restart safely.
- [ ] Health endpoints work.
- [ ] Version endpoint works.
- [ ] Monitoring receives deployment events.
- [ ] Logs are available.

---

# 128. UAT — Security

- [ ] Production access restricted.
- [ ] Deployment identity dedicated.
- [ ] TLS enabled.
- [ ] Secure headers active.
- [ ] Debug disabled in production.
- [ ] Secrets absent from logs.
- [ ] Manual changes audited.
- [ ] Tenant isolation smoke test passes.

---

# 129. UAT — Rollback & Recovery

- [ ] Previous artifact retained.
- [ ] Config snapshot available.
- [ ] Rollback trigger defined.
- [ ] Rollback tested.
- [ ] Restore test completed.
- [ ] RTO/RPO defined.
- [ ] DR procedure documented.
- [ ] Recovery evidence retained.

---

# 130. UAT — Evidence & Governance

- [ ] Deployment evidence complete.
- [ ] Release notes published.
- [ ] Approvals traceable.
- [ ] Migration results traceable.
- [ ] Health/smoke results traceable.
- [ ] Audit trail complete.
- [ ] Metrics available.
- [ ] Hypercare defined for high-risk releases.

---

# 131. Definition of Done — SSOT-DEPLOY-01

SSOT-DEPLOY-01 dianggap selesai bila:

- [ ] deployment vision tersedia;
- [ ] objectives/principles tersedia;
- [ ] environment model tersedia;
- [ ] topology baseline tersedia;
- [ ] runtime components tersedia;
- [ ] artifact model tersedia;
- [ ] immutable promotion model tersedia;
- [ ] release manifest tersedia;
- [ ] configuration architecture tersedia;
- [ ] secrets handling tersedia;
- [ ] drift management tersedia;
- [ ] database account separation tersedia;
- [ ] migration architecture tersedia;
- [ ] expand-migrate-contract tersedia;
- [ ] scheduler/worker architecture tersedia;
- [ ] storage architecture tersedia;
- [ ] web/PHP/TLS architecture tersedia;
- [ ] health checks tersedia;
- [ ] observability integration tersedia;
- [ ] security architecture tersedia;
- [ ] deployment strategies tersedia;
- [ ] rollback/roll-forward tersedia;
- [ ] backup/restore tersedia;
- [ ] disaster recovery tersedia;
- [ ] capacity/scaling tersedia;
- [ ] access matrix/SoD tersedia;
- [ ] evidence/audit trail tersedia;
- [ ] runbook/checklists tersedia;
- [ ] reference architecture tersedia;
- [ ] event/error codes tersedia;
- [ ] metrics/KPI tersedia;
- [ ] UAT tersedia.

---

# 132. Implementation Roadmap

## Phase 1 — Baseline Deployment

- establish environment naming;
- set document root;
- separate configuration;
- define release artifact;
- create deployment runbook;
- create migration ledger.

## Phase 2 — Controlled Promotion

- add checksum/signature;
- add release manifest;
- implement staging promotion;
- add approvals;
- add deployment evidence.

## Phase 3 — Operational Readiness

- health endpoints;
- deployment events;
- monitoring annotations;
- scheduler/worker controls;
- backup and restore testing.

## Phase 4 — Resilience

- release directories;
- safer atomic switch;
- automated rollback checks;
- DR procedures;
- capacity monitoring.

## Phase 5 — Advanced Deployment

- CI/CD automation;
- containerization;
- blue-green/canary;
- horizontal scaling;
- automated policy gates.

---

# 133. Approval Gate

Dokumen dapat menjadi Approved setelah:

- Platform Governance review;
- Architecture Review Board review;
- Security Governance review;
- Release Engineering review;
- Operations review;
- Database review;
- Observability review;
- Backup/DR review;
- access and segregation review;
- UAT and rollback review.

---

# 134. Closing Statement

Deployment architecture harus memastikan setiap release:

- dibangun sekali;
- dipromosikan sebagai artifact yang sama;
- menggunakan configuration yang terkendali;
- memiliki migration yang aman;
- memiliki observability;
- memiliki security controls;
- memiliki rollback;
- memiliki backup;
- dapat dipulihkan;
- dapat diaudit.

Deployment tidak boleh bergantung pada copy manual yang tidak dapat diverifikasi.

Deployment harus menjadi proses terkontrol, repeatable, evidence-driven, dan siap berkembang dari XAMPP baseline menuju runtime enterprise yang lebih scalable.
