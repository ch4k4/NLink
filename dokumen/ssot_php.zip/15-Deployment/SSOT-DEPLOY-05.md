# SSOT-DEPLOY-05 — Infrastructure & Runtime Hardening

---

## Status Dokumen

| Item | Nilai |
|---|---|
| Kode | SSOT-DEPLOY-05 |
| Judul | Infrastructure & Runtime Hardening |
| Versi | 1.0 |
| Status | Draft for Review |
| Domain | Platform Kernel |
| Kategori | Infrastructure Security & Runtime Hardening |
| Cakupan | Host OS, Apache, PHP, MySQL/MariaDB, Filesystem, Network, Identities, Secrets, Patching, Logging, Monitoring, Vulnerability Management |
| Bergantung pada | SSOT-DEPLOY-01, SSOT-DEPLOY-02, SSOT-DEPLOY-03, SSOT-DEPLOY-04, SSOT-SEC-01, SSOT-SEC-02 |
| Target Stack | Windows 10/11, XAMPP, Apache, PHP 8.1+, MySQL 8/MariaDB |
| Target Evolusi | Hardened Linux/Windows Server, Reverse Proxy, Container-ready, Cloud-ready |

---

# 1. Executive Summary

SSOT-DEPLOY-05 menetapkan baseline hardening resmi untuk infrastructure dan runtime Platform Kernel.

Dokumen ini mengatur:

- host operating system hardening;
- Windows/XAMPP baseline;
- Apache hardening;
- PHP runtime hardening;
- MySQL/MariaDB hardening;
- filesystem permissions;
- network exposure;
- TLS;
- service identities;
- privileged access;
- secrets;
- patching;
- vulnerability management;
- malware protection;
- logging;
- monitoring;
- backup protection;
- runtime verification;
- compliance evidence;
- UAT;
- Definition of Done.

Tujuan akhirnya adalah memastikan runtime:

- hanya mengekspos service yang dibutuhkan;
- menggunakan least privilege;
- tidak membocorkan informasi;
- menggunakan konfigurasi yang aman;
- dapat dipantau;
- dapat dipatch;
- dapat diaudit;
- dapat direcovery;
- memiliki measurable hardening posture.

---

# 2. Objectives

Framework harus:

- mengurangi attack surface;
- membatasi privilege;
- mencegah exposure file sensitif;
- menjaga patch hygiene;
- mengurangi configuration drift;
- memperkuat service isolation;
- meningkatkan detection;
- mendukung incident response;
- menjaga runtime consistency;
- menyediakan evidence.

---

# 3. Core Principles

```text
Secure by Default
Minimal Attack Surface
Least Privilege
Deny by Default
No Shared Administrative Identity
Patch Before Exposure
Configuration Must Be Measurable
Sensitive Files Must Not Be Public
Every Critical Service Must Be Observable
Hardening Must Be Continuously Verified
```

---

# 4. Scope

Framework berlaku untuk:

```text
Windows Host
Apache
PHP
MySQL/MariaDB
Filesystem
Network
TLS
Service Accounts
Task Scheduler
Workers
Backup Agents
Monitoring Agents
Security Tools
Deployment Runtime
```

---

# 5. Hardening Layers

```text
Physical/Hosting
→ Operating System
→ Network
→ Web Server
→ Runtime
→ Database
→ Filesystem
→ Identity
→ Application Boundary
→ Monitoring
```

---

# 6. Environment-Based Hardening

## Local

- developer convenience allowed within safe boundary;
- no production secrets;
- no public internet exposure;
- debug may be enabled;
- synthetic data only.

## Test

- automated testing;
- isolated network;
- temporary credentials;
- no production integrations.

## Staging

- production-like hardening;
- restricted access;
- debug off by default;
- production-like monitoring.

## Production

- full hardening baseline;
- approved access only;
- no direct developer access;
- continuous monitoring;
- patch and vulnerability governance.

---

# 7. Host Operating System Baseline

Host must:

- run supported OS version;
- receive security updates;
- use endpoint protection;
- restrict local admin rights;
- disable unnecessary services;
- use time synchronization;
- use host firewall;
- maintain secure audit logs.

---

# 8. Supported Operating System

Production must not run on unsupported OS.

---

# 9. Host Inventory

Minimum:

```text
host_id
hostname
environment
owner
os_version
patch_level
ip_addresses
roles
criticality
last_hardening_review
```

---

# 10. Host Ownership

Every host must have:

- business/system owner;
- technical owner;
- operations owner;
- security reviewer.

---

# 11. Windows Account Hardening

- separate standard and admin accounts;
- no shared administrator password;
- strong authentication;
- lockout policy;
- inactivity timeout;
- remove dormant accounts;
- audit privileged logon.

---

# 12. Local Administrator

Use only when required.

Routine application operations must not require local administrator.

---

# 13. Guest Account

Disable guest accounts.

---

# 14. Default Accounts

Rename, disable, or protect default privileged accounts where applicable.

---

# 15. Password Policy

Recommended:

- minimum length;
- blocked common passwords;
- lockout/throttling;
- no default passwords;
- no password reuse for service accounts where applicable.

---

# 16. Multi-Factor Authentication

MFA is recommended for:

- remote administration;
- privileged access;
- production control plane;
- backup console;
- secret management.

---

# 17. Screen Lock

Privileged workstations and servers should auto-lock.

---

# 18. Remote Access

Remote access must use:

- approved secure channel;
- MFA;
- restricted source;
- logging;
- time-bound access where feasible.

---

# 19. RDP Hardening

If RDP is used:

- restrict firewall source;
- require Network Level Authentication;
- require MFA via approved gateway where available;
- log connections;
- disable unnecessary redirection;
- avoid public exposure.

---

# 20. Host Firewall

Allow only required ports.

Example:

```text
80/443 from approved network or load balancer
3306 only from application/administration sources
RDP only from approved administration source
```

---

# 21. Unnecessary Services

Disable services not required by the platform.

---

# 22. Time Synchronization

All hosts must use reliable time synchronization.

Accurate time is required for:

- logs;
- authentication;
- certificates;
- audit;
- recovery;
- correlation.

---

# 23. Endpoint Protection

Use supported anti-malware/EDR where available.

---

# 24. Malware Exclusions

Do not create broad exclusions.

Any exclusion must be:

- justified;
- narrow;
- approved;
- reviewed.

---

# 25. Disk Encryption

Production host storage containing restricted data should use full-disk or volume encryption.

---

# 26. Removable Media

Restrict removable media on production hosts.

---

# 27. Local Data Storage

Do not store unrestricted production exports on administrator desktops or ungoverned folders.

---

# 28. System Logs

Windows event logs should include:

- authentication;
- privilege use;
- service changes;
- policy changes;
- task scheduler events;
- security events.

---

# 29. Audit Policy

Enable appropriate audit categories.

---

# 30. Log Retention

Host log retention must align with observability and compliance policy.

---

# 31. Apache Hardening

Apache must:

- expose only required virtual hosts;
- disable directory listing;
- hide version information;
- restrict sensitive paths;
- apply request limits;
- use TLS in production;
- log access and errors.

---

# 32. Apache Version

Use supported Apache release.

---

# 33. Apache Modules

Enable only required modules.

Review:

```text
rewrite
headers
ssl
proxy
proxy_http
remoteip
```

Disable unused modules.

---

# 34. Server Information Disclosure

Recommended:

```apache
ServerTokens Prod
ServerSignature Off
```

---

# 35. Directory Listing

Disable:

```apache
Options -Indexes
```

---

# 36. Trace Method

Disable:

```apache
TraceEnable Off
```

---

# 37. Public Directory

Document root must point to:

```text
D:\xampp\htdocs\platform\public
```

---

# 38. Sensitive Directory Protection

Example:

```apache
<Directory "D:/xampp/htdocs/platform/storage">
    Require all denied
    Options -Indexes
</Directory>
```

---

# 39. Sensitive File Protection

Example:

```apache
<FilesMatch "\.(env|ini|log|sql|bak|md|key|pem)$">
    Require all denied
</FilesMatch>
```

---

# 40. Virtual Host Isolation

Each application should have dedicated virtual host configuration.

---

# 41. Default Virtual Host

Remove or restrict default/example virtual hosts.

---

# 42. Request Size Limits

Configure limits for:

- request body;
- file upload;
- headers;
- timeouts.

---

# 43. HTTP Methods

Allow only methods required by the application.

---

# 44. Security Headers

Recommended baseline:

```text
Content-Security-Policy
X-Content-Type-Options
Referrer-Policy
Permissions-Policy
Strict-Transport-Security
```

---

# 45. Clickjacking Protection

Use CSP `frame-ancestors` or approved equivalent.

---

# 46. MIME Sniffing

Use:

```text
X-Content-Type-Options: nosniff
```

---

# 47. Referrer Policy

Use a restrictive policy appropriate to the application.

---

# 48. HSTS

Production HTTPS should use HSTS after validation.

---

# 49. TLS Baseline

Production must:

- use valid certificate;
- disable obsolete protocols;
- use approved cipher configuration;
- automate/monitor certificate expiry;
- protect private keys.

---

# 50. Certificate Inventory

Minimum:

```text
certificate_id
domain
issuer
expires_at
owner
renewal_method
private_key_location
status
```

---

# 51. Certificate Expiry

Alert before expiry.

---

# 52. Private Key Protection

Private keys must:

- not be stored in public root;
- have restricted permissions;
- be backed up securely where required;
- be rotated on compromise.

---

# 53. Reverse Proxy

If used, trusted proxy configuration must be explicit.

---

# 54. Forwarded Headers

Only trust forwarded headers from approved proxies.

---

# 55. Access Logs

Access logs should capture:

- timestamp;
- client source;
- method;
- path;
- status;
- response size;
- user agent;
- request/correlation ID where integrated.

---

# 56. Error Logs

Error logs must not expose secrets.

---

# 57. PHP Runtime Hardening

Production baseline:

```ini
display_errors = Off
display_startup_errors = Off
log_errors = On
expose_php = Off
session.use_strict_mode = 1
session.cookie_httponly = 1
session.cookie_secure = 1
session.cookie_samesite = Lax
allow_url_include = Off
```

---

# 58. PHP Version

Use supported PHP version with security patches.

---

# 59. PHP Extensions

Enable only required extensions.

---

# 60. Dangerous Functions

Review and restrict dangerous functions where feasible and compatible.

Potential examples:

```text
exec
shell_exec
system
passthru
proc_open
popen
```

Do not disable blindly if required by approved operations.

---

# 61. File Inclusion

Disable remote file inclusion.

---

# 62. Error Display

Production must not display stack traces or raw errors.

---

# 63. Error Logging

Errors must be logged to protected location.

---

# 64. Upload Limits

Configure:

```ini
upload_max_filesize
post_max_size
max_file_uploads
```

to approved values.

---

# 65. Execution Limits

Configure:

```ini
max_execution_time
max_input_time
memory_limit
```

according to workload.

---

# 66. Session Hardening

Recommended:

```ini
session.use_strict_mode = 1
session.use_only_cookies = 1
session.cookie_httponly = 1
session.cookie_secure = 1
session.cookie_samesite = Lax
session.sid_length = appropriate secure value
```

---

# 67. Session Storage

For multi-node environments, use shared server-side session storage.

---

# 68. Temporary Directory

PHP temporary directories should be protected and not web-accessible.

---

# 69. Open Basedir

May be used where compatible to restrict filesystem scope.

---

# 70. PHP Configuration Ownership

Production `php.ini` changes require governed change.

---

# 71. MySQL/MariaDB Hardening

Database must:

- use dedicated service;
- restrict network access;
- disable anonymous users;
- remove test databases;
- use separate accounts;
- enforce least privilege;
- log critical events;
- back up securely.

---

# 72. Database Version

Use supported MySQL/MariaDB version.

---

# 73. Root Account

Application must not use database root.

---

# 74. Anonymous Users

Remove anonymous database accounts.

---

# 75. Test Database

Remove default test database in production.

---

# 76. Remote Root Login

Disable or strictly restrict remote root access.

---

# 77. Application Runtime Account

Grant only required DML privileges.

---

# 78. Migration Account

Use separate account for DDL and migrations.

---

# 79. Backup Account

Use dedicated backup account.

---

# 80. Reporting Account

Use read-only account for reporting where appropriate.

---

# 81. Database Network Exposure

Port 3306 must not be publicly exposed.

---

# 82. Bind Address

Bind database to required interface only.

---

# 83. TLS for Database

Use encrypted database connections where network path is not trusted or policy requires.

---

# 84. Password Storage

Database credentials must be referenced securely.

---

# 85. SQL Mode

Use strict SQL behavior appropriate to application.

---

# 86. Local Infile

Disable `local_infile` unless explicitly required and governed.

---

# 87. Secure File Privilege

Restrict file import/export paths.

---

# 88. Database Logging

Consider:

- error log;
- slow query log;
- audit plugin where available;
- connection failures.

---

# 89. Slow Query Log

Enable with controlled threshold in production where operationally appropriate.

---

# 90. Database Audit

Audit privileged and security-relevant actions where feasible.

---

# 91. Database Encryption

Use storage encryption and application-level encryption where required by data classification.

---

# 92. Database Backup Protection

Backups must be encrypted and access-controlled.

---

# 93. Database Configuration Changes

Must be versioned, approved, tested, and auditable.

---

# 94. Filesystem Hardening

Filesystem must enforce:

- least privilege;
- directory separation;
- public/private separation;
- restricted write access;
- controlled execution.

---

# 95. Directory Ownership

Recommended responsibility:

```text
Application Code: deployment identity writes, runtime reads
Storage: runtime writes only required subdirectories
Logs: runtime/agent writes, restricted read
Config: deployment/operations writes, runtime reads
Backups: backup service writes, restricted read
```

---

# 96. Public Root Permissions

Runtime should not need broad write access to public root.

---

# 97. Upload Directory

Upload directory must:

- be outside public root;
- disallow script execution;
- use generated filenames;
- be scanned;
- be tenant-scoped.

---

# 98. Quarantine Directory

Quarantine must be isolated and inaccessible to normal users.

---

# 99. Log Directory

Logs must be outside public root and protected from tampering.

---

# 100. Configuration Files

Configuration files must have restricted access.

---

# 101. Backup Directory

Backup directories must not be served by Apache.

---

# 102. Artifact Directory

Artifacts must be immutable or write-protected after approval.

---

# 103. File Extension Blocking

Block direct serving of sensitive extensions.

---

# 104. Script Execution

Do not allow execution in upload, backup, evidence, or quarantine directories.

---

# 105. NTFS Permissions

Use explicit NTFS ACLs for production folders.

---

# 106. Service Identities

Each service should use dedicated identity where feasible.

---

# 107. Apache Service Identity

Apache should not run as an unnecessary privileged user.

---

# 108. Database Service Identity

Database should run under dedicated service account.

---

# 109. Scheduler Identity

Scheduled tasks should use dedicated least-privilege identity.

---

# 110. Worker Identity

Workers should use dedicated identity with scoped access.

---

# 111. Backup Identity

Backup jobs should use dedicated identity.

---

# 112. Identity Rotation

Service credentials must be rotated according to policy.

---

# 113. Privileged Access

Privileged access must be:

- approved;
- time-bound where feasible;
- logged;
- reviewed;
- revoked when no longer needed.

---

# 114. Shared Accounts

Shared privileged accounts are prohibited unless unavoidable and strictly governed.

---

# 115. Secrets Management

Secrets include:

- database passwords;
- API keys;
- TLS private keys;
- signing keys;
- encryption keys;
- service tokens.

---

# 116. Secret Storage

Do not store secrets in:

- source code;
- public directories;
- logs;
- tickets;
- chat;
- unencrypted backup.

---

# 117. Secret Access

Access must be scoped and audited.

---

# 118. Secret Rotation

Rotate:

- periodically;
- on staff change;
- on suspected compromise;
- after emergency exposure.

---

# 119. Key Management

Keys must have:

- owner;
- purpose;
- version;
- rotation;
- revocation;
- recovery process.

---

# 120. Network Segmentation

Recommended zones:

```text
Public Edge
Application
Database
Management
Backup
Monitoring
```

---

# 121. Inbound Rules

Allow only required traffic.

---

# 122. Outbound Rules

Restrict outbound traffic where feasible.

---

# 123. Egress Control

High-risk environments should control outbound destinations.

---

# 124. DNS

Use approved DNS resolvers and monitor unexpected resolution changes.

---

# 125. Proxy Configuration

Proxy settings must be documented and secured.

---

# 126. External Integrations

Use allowlisted endpoints and TLS validation.

---

# 127. Default Deny

Firewall and network policies should default deny.

---

# 128. Patch Management

Patching lifecycle:

```text
Inventory
→ Assess
→ Prioritize
→ Test
→ Approve
→ Deploy
→ Verify
→ Record
```

---

# 129. Patch Sources

Use trusted vendor sources.

---

# 130. Patch Categories

```text
CRITICAL_SECURITY
HIGH_SECURITY
ROUTINE_SECURITY
FEATURE
DRIVER
FIRMWARE
```

---

# 131. Patch SLA

Recommended:

| Severity | Target |
|---|---:|
| Critical actively exploited | 24–72 hours |
| Critical | 7 days |
| High | 14–30 days |
| Medium | 60 days |
| Low | planned cycle |

---

# 132. Emergency Patch

Emergency patch may use expedited process with retrospective review.

---

# 133. Patch Testing

Test in non-production before production where feasible.

---

# 134. Patch Rollback

Maintain rollback/recovery plan for critical patches.

---

# 135. End-of-Life Software

EOL software must:

- be removed;
- be upgraded;
- or have approved time-bound exception.

---

# 136. Vulnerability Management

Infrastructure vulnerabilities should enter central vulnerability workflow.

---

# 137. Vulnerability Sources

- vendor advisories;
- OS scanner;
- dependency scanner;
- configuration scanner;
- penetration test;
- incident;
- external report.

---

# 138. Vulnerability Prioritization

Consider:

- severity;
- exploitability;
- exposure;
- asset criticality;
- compensating controls;
- active exploitation.

---

# 139. Configuration Vulnerability

Misconfiguration is treated as a vulnerability.

---

# 140. Vulnerability Remediation

Must have:

- owner;
- target date;
- evidence;
- verification;
- escalation.

---

# 141. Baseline Scanning

Regularly scan:

- OS;
- Apache;
- PHP;
- database;
- open ports;
- TLS;
- filesystem permissions;
- configuration drift.

---

# 142. Hardening Benchmark

Internal hardening baseline may map to recognized benchmarks, adapted to actual stack.

---

# 143. Benchmark Exception

Any deviation requires risk assessment and approval.

---

# 144. Logging Architecture

Infrastructure logs should feed centralized observability where possible.

---

# 145. Required Log Sources

```text
Windows Event Logs
Apache Access/Error
PHP Error Logs
Database Error/Slow Query
Task Scheduler
Backup Jobs
Security Tools
Deployment Events
```

---

# 146. Log Integrity

Critical logs should be protected from local tampering.

---

# 147. Log Time

All logs must use synchronized time.

---

# 148. Sensitive Log Data

Logs must not contain secrets or unrestricted sensitive data.

---

# 149. Log Rotation

Configure rotation, size, retention, and archive.

---

# 150. Monitoring

Monitor:

- CPU;
- memory;
- disk;
- network;
- process/service state;
- certificate expiry;
- patch status;
- backup status;
- open ports;
- database health;
- scheduler health.

---

# 151. Runtime Alerts

Critical alerts:

- Apache down;
- database down;
- disk full;
- certificate near expiry;
- backup failed;
- unauthorized port open;
- critical vulnerability detected;
- configuration drift;
- suspicious privileged login.

---

# 152. Health Checks

Use:

```text
/live
/ready
/version
```

---

# 153. Service Recovery

Define restart and recovery behavior for:

- Apache;
- database;
- scheduler;
- workers;
- monitoring agents.

---

# 154. Resource Limits

Configure reasonable limits for:

- PHP memory;
- execution time;
- upload size;
- database connections;
- log storage;
- worker concurrency.

---

# 155. Capacity Thresholds

Set alert thresholds for critical resource exhaustion.

---

# 156. Denial-of-Service Resilience

Use:

- request size limits;
- rate limiting;
- timeouts;
- connection limits;
- reverse proxy controls;
- resource monitoring.

---

# 157. Process Isolation

Separate web, worker, scheduler, and backup responsibilities where feasible.

---

# 158. Task Scheduler Hardening

Tasks must:

- use dedicated identity;
- use absolute paths;
- have controlled working directory;
- log result;
- use timeout;
- avoid embedding secrets;
- use least privilege.

---

# 159. Scheduled Task Inventory

Minimum:

```text
task_name
command
identity
schedule
owner
timeout
last_result
status
```

---

# 160. Worker Hardening

Workers must:

- validate tenant context;
- use bounded retries;
- avoid unsafe command execution;
- log failures;
- handle duplicate execution.

---

# 161. Backup Runtime Hardening

Backup services must:

- use dedicated identity;
- encrypt output;
- restrict storage;
- log access;
- validate backup integrity.

---

# 162. Monitoring Agent Hardening

Agents should have read-only/minimum required permissions.

---

# 163. Development Tools in Production

Remove or disable unnecessary development tools in production.

Examples:

- debug toolbar;
- test endpoints;
- sample apps;
- database admin UI;
- package manager UI.

---

# 164. phpMyAdmin

Do not expose phpMyAdmin publicly.

If used:

- restrict source;
- require strong authentication;
- use TLS;
- remove when not needed.

---

# 165. XAMPP Production Warning

XAMPP is primarily a development bundle.

If retained for production baseline:

- remove sample applications;
- restrict admin tools;
- change default credentials;
- harden all components;
- document residual risk;
- plan migration to supported production runtime.

---

# 166. Sample Applications

Remove:

- demos;
- examples;
- status pages exposing internals;
- default dashboards not needed.

---

# 167. Default Credentials

Change or remove all default credentials.

---

# 168. Environment Banner

Clearly mark non-production environments.

---

# 169. Production Banner

Do not expose unnecessary environment detail publicly.

---

# 170. Deployment Hardening

Deployment process must verify hardening state before activation.

---

# 171. Pre-Deployment Hardening Check

- OS patch level;
- Apache config;
- PHP config;
- DB accounts;
- filesystem ACL;
- firewall;
- certificate;
- monitoring;
- backup;
- secrets.

---

# 172. Post-Deployment Verification

- only required ports open;
- sensitive files inaccessible;
- debug disabled;
- secure cookies enabled;
- health checks pass;
- logs flowing;
- backup healthy;
- no critical drift.

---

# 173. Configuration Drift

Hardening configuration must be versioned and compared to runtime.

---

# 174. Drift Severity

```text
LOW
MEDIUM
HIGH
CRITICAL
```

---

# 175. Critical Drift Examples

- public database port;
- debug enabled;
- directory listing enabled;
- production secret in source;
- Apache running with excessive privilege;
- missing backup;
- disabled audit logs.

---

# 176. Drift Remediation

```text
Detect
→ Classify
→ Isolate if Needed
→ Correct
→ Verify
→ Record
```

---

# 177. Baseline Compliance State

```text
COMPLIANT
PARTIALLY_COMPLIANT
NON_COMPLIANT
EXCEPTION_ACTIVE
UNKNOWN
```

---

# 178. Hardening Exception

Exception must include:

```text
control
scope
reason
risk
compensating_control
owner
approver
expires_at
```

---

# 179. Hardening Evidence

Minimum evidence:

- config snapshots;
- port scans;
- patch reports;
- account lists;
- ACL reports;
- certificate reports;
- vulnerability scan;
- backup status;
- monitoring screenshots/reports;
- exception records.

---

# 180. Hardening Review Cadence

Recommended:

| Area | Review |
|---|---:|
| Critical exposure | continuous/daily |
| Patch status | weekly |
| Accounts/privilege | monthly |
| Apache/PHP/DB config | quarterly |
| Full hardening review | semiannual |
| Major upgrade | event-driven |

---

# 181. Hardening Metrics

```text
host_compliance_ratio
critical_patch_overdue_total
unsupported_software_total
open_critical_port_total
privileged_account_total
inactive_privileged_account_total
hardening_drift_total
certificate_expiry_risk_total
critical_vulnerability_total
backup_protection_failure_total
```

---

# 182. KPIs

Initial targets:

```text
Unsupported production software = 0
Public database exposure = 0
Default credentials = 0
Critical patches overdue = 0
Critical hardening drift unresolved = 0
Production debug enabled = 0
Sensitive file exposure = 0
```

---

# 183. KRIs

```text
EOL software count
Unpatched critical vulnerabilities
Shared admin accounts
Expired certificates
Unexpected open ports
Failed backup protection
Repeated hardening exceptions
```

---

# 184. Dashboard Views

Recommended:

- host compliance;
- patch status;
- vulnerability status;
- open ports;
- certificate expiry;
- service health;
- privileged accounts;
- drift events;
- backup protection;
- hardening exceptions.

---

# 185. Automation

Automate where possible:

- config validation;
- port scanning;
- patch inventory;
- certificate monitoring;
- account review;
- ACL inspection;
- drift detection;
- evidence collection;
- baseline scoring.

---

# 186. Hardening API Direction

Potential endpoints:

```text
/api/internal/v1/hardening/hosts
/api/internal/v1/hardening/baselines
/api/internal/v1/hardening/assessments
/api/internal/v1/hardening/findings
/api/internal/v1/hardening/exceptions
/api/internal/v1/hardening/dashboard
```

---

# 187. Database Direction

Potential tables:

```text
hard_hosts
hard_baselines
hard_controls
hard_assessments
hard_findings
hard_evidence
hard_exceptions
hard_patch_inventory
hard_certificate_inventory
hard_port_inventory
```

---

# 188. Table: hard_hosts

```sql
CREATE TABLE hard_hosts (
    id CHAR(26) NOT NULL,
    host_code VARCHAR(80) NOT NULL,
    hostname VARCHAR(255) NOT NULL,
    environment_code VARCHAR(30) NOT NULL,
    os_name VARCHAR(100) NOT NULL,
    os_version VARCHAR(100) NOT NULL,
    owner_reference VARCHAR(180) NOT NULL,
    criticality VARCHAR(30) NOT NULL,
    status VARCHAR(30) NOT NULL,
    last_assessed_at DATETIME(6) NULL,

    PRIMARY KEY (id),
    UNIQUE KEY uq_hard_host_code (
        host_code
    ),
    KEY idx_hard_host_status (
        environment_code,
        status,
        last_assessed_at
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

# 189. Table: hard_assessments

```sql
CREATE TABLE hard_assessments (
    id CHAR(26) NOT NULL,
    host_id CHAR(26) NOT NULL,
    baseline_version VARCHAR(100) NOT NULL,
    compliance_status VARCHAR(30) NOT NULL,
    score DECIMAL(8,2) NULL,
    critical_findings INT UNSIGNED NOT NULL DEFAULT 0,
    high_findings INT UNSIGNED NOT NULL DEFAULT 0,
    assessor_reference VARCHAR(180) NOT NULL,
    assessed_at DATETIME(6) NOT NULL,

    PRIMARY KEY (id),
    KEY idx_hard_assessment (
        compliance_status,
        assessed_at
    ),
    CONSTRAINT fk_hard_assessment_host
        FOREIGN KEY (host_id)
        REFERENCES hard_hosts (id)
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

# 190. Table: hard_findings

```sql
CREATE TABLE hard_findings (
    id CHAR(26) NOT NULL,
    assessment_id CHAR(26) NOT NULL,
    finding_code VARCHAR(80) NOT NULL,
    control_reference VARCHAR(100) NOT NULL,
    severity VARCHAR(30) NOT NULL,
    description_text LONGTEXT NOT NULL,
    owner_reference VARCHAR(180) NOT NULL,
    status VARCHAR(30) NOT NULL,
    target_date DATE NULL,
    verified_at DATETIME(6) NULL,

    PRIMARY KEY (id),
    UNIQUE KEY uq_hard_finding_code (
        finding_code
    ),
    KEY idx_hard_finding_status (
        severity,
        status,
        target_date
    ),
    CONSTRAINT fk_hard_finding_assessment
        FOREIGN KEY (assessment_id)
        REFERENCES hard_assessments (id)
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

# 191. Event Codes

```text
HARD_HOST_REGISTERED
HARD_ASSESSMENT_STARTED
HARD_ASSESSMENT_COMPLETED
HARD_CRITICAL_FINDING_CREATED
HARD_DRIFT_DETECTED
HARD_PATCH_OVERDUE
HARD_CERTIFICATE_NEAR_EXPIRY
HARD_UNEXPECTED_PORT_DETECTED
HARD_EXCEPTION_APPROVED
HARD_FINDING_VERIFIED
```

---

# 192. Error Codes

```text
HARD_HOST_NOT_FOUND
HARD_BASELINE_NOT_FOUND
HARD_ASSESSMENT_FAILED
HARD_CRITICAL_DRIFT_DETECTED
HARD_PATCH_LEVEL_INVALID
HARD_UNSUPPORTED_SOFTWARE
HARD_PORT_EXPOSURE_DETECTED
HARD_CERTIFICATE_INVALID
HARD_PERMISSION_INVALID
HARD_EXCEPTION_EXPIRED
```

---

# 193. Reference Apache Baseline

```apache
ServerTokens Prod
ServerSignature Off
TraceEnable Off

<Directory "D:/xampp/htdocs/platform/public">
    AllowOverride All
    Require all granted
    Options -Indexes
</Directory>

<Directory "D:/xampp/htdocs/platform/storage">
    Require all denied
    Options -Indexes
</Directory>

<FilesMatch "\.(env|ini|log|sql|bak|md|key|pem)$">
    Require all denied
</FilesMatch>
```

---

# 194. Reference PHP Production Baseline

```ini
display_errors = Off
display_startup_errors = Off
log_errors = On
expose_php = Off

session.use_strict_mode = 1
session.use_only_cookies = 1
session.cookie_httponly = 1
session.cookie_secure = 1
session.cookie_samesite = Lax

allow_url_include = Off
```

---

# 195. Reference MySQL Account Model

```sql
CREATE USER 'platform_app'@'localhost'
IDENTIFIED BY 'strong-runtime-password';

GRANT SELECT, INSERT, UPDATE, DELETE
ON platform_db.*
TO 'platform_app'@'localhost';
```

Migration account:

```sql
CREATE USER 'platform_migration'@'localhost'
IDENTIFIED BY 'strong-migration-password';

GRANT SELECT, INSERT, UPDATE, DELETE,
      CREATE, ALTER, INDEX, DROP, REFERENCES
ON platform_db.*
TO 'platform_migration'@'localhost';
```

---

# 196. Host Hardening Checklist

- [ ] Supported OS.
- [ ] Security patches current.
- [ ] Host firewall enabled.
- [ ] Unnecessary services disabled.
- [ ] Standard/admin accounts separated.
- [ ] Guest/default accounts secured.
- [ ] Time synchronization active.
- [ ] Endpoint protection active.
- [ ] Disk encryption reviewed.
- [ ] Remote access restricted.

---

# 197. Apache Hardening Checklist

- [ ] Supported version.
- [ ] Only required modules enabled.
- [ ] Server signature disabled.
- [ ] Directory listing disabled.
- [ ] TRACE disabled.
- [ ] Document root points to public.
- [ ] Sensitive paths denied.
- [ ] Sensitive extensions denied.
- [ ] TLS enabled in production.
- [ ] Access/error logs enabled.

---

# 198. PHP Hardening Checklist

- [ ] Supported PHP version.
- [ ] Display errors off in production.
- [ ] Logging enabled.
- [ ] Expose PHP off.
- [ ] Secure session settings.
- [ ] Remote include disabled.
- [ ] Upload limits configured.
- [ ] Runtime limits configured.
- [ ] Temporary paths protected.
- [ ] Unneeded extensions removed.

---

# 199. Database Hardening Checklist

- [ ] Supported DB version.
- [ ] Root not used by application.
- [ ] Anonymous users removed.
- [ ] Test DB removed.
- [ ] Remote root restricted.
- [ ] Runtime/migration/backup accounts separated.
- [ ] Port not publicly exposed.
- [ ] Strict SQL mode reviewed.
- [ ] Logs configured.
- [ ] Backup protected.

---

# 200. Filesystem Hardening Checklist

- [ ] Public/private separation.
- [ ] Uploads outside public root.
- [ ] Script execution disabled in upload paths.
- [ ] Logs protected.
- [ ] Config protected.
- [ ] Backups protected.
- [ ] Artifact immutability enforced.
- [ ] ACLs reviewed.
- [ ] Runtime write permissions minimal.
- [ ] Quarantine isolated.

---

# 201. Runtime Verification Checklist

- [ ] Only expected ports open.
- [ ] Services run under expected identities.
- [ ] Debug disabled.
- [ ] Secure headers active.
- [ ] Certificate valid.
- [ ] Health endpoints pass.
- [ ] Logs flow.
- [ ] Backup healthy.
- [ ] No critical vulnerabilities.
- [ ] No critical drift.

---

# 202. UAT — Host Hardening

- [ ] Host inventory exists.
- [ ] Owners assigned.
- [ ] OS support status known.
- [ ] Patch level verified.
- [ ] Firewall rules verified.
- [ ] Remote access restricted.
- [ ] Privileged account review passes.
- [ ] Endpoint protection healthy.
- [ ] Time synchronization works.
- [ ] Host logs available.

---

# 203. UAT — Apache & TLS

- [ ] Directory listing blocked.
- [ ] Server version hidden.
- [ ] TRACE disabled.
- [ ] Sensitive paths blocked.
- [ ] Sensitive files blocked.
- [ ] Only required virtual hosts active.
- [ ] TLS certificate valid.
- [ ] Obsolete protocols disabled.
- [ ] Security headers active.
- [ ] Logs available.

---

# 204. UAT — PHP Runtime

- [ ] Production errors hidden.
- [ ] Errors logged.
- [ ] Secure session settings active.
- [ ] Remote include disabled.
- [ ] Upload limits enforced.
- [ ] Memory/execution limits enforced.
- [ ] Temp directories protected.
- [ ] Unnecessary extensions absent.
- [ ] Dangerous functions reviewed.
- [ ] Config changes audited.

---

# 205. UAT — Database

- [ ] Root not used by app.
- [ ] Accounts separated.
- [ ] Least privilege verified.
- [ ] Port exposure restricted.
- [ ] Test/default accounts removed.
- [ ] Secure file behavior reviewed.
- [ ] Local infile reviewed.
- [ ] Logs available.
- [ ] Backup account works.
- [ ] Unauthorized DDL denied for runtime user.

---

# 206. UAT — Filesystem & Identity

- [ ] Public/private paths separated.
- [ ] Runtime cannot write broadly.
- [ ] Upload scripts cannot execute.
- [ ] Logs/config/backups protected.
- [ ] Service identities dedicated.
- [ ] Shared admin accounts absent.
- [ ] Privileged access audited.
- [ ] Secrets absent from public files.
- [ ] ACL evidence available.
- [ ] Quarantine isolated.

---

# 207. UAT — Patching & Vulnerability

- [ ] Software inventory exists.
- [ ] EOL software identified.
- [ ] Patch SLAs defined.
- [ ] Critical patches current.
- [ ] Vulnerability scans run.
- [ ] Misconfigurations create findings.
- [ ] Exceptions expire.
- [ ] Remediation verified.
- [ ] Metrics available.
- [ ] Escalations work.

---

# 208. UAT — Monitoring & Recovery

- [ ] Service health monitored.
- [ ] Certificate expiry monitored.
- [ ] Disk/capacity monitored.
- [ ] Backup status monitored.
- [ ] Unexpected ports detected.
- [ ] Security events visible.
- [ ] Runtime alerts work.
- [ ] Logs retained.
- [ ] Deployment verification works.
- [ ] Hardening evidence retained.

---

# 209. Definition of Done — SSOT-DEPLOY-05

SSOT-DEPLOY-05 dianggap selesai bila:

- [ ] objectives/principles tersedia;
- [ ] hardening layers tersedia;
- [ ] environment-based hardening tersedia;
- [ ] host OS baseline tersedia;
- [ ] host inventory/ownership tersedia;
- [ ] account/remote access/firewall rules tersedia;
- [ ] time/endpoint/disk/log controls tersedia;
- [ ] Apache hardening tersedia;
- [ ] TLS/certificate controls tersedia;
- [ ] PHP hardening tersedia;
- [ ] session/upload/runtime controls tersedia;
- [ ] database hardening tersedia;
- [ ] account/network/log/backup controls tersedia;
- [ ] filesystem hardening tersedia;
- [ ] service identity model tersedia;
- [ ] privileged access tersedia;
- [ ] secrets/key controls tersedia;
- [ ] network segmentation/egress tersedia;
- [ ] patch management tersedia;
- [ ] vulnerability management tersedia;
- [ ] logging/monitoring tersedia;
- [ ] scheduler/worker/backup agent hardening tersedia;
- [ ] XAMPP-specific risk tersedia;
- [ ] deployment verification tersedia;
- [ ] drift/compliance/exception model tersedia;
- [ ] evidence/review cadence tersedia;
- [ ] metrics/KPI/KRI tersedia;
- [ ] automation direction tersedia;
- [ ] API/database direction tersedia;
- [ ] event/error codes tersedia;
- [ ] reference configs tersedia;
- [ ] checklists/UAT tersedia.

---

# 210. Implementation Roadmap

## Phase 1 — Baseline Inventory

- inventory hosts and services;
- inventory ports;
- inventory accounts;
- inventory certificates;
- inventory versions and patches;
- assign owners.

## Phase 2 — Immediate Hardening

- secure Apache;
- secure PHP;
- separate DB accounts;
- restrict filesystem;
- remove samples/default credentials;
- restrict admin tools.

## Phase 3 — Monitoring & Patching

- centralize logs;
- monitor certificates;
- monitor services;
- define patch SLAs;
- scan vulnerabilities;
- track drift.

## Phase 4 — Privilege & Network

- dedicated service identities;
- privileged access workflow;
- network segmentation;
- egress restrictions;
- hardened remote access.

## Phase 5 — Continuous Hardening

- automated assessments;
- compliance scoring;
- policy-as-code;
- immutable infrastructure;
- production runtime migration away from development bundle where appropriate.

---

# 211. Approval Gate

Dokumen dapat menjadi Approved setelah:

- Platform Governance review;
- Security Governance review;
- Infrastructure/Operations review;
- Architecture Review Board review;
- Database review;
- Release Engineering review;
- Observability review;
- Backup/DR review;
- patch/vulnerability process review;
- XAMPP residual-risk review;
- UAT evidence review.

---

# 212. Closing Statement

Infrastructure dan runtime hardening harus memastikan setiap host, service, account, port, certificate, configuration, dan dependency:

- diketahui;
- memiliki owner;
- menggunakan supported version;
- menggunakan least privilege;
- dipatch;
- dipantau;
- dilindungi;
- diuji;
- dapat diaudit;
- memiliki exception yang time-bound bila belum compliant.

Hardening tidak boleh menjadi aktivitas satu kali.

Hardening harus menjadi baseline aktif yang terus diverifikasi, dibandingkan dengan runtime aktual, dan diperbarui mengikuti perubahan teknologi, ancaman, dan kebutuhan platform.
