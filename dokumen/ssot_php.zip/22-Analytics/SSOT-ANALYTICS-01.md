# SSOT-ANALYTICS-01 — Analytics, Metrics & Semantic Layer Governance

## Status Dokumen

| Item | Nilai |
|---|---|
| Kode | SSOT-ANALYTICS-01 |
| Judul | Analytics, Metrics & Semantic Layer Governance |
| Versi | 1.0 |
| Status | Draft Architecture |
| Domain | Platform Kernel |
| Kategori | Analytics Governance, Metrics, Semantic Models & Reporting Certification |
| Cakupan | Metric Definitions, KPI Ownership, Semantic Models, Dimensional Consistency, Lineage, Certification, Reconciliation |
| Bergantung pada | SSOT-GOV-01, SSOT-GOV-04, SSOT-GOV-05, SSOT-DATA-01..07, SSOT-MDM-01, SSOT-AUDIT-01, SSOT-API-01..09, SSOT-TEST-01 |
| Target Stack | SQL-compatible Warehouse/Lakehouse, BI Tools, Semantic Layer, dbt-compatible |
| Target Evolusi | Governed Metrics Store, Federated Semantic Layer, Certified Self-Service Analytics, Continuous Reporting Assurance |

# 1. Executive Summary

SSOT-ANALYTICS-01 menetapkan governance resmi untuk analytics, metric definitions, KPI ownership, semantic models, dimensions, measures, lineage, certification, publication, dan reconciliation.

Dokumen ini memastikan setiap metric dan report:

- memiliki owner;
- memiliki business definition;
- memiliki technical definition;
- memiliki grain;
- memiliki dimensions;
- memiliki source lineage;
- memiliki freshness policy;
- memiliki quality rules;
- memiliki certification status;
- dapat direkonsiliasi;
- dapat diaudit.

# 2. Objectives

Framework harus:

- menyediakan metric registry;
- menetapkan ownership;
- menyediakan semantic layer;
- mengatur dimensions dan measures;
- mengatur KPI lifecycle;
- menyediakan certification;
- mengatur report publication;
- menyediakan lineage;
- menyediakan freshness dan quality controls;
- menyediakan reconciliation.

# 3. Core Principles

```text
Every Metric Has an Owner
Business Meaning Comes Before SQL
Grain Must Be Explicit
Dimensions Must Be Conformed
Measures Must Be Deterministic
Certified Metrics Are Reusable
Reports Must Use Governed Definitions
Lineage Must Be Visible
Freshness Must Be Measurable
Every Published Number Must Be Explainable
```

# 4. Scope

Berlaku untuk:

```text
Operational Dashboards
Executive Dashboards
Regulatory Reports
Financial Reports
Clinical Reports
Homecare Reports
CRM Reports
Usage Analytics
SLA Metrics
Audit Analytics
```

# 5. Metric Registry

Minimum:

```text
metric_code
metric_name
business_definition
technical_definition
owner
grain
aggregation
dimensions
source
freshness
status
```

# 6. Metric Types

```text
COUNT
SUM
AVERAGE
RATIO
RATE
PERCENTAGE
DURATION
DISTINCT_COUNT
INDEX
SCORE
```

# 7. Metric Ownership

Setiap metric wajib memiliki:

- business owner;
- data owner;
- technical owner;
- data steward;
- reporting owner;
- compliance owner where applicable.

# 8. Metric Lifecycle

```text
PROPOSED
DRAFT
IN_REVIEW
CERTIFIED
ACTIVE
DEPRECATED
RETIRED
REJECTED
```

# 9. Business Definition

Business definition harus:

- jelas;
- tidak ambigu;
- memiliki inclusion rules;
- memiliki exclusion rules;
- memiliki unit;
- memiliki period;
- memiliki intended use.

# 10. Technical Definition

Technical definition harus mencakup:

- source datasets;
- joins;
- filters;
- aggregation;
- null handling;
- timezone;
- effective date;
- SQL/model reference;
- version.

# 11. Metric Grain

Grain adalah level detail satu baris/observasi.

Contoh:

```text
per patient
per visit
per invoice
per day
per clinic
per nurse
per wound episode
```

# 12. Aggregation

Allowed aggregation must be explicit.

# 13. Additivity

Classification:

```text
ADDITIVE
SEMI_ADDITIVE
NON_ADDITIVE
```

# 14. Additive Measure

Dapat dijumlahkan lintas semua dimensions.

# 15. Semi-Additive Measure

Hanya dapat dijumlahkan lintas dimensions tertentu.

# 16. Non-Additive Measure

Harus dihitung ulang, tidak boleh dijumlahkan langsung.

# 17. Ratio Metrics

Numerator dan denominator harus didefinisikan terpisah.

# 18. Percentage Metrics

Harus menyebut denominator dan basis population.

# 19. Distinct Counts

Harus menyebut canonical identity.

# 20. Time Semantics

Metric harus menentukan:

```text
event time
processing time
reporting date
timezone
calendar
period boundary
```

# 21. Calendar Types

```text
GREGORIAN
FISCAL
BUSINESS
CLINICAL
TENANT_SPECIFIC
```

# 22. Timezone

Default UTC untuk storage; reporting timezone harus explicit.

# 23. Late-Arriving Data

Metric policy harus menentukan restatement behavior.

# 24. Restatement Modes

```text
NO_RESTATEMENT
WINDOWED_RESTATEMENT
FULL_RESTATEMENT
MANUAL_RESTATEMENT
```

# 25. Dimensions

Dimension provides analytical context.

# 26. Conformed Dimensions

Dimensions reused consistently across metrics.

Examples:

```text
date
tenant
organization
clinic
department
patient
practitioner
service
location
status
```

# 27. Dimension Ownership

Every dimension has owner and source.

# 28. Slowly Changing Dimensions

Supported:

```text
TYPE_1
TYPE_2
TYPE_3_APPROVED
```

# 29. Type 1

Overwrite current value without history.

# 30. Type 2

Preserve historical versions.

# 31. Dimension Keys

Use surrogate analytical keys plus canonical master-data IDs.

# 32. Master Data Binding

Dimensions must reference MDM-01 where applicable.

# 33. Unknown Member

Every dimension should define unknown/not-applicable handling.

# 34. Hierarchies

Examples:

```text
tenant > organization > clinic > department
country > province > city
year > quarter > month > day
```

# 35. Hierarchy Governance

Must prevent cycles and preserve effective dates.

# 36. Measures

Measures must define:

- type;
- unit;
- aggregation;
- precision;
- rounding;
- null behavior;
- allowed dimensions.

# 37. Semantic Model

Semantic model contains governed:

```text
entities
dimensions
measures
metrics
relationships
filters
time semantics
security policies
```

# 38. Semantic Model Lifecycle

```text
DRAFT
VALIDATING
CERTIFIED
ACTIVE
DEPRECATED
RETIRED
```

# 39. Semantic Versioning

Recommended:

```text
MAJOR.MINOR.PATCH
```

# 40. Breaking Semantic Change

Examples:

- metric meaning changed;
- grain changed;
- denominator changed;
- dimension relationship changed;
- history behavior changed;
- security scope changed.

# 41. Certified Semantic Model

Only certified models may back official reports.

# 42. Metric Reuse

Reports must reference canonical metric codes rather than copy custom SQL.

# 43. Local Metric Exception

Allowed only with:

- business justification;
- owner;
- scope;
- expiry;
- migration path.

# 44. KPI

KPI is a metric tied to target, threshold, and decision.

# 45. KPI Definition

Minimum:

```text
metric
target
warning threshold
critical threshold
period
owner
action
```

# 46. KPI Ownership

Owner accountable for action, not only calculation.

# 47. KPI Status

```text
ON_TARGET
AT_RISK
OFF_TARGET
NO_DATA
NOT_APPLICABLE
```

# 48. Threshold Versioning

Thresholds must be versioned and effective-dated.

# 49. Targets

Targets may vary by tenant, organization, clinic, or period.

# 50. Reporting Dataset

Must define:

- grain;
- partitioning;
- retention;
- freshness;
- owner;
- classification;
- quality checks.

# 51. Source Types

```text
OPERATIONAL_DB
EVENT_STREAM
DATA_WAREHOUSE
DATA_LAKE
MATERIALIZED_VIEW
EXTERNAL_DATASET
```

# 52. Source Authority

Official reports must use approved sources.

# 53. Data Mart

A data mart must have domain owner and semantic contract.

# 54. Transformation Models

Models should be version-controlled, tested, and documented.

# 55. Model Layers

Recommended:

```text
STAGING
INTERMEDIATE
CORE
MART
SEMANTIC
REPORT
```

# 56. Staging

Minimal source normalization.

# 57. Intermediate

Reusable transformations.

# 58. Core

Conformed business entities.

# 59. Mart

Domain-focused analytical datasets.

# 60. Report Layer

Presentation-specific final output.

# 61. Metric Calculation

Should occur in semantic/metric layer where possible.

# 62. Data Quality Rules

Dimensions:

```text
COMPLETENESS
ACCURACY
CONSISTENCY
UNIQUENESS
TIMELINESS
VALIDITY
```

# 63. Quality Thresholds

Certified metrics must define blocking and warning thresholds.

# 64. Freshness SLA

Every official dataset/metric must define freshness.

# 65. Freshness States

```text
FRESH
DELAYED
STALE
UNKNOWN
```

# 66. Stale Report Behavior

May:

- show warning;
- block publication;
- show last refresh;
- hide metric;
- escalate.

# 67. Data Observability

Monitor:

- row count;
- nulls;
- schema changes;
- freshness;
- distribution;
- duplicates;
- anomalies;
- lineage breaks.

# 68. Metric Lineage

Must trace:

```text
source
→ transformation
→ model
→ metric
→ report/dashboard
```

# 69. Field-Level Lineage

Required for regulated/high-risk metrics where feasible.

# 70. Report Registry

Minimum:

```text
report_code
report_name
owner
audience
metrics
datasets
schedule
classification
certification
```

# 71. Report Types

```text
OPERATIONAL
MANAGEMENT
EXECUTIVE
REGULATORY
FINANCIAL
CLINICAL
AD_HOC
```

# 72. Report Lifecycle

```text
DRAFT
IN_REVIEW
CERTIFIED
PUBLISHED
DEPRECATED
RETIRED
```

# 73. Report Certification

Validate:

- metric definitions;
- filters;
- dimensions;
- totals;
- access control;
- freshness;
- lineage;
- export behavior;
- reconciliation.

# 74. Dashboard Certification

Must include all constituent metrics and filters.

# 75. Self-Service Analytics

Permitted using certified datasets and semantic models.

# 76. Self-Service Guardrails

- certified sources;
- governed metrics;
- row-level security;
- field masking;
- query limits;
- export controls;
- lineage.

# 77. Ad Hoc Analysis

Must be labeled non-certified unless formally reviewed.

# 78. Regulatory Reports

Require:

- fixed definitions;
- versioned rules;
- evidence;
- approval;
- submission reconciliation;
- retention.

# 79. Financial Reports

Require:

- controlled close period;
- restatement policy;
- reconciliation;
- approval;
- immutable snapshots.

# 80. Clinical Reports

Require:

- data quality;
- patient identity resolution;
- clinical definition review;
- privacy controls;
- safe interpretation.

# 81. Row-Level Security

Analytics access must respect tenant, organization, clinic, team, and user scope.

# 82. Column-Level Security

Sensitive fields must be masked or omitted.

# 83. Aggregation Privacy

Small-cell suppression or privacy rules may apply.

# 84. Export Governance

Exports require:

- permission;
- purpose;
- minimization;
- classification;
- expiry/retention;
- audit.

# 85. Query Governance

May enforce:

- timeout;
- row limits;
- concurrency;
- cost limits;
- sandboxing;
- cancellation.

# 86. Caching

Cache must include security scope and semantic version.

# 87. Metric Cache Invalidation

Invalidate on:

- source refresh;
- semantic change;
- threshold change;
- security change;
- restatement.

# 88. Materialized Views

Must record refresh policy and failure behavior.

# 89. Snapshot Reporting

Official period-close reports may use immutable snapshots.

# 90. Report Reconciliation

Compare:

- source totals;
- warehouse totals;
- semantic totals;
- report totals;
- exports;
- submissions.

# 91. Reconciliation Dimensions

```text
count
amount
distinct identity
status
period
tenant
organization
clinic
```

# 92. Reconciliation Findings

```text
SOURCE_MART_COUNT_MISMATCH
SEMANTIC_REPORT_MISMATCH
METRIC_DEFINITION_DRIFT
DIMENSION_KEY_MISSING
STALE_DATA_PUBLISHED
UNAUTHORIZED_REPORT_ACCESS
UNCERTIFIED_METRIC_USED
LINEAGE_MISSING
THRESHOLD_VERSION_MISMATCH
SNAPSHOT_MISMATCH
```

# 93. Auto-Remediation

Examples:

- refresh stale model;
- invalidate cache;
- rebuild materialized view;
- republish semantic model;
- repair lineage metadata.

# 94. Manual Remediation

Required for:

- financial mismatch;
- regulatory mismatch;
- clinical-definition conflict;
- identity ambiguity;
- metric semantic dispute;
- cross-tenant risk.

# 95. Metric Certification Tests

```text
DEFINITION_TEST
GRAIN_TEST
AGGREGATION_TEST
DIMENSION_TEST
NULL_TEST
TIME_TEST
RECONCILIATION_TEST
SECURITY_TEST
FRESHNESS_TEST
```

# 96. Golden Datasets

Use representative fixed datasets with known expected outputs.

# 97. Metric Change Management

Material changes require:

- impact analysis;
- new version;
- consumer list;
- migration guide;
- recertification;
- communication.

# 98. Metric Deprecation

Must include:

- replacement;
- reason;
- affected reports;
- migration deadline;
- sunset date;
- owner.

# 99. Metric Retirement

Preconditions:

- no certified reports depend on it;
- no active consumers;
- history preserved;
- replacement available;
- audit retained.

# 100. Analytics Catalog

Must expose:

- metrics;
- dimensions;
- datasets;
- reports;
- owners;
- freshness;
- quality;
- lineage;
- certification;
- support status.

# 101. Audit Events

```text
ANALYTICS_METRIC_PROPOSED
ANALYTICS_METRIC_CERTIFIED
ANALYTICS_METRIC_DEPRECATED
ANALYTICS_SEMANTIC_MODEL_PUBLISHED
ANALYTICS_REPORT_CERTIFIED
ANALYTICS_REPORT_PUBLISHED
ANALYTICS_DATA_STALE
ANALYTICS_RECONCILIATION_FAILED
ANALYTICS_EXPORT_CREATED
ANALYTICS_ACCESS_DENIED
```

# 102. Metrics

```text
analytics_metric_total
analytics_certified_metric_total
analytics_uncertified_usage_total
analytics_report_total
analytics_stale_dataset_total
analytics_quality_failure_total
analytics_reconciliation_failure_total
analytics_export_total
analytics_lineage_gap_total
```

# 103. KPIs

```text
Official reports using uncertified metrics = 0
Published reports without owner = 0
Certified metrics without lineage = 0
Stale regulatory reports published = 0
Cross-tenant analytics leakage = 0
Metric definition drift = 0
Financial report mismatch unresolved = 0
```

# 104. KRIs

```text
Uncertified metric usage
Stale data frequency
Quality failure rate
Reconciliation mismatch
Metric duplication
Semantic model fragmentation
Export volume growth
Lineage gap growth
```

# 105. Database Direction

Potential tables:

```text
analytics_metric_registry
analytics_metric_versions
analytics_dimensions
analytics_dimension_hierarchies
analytics_semantic_models
analytics_semantic_model_versions
analytics_datasets
analytics_reports
analytics_report_metrics
analytics_certifications
analytics_quality_results
analytics_lineage
analytics_reconciliation_runs
analytics_reconciliation_findings
```

# 106. Table: analytics_metric_registry

```sql
CREATE TABLE analytics_metric_registry (
    id CHAR(26) NOT NULL,
    metric_code VARCHAR(180) NOT NULL,
    metric_name VARCHAR(255) NOT NULL,
    metric_type VARCHAR(40) NOT NULL,
    business_owner VARCHAR(180) NOT NULL,
    data_owner VARCHAR(180) NOT NULL,
    grain_description VARCHAR(500) NOT NULL,
    aggregation_type VARCHAR(40) NOT NULL,
    unit_code VARCHAR(50) NULL,
    status VARCHAR(30) NOT NULL,
    current_version VARCHAR(100) NOT NULL,
    created_at DATETIME(6) NOT NULL,

    PRIMARY KEY (id),
    UNIQUE KEY uq_analytics_metric_code (metric_code),
    KEY idx_analytics_metric_status (
        status,
        metric_type
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

# 107. Table: analytics_metric_versions

```sql
CREATE TABLE analytics_metric_versions (
    id CHAR(26) NOT NULL,
    metric_id CHAR(26) NOT NULL,
    metric_version VARCHAR(100) NOT NULL,
    business_definition TEXT NOT NULL,
    technical_definition JSON NOT NULL,
    semantic_model_version VARCHAR(100) NOT NULL,
    checksum_sha256 CHAR(64) NOT NULL,
    status VARCHAR(30) NOT NULL,
    certified_at DATETIME(6) NULL,
    deprecated_at DATETIME(6) NULL,

    PRIMARY KEY (id),
    UNIQUE KEY uq_analytics_metric_version (
        metric_id,
        metric_version
    ),
    CONSTRAINT fk_analytics_metric_version
        FOREIGN KEY (metric_id)
        REFERENCES analytics_metric_registry (id)
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

# 108. Table: analytics_reports

```sql
CREATE TABLE analytics_reports (
    id CHAR(26) NOT NULL,
    report_code VARCHAR(180) NOT NULL,
    report_name VARCHAR(255) NOT NULL,
    report_type VARCHAR(40) NOT NULL,
    owner_reference VARCHAR(180) NOT NULL,
    audience_code VARCHAR(180) NOT NULL,
    classification VARCHAR(30) NOT NULL,
    certification_status VARCHAR(30) NOT NULL,
    refresh_schedule VARCHAR(255) NULL,
    status VARCHAR(30) NOT NULL,
    created_at DATETIME(6) NOT NULL,

    PRIMARY KEY (id),
    UNIQUE KEY uq_analytics_report_code (report_code),
    KEY idx_analytics_report_status (
        status,
        certification_status
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

# 109. Table: analytics_reconciliation_findings

```sql
CREATE TABLE analytics_reconciliation_findings (
    id CHAR(26) NOT NULL,
    run_id CHAR(26) NOT NULL,
    finding_type VARCHAR(60) NOT NULL,
    severity VARCHAR(30) NOT NULL,
    metric_code VARCHAR(180) NULL,
    report_code VARCHAR(180) NULL,
    expected_state_json JSON NULL,
    actual_state_json JSON NULL,
    status VARCHAR(30) NOT NULL,
    detected_at DATETIME(6) NOT NULL,
    resolved_at DATETIME(6) NULL,

    PRIMARY KEY (id),
    KEY idx_analytics_reconciliation_finding (
        severity,
        status,
        detected_at
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

# 110. API Direction

```text
GET  /api/internal/v1/analytics/metrics
POST /api/internal/v1/analytics/metrics
GET  /api/internal/v1/analytics/metrics/{metricCode}
POST /api/internal/v1/analytics/metrics/{metricCode}/versions
POST /api/internal/v1/analytics/metrics/{metricCode}/certify
GET  /api/internal/v1/analytics/semantic-models
POST /api/internal/v1/analytics/semantic-models
GET  /api/internal/v1/analytics/reports
POST /api/internal/v1/analytics/reports/{reportCode}/certify
POST /api/internal/v1/analytics/reconciliation/runs
```

# 111. SDK Contracts

```text
AnalyticsMetricRegistryInterface
SemanticModelRegistryInterface
AnalyticsCertificationServiceInterface
AnalyticsLineageServiceInterface
AnalyticsFreshnessServiceInterface
AnalyticsQualityServiceInterface
AnalyticsReconciliationServiceInterface
```

# 112. Metric Registry Contract

```php
interface AnalyticsMetricRegistryInterface
{
    public function find(
        string $metricCode,
        string $version
    ): ?AnalyticsMetricDefinition;

    public function requireCertified(
        string $metricCode
    ): AnalyticsMetricDefinition;
}
```

# 113. Certification Contract

```php
interface AnalyticsCertificationServiceInterface
{
    public function certifyMetric(
        AnalyticsMetricCertificationRequest $request
    ): AnalyticsCertificationResult;

    public function certifyReport(
        AnalyticsReportCertificationRequest $request
    ): AnalyticsCertificationResult;
}
```

# 114. Error Codes

```text
ANALYTICS_METRIC_NOT_FOUND
ANALYTICS_METRIC_NOT_CERTIFIED
ANALYTICS_METRIC_DEFINITION_INVALID
ANALYTICS_METRIC_GRAIN_CONFLICT
ANALYTICS_DIMENSION_NOT_FOUND
ANALYTICS_SEMANTIC_MODEL_INVALID
ANALYTICS_DATA_STALE
ANALYTICS_REPORT_NOT_CERTIFIED
ANALYTICS_ACCESS_DENIED
ANALYTICS_LINEAGE_MISSING
ANALYTICS_RECONCILIATION_FAILED
```

# 115. Metric Registration Checklist

- [ ] Metric code unique.
- [ ] Business owner assigned.
- [ ] Data owner assigned.
- [ ] Business definition complete.
- [ ] Technical definition complete.
- [ ] Grain explicit.
- [ ] Aggregation defined.
- [ ] Dimensions defined.
- [ ] Source lineage available.
- [ ] Freshness SLA defined.
- [ ] Quality rules defined.
- [ ] Intended use documented.

# 116. Certification Checklist

- [ ] Definition reviewed.
- [ ] Grain validated.
- [ ] Aggregation validated.
- [ ] Dimensions conformed.
- [ ] Time semantics validated.
- [ ] Null behavior tested.
- [ ] Golden dataset passed.
- [ ] Security policies validated.
- [ ] Reconciliation passed.
- [ ] Lineage complete.
- [ ] Owner approval complete.
- [ ] Audit generated.

# 117. UAT — Metric Definition

- [ ] Count metric calculates correctly.
- [ ] Ratio numerator/denominator correct.
- [ ] Distinct count uses canonical identity.
- [ ] Grain prevents double counting.
- [ ] Null behavior follows policy.
- [ ] Timezone boundaries correct.
- [ ] Late-arriving data follows restatement policy.
- [ ] Additivity classification enforced.
- [ ] Metric version recorded.

# 118. UAT — Dimensions & Semantic Model

- [ ] Conformed dimension reused.
- [ ] Type-2 history resolves correctly.
- [ ] Unknown member handled.
- [ ] Hierarchy rollup correct.
- [ ] Cycle rejected.
- [ ] Security scope applied.
- [ ] Breaking semantic change requires major version.
- [ ] Deprecated dimension warns consumers.
- [ ] Model checksum retained.

# 119. UAT — Report Certification

- [ ] Certified metric accepted.
- [ ] Uncertified metric blocked for official report.
- [ ] Filters validated.
- [ ] Totals reconcile.
- [ ] Freshness shown.
- [ ] Row-level security applied.
- [ ] Sensitive columns masked.
- [ ] Export permission enforced.
- [ ] Lineage visible.
- [ ] Certification evidence retained.

# 120. UAT — Freshness & Quality

- [ ] Fresh data marked fresh.
- [ ] Delayed load creates warning.
- [ ] Stale regulatory report blocked.
- [ ] Null threshold failure detected.
- [ ] Duplicate threshold failure detected.
- [ ] Schema drift detected.
- [ ] Distribution anomaly detected.
- [ ] Materialized view refresh failure detected.
- [ ] Metrics update.

# 121. UAT — KPI & Thresholds

- [ ] Target applied by period.
- [ ] Tenant-specific threshold resolves.
- [ ] At-risk state calculates correctly.
- [ ] Off-target state calculates correctly.
- [ ] No-data state handled.
- [ ] Threshold version effective date works.
- [ ] Historical reports retain historical thresholds.
- [ ] KPI owner receives alert.
- [ ] Audit complete.

# 122. UAT — Reconciliation

- [ ] Source/mart count mismatch detected.
- [ ] Semantic/report mismatch detected.
- [ ] Metric-definition drift detected.
- [ ] Missing dimension key detected.
- [ ] Stale published data detected.
- [ ] Unauthorized access detected.
- [ ] Uncertified metric usage detected.
- [ ] Missing lineage detected.
- [ ] Threshold-version mismatch detected.
- [ ] Snapshot mismatch detected.

# 123. Definition of Done — SSOT-ANALYTICS-01

SSOT-ANALYTICS-01 dianggap selesai bila:

- [ ] metric registry tersedia;
- [ ] ownership model tersedia;
- [ ] business/technical definitions tersedia;
- [ ] grain/aggregation/additivity tersedia;
- [ ] ratio/percentage/distinct rules tersedia;
- [ ] time semantics/restatement tersedia;
- [ ] conformed dimensions tersedia;
- [ ] SCD/hierarchy governance tersedia;
- [ ] semantic model tersedia;
- [ ] semantic versioning tersedia;
- [ ] KPI/threshold governance tersedia;
- [ ] reporting dataset layers tersedia;
- [ ] freshness/quality controls tersedia;
- [ ] lineage tersedia;
- [ ] report/dashboard certification tersedia;
- [ ] self-service guardrails tersedia;
- [ ] regulatory/financial/clinical reporting tersedia;
- [ ] row/column security tersedia;
- [ ] export/query/cache controls tersedia;
- [ ] reconciliation tersedia;
- [ ] deprecation/retirement tersedia;
- [ ] catalog tersedia;
- [ ] audit and metrics tersedia;
- [ ] database direction tersedia;
- [ ] API direction tersedia;
- [ ] SDK contracts tersedia;
- [ ] UAT and DoD tersedia.

# 124. Implementation Roadmap

## Phase 1 — Metric Registry Foundation

- metric registry;
- ownership;
- business definitions;
- technical definitions;
- grain;
- administrative APIs.

## Phase 2 — Semantic Layer

- dimensions;
- measures;
- hierarchies;
- semantic models;
- versioning;
- access controls.

## Phase 3 — Certification & Quality

- golden datasets;
- metric tests;
- freshness;
- quality rules;
- report certification;
- lineage.

## Phase 4 — Reporting Governance

- report catalog;
- self-service guardrails;
- exports;
- regulatory/financial snapshots;
- deprecation campaigns;
- reconciliation.

## Phase 5 — Governed Analytics Platform

- centralized metrics store;
- federated semantic layer;
- automated certification;
- anomaly detection;
- continuous reconciliation;
- analytics governance dashboard.

# 125. Initial Implementation Backlog

```text
ANALYTICS01-001 Metric Registry
ANALYTICS01-002 Metric Versioning
ANALYTICS01-003 Dimension Registry
ANALYTICS01-004 Hierarchy Governance
ANALYTICS01-005 Semantic Model Registry
ANALYTICS01-006 KPI Threshold Service
ANALYTICS01-007 Freshness Monitor
ANALYTICS01-008 Data Quality Tests
ANALYTICS01-009 Metric Certification
ANALYTICS01-010 Report Registry
ANALYTICS01-011 Report Certification
ANALYTICS01-012 Analytics Lineage
ANALYTICS01-013 Self-Service Guardrails
ANALYTICS01-014 Export Governance
ANALYTICS01-015 Reconciliation Engine
ANALYTICS01-016 Analytics Governance Dashboard
```

# 126. Approval Gate

Dokumen dapat menjadi Approved setelah:

- Data Architecture review;
- Analytics/BI Architecture review;
- Domain Owner review;
- Data Stewardship review;
- Security/Privacy review;
- Finance/Clinical/Regulatory review where applicable;
- Operations review;
- Audit/Compliance review;
- Quality Engineering review;
- UAT review.

# 127. Closing Statement

Metric bukan sekadar query.

Setiap metric harus memiliki business meaning, grain, aggregation, dimensions, source, owner, freshness, quality, dan lineage.

Official reports harus menggunakan certified metrics.

Setiap angka yang dipublikasikan harus dapat dijelaskan dan direkonsiliasi.
