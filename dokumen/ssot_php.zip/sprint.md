Berikut **planning development aplikasi sesuai blueprint Permenkes 6/2026**.

# Roadmap Development

## Fase 0 — Foundation

**Target:** aplikasi punya pondasi enterprise.

Modul:

* tenant / hospital scope
* user management
* RBAC granular
* audit trail
* security baseline
* dynamic menu
* master organisasi

Output:

* login aman
* role & permission jalan
* menu muncul sesuai role
* semua aktivitas penting tercatat

---

## Fase 1 — Compliance Core

**Target:** rumah sakit/klinik bisa dikelola secara legal dan terstruktur.

Modul:

* master rumah sakit/klinik
* legal entity
* izin operasional
* klasifikasi layanan
* unit/instalasi
* struktur organisasi
* dokumen kebijakan/SOP

Output:

* data organisasi lengkap
* izin dan dokumen punya masa berlaku
* reminder dokumen kedaluwarsa
* SOP terdokumentasi

---

## Fase 2 — SDM & Credentialing

**Target:** tenaga klinis tidak hanya punya role, tapi juga kewenangan klinis.

Modul:

* staff profile
* dokter/perawat/nakes profile
* STR/SIP/sertifikat
* credentialing
* clinical privilege
* assignment unit
* approval kewenangan

Output:

* tindakan klinis bisa dibatasi berdasarkan privilege
* STR/SIP expired otomatis memberi warning/block
* riwayat credentialing tersimpan

---

## Fase 3 — Patient & Encounter Core

**Target:** transaksi pasien mulai bisa berjalan.

Modul:

* master pasien
* nomor rekam medis
* registrasi pasien
* encounter/kunjungan
* penjamin/asuransi
* consent awal
* appointment

Output:

* pasien bisa daftar
* kunjungan tercatat
* status encounter berjalan
* histori pasien rapi

---

## Fase 4 — EMR Core

**Target:** rekam medis elektronik dasar.

Modul:

* asesmen klinis
* diagnosis
* catatan dokter
* catatan keperawatan
* care plan
* tindakan
* resep
* order lab/radiologi
* hasil pemeriksaan
* tanda tangan elektronik
* amendment rekam medis

Output:

* EMR tidak diedit langsung setelah dikunci
* perubahan pakai addendum/amendment
* semua akses rekam medis diaudit

---

## Fase 5 — Billing & Service Operation

**Target:** transaksi pelayanan bisa ditagihkan.

Modul:

* service catalog
* tarif versi
* billing
* payment
* refund
* klaim
* invoice
* laporan transaksi

Output:

* tarif punya periode berlaku
* billing otomatis dari layanan
* refund perlu approval
* perubahan nominal masuk audit trail

---

## Fase 6 — Quality & Patient Safety

**Target:** platform mendukung tata kelola mutu.

Modul:

* indikator mutu
* patient safety incident
* risk grading
* RCA
* CAPA
* clinical audit
* complaint management

Output:

* insiden bisa dilaporkan
* investigasi terdokumentasi
* CAPA punya PIC, deadline, dan evidence
* dashboard mutu tersedia

---

## Fase 7 — Governance & Compliance

**Target:** siap untuk audit internal/regulator.

Modul:

* governance body / komite / tim
* rapat dan keputusan
* dewan pengawas
* compliance checklist
* finding management
* sanction remediation
* regulatory evidence package

Output:

* struktur tata kelola fleksibel
* temuan audit bisa ditindaklanjuti
* bukti kepatuhan bisa diekspor

---

## Fase 8 — Reporting & Integration

**Target:** siap integrasi dan pelaporan.

Modul:

* reporting engine
* report submission log
* integration engine
* API credential
* integration audit log
* SATUSEHAT-ready architecture

Output:

* laporan bisa dibuat dan ditelusuri
* integrasi punya retry/error log
* payload keluar-masuk terdokumentasi

---

# Sprint Plan Detail

## Sprint 1.0 — Bootstrap Platform

* struktur folder modular
* environment config
* database connection
* migration system
* base layout
* error handling
* logging dasar

## Sprint 1.1 — Tenant & Hospital Scope

* tabel `tenants`
* tabel `hospitals`
* middleware tenant/hospital scope
* semua query wajib filter scope
* seed data awal

## Sprint 1.2 — User & Auth

* login/logout
* password hash
* session security
* user status
* failed login log
* password reset foundation

## Sprint 1.3 — RBAC Core

* `roles`
* `permissions`
* `role_permissions`
* `user_role_assignments`
* permission checker
* middleware permission

## Sprint 1.4 — Dynamic Menu

* `menus`
* `menu_items`
* `menu_permissions`
* render menu sesuai permission
* sidebar dinamis

## Sprint 1.5 — Audit Trail

* `audit_events`
* audit helper
* audit middleware
* log create/update/delete
* log login/logout
* log akses data sensitif

---

## Sprint 2.0 — Organization Master

* legal entity
* hospital profile
* unit/instalasi
* jabatan
* struktur organisasi
* versi struktur

## Sprint 2.1 — Licensing Registry

* master jenis izin
* data izin RS/klinik
* upload dokumen
* expiry reminder
* approval status

## Sprint 2.2 — SOP & Document Governance

* dokumen kebijakan
* SOP
* versi dokumen
* approval dokumen
* acknowledgement staff

---

## Sprint 3.0 — Staff Master

* staff profile
* dokter profile
* perawat profile
* nakes profile
* unit assignment

## Sprint 3.1 — STR/SIP & Certificate

* registrasi STR
* SIP
* sertifikat kompetensi
* expiry warning
* document upload

## Sprint 3.2 — Credentialing

* pengajuan kredensial
* review
* approval
* recredentialing schedule

## Sprint 3.3 — Clinical Privilege

* privilege catalog
* privilege assignment
* privilege restriction
* privilege expiry
* privilege checker untuk tindakan klinis

---

## Sprint 4.0 — Patient Master

* pasien
* alamat
* kontak
* nomor RM
* emergency contact
* duplicate detection dasar

## Sprint 4.1 — Registration & Encounter

* registrasi kunjungan
* encounter
* status encounter
* lokasi pelayanan
* tenaga terlibat

## Sprint 4.2 — Appointment

* jadwal kunjungan
* booking
* reschedule
* cancel
* reminder dasar

## Sprint 4.3 — Consent

* general consent
* informed consent
* refusal form
* digital signature foundation

---

## Sprint 5.0 — EMR Basic

* asesmen
* vital sign
* diagnosis
* clinical note
* nursing note
* care plan

## Sprint 5.1 — Orders

* clinical order
* lab order
* radiology order
* procedure order
* status order

## Sprint 5.2 — Medication

* resep
* verifikasi farmasi
* dispensing
* medication administration

## Sprint 5.3 — EMR Lock & Amendment

* sign note
* lock record
* amendment
* cosign
* access log EMR

---

## Sprint 6.0 — Billing Foundation

* service catalog
* tariff version
* bill item
* invoice
* payment

## Sprint 6.1 — Claim & Refund

* claim data
* claim submission
* refund request
* refund approval
* audit nominal

---

## Sprint 7.0 — Quality Indicator

* indikator mutu
* target
* measurement
* dashboard mutu

## Sprint 7.1 — Patient Safety

* incident report
* severity
* risk grading
* investigator assignment

## Sprint 7.2 — RCA & CAPA

* RCA
* corrective action
* preventive action
* evidence upload
* effectiveness review

## Sprint 7.3 — Complaint Management

* pengaduan pasien
* investigasi
* response
* resolution

---

## Sprint 8.0 — Governance Body

* komite/tim/penanggung jawab
* anggota
* fungsi
* kewenangan
* masa berlaku

## Sprint 8.1 — Meeting & Decision

* agenda rapat
* notulen
* keputusan
* rekomendasi
* tindak lanjut

## Sprint 8.2 — Compliance Case

* requirement checklist
* finding
* remediation plan
* evidence
* verification

---

## Sprint 9.0 — Reporting Engine

* report definition
* report parameter
* report run
* export PDF/Excel

## Sprint 9.1 — Integration Engine

* API endpoint registry
* credential
* mapping
* request/response log
* retry/error handling

---

# Prioritas Build untuk Nerslink

Untuk kondisi Nerslink sekarang, urutan paling aman:

1. RBAC + dynamic menu
2. audit trail
3. tenant/hospital/clinic scope
4. staff + nurse/doctor profile
5. credentialing + privilege
6. patient master
7. encounter/visit
8. EMR woundcare/homecare
9. consent
10. billing
11. quality & patient safety
12. reporting
13. compliance dashboard

# Kesimpulan

Mulai dari **Sprint 1.0 sampai 3.3 dulu** sebelum memperluas transaksi klinis.

Bagian paling kritis bukan EMR, tapi:

1. **scope klinik/RS**
2. **RBAC**
3. **audit trail**
4. **credentialing**
5. **clinical privilege**

Tanpa 5 fondasi itu, transaksi klinis rawan bocor akses, sulit diaudit, dan lemah untuk compliance.
