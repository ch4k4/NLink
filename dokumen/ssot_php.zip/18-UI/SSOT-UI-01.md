# SSOT-UI-01 — Enterprise UI Architecture & Design System

---

## Status Dokumen

| Item | Nilai |
|---|---|
| Kode | SSOT-UI-01 |
| Judul | Enterprise UI Architecture & Design System |
| Versi | 1.0 |
| Status | Draft Architecture |
| Domain | Platform Kernel |
| Kategori | UI Architecture, Design System & Frontend Governance |
| Cakupan | Design Tokens, Theme Engine, Layout, Responsive, Accessibility, Components, State, Navigation Integration, Frontend Security, Testing |
| Bergantung pada | SSOT-GOV-01, SSOT-GOV-02, SSOT-GOV-03, SSOT-RBAC-05, SSOT-MENU-02, SSOT-MENU-03, SSOT-MENU-04, SSOT-TEST-01, SSOT-MODULE-01 |
| Target Stack | HTML5, CSS3, Vanilla JavaScript-first, Progressive Enhancement, PHP-rendered UI compatible |
| Target Evolusi | Component Library, Multi-Theme, Multi-Industry UI, Microfrontend-ready, Design Token Distribution |

---

# 1. Executive Summary

SSOT-UI-01 menetapkan arsitektur UI dan design system resmi untuk Platform Kernel dan seluruh business modules.

Dokumen ini mengatur:

- design tokens;
- color system;
- typography;
- spacing;
- sizing;
- radius;
- elevation;
- motion;
- z-index;
- theme engine;
- light/dark/system themes;
- tenant branding;
- industry themes;
- layout system;
- responsive breakpoints;
- shell;
- sidebar;
- topbar;
- content regions;
- grid;
- forms;
- tables;
- cards;
- navigation;
- notifications;
- dialogs;
- drawers;
- tabs;
- filters;
- empty states;
- loading states;
- errors;
- accessibility;
- localization;
- frontend state;
- component lifecycle;
- module UI contribution;
- CSS architecture;
- JavaScript architecture;
- route/menu integration;
- authorization projection;
- performance;
- testing;
- observability;
- governance;
- versioning;
- Definition of Done;
- roadmap.

Tujuan akhirnya adalah memastikan seluruh UI:

- konsisten;
- reusable;
- responsive;
- accessible;
- secure;
- themeable;
- multi-tenant;
- multi-industry;
- module-friendly;
- tidak menjadi authorization boundary;
- mudah dipelihara;
- dapat diuji;
- dapat dikembangkan menuju multi-platform frontend.

---

# 2. Objectives

UI architecture harus:

- menyediakan single source of truth untuk visual system;
- mengurangi inline styling dan duplication;
- mendukung desktop, tablet, dan mobile;
- mendukung light/dark/system theme;
- mendukung tenant branding dengan guardrails;
- mendukung module contribution;
- menjaga accessibility;
- menjaga frontend security;
- menjaga performance;
- menyediakan component governance;
- menjaga backward compatibility.

---

# 3. Core Principles

```text
Tokens Before Hard-Coded Values
Components Before Page-Specific Styling
Progressive Enhancement
Mobile-First Where Practical
Accessibility Is Mandatory
UI Visibility Is Not Authorization
Server-Side Security Remains Authoritative
Modules Extend Through Contracts
Themes Must Not Break Semantics
Consistency Over Local Preference
```

---

# 4. Scope

Framework berlaku untuk:

```text
Platform Shell
Admin Console
Business Module UI
Patient/Customer Portal
Mobile Web
Tablet Layout
Responsive Desktop
Dashboard
Forms
Data Tables
Reports
Workflow Screens
Navigation
Notifications
Authentication Screens
Error Screens
```

---

# 5. Non-Scope

Dokumen ini tidak menetapkan:

- native mobile implementation;
- final brand identity;
- every page-specific design;
- detailed marketing website design;
- business copywriting;
- authorization engine internals.

---

# 6. UI Architecture Layers

```text
Design Tokens
→ Foundations
→ Primitive Components
→ Composite Components
→ Patterns
→ Layouts
→ Pages
→ Module UI Contributions
```

---

# 7. Design Tokens

Design tokens adalah canonical variables untuk visual decisions.

Categories:

```text
COLOR
TYPOGRAPHY
SPACING
SIZE
RADIUS
ELEVATION
BORDER
MOTION
Z_INDEX
BREAKPOINT
DENSITY
```

---

# 8. Token Naming

Format:

```text
--{category}-{role}-{variant}
```

Examples:

```text
--color-bg-surface
--color-text-primary
--space-4
--radius-md
--shadow-lg
--font-size-sm
```

---

# 9. Semantic Tokens

Semantic tokens lebih diprioritaskan daripada raw palette tokens.

Good:

```text
--color-status-danger
```

Avoid direct usage:

```text
#ff0000
```

---

# 10. Token Layers

```text
GLOBAL
SEMANTIC
COMPONENT
TENANT_OVERRIDE
```

---

# 11. Global Tokens

Contoh:

- neutral palette;
- spacing scale;
- typography scale;
- motion durations.

---

# 12. Semantic Tokens

Contoh:

- surface;
- text;
- border;
- action;
- success;
- warning;
- danger;
- info.

---

# 13. Component Tokens

Contoh:

```text
--button-primary-bg
--input-border-focus
--sidebar-width-expanded
```

---

# 14. Tenant Override

Tenant override hanya boleh pada approved branding tokens.

---

# 15. Protected Tokens

Tidak boleh diubah tenant:

- danger semantics;
- focus indicators;
- minimum contrast;
- disabled states;
- accessibility-critical dimensions;
- z-index system;
- security warnings.

---

# 16. Color System

Color system minimum:

```text
BRAND
NEUTRAL
SURFACE
TEXT
BORDER
ACTION
SUCCESS
WARNING
DANGER
INFO
```

---

# 17. Color Semantics

Color tidak boleh menjadi satu-satunya indikator status.

---

# 18. Contrast

Text dan interactive elements harus memenuhi target accessibility yang ditetapkan organisasi.

---

# 19. Typography

Typography system mencakup:

```text
font family
font size
line height
weight
letter spacing
heading scale
body scale
caption scale
code scale
```

---

# 20. Font Strategy

Gunakan system font stack atau approved web fonts dengan fallback yang aman.

---

# 21. Spacing Scale

Recommended base:

```text
4px
```

Example scale:

```text
0, 4, 8, 12, 16, 24, 32, 40, 48, 64
```

---

# 22. Density Modes

```text
COMFORTABLE
COMPACT
TOUCH
```

---

# 23. Radius Scale

```text
none
sm
md
lg
xl
pill
```

---

# 24. Elevation

Gunakan elevation terbatas dan semantic.

---

# 25. Motion

Motion harus:

- purposeful;
- short;
- non-blocking;
- respect reduced motion;
- tidak mengganggu accessibility.

---

# 26. Z-Index Scale

Canonical layers:

```text
BASE
STICKY
DROPDOWN
OVERLAY
DRAWER
MODAL
TOAST
CRITICAL_ALERT
```

---

# 27. Theme Engine

Theme engine mendukung:

```text
LIGHT
DARK
SYSTEM
TENANT_BRANDED
INDUSTRY_VARIANT
```

---

# 28. Theme Resolution

```text
User Preference
→ Tenant Policy
→ System Preference
→ Platform Default
```

---

# 29. Theme Persistence

Preference dapat disimpan per user, tetapi harus memiliki fallback.

---

# 30. Theme Flash Prevention

Initial theme harus diterapkan sebelum first meaningful paint jika memungkinkan.

---

# 31. Tenant Branding

Tenant dapat mengatur:

- logo;
- primary brand color;
- accent;
- approved typography;
- favicon;
- limited shell branding.

---

# 32. Branding Guardrails

Tenant tidak boleh:

- menurunkan contrast;
- menyamarkan danger state;
- menyembunyikan platform/security notices;
- inject arbitrary CSS/JS;
- mengubah authorization semantics.

---

# 33. Industry Themes

Industry theme boleh mengubah presentational defaults, bukan business authorization.

---

# 34. Layout System

Canonical layout regions:

```text
APP_SHELL
SIDEBAR
TOPBAR
BREADCRUMB
PAGE_HEADER
CONTENT
ASIDE
FOOTER
OVERLAY_LAYER
```

---

# 35. App Shell

App shell bertanggung jawab atas:

- global navigation;
- tenant context;
- user context;
- notifications;
- workspace;
- responsive layout;
- global errors.

---

# 36. Sidebar

Modes:

```text
EXPANDED
COLLAPSED
OVERLAY
HIDDEN
```

---

# 37. Topbar

Topbar dapat berisi:

- workspace switcher;
- tenant/clinic context;
- search;
- notification;
- profile;
- command palette;
- contextual actions.

---

# 38. Page Header

Page header minimum:

```text
title
subtitle
breadcrumb
primary action
secondary actions
status
```

---

# 39. Content Width

Supported modes:

```text
FLUID
CONSTRAINED
READING
FULL_BLEED
```

---

# 40. Grid System

Gunakan CSS Grid/Flexbox modern.

Recommended grid:

```text
12 columns desktop
8 columns tablet
4 columns mobile
```

---

# 41. Responsive Strategy

Mobile-first where practical, with desktop enterprise optimization.

---

# 42. Breakpoints

Recommended baseline:

```text
xs: 0
sm: 576px
md: 768px
lg: 1024px
xl: 1280px
2xl: 1536px
```

---

# 43. Breakpoint Governance

Breakpoint baru membutuhkan architecture/design system review.

---

# 44. Container Queries

Dapat digunakan untuk reusable component responsiveness.

---

# 45. Responsive Tables

Strategies:

- horizontal scroll;
- priority columns;
- stacked cards;
- expandable rows;
- summary/detail split.

---

# 46. Mobile Navigation

Mobile navigation menggunakan overlay/drawer atau bottom navigation sesuai context.

---

# 47. Touch Targets

Interactive target harus cukup besar untuk touch.

---

# 48. Primitive Components

Baseline:

```text
Button
IconButton
Link
Input
Textarea
Select
Checkbox
Radio
Switch
Badge
Avatar
Divider
Spinner
Skeleton
Tooltip
```

---

# 49. Composite Components

Baseline:

```text
Card
FormField
DataTable
Pagination
Modal
Drawer
Tabs
Accordion
Dropdown
Toast
Alert
Breadcrumb
CommandPalette
FilterBar
DatePicker
FileUploader
```

---

# 50. Component States

Every interactive component should define:

```text
DEFAULT
HOVER
FOCUS
ACTIVE
DISABLED
LOADING
ERROR
SUCCESS
READ_ONLY
```

---

# 51. Button Variants

```text
PRIMARY
SECONDARY
TERTIARY
GHOST
DANGER
LINK
```

---

# 52. Destructive Action

Danger action harus jelas, terpisah, dan membutuhkan confirmation sesuai risk.

---

# 53. Forms

Form architecture mencakup:

- label;
- help text;
- validation;
- error summary;
- required marker;
- disabled/read-only;
- async state;
- dirty state;
- submit state.

---

# 54. Validation

Client-side validation meningkatkan UX tetapi server-side validation authoritative.

---

# 55. Form Error

Error harus:

- spesifik;
- dekat dengan field;
- tersedia dalam summary;
- tidak hanya menggunakan warna;
- tidak membocorkan data sensitif.

---

# 56. Read-Only vs Disabled

Read-only data tetap dapat dibaca/fokus bila appropriate.

Disabled control tidak dapat diinteraksikan.

---

# 57. Data Tables

Data table harus mendukung:

- sorting;
- filtering;
- pagination;
- selection;
- bulk actions;
- column visibility;
- empty state;
- loading;
- responsive behavior;
- accessibility.

---

# 58. Table Security

Column visibility tidak menggantikan field-level authorization.

---

# 59. Bulk Actions

Bulk action harus menampilkan:

- selected count;
- affected scope;
- destructive warning;
- permission dependency;
- progress;
- partial failure result.

---

# 60. Pagination

Prefer server-side pagination untuk dataset besar.

---

# 61. Filters

Filter state dapat disimpan di URL jika aman dan tidak mengandung sensitive data.

---

# 62. Search UI

Search harus:

- debounce;
- show loading;
- handle empty results;
- enforce query limits;
- respect tenant and authorization scope.

---

# 63. Dialog

Modal digunakan untuk focused task, bukan menggantikan page untuk complex workflows.

---

# 64. Drawer

Drawer cocok untuk secondary detail atau mobile navigation.

---

# 65. Toast

Toast tidak boleh menjadi satu-satunya tempat untuk critical error.

---

# 66. Alerts

Types:

```text
INFO
SUCCESS
WARNING
DANGER
CRITICAL
```

---

# 67. Empty States

Empty state harus membedakan:

- no data;
- no permission;
- no result;
- filtered out;
- feature unavailable;
- module inactive.

---

# 68. Loading States

Gunakan:

```text
SPINNER
SKELETON
PROGRESS
OPTIMISTIC_PENDING
```

sesuai context.

---

# 69. Error States

Categories:

```text
VALIDATION
AUTHENTICATION
AUTHORIZATION
NOT_FOUND
CONFLICT
SERVER_ERROR
NETWORK_ERROR
MAINTENANCE
```

---

# 70. Authorization UI

UI dapat menyembunyikan action berdasarkan projection, tetapi server tetap melakukan authorization.

---

# 71. Permission Projection

Frontend menerima derived capability state, bukan seluruh internal permission model jika tidak diperlukan.

---

# 72. Disabled vs Hidden

Policy:

- hidden bila existence sensitive;
- disabled bila user perlu memahami capability tapi belum memenuhi precondition;
- always secure server-side.

---

# 73. Menu Integration

Navigation berasal dari MENU-02 registry dan MENU-03 projection.

---

# 74. Route Integration

Links menggunakan canonical route name/URL generator sesuai MENU-04.

---

# 75. Deep Links

Deep link harus mempertahankan security and scope rules.

---

# 76. Breadcrumb

Breadcrumb berasal dari route/menu context dan resource label resolver.

---

# 77. Module UI Contribution

Module boleh berkontribusi melalui:

- pages;
- menu nodes;
- context actions;
- dashboard widgets;
- form sections;
- tabs;
- cards;
- reports.

---

# 78. UI Extension Point

Setiap extension point harus mendefinisikan:

```text
code
owner
allowed component types
data contract
permission policy
ordering
lifecycle
```

---

# 79. Arbitrary HTML

Module tidak boleh inject arbitrary unsafe HTML.

---

# 80. Arbitrary JavaScript

Module tidak boleh inject ungoverned JavaScript ke global scope.

---

# 81. Component Registry

Canonical component registry mencatat:

- component code;
- version;
- owner;
- status;
- accessibility status;
- supported variants;
- dependencies.

---

# 82. Component Lifecycle

```text
EXPERIMENTAL
DRAFT
APPROVED
ACTIVE
DEPRECATED
RETIRED
```

---

# 83. Component Versioning

Breaking API/markup changes require major version or migration path.

---

# 84. CSS Architecture

Recommended layers:

```text
tokens
reset
base
layout
components
utilities
themes
overrides
```

---

# 85. CSS Naming

Gunakan naming convention konsisten.

Examples:

```text
.c-button
.c-card
.l-shell
.u-hidden
.is-active
```

atau equivalent convention approved by project.

---

# 86. CSS Specificity

Hindari specificity escalation.

---

# 87. Inline Styles

Inline styles dilarang untuk reusable design behavior kecuali dynamic value yang tervalidasi.

---

# 88. Utility Classes

Utilities harus kecil, documented, dan tidak menggantikan component architecture secara berlebihan.

---

# 89. CSS Custom Properties

Design tokens harus diekspos melalui custom properties.

---

# 90. JavaScript Architecture

JavaScript harus:

- modular;
- scoped;
- progressively enhanced;
- event-driven where appropriate;
- bebas global mutation;
- accessible;
- resilient terhadap partial failure.

---

# 91. Frontend Module Boundary

Setiap module harus memiliki namespace dan lifecycle untuk scripts.

---

# 92. Event Handling

Gunakan event delegation secara hati-hati dan hindari duplicate listeners.

---

# 93. DOM Contracts

Selectors harus stable dan tidak bergantung pada visual text.

---

# 94. Data Attributes

Gunakan `data-*` untuk behavior hooks yang terdokumentasi.

---

# 95. Frontend State

State categories:

```text
SERVER_STATE
URL_STATE
FORM_STATE
SESSION_UI_STATE
PERSISTED_PREFERENCE
EPHEMERAL_STATE
```

---

# 96. State Ownership

Setiap state harus memiliki owner dan source of truth.

---

# 97. URL State

Cocok untuk:

- pagination;
- sorting;
- filtering;
- tab;
- workspace.

Hindari sensitive data.

---

# 98. Server State

Server state harus direfresh/invalidate setelah mutation.

---

# 99. Optimistic UI

Gunakan hanya jika rollback jelas dan operation aman.

---

# 100. Concurrency

UI harus menangani:

- stale version;
- optimistic locking conflict;
- duplicate submit;
- concurrent edit;
- expired session.

---

# 101. Idempotent Submit

Gunakan idempotency token untuk critical repeated submissions jika tersedia.

---

# 102. Accessibility

Target minimum:

- keyboard accessible;
- focus visible;
- semantic HTML;
- labels;
- landmarks;
- error association;
- reduced motion;
- contrast;
- zoom/responsive.

---

# 103. Semantic HTML

Gunakan elemen semantic sebelum ARIA.

---

# 104. ARIA

ARIA digunakan untuk melengkapi semantic behavior, bukan mengganti HTML yang benar.

---

# 105. Focus Management

Modal, drawer, validation, dan route changes harus memiliki focus management.

---

# 106. Keyboard Navigation

Interactive composite components harus memiliki keyboard contract.

---

# 107. Screen Reader

Critical journeys harus diuji dengan screen reader.

---

# 108. Reduced Motion

Respect:

```css
@media (prefers-reduced-motion: reduce)
```

---

# 109. Localization

UI harus mendukung translation keys dan locale formatting.

---

# 110. RTL Readiness

Layout/component yang relevant sebaiknya tidak bergantung pada left/right hard-coded semantics.

---

# 111. Date and Time

Display menggunakan user locale dan timezone, tetapi server stores canonical time.

---

# 112. Numbers and Currency

Gunakan locale-aware formatting.

---

# 113. Content Length

Component harus tahan terhadap translation expansion.

---

# 114. Frontend Security

Controls:

- output encoding;
- safe DOM APIs;
- CSP compatibility;
- CSRF protection;
- trusted URLs;
- no raw secret exposure;
- file preview safety;
- clickjacking controls;
- secure external links.

---

# 115. XSS Prevention

Hindari `innerHTML` dengan untrusted content.

---

# 116. CSRF

State-changing browser requests harus menggunakan approved CSRF mechanism.

---

# 117. Sensitive Data

Jangan simpan sensitive data di:

- localStorage;
- URL query;
- DOM attributes;
- client logs;
- analytics events.

---

# 118. External Links

External links harus menggunakan safe target and rel policy.

---

# 119. File Preview

Preview file harus mengikuti content security dan sandbox policy.

---

# 120. Performance

UI performance targets mencakup:

```text
Initial Load
Interaction Latency
Layout Stability
Bundle/Asset Size
Network Requests
Large Table Rendering
Memory Usage
```

---

# 121. Asset Strategy

Assets harus:

- versioned;
- cacheable;
- compressed;
- integrity-aware;
- avoid unnecessary duplication.

---

# 122. CSS Budget

Tetapkan budget untuk master CSS dan module additions.

---

# 123. JavaScript Budget

Module scripts harus memiliki size/performance budget.

---

# 124. Lazy Loading

Gunakan untuk non-critical assets dan module UI.

---

# 125. Image Optimization

Gunakan format, dimension, dan lazy load yang sesuai.

---

# 126. Rendering Strategy

Supported:

```text
SERVER_RENDERED
PROGRESSIVELY_ENHANCED
PARTIAL_UPDATE
CLIENT_RENDERED_APPROVED
```

---

# 127. Server-Rendered Baseline

Critical workflows sebaiknya tetap functional tanpa heavy client runtime bila memungkinkan.

---

# 128. Error Recovery

Frontend harus dapat recovery dari failed partial requests.

---

# 129. Offline Behavior

Tidak dijamin kecuali capability tertentu mendefinisikan offline policy.

---

# 130. Observability

Frontend dapat mengirim:

- route/view;
- interaction errors;
- performance metrics;
- failed requests;
- correlation ID;
- feature/module context.

---

# 131. Privacy in Telemetry

Tidak boleh mengirim PII/PHI tanpa approved purpose.

---

# 132. UI Audit

Audit untuk sensitive UI action tetap dilakukan server-side.

---

# 133. Component Testing

Setiap component penting membutuhkan:

- rendering test;
- state test;
- accessibility test;
- keyboard test;
- responsive test;
- theme test.

---

# 134. Visual Regression

Recommended untuk:

- shell;
- forms;
- tables;
- modal;
- navigation;
- responsive breakpoints;
- light/dark themes.

---

# 135. Browser Matrix

Harus didefinisikan sesuai supported browser policy.

---

# 136. UAT UI

UAT mencakup:

- navigation;
- forms;
- workflow;
- responsive;
- accessibility;
- errors;
- loading;
- role/scope visibility;
- theme;
- tenant branding.

---

# 137. Design Review

New pattern/component requires design system review.

---

# 138. Component Proposal

Minimum:

```text
component_code
problem
use_cases
variants
states
accessibility
responsive behavior
tokens
owner
alternatives
```

---

# 139. Component Approval

Review:

- necessity;
- duplication;
- semantics;
- accessibility;
- performance;
- security;
- maintainability;
- module reuse.

---

# 140. Deprecation

Deprecated component harus memiliki replacement dan migration guide.

---

# 141. UI Governance Roles

```text
UI_ARCHITECT
DESIGN_SYSTEM_OWNER
ACCESSIBILITY_OWNER
FRONTEND_OWNER
MODULE_UI_OWNER
SECURITY_REVIEWER
QA_OWNER
```

---

# 142. Metrics

```text
ui_component_total
ui_component_deprecated_total
ui_accessibility_failure_total
ui_visual_regression_total
ui_bundle_size_bytes
ui_css_size_bytes
ui_interaction_error_total
ui_render_duration_seconds
ui_theme_failure_total
ui_broken_route_total
```

---

# 143. KPIs

```text
Approved components with accessibility tests = 100%
Critical pages responsive = 100%
Inline reusable styles trend = 0
Broken menu/route links = 0
Critical UI actions without server authorization = 0
Tenant themes violating contrast = 0
Deprecated component usage declines
```

---

# 144. KRIs

```text
CSS size growth
Component duplication
Accessibility regression
Bundle growth
Theme override count
Broken responsive layouts
Client-side security findings
Unowned components
```

---

# 145. Database Direction

Potential tables/configuration:

```text
ui_theme_definitions
ui_tenant_branding
ui_user_preferences
ui_component_registry
ui_component_versions
ui_extension_points
ui_module_contributions
ui_visual_test_baselines
ui_reconciliation_runs
ui_reconciliation_findings
```

---

# 146. Table: ui_theme_definitions

```sql
CREATE TABLE ui_theme_definitions (
    id CHAR(26) NOT NULL,
    theme_code VARCHAR(100) NOT NULL,
    name VARCHAR(255) NOT NULL,
    theme_type VARCHAR(40) NOT NULL,
    token_document_json JSON NOT NULL,
    checksum_sha256 CHAR(64) NOT NULL,
    status VARCHAR(30) NOT NULL,
    current_version VARCHAR(100) NOT NULL,
    created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),

    PRIMARY KEY (id),
    UNIQUE KEY uq_ui_theme_code (theme_code),
    KEY idx_ui_theme_status (
        status,
        theme_type
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

# 147. Table: ui_tenant_branding

```sql
CREATE TABLE ui_tenant_branding (
    id CHAR(26) NOT NULL,
    tenant_id CHAR(26) NOT NULL,
    theme_code VARCHAR(100) NOT NULL,
    branding_tokens_json JSON NOT NULL,
    logo_file_id CHAR(26) NULL,
    status VARCHAR(30) NOT NULL,
    approved_by VARCHAR(180) NULL,
    updated_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),

    PRIMARY KEY (id),
    UNIQUE KEY uq_ui_tenant_branding (
        tenant_id
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

# 148. Table: ui_user_preferences

```sql
CREATE TABLE ui_user_preferences (
    id CHAR(26) NOT NULL,
    user_id CHAR(26) NOT NULL,
    tenant_id CHAR(26) NOT NULL,
    theme_preference VARCHAR(30) NULL,
    density_preference VARCHAR(30) NULL,
    navigation_state_json JSON NULL,
    locale_code VARCHAR(30) NULL,
    updated_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),

    PRIMARY KEY (id),
    UNIQUE KEY uq_ui_user_preference (
        user_id,
        tenant_id
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

# 149. Table: ui_component_registry

```sql
CREATE TABLE ui_component_registry (
    id CHAR(26) NOT NULL,
    component_code VARCHAR(180) NOT NULL,
    name VARCHAR(255) NOT NULL,
    owner_reference VARCHAR(180) NOT NULL,
    status VARCHAR(30) NOT NULL,
    current_version VARCHAR(100) NOT NULL,
    accessibility_status VARCHAR(30) NOT NULL,
    metadata_json JSON NOT NULL,
    created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),

    PRIMARY KEY (id),
    UNIQUE KEY uq_ui_component_code (
        component_code
    ),
    KEY idx_ui_component_status (
        status,
        accessibility_status
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

# 150. API Direction

```text
GET  /api/internal/v1/ui/themes
GET  /api/internal/v1/ui/themes/{themeCode}
POST /api/internal/v1/ui/themes
POST /api/internal/v1/ui/themes/{themeCode}/publish
GET  /api/internal/v1/ui/branding/{tenantId}
PATCH /api/internal/v1/ui/branding/{tenantId}
GET  /api/internal/v1/ui/preferences
PATCH /api/internal/v1/ui/preferences
GET  /api/internal/v1/ui/components
POST /api/internal/v1/ui/reconcile
```

---

# 151. SDK Contracts

Potential contracts:

```text
ThemeRegistryInterface
DesignTokenProviderInterface
TenantBrandingServiceInterface
UiPreferenceServiceInterface
UiComponentRegistryInterface
UiExtensionPointRegistryInterface
UiContributionValidatorInterface
UiReconciliationServiceInterface
```

---

# 152. Theme Provider Contract

```php
interface DesignTokenProviderInterface
{
    public function resolve(
        UiThemeContext $context
    ): DesignTokenSet;
}
```

---

# 153. Component Registry Contract

```php
interface UiComponentRegistryInterface
{
    public function find(string $componentCode): ?UiComponentDefinition;

    public function requireActive(string $componentCode): UiComponentDefinition;
}
```

---

# 154. Error Codes

```text
UI_THEME_NOT_FOUND
UI_THEME_INVALID
UI_THEME_CONTRAST_FAILED
UI_BRANDING_OVERRIDE_FORBIDDEN
UI_COMPONENT_NOT_FOUND
UI_COMPONENT_DEPRECATED
UI_EXTENSION_POINT_INVALID
UI_CONTRIBUTION_INVALID
UI_ROUTE_BINDING_INVALID
UI_PERMISSION_PROJECTION_INVALID
UI_ACCESSIBILITY_VALIDATION_FAILED
UI_RECONCILIATION_FAILED
```

---

# 155. Token Checklist

- [ ] Semantic names used.
- [ ] No unnecessary hard-coded values.
- [ ] Light theme defined.
- [ ] Dark theme defined.
- [ ] Contrast validated.
- [ ] Focus token defined.
- [ ] Danger semantics protected.
- [ ] Reduced motion supported.
- [ ] Tenant override boundaries defined.
- [ ] Token version documented.

---

# 156. Component Checklist

- [ ] Problem/use case defined.
- [ ] Component code unique.
- [ ] Owner assigned.
- [ ] Variants defined.
- [ ] States defined.
- [ ] Responsive behavior defined.
- [ ] Keyboard behavior defined.
- [ ] Screen-reader semantics defined.
- [ ] Security reviewed.
- [ ] Tests provided.
- [ ] Documentation provided.

---

# 157. Page Checklist

- [ ] Uses app shell.
- [ ] Uses canonical layout.
- [ ] Responsive.
- [ ] Accessible title and landmarks.
- [ ] Loading state.
- [ ] Empty state.
- [ ] Error state.
- [ ] Permission projection correct.
- [ ] Server authorization present.
- [ ] Route canonical.
- [ ] Mobile behavior verified.
- [ ] Theme compatibility verified.

---

# 158. UAT — Tokens & Themes

- [ ] Light theme renders.
- [ ] Dark theme renders.
- [ ] System preference works.
- [ ] Tenant branding applies approved tokens.
- [ ] Invalid contrast rejected.
- [ ] Protected danger token cannot be overridden.
- [ ] Theme persists per user.
- [ ] No flash of incorrect theme where supported.
- [ ] Reduced motion respected.

---

# 159. UAT — Layout & Responsive

- [ ] Desktop shell works.
- [ ] Tablet shell works.
- [ ] Mobile navigation works.
- [ ] Sidebar modes work.
- [ ] Table responsive strategy works.
- [ ] Form remains usable at narrow widths.
- [ ] Content does not overflow unexpectedly.
- [ ] Touch targets adequate.
- [ ] Zoom does not break critical flow.

---

# 160. UAT — Components

- [ ] Button variants work.
- [ ] Disabled/loading states work.
- [ ] Form errors accessible.
- [ ] Modal focus trap works.
- [ ] Drawer keyboard handling works.
- [ ] Tabs keyboard behavior works.
- [ ] Toast not sole critical error.
- [ ] Data table sorting/filtering works.
- [ ] Bulk action confirmation works.
- [ ] Empty/loading/error states render.

---

# 161. UAT — Authorization & Navigation

- [ ] Menu follows projection.
- [ ] Hidden action does not expose endpoint.
- [ ] Direct URL denied without permission.
- [ ] Wrong scope denied.
- [ ] Disabled state follows policy.
- [ ] Breadcrumb resolves.
- [ ] Deep link safe.
- [ ] Inactive module hides contribution.
- [ ] Route change does not break canonical links.

---

# 162. UAT — Accessibility

- [ ] Keyboard-only critical journey passes.
- [ ] Focus visible.
- [ ] Modal focus restored.
- [ ] Labels associated.
- [ ] Errors announced.
- [ ] Screen-reader navigation works.
- [ ] Color not sole indicator.
- [ ] Reduced motion works.
- [ ] Contrast tests pass.

---

# 163. UAT — Security

- [ ] Untrusted HTML escaped.
- [ ] Unsafe URL rejected.
- [ ] CSRF protected.
- [ ] Sensitive data absent from URL.
- [ ] Sensitive data absent from local storage.
- [ ] External links safe.
- [ ] Arbitrary CSS/JS injection blocked.
- [ ] Tenant branding sanitized.
- [ ] File preview sandboxed where required.

---

# 164. UAT — Performance

- [ ] CSS budget measured.
- [ ] JavaScript budget measured.
- [ ] Initial render baseline measured.
- [ ] Large table performance measured.
- [ ] Lazy loading works.
- [ ] Asset cache works.
- [ ] Theme resolution fast.
- [ ] No major layout shift on shell.
- [ ] Memory does not grow on navigation loops.

---

# 165. UAT — Module UI Contribution

- [ ] Valid contribution registers.
- [ ] Invalid extension point rejected.
- [ ] Unauthorized component rejected.
- [ ] Inactive module contribution hidden.
- [ ] Namespace collision rejected.
- [ ] Contribution uses approved tokens.
- [ ] Contribution passes accessibility.
- [ ] Contribution respects responsive layout.
- [ ] Contribution lifecycle follows module state.

---

# 166. Definition of Done — SSOT-UI-01

SSOT-UI-01 dianggap selesai bila:

- [ ] UI architecture layers tersedia;
- [ ] design token system tersedia;
- [ ] color/typography/spacing/radius/elevation tersedia;
- [ ] theme engine tersedia;
- [ ] tenant branding guardrails tersedia;
- [ ] layout and responsive system tersedia;
- [ ] primitive/composite components tersedia;
- [ ] form/table/navigation patterns tersedia;
- [ ] loading/empty/error states tersedia;
- [ ] authorization projection rules tersedia;
- [ ] module UI contribution tersedia;
- [ ] CSS architecture tersedia;
- [ ] JavaScript architecture tersedia;
- [ ] frontend state model tersedia;
- [ ] accessibility tersedia;
- [ ] localization tersedia;
- [ ] frontend security tersedia;
- [ ] performance governance tersedia;
- [ ] testing/visual regression tersedia;
- [ ] component lifecycle/governance tersedia;
- [ ] metrics/KPI/KRI tersedia;
- [ ] database direction tersedia;
- [ ] API direction tersedia;
- [ ] SDK contracts tersedia;
- [ ] UAT and DoD tersedia.

---

# 167. Implementation Roadmap

## Phase 1 — Foundations

- design token definitions;
- master CSS normalization;
- typography;
- color semantics;
- spacing;
- responsive breakpoints;
- base shell.

## Phase 2 — Core Components

- buttons;
- forms;
- cards;
- alerts;
- modal/drawer;
- tables;
- pagination;
- navigation components.

## Phase 3 — Themes & Module Contracts

- light/dark/system themes;
- tenant branding;
- component registry;
- UI extension points;
- module contribution validation;
- documentation site.

## Phase 4 — Quality & Accessibility

- accessibility test suite;
- visual regression;
- browser matrix;
- performance budgets;
- component certification;
- UI reconciliation.

## Phase 5 — Distributed UI

- token package distribution;
- microfrontend contracts;
- remote module UI;
- versioned component packages;
- multi-platform design tokens;
- advanced personalization.

---

# 168. Initial Implementation Backlog

```text
UI-001 Design Token Catalog
UI-002 Theme Engine
UI-003 App Shell
UI-004 Responsive Layout Grid
UI-005 Core Form Components
UI-006 Data Table
UI-007 Modal & Drawer
UI-008 Navigation Components
UI-009 Status & Feedback Components
UI-010 Component Registry
UI-011 UI Extension Point Registry
UI-012 Tenant Branding Service
UI-013 Accessibility Test Suite
UI-014 Visual Regression Suite
UI-015 UI Performance Budgets
UI-016 Design System Documentation
```

---

# 169. Approval Gate

Dokumen dapat menjadi Approved setelah:

- Platform Architecture review;
- UI/UX Architecture review;
- Accessibility review;
- Security review;
- RBAC/Menu/Route integration review;
- Module SDK review;
- Frontend Engineering review;
- Quality Engineering review;
- Multi-tenant branding review;
- UAT review.

---

# 170. Closing Statement

Enterprise UI architecture harus memastikan seluruh pengalaman pengguna:

- konsisten;
- responsive;
- accessible;
- secure;
- themeable;
- module-friendly;
- measurable;
- maintainable.

UI menampilkan capability.

UI tidak memberikan authorization.

Setiap component, theme, navigation, dan module contribution harus mengikuti contract resmi Platform Kernel.
