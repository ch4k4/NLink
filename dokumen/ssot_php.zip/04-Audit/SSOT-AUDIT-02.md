# SSOT-AUDIT-02 --- Audit Database

> Enterprise Platform Kernel Blueprint

## 1. Status Dokumen

-   Kode: SSOT-AUDIT-02
-   Domain: Platform Kernel
-   Bergantung pada: SSOT-AUDIT-01

## 2. Tujuan

Dokumen ini menjadi Single Source of Truth desain database audit untuk
seluruh platform.

## 3. Prinsip

-   Append-only
-   Immutable
-   Scope-aware
-   Correlation-aware
-   Privacy-aware
-   Tamper-evident

## 4. Database Architecture

Pisahkan audit header, detail perubahan, log keamanan, log akses data,
log ekspor, dan log break-glass agar query operasional tetap cepat.

## 5. Event Storage Strategy

-   Header + detail
-   Snapshot JSON
-   Hash chain
-   UTC timestamp

## 6. Audit Event Lifecycle

Request → Validation → Business Action → Audit Header → Audit Detail →
Archive → Retention.

## 7. audit_events

Header seluruh event.

Kolom minimum:

``` text
id
event_uuid
event_type
event_category
event_severity
actor_user_id
tenant_id
organization_id
business_entity_id
scope_snapshot(JSON)
resource_type
resource_id
action
result
correlation_id
request_id
created_at
```

## 8. audit_event_details

Menyimpan perubahan field.

``` text
audit_event_id
field_name
old_value
new_value
value_type
```

## 9. audit_event_tags

Tag tambahan seperti: - hipaa - pii - phi - billing - security - export

## 10. audit_subjects

Snapshot subjek audit (mis. pasien, user, invoice).

## 11. audit_actors

Snapshot actor saat event terjadi.

## 12. audit_resources

Snapshot resource agar perubahan nama/resource di masa depan tidak
menghilangkan konteks.

## 13. security_events

Login gagal, brute force, lockout, API abuse, suspicious activity.

## 14. authentication_events

Login, logout, MFA, password reset.

## 15. authorization_events

Access granted, denied, permission override.

## 16. scope_events

Resolve scope, switch scope, cross-scope, break-glass.

## 17. rbac_events

Role assignment, revoke, permission update.

## 18. clinical_events

EMR, encounter, medication, clinical document.

## 19. integration_events

Webhook, API, queue, retry.

## 20. export_logs

Format, filter, row_count, requester, approver.

## 21. print_logs

Print event beserta alasan.

## 22. download_logs

Download file sensitif.

## 23. data_access_logs

Log baca PHI/PII.

## 24. break_glass_logs

Semua aktivitas emergency access.

## 25. permission_override_logs

Override permission sementara.

## 26. cross_scope_logs

Akses lintas scope.

## 27. audit_hash_chain

Menyimpan event_hash dan previous_event_hash.

## 28. audit_retention_policy

Retention berdasarkan kategori, tenant, dan regulasi.

## 29. legal_hold

Mencegah penghapusan saat investigasi.

## 30. audit_archive_jobs

Arsip otomatis berdasarkan retention.

## 31. Foreign Key Strategy

FK digunakan untuk referensi aktif; snapshot tetap disimpan agar histori
tidak hilang.

## 32. Index Strategy

Index: - created_at - actor_user_id - tenant_id - business_entity_id -
event_type - correlation_id - resource_type + resource_id

## 33. Partition Strategy

Partition bulanan untuk audit_events dan data_access_logs.

## 34. Compression Strategy

Arsip lama dikompresi pada storage sekunder.

## 35. JSON Columns

scope_snapshot, actor_snapshot, resource_snapshot.

## 36. Snapshot Strategy

Snapshot tidak boleh diubah setelah event dibuat.

## 37. Old/New Value Storage

Gunakan field-level diff.

## 38. PII/PHI Masking

PII/PHI dimasking atau di-redact.

## 39. Correlation ID

Wajib untuk semua event.

## 40. Request ID

Wajib untuk setiap request HTTP/API.

## 41. Queue Integration

Event non-kritis boleh asynchronous dengan queue andal.

## 42. Performance Guideline

Pisahkan header/detail, gunakan batch insert dan index yang sesuai.

## 43. Migration Sequence

1.  audit_events
2.  audit_event_details
3.  security_events
4.  authentication_events
5.  authorization_events
6.  scope_events
7.  rbac_events
8.  clinical_events
9.  integration_events
10. export_logs
11. print_logs
12. download_logs
13. data_access_logs
14. break_glass_logs
15. permission_override_logs
16. cross_scope_logs
17. audit_hash_chain
18. audit_retention_policy
19. legal_hold
20. audit_archive_jobs

## 44. Seed Data

Seed kategori event, severity, dan retention policy default.

## 45. Data Integrity Rules

-   Tidak ada UPDATE/DELETE audit event.
-   Semua event memiliki UTC timestamp.
-   Correlation ID wajib.
-   Scope snapshot wajib untuk transaksi.

## 46. UAT

-   Login menghasilkan authentication event.
-   Update menghasilkan detail perubahan.
-   Export menghasilkan export_log.
-   Break-glass menghasilkan break_glass_log.

## 47. Monitoring

Pantau volume event, queue backlog, dan kegagalan audit.

## 48. Backup

Audit dibackup terpisah dari database transaksi.

## 49. Disaster Recovery

Audit dapat dipulihkan tanpa mengubah integritas hash chain.

## 50. Definition of Done

-   Seluruh tabel audit tersedia.
-   Mendukung miliaran event.
-   Mendukung retention dan archive.
-   Mendukung compliance.
-   Mendukung forensic investigation.
