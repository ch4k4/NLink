# SSOT-AUDIT-03 --- Audit Logger & Implementation

## Status

-   Kode: SSOT-AUDIT-03
-   Domain: Platform Kernel
-   Bergantung pada: SSOT-AUDIT-01, SSOT-AUDIT-02, Scope, RBAC

------------------------------------------------------------------------

# 1. Tujuan

Menyediakan implementasi standar Audit Trail yang digunakan oleh seluruh
modul platform sehingga developer tidak membuat mekanisme audit
sendiri-sendiri.

------------------------------------------------------------------------

# 2. Arsitektur

``` text
HTTP/API
→ CorrelationIdMiddleware
→ Authentication
→ ScopeMiddleware
→ PermissionMiddleware
→ Business Service
→ Audit Event Builder
→ Audit Logger
→ Queue (opsional)
→ Audit Repository
→ Audit Database
```

------------------------------------------------------------------------

# 3. Komponen

``` text
AuditLogger
AuditEventBuilder
AuditRepository
AuditMiddleware
CorrelationIdMiddleware
SecurityAuditLogger
DataAccessLogger
AuditQueuePublisher
AuditRetentionJob
AuditIntegrityVerifier
```

------------------------------------------------------------------------

# 4. AuditLogger Interface

``` php
interface AuditLoggerInterface
{
    public function log(AuditEvent $event): void;
}
```

------------------------------------------------------------------------

# 5. AuditEvent

Minimal berisi:

``` text
event_type
event_category
severity
actor
scope_snapshot
resource
action
result
reason
correlation_id
request_id
created_at
```

------------------------------------------------------------------------

# 6. Correlation ID

Jika request belum memiliki Correlation ID maka middleware membuat UUID
baru.

Correlation ID harus diteruskan ke: - HTTP response - queue message -
webhook - integration event

------------------------------------------------------------------------

# 7. Automatic Audit

Audit otomatis untuk:

-   login/logout
-   CRUD master
-   CRUD transaksi
-   role assignment
-   permission change
-   scope switch
-   export
-   download
-   print

------------------------------------------------------------------------

# 8. Manual Audit

Business service boleh membuat audit khusus.

Contoh:

``` php
$audit->log($event);
```

------------------------------------------------------------------------

# 9. CRUD Diff Engine

Update menghasilkan diff field.

``` text
status
draft -> signed

address
(redacted) -> (redacted)
```

Hanya field yang berubah yang disimpan.

------------------------------------------------------------------------

# 10. Queue Strategy

Synchronous: - login - access denied - EMR sign - break glass -
permission change

Asynchronous: - read access - reporting - navigation - integration
telemetry

------------------------------------------------------------------------

# 11. Repository Pattern

``` php
AuditRepositoryInterface
```

Method minimum:

-   saveHeader()
-   saveDetails()
-   saveSecurityEvent()
-   saveAccessLog()

------------------------------------------------------------------------

# 12. Error Handling

Jika audit gagal:

Kritis: - batalkan transaksi.

Non-kritis: - simpan ke fallback queue/log.

------------------------------------------------------------------------

# 13. Data Access Audit

Setiap akses PHI/PII:

``` text
who
when
resource
reason
scope
```

------------------------------------------------------------------------

# 14. Break Glass

Semua event diberi:

``` text
is_break_glass=true
```

dan wajib direview.

------------------------------------------------------------------------

# 15. Export Audit

Catat:

-   format
-   filter
-   row_count
-   requester
-   approver
-   hash file

------------------------------------------------------------------------

# 16. Integration Audit

Catat:

-   endpoint
-   method
-   duration
-   status
-   payload_hash

------------------------------------------------------------------------

# 17. Performance

-   Batch insert
-   Async queue
-   Monthly partition
-   Separate header/detail

------------------------------------------------------------------------

# 18. Integrity Verification

AuditIntegrityVerifier menghitung ulang hash chain.

Jika gagal:

``` text
audit.integrity.failed
```

------------------------------------------------------------------------

# 19. UAT

-   Login menghasilkan audit.
-   Scope switch menghasilkan audit.
-   Access denied menghasilkan security event.
-   Update menghasilkan field diff.
-   Export menghasilkan export log.
-   Break glass menghasilkan event khusus.

------------------------------------------------------------------------

# 20. Definition of Done

-   Audit SDK tersedia.
-   Middleware aktif.
-   Correlation ID otomatis.
-   CRUD audit otomatis.
-   Diff engine berjalan.
-   Queue didukung.
-   Hash verification tersedia.
-   Semua modul memakai AuditLogger yang sama.
