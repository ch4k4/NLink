# SSOT-AUDIT-01 — Audit Trail Architecture

## Status Dokumen

| Item | Nilai |
|---|---|
| Kode Dokumen | SSOT-AUDIT-01 |
| Nama | Audit Trail Architecture |
| Versi | 1.0 |
| Status | Draft Architecture |
| Domain | Platform Kernel |
| Berlaku Untuk | Multi-tenant, multi-organization, multi-business entity, healthcare, non-healthcare |
| Dependensi | SSOT-SCOPE-01 s.d. SSOT-SCOPE-04, SSOT-RBAC-01 s.d. SSOT-RBAC-03, SSOT-MENU-01 |

---

# 1. Tujuan

Audit Trail adalah mekanisme platform untuk mencatat seluruh aktivitas penting yang dilakukan oleh:

- user manusia;
- service account;
- background job;
- sistem integrasi;
- API client;
- administrator;
- emergency access / break-glass session.

Audit Trail harus dapat menjawab pertanyaan berikut:

1. Siapa melakukan apa?
2. Kapan dilakukan?
3. Dari scope mana aktivitas dilakukan?
4. Resource apa yang terdampak?
5. Data apa yang berubah?
6. Apakah aktivitas berhasil atau gagal?
7. Apakah aktivitas dilakukan dengan permission normal, override, cross-scope, atau break-glass?
8. Apakah aktivitas dapat ditelusuri kembali untuk audit internal, legal, compliance, dan forensik?

---

# 2. Posisi Audit Trail dalam Arsitektur Platform

Audit Trail berjalan setelah proses utama berikut:

```text
Auth
→ Scope Resolver
→ Scope Guard
→ RBAC
→ Business Rule
→ Action Execution
→ Audit Trail
```

Namun untuk event keamanan tertentu, audit juga dapat terjadi sebelum action selesai.

Contoh:

```text
Request masuk
→ Auth gagal
→ Security Audit Event dicatat
→ Response 401
```

Audit Trail tidak menggantikan:

- logging aplikasi;
- monitoring;
- error tracking;
- observability;
- backup;
- SIEM;
- database binlog.

Audit Trail fokus pada **jejak aktivitas bermakna secara bisnis, keamanan, klinis, dan kepatuhan**.

---

# 3. Prinsip Dasar

## 3.1 Append-only

Audit event bersifat append-only.

Tidak boleh:

```text
UPDATE audit_events
DELETE FROM audit_events
```

Koreksi audit dilakukan dengan event baru.

Contoh:

```text
audit_event_created
audit_event_correction_recorded
```

## 3.2 Immutable by Application

Aplikasi biasa tidak boleh menyediakan fitur edit/hapus audit.

Administrator aplikasi tidak otomatis boleh mengubah audit.

## 3.3 Scope-aware

Setiap audit event wajib menyimpan scope saat aktivitas terjadi.

Minimal:

```text
tenant_id
organization_id
business_entity_id
scope_snapshot
```

Jika tersedia:

```text
branch_id
division_id
department_id
service_id
team_id
workgroup_id
assignment_id
```

## 3.4 Actor-aware

Audit harus membedakan actor:

```text
human_user
service_account
system_job
api_client
integration
```

## 3.5 Resource-aware

Audit harus mencatat resource terdampak:

```text
resource_type
resource_id
resource_display
resource_owner_scope
```

## 3.6 Correlation-aware

Semua event dalam satu request/proses harus memiliki `correlation_id`.

Contoh:

```text
User klik “Simpan Pasien”
→ patient.record.update
→ audit_event_details
→ notification.sent
→ integration.message_queued
```

Semua event itu harus bisa ditelusuri dengan correlation ID yang sama.

## 3.7 Privacy-aware

Audit tidak boleh menjadi tempat membocorkan data sensitif.

Hindari menyimpan raw value untuk:

- password;
- token;
- secret;
- API key;
- OTP;
- data klinis sensitif yang tidak perlu;
- data identitas penuh bila tidak diperlukan.

Gunakan:

```text
masked_value
hashed_value
redacted
```

## 3.8 Tamper-evident

Audit sebaiknya memiliki mekanisme deteksi perubahan.

Contoh:

```text
event_hash
previous_event_hash
hash_chain
```

Ini membuat perubahan ilegal pada audit record lebih mudah dideteksi.

---

# 4. Kategori Audit Event

## 4.1 Authentication Events

Contoh:

```text
auth.login.success
auth.login.failed
auth.logout
auth.password.changed
auth.password.reset.requested
auth.password.reset.completed
auth.mfa.challenge.created
auth.mfa.challenge.failed
auth.mfa.challenge.passed
auth.account.locked
auth.account.unlocked
```

## 4.2 Session Events

```text
session.created
session.expired
session.revoked
session.concurrent_detected
session.device_changed
```

## 4.3 Scope Events

```text
scope.resolved
scope.switch.requested
scope.switched
scope.switch.denied
scope.expired
scope.denied
scope.cross_access.granted
scope.cross_access.revoked
scope.break_glass.started
scope.break_glass.expired
scope.break_glass.reviewed
```

## 4.4 RBAC Events

```text
rbac.role.created
rbac.role.updated
rbac.role.deactivated
rbac.permission.created
rbac.permission.updated
rbac.role_permission.added
rbac.role_permission.removed
rbac.user_role.assigned
rbac.user_role.revoked
rbac.permission_override.granted
rbac.permission_override.revoked
rbac.access.denied
rbac.access.allowed_sensitive
```

## 4.5 Data CRUD Events

```text
data.created
data.updated
data.deleted_soft
data.restored
data.archived
data.imported
data.merged
```

## 4.6 Healthcare Clinical Events

Untuk healthcare module:

```text
patient.record.created
patient.record.updated
patient.record.merged
patient.record.restricted
patient.record.accessed

encounter.created
encounter.updated
encounter.closed
encounter.cancelled

emr.note.created
emr.note.updated
emr.note.signed
emr.note.cosigned
emr.note.locked
emr.note.amended
emr.note.viewed

clinical_order.created
clinical_order.cancelled
clinical_result.received
medication.prescribed
medication.verified
medication.dispensed
medication.administered
```

## 4.7 Billing Events

```text
billing.invoice.created
billing.invoice.updated
billing.invoice.cancelled
billing.payment.received
billing.payment.voided
billing.refund.requested
billing.refund.approved
billing.refund.rejected
tariff.created
tariff.updated
tariff.activated
```

## 4.8 Export, Print, and Disclosure Events

```text
data.export.requested
data.export.completed
data.export.failed
data.printed
data.downloaded
medical_record.disclosed
medical_record.copy_requested
medical_record.copy_released
```

## 4.9 Integration Events

```text
integration.api.request.received
integration.api.response.sent
integration.message.sent
integration.message.failed
integration.message.retried
integration.webhook.received
integration.webhook.failed
integration.credential.rotated
```

## 4.10 System Configuration Events

```text
system.setting.updated
feature_flag.enabled
feature_flag.disabled
module.enabled
module.disabled
menu.updated
workflow.definition.updated
```

## 4.11 Security Events

```text
security.access.denied
security.suspicious_activity.detected
security.rate_limit.exceeded
security.ip_blocked
security.secret.rotated
security.api_key.created
security.api_key.revoked
security.privileged_action.performed
```

---

# 5. Audit Event Severity

Setiap event dapat diberi severity:

```text
info
low
medium
high
critical
```

Contoh:

| Event | Severity |
|---|---|
| auth.login.success | info |
| auth.login.failed | low |
| auth.account.locked | medium |
| rbac.permission_override.granted | high |
| scope.break_glass.started | critical |
| emr.note.amended | high |
| audit.log.exported | critical |

---

# 6. Struktur Audit Event

Audit event utama harus memuat:

```text
id
event_uuid
event_type
event_category
event_severity
event_source
actor_type
actor_user_id
actor_service_account_id
actor_display
tenant_id
organization_id
business_entity_id
branch_id
division_id
department_id
service_id
team_id
workgroup_id
assignment_id
scope_level
scope_snapshot
resource_type
resource_id
resource_display
action
result
deny_reason
reason
correlation_id
request_id
session_id
ip_address
user_agent
is_break_glass
is_cross_scope
is_permission_override
created_at
```

---

# 7. Scope Snapshot

`scope_snapshot` harus menyimpan keadaan scope pada saat event terjadi.

Contoh:

```json
{
  "tenant_id": 1,
  "tenant_code": "NERSLINK",
  "organization_id": 1,
  "organization_code": "ORG-NERSLINK",
  "business_entity_id": 2,
  "business_entity_code": "BE-KLINIK-001",
  "business_entity_type": "clinic",
  "industry_type": "healthcare",
  "branch_id": 2,
  "department_id": 5,
  "service_id": 2,
  "team_id": 2,
  "scope_level": "team"
}
```

Snapshot diperlukan karena struktur organisasi bisa berubah di masa depan.

Audit lama tetap harus bisa dipahami walaupun:

- nama klinik berubah;
- unit dipindahkan;
- team dibubarkan;
- cabang digabung;
- user pindah role.

---

# 8. Actor Snapshot

Selain `actor_user_id`, simpan snapshot actor.

Contoh:

```json
{
  "user_id": 12,
  "username": "nurse01",
  "display_name": "Siti Aminah",
  "active_role_codes": ["woundcare_nurse"],
  "actor_type": "human_user"
}
```

Actor snapshot membantu audit historis ketika:

- nama user berubah;
- user resign;
- role dicabut;
- akun dinonaktifkan.

---

# 9. Resource Snapshot

Untuk resource penting, simpan snapshot ringkas.

Contoh:

```json
{
  "resource_type": "patient",
  "resource_id": 103,
  "resource_display": "RM-000103",
  "owner_scope": {
    "tenant_id": 1,
    "business_entity_id": 2
  }
}
```

Jangan menyimpan seluruh data pasien/EMR di audit event utama.

Detail perubahan disimpan di `audit_event_details` dengan masking.

---

# 10. Old Value dan New Value

Untuk perubahan data, audit harus mencatat field yang berubah.

Contoh:

```json
[
  {
    "field": "address",
    "old_value": "redacted",
    "new_value": "redacted",
    "value_type": "pii"
  },
  {
    "field": "status",
    "old_value": "draft",
    "new_value": "signed",
    "value_type": "normal"
  }
]
```

Aturan:

- field biasa boleh dicatat plain;
- PII/PHI dicatat masked/redacted;
- secret tidak pernah dicatat;
- file binary tidak dicatat, hanya metadata.

---

# 11. Data Sensitivity Classification

Setiap field dapat diklasifikasikan:

```text
public
internal
confidential
restricted
secret
phi
pii
financial
credential
```

Policy audit:

| Klasifikasi | Audit Value |
|---|---|
| public | plain |
| internal | plain/summary |
| confidential | masked |
| restricted | redacted |
| secret | never log |
| phi | masked/redacted |
| pii | masked/redacted |
| financial | masked |
| credential | never log |

---

# 12. Event Source

Audit event dapat berasal dari:

```text
web
mobile
api
cli
scheduler
queue_worker
integration
system
```

Ini penting untuk forensik.

Contoh:

```text
api client membuat pasien
queue worker mengirim laporan
scheduler menjalankan archive
web user mengubah role
```

---

# 13. Result Status

Gunakan status standar:

```text
success
failed
denied
cancelled
skipped
partial
pending
```

Contoh:

```text
rbac.access.denied → denied
data.export.completed → success
integration.message.failed → failed
```

---

# 14. Correlation ID dan Request ID

## 14.1 Correlation ID

Correlation ID menghubungkan banyak event dalam satu alur bisnis.

Contoh:

```text
cor_20260703_abc123
```

## 14.2 Request ID

Request ID mengidentifikasi satu HTTP request.

Satu correlation ID bisa memiliki banyak request ID jika workflow panjang.

---

# 15. Break-Glass Audit

Break-glass adalah emergency access.

Setiap event dalam mode break-glass wajib memiliki:

```text
is_break_glass = true
break_glass_id
reason
expires_at
review_required = true
```

Event wajib:

```text
scope.break_glass.started
scope.break_glass.resource_accessed
scope.break_glass.action_performed
scope.break_glass.expired
scope.break_glass.reviewed
```

Aturan:

- alasan wajib;
- durasi terbatas;
- semua akses sensitif dicatat;
- supervisor/compliance wajib review;
- tidak boleh silent.

---

# 16. Cross-Scope Audit

Jika user mengakses data di luar scope normal, event wajib menandai:

```text
is_cross_scope = true
cross_scope_grant_id
source_scope
target_scope
reason
valid_until
```

Contoh:

```text
Supervisor Homecare melihat semua team dalam department Homecare.
```

---

# 17. Permission Override Audit

Jika akses terjadi karena override, audit harus menandai:

```text
is_permission_override = true
permission_override_id
override_effect
override_reason
override_valid_until
```

---

# 18. Audit untuk Read Access

Tidak semua read harus diaudit detail, karena bisa sangat besar.

Namun data berikut wajib dicatat saat dibaca:

- rekam medis;
- data pasien sensitif;
- audit log;
- data billing sensitif;
- data identitas;
- file legal;
- file hasil pemeriksaan;
- data yang diekspor/diunduh/dicetak.

Jenis event:

```text
data.accessed
emr.note.viewed
patient.record.viewed
audit.log.viewed
document.downloaded
```

---

# 19. Audit untuk Export dan Print

Export/print harus mencatat:

```text
export_format
filters_used
row_count
file_name
file_hash
reason
approved_by
downloaded_by
downloaded_at
```

Untuk data sensitif, export harus membutuhkan permission khusus.

Contoh permission:

```text
audit.log.export
patient.record.export
emr.record.export
billing.report.export
```

---

# 20. Audit untuk Integration/API

API audit harus mencatat:

```text
client_id
service_account_id
endpoint
method
status_code
request_hash
response_hash
correlation_id
duration_ms
ip_address
```

Jangan mencatat payload penuh jika berisi data sensitif.

Gunakan:

```text
payload_hash
payload_schema_version
payload_size
```

---

# 21. Retention dan Archiving

Audit retention harus dapat dikonfigurasi berdasarkan:

- tenant;
- business entity;
- industry;
- event category;
- severity;
- legal hold.

Contoh policy:

```text
security events: 10 tahun
clinical audit events: sesuai kebijakan rekam medis
system info events: 2 tahun
debug-level operational events: 90 hari
```

Catatan: periode final harus mengikuti regulasi dan kebijakan organisasi.

---

# 22. Legal Hold

Audit event tidak boleh dihapus/diarsipkan jika sedang terkena legal hold.

Contoh trigger:

- sengketa hukum;
- investigasi insiden;
- audit regulator;
- komplain pasien;
- fraud investigation;
- breach investigation.

---

# 23. Tamper Evidence

Untuk meningkatkan integritas:

```text
event_hash = hash(event_payload)
previous_event_hash = hash event sebelumnya
hash_algorithm = SHA-256
```

Dengan hash chain, perubahan ilegal pada audit lama dapat terdeteksi.

Minimal hash mencakup:

```text
event_uuid
event_type
actor
resource
scope_snapshot
created_at
previous_event_hash
```

---

# 24. Audit Access Control

Akses audit log sendiri harus dibatasi.

Permission minimum:

```text
audit.log.read
audit.log.export
audit.log.view_sensitive
audit.log.view_security
audit.log.view_clinical
audit.log.verify_integrity
```

Aturan:

- melihat audit log dicatat;
- export audit log dicatat;
- audit log sensitif hanya untuk role tertentu;
- auditor tidak otomatis boleh melihat isi PHI penuh;
- audit admin tidak boleh memodifikasi audit.

---

# 25. Audit Dashboard

Dashboard audit minimal menampilkan:

- event hari ini;
- failed login;
- access denied;
- break-glass active;
- permission override active;
- export data sensitif;
- perubahan role;
- perubahan scope;
- aktivitas user berisiko tinggi;
- integrity check status.

---

# 26. Search dan Filter Audit

Audit log harus bisa dicari berdasarkan:

```text
date range
event_type
event_category
severity
actor_user_id
tenant_id
business_entity_id
resource_type
resource_id
correlation_id
ip_address
result
is_break_glass
is_cross_scope
```

---

# 27. Performance Principle

Audit table akan sangat besar.

Best practice:

- index berdasarkan waktu;
- partition by month/year;
- gunakan async queue untuk event non-blocking;
- event kritis boleh synchronous;
- pisahkan audit detail dari audit header;
- hindari payload besar;
- gunakan archive storage untuk data lama.

---

# 28. Synchronous vs Asynchronous Audit

## Synchronous

Wajib untuk:

- login failed/success;
- access denied;
- role assignment;
- permission override;
- break-glass;
- EMR sign/amend;
- export sensitive data.

## Asynchronous

Boleh untuk:

- read access volume tinggi;
- integration log non-kritis;
- reporting activity;
- UI navigation event.

Namun event async tidak boleh hilang. Gunakan queue yang reliable.

---

# 29. Failure Handling

Jika audit gagal:

## Event kritis

Action harus bisa dibatalkan.

Contoh:

```text
Tidak boleh grant role jika audit event gagal dicatat.
```

## Event non-kritis

Action boleh lanjut, tetapi error audit dicatat ke fallback log.

Fallback:

```text
local file log
error log
dead letter queue
monitoring alert
```

---

# 30. Audit Event Naming Convention

Gunakan format:

```text
domain.resource.action
```

Contoh:

```text
auth.login.success
rbac.user_role.assigned
patient.record.updated
emr.note.signed
billing.refund.approved
integration.message.failed
```

---

# 31. Audit Event Taxonomy Minimum

## IAM

```text
iam.user.created
iam.user.updated
iam.user.disabled
iam.user.enabled
iam.user.deleted_soft
iam.password.reset
iam.mfa.enabled
iam.mfa.disabled
```

## Scope

```text
scope.resolved
scope.switched
scope.denied
scope.cross_access.granted
scope.break_glass.started
```

## RBAC

```text
rbac.role.created
rbac.role.updated
rbac.user_role.assigned
rbac.user_role.revoked
rbac.permission_override.granted
```

## Organization

```text
organization.created
business_entity.created
branch.created
department.created
team.created
```

## Healthcare

```text
patient.record.created
patient.record.updated
patient.record.viewed
encounter.created
encounter.closed
emr.note.created
emr.note.signed
emr.note.amended
```

## Billing

```text
billing.invoice.created
billing.payment.received
billing.refund.approved
```

## Audit

```text
audit.log.viewed
audit.log.exported
audit.integrity.checked
```

---

# 32. Modul yang Wajib Menggunakan Audit

Audit wajib diterapkan pada:

- IAM;
- Scope Engine;
- RBAC;
- Dynamic Menu configuration;
- Organization;
- Staff;
- Credentialing;
- Patient;
- Encounter;
- EMR;
- Homecare;
- Woundcare;
- Billing;
- Quality;
- Patient Safety;
- Reporting;
- Integration;
- System Settings.

---

# 33. Acceptance Criteria

Audit Trail Architecture dianggap siap bila:

- event taxonomy tersedia;
- setiap event menyimpan actor, scope, resource, result, timestamp;
- correlation ID tersedia;
- audit sensitive access tersedia;
- audit read access untuk PHI/PII tersedia;
- break-glass audit tersedia;
- cross-scope audit tersedia;
- permission override audit tersedia;
- export/print/download audit tersedia;
- audit log sendiri dilindungi permission;
- audit log tidak bisa diedit/hapus lewat UI biasa;
- ada strategi retention dan legal hold;
- ada strategi tamper evidence;
- ada strategi performance untuk volume besar.

---

# 34. Risiko Desain

## Risiko 1 — Audit terlalu sedikit

Dampak:

- sulit investigasi;
- tidak siap audit regulator;
- sulit tracing kebocoran data.

## Risiko 2 — Audit terlalu banyak tanpa klasifikasi

Dampak:

- database membengkak;
- performa turun;
- sulit mencari event penting.

## Risiko 3 — Audit menyimpan data sensitif mentah

Dampak:

- audit log menjadi sumber kebocoran baru.

## Risiko 4 — Audit asynchronous untuk event kritis

Dampak:

- aksi penting bisa terjadi tanpa jejak audit.

## Risiko 5 — Tidak ada correlation ID

Dampak:

- sulit menelusuri workflow lintas modul.

---

# 35. Kesimpulan

Audit Trail adalah lapisan kontrol setelah Scope dan RBAC.

Scope menjawab:

```text
Data mana yang boleh diakses?
```

RBAC menjawab:

```text
Aksi apa yang boleh dilakukan?
```

Audit Trail menjawab:

```text
Apa yang benar-benar terjadi, oleh siapa, kapan, dari scope mana, terhadap resource apa, dan dengan hasil apa?
```

Tanpa Audit Trail yang kuat, platform sulit dipertanggungjawabkan secara operasional, keamanan, hukum, dan compliance.
