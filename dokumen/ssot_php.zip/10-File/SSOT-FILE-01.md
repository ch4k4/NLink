
# SSOT-FILE-01 — File & Object Storage Architecture

## Status Dokumen

| Item | Nilai |
|---|---|
| Kode | SSOT-FILE-01 |
| Nama | File & Object Storage Architecture |
| Versi | 1.0 |
| Status | Draft Architecture |
| Domain | Platform Kernel / File Storage |
| Berlaku Untuk | Multi-tenant, multi-organization, multi-business entity, healthcare, non-healthcare |
| Dependensi | SSOT-SCOPE, SSOT-RBAC, SSOT-AUDIT, SSOT-DATA, SSOT-IAM, SSOT-API, SSOT-WF |

---

# 1. Tujuan

File & Object Storage Architecture mengatur standar penyimpanan, akses, keamanan, audit, lifecycle, dan integrasi file pada platform.

Jenis file yang didukung:

- dokumen legal;
- attachment workflow;
- foto woundcare;
- dokumen EMR;
- hasil lab/radiologi;
- dokumen credentialing;
- invoice/export report;
- file import;
- file integrasi;
- file non-healthcare seperti kontrak, bukti pengiriman, foto barang, dokumen purchase.

---

# 2. Prinsip Dasar

## 2.1 File metadata dipisah dari binary

Database menyimpan metadata.

Binary disimpan di storage:

```text
local filesystem
object storage
cloud storage
private storage
```

## 2.2 File harus scope-aware

Setiap file wajib memiliki scope.

Minimal:

```text
tenant_id
organization_id
business_entity_id
```

## 2.3 File harus RBAC-aware

Akses file harus lewat permission dan policy.

## 2.4 File harus audit-aware

Aksi penting wajib diaudit:

```text
upload
download
view
delete
restore
share
export
```

## 2.5 File sensitif tidak boleh public by default

Default file adalah private.

---

# 3. Storage Types

```text
local_private
local_public
s3_compatible
cloud_object_storage
archive_storage
temporary_storage
```

Rekomendasi:

- development: local private;
- production: object storage/private bucket;
- archive: cold storage.

---

# 4. File Classification

```text
public
internal
confidential
restricted
phi
pii
financial
credential
legal
```

Healthcare:

- foto luka = PHI;
- EMR attachment = PHI;
- hasil lab = PHI;
- dokumen identitas pasien = PII/PHI.

---

# 5. Access Model

Akses file harus melalui aplikasi/API.

Tidak boleh:

```text
direct public URL untuk file sensitif
```

Gunakan:

```text
signed URL
stream through application
temporary download token
```

---

# 6. Komponen

```text
file_objects
file_versions
file_access_logs
file_storage_providers
file_storage_buckets
file_scan_results
file_share_links
file_retention_policies
file_archive_jobs
```

---

# 7. Database — file_storage_providers

```sql
CREATE TABLE file_storage_providers (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,

    code VARCHAR(100) NOT NULL UNIQUE,
    name VARCHAR(150) NOT NULL,

    provider_type ENUM('local','s3','gcs','azure_blob','minio','custom') NOT NULL,

    configuration_json JSON NULL,
    credential_reference VARCHAR(255) NULL,

    status ENUM('active','inactive') NOT NULL DEFAULT 'active',

    created_at TIMESTAMP NULL,
    updated_at TIMESTAMP NULL
);
```

---

# 8. Database — file_storage_buckets

```sql
CREATE TABLE file_storage_buckets (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,

    storage_provider_id BIGINT UNSIGNED NOT NULL,

    tenant_id BIGINT UNSIGNED NULL,
    business_entity_id BIGINT UNSIGNED NULL,

    bucket_code VARCHAR(100) NOT NULL,
    bucket_name VARCHAR(150) NOT NULL,

    visibility ENUM('private','public','restricted') NOT NULL DEFAULT 'private',

    base_path VARCHAR(500) NULL,

    status ENUM('active','inactive') NOT NULL DEFAULT 'active',

    created_at TIMESTAMP NULL,
    updated_at TIMESTAMP NULL,

    UNIQUE KEY uq_bucket_code (tenant_id, business_entity_id, bucket_code),
    INDEX idx_bucket_scope (tenant_id, business_entity_id)
);
```

---

# 9. Database — file_objects

```sql
CREATE TABLE file_objects (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,

    file_uuid CHAR(36) NOT NULL UNIQUE,

    tenant_id BIGINT UNSIGNED NOT NULL,
    organization_id BIGINT UNSIGNED NULL,
    business_entity_id BIGINT UNSIGNED NULL,
    branch_id BIGINT UNSIGNED NULL,
    department_id BIGINT UNSIGNED NULL,
    service_id BIGINT UNSIGNED NULL,
    team_id BIGINT UNSIGNED NULL,

    storage_bucket_id BIGINT UNSIGNED NOT NULL,

    resource_type VARCHAR(100) NULL,
    resource_id BIGINT UNSIGNED NULL,

    file_category VARCHAR(100) NOT NULL,
    classification VARCHAR(50) NOT NULL DEFAULT 'internal',

    original_filename VARCHAR(255) NOT NULL,
    stored_filename VARCHAR(255) NOT NULL,
    storage_path VARCHAR(1000) NOT NULL,

    mime_type VARCHAR(150) NULL,
    file_extension VARCHAR(20) NULL,
    file_size_bytes BIGINT UNSIGNED NOT NULL,

    checksum_sha256 CHAR(64) NULL,

    encryption_status ENUM('none','encrypted') NOT NULL DEFAULT 'none',

    status ENUM('active','quarantined','archived','deleted') NOT NULL DEFAULT 'active',

    uploaded_by BIGINT UNSIGNED NULL,
    uploaded_at DATETIME NOT NULL,

    deleted_by BIGINT UNSIGNED NULL,
    deleted_at DATETIME NULL,
    delete_reason TEXT NULL,

    created_at TIMESTAMP NULL,
    updated_at TIMESTAMP NULL,

    INDEX idx_file_scope (tenant_id, business_entity_id),
    INDEX idx_file_resource (resource_type, resource_id),
    INDEX idx_file_status (status),
    INDEX idx_file_category (file_category),
    INDEX idx_file_checksum (checksum_sha256)
);
```

---

# 10. Database — file_versions

```sql
CREATE TABLE file_versions (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,

    file_object_id BIGINT UNSIGNED NOT NULL,

    version_number INT NOT NULL,

    storage_path VARCHAR(1000) NOT NULL,
    file_size_bytes BIGINT UNSIGNED NOT NULL,
    checksum_sha256 CHAR(64) NULL,

    uploaded_by BIGINT UNSIGNED NULL,
    uploaded_at DATETIME NOT NULL,

    change_reason TEXT NULL,

    created_at TIMESTAMP NULL,

    UNIQUE KEY uq_file_version (file_object_id, version_number),
    INDEX idx_file_version_file (file_object_id)
);
```

---

# 11. Database — file_access_logs

```sql
CREATE TABLE file_access_logs (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,

    file_object_id BIGINT UNSIGNED NOT NULL,

    actor_user_id BIGINT UNSIGNED NULL,
    actor_type VARCHAR(50) NULL,

    action ENUM('view','download','upload','delete','restore','share','archive') NOT NULL,

    result ENUM('success','denied','failed') NOT NULL,

    reason TEXT NULL,

    scope_snapshot JSON NULL,

    ip_address VARCHAR(45) NULL,
    user_agent TEXT NULL,

    correlation_id VARCHAR(100) NULL,

    created_at TIMESTAMP NULL,

    INDEX idx_file_access_file (file_object_id),
    INDEX idx_file_access_actor (actor_user_id),
    INDEX idx_file_access_created (created_at)
);
```

---

# 12. Database — file_scan_results

```sql
CREATE TABLE file_scan_results (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,

    file_object_id BIGINT UNSIGNED NOT NULL,

    scan_type VARCHAR(100) NOT NULL,
    scan_status ENUM('pending','clean','infected','failed','skipped') NOT NULL DEFAULT 'pending',

    provider VARCHAR(100) NULL,
    result_payload JSON NULL,

    scanned_at DATETIME NULL,

    created_at TIMESTAMP NULL,
    updated_at TIMESTAMP NULL,

    INDEX idx_file_scan_file (file_object_id),
    INDEX idx_file_scan_status (scan_status)
);
```

---

# 13. Database — file_share_links

```sql
CREATE TABLE file_share_links (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,

    file_object_id BIGINT UNSIGNED NOT NULL,

    token_hash VARCHAR(255) NOT NULL,

    purpose TEXT NOT NULL,

    expires_at DATETIME NOT NULL,
    max_downloads INT NULL,
    download_count INT NOT NULL DEFAULT 0,

    status ENUM('active','expired','revoked') NOT NULL DEFAULT 'active',

    created_by BIGINT UNSIGNED NULL,
    revoked_by BIGINT UNSIGNED NULL,
    revoked_at DATETIME NULL,

    created_at TIMESTAMP NULL,
    updated_at TIMESTAMP NULL,

    INDEX idx_file_share_file (file_object_id),
    INDEX idx_file_share_status (status),
    INDEX idx_file_share_expiry (expires_at)
);
```

---

# 14. Upload Flow

```text
Request upload
→ Auth
→ Scope check
→ Permission check
→ Validate file
→ Virus/malware scan if required
→ Store binary
→ Save metadata
→ Publish event file.uploaded
→ Audit file.uploaded
```

---

# 15. Download Flow

```text
Request download
→ Auth
→ Scope check
→ Permission check
→ Resource policy check
→ Audit access
→ Stream file or generate signed URL
```

---

# 16. File Validation

Validasi:

- mime type;
- extension;
- file size;
- file signature/magic bytes;
- category allowed;
- malware scan;
- duplicate checksum if needed.

Tidak cukup hanya validasi extension.

---

# 17. File Size Policy

Ukuran file ditentukan per kategori.

Contoh:

```text
avatar: 2 MB
wound_photo: 20 MB
document_pdf: 50 MB
dicom/radiology: policy khusus
import_file: 100 MB
```

---

# 18. Allowed File Types

Contoh:

```text
pdf
jpg
jpeg
png
webp
docx
xlsx
csv
txt
```

File berisiko tinggi harus dibatasi:

```text
exe
bat
sh
js
php
html
macro-enabled office
```

---

# 19. Malware Scan

File sensitif atau dari eksternal harus discan.

Jika scan belum selesai:

```text
status = quarantined
```

File quarantined tidak boleh diunduh user biasa.

---

# 20. Encryption

File sensitif harus dienkripsi at-rest.

Strategi:

```text
storage provider encryption
application-level encryption
customer-managed key
```

Key management detail dibuat di SSOT-SEC.

---

# 21. Signed URL

Signed URL:

- durasi pendek;
- hanya untuk file yang boleh diakses;
- tidak untuk file sangat sensitif kecuali policy mengizinkan;
- access tetap dicatat sebelum URL dibuat.

---

# 22. File Versioning

File yang berubah harus memiliki versi.

Contoh:

```text
SOP v1
SOP v2
credential document update
```

Untuk EMR signed document, versi lama tidak boleh hilang.

---

# 23. File Deletion

Default: soft delete metadata dan optionally move object ke deleted prefix.

Hard delete hanya setelah:

- retention habis;
- legal hold tidak aktif;
- policy mengizinkan.

---

# 24. Archive

File lama dapat dipindah ke archive storage.

Status:

```text
archived
```

Restore perlu job async bila cold storage.

---

# 25. Retention

Retention berdasarkan:

- classification;
- resource type;
- regulation;
- tenant policy;
- legal hold.

---

# 26. Legal Hold

File yang masuk legal hold tidak boleh dipurge.

Contoh:

- rekam medis dalam sengketa;
- dokumen audit;
- bukti insiden;
- komplain pasien.

---

# 27. Healthcare Rule

File healthcare sensitif:

```text
wound_photo
emr_attachment
lab_result
radiology_result
identity_document
consent_document
```

Wajib:

- private;
- scope-aware;
- access audit;
- PHI classification;
- no public URL;
- retention sesuai regulasi/kebijakan organisasi.

---

# 28. Woundcare Photo Rule

Foto luka:

- diklasifikasikan sebagai PHI;
- terkait patient/encounter/woundcare assessment;
- harus memiliki timestamp;
- harus memiliki uploader;
- tidak boleh tampil di luar scope;
- akses harus diaudit.

---

# 29. Import File Rule

File import:

- disimpan sementara;
- discan;
- divalidasi;
- diproses batch;
- hasil import diaudit;
- file dapat dipurge sesuai retention pendek.

---

# 30. Export File Rule

File export:

- harus memiliki alasan;
- dapat memiliki expiry;
- akses download diaudit;
- PHI/PII harus dimasking bila perlu;
- share link dibatasi.

---

# 31. API Integration

Endpoint standar:

```text
POST /api/v1/files
GET /api/v1/files/{id}
GET /api/v1/files/{id}/download
DELETE /api/v1/files/{id}
POST /api/v1/files/{id}/restore
POST /api/v1/files/{id}/share-link
```

---

# 32. Permission

Contoh permission:

```text
file.object.read
file.object.upload
file.object.download
file.object.delete
file.object.restore
file.object.share
file.object.archive
file.object.scan_result.read
```

Healthcare:

```text
emr.attachment.read
woundcare.photo.upload
woundcare.photo.read
patient.document.download
```

---

# 33. Audit Events

```text
file.uploaded
file.viewed
file.downloaded
file.deleted
file.restored
file.archived
file.share_link.created
file.share_link.used
file.scan.completed
file.scan.failed
file.access.denied
```

---

# 34. Event Integration

File module publish event:

```text
file.object.uploaded
file.object.deleted
file.object.archived
file.scan.completed
```

Subscriber:

- Audit;
- Notification;
- Workflow;
- Search Index;
- Integration.

---

# 35. Search Integration

File metadata dapat diindex.

Jangan index isi file sensitif tanpa policy.

---

# 36. Backup & DR

File storage harus masuk strategi backup.

Metadata database dan object storage harus konsisten.

---

# 37. Monitoring

Pantau:

- upload failure;
- storage usage;
- malware detected;
- access denied;
- download spikes;
- archive job failure;
- signed URL usage.

---

# 38. Anti-pattern

Hindari:

```text
file sensitif public
path file disusun dari input user mentah
validasi hanya extension
binary besar disimpan di database
download tanpa audit
file tanpa scope
file tanpa classification
share link tanpa expiry
foto luka dikirim melalui URL publik
```

---

# 39. UAT

## Scenario 1 — Upload File

```text
Given user punya permission upload
When upload PDF valid
Then file tersimpan
And metadata tercatat
And audit file.uploaded tercatat
```

## Scenario 2 — Lintas Scope

```text
Given file milik Klinik B
When user Klinik A akses
Then ditolak
And audit access denied tercatat
```

## Scenario 3 — Malware

```text
Given file terdeteksi malware
When upload selesai
Then status quarantined/infected
And tidak bisa didownload
```

## Scenario 4 — Share Link Expired

```text
Given share link expired
When digunakan
Then akses ditolak
```

## Scenario 5 — Foto Woundcare

```text
Given perawat upload foto luka
When file tersimpan
Then classification = phi
And resource link ke woundcare assessment
```

---

# 40. Definition of Done

File & Object Storage dianggap siap bila:

- metadata file tersedia;
- provider storage configurable;
- file scope-aware;
- file RBAC-aware;
- file audit-aware;
- upload/download flow tersedia;
- malware scan policy tersedia;
- classification tersedia;
- signed URL tersedia;
- file versioning tersedia;
- retention/archive/legal hold tersedia;
- healthcare PHI rule diterapkan;
- API endpoint standar tersedia;
- monitoring tersedia.
