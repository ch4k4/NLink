# SSOT-FILE-03 — File Retention, Versioning & Evidence Governance

## Status Dokumen

| Item | Nilai |
|---|---|
| Kode | SSOT-FILE-03 |
| Judul | File Retention, Versioning & Evidence Governance |
| Versi | 1.0 |
| Status | Draft Architecture |
| Domain | Platform Kernel |
| Kategori | File Lifecycle, Records Governance & Evidentiary Integrity |
| Cakupan | Retention, Versioning, Archival, Legal Hold, Disposal, Restore, Chain of Custody, Evidence Integrity |
| Bergantung pada | SSOT-GOV-01, SSOT-GOV-04, SSOT-GOV-05, SSOT-AUDIT-01, SSOT-DATA-06, SSOT-SEC-03, SSOT-FILE-01, SSOT-FILE-02, SSOT-OBS-01, SSOT-TEST-01 |
| Target Stack | PHP 8.1+, PDO, MySQL 8/MariaDB, Object Storage-compatible |
| Target Evolusi | WORM Storage, Immutable Archives, Evidence Vault, Automated Records Management |

# 1. Executive Summary

SSOT-FILE-03 menetapkan governance resmi untuk lifecycle file setelah file dinyatakan aman dan tersedia.

Dokumen ini mengatur:

- file retention;
- file versioning;
- document revision;
- immutable versions;
- archival;
- cold storage;
- legal hold;
- evidence preservation;
- chain of custody;
- file disposition;
- secure deletion;
- tombstones;
- restore;
- rehydration;
- backup interactions;
- derivative lifecycle;
- file lineage;
- checksum verification;
- evidentiary integrity;
- access history;
- transfer of custody;
- policy exceptions;
- reconciliation;
- metrics;
- database direction;
- API direction;
- SDK contracts;
- UAT;
- Definition of Done;
- implementation roadmap.

Tujuan akhirnya adalah memastikan setiap file:

- memiliki lifecycle;
- memiliki retention policy;
- memiliki version history;
- tidak dapat dihapus selama legal hold;
- dapat dipulihkan secara terkontrol;
- dapat dibuktikan integritasnya;
- memiliki chain of custody;
- dapat dihancurkan secara sah;
- dapat direkonsiliasi antara metadata, storage, backup, dan audit.

# 2. Objectives

Framework harus:

- menyediakan canonical file lifecycle;
- mendukung versioning;
- menjaga evidence integrity;
- mendukung legal hold;
- mendukung archival;
- mengatur disposal;
- menyediakan restore;
- menjaga derivative lineage;
- menyediakan audit;
- mendukung records management automation.

# 3. Core Principles

```text
Every File Has a Lifecycle
Retention Is Explicit
Legal Hold Overrides Disposal
Versions Are Immutable After Finalization
Evidence Must Be Verifiable
Deletion Must Be Governed
Restore Must Reapply Current Controls
Metadata and Storage Must Reconcile
Chain of Custody Must Be Preserved
No Silent Replacement of Historical Versions
```

# 4. Scope

Berlaku untuk:

```text
Uploaded Files
Clinical Documents
Generated Reports
Exports
Attachments
Evidence Files
Signed Documents
Scanned Documents
Archived Documents
File Derivatives
Backup Copies
```

# 5. Non-Scope

Dokumen ini tidak menetapkan:

- malware scanning internals;
- general database retention;
- full legal interpretation;
- document content semantics;
- external court admissibility decisions.

# 6. File Lifecycle States

```text
DRAFT
ACTIVE
SUPERSEDED
ARCHIVED
ON_HOLD
PENDING_DISPOSAL
DISPOSED
RESTORED
SUSPENDED
```

# 7. Draft File

Draft belum menjadi official record.

# 8. Active File

Active file adalah current approved or operational version.

# 9. Superseded File

Superseded file tetap disimpan sesuai retention.

# 10. Archived File

Archived file dipindahkan ke lower-cost or immutable storage.

# 11. On Hold

On-hold file tidak boleh dimodifikasi atau dihapus sesuai hold policy.

# 12. Pending Disposal

File memenuhi retention end tetapi menunggu approval or execution.

# 13. Disposed

File telah dihapus atau dibuat inaccessible sesuai approved method.

# 14. File Versioning

Every governed file can have one or more immutable versions.

# 15. Version Identity

Minimum:

```text
file_id
version_id
version_number
source_version_id
created_at
created_by
checksum
status
```

# 16. Version Numbering

Recommended:

```text
1
2
3
```

or semantic revision where business process requires.

# 17. Immutable Version

Once finalized, file bytes and canonical metadata cannot be changed in place.

# 18. New Version

Changes create a new version, not overwrite.

# 19. Current Version

One version may be designated current.

# 20. Supersession

Superseding a version must preserve:

- previous version;
- reason;
- actor;
- timestamp;
- relationship;
- current designation.

# 21. Minor Metadata Change

Non-material metadata may be updated without file version change if policy allows.

# 22. Material Metadata Change

Changes to classification, owner, resource binding, or evidentiary status should create governed revision history.

# 23. Finalization

Finalization locks file version for evidence/record purposes.

# 24. Signed Document

Signed document version must be immutable.

# 25. File Lineage

Lineage tracks:

```text
source
derived from
converted from
redacted from
watermarked from
restored from
```

# 26. Derivative Governance

Derivatives inherit:

- source classification;
- retention baseline;
- legal hold status;
- lineage;
- owner/resource binding.

# 27. Independent Retention

A derivative may have stricter retention but not weaker without approval.

# 28. Retention Policy

Minimum:

```text
policy_code
file_category
retention_trigger
duration
archive_action
disposition_action
hold_behavior
owner
```

# 29. Retention Triggers

Examples:

```text
CREATED_AT
FINALIZED_AT
CASE_CLOSED
PATIENT_DISCHARGED
CONTRACT_ENDED
LAST_ACTIVITY
SUPERSEDED_AT
```

# 30. Retention Duration

May be fixed, event-based, indefinite, or review-based.

# 31. Retention Actions

```text
KEEP_ACTIVE
ARCHIVE
MOVE_TO_COLD_STORAGE
ANONYMIZE_METADATA
DELETE
CRYPTO_ERASE
REVIEW
```

# 32. Retention Calculation

Calculation must be deterministic and versioned.

# 33. Policy Version

Every file records applicable retention policy version.

# 34. Policy Change

New policy may affect future or existing files according to approved migration rule.

# 35. Retention Extension

May occur due to:

- legal hold;
- investigation;
- contract;
- regulatory requirement;
- business exception;
- unresolved dispute.

# 36. Retention Reduction

Requires heightened approval and impact review.

# 37. Archival

Archival changes storage tier but not ownership or authorization.

# 38. Archive Preconditions

- file clean;
- checksum valid;
- metadata complete;
- retention policy known;
- legal hold status known;
- access policy retained.

# 39. Archive Storage

May use:

- cold object storage;
- immutable bucket;
- WORM storage;
- evidence vault;
- offline archive.

# 40. Archive Encryption

Encryption remains required.

# 41. Archive Access

Access is slower and may require explicit restore request.

# 42. Archive Restore

Restored copy must remain linked to archived source.

# 43. Rehydration

Rehydration creates a controlled accessible instance without changing archive integrity.

# 44. Legal Hold

Legal hold suspends normal disposal.

# 45. Hold Scope

```text
FILE
RESOURCE
CASE
SUBJECT
TENANT
DATE_RANGE
FILE_CATEGORY
```

# 46. Hold Record

Minimum:

```text
hold_code
scope
reason
authority
start_at
end_at
status
custodian
```

# 47. Hold Status

```text
DRAFT
ACTIVE
RELEASE_PENDING
RELEASED
CANCELLED
```

# 48. Hold Application

Hold must propagate to:

- current version;
- historical versions;
- derivatives;
- archived copies;
- restored copies;
- pending disposal items.

# 49. Hold Release

Release requires authority and audit.

# 50. Hold Conflict

Hold always overrides disposal.

# 51. Multiple Holds

File remains protected until all active holds are released.

# 52. Custodian

Custodian is responsible for preservation and production.

# 53. Chain of Custody

Chain of custody records:

- who handled;
- what action;
- when;
- where;
- why;
- resulting state;
- checksum before/after.

# 54. Custody Events

```text
RECEIVED
VALIDATED
SCANNED
RELEASED
ACCESSED
DOWNLOADED
COPIED
TRANSFERRED
ARCHIVED
RESTORED
EXPORTED
DISPOSED
```

# 55. Evidence Integrity

Evidence must support verification of:

- file bytes;
- metadata;
- version;
- timestamps;
- custody events;
- access history.

# 56. Checksum

Use approved cryptographic checksum.

# 57. Checksum Verification

Perform:

- at upload;
- after transformation;
- before archive;
- after restore;
- before evidence export;
- during reconciliation.

# 58. Digital Signature

Optional for high-value evidence.

# 59. Timestamping

Trusted timestamping may be used for critical evidence.

# 60. WORM Storage

Use where immutability requirement justifies it.

# 61. Evidence Package

May include:

```text
file
metadata manifest
version history
checksums
custody history
access history
signatures
timestamps
export manifest
```

# 62. Evidence Export

Must be:

- authorized;
- purpose-bound;
- encrypted;
- manifest-based;
- checksum-verifiable;
- audited.

# 63. Evidence Package ID

Every package should have unique identifier.

# 64. Evidence Verification

Recipient can verify checksum and manifest integrity.

# 65. File Access History

Sensitive/evidentiary files should retain:

- actor;
- action;
- purpose;
- timestamp;
- device/session;
- result;
- correlation ID.

# 66. Copy Governance

Copying a file creates a new governed relation.

# 67. Unauthorized Copy

Unauthorized duplication should be prevented or detected where possible.

# 68. Exported Copy

Exported copy must record recipient, expiry, protection, and purpose.

# 69. Disposal

Disposal removes file according to approved policy.

# 70. Disposal Preconditions

- retention expired;
- no active hold;
- no active investigation;
- no active dependency;
- approval complete;
- backup impact known;
- evidence recorded.

# 71. Disposal Methods

```text
LOGICAL_DELETE
PHYSICAL_DELETE
CRYPTO_ERASE
ANONYMIZE
MEDIA_DESTRUCTION
```

# 72. Secure Deletion

Deletion method must match storage technology.

# 73. Tombstone

Tombstone preserves minimum identity and disposal evidence.

# 74. Tombstone Fields

```text
file_id
disposed_at
policy
method
approved_by
checksum_reference
hold_check
```

# 75. Backup Interaction

Disposed files may remain in immutable backup until backup expiry.

# 76. Restore from Backup

Restore process must reapply tombstones and legal holds.

# 77. Disposal Verification

Must confirm object no longer accessible in active storage.

# 78. Failed Disposal

Failure creates retry and escalation.

# 79. Batch Disposal

Batch disposal requires:

- stable population;
- approval;
- dry run;
- exclusions;
- evidence;
- verification.

# 80. Disposal Exception

Requires owner, reason, expiry, and approval.

# 81. Restore

Restore recovers archived or deleted-eligible file according to policy.

# 82. Restore Preconditions

- requester authorized;
- source available;
- hold status checked;
- retention checked;
- classification known;
- destination controlled;
- checksum verification planned.

# 83. Restore Types

```text
ARCHIVE_RESTORE
BACKUP_RESTORE
VERSION_RESTORE
DISASTER_RECOVERY_RESTORE
EVIDENCE_RESTORE
```

# 84. Version Restore

Historical version may become current only through explicit action.

# 85. Restore Does Not Rewrite History

Restore creates new lifecycle event and possibly new version.

# 86. Restore Security

Restored file must:

- be rescanned where policy requires;
- be re-authorized;
- use current encryption;
- preserve original checksum;
- record source.

# 87. Disaster Recovery

DR restore must preserve:

- version history;
- legal holds;
- retention metadata;
- custody events;
- tombstones;
- checksums.

# 88. Storage Migration

Migration between providers must verify integrity before cutover.

# 89. Migration Flow

```text
Snapshot
→ Copy
→ Verify Checksum
→ Verify Metadata
→ Validate Access
→ Cutover
→ Reconcile
→ Retire Old Copy
```

# 90. Duplicate Storage Copy

Temporary duplicates during migration must have lifecycle and deletion plan.

# 91. File Ownership Transfer

Ownership change must not change evidence history.

# 92. Tenant Transfer

Cross-tenant transfer is high risk and generally requires copy/export-import with explicit governance.

# 93. Classification Change

Classification change may alter:

- storage tier;
- encryption key;
- access;
- retention;
- evidence requirements.

# 94. Retention Jobs

Must be:

- idempotent;
- restart-safe;
- tenant-aware;
- hold-aware;
- auditable;
- dry-run capable.

# 95. Archive Jobs

Must verify checksums before and after transfer.

# 96. Legal Hold Service Contract

```php
interface FileLegalHoldServiceInterface
{
    public function apply(
        FileLegalHoldRequest $request
    ): FileLegalHoldResult;

    public function release(
        FileLegalHoldReleaseRequest $request
    ): FileLegalHoldResult;
}
```

# 97. Retention Service Contract

```php
interface FileRetentionServiceInterface
{
    public function evaluate(
        FileRetentionEvaluationRequest $request
    ): FileRetentionDecision;
}
```

# 98. Versioning Service Contract

```php
interface FileVersioningServiceInterface
{
    public function createVersion(
        FileVersionRequest $request
    ): FileVersionResult;
}
```

# 99. Evidence Service Contract

```php
interface FileEvidenceServiceInterface
{
    public function createPackage(
        FileEvidencePackageRequest $request
    ): FileEvidencePackage;
}
```

# 100. Disposal Service Contract

```php
interface FileDisposalServiceInterface
{
    public function dispose(
        FileDisposalRequest $request
    ): FileDisposalResult;
}
```

# 101. File Reconciliation

Compare:

- file registry;
- versions;
- current pointer;
- storage objects;
- archives;
- legal holds;
- retention status;
- tombstones;
- backups;
- checksums.

# 102. Reconciliation Findings

```text
VERSION_MISSING
CURRENT_VERSION_INVALID
ARCHIVE_OBJECT_MISSING
CHECKSUM_MISMATCH
HOLD_NOT_PROPAGATED
DISPOSED_OBJECT_STILL_AVAILABLE
TOMBSTONE_MISSING
RESTORE_HISTORY_MISSING
DERIVATIVE_RETENTION_DRIFT
BACKUP_TOMBSTONE_DRIFT
```

# 103. Audit Events

```text
FILE_VERSION_CREATED
FILE_VERSION_FINALIZED
FILE_VERSION_SUPERSEDED
FILE_ARCHIVED
FILE_RESTORED
FILE_LEGAL_HOLD_APPLIED
FILE_LEGAL_HOLD_RELEASED
FILE_DISPOSAL_REQUESTED
FILE_DISPOSED
FILE_DISPOSAL_FAILED
FILE_EVIDENCE_PACKAGE_CREATED
FILE_CUSTODY_TRANSFERRED
FILE_RETENTION_RECONCILIATION_FAILED
```

# 104. Metrics

```text
file_version_total
file_archive_total
file_restore_total
file_legal_hold_total
file_pending_disposal_total
file_disposal_total
file_disposal_failure_total
file_checksum_failure_total
file_evidence_package_total
file_retention_reconciliation_failure_total
```

# 105. KPIs

```text
Files without retention policy = 0
Disposed files under active hold = 0
Finalized versions modified in place = 0
Checksum mismatch unresolved = 0
Archived objects without metadata = 0
Disposals without evidence = 0
Restores without custody event = 0
```

# 106. KRIs

```text
Pending disposal backlog
Long-running legal holds
Restore failure rate
Checksum failure rate
Orphan archive objects
Duplicate storage copies
Retention exceptions
Evidence export volume
```

# 107. Database Direction

Potential tables:

```text
file_versions
file_version_relationships
file_retention_policies
file_retention_evaluations
file_archival_records
file_legal_holds
file_legal_hold_bindings
file_custody_events
file_disposal_requests
file_disposal_tombstones
file_evidence_packages
file_retention_reconciliation_runs
file_retention_reconciliation_findings
```

# 108. Table: file_versions

```sql
CREATE TABLE file_versions (
    id CHAR(26) NOT NULL,
    file_id CHAR(26) NOT NULL,
    version_number INT NOT NULL,
    storage_reference VARCHAR(1000) NOT NULL,
    checksum_sha256 CHAR(64) NOT NULL,
    status VARCHAR(30) NOT NULL,
    created_by CHAR(26) NOT NULL,
    created_at DATETIME(6) NOT NULL,
    finalized_at DATETIME(6) NULL,
    superseded_at DATETIME(6) NULL,

    PRIMARY KEY (id),
    UNIQUE KEY uq_file_version_number (
        file_id,
        version_number
    ),
    KEY idx_file_version_status (
        file_id,
        status
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

# 109. Table: file_legal_holds

```sql
CREATE TABLE file_legal_holds (
    id CHAR(26) NOT NULL,
    hold_code VARCHAR(100) NOT NULL,
    hold_scope_type VARCHAR(40) NOT NULL,
    hold_scope_reference VARCHAR(255) NOT NULL,
    reason_text VARCHAR(2000) NOT NULL,
    authority_reference VARCHAR(255) NOT NULL,
    status VARCHAR(30) NOT NULL,
    start_at DATETIME(6) NOT NULL,
    end_at DATETIME(6) NULL,
    created_by CHAR(26) NOT NULL,

    PRIMARY KEY (id),
    UNIQUE KEY uq_file_legal_hold_code (
        hold_code
    ),
    KEY idx_file_legal_hold_status (
        status,
        start_at
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

# 110. Table: file_custody_events

```sql
CREATE TABLE file_custody_events (
    id CHAR(26) NOT NULL,
    file_id CHAR(26) NOT NULL,
    file_version_id CHAR(26) NULL,
    event_type VARCHAR(50) NOT NULL,
    actor_reference VARCHAR(180) NOT NULL,
    source_location VARCHAR(255) NULL,
    destination_location VARCHAR(255) NULL,
    purpose_code VARCHAR(180) NULL,
    checksum_before CHAR(64) NULL,
    checksum_after CHAR(64) NULL,
    correlation_id VARCHAR(180) NOT NULL,
    occurred_at DATETIME(6) NOT NULL,

    PRIMARY KEY (id),
    KEY idx_file_custody_file (
        file_id,
        occurred_at
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

# 111. Table: file_disposal_tombstones

```sql
CREATE TABLE file_disposal_tombstones (
    id CHAR(26) NOT NULL,
    file_id CHAR(26) NOT NULL,
    disposal_method VARCHAR(50) NOT NULL,
    retention_policy_code VARCHAR(180) NOT NULL,
    hold_check_result VARCHAR(30) NOT NULL,
    disposed_by VARCHAR(180) NOT NULL,
    approved_by VARCHAR(180) NOT NULL,
    disposed_at DATETIME(6) NOT NULL,
    evidence_reference VARCHAR(1000) NOT NULL,

    PRIMARY KEY (id),
    UNIQUE KEY uq_file_disposal_tombstone (
        file_id
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

# 112. Table: file_evidence_packages

```sql
CREATE TABLE file_evidence_packages (
    id CHAR(26) NOT NULL,
    package_code VARCHAR(100) NOT NULL,
    file_id CHAR(26) NOT NULL,
    requested_by CHAR(26) NOT NULL,
    purpose_code VARCHAR(180) NOT NULL,
    manifest_checksum_sha256 CHAR(64) NOT NULL,
    storage_reference VARCHAR(1000) NOT NULL,
    status VARCHAR(30) NOT NULL,
    expires_at DATETIME(6) NULL,
    created_at DATETIME(6) NOT NULL,

    PRIMARY KEY (id),
    UNIQUE KEY uq_file_evidence_package_code (
        package_code
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

# 113. API Direction

```text
GET  /api/internal/v1/files/{fileId}/versions
POST /api/internal/v1/files/{fileId}/versions
POST /api/internal/v1/files/{fileId}/finalize
POST /api/internal/v1/files/{fileId}/archive
POST /api/internal/v1/files/{fileId}/restore
POST /api/internal/v1/files/{fileId}/legal-holds
POST /api/internal/v1/files/{fileId}/legal-holds/{holdCode}/release
POST /api/internal/v1/files/{fileId}/dispose
POST /api/internal/v1/files/{fileId}/evidence-packages
POST /api/internal/v1/files/retention/reconcile
```

# 114. Error Codes

```text
FILE_VERSION_NOT_FOUND
FILE_VERSION_IMMUTABLE
FILE_VERSION_CONFLICT
FILE_RETENTION_POLICY_MISSING
FILE_LEGAL_HOLD_ACTIVE
FILE_ARCHIVE_FAILED
FILE_RESTORE_FAILED
FILE_DISPOSAL_BLOCKED
FILE_DISPOSAL_FAILED
FILE_CHECKSUM_MISMATCH
FILE_CUSTODY_EVIDENCE_MISSING
FILE_EVIDENCE_PACKAGE_FAILED
FILE_RETENTION_RECONCILIATION_FAILED
```

# 115. Versioning Checklist

- [ ] File identity valid.
- [ ] Current version identified.
- [ ] New bytes stored separately.
- [ ] Checksum generated.
- [ ] Source relationship recorded.
- [ ] Classification inherited.
- [ ] Retention inherited.
- [ ] Hold inherited.
- [ ] Current pointer updated.
- [ ] Audit generated.

# 116. Legal Hold Checklist

- [ ] Authority valid.
- [ ] Scope defined.
- [ ] Reason documented.
- [ ] Custodian assigned.
- [ ] Current version bound.
- [ ] Historical versions bound.
- [ ] Derivatives bound.
- [ ] Archive copies bound.
- [ ] Disposal jobs blocked.
- [ ] Audit generated.

# 117. Disposal Checklist

- [ ] Retention expired.
- [ ] No active hold.
- [ ] No active investigation.
- [ ] Dependencies checked.
- [ ] Backup impact assessed.
- [ ] Approval complete.
- [ ] Method selected.
- [ ] Object removed/inaccessible.
- [ ] Tombstone created.
- [ ] Verification complete.
- [ ] Audit generated.

# 118. UAT — Versioning

- [ ] New version created.
- [ ] Prior version preserved.
- [ ] Finalized version cannot be overwritten.
- [ ] Current pointer updates.
- [ ] Supersession reason recorded.
- [ ] Derivative lineage retained.
- [ ] Classification inherited.
- [ ] Legal hold inherited.
- [ ] Version restore creates history event.

# 119. UAT — Retention

- [ ] Correct trigger calculates expiry.
- [ ] Policy version recorded.
- [ ] Archive action executes.
- [ ] Hold blocks disposal.
- [ ] Exception extends retention.
- [ ] Reduced retention requires approval.
- [ ] Overdue retention detected.
- [ ] Dry run lists correct population.
- [ ] Job remains idempotent.

# 120. UAT — Legal Hold

- [ ] File-level hold works.
- [ ] Case-level hold propagates.
- [ ] Multiple holds coexist.
- [ ] Releasing one hold does not release others.
- [ ] Pending disposal item returns to hold state.
- [ ] Archive restore preserves hold.
- [ ] Unauthorized release denied.
- [ ] Hold history retained.
- [ ] Audit complete.

# 121. UAT — Evidence Integrity

- [ ] Upload checksum verifies.
- [ ] Archive checksum verifies.
- [ ] Restore checksum verifies.
- [ ] Tampered file detected.
- [ ] Custody chain complete.
- [ ] Evidence package manifest verifies.
- [ ] Missing custody event detected.
- [ ] Digital signature verifies where enabled.
- [ ] Export audited.

# 122. UAT — Disposal

- [ ] Eligible file disposes.
- [ ] Active hold blocks disposal.
- [ ] Missing approval blocks disposal.
- [ ] Batch dry run works.
- [ ] Physical deletion verified.
- [ ] Tombstone created.
- [ ] Failed delete retries.
- [ ] Backup tombstone reapplies after restore.
- [ ] Disposed file unavailable.

# 123. UAT — Restore

- [ ] Archive restore works.
- [ ] Historical version restore works.
- [ ] Backup restore works.
- [ ] Restored file rescanned where required.
- [ ] Current access policy reapplied.
- [ ] Current encryption applied.
- [ ] Source lineage retained.
- [ ] Hold status retained.
- [ ] Restore does not rewrite history.

# 124. UAT — Reconciliation

- [ ] Missing version object detected.
- [ ] Invalid current pointer detected.
- [ ] Archive object missing detected.
- [ ] Checksum mismatch detected.
- [ ] Hold propagation drift detected.
- [ ] Disposed object still available detected.
- [ ] Missing tombstone detected.
- [ ] Restore history missing detected.
- [ ] Derivative retention drift detected.
- [ ] Critical finding opens case.

# 125. Definition of Done — SSOT-FILE-03

SSOT-FILE-03 dianggap selesai bila:

- [ ] lifecycle states tersedia;
- [ ] version identity and immutability tersedia;
- [ ] supersession and lineage tersedia;
- [ ] retention policy model tersedia;
- [ ] archival and cold storage tersedia;
- [ ] legal hold governance tersedia;
- [ ] chain of custody tersedia;
- [ ] evidentiary integrity tersedia;
- [ ] evidence packages tersedia;
- [ ] disposal and tombstone tersedia;
- [ ] backup interaction tersedia;
- [ ] restore governance tersedia;
- [ ] storage migration tersedia;
- [ ] retention jobs tersedia;
- [ ] reconciliation tersedia;
- [ ] audit/metrics tersedia;
- [ ] database direction tersedia;
- [ ] API direction tersedia;
- [ ] SDK contracts tersedia;
- [ ] UAT and DoD tersedia.

# 126. Implementation Roadmap

## Phase 1 — Versioning & Retention Foundation

- file version registry;
- immutable versions;
- retention policy;
- current version pointer;
- lineage;
- audit events.

## Phase 2 — Archive & Hold

- archive service;
- cold storage;
- legal hold service;
- hold propagation;
- restore;
- checksum verification.

## Phase 3 — Disposal & Evidence

- disposal workflow;
- tombstones;
- evidence packages;
- custody events;
- backup tombstone integration;
- secure evidence export.

## Phase 4 — Reconciliation

- metadata/storage reconciliation;
- archive checks;
- hold drift;
- checksum drift;
- restore verification;
- disposal verification.

## Phase 5 — Advanced Records Governance

- WORM storage;
- trusted timestamping;
- digital signatures;
- evidence vault;
- automated records classification;
- compliance evidence dashboard.

# 127. Initial Implementation Backlog

```text
FILE03-001 File Version Registry
FILE03-002 Version Finalization
FILE03-003 File Lineage Service
FILE03-004 Retention Policy Engine
FILE03-005 Archive Service
FILE03-006 Legal Hold Service
FILE03-007 Hold Propagation
FILE03-008 Restore Service
FILE03-009 Custody Event Registry
FILE03-010 Evidence Package Service
FILE03-011 Disposal Workflow
FILE03-012 Tombstone Registry
FILE03-013 Backup Tombstone Integration
FILE03-014 Checksum Verification
FILE03-015 Reconciliation Engine
FILE03-016 Records Governance Dashboard
```

# 128. Approval Gate

Dokumen dapat menjadi Approved setelah:

- File/Storage Architecture review;
- Data Governance review;
- Legal/Compliance review;
- Security review;
- Audit review;
- Backup/DR review;
- Operations review;
- Quality Engineering review;
- UAT review.

# 129. Closing Statement

File lifecycle tidak berhenti saat upload berhasil.

Setiap file harus memiliki version history, retention, hold behavior, evidence integrity, disposal method, dan restore governance yang jelas.

Historical versions tidak boleh ditimpa.

Legal hold tidak boleh dilanggar.

Disposal tidak boleh terjadi tanpa evidence.
