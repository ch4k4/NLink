# SSOT-INTEGRATION-03 — Webhook, Callback & Partner Security

## Status Dokumen

| Item | Nilai |
|---|---|
| Kode | SSOT-INTEGRATION-03 |
| Judul | Webhook, Callback & Partner Security |
| Versi | 1.0 |
| Status | Draft Architecture |
| Domain | Platform Kernel |
| Kategori | Webhook Security, Partner Trust & Callback Governance |
| Cakupan | Signature Verification, Replay Protection, Callback Validation, Partner Authentication, Endpoint Trust, Key Rotation, Incident Handling |
| Bergantung pada | SSOT-GOV-01, SSOT-GOV-04, SSOT-GOV-05, SSOT-SEC-03, SSOT-IAM-08, SSOT-RBAC-05, SSOT-AUDIT-01, SSOT-INTEGRATION-01, SSOT-INTEGRATION-02, SSOT-EVENT-01, SSOT-OBS-01, SSOT-TEST-01 |
| Target Stack | PHP 8.1+, HTTP Client/Server, Secret Manager-compatible |
| Target Evolusi | Partner Trust Registry, Automated Key Rotation, mTLS Webhooks, Adaptive Webhook Risk Scoring |

# 1. Executive Summary

SSOT-INTEGRATION-03 menetapkan governance resmi untuk inbound webhook, outbound webhook, callback, partner authentication, signature verification, replay protection, endpoint validation, key rotation, dan webhook incident handling.

Tujuannya memastikan setiap webhook:

- berasal dari partner yang terdaftar;
- menggunakan authentication yang disetujui;
- ditandatangani secara benar;
- terlindungi dari replay;
- tenant-aware;
- memiliki payload tervalidasi;
- hanya dikirim ke endpoint tepercaya;
- dapat disuspend dan dicabut;
- dapat diaudit dan direkonsiliasi.

# 2. Core Principles

```text
Every Webhook Has a Registered Partner
Every Callback Endpoint Is Verified
Unsigned Requests Are Rejected by Default
Timestamps and Nonces Are Mandatory
Replay Is Prevented
Payloads Are Schema-Validated
Outbound Requests Are Signed
Secrets and Keys Are Rotated
Partner Trust Is Explicit
Every Verification Decision Is Auditable
```

# 3. Scope

Berlaku untuk:

```text
Inbound Webhooks
Outbound Webhooks
OAuth Callbacks
Payment Callbacks
Identity Provider Callbacks
Delivery Receipts
Partner Event Push
Status Callbacks
Asynchronous API Callbacks
```

# 4. Webhook Registry

Minimum metadata:

```text
webhook_code
direction
partner_code
event_type
endpoint
environment
tenant_binding
authentication_method
signature_algorithm
key_reference
owner
risk_tier
status
```

# 5. Partner Registry

Setiap partner memiliki:

- partner code;
- business dan technical owner;
- security contact;
- trust status;
- environment yang disetujui;
- event types;
- authentication methods;
- incident contact;
- expiry/review date.

# 6. Status Models

Partner:

```text
PROPOSED
VERIFIED
ACTIVE
RESTRICTED
SUSPENDED
REVOKED
RETIRED
```

Webhook:

```text
DRAFT
PENDING_VERIFICATION
ACTIVE
DEGRADED
SUSPENDED
REVOKED
EXPIRED
RETIRED
```

# 7. Authentication Methods

```text
HMAC_SIGNATURE
ASYMMETRIC_SIGNATURE
MTLS
JWT_ASSERTION
OAUTH2_ACCESS_TOKEN
IP_ALLOWLIST_PLUS_SIGNATURE
CUSTOM_APPROVED
```

IP allowlist hanya defense-in-depth dan tidak menggantikan cryptographic authentication.

# 8. Signature Canonicalization

Recommended canonical input:

```text
HTTP_METHOD
REQUEST_PATH
TIMESTAMP
NONCE
BODY_HASH
CONTENT_TYPE
```

Canonicalization harus versioned dan terdokumentasi.

# 9. Signature Headers

Conceptual headers:

```text
X-Webhook-Key-Id
X-Webhook-Timestamp
X-Webhook-Nonce
X-Webhook-Signature
X-Webhook-Signature-Version
X-Webhook-Event-Id
```

# 10. HMAC Requirements

- approved algorithm;
- strong shared secret;
- raw-body hash;
- timestamp and nonce;
- key identifier;
- constant-time comparison;
- secret from secret manager;
- no secret logging.

# 11. Asymmetric Signatures

Partner public key atau certificate harus:

- registered;
- environment-bound;
- partner-bound;
- versioned;
- expiry-monitored;
- revocable.

# 12. Timestamp Validation

Request di luar allowed clock skew harus ditolak.

Recommended policy:

```text
high risk: 2–5 minutes
standard: maximum 10 minutes
```

# 13. Nonce and Replay Protection

Nonce harus unik dalam replay window.

Store fingerprint dari:

```text
partner
key_id
timestamp
nonce
body_hash
event_id
```

# 14. Replay Outcomes

```text
FIRST_SEEN
DUPLICATE_IDEMPOTENT
REPLAY_REJECTED
UNKNOWN
```

# 15. Idempotency

Replay protection dan idempotency berbeda:

- replay protection menolak reuse berbahaya;
- idempotency mencegah duplicate business effects akibat legitimate retry.

Setiap event harus memiliki stable event ID.

# 16. Inbound Verification Flow

```text
Receive Raw Request
→ Resolve Partner and Key
→ Validate Partner Status
→ Validate Timestamp
→ Validate Nonce
→ Hash Raw Body
→ Verify Signature
→ Check Replay
→ Validate Schema
→ Persist Envelope
→ Acknowledge or Process
→ Audit
```

# 17. Key Rotation

Rotation mendukung overlap terbatas:

```text
NEXT
ACTIVE
RETIRING
REVOKED
EXPIRED
```

Selama overlap, hanya current dan next key yang diterima.

# 18. Emergency Rotation

Trigger:

- suspected leak;
- partner compromise;
- source-code exposure;
- accidental logging;
- unauthorized webhook;
- staff departure;
- weak algorithm discovery.

# 19. mTLS Governance

mTLS harus memvalidasi:

- approved CA;
- subject/SAN mapping;
- partner mapping;
- environment;
- expiry;
- revocation;
- certificate chain.

# 20. Inbound Endpoint Security

Endpoint harus:

- dedicated dan versioned;
- non-interactive;
- rate-limited;
- hanya menerima expected method/content type;
- membatasi payload size;
- tidak bergantung pada browser session;
- memiliki safe error responses.

# 21. Payload Validation

Validasi:

- schema version;
- event type;
- required fields;
- data types;
- enum values;
- string lengths;
- nested depth;
- unknown-field policy;
- tenant binding;
- data classification.

# 22. Logging and Privacy

Jangan mencatat:

- shared secrets;
- private keys;
- access tokens;
- full sensitive payload;
- full signature inputs bila mengandung sensitive data.

Gunakan body hash dan minimized metadata.

# 23. Callback URL Governance

Outbound callback hanya menuju endpoint terdaftar dan terverifikasi.

Validation:

- HTTPS wajib untuk production;
- approved host dan port;
- tidak ada embedded credentials;
- tidak ada fragments;
- bukan localhost;
- bukan private, link-local, loopback, atau metadata IP kecuali internal-approved;
- normalized URL;
- DNS policy;
- region/residency sesuai.

# 24. SSRF Protection

Defenses:

- resolve destination before connect;
- validate resolved IP;
- reject private/reserved ranges;
- pin resolution for request;
- controlled egress proxy;
- redirect disabled by default;
- revalidate every redirect target.

# 25. Endpoint Ownership Verification

Metode:

```text
CHALLENGE_RESPONSE
SIGNED_VERIFICATION
DNS_VERIFICATION
MTLS
MANUAL_SECURITY_APPROVAL
```

Challenge token harus random, short-lived, single-use, dan endpoint-bound.

# 26. Outbound Signing

Setiap outbound webhook sebaiknya menyertakan:

- key ID;
- signature version;
- timestamp;
- nonce;
- event ID;
- attempt ID;
- body hash;
- cryptographic signature.

# 27. Event and Attempt Identity

- Event ID stabil untuk satu business event.
- Attempt ID unik untuk setiap delivery attempt.

# 28. Response Validation

Validasi:

- expected HTTP status;
- TLS identity;
- response size;
- content type;
- response schema bila diperlukan;
- timeout;
- redirect policy.

# 29. Processing Model

Recommended:

```text
Verify
→ Persist Trusted Envelope
→ Return Fast Acknowledgment
→ Process Asynchronously
```

Acknowledgment hanya diberikan setelah minimum authenticity, replay, dan schema checks lulus.

# 30. Queue Envelope

Queue message menyimpan:

```text
partner_code
webhook_code
tenant_id
event_type
event_id
payload_hash
verification_result
key_id
correlation_id
received_at
```

# 31. Rate Limiting

Apply by:

- partner;
- webhook;
- tenant;
- event type;
- source IP;
- signature-failure count;
- endpoint.

# 32. Abuse Detection

Detect:

- signature-failure spikes;
- nonce reuse;
- replay attempts;
- timestamp anomalies;
- unknown key IDs;
- schema abuse;
- endpoint probing;
- unusual volume;
- tenant mismatch;
- callback changes.

# 33. Safe Failure Responses

External response tidak boleh mengungkap detail cryptographic failure.

Internal reason codes:

```text
SIGNATURE_MISSING
SIGNATURE_INVALID
KEY_UNKNOWN
TIMESTAMP_EXPIRED
NONCE_REUSED
REPLAY_DETECTED
SCHEMA_INVALID
PARTNER_SUSPENDED
ENDPOINT_UNTRUSTED
TENANT_MISMATCH
```

# 34. Partner Onboarding

Required:

- ownership;
- due diligence;
- security contact;
- authentication method;
- endpoint verification;
- schemas;
- key exchange;
- test environment;
- expected volume;
- retry policy;
- incident process;
- production approval.

# 35. Production Activation

Preconditions:

- test passed;
- endpoint verified;
- key exchange complete;
- schema approved;
- rate limits configured;
- monitoring active;
- incident contacts tested;
- owner approval complete.

# 36. Partner Suspension

Suspension harus:

- reject inbound trust;
- block outbound delivery;
- disable scheduled callbacks;
- preserve evidence;
- notify owners;
- open incident bila security-related.

# 37. Partner Offboarding

- disable all webhooks;
- revoke keys/secrets/certificates;
- remove network allowlists;
- stop deliveries;
- reconcile outstanding events;
- retain evidence;
- retire registry records.

# 38. Tenant-Configured Webhooks

Require:

- tenant owner;
- endpoint verification;
- isolated secret/key;
- event allowlist;
- field minimization;
- SSRF controls;
- expiry and periodic review;
- per-tenant rate limits.

# 39. Cross-Tenant Controls

Cross-tenant webhook delivery dilarang kecuali platform-governed dan explicitly approved.

# 40. Versioning

Version:

- endpoint path;
- payload schema;
- signature canonicalization;
- signature algorithm;
- key ID.

Breaking changes membutuhkan new version dan sunset plan.

# 41. JWKS Governance

JWKS source harus:

- HTTPS;
- registered host;
- cache-bounded;
- key-ID validated;
- resilient terhadap stale key;
- environment-bound;
- monitored.

Trust-on-first-use dilarang untuk high-risk production partner.

# 42. Webhook Incident Flow

```text
Detect
→ Suspend or Block
→ Preserve Evidence
→ Rotate Keys
→ Identify Affected Events
→ Reconcile Business Effects
→ Notify Owners
→ Restore Trust
→ Post-Incident Review
```

# 43. Evidence

Preserve:

- partner and webhook ID;
- source IP;
- timestamp;
- nonce;
- event ID;
- attempt ID;
- key ID;
- body hash;
- signature version;
- verification result;
- response status;
- correlation ID.

# 44. Reconciliation

Compare:

- partner registry;
- webhook registry;
- active endpoints;
- endpoint verification;
- secret/key manager;
- certificate store;
- runtime configuration;
- replay store;
- delivery records;
- provider state.

# 45. Reconciliation Findings

```text
UNKNOWN_WEBHOOK_KEY
EXPIRED_KEY_ACTIVE
UNVERIFIED_ENDPOINT_ACTIVE
PARTNER_STATUS_MISMATCH
ENVIRONMENT_MISMATCH
TENANT_BINDING_MISMATCH
MISSING_DELIVERY_EVIDENCE
REPLAY_STORE_UNAVAILABLE
RUNTIME_ENDPOINT_DRIFT
REVOKED_PARTNER_ACTIVE
```

# 46. Audit Events

```text
WEBHOOK_REGISTERED
WEBHOOK_ENDPOINT_VERIFIED
WEBHOOK_ACTIVATED
WEBHOOK_SIGNATURE_VERIFIED
WEBHOOK_SIGNATURE_FAILED
WEBHOOK_REPLAY_REJECTED
WEBHOOK_DELIVERY_SENT
WEBHOOK_DELIVERY_ACKNOWLEDGED
WEBHOOK_SUSPENDED
WEBHOOK_KEY_ROTATED
WEBHOOK_PARTNER_REVOKED
WEBHOOK_INCIDENT_OPENED
WEBHOOK_RECONCILIATION_FAILED
```

# 47. Metrics

```text
webhook_inbound_total
webhook_outbound_total
webhook_signature_failure_total
webhook_replay_rejected_total
webhook_schema_failure_total
webhook_delivery_failure_total
webhook_endpoint_verification_failure_total
webhook_key_rotation_overdue_total
webhook_partner_suspended_total
webhook_reconciliation_failure_total
```

# 48. KPIs

```text
Unsigned production webhooks = 0
Accepted replay attacks = 0
Unverified callback endpoints active = 0
Webhook secrets stored plaintext = 0
Expired keys accepted = 0
Cross-tenant webhook delivery = 0
Critical signature failures without alert = 0
```

# 49. KRIs

```text
Signature-failure growth
Replay attempts
Unknown key IDs
Endpoint changes
Verification failures
Partner incident frequency
Rotation overdue
Outbound delivery anomalies
```

# 50. Database Direction

Potential tables:

```text
integration_partners
integration_webhooks
integration_webhook_endpoints
integration_webhook_keys
integration_webhook_endpoint_verifications
integration_webhook_replay_fingerprints
integration_webhook_deliveries
integration_webhook_attempts
integration_webhook_incidents
integration_webhook_reconciliation_runs
integration_webhook_reconciliation_findings
```

# 51. Table: integration_partners

```sql
CREATE TABLE integration_partners (
    id CHAR(26) NOT NULL,
    partner_code VARCHAR(180) NOT NULL,
    partner_name VARCHAR(255) NOT NULL,
    trust_status VARCHAR(30) NOT NULL,
    risk_tier VARCHAR(30) NOT NULL,
    business_owner VARCHAR(180) NOT NULL,
    technical_contact VARCHAR(255) NULL,
    security_contact VARCHAR(255) NULL,
    created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),

    PRIMARY KEY (id),
    UNIQUE KEY uq_integration_partner_code (partner_code),
    KEY idx_integration_partner_status (trust_status, risk_tier)
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

# 52. Table: integration_webhooks

```sql
CREATE TABLE integration_webhooks (
    id CHAR(26) NOT NULL,
    webhook_code VARCHAR(180) NOT NULL,
    partner_id CHAR(26) NOT NULL,
    direction VARCHAR(20) NOT NULL,
    event_type VARCHAR(180) NOT NULL,
    environment VARCHAR(30) NOT NULL,
    tenant_id CHAR(26) NULL,
    authentication_method VARCHAR(50) NOT NULL,
    signature_algorithm VARCHAR(50) NULL,
    status VARCHAR(30) NOT NULL,
    owner_reference VARCHAR(180) NOT NULL,

    PRIMARY KEY (id),
    UNIQUE KEY uq_integration_webhook (
        webhook_code,
        environment,
        tenant_id
    ),
    CONSTRAINT fk_integration_webhook_partner
        FOREIGN KEY (partner_id)
        REFERENCES integration_partners (id)
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

# 53. Table: integration_webhook_keys

```sql
CREATE TABLE integration_webhook_keys (
    id CHAR(26) NOT NULL,
    webhook_id CHAR(26) NOT NULL,
    key_id VARCHAR(180) NOT NULL,
    key_type VARCHAR(40) NOT NULL,
    secret_or_public_key_reference VARCHAR(1000) NOT NULL,
    status VARCHAR(30) NOT NULL,
    valid_from DATETIME(6) NOT NULL,
    valid_to DATETIME(6) NULL,

    PRIMARY KEY (id),
    UNIQUE KEY uq_integration_webhook_key (
        webhook_id,
        key_id
    ),
    KEY idx_integration_webhook_key_validity (
        status,
        valid_to
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

# 54. Table: integration_webhook_replay_fingerprints

```sql
CREATE TABLE integration_webhook_replay_fingerprints (
    id CHAR(26) NOT NULL,
    webhook_id CHAR(26) NOT NULL,
    fingerprint_sha256 CHAR(64) NOT NULL,
    event_id VARCHAR(255) NULL,
    nonce VARCHAR(255) NOT NULL,
    accepted_at DATETIME(6) NOT NULL,
    expires_at DATETIME(6) NOT NULL,

    PRIMARY KEY (id),
    UNIQUE KEY uq_integration_webhook_replay (
        webhook_id,
        fingerprint_sha256
    ),
    KEY idx_integration_webhook_replay_expiry (
        expires_at
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

# 55. Table: integration_webhook_deliveries

```sql
CREATE TABLE integration_webhook_deliveries (
    id CHAR(26) NOT NULL,
    webhook_id CHAR(26) NOT NULL,
    event_id VARCHAR(255) NOT NULL,
    tenant_id CHAR(26) NULL,
    event_type VARCHAR(180) NOT NULL,
    payload_hash CHAR(64) NOT NULL,
    status VARCHAR(30) NOT NULL,
    created_at DATETIME(6) NOT NULL,
    completed_at DATETIME(6) NULL,

    PRIMARY KEY (id),
    UNIQUE KEY uq_integration_webhook_event (
        webhook_id,
        event_id
    ),
    KEY idx_integration_webhook_delivery_status (
        status,
        created_at
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

# 56. API Direction

```text
GET  /api/internal/v1/integrations/partners
POST /api/internal/v1/integrations/partners
GET  /api/internal/v1/integrations/webhooks
POST /api/internal/v1/integrations/webhooks
POST /api/internal/v1/integrations/webhooks/{webhookCode}/verify-endpoint
POST /api/internal/v1/integrations/webhooks/{webhookCode}/activate
POST /api/internal/v1/integrations/webhooks/{webhookCode}/rotate-key
POST /api/internal/v1/integrations/webhooks/{webhookCode}/suspend
POST /api/internal/v1/integrations/webhooks/{webhookCode}/test
POST /api/internal/v1/integrations/webhooks/reconcile
```

# 57. SDK Contracts

```text
WebhookRegistryInterface
PartnerTrustServiceInterface
WebhookSignatureVerifierInterface
WebhookSignerInterface
WebhookReplayProtectionInterface
WebhookEndpointValidatorInterface
WebhookDeliveryServiceInterface
WebhookReconciliationServiceInterface
```

# 58. Signature Verifier Contract

```php
interface WebhookSignatureVerifierInterface
{
    public function verify(
        WebhookVerificationRequest $request
    ): WebhookVerificationResult;
}
```

# 59. Replay Protection Contract

```php
interface WebhookReplayProtectionInterface
{
    public function checkAndStore(
        WebhookReplayRequest $request
    ): WebhookReplayDecision;
}
```

# 60. Endpoint Validator Contract

```php
interface WebhookEndpointValidatorInterface
{
    public function validate(
        WebhookEndpointValidationRequest $request
    ): WebhookEndpointValidationResult;
}
```

# 61. Error Codes

```text
WEBHOOK_NOT_REGISTERED
WEBHOOK_PARTNER_INACTIVE
WEBHOOK_SIGNATURE_MISSING
WEBHOOK_SIGNATURE_INVALID
WEBHOOK_KEY_UNKNOWN
WEBHOOK_TIMESTAMP_EXPIRED
WEBHOOK_NONCE_REUSED
WEBHOOK_REPLAY_DETECTED
WEBHOOK_SCHEMA_INVALID
WEBHOOK_ENDPOINT_INVALID
WEBHOOK_ENDPOINT_UNVERIFIED
WEBHOOK_SSRF_BLOCKED
WEBHOOK_DELIVERY_FAILED
WEBHOOK_KEY_ROTATION_FAILED
WEBHOOK_RECONCILIATION_FAILED
```

# 62. Partner Onboarding Checklist

- [ ] Partner owner assigned.
- [ ] Technical/security contacts recorded.
- [ ] Trust status reviewed.
- [ ] Event types approved.
- [ ] Payload schemas approved.
- [ ] Authentication method approved.
- [ ] Keys exchanged securely.
- [ ] Endpoints verified.
- [ ] Retry behavior documented.
- [ ] Incident process tested.
- [ ] Test environment passed.
- [ ] Production activation approved.

# 63. Signature Verification Checklist

- [ ] Raw body preserved.
- [ ] Partner resolved.
- [ ] Key ID resolved.
- [ ] Timestamp within skew.
- [ ] Nonce unused.
- [ ] Body hash calculated.
- [ ] Canonical string built.
- [ ] Signature verified safely.
- [ ] Replay fingerprint stored.
- [ ] Schema validated.
- [ ] Result audited.

# 64. UAT — Signature Verification

- [ ] Valid HMAC accepted.
- [ ] Invalid signature rejected.
- [ ] Missing signature rejected.
- [ ] Unknown key rejected.
- [ ] Expired timestamp rejected.
- [ ] Future timestamp outside skew rejected.
- [ ] Reused nonce rejected.
- [ ] Modified body invalidates signature.
- [ ] Constant-time comparison used.
- [ ] Audit complete.

# 65. UAT — Replay and Idempotency

- [ ] First event accepted.
- [ ] Malicious replay rejected.
- [ ] Legitimate retry acknowledged safely.
- [ ] Duplicate event does not duplicate business effect.
- [ ] Replay window expiry works.
- [ ] Event ID uniqueness enforced.
- [ ] Attempt IDs remain unique.
- [ ] Concurrent duplicate remains idempotent.
- [ ] Metrics updated.

# 66. UAT — Callback URL Security

- [ ] HTTPS production endpoint accepted.
- [ ] HTTP production endpoint rejected.
- [ ] Localhost rejected.
- [ ] Private IP rejected.
- [ ] Metadata IP rejected.
- [ ] DNS rebinding defense works.
- [ ] Redirect target revalidated.
- [ ] Embedded credentials rejected.
- [ ] Endpoint challenge succeeds.
- [ ] Unverified endpoint cannot activate.

# 67. UAT — Outbound Signing and Rotation

- [ ] Body hash correct.
- [ ] Timestamp and nonce included.
- [ ] Key ID included.
- [ ] Partner verifies signature.
- [ ] Old key accepted during overlap.
- [ ] Retired key rejected after cutover.
- [ ] Event ID stable across retries.
- [ ] Attempt ID changes per retry.
- [ ] Secret never logged.

# 68. UAT — Tenant Isolation

- [ ] Tenant secrets isolated.
- [ ] Tenant A event cannot target Tenant B webhook.
- [ ] Tenant switch re-resolves endpoint.
- [ ] Cross-tenant delivery blocked.
- [ ] Global webhook requires platform approval.
- [ ] Audit records tenant context.
- [ ] Cache remains tenant-bound.
- [ ] Partner cannot infer another tenant endpoint.

# 69. UAT — Incident Handling

- [ ] Signature-failure spike alerts.
- [ ] Replay attack opens incident.
- [ ] Malicious endpoint blocked.
- [ ] Emergency partner suspension works.
- [ ] Key compromise triggers rotation.
- [ ] Affected-event report generated.
- [ ] Business-effect reconciliation initiated.
- [ ] Restoration requires approval.
- [ ] Post-incident review retained.

# 70. UAT — Reconciliation

- [ ] Unknown key detected.
- [ ] Expired active key detected.
- [ ] Unverified active endpoint detected.
- [ ] Partner-status mismatch detected.
- [ ] Environment mismatch detected.
- [ ] Tenant-binding mismatch detected.
- [ ] Missing delivery evidence detected.
- [ ] Replay-store failure detected.
- [ ] Critical finding opens incident.
- [ ] Report generated.

# 71. Definition of Done — SSOT-INTEGRATION-03

SSOT-INTEGRATION-03 dianggap selesai bila:

- [ ] partner and webhook registries tersedia;
- [ ] trust/status models tersedia;
- [ ] inbound authentication tersedia;
- [ ] canonical signature model tersedia;
- [ ] timestamp/nonce/replay controls tersedia;
- [ ] idempotency guidance tersedia;
- [ ] key and secret rotation tersedia;
- [ ] mTLS and IP controls tersedia;
- [ ] payload validation tersedia;
- [ ] callback URL and SSRF controls tersedia;
- [ ] endpoint ownership verification tersedia;
- [ ] outbound signing tersedia;
- [ ] rate limiting and abuse detection tersedia;
- [ ] queue-envelope security tersedia;
- [ ] incident handling tersedia;
- [ ] partner onboarding/offboarding tersedia;
- [ ] tenant isolation tersedia;
- [ ] reconciliation tersedia;
- [ ] audit and metrics tersedia;
- [ ] database direction tersedia;
- [ ] API direction tersedia;
- [ ] SDK contracts tersedia;
- [ ] UAT and DoD tersedia.

# 72. Implementation Roadmap

## Phase 1 — Registry Foundation

- partner registry;
- webhook registry;
- endpoint registry;
- ownership;
- environment and tenant binding;
- administrative APIs.

## Phase 2 — Verification and Replay Security

- HMAC verification;
- asymmetric verification;
- canonicalization;
- timestamp and nonce validation;
- replay store;
- idempotency integration.

## Phase 3 — Endpoint and Delivery Security

- SSRF protection;
- endpoint verification;
- outbound signing;
- response validation;
- rate limiting;
- queue-envelope security.

## Phase 4 — Lifecycle and Incident Controls

- key rotation;
- partner suspension;
- emergency block;
- incident workflow;
- evidence preservation;
- offboarding.

## Phase 5 — Advanced Partner Trust

- mTLS automation;
- JWKS lifecycle;
- adaptive partner risk;
- webhook anomaly analytics;
- continuous reconciliation;
- trust dashboard.

# 73. Initial Implementation Backlog

```text
INTEGRATION03-001 Partner Registry
INTEGRATION03-002 Webhook Registry
INTEGRATION03-003 Signature Canonicalizer
INTEGRATION03-004 HMAC Verifier
INTEGRATION03-005 Asymmetric Signature Verifier
INTEGRATION03-006 Timestamp and Nonce Validator
INTEGRATION03-007 Replay Protection Store
INTEGRATION03-008 Endpoint Validator
INTEGRATION03-009 Endpoint Challenge Service
INTEGRATION03-010 Outbound Webhook Signer
INTEGRATION03-011 Delivery Service
INTEGRATION03-012 Key Rotation Orchestrator
INTEGRATION03-013 Abuse Detection
INTEGRATION03-014 Incident Workflow
INTEGRATION03-015 Reconciliation Engine
INTEGRATION03-016 Partner Trust Dashboard
```

# 74. Approval Gate

Dokumen dapat menjadi Approved setelah:

- Integration Architecture review;
- Security Architecture review;
- Cryptography and Secrets review;
- Network and SSRF review;
- IAM/RBAC review;
- Data Privacy review;
- Operations/SRE review;
- Audit/Compliance review;
- Quality Engineering review;
- UAT review.

# 75. Closing Statement

Webhook dan callback adalah trust boundary.

Setiap request harus diverifikasi, dibatasi waktu, dilindungi dari replay, dan diikat ke partner yang terdaftar.

Setiap callback endpoint harus tervalidasi.

Setiap key harus dapat dirotasi.

Setiap incident harus dapat ditelusuri.
