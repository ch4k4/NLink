# SSOT-INTEGRATION-04 — Integration Reliability, Retry & Reconciliation

## Status Dokumen

| Item | Nilai |
|---|---|
| Kode | SSOT-INTEGRATION-04 |
| Judul | Integration Reliability, Retry & Reconciliation |
| Versi | 1.0 |
| Status | Draft Architecture |
| Domain | Platform Kernel |
| Kategori | Integration Reliability, Resilience & Transaction Reconciliation |
| Cakupan | Retry, Idempotency, Timeout, Circuit Breaker, Dead-Letter, Partial Failure, Reconciliation, Recovery |
| Bergantung pada | SSOT-GOV-01, SSOT-GOV-04, SSOT-GOV-05, SSOT-AUDIT-01, SSOT-INTEGRATION-01, SSOT-INTEGRATION-02, SSOT-INTEGRATION-03, SSOT-EVENT-01, SSOT-EVENT-02, SSOT-EVENT-03, SSOT-OBS-01, SSOT-TEST-01 |
| Target Stack | PHP 8.1+, Queue/Event-ready, HTTP Client, PDO, MySQL 8/MariaDB |
| Target Evolusi | Distributed Saga, Automated Reconciliation, Exactly-Once Effect Simulation, Integration Reliability Platform |

# 1. Executive Summary

SSOT-INTEGRATION-04 menetapkan governance resmi untuk reliability dan reconciliation seluruh integrasi.

Dokumen ini mengatur:

- retry;
- backoff;
- timeout;
- idempotency;
- duplicate handling;
- circuit breaker;
- bulkhead;
- rate-limit handling;
- dead-letter;
- poison messages;
- partial failure;
- compensation;
- transaction reconciliation;
- source-of-truth comparison;
- replay;
- recovery;
- failover;
- observability;
- incident handling;
- audit;
- metrics;
- database direction;
- API direction;
- SDK contracts;
- UAT;
- Definition of Done;
- implementation roadmap.

Tujuan akhirnya adalah memastikan integrasi:

- tahan terhadap kegagalan sementara;
- tidak menggandakan business effect;
- tidak retry tanpa batas;
- dapat berhenti saat partner tidak sehat;
- dapat memisahkan poison messages;
- dapat merekonsiliasi partial failure;
- dapat memulihkan state;
- dapat diaudit.

# 2. Objectives

Framework harus:

- menyediakan retry policy;
- menyediakan timeout policy;
- menjamin idempotent effect;
- menyediakan circuit breaker;
- menyediakan dead-letter handling;
- mendukung partial failure recovery;
- menyediakan transaction reconciliation;
- mendukung replay;
- menyediakan incident evidence;
- menghasilkan reliability metrics.

# 3. Core Principles

```text
Retries Must Be Bounded
Every Retry Must Be Safe
Idempotency Protects Business Effects
Timeouts Are Mandatory
Circuit Breakers Protect the Platform
Partial Failure Must Be Visible
Dead-Letter Is a Managed State
Reconciliation Compares Expected and Actual State
Recovery Must Be Repeatable
Every Reliability Decision Is Auditable
```

# 4. Scope

Berlaku untuk:

```text
Outbound APIs
Inbound Webhooks
Outbound Webhooks
Message Brokers
SFTP Transfers
Database Integrations
Payment Integrations
Notification Providers
Partner Events
Background Jobs
Batch Integrations
```

# 5. Failure Categories

```text
TRANSIENT
PERMANENT
AUTHENTICATION
AUTHORIZATION
VALIDATION
RATE_LIMIT
TIMEOUT
NETWORK
DEPENDENCY_UNAVAILABLE
PARTIAL_SUCCESS
DUPLICATE
UNKNOWN
```

# 6. Retry Eligibility

Retry hanya untuk failure yang mungkin pulih.

Retryable examples:

```text
connection reset
temporary DNS failure
HTTP 429
HTTP 502
HTTP 503
HTTP 504
broker unavailable
temporary lock
```

Non-retryable examples:

```text
invalid payload
permission denied
unknown resource
schema mismatch
revoked credential
business rule rejection
```

# 7. Retry Policy

Minimum:

```text
policy_code
max_attempts
initial_delay
backoff_strategy
max_delay
jitter
retryable_errors
timeout
dead_letter_behavior
```

# 8. Backoff Strategies

```text
FIXED
LINEAR
EXPONENTIAL
EXPONENTIAL_WITH_JITTER
PROVIDER_RETRY_AFTER
```

# 9. Jitter

Jitter menghindari retry storm.

# 10. Retry Budget

Setiap integration memiliki retry budget berdasarkan:

- request volume;
- partner capacity;
- business urgency;
- operation risk;
- cost.

# 11. Maximum Attempts

Harus bounded dan configurable per operation.

# 12. Retry Deadline

Retry berhenti setelah business deadline, walaupun attempt belum habis.

# 13. Retry-After

Provider `Retry-After` boleh digunakan setelah divalidasi dan dibatasi.

# 14. Timeout Policy

Setiap call harus memiliki:

- connect timeout;
- TLS timeout;
- request timeout;
- response timeout;
- total deadline.

# 15. Timeout Budget

Timeout downstream harus lebih kecil dari upstream request budget.

# 16. Long-Running Operations

Gunakan asynchronous job/polling/callback, bukan synchronous call tanpa batas.

# 17. Idempotency

Idempotency memastikan repeated request tidak menciptakan repeated business effect.

# 18. Idempotency Key

Key harus:

- stable untuk logical operation;
- unique per tenant and operation;
- bounded;
- non-sensitive;
- stored with result;
- protected from collision.

# 19. Idempotency Scope

```text
tenant
connection
operation
resource
request fingerprint
```

# 20. Idempotency Record

Minimum:

```text
idempotency_key
tenant_id
operation_code
request_hash
status
result_reference
created_at
expires_at
```

# 21. Idempotency Outcomes

```text
FIRST_REQUEST
IN_PROGRESS
COMPLETED_REPLAY
FAILED_RETRYABLE
FAILED_FINAL
CONFLICT
```

# 22. Request Hash

Same key with different request payload must be rejected as conflict.

# 23. Concurrent Duplicate

Use locking or atomic insert to ensure only one execution.

# 24. Exactly-Once Effect

True exactly-once delivery is generally unrealistic across distributed systems.

Target:

```text
at-least-once delivery
+
idempotent processing
+
reconciliation
=
effectively-once business outcome
```

# 25. Duplicate Detection

Use:

- event ID;
- provider transaction ID;
- idempotency key;
- canonical request hash;
- sequence number.

# 26. Circuit Breaker

States:

```text
CLOSED
OPEN
HALF_OPEN
FORCED_OPEN
DISABLED
```

# 27. Circuit Open Triggers

- consecutive failures;
- failure rate;
- timeout rate;
- authentication failure;
- provider health;
- manual incident action.

# 28. Circuit Open Behavior

- fail fast;
- queue if safe;
- use fallback if approved;
- notify operations;
- avoid retry storm.

# 29. Half-Open

Allow limited probe requests.

# 30. Circuit Reset

Requires successful probes and healthy thresholds.

# 31. Bulkhead

Separate resource pools by:

- provider;
- tenant;
- operation type;
- risk;
- queue.

# 32. Bulkhead Purpose

Prevent one failed integration from exhausting all platform workers.

# 33. Rate-Limit Handling

Track:

- local limit;
- partner limit;
- quota window;
- remaining quota;
- reset time;
- retry-after;
- tenant share.

# 34. Local Throttling

Throttle before provider rejects where possible.

# 35. Priority

Critical operations may have separate queue and quota.

# 36. Dead-Letter

Dead-letter stores messages/jobs that cannot complete automatically.

# 37. Dead-Letter Reasons

```text
MAX_RETRIES_EXCEEDED
PERMANENT_ERROR
SCHEMA_INVALID
AUTHENTICATION_FAILED
POISON_MESSAGE
DEPENDENCY_RETIRED
MANUAL_QUARANTINE
UNKNOWN_FAILURE
```

# 38. Dead-Letter Record

Minimum:

```text
source
operation
tenant
payload_reference
error
attempt_count
first_failed_at
last_failed_at
owner
status
```

# 39. Dead-Letter States

```text
OPEN
TRIAGED
RETRY_APPROVED
REPLAYING
RESOLVED
DISCARDED
ESCALATED
```

# 40. Poison Message

Message yang selalu gagal harus diisolasi agar tidak memblokir queue.

# 41. Dead-Letter Replay

Replay membutuhkan:

- root cause resolved;
- payload still valid;
- idempotency preserved;
- approval for high-risk;
- audit.

# 42. Partial Failure

Examples:

- provider accepted but local save failed;
- local transaction committed but outbound call timed out;
- multi-step partner process partially completed;
- one tenant batch item failed.

# 43. Partial Failure States

```text
UNKNOWN
LOCAL_ONLY
REMOTE_ONLY
PARTIAL
COMPENSATION_PENDING
RECONCILIATION_PENDING
RESOLVED
```

# 44. Transaction Boundary

Local database transaction tidak boleh diasumsikan mencakup remote system.

# 45. Transactional Outbox

Use outbox for reliable local-state-to-event publication.

# 46. Inbox Pattern

Use inbox for deduplicated inbound event processing.

# 47. Saga

Multi-step operations may use saga orchestration or choreography.

# 48. Saga State

```text
STARTED
STEP_PENDING
STEP_COMPLETED
COMPENSATING
COMPENSATED
COMPLETED
FAILED
MANUAL_INTERVENTION
```

# 49. Compensation

Compensation reverses or neutralizes prior effects where possible.

# 50. Non-Reversible Action

Requires manual recovery path and explicit risk.

# 51. Reconciliation

Reconciliation compares expected state with actual external and internal state.

# 52. Reconciliation Types

```text
TRANSACTION
BALANCE
DELIVERY
STATUS
FILE_TRANSFER
EVENT
ACCOUNT
CONFIGURATION
```

# 53. Reconciliation Sources

```text
local transaction
provider transaction
provider statement
delivery receipt
event log
outbox/inbox
file manifest
connection registry
```

# 54. Reconciliation Flow

```text
Define Population
→ Collect Local State
→ Collect Remote State
→ Normalize
→ Match
→ Classify Differences
→ Remediate
→ Verify
→ Close
```

# 55. Matching Keys

Examples:

```text
provider_transaction_id
merchant_reference
event_id
file_sequence
account_id
tenant_id
date
amount
checksum
```

# 56. Reconciliation Findings

```text
LOCAL_MISSING
REMOTE_MISSING
STATUS_MISMATCH
AMOUNT_MISMATCH
DUPLICATE_REMOTE
DUPLICATE_LOCAL
LATE_DELIVERY
UNKNOWN_TRANSACTION
UNMATCHED_CALLBACK
PARTIAL_COMPLETION
```

# 57. Finding Severity

Based on:

- financial impact;
- patient/customer impact;
- security impact;
- data inconsistency;
- age;
- volume;
- tenant impact.

# 58. Auto-Remediation

Allowed for deterministic and low-risk cases.

Examples:

- replay missing delivery;
- refresh status;
- recreate missing local projection;
- close duplicate safe callback.

# 59. Manual Remediation

Required for:

- financial mismatch;
- ambiguous ownership;
- non-reversible operation;
- conflicting provider evidence;
- compliance impact.

# 60. Reconciliation Schedule

Examples:

```text
real-time event driven
hourly
daily
end-of-day
statement-based
post-incident
```

# 61. Reconciliation Window

Must account for eventual consistency and provider settlement delay.

# 62. Cutoff

Daily reconciliation requires explicit timezone and cutoff.

# 63. Late Arrival

Late events remain matchable within retention window.

# 64. Replay

Replay reprocesses previously received or generated operations.

# 65. Replay Safety

- preserve original event ID;
- generate replay attempt ID;
- maintain idempotency;
- validate current policy;
- record operator;
- limit scope;
- support dry run where possible.

# 66. Full Replay

High-risk and requires strict approval.

# 67. Selective Replay

Prefer replay by:

- tenant;
- event type;
- time window;
- failed operation;
- finding ID.

# 68. Recovery Modes

```text
AUTOMATIC_RETRY
MANUAL_RETRY
REPLAY
COMPENSATE
RECREATE
STATUS_REFRESH
FAILOVER
CANCEL
WRITE_OFF_APPROVED
```

# 69. Failover

Failover uses approved alternate connection.

# 70. Failover Preconditions

- alternate healthy;
- credentials valid;
- data semantics compatible;
- idempotency maintained;
- tenant routing correct;
- rollback defined.

# 71. Failback

Must be controlled and reconciled.

# 72. Provider Timeout Ambiguity

Timeout after request send may mean remote success with unknown local knowledge.

Action:

```text
DO_NOT blind retry non-idempotent operation
query provider status
reconcile by reference
then retry only if safe
```

# 73. HTTP Status Guidance

```text
2xx: success according to operation contract
409: duplicate/conflict; inspect idempotency semantics
429: retry with bounded delay
4xx validation/auth: usually non-retryable
5xx: usually retryable within policy
```

# 74. Queue Delivery Semantics

Assume at-least-once unless documented otherwise.

# 75. Consumer Acknowledgment

Acknowledge only after durable processing or durable handoff.

# 76. Visibility Timeout

Must exceed expected processing time and support extension where safe.

# 77. Message Ordering

Use partition key when order matters.

# 78. Out-of-Order Handling

Use sequence/source version and reject stale operations.

# 79. Backpressure

When dependency is unhealthy:

- pause consumers;
- reduce concurrency;
- delay retries;
- open circuit;
- prioritize critical work;
- alert operations.

# 80. Load Shedding

Reject or defer low-priority work during overload.

# 81. Job Ownership

Every integration job has:

- owner;
- policy;
- SLA;
- queue;
- connection;
- tenant scope;
- retry profile.

# 82. Operation States

```text
PENDING
IN_PROGRESS
SUCCEEDED
FAILED_RETRYABLE
FAILED_FINAL
UNKNOWN
RECONCILING
COMPENSATING
CANCELLED
```

# 83. Correlation

Track:

```text
correlation_id
operation_id
event_id
attempt_id
provider_reference
tenant_id
```

# 84. Error Taxonomy

Errors must map to canonical category and provider-specific code.

# 85. Error Redaction

Do not store secrets or full sensitive payloads in error records.

# 86. Observability

Monitor:

- success rate;
- failure rate;
- latency;
- timeout;
- retry count;
- circuit state;
- queue depth;
- dead-letter count;
- reconciliation findings;
- recovery time.

# 87. SLOs

Per integration define:

```text
availability
success rate
latency
freshness
delivery time
reconciliation completeness
recovery time
```

# 88. Alerting

Alert on:

- circuit open;
- retry storm;
- dead-letter growth;
- unknown transaction;
- reconciliation mismatch;
- provider outage;
- timeout spike;
- auth failures.

# 89. Incident Handling

```text
Detect
→ Stabilize
→ Open Circuit/Pause
→ Preserve Evidence
→ Identify Impact
→ Reconcile
→ Recover
→ Verify
→ Post-Incident Review
```

# 90. Evidence

Preserve:

- request hash;
- attempt history;
- responses;
- error category;
- provider reference;
- retry decisions;
- reconciliation result;
- remediation actions;
- correlation IDs.

# 91. Integration Reliability Service Contract

```php
interface IntegrationReliabilityServiceInterface
{
    public function execute(
        IntegrationOperationRequest $request
    ): IntegrationOperationResult;
}
```

# 92. Idempotency Contract

```php
interface IntegrationIdempotencyStoreInterface
{
    public function acquire(
        IntegrationIdempotencyRequest $request
    ): IntegrationIdempotencyDecision;

    public function complete(
        IntegrationIdempotencyCompletion $completion
    ): void;
}
```

# 93. Circuit Breaker Contract

```php
interface IntegrationCircuitBreakerInterface
{
    public function allow(
        IntegrationConnectionReference $connection
    ): CircuitBreakerDecision;

    public function record(
        IntegrationAttemptResult $result
    ): void;
}
```

# 94. Reconciliation Contract

```php
interface IntegrationReconciliationServiceInterface
{
    public function run(
        IntegrationReconciliationRequest $request
    ): IntegrationReconciliationResult;
}
```

# 95. Dead-Letter Contract

```php
interface IntegrationDeadLetterServiceInterface
{
    public function quarantine(
        IntegrationFailedOperation $operation
    ): IntegrationDeadLetterRecord;

    public function replay(
        IntegrationDeadLetterReplayRequest $request
    ): IntegrationReplayResult;
}
```

# 96. Audit Events

```text
INTEGRATION_OPERATION_STARTED
INTEGRATION_OPERATION_SUCCEEDED
INTEGRATION_OPERATION_FAILED
INTEGRATION_RETRY_SCHEDULED
INTEGRATION_CIRCUIT_OPENED
INTEGRATION_CIRCUIT_CLOSED
INTEGRATION_DEAD_LETTER_CREATED
INTEGRATION_DEAD_LETTER_REPLAYED
INTEGRATION_RECONCILIATION_STARTED
INTEGRATION_RECONCILIATION_FINDING_CREATED
INTEGRATION_REMEDIATION_COMPLETED
INTEGRATION_COMPENSATION_EXECUTED
```

# 97. Metrics

```text
integration_operation_total
integration_operation_success_total
integration_operation_failure_total
integration_retry_total
integration_timeout_total
integration_circuit_open_total
integration_dead_letter_total
integration_reconciliation_finding_total
integration_compensation_total
integration_recovery_duration_seconds
```

# 98. KPIs

```text
Unbounded retries = 0
Non-idempotent blind retries = 0
Critical dead-letter items beyond SLA = 0
Unknown financial transactions unresolved = 0
Circuit open without alert = 0
Reconciliation jobs without owner = 0
Duplicate business effects = 0
```

# 99. KRIs

```text
Retry amplification
Dead-letter growth
Unknown-state growth
Timeout rate
Circuit-open frequency
Compensation frequency
Reconciliation mismatch volume
Provider-specific failure concentration
```

# 100. Database Direction

Potential tables:

```text
integration_operations
integration_operation_attempts
integration_idempotency_records
integration_circuit_states
integration_dead_letters
integration_sagas
integration_saga_steps
integration_reconciliation_runs
integration_reconciliation_items
integration_reconciliation_findings
integration_recovery_actions
```

# 101. Table: integration_operations

```sql
CREATE TABLE integration_operations (
    id CHAR(26) NOT NULL,
    operation_code VARCHAR(180) NOT NULL,
    connection_code VARCHAR(180) NOT NULL,
    tenant_id CHAR(26) NULL,
    operation_type VARCHAR(100) NOT NULL,
    idempotency_key VARCHAR(255) NULL,
    request_hash CHAR(64) NOT NULL,
    status VARCHAR(30) NOT NULL,
    provider_reference VARCHAR(255) NULL,
    correlation_id VARCHAR(180) NOT NULL,
    created_at DATETIME(6) NOT NULL,
    completed_at DATETIME(6) NULL,

    PRIMARY KEY (id),
    UNIQUE KEY uq_integration_operation_code (
        operation_code
    ),
    KEY idx_integration_operation_status (
        connection_code,
        status,
        created_at
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

# 102. Table: integration_operation_attempts

```sql
CREATE TABLE integration_operation_attempts (
    id CHAR(26) NOT NULL,
    operation_id CHAR(26) NOT NULL,
    attempt_number INT NOT NULL,
    attempt_id VARCHAR(180) NOT NULL,
    result VARCHAR(30) NOT NULL,
    error_category VARCHAR(50) NULL,
    provider_error_code VARCHAR(180) NULL,
    response_status INT NULL,
    started_at DATETIME(6) NOT NULL,
    completed_at DATETIME(6) NULL,

    PRIMARY KEY (id),
    UNIQUE KEY uq_integration_operation_attempt (
        operation_id,
        attempt_number
    ),
    CONSTRAINT fk_integration_attempt_operation
        FOREIGN KEY (operation_id)
        REFERENCES integration_operations (id)
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

# 103. Table: integration_idempotency_records

```sql
CREATE TABLE integration_idempotency_records (
    id CHAR(26) NOT NULL,
    idempotency_key VARCHAR(255) NOT NULL,
    tenant_id CHAR(26) NULL,
    operation_type VARCHAR(100) NOT NULL,
    request_hash CHAR(64) NOT NULL,
    status VARCHAR(30) NOT NULL,
    result_reference VARCHAR(1000) NULL,
    created_at DATETIME(6) NOT NULL,
    expires_at DATETIME(6) NOT NULL,

    PRIMARY KEY (id),
    UNIQUE KEY uq_integration_idempotency (
        tenant_id,
        operation_type,
        idempotency_key
    ),
    KEY idx_integration_idempotency_expiry (
        expires_at
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

# 104. Table: integration_dead_letters

```sql
CREATE TABLE integration_dead_letters (
    id CHAR(26) NOT NULL,
    operation_id CHAR(26) NOT NULL,
    reason_code VARCHAR(180) NOT NULL,
    payload_reference VARCHAR(1000) NULL,
    attempt_count INT NOT NULL,
    owner_reference VARCHAR(180) NULL,
    status VARCHAR(30) NOT NULL,
    first_failed_at DATETIME(6) NOT NULL,
    last_failed_at DATETIME(6) NOT NULL,
    resolved_at DATETIME(6) NULL,

    PRIMARY KEY (id),
    KEY idx_integration_dead_letter_status (
        status,
        last_failed_at
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

# 105. Table: integration_reconciliation_findings

```sql
CREATE TABLE integration_reconciliation_findings (
    id CHAR(26) NOT NULL,
    run_id CHAR(26) NOT NULL,
    finding_type VARCHAR(60) NOT NULL,
    severity VARCHAR(30) NOT NULL,
    tenant_id CHAR(26) NULL,
    local_reference VARCHAR(255) NULL,
    remote_reference VARCHAR(255) NULL,
    expected_state_json JSON NULL,
    actual_state_json JSON NULL,
    status VARCHAR(30) NOT NULL,
    owner_reference VARCHAR(180) NULL,
    detected_at DATETIME(6) NOT NULL,
    resolved_at DATETIME(6) NULL,

    PRIMARY KEY (id),
    KEY idx_integration_reconciliation_finding (
        severity,
        status,
        detected_at
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

# 106. API Direction

```text
GET  /api/internal/v1/integrations/operations
GET  /api/internal/v1/integrations/operations/{operationCode}
POST /api/internal/v1/integrations/operations/{operationCode}/retry
POST /api/internal/v1/integrations/operations/{operationCode}/reconcile
GET  /api/internal/v1/integrations/dead-letters
POST /api/internal/v1/integrations/dead-letters/{id}/replay
POST /api/internal/v1/integrations/dead-letters/{id}/discard
GET  /api/internal/v1/integrations/circuits
POST /api/internal/v1/integrations/circuits/{connectionCode}/open
POST /api/internal/v1/integrations/circuits/{connectionCode}/reset
POST /api/internal/v1/integrations/reconciliation/runs
```

# 107. Error Codes

```text
INTEGRATION_RETRY_NOT_ALLOWED
INTEGRATION_RETRY_LIMIT_EXCEEDED
INTEGRATION_TIMEOUT
INTEGRATION_IDEMPOTENCY_CONFLICT
INTEGRATION_DUPLICATE_OPERATION
INTEGRATION_CIRCUIT_OPEN
INTEGRATION_RATE_LIMITED
INTEGRATION_DEAD_LETTERED
INTEGRATION_PARTIAL_FAILURE
INTEGRATION_RECONCILIATION_MISMATCH
INTEGRATION_COMPENSATION_FAILED
INTEGRATION_RECOVERY_FAILED
```

# 108. Retry Checklist

- [ ] Failure classified.
- [ ] Retryable status confirmed.
- [ ] Operation idempotent.
- [ ] Attempt limit configured.
- [ ] Deadline configured.
- [ ] Backoff and jitter configured.
- [ ] Provider quota considered.
- [ ] Circuit state checked.
- [ ] Attempt audited.
- [ ] Dead-letter path configured.

# 109. Reconciliation Checklist

- [ ] Population defined.
- [ ] Local source collected.
- [ ] Remote source collected.
- [ ] Matching keys defined.
- [ ] Eventual-consistency window applied.
- [ ] Differences classified.
- [ ] Severity assigned.
- [ ] Owner assigned.
- [ ] Remediation selected.
- [ ] Verification completed.
- [ ] Evidence retained.

# 110. UAT — Retry & Timeout

- [ ] Transient 503 retries.
- [ ] Validation 400 does not retry.
- [ ] 429 honors bounded Retry-After.
- [ ] Exponential backoff works.
- [ ] Jitter differs between workers.
- [ ] Maximum attempts enforced.
- [ ] Business deadline stops retry.
- [ ] Connect timeout enforced.
- [ ] Total timeout enforced.
- [ ] Retry audit complete.

# 111. UAT — Idempotency

- [ ] First request executes.
- [ ] Duplicate key returns prior result.
- [ ] Same key with different payload rejected.
- [ ] Concurrent duplicate executes once.
- [ ] Failed retryable state can continue.
- [ ] Final failure cannot silently repeat.
- [ ] Tenant-scoped keys isolated.
- [ ] Expiry cleanup works.
- [ ] Business effect occurs once.

# 112. UAT — Circuit Breaker

- [ ] Repeated failures open circuit.
- [ ] Open circuit fails fast.
- [ ] Probe request allowed in half-open.
- [ ] Successful probes close circuit.
- [ ] Failed probe reopens circuit.
- [ ] Manual forced-open works.
- [ ] Alerts generated.
- [ ] Separate providers use separate circuits.
- [ ] Metrics updated.

# 113. UAT — Dead-Letter

- [ ] Max retries creates dead-letter.
- [ ] Poison message isolated.
- [ ] Permanent schema error dead-lettered.
- [ ] Owner assigned.
- [ ] Replay requires root-cause resolution.
- [ ] Replay preserves idempotency.
- [ ] Discard requires reason.
- [ ] High-risk replay requires approval.
- [ ] Evidence retained.

# 114. UAT — Partial Failure

- [ ] Local success/remote unknown detected.
- [ ] Remote success/local failure detected.
- [ ] Provider status query resolves timeout ambiguity.
- [ ] Compensation executes where supported.
- [ ] Non-reversible case opens manual task.
- [ ] Saga state persists.
- [ ] Failed compensation escalates.
- [ ] Correlation maintained.
- [ ] Audit complete.

# 115. UAT — Reconciliation

- [ ] Local missing detected.
- [ ] Remote missing detected.
- [ ] Status mismatch detected.
- [ ] Duplicate remote detected.
- [ ] Duplicate local detected.
- [ ] Late delivery handled.
- [ ] Unknown transaction detected.
- [ ] Auto-remediation works for deterministic case.
- [ ] Manual remediation required for ambiguous mismatch.
- [ ] Verification closes finding.

# 116. UAT — Queue Reliability

- [ ] At-least-once duplicate handled.
- [ ] Acknowledge after durable processing.
- [ ] Visibility timeout extension works.
- [ ] Out-of-order message rejected by version.
- [ ] Backpressure reduces concurrency.
- [ ] Paused consumer resumes safely.
- [ ] Dead-letter queue receives poison message.
- [ ] Partition ordering works.
- [ ] Queue metrics available.

# 117. UAT — Failover & Recovery

- [ ] Primary unhealthy triggers approved failover.
- [ ] Alternate credential valid.
- [ ] Idempotency preserved across providers.
- [ ] Tenant routing remains correct.
- [ ] Failback is controlled.
- [ ] Outstanding operations reconciled.
- [ ] Recovery time measured.
- [ ] Audit and incident evidence retained.

# 118. Definition of Done — SSOT-INTEGRATION-04

SSOT-INTEGRATION-04 dianggap selesai bila:

- [ ] failure taxonomy tersedia;
- [ ] retry policy tersedia;
- [ ] backoff/jitter/budget tersedia;
- [ ] timeout policy tersedia;
- [ ] idempotency model tersedia;
- [ ] duplicate handling tersedia;
- [ ] circuit breaker tersedia;
- [ ] bulkhead and rate-limit handling tersedia;
- [ ] dead-letter governance tersedia;
- [ ] partial failure model tersedia;
- [ ] outbox/inbox guidance tersedia;
- [ ] saga and compensation tersedia;
- [ ] reconciliation model tersedia;
- [ ] replay safety tersedia;
- [ ] recovery/failover tersedia;
- [ ] queue reliability tersedia;
- [ ] incident/evidence tersedia;
- [ ] audit and metrics tersedia;
- [ ] database direction tersedia;
- [ ] API direction tersedia;
- [ ] SDK contracts tersedia;
- [ ] UAT and DoD tersedia.

# 119. Implementation Roadmap

## Phase 1 — Reliability Foundation

- canonical error taxonomy;
- timeout policy;
- retry policy;
- idempotency store;
- operation registry;
- attempt history.

## Phase 2 — Resilience Controls

- circuit breaker;
- bulkheads;
- rate-limit handling;
- backpressure;
- dead-letter;
- alerts.

## Phase 3 — Distributed Transaction Safety

- outbox;
- inbox;
- saga states;
- compensation;
- timeout ambiguity handling;
- provider status queries.

## Phase 4 — Reconciliation & Recovery

- reconciliation engine;
- matching rules;
- findings;
- auto-remediation;
- replay tooling;
- failover/failback.

## Phase 5 — Reliability Platform

- distributed reliability policies;
- automated anomaly detection;
- predictive provider health;
- continuous reconciliation;
- exactly-once-effect simulation;
- reliability dashboard.

# 120. Initial Implementation Backlog

```text
INTEGRATION04-001 Error Taxonomy
INTEGRATION04-002 Retry Policy Engine
INTEGRATION04-003 Timeout Policy
INTEGRATION04-004 Idempotency Store
INTEGRATION04-005 Operation Registry
INTEGRATION04-006 Attempt History
INTEGRATION04-007 Circuit Breaker
INTEGRATION04-008 Bulkhead Manager
INTEGRATION04-009 Dead-Letter Service
INTEGRATION04-010 Outbox/Inbox Foundation
INTEGRATION04-011 Saga Coordinator
INTEGRATION04-012 Compensation Service
INTEGRATION04-013 Reconciliation Engine
INTEGRATION04-014 Replay Service
INTEGRATION04-015 Failover Orchestrator
INTEGRATION04-016 Reliability Dashboard
```

# 121. Approval Gate

Dokumen dapat menjadi Approved setelah:

- Integration Architecture review;
- Event Architecture review;
- Operations/SRE review;
- Security review;
- Data/Transaction Architecture review;
- Audit/Compliance review;
- Business Operations review;
- Quality Engineering review;
- UAT review.

# 122. Closing Statement

Reliable integration bukan berarti semua call selalu berhasil.

Reliable integration berarti setiap kegagalan:

- diklasifikasikan;
- dibatasi;
- tidak menggandakan effect;
- dapat dipulihkan;
- dapat direkonsiliasi;
- dapat dibuktikan.

Retry tanpa idempotency adalah risiko.

Timeout tanpa reconciliation adalah ketidakpastian.

Dead-letter tanpa owner adalah kehilangan data operasional.
