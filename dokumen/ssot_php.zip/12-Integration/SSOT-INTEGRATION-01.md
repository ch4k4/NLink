
# SSOT-INTEGRATION-01 — External Integration Framework

## Status Dokumen

| Item | Nilai |
|---|---|
| Kode | SSOT-INTEGRATION-01 |
| Nama | External Integration Framework |
| Versi | 1.0 |
| Status | Draft Architecture |
| Domain | Platform Kernel / Integration |
| Berlaku Untuk | Multi-tenant, multi-organization, multi-business entity, healthcare, non-healthcare |
| Dependensi | SSOT-API, SSOT-EVENT, SSOT-IAM, SSOT-SCOPE, SSOT-RBAC, SSOT-AUDIT, SSOT-WF, SSOT-NOTIFY, SSOT-DATA |

---

# 1. Tujuan

External Integration Framework adalah standar platform untuk menghubungkan aplikasi dengan sistem eksternal secara aman, andal, dan dapat diaudit.

Contoh integrasi:

- SATUSEHAT
- BPJS Kesehatan
- payment gateway
- WhatsApp provider
- SMS gateway
- email provider
- ERP
- accounting system
- marketplace
- lab/radiology system
- third-party CRM
- partner API
- government reporting system

---

# 2. Prinsip Dasar

## 2.1 Integrasi tidak boleh hardcoded di modul bisnis

Tidak boleh:

```php
Http::post('https://api.partner.com/endpoint', $payload);
```

Harus melalui Integration Framework.

## 2.2 Adapter-based

Setiap sistem eksternal memiliki adapter/connector.

## 2.3 Credential terpusat dan aman

Credential tidak boleh disimpan plain di kode.

## 2.4 Event-driven

Integrasi sebaiknya dipicu oleh event/outbox, bukan langsung dari controller.

## 2.5 Retryable dan observable

Kegagalan integrasi harus dapat diulang, dipantau, dan diaudit.

## 2.6 Scope-aware dan tenant-aware

Setiap credential dan konfigurasi integrasi dapat berbeda per tenant/business entity.

---

# 3. Komponen Framework

```text
integration_connectors
integration_endpoints
integration_credentials
integration_mappings
integration_requests
integration_responses
integration_jobs
integration_failures
integration_webhooks
integration_sync_states
integration_rate_limits
```

---

# 4. Connector

Connector adalah definisi sistem eksternal.

Contoh:

```text
satusehat
bpjs_vclaim
midtrans
xendit
whatsapp_cloud_api
sendgrid
sap_erp
```

---

# 5. Adapter

Adapter adalah class implementasi teknis.

Contoh:

```text
SatusehatConnector
BpjsVClaimConnector
PaymentGatewayConnector
WhatsAppConnector
```

Adapter bertugas:

- auth;
- build payload;
- send request;
- parse response;
- normalize error;
- retry decision;
- audit metadata.

---

# 6. Database — integration_connectors

```sql
CREATE TABLE integration_connectors (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,

    code VARCHAR(100) NOT NULL UNIQUE,
    name VARCHAR(150) NOT NULL,
    description TEXT NULL,

    connector_type ENUM('api','webhook','file','database','message_queue','email','sms','whatsapp') NOT NULL,

    adapter_class VARCHAR(255) NOT NULL,

    status ENUM('active','inactive','deprecated') NOT NULL DEFAULT 'active',

    created_at TIMESTAMP NULL,
    updated_at TIMESTAMP NULL,
    deleted_at TIMESTAMP NULL
);
```

---

# 7. Database — integration_endpoints

```sql
CREATE TABLE integration_endpoints (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,

    connector_id BIGINT UNSIGNED NOT NULL,

    endpoint_code VARCHAR(100) NOT NULL,
    endpoint_name VARCHAR(150) NOT NULL,

    method VARCHAR(10) NULL,
    url_template VARCHAR(500) NOT NULL,

    timeout_seconds INT NOT NULL DEFAULT 30,
    retry_enabled TINYINT(1) NOT NULL DEFAULT 1,
    max_retries INT NOT NULL DEFAULT 3,

    status ENUM('active','inactive') NOT NULL DEFAULT 'active',

    created_at TIMESTAMP NULL,
    updated_at TIMESTAMP NULL,

    UNIQUE KEY uq_integration_endpoint (connector_id, endpoint_code),
    INDEX idx_integration_endpoint_connector (connector_id)
);
```

---

# 8. Database — integration_credentials

```sql
CREATE TABLE integration_credentials (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,

    tenant_id BIGINT UNSIGNED NOT NULL,
    organization_id BIGINT UNSIGNED NULL,
    business_entity_id BIGINT UNSIGNED NULL,

    connector_id BIGINT UNSIGNED NOT NULL,

    credential_name VARCHAR(150) NOT NULL,
    credential_type VARCHAR(50) NOT NULL,

    encrypted_payload TEXT NULL,
    vault_reference VARCHAR(255) NULL,

    status ENUM('active','inactive','revoked','expired') NOT NULL DEFAULT 'active',

    valid_from DATETIME NULL,
    valid_until DATETIME NULL,

    last_used_at DATETIME NULL,
    last_rotation_at DATETIME NULL,
    next_rotation_due_at DATETIME NULL,

    created_by BIGINT UNSIGNED NULL,
    rotated_by BIGINT UNSIGNED NULL,
    revoked_by BIGINT UNSIGNED NULL,
    revoked_at DATETIME NULL,

    created_at TIMESTAMP NULL,
    updated_at TIMESTAMP NULL,
    deleted_at TIMESTAMP NULL,

    INDEX idx_credential_scope (tenant_id, business_entity_id),
    INDEX idx_credential_connector (connector_id),
    INDEX idx_credential_status (status)
);
```

---

# 9. Database — integration_mappings

```sql
CREATE TABLE integration_mappings (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,

    connector_id BIGINT UNSIGNED NOT NULL,

    mapping_code VARCHAR(100) NOT NULL,
    mapping_name VARCHAR(150) NOT NULL,

    source_resource_type VARCHAR(100) NOT NULL,
    target_resource_type VARCHAR(100) NOT NULL,

    mapping_json JSON NOT NULL,
    transform_rules_json JSON NULL,

    version_number INT NOT NULL DEFAULT 1,

    status ENUM('draft','active','deprecated') NOT NULL DEFAULT 'draft',

    created_by BIGINT UNSIGNED NULL,
    approved_by BIGINT UNSIGNED NULL,
    approved_at DATETIME NULL,

    created_at TIMESTAMP NULL,
    updated_at TIMESTAMP NULL,

    UNIQUE KEY uq_integration_mapping (connector_id, mapping_code, version_number)
);
```

---

# 10. Database — integration_requests

```sql
CREATE TABLE integration_requests (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,

    tenant_id BIGINT UNSIGNED NOT NULL,
    business_entity_id BIGINT UNSIGNED NULL,

    connector_id BIGINT UNSIGNED NOT NULL,
    endpoint_id BIGINT UNSIGNED NULL,

    request_uuid CHAR(36) NOT NULL UNIQUE,

    resource_type VARCHAR(100) NULL,
    resource_id BIGINT UNSIGNED NULL,

    method VARCHAR(10) NULL,
    url VARCHAR(500) NULL,

    request_payload_hash CHAR(64) NULL,
    request_payload_snapshot JSON NULL,

    status ENUM('queued','sending','sent','failed','cancelled') NOT NULL DEFAULT 'queued',

    attempts INT NOT NULL DEFAULT 0,
    max_attempts INT NOT NULL DEFAULT 3,

    next_retry_at DATETIME NULL,

    correlation_id VARCHAR(100) NULL,
    causation_id VARCHAR(100) NULL,

    created_by BIGINT UNSIGNED NULL,
    created_at TIMESTAMP NULL,
    updated_at TIMESTAMP NULL,

    INDEX idx_integration_request_scope (tenant_id, business_entity_id),
    INDEX idx_integration_request_status (status, next_retry_at),
    INDEX idx_integration_request_resource (resource_type, resource_id),
    INDEX idx_integration_request_connector (connector_id)
);
```

---

# 11. Database — integration_responses

```sql
CREATE TABLE integration_responses (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,

    integration_request_id BIGINT UNSIGNED NOT NULL,

    status_code INT NULL,
    response_payload_hash CHAR(64) NULL,
    response_payload_snapshot JSON NULL,

    success TINYINT(1) NOT NULL DEFAULT 0,
    external_reference VARCHAR(255) NULL,

    error_code VARCHAR(100) NULL,
    error_message TEXT NULL,

    duration_ms INT NULL,

    received_at DATETIME NOT NULL,

    created_at TIMESTAMP NULL,

    INDEX idx_integration_response_request (integration_request_id),
    INDEX idx_integration_response_success (success),
    INDEX idx_integration_response_external_ref (external_reference)
);
```

---

# 12. Database — integration_jobs

```sql
CREATE TABLE integration_jobs (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,

    tenant_id BIGINT UNSIGNED NOT NULL,
    connector_id BIGINT UNSIGNED NOT NULL,

    job_code VARCHAR(150) NOT NULL,
    job_type ENUM('send','sync','pull','push','retry','reconcile') NOT NULL,

    status ENUM('queued','running','completed','failed','cancelled') NOT NULL DEFAULT 'queued',

    started_at DATETIME NULL,
    completed_at DATETIME NULL,

    summary_json JSON NULL,

    correlation_id VARCHAR(100) NULL,

    created_at TIMESTAMP NULL,
    updated_at TIMESTAMP NULL,

    INDEX idx_integration_job_status (status),
    INDEX idx_integration_job_connector (connector_id)
);
```

---

# 13. Database — integration_failures

```sql
CREATE TABLE integration_failures (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,

    integration_request_id BIGINT UNSIGNED NULL,
    integration_job_id BIGINT UNSIGNED NULL,

    failure_type VARCHAR(100) NOT NULL,
    failure_code VARCHAR(100) NULL,
    failure_message TEXT NOT NULL,

    retryable TINYINT(1) NOT NULL DEFAULT 0,

    occurred_at DATETIME NOT NULL,

    resolved TINYINT(1) NOT NULL DEFAULT 0,
    resolved_by BIGINT UNSIGNED NULL,
    resolved_at DATETIME NULL,
    resolution_note TEXT NULL,

    created_at TIMESTAMP NULL,

    INDEX idx_integration_failure_request (integration_request_id),
    INDEX idx_integration_failure_job (integration_job_id),
    INDEX idx_integration_failure_resolved (resolved)
);
```

---

# 14. Integration Request Flow

```text
Domain Event
→ Integration Handler
→ Resolve connector
→ Resolve credential
→ Build payload
→ Save integration_request
→ Queue send job
→ Send via adapter
→ Save response
→ Publish integration result event
→ Audit
```

---

# 15. Synchronous vs Asynchronous

## Synchronous

Dipakai bila user butuh respons langsung.

Contoh:

```text
cek eligibility
validasi nomor
cek status pembayaran
```

## Asynchronous

Dipakai untuk pengiriman data, webhook, pelaporan, dan sinkronisasi.

Contoh:

```text
send encounter to SATUSEHAT
send invoice to ERP
send notification to WhatsApp provider
```

Default integrasi eksternal sebaiknya async.

---

# 16. Retry Policy

Retry hanya untuk error yang retryable.

Contoh retryable:

```text
timeout
connection failed
HTTP 429
HTTP 500
HTTP 502
HTTP 503
HTTP 504
```

Contoh non-retryable:

```text
HTTP 400 invalid payload
HTTP 401 invalid credential
HTTP 403 forbidden
validation failed
```

---

# 17. Backoff

Gunakan exponential backoff.

Contoh:

```text
1 menit
5 menit
15 menit
1 jam
6 jam
```

---

# 18. Dead Letter

Jika retry habis, request masuk dead-letter/failure queue dan butuh review.

---

# 19. Idempotency

Integrasi harus mendukung idempotency bila memungkinkan.

Header contoh:

```text
Idempotency-Key
X-Correlation-ID
```

Idempotency key dapat berbasis:

```text
resource_type
resource_id
event_uuid
```

---

# 20. Credential Management

Credential harus:

- terenkripsi atau vault-backed;
- punya expiry;
- bisa dirotasi;
- tidak tampil ulang di UI;
- akses credential diaudit.

---

# 21. Mapping & Transformation

Mapping digunakan untuk mengubah data internal ke format eksternal.

Contoh:

```text
internal_patient → satusehat_patient
internal_invoice → erp_invoice
internal_message → whatsapp_template
```

Mapping harus versioned.

---

# 22. Validation

Sebelum kirim:

- validasi required field;
- validasi format target;
- validasi scope;
- validasi credential;
- validasi consent jika komunikasi pasien/customer.

---

# 23. Inbound Integration

Inbound flow:

```text
External request/callback
→ API Gateway
→ Signature/Auth validation
→ Schema validation
→ Idempotency check
→ Save inbound request
→ Process handler
→ Publish domain event
→ Audit
```

---

# 24. Webhook Integration

Webhook mengikuti SSOT-API-04.

Wajib:

- signature;
- timestamp;
- replay protection;
- retry;
- delivery log;
- dead-letter.

---

# 25. File-based Integration

File-based integration digunakan untuk:

- CSV import;
- claim batch;
- report upload;
- legacy system.

Flow:

```text
receive file
→ scan
→ validate
→ parse
→ preview
→ process batch
→ audit
```

---

# 26. Reconciliation

Integrasi penting harus punya rekonsiliasi.

Contoh:

```text
payment status
claim status
SATUSEHAT submission status
inventory sync
```

Reconciliation dapat dijalankan Scheduler.

---

# 27. Integration State

Simpan status sinkronisasi per resource.

Contoh:

```text
pending
sent
accepted
rejected
failed
synced
```

---

# 28. Database — integration_sync_states

```sql
CREATE TABLE integration_sync_states (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,

    tenant_id BIGINT UNSIGNED NOT NULL,
    business_entity_id BIGINT UNSIGNED NULL,

    connector_id BIGINT UNSIGNED NOT NULL,

    resource_type VARCHAR(100) NOT NULL,
    resource_id BIGINT UNSIGNED NOT NULL,

    external_reference VARCHAR(255) NULL,

    sync_status ENUM('pending','sent','accepted','rejected','failed','synced') NOT NULL DEFAULT 'pending',

    last_request_id BIGINT UNSIGNED NULL,
    last_synced_at DATETIME NULL,
    last_error TEXT NULL,

    created_at TIMESTAMP NULL,
    updated_at TIMESTAMP NULL,

    UNIQUE KEY uq_sync_state (connector_id, resource_type, resource_id),
    INDEX idx_sync_status (sync_status),
    INDEX idx_sync_scope (tenant_id, business_entity_id)
);
```

---

# 29. Rate Limiting

Integrasi harus mematuhi rate limit provider.

Rate limit dapat disimpan per connector/endpoint.

---

# 30. Circuit Breaker

Jika provider gagal terus:

```text
circuit open
stop sending temporarily
retry later
alert operator
```

---

# 31. Monitoring

Pantau:

```text
request count
success rate
failure rate
latency
retry count
dead letter count
circuit breaker status
credential expiry
rate limit usage
```

---

# 32. Audit Events

```text
integration.request.created
integration.request.sent
integration.response.received
integration.request.failed
integration.request.retried
integration.request.dead_letter
integration.credential.created
integration.credential.rotated
integration.credential.revoked
integration.mapping.created
integration.mapping.approved
integration.sync.completed
integration.sync.failed
```

---

# 33. Security

Jangan simpan payload sensitif penuh jika tidak perlu.

Gunakan:

```text
payload_hash
masked snapshot
encrypted payload
```

Credential tidak boleh ada di log.

---

# 34. Healthcare Rule

Untuk healthcare:

- PHI minimal di log;
- gunakan consent untuk komunikasi pasien;
- akses payload sensitif dibatasi;
- integrasi regulator harus punya audit lengkap;
- mapping versi wajib.

---

# 35. SATUSEHAT Example

Flow:

```text
encounter.closed
→ satusehat.encounter.ready_to_send
→ build payload
→ send to SATUSEHAT
→ save external reference
→ update sync state
→ audit
```

---

# 36. BPJS Example

Flow:

```text
eligibility.check.requested
→ call BPJS adapter
→ normalize response
→ save result
→ audit
```

---

# 37. Payment Gateway Example

Flow:

```text
invoice.created
→ payment link requested
→ payment gateway adapter
→ callback received
→ invoice.paid event
→ audit
```

---

# 38. WhatsApp Provider Example

Flow:

```text
notification.delivery.queued
→ whatsapp adapter
→ provider response
→ delivery status updated
→ audit
```

---

# 39. Permissions

Contoh permission:

```text
integration.connector.read
integration.connector.manage
integration.credential.manage
integration.mapping.manage
integration.request.read
integration.request.retry
integration.failure.resolve
integration.sync.run
```

---

# 40. API Endpoint

Contoh:

```text
GET /api/v1/integrations/connectors
POST /api/v1/integrations/credentials
GET /api/v1/integrations/requests
POST /api/v1/integrations/requests/{id}/retry
GET /api/v1/integrations/sync-states
```

---

# 41. Event Integration

Integration Framework publish event:

```text
integration.request.sent
integration.response.received
integration.sync.completed
integration.sync.failed
```

---

# 42. Scheduler Integration

Scheduler menjalankan:

- retry;
- reconciliation;
- credential expiry reminder;
- batch sync;
- circuit breaker reset.

---

# 43. Notification Integration

Notification dikirim untuk:

- credential hampir expired;
- integration failed;
- dead-letter bertambah;
- sync rejected;
- provider unavailable.

---

# 44. UAT Scenario

## Scenario 1 — Successful Send

```text
Given event encounter.closed
When integration handler berjalan
Then request dikirim
And response sukses tersimpan
And sync state updated
And audit tercatat
```

## Scenario 2 — Retryable Failure

```text
Given provider timeout
When request gagal
Then status retry
And next_retry_at terisi
```

## Scenario 3 — Non-retryable Failure

```text
Given provider response 400 invalid payload
When request gagal
Then tidak retry
And failure tercatat
```

## Scenario 4 — Credential Expired

```text
Given credential expired
When integration request dibuat
Then request ditolak
And notification operator dikirim
```

## Scenario 5 — Callback Idempotency

```text
Given callback sama diterima dua kali
When diproses
Then efek bisnis hanya terjadi sekali
```

---

# 45. Anti-pattern

Hindari:

```text
HTTP call langsung dari controller
credential hardcoded
retry tanpa batas
payload sensitif di log
mapping tidak versioned
callback tidak idempotent
integrasi tanpa audit
semua provider dianggap sama
tidak ada reconciliation
```

---

# 46. Definition of Done

External Integration Framework dianggap siap bila:

- connector registry tersedia;
- adapter pattern tersedia;
- credential secure tersedia;
- mapping versioned tersedia;
- request/response log tersedia;
- retry dan dead-letter tersedia;
- sync state tersedia;
- inbound callback idempotent;
- webhook signature didukung;
- scheduler reconciliation tersedia;
- monitoring tersedia;
- audit lengkap;
- healthcare privacy rule diterapkan;
- mendukung SATUSEHAT/BPJS/payment/notification provider dan non-healthcare provider.
