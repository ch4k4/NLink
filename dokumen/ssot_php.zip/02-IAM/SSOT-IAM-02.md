# SSOT-IAM-02 — Authentication Architecture

## Status Dokumen

| Item | Nilai |
|---|---|
| Kode Dokumen | SSOT-IAM-02 |
| Nama | Authentication Architecture |
| Versi | 1.0 |
| Status | Draft Architecture |
| Domain | Platform Kernel / IAM |
| Dependensi | SSOT-IAM-01, SSOT-SCOPE, SSOT-RBAC, SSOT-AUDIT |

---

# 1. Tujuan

Authentication Architecture mendefinisikan mekanisme platform untuk memastikan bahwa hanya identitas yang valid yang dapat masuk ke aplikasi.

Dokumen ini mencakup:

- login;
- logout;
- password policy;
- password hashing;
- failed login;
- account lockout;
- reset password;
- email/phone verification;
- login audit;
- authentication untuk human user dan non-human user.

---

# 2. Prinsip Dasar

## 2.1 Authentication bukan Authorization

Authentication menjawab:

```text
Siapa user ini?
```

Authorization / RBAC menjawab:

```text
Apa yang boleh user ini lakukan?
```

Scope menjawab:

```text
Data wilayah mana yang boleh diakses?
```

## 2.2 Login tidak otomatis berarti boleh transaksi

Setelah login berhasil, sistem tetap harus:

```text
resolve scope
validate scope
load roles
check permissions
build menu
```

## 2.3 Semua login diaudit

Wajib mencatat:

```text
login success
login failed
logout
lockout
password reset
password changed
```

## 2.4 Password tidak pernah disimpan plain

Simpan hanya `password_hash`.

## 2.5 Token reset tidak pernah disimpan plain

Simpan hanya hash token.

---

# 3. Authentication Flow

```text
User submit login
→ Validate input
→ Find user by tenant + username/email
→ Check user status
→ Check lockout
→ Verify password
→ Reset failed counter
→ Create session
→ Resolve scope
→ Audit auth.login.success
→ Redirect dashboard
```

Jika gagal:

```text
Login failed
→ Increment failed counter bila user ditemukan
→ Audit auth.login.failed
→ Lock account bila melewati threshold
→ Return generic error
```

Error tidak boleh membocorkan apakah email/username terdaftar.

---

# 4. Login Identifier

Platform mendukung login menggunakan:

```text
username
email
phone
SSO provider
API client credential
service account credential
```

Namun untuk fase awal:

```text
username/email + password
```

---

# 5. User Status Check

User hanya boleh login bila:

```text
status = active
AND deleted_at IS NULL
AND locked_until IS NULL OR locked_until < NOW()
```

Status yang ditolak:

```text
pending
invited
suspended
locked
disabled
terminated
archived
```

---

# 6. Password Hashing

Gunakan algoritma password hashing modern.

Rekomendasi:

```text
Argon2id
```

Alternatif:

```text
bcrypt
```

Tidak boleh:

```text
MD5
SHA1
SHA256 plain
base64
custom encryption
```

Kolom:

```text
password_hash
password_changed_at
must_change_password
```

---

# 7. Password Policy

Minimum policy:

```text
minimal 12 karakter untuk privileged user
minimal 8 karakter untuk user biasa
tidak boleh sama dengan username/email
tidak boleh memakai password umum
tidak boleh memakai password terakhir
```

Recommended:

```text
password strength meter
breached password check
password history
force change after reset
```

---

# 8. Password History

Tabel:

```sql
CREATE TABLE user_password_histories (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id BIGINT UNSIGNED NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    changed_at DATETIME NOT NULL,
    changed_by BIGINT UNSIGNED NULL,
    reason VARCHAR(100) NULL,
    created_at TIMESTAMP NULL,

    INDEX idx_password_history_user (user_id)
);
```

Rule:

- simpan 5–10 hash terakhir;
- user tidak boleh memakai ulang password terakhir;
- password lama tidak boleh bisa dipulihkan.

---

# 9. Failed Login

Tambahkan pada users:

```text
failed_login_count
locked_until
last_failed_login_at
last_failed_login_ip
```

Aturan default:

```text
5 gagal login → lock 15 menit
10 gagal login → lock 1 jam
>10 gagal login → butuh admin unlock atau step-up verification
```

---

# 10. Login Attempts Table

```sql
CREATE TABLE login_attempts (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,

    tenant_id BIGINT UNSIGNED NULL,
    user_id BIGINT UNSIGNED NULL,

    login_identifier VARCHAR(150) NULL,
    result ENUM('success','failed','locked','blocked') NOT NULL,

    failure_reason VARCHAR(100) NULL,

    ip_address VARCHAR(45) NULL,
    user_agent TEXT NULL,
    device_fingerprint VARCHAR(255) NULL,

    correlation_id VARCHAR(100) NULL,

    created_at TIMESTAMP NULL,

    INDEX idx_login_attempt_user (user_id),
    INDEX idx_login_attempt_identifier (login_identifier),
    INDEX idx_login_attempt_ip (ip_address),
    INDEX idx_login_attempt_created (created_at)
);
```

---

# 11. Account Lockout

Lockout terjadi karena:

```text
failed login threshold
suspicious activity
admin action
security policy
```

Event audit:

```text
auth.account.locked
auth.account.unlocked
```

Unlock dapat dilakukan oleh:

```text
auto expiry
security admin
password reset completion
```

---

# 12. Generic Error Message

Jangan tampilkan:

```text
Email tidak terdaftar
Password salah untuk user ini
Akun ada tapi disabled
```

Gunakan:

```text
Username/email atau password tidak valid.
```

Untuk status disabled, boleh tampilkan pesan generik:

```text
Akun tidak dapat digunakan. Hubungi administrator.
```

---

# 13. Password Reset Flow

```text
User request reset
→ Input email/username
→ Generate token
→ Store token hash
→ Send reset link
→ Audit auth.password.reset.requested
→ User opens link
→ Validate token hash + expiry
→ Set new password
→ Revoke old sessions
→ Mark token used
→ Audit auth.password.reset.completed
```

---

# 14. Password Reset Tokens

```sql
CREATE TABLE password_reset_tokens (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,

    tenant_id BIGINT UNSIGNED NOT NULL,
    user_id BIGINT UNSIGNED NOT NULL,

    token_hash VARCHAR(255) NOT NULL,
    status ENUM('active','used','expired','revoked') NOT NULL DEFAULT 'active',

    requested_ip VARCHAR(45) NULL,
    requested_user_agent TEXT NULL,

    expires_at DATETIME NOT NULL,
    used_at DATETIME NULL,
    revoked_at DATETIME NULL,

    created_at TIMESTAMP NULL,
    updated_at TIMESTAMP NULL,

    INDEX idx_prt_user_status (user_id, status),
    INDEX idx_prt_token_hash (token_hash),
    INDEX idx_prt_expiry (expires_at)
);
```

Rule:

- token asli tidak disimpan;
- token hanya berlaku satu kali;
- expiry default 15–60 menit;
- reset password mencabut session lama.

---

# 15. Change Password Flow

```text
User authenticated
→ Input current password
→ Verify current password
→ Validate new password policy
→ Save new hash
→ Save password history
→ Revoke other sessions
→ Audit auth.password.changed
```

Privileged user dapat diminta MFA/step-up.

---

# 16. Must Change Password

Kondisi:

```text
password dibuat admin
password reset admin
password expired by policy
password compromise suspected
```

Saat `must_change_password = 1`, user hanya boleh mengakses halaman ganti password.

---

# 17. Email Verification

```sql
CREATE TABLE email_verification_tokens (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,

    tenant_id BIGINT UNSIGNED NOT NULL,
    user_id BIGINT UNSIGNED NOT NULL,

    email VARCHAR(150) NOT NULL,
    token_hash VARCHAR(255) NOT NULL,

    status ENUM('active','used','expired','revoked') NOT NULL DEFAULT 'active',

    expires_at DATETIME NOT NULL,
    used_at DATETIME NULL,

    created_at TIMESTAMP NULL,
    updated_at TIMESTAMP NULL,

    INDEX idx_evt_user_status (user_id, status),
    INDEX idx_evt_token_hash (token_hash)
);
```

---

# 18. Logout Flow

```text
User clicks logout
→ Revoke current session
→ Clear session cookie
→ Audit auth.logout
→ Redirect login
```

Logout harus aman walaupun session sudah expired.

---

# 19. Service Account Authentication

Service account tidak memakai login UI.

Metode:

```text
client credential
signed token
internal secret
mTLS
```

Detail credential dibuat di SSOT-IAM-05.

Rule:

- wajib scope;
- wajib role minimum;
- wajib audit;
- tidak boleh memakai akun manusia.

---

# 20. API Client Authentication

API client memakai credential khusus.

Event audit:

```text
auth.api_client.authenticated
auth.api_client.failed
auth.api_client.revoked
```

Jangan mencampur API client secret dengan password user manusia.

---

# 21. Authentication Audit Events

Wajib:

```text
auth.login.success
auth.login.failed
auth.logout
auth.password.changed
auth.password.reset.requested
auth.password.reset.completed
auth.account.locked
auth.account.unlocked
auth.email.verified
auth.token.expired
auth.session.revoked
```

Audit menyimpan:

```text
actor_user_id
login_identifier
tenant_id
result
failure_reason
ip_address
user_agent
correlation_id
created_at
```

---

# 22. Rate Limiting

Rate limit pada:

```text
login
password reset request
email verification resend
MFA challenge
API client auth
```

Basis rate limit:

```text
IP
tenant
login_identifier
device fingerprint
```

---

# 23. Security Controls

Minimum:

- CSRF untuk form login berbasis web;
- secure cookie;
- HttpOnly cookie;
- SameSite cookie;
- HTTPS only;
- password hash kuat;
- generic error;
- failed login throttle;
- audit login;
- session regeneration after login;
- no password in logs.

---

# 24. Anti-Pattern

Hindari:

```text
password plain
password di log
token reset plain di database
pesan error membocorkan user terdaftar
akun admin bersama
service account login UI
tanpa lockout
tanpa audit login
login langsung bypass scope
```

---

# 25. UAT Scenario

## Scenario 1 — Login Berhasil

```text
Given user active
And password benar
When login
Then session dibuat
And scope resolved
And audit auth.login.success tercatat
```

## Scenario 2 — Password Salah

```text
Given user active
When password salah
Then login ditolak
And failed_login_count bertambah
And audit auth.login.failed tercatat
```

## Scenario 3 — Lockout

```text
Given user gagal login 5 kali
When login berikutnya
Then akun locked sementara
And audit auth.account.locked tercatat
```

## Scenario 4 — Reset Password

```text
Given user request reset
When token valid digunakan
Then password berubah
And session lama dicabut
And audit auth.password.reset.completed tercatat
```

## Scenario 5 — Must Change Password

```text
Given must_change_password = 1
When user login
Then user diarahkan ke halaman ganti password
And tidak bisa akses transaksi
```

---

# 26. Definition of Done

Authentication dianggap siap bila:

- login username/email berjalan;
- password hash aman;
- failed login tercatat;
- lockout berjalan;
- reset password aman;
- token disimpan hash;
- generic error message diterapkan;
- session dibuat aman;
- scope resolve setelah login;
- semua event auth diaudit;
- service account tidak bisa login UI;
- rate limit tersedia.
