# SSOT-IAM-03 --- Session Management Architecture

## Status

-   Kode: SSOT-IAM-03
-   Domain: Platform Kernel / IAM
-   Dependensi: SSOT-IAM-01, SSOT-IAM-02, Scope, RBAC, Audit

------------------------------------------------------------------------

# 1. Tujuan

Menyediakan arsitektur manajemen session yang aman, dapat diaudit,
multi-device, dan siap untuk aplikasi web, mobile, API, serta service
account.

------------------------------------------------------------------------

# 2. Prinsip

-   Session terpisah dari autentikasi.
-   Setiap session memiliki identitas unik.
-   Session selalu terikat pada user, device, dan tenant.
-   Session dibuat setelah login berhasil.
-   Session dicabut saat logout, password reset, atau akun
    dinonaktifkan.

------------------------------------------------------------------------

# 3. Session Lifecycle

``` text
Created
→ Active
→ Refreshed
→ Idle
→ Expired
→ Revoked
→ Archived
```

------------------------------------------------------------------------

# 4. Komponen

-   user_sessions
-   session_devices
-   refresh_tokens
-   session_events
-   session_revocations

------------------------------------------------------------------------

# 5. user_sessions

Kolom minimum:

``` text
session_uuid
user_id
tenant_id
device_id
ip_address
user_agent
login_at
last_activity_at
expires_at
status
correlation_id
```

Status:

``` text
active
expired
revoked
terminated
```

------------------------------------------------------------------------

# 6. Device Binding

Session terhubung ke:

-   device_id
-   platform
-   browser/app
-   IP terakhir

Trusted device dapat ditandai terpisah.

------------------------------------------------------------------------

# 7. Timeout Policy

-   Idle timeout (mis. 30 menit)
-   Absolute timeout (mis. 12 jam)
-   Remember me memiliki batas maksimum tersendiri.
-   Timeout dapat berbeda untuk role berisiko tinggi.

------------------------------------------------------------------------

# 8. Concurrent Session

Kebijakan dapat dikonfigurasi:

-   satu session saja
-   maksimal N session
-   tidak terbatas

Jika melebihi batas:

-   tolak login baru; atau
-   cabut session lama.

------------------------------------------------------------------------

# 9. Session Refresh

Setiap aktivitas memperbarui:

``` text
last_activity_at
```

Refresh tidak mengubah:

``` text
login_at
session_uuid
```

------------------------------------------------------------------------

# 10. Session Revocation

Dicabut ketika:

-   logout
-   password berubah
-   reset password
-   akun disabled
-   role keamanan memaksa logout
-   aktivitas mencurigakan

------------------------------------------------------------------------

# 11. Refresh Token

Refresh token:

-   disimpan dalam bentuk hash
-   memiliki expiry
-   one-time rotation
-   dicabut bersama session

------------------------------------------------------------------------

# 12. Session Audit

Event:

``` text
auth.session.created
auth.session.refreshed
auth.session.revoked
auth.session.expired
auth.session.concurrent_detected
```

------------------------------------------------------------------------

# 13. Security

-   Secure cookie
-   HttpOnly
-   SameSite
-   Session ID acak kriptografis
-   Regenerate session setelah login

------------------------------------------------------------------------

# 14. Integration

Setelah session aktif:

``` text
Load active scope
Load active role
Load permissions
Build menu
```

------------------------------------------------------------------------

# 15. UAT

-   Login membuat session.
-   Logout mencabut session.
-   Password reset mencabut seluruh session.
-   Idle timeout bekerja.
-   Concurrent session sesuai kebijakan.

------------------------------------------------------------------------

# 16. Definition of Done

-   Multi-device didukung.
-   Revocation tersedia.
-   Idle & absolute timeout tersedia.
-   Audit seluruh lifecycle session.
-   Scope dan RBAC dimuat dari session aktif.
