# SSOT-IAM-07 — Identity Lifecycle Provisioning & Deprovisioning

---

## Status Dokumen

| Item | Nilai |
|---|---|
| Kode | SSOT-IAM-07 |
| Judul | Identity Lifecycle Provisioning & Deprovisioning |
| Versi | 1.0 |
| Status | Draft Architecture |
| Domain | Platform Kernel |
| Kategori | Identity Governance, Provisioning & Lifecycle |
| Cakupan | Joiner, Mover, Leaver, Provisioning, Transfer, Suspension, Termination, Deprovisioning, Orphan Cleanup, Reconciliation |
| Bergantung pada | SSOT-GOV-01, SSOT-GOV-04, SSOT-GOV-05, SSOT-SCOPE-01, SSOT-IAM-01, SSOT-IAM-02, SSOT-IAM-03, SSOT-IAM-04, SSOT-IAM-05, SSOT-IAM-06, SSOT-RBAC-04, SSOT-RBAC-05, SSOT-RBAC-07, SSOT-RBAC-08, SSOT-AUDIT-01, SSOT-EVENT-01, SSOT-WF-01, SSOT-NOTIFY-01, SSOT-TEST-01 |
| Target Stack | PHP 8.1+, PDO, MySQL 8/MariaDB, Queue/Event-ready |
| Target Evolusi | SCIM, HRIS-driven Provisioning, Event-Driven Identity Lifecycle, Continuous Reconciliation |

---

# 1. Executive Summary

SSOT-IAM-07 menetapkan governance resmi untuk lifecycle identity dari joiner, mover, leaver, temporary worker, external user, service identity, dan account recovery-related state transitions.

Dokumen ini mengatur:

- identity source;
- authoritative source;
- identity creation;
- account provisioning;
- invitation;
- activation;
- initial credential;
- verification;
- role assignment;
- scope assignment;
- transfer;
- promotion;
- demotion;
- organizational change;
- clinic/department movement;
- temporary assignment;
- leave of absence;
- suspension;
- termination;
- deactivation;
- deprovisioning;
- session revocation;
- token revocation;
- privileged access revocation;
- external account cleanup;
- orphan account detection;
- dormant account handling;
- service account lifecycle;
- identity reconciliation;
- lifecycle events;
- audit;
- metrics;
- database direction;
- API direction;
- SDK contracts;
- UAT;
- Definition of Done;
- implementation roadmap.

Tujuan akhirnya adalah memastikan identity:

- dibuat dari sumber yang sah;
- memiliki owner;
- memiliki lifecycle state yang jelas;
- menerima akses minimum;
- mengikuti perubahan organisasi;
- kehilangan akses secara tepat waktu;
- tidak meninggalkan orphan account;
- dapat direkonsiliasi;
- dapat diaudit.

---

# 2. Objectives

Framework harus:

- menyediakan canonical identity lifecycle;
- mendukung joiner–mover–leaver;
- memastikan provisioning tepat dan minimal;
- memastikan deprovisioning tepat waktu;
- menjaga tenant dan organization scope;
- mencegah orphan/stale accounts;
- mencabut sessions dan grants;
- mendukung external identities;
- mendukung service identities;
- menyediakan reconciliation dan evidence.

---

# 3. Core Principles

```text
Authoritative Source Drives Lifecycle
Least Privilege at Provisioning
Access Follows Employment or Engagement State
Mover Events Recalculate Access
Leaver Events Revoke Access Immediately
Suspension Is Reversible, Termination Is Final
No Orphan Accounts
No Access Without Owner
Every Lifecycle Change Must Be Auditable
Reconciliation Detects Drift
```

---

# 4. Scope

Framework berlaku untuk:

```text
Employees
Contractors
Nurses
Doctors
Administrative Staff
Tenant Administrators
External Support
Partners
Temporary Workers
Service Accounts
Machine Identities
Break-Glass Accounts
```

---

# 5. Non-Scope

Dokumen ini tidak menggantikan:

- HR policy;
- payroll;
- legal employment process;
- full identity proofing;
- authentication protocol implementation;
- RBAC permission catalog.

---

# 6. Identity Lifecycle States

```text
PROPOSED
INVITED
PENDING_VERIFICATION
ACTIVE
SUSPENDED
ON_LEAVE
TRANSFER_PENDING
TERMINATED
DEPROVISIONING
DEPROVISIONED
RETIRED
REJECTED
```

---

# 7. State Semantics

## 7.1 Proposed

Identity record diajukan namun belum diundang.

## 7.2 Invited

Invitation telah dikirim.

## 7.3 Pending Verification

Identity belum menyelesaikan verification.

## 7.4 Active

Identity dapat beroperasi sesuai assigned access.

## 7.5 Suspended

Access diblokir sementara.

## 7.6 On Leave

Identity berada dalam status cuti dengan policy akses terbatas.

## 7.7 Transfer Pending

Perubahan organisasi/scope sedang diproses.

## 7.8 Terminated

Hubungan kerja/engagement berakhir.

## 7.9 Deprovisioning

Access removal sedang berlangsung.

## 7.10 Deprovisioned

Account dan access telah dicabut sesuai policy.

## 7.11 Retired

Record dipertahankan untuk audit/history, tidak dapat diaktifkan ulang tanpa proses baru.

---

# 8. Lifecycle Actors

```text
HR_SOURCE
TENANT_ADMIN
IAM_ADMIN
MANAGER
SECURITY_ADMIN
SYSTEM_AUTOMATION
SERVICE_OWNER
AUDITOR
```

---

# 9. Authoritative Sources

Possible sources:

```text
HRIS
Tenant Master Data
Approved Admin Workflow
External Identity Provider
Service Registry
Contractor Management System
```

---

# 10. Source Priority

Authoritative source precedence harus deterministic.

---

# 11. Identity Correlation

Correlation menggunakan stable identifiers, bukan hanya email.

---

# 12. Identity Correlation Fields

```text
employee_id
external_subject_id
tenant_person_id
provider_subject
email
phone
national_identifier_hash
```

---

# 13. Duplicate Identity Prevention

System harus memeriksa:

- existing active identity;
- aliases;
- external provider mapping;
- employee/contractor ID;
- tenant-specific person record.

---

# 14. Identity Ownership

Human identity memiliki accountable organizational owner.

Service identity memiliki technical dan business owner.

---

# 15. Joiner Lifecycle

```text
Source Event
→ Identity Match
→ Approval
→ Create Identity
→ Provision Account
→ Assign Baseline Access
→ Verify
→ Activate
→ Notify
```

---

# 16. Joiner Minimum Data

```text
legal/display name
identity source
tenant
organization
clinic/department
employment/engagement type
start date
manager/owner
contact channel
job function
```

---

# 17. Pre-Start Provisioning

Dapat dilakukan sebelum start date, tetapi activation harus dibatasi.

---

# 18. Start Date Enforcement

Account tidak boleh aktif sebelum approved start time kecuali exception.

---

# 19. Baseline Access

Baseline access berasal dari:

- job function;
- tenant;
- organization;
- clinic;
- department;
- employment type;
- module entitlement.

---

# 20. Birthright Access

Birthright access harus minimal dan direview.

---

# 21. Invitation

Invitation harus:

- time-bound;
- single-use where possible;
- tenant-bound;
- recipient-bound;
- auditable;
- revocable.

---

# 22. Initial Verification

May include:

- email verification;
- phone verification;
- IdP verification;
- manager confirmation;
- identity proofing for high-risk roles.

---

# 23. Initial Credential

No plaintext password delivery.

Prefer:

- invitation-based setup;
- federated login;
- temporary one-time setup;
- passwordless enrollment.

---

# 24. MFA Enrollment

Required based on role/risk.

---

# 25. Activation Preconditions

- source valid;
- identity unique;
- start date reached;
- verification complete;
- owner assigned;
- tenant/scope valid;
- access approved;
- MFA enrolled where required.

---

# 26. Mover Lifecycle

Mover includes:

```text
organization transfer
clinic transfer
department transfer
job function change
promotion
demotion
manager change
employment type change
tenant reassignment
temporary assignment
```

---

# 27. Mover Flow

```text
Change Event
→ Validate
→ Calculate Delta
→ SoD Check
→ Approve
→ Apply Scope/Role Changes
→ Revoke Old Access
→ Notify
→ Reconcile
```

---

# 28. Access Delta

Delta must distinguish:

```text
ADD
RETAIN
MODIFY_SCOPE
REMOVE
TEMPORARY
REVIEW_REQUIRED
```

---

# 29. Old Access Removal

Old access must not persist by default after mover event.

---

# 30. Grace Period

Grace period requires explicit policy, expiry, and approval.

---

# 31. Temporary Dual Access

May be allowed for handover but must be:

- time-bound;
- approved;
- SoD checked;
- monitored;
- auto-expiring.

---

# 32. Scope Recalculation

Mover event recalculates:

- tenant;
- organization;
- clinic;
- department;
- resource scope;
- menu projection;
- workflow assignments.

---

# 33. Role Recalculation

Role assignment must be reevaluated, not copied blindly.

---

# 34. Promotion

Promotion may add access but still requires least privilege and SoD validation.

---

# 35. Demotion

Demotion must remove no-longer-appropriate access immediately.

---

# 36. Leave of Absence

Possible policies:

```text
FULL_SUSPENSION
LIMITED_ACCESS
READ_ONLY
NO_CHANGE_APPROVED
```

---

# 37. Leave Start

At leave start:

- sessions may be revoked;
- privileged grants revoked;
- external access suspended;
- ownership delegated.

---

# 38. Leave Return

Requires revalidation before reactivation.

---

# 39. Suspension

Suspension is immediate and reversible.

---

# 40. Suspension Triggers

- security incident;
- HR request;
- compliance issue;
- inactivity;
- suspected compromise;
- failed verification;
- manager request;
- contract pause.

---

# 41. Suspension Effects

- block authentication;
- revoke active sessions;
- revoke refresh tokens;
- suspend temporary grants;
- stop privileged sessions;
- disable API tokens where owned;
- preserve account data;
- preserve audit.

---

# 42. Emergency Suspension

Security may suspend immediately without normal workflow, followed by review.

---

# 43. Reactivation

Requires:

- active source status;
- owner;
- reason;
- risk review;
- access recalculation;
- credential/MFA validation.

---

# 44. Leaver Lifecycle

```text
Termination Event
→ Immediate Access Block
→ Revoke Sessions/Tokens
→ Revoke Roles/Scopes/Grants
→ Disable External Accounts
→ Transfer Ownership
→ Archive Data
→ Deprovision
→ Reconcile
→ Close
```

---

# 45. Termination Types

```text
PLANNED
IMMEDIATE
INVOLUNTARY
CONTRACT_END
VENDOR_END
SECURITY_TERMINATION
DECEASED
```

---

# 46. Effective Time

Termination action should support exact effective timestamp.

---

# 47. Immediate Termination

Must prioritize access revocation before notification where appropriate.

---

# 48. Planned Termination

Can schedule deprovisioning at end date/time.

---

# 49. Access Revocation

Must cover:

- password login;
- federated sessions;
- local sessions;
- refresh tokens;
- API keys;
- personal access tokens;
- temporary grants;
- privileged access;
- delegated access;
- device sessions;
- external systems.

---

# 50. Ownership Transfer

Transfer ownership of:

- open tasks;
- workflows;
- cases;
- reports;
- service accounts;
- integrations;
- documents;
- scheduled jobs.

---

# 51. Data Preservation

User-generated business records remain under data retention rules.

---

# 52. Account Deletion

Human account record should normally be retained as deprovisioned/retired for audit.

---

# 53. Personal Data Minimization

After retention needs are met, identity profile may be minimized or anonymized according to DATA-06.

---

# 54. Deprovisioning SLA

Suggested:

| Risk | Target |
|---|---:|
| Critical/Privileged | Immediate |
| Standard Employee | Minutes to hours |
| Contractor End | At exact expiry |
| Dormant Account | According to review policy |

---

# 55. Deprovisioning Status

```text
REQUESTED
IN_PROGRESS
PARTIALLY_COMPLETED
COMPLETED
FAILED
BLOCKED
RETRYING
```

---

# 56. Partial Deprovisioning

Must generate finding and retry/escalation.

---

# 57. External Account Deprovisioning

Connectors must support:

- disable;
- remove groups;
- revoke tokens;
- remove licenses where applicable;
- confirm status.

---

# 58. SCIM Direction

SCIM may be used for provisioning/deprovisioning external systems.

---

# 59. Service Account Lifecycle

Service accounts require:

- owner;
- purpose;
- environment;
- scope;
- credential policy;
- review date;
- expiry or exception;
- no human interactive login.

---

# 60. Service Account Creation

Requires approval and registration.

---

# 61. Service Account Ownership Change

Must update owner and review access.

---

# 62. Service Account Dormancy

Dormant service accounts should be disabled after review.

---

# 63. Service Account Retirement

Requires dependency and job/integration impact analysis.

---

# 64. External User Lifecycle

External users require:

- sponsor;
- tenant;
- purpose;
- start/end dates;
- limited scope;
- periodic review;
- auto-expiry.

---

# 65. Contractor Lifecycle

Contractors should default to time-bound access.

---

# 66. Sponsor Responsibility

Sponsor confirms continued need and scope.

---

# 67. Dormant Account

Dormant account defined by no successful use within policy threshold.

---

# 68. Dormancy Threshold

Examples:

```text
30 days privileged
60 days external
90 days standard
```

---

# 69. Dormant Account Actions

```text
NOTIFY
REVIEW
SUSPEND
DEPROVISION
EXEMPT_WITH_EXPIRY
```

---

# 70. Orphan Account

Account with no valid source, owner, or linked identity.

---

# 71. Orphan Detection

Compare:

- IAM registry;
- HR/source systems;
- IdP;
- local accounts;
- external systems;
- service registry;
- active role assignments.

---

# 72. Orphan Remediation

```text
ASSIGN_OWNER
LINK_IDENTITY
SUSPEND
DEPROVISION
INVESTIGATE
```

---

# 73. Duplicate Account

Duplicate identities must be merged or retired with audit preservation.

---

# 74. Rehire

Rehire should not blindly reactivate old access.

Flow:

```text
Match Historical Identity
→ Validate New Engagement
→ Recalculate Access
→ Reverify Credentials/MFA
→ Activate New Lifecycle Episode
```

---

# 75. Identity Lifecycle Episode

Each employment/engagement period should be tracked separately.

---

# 76. Identity Source Change

Provider/source migration must preserve stable internal identity.

---

# 77. Email Change

Email is mutable attribute, not primary identity key.

---

# 78. Name Change

Name changes must not create new identity.

---

# 79. Tenant Transfer

Cross-tenant transfer is high risk and typically modeled as old tenant deprovision + new tenant provisioning.

---

# 80. Cross-Tenant Access

Must be explicit and time-bound where required.

---

# 81. Manager Change

Manager change may trigger approval-path recalculation.

---

# 82. Delegations

Delegations owned by departing user must be revoked or transferred.

---

# 83. Workflow Assignments

Open human tasks must be reassigned.

---

# 84. Notification

Lifecycle notifications must avoid sensitive detail and follow policy.

---

# 85. Identity Events

```text
IAM_IDENTITY_PROPOSED
IAM_IDENTITY_INVITED
IAM_IDENTITY_ACTIVATED
IAM_IDENTITY_MOVED
IAM_IDENTITY_SCOPE_CHANGED
IAM_IDENTITY_SUSPENDED
IAM_IDENTITY_REACTIVATED
IAM_IDENTITY_TERMINATED
IAM_IDENTITY_DEPROVISION_STARTED
IAM_IDENTITY_DEPROVISIONED
IAM_IDENTITY_ORPHAN_DETECTED
IAM_IDENTITY_REHIRED
```

---

# 86. Event Metadata

```text
identity_id
lifecycle_episode_id
tenant_id
source
effective_at
previous_state
new_state
reason
correlation_id
```

---

# 87. Idempotency

Lifecycle events and provisioning commands must be idempotent.

---

# 88. Event Ordering

Out-of-order events must be detected and handled.

---

# 89. Effective-Dated Changes

Changes may be scheduled with `effective_from`.

---

# 90. Retroactive Changes

Retroactive source corrections require controlled reconciliation, not silent overwrite.

---

# 91. Provisioning Policy

Policy inputs:

- identity type;
- job function;
- tenant;
- organization;
- clinic;
- employment type;
- module entitlement;
- risk;
- start/end date.

---

# 92. Policy Output

```text
baseline roles
scope assignments
required MFA
allowed modules
access expiry
review schedule
```

---

# 93. Manual Access

Manual access must remain governed by RBAC and expiry where appropriate.

---

# 94. Self-Service

Self-service can update limited attributes but not authoritative employment/scope attributes.

---

# 95. Administrative Override

Override requires permission, reason, audit, and expiry where temporary.

---

# 96. Provisioning Reconciliation

Compare desired state and actual state.

---

# 97. Desired State

Derived from:

- authoritative source;
- lifecycle state;
- access policy;
- approved exceptions;
- temporary grants.

---

# 98. Actual State

Includes:

- account status;
- role assignments;
- scope assignments;
- active sessions;
- tokens;
- external accounts;
- service ownership.

---

# 99. Drift Types

```text
MISSING_ACCOUNT
UNEXPECTED_ACCOUNT
MISSING_ACCESS
EXCESS_ACCESS
STALE_SCOPE
ACTIVE_AFTER_TERMINATION
ORPHAN_ACCOUNT
EXPIRED_EXTERNAL_ACCESS
SESSION_REVOCATION_FAILED
```

---

# 100. Reconciliation Frequency

- event-driven;
- hourly for critical systems;
- daily general;
- before/after major migration;
- after incident.

---

# 101. Reconciliation Action

```text
AUTO_REMEDIATE
CREATE_CASE
SUSPEND
NOTIFY_OWNER
REQUIRE_REVIEW
```

---

# 102. Fail-Closed

If identity state is terminated/suspended, access must fail closed even if downstream cleanup is incomplete.

---

# 103. Lifecycle Workflow

Use workflow for:

- approvals;
- transfer;
- exception;
- termination;
- ownership transfer;
- failed deprovisioning.

---

# 104. Maker-Checker

High-risk provisioning and privileged assignment require independent approval.

---

# 105. SoD Integration

Mover/joiner access must pass SoD checks.

---

# 106. Privileged Access Integration

Permanent privileged assignment should be minimized; use RBAC-08 JIT where possible.

---

# 107. Session Revocation

Lifecycle changes should trigger immediate revocation when policy requires.

---

# 108. Cache Invalidation

Identity status, role, scope, menu, and policy caches must invalidate.

---

# 109. Device Management

Managed device access may need disable/wipe workflow outside core IAM.

---

# 110. API Tokens

Personal tokens owned by identity must be revoked on suspension/termination.

---

# 111. MFA Factors

MFA factors should be disabled or removed on deprovisioning.

---

# 112. Recovery Methods

Recovery methods must be invalidated on termination.

---

# 113. Federation

Federated account state must synchronize with external IdP where supported.

---

# 114. Local Fallback Account

Local fallback account must not bypass terminated identity state.

---

# 115. Break-Glass Accounts

Break-glass lifecycle follows RBAC-08 and independent ownership/review.

---

# 116. Privacy

Identity lifecycle records follow DATA-06 retention and minimization.

---

# 117. Audit

Every lifecycle state change and access delta must be auditable.

---

# 118. Audit Metadata

```text
identity_id
source
actor
effective_time
old_state
new_state
roles_added
roles_removed
scopes_added
scopes_removed
sessions_revoked
external_actions
correlation_id
```

---

# 119. Metrics

```text
iam_joiner_total
iam_mover_total
iam_leaver_total
iam_provisioning_duration_seconds
iam_deprovisioning_duration_seconds
iam_deprovision_failure_total
iam_orphan_account_total
iam_dormant_account_total
iam_active_after_termination_total
iam_reconciliation_failure_total
```

---

# 120. KPIs

```text
Critical leaver access revoked within SLA = 100%
Active terminated identities = 0
Orphan privileged accounts = 0
Joiners without owner = 0
External accounts without expiry = 0
Mover events with stale scope = 0
Failed session revocation unresolved = 0
```

---

# 121. KRIs

```text
Deprovisioning delay
Orphan account growth
Dormant privileged accounts
Repeated manual overrides
External access extensions
Mover access accumulation
Failed downstream connector actions
Active account without authoritative source
```

---

# 122. Database Direction

Potential tables:

```text
iam_identities
iam_identity_lifecycle_episodes
iam_identity_source_links
iam_identity_lifecycle_events
iam_provisioning_requests
iam_provisioning_tasks
iam_deprovisioning_runs
iam_external_account_links
iam_service_identity_owners
iam_identity_reconciliation_runs
iam_identity_reconciliation_findings
```

---

# 123. Table: iam_identity_lifecycle_episodes

```sql
CREATE TABLE iam_identity_lifecycle_episodes (
    id CHAR(26) NOT NULL,
    identity_id CHAR(26) NOT NULL,
    tenant_id CHAR(26) NOT NULL,
    engagement_type VARCHAR(40) NOT NULL,
    source_reference VARCHAR(255) NOT NULL,
    start_at DATETIME(6) NOT NULL,
    end_at DATETIME(6) NULL,
    status VARCHAR(30) NOT NULL,
    owner_reference VARCHAR(180) NOT NULL,
    created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),

    PRIMARY KEY (id),
    KEY idx_iam_lifecycle_identity (
        identity_id,
        status
    ),
    KEY idx_iam_lifecycle_tenant (
        tenant_id,
        status,
        start_at
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

# 124. Table: iam_identity_source_links

```sql
CREATE TABLE iam_identity_source_links (
    id CHAR(26) NOT NULL,
    identity_id CHAR(26) NOT NULL,
    source_type VARCHAR(50) NOT NULL,
    source_system_code VARCHAR(100) NOT NULL,
    external_subject_id VARCHAR(255) NOT NULL,
    is_authoritative BOOLEAN NOT NULL DEFAULT FALSE,
    status VARCHAR(30) NOT NULL,
    last_synchronized_at DATETIME(6) NULL,

    PRIMARY KEY (id),
    UNIQUE KEY uq_iam_source_subject (
        source_system_code,
        external_subject_id
    ),
    KEY idx_iam_source_identity (
        identity_id,
        status
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

# 125. Table: iam_provisioning_requests

```sql
CREATE TABLE iam_provisioning_requests (
    id CHAR(26) NOT NULL,
    request_code VARCHAR(100) NOT NULL,
    identity_id CHAR(26) NOT NULL,
    request_type VARCHAR(40) NOT NULL,
    effective_at DATETIME(6) NOT NULL,
    desired_state_json JSON NOT NULL,
    status VARCHAR(30) NOT NULL,
    requested_by VARCHAR(180) NOT NULL,
    approved_by VARCHAR(180) NULL,
    created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),

    PRIMARY KEY (id),
    UNIQUE KEY uq_iam_provisioning_request_code (
        request_code
    ),
    KEY idx_iam_provisioning_identity (
        identity_id,
        status,
        effective_at
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

# 126. Table: iam_provisioning_tasks

```sql
CREATE TABLE iam_provisioning_tasks (
    id CHAR(26) NOT NULL,
    provisioning_request_id CHAR(26) NOT NULL,
    target_system_code VARCHAR(100) NOT NULL,
    task_type VARCHAR(40) NOT NULL,
    status VARCHAR(30) NOT NULL,
    attempt_count INT NOT NULL DEFAULT 0,
    last_error_code VARCHAR(180) NULL,
    completed_at DATETIME(6) NULL,

    PRIMARY KEY (id),
    UNIQUE KEY uq_iam_provisioning_task (
        provisioning_request_id,
        target_system_code,
        task_type
    ),
    CONSTRAINT fk_iam_provisioning_task_request
        FOREIGN KEY (provisioning_request_id)
        REFERENCES iam_provisioning_requests (id)
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

# 127. Table: iam_external_account_links

```sql
CREATE TABLE iam_external_account_links (
    id CHAR(26) NOT NULL,
    identity_id CHAR(26) NOT NULL,
    external_system_code VARCHAR(100) NOT NULL,
    external_account_id VARCHAR(255) NOT NULL,
    account_status VARCHAR(30) NOT NULL,
    expires_at DATETIME(6) NULL,
    last_reconciled_at DATETIME(6) NULL,

    PRIMARY KEY (id),
    UNIQUE KEY uq_iam_external_account (
        external_system_code,
        external_account_id
    ),
    KEY idx_iam_external_identity (
        identity_id,
        account_status
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

# 128. API Direction

```text
GET  /api/internal/v1/iam/identities
POST /api/internal/v1/iam/identities/provision
POST /api/internal/v1/iam/identities/{identityId}/activate
POST /api/internal/v1/iam/identities/{identityId}/move
POST /api/internal/v1/iam/identities/{identityId}/suspend
POST /api/internal/v1/iam/identities/{identityId}/reactivate
POST /api/internal/v1/iam/identities/{identityId}/terminate
POST /api/internal/v1/iam/identities/{identityId}/deprovision
GET  /api/internal/v1/iam/identities/{identityId}/lifecycle
POST /api/internal/v1/iam/identities/reconcile
```

---

# 129. SDK Contracts

Potential contracts:

```text
IdentityLifecycleServiceInterface
IdentityProvisioningServiceInterface
IdentityDeprovisioningServiceInterface
IdentitySourceConnectorInterface
IdentityCorrelationServiceInterface
AccessDeltaCalculatorInterface
IdentityReconciliationServiceInterface
ExternalAccountProvisionerInterface
```

---

# 130. Lifecycle Service Contract

```php
interface IdentityLifecycleServiceInterface
{
    public function provision(
        IdentityProvisioningRequest $request
    ): IdentityLifecycleResult;

    public function move(
        IdentityMoveRequest $request
    ): IdentityLifecycleResult;

    public function suspend(
        IdentitySuspensionRequest $request
    ): IdentityLifecycleResult;

    public function terminate(
        IdentityTerminationRequest $request
    ): IdentityLifecycleResult;
}
```

---

# 131. External Provisioner Contract

```php
interface ExternalAccountProvisionerInterface
{
    public function provision(
        ExternalAccountRequest $request
    ): ExternalAccountResult;

    public function disable(
        ExternalAccountReference $account
    ): ExternalAccountResult;
}
```

---

# 132. Error Codes

```text
IAM_LIFECYCLE_IDENTITY_NOT_FOUND
IAM_LIFECYCLE_SOURCE_INVALID
IAM_LIFECYCLE_DUPLICATE_IDENTITY
IAM_LIFECYCLE_OWNER_REQUIRED
IAM_LIFECYCLE_START_DATE_INVALID
IAM_LIFECYCLE_ACCESS_POLICY_INVALID
IAM_LIFECYCLE_SOD_CONFLICT
IAM_LIFECYCLE_TRANSFER_INVALID
IAM_LIFECYCLE_SUSPENSION_FAILED
IAM_LIFECYCLE_REACTIVATION_DENIED
IAM_LIFECYCLE_TERMINATION_FAILED
IAM_LIFECYCLE_DEPROVISION_FAILED
IAM_LIFECYCLE_ORPHAN_ACCOUNT
IAM_LIFECYCLE_RECONCILIATION_FAILED
```

---

# 133. Joiner Checklist

- [ ] Authoritative source valid.
- [ ] Identity correlation complete.
- [ ] Duplicate check complete.
- [ ] Owner assigned.
- [ ] Tenant/organization/clinic valid.
- [ ] Start date valid.
- [ ] Baseline access calculated.
- [ ] SoD check passed.
- [ ] Verification completed.
- [ ] MFA enrolled where required.
- [ ] Account activated at correct time.
- [ ] Audit generated.

---

# 134. Mover Checklist

- [ ] Change source valid.
- [ ] Effective time defined.
- [ ] New scope valid.
- [ ] Access delta calculated.
- [ ] Old access removal identified.
- [ ] Temporary overlap approved.
- [ ] SoD check passed.
- [ ] Sessions/caches reevaluated.
- [ ] Workflow assignments reviewed.
- [ ] External accounts updated.
- [ ] Reconciliation passed.
- [ ] Audit generated.

---

# 135. Leaver Checklist

- [ ] Termination source validated.
- [ ] Effective time confirmed.
- [ ] Authentication blocked.
- [ ] Sessions revoked.
- [ ] Tokens/API keys revoked.
- [ ] Roles/scopes removed.
- [ ] Privileged grants revoked.
- [ ] External accounts disabled.
- [ ] Ownership transferred.
- [ ] Open tasks reassigned.
- [ ] Data retained correctly.
- [ ] Reconciliation complete.

---

# 136. UAT — Joiner

- [ ] Valid joiner provisions.
- [ ] Duplicate identity rejected.
- [ ] Missing owner rejected.
- [ ] Pre-start account remains inactive.
- [ ] Start date activates correctly.
- [ ] Wrong tenant scope rejected.
- [ ] Baseline role assigned.
- [ ] SoD conflict blocks access.
- [ ] Invitation expires.
- [ ] MFA requirement enforced.

---

# 137. UAT — Mover

- [ ] Clinic transfer updates scope.
- [ ] Old clinic access removed.
- [ ] Promotion recalculates role.
- [ ] Demotion removes elevated access.
- [ ] Temporary dual access expires.
- [ ] Manager change updates approval routing.
- [ ] Tenant transfer handled as controlled transition.
- [ ] Menu projection updates.
- [ ] Sessions re-evaluated.
- [ ] Audit includes access delta.

---

# 138. UAT — Suspension & Reactivation

- [ ] Suspension blocks login.
- [ ] Active sessions revoked.
- [ ] Temporary grants suspended.
- [ ] External access disabled where configured.
- [ ] Emergency suspension works.
- [ ] Reactivation requires valid source.
- [ ] Access recalculated on reactivation.
- [ ] Old stale access not restored blindly.
- [ ] Audit complete.

---

# 139. UAT — Leaver & Deprovisioning

- [ ] Planned termination executes at timestamp.
- [ ] Immediate termination revokes access immediately.
- [ ] Refresh tokens revoked.
- [ ] API tokens revoked.
- [ ] MFA factors disabled.
- [ ] Privileged sessions terminated.
- [ ] External account disable confirmed.
- [ ] Failed downstream task retries/escalates.
- [ ] Open tasks reassigned.
- [ ] Active-after-termination finding is zero.

---

# 140. UAT — External & Contractor Identities

- [ ] Sponsor required.
- [ ] End date required.
- [ ] Access auto-expires.
- [ ] Sponsor review notification sent.
- [ ] Expired contractor cannot login.
- [ ] Extension requires approval.
- [ ] External account reconciliation works.
- [ ] Missing sponsor creates finding.
- [ ] Tenant isolation enforced.

---

# 141. UAT — Service Identities

- [ ] Owner required.
- [ ] Purpose required.
- [ ] Human login blocked.
- [ ] Environment/scope enforced.
- [ ] Credential rotation policy linked.
- [ ] Dormant service account detected.
- [ ] Owner departure triggers reassignment.
- [ ] Retirement blocks dependent job if unresolved.
- [ ] Audit complete.

---

# 142. UAT — Rehire

- [ ] Historical identity matched.
- [ ] Old account history retained.
- [ ] New lifecycle episode created.
- [ ] Access recalculated.
- [ ] Old privileged access not restored automatically.
- [ ] MFA revalidated.
- [ ] New tenant/scope applied.
- [ ] Audit links prior episode.

---

# 143. UAT — Reconciliation

- [ ] Missing account detected.
- [ ] Unexpected active account detected.
- [ ] Excess access detected.
- [ ] Stale scope detected.
- [ ] Orphan account detected.
- [ ] Dormant account detected.
- [ ] Failed session revocation detected.
- [ ] External account drift detected.
- [ ] Auto-remediation works where approved.
- [ ] Critical finding opens case.

---

# 144. Definition of Done — SSOT-IAM-07

SSOT-IAM-07 dianggap selesai bila:

- [ ] lifecycle states tersedia;
- [ ] authoritative source model tersedia;
- [ ] identity correlation tersedia;
- [ ] ownership tersedia;
- [ ] joiner lifecycle tersedia;
- [ ] invitation/verification/activation tersedia;
- [ ] mover lifecycle and access delta tersedia;
- [ ] leave and suspension tersedia;
- [ ] leaver/termination tersedia;
- [ ] deprovisioning SLA and state tersedia;
- [ ] session/token/grant revocation tersedia;
- [ ] ownership/task transfer tersedia;
- [ ] external account lifecycle tersedia;
- [ ] service identity lifecycle tersedia;
- [ ] dormancy/orphan detection tersedia;
- [ ] rehire model tersedia;
- [ ] lifecycle events/idempotency tersedia;
- [ ] policy and SoD integration tersedia;
- [ ] reconciliation tersedia;
- [ ] audit/logging/metrics tersedia;
- [ ] database direction tersedia;
- [ ] API direction tersedia;
- [ ] SDK contracts tersedia;
- [ ] error codes tersedia;
- [ ] checklists and UAT tersedia.

---

# 145. Implementation Roadmap

## Phase 1 — Identity Lifecycle Foundation

- lifecycle state model;
- source links;
- identity correlation;
- joiner provisioning;
- baseline access policy;
- audit events.

## Phase 2 — Mover & Access Delta

- organization/scope changes;
- delta calculator;
- SoD integration;
- workflow/task reassignment;
- cache/session reevaluation;
- temporary overlap.

## Phase 3 — Leaver & Deprovisioning

- scheduled termination;
- immediate suspension;
- session/token revocation;
- role/scope/grant removal;
- external account connectors;
- SLA monitoring.

## Phase 4 — External & Service Identities

- contractor lifecycle;
- sponsor reviews;
- service account ownership;
- expiry/dormancy;
- SCIM integration;
- connector evidence.

## Phase 5 — Continuous Identity Governance

- event-driven lifecycle;
- reconciliation;
- auto-remediation;
- identity risk integration;
- lifecycle analytics;
- continuous certification.

---

# 146. Initial Implementation Backlog

```text
IAM07-001 Lifecycle State Model
IAM07-002 Identity Source Registry
IAM07-003 Identity Correlation Service
IAM07-004 Joiner Provisioning Workflow
IAM07-005 Baseline Access Policy
IAM07-006 Mover Access Delta Calculator
IAM07-007 Suspension Service
IAM07-008 Termination Orchestrator
IAM07-009 Session & Token Revocation
IAM07-010 External Account Provisioner
IAM07-011 Service Identity Lifecycle
IAM07-012 Dormant Account Detection
IAM07-013 Orphan Account Detection
IAM07-014 Reconciliation Engine
IAM07-015 Lifecycle SLA Dashboard
IAM07-016 SCIM Connector Foundation
```

---

# 147. Approval Gate

Dokumen dapat menjadi Approved setelah:

- IAM Architecture review;
- Platform Architecture review;
- RBAC/Scope review;
- Security review;
- HR/People Operations integration review;
- Tenant Administration review;
- Audit/Compliance review;
- Operations review;
- Quality Engineering review;
- UAT review.

---

# 148. Closing Statement

Identity lifecycle governance harus memastikan:

- joiner mendapat akses minimum yang benar;
- mover tidak mengakumulasi akses lama;
- leaver kehilangan akses tepat waktu;
- external identity memiliki sponsor dan expiry;
- service identity memiliki owner;
- orphan account tidak dibiarkan;
- setiap perubahan dapat diaudit;
- actual state selalu direkonsiliasi dengan desired state.

Identity bukan sekadar akun login.

Identity adalah entitas ber-lifecycle yang menghubungkan subject, source, tenant, scope, role, session, device, service, dan business responsibility.
