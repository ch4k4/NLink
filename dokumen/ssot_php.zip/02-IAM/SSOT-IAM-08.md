# SSOT-IAM-08 — Identity Risk, Account Recovery & Identity Proofing

---

## Status Dokumen

| Item | Nilai |
|---|---|
| Kode | SSOT-IAM-08 |
| Judul | Identity Risk, Account Recovery & Identity Proofing |
| Versi | 1.0 |
| Status | Draft Architecture |
| Domain | Platform Kernel |
| Kategori | Identity Assurance, Risk, Recovery & Fraud Resistance |
| Cakupan | Identity Risk, Adaptive Authentication, Proofing, Recovery, Compromise Response, Assurance Levels, Fraud Controls |
| Bergantung pada | SSOT-GOV-01, SSOT-GOV-04, SSOT-GOV-05, SSOT-IAM-01, SSOT-IAM-02, SSOT-IAM-03, SSOT-IAM-04, SSOT-IAM-05, SSOT-IAM-06, SSOT-IAM-07, SSOT-RBAC-05, SSOT-RBAC-08, SSOT-AUDIT-01, SSOT-SEC-01, SSOT-SEC-02, SSOT-SEC-03, SSOT-OBS-01, SSOT-NOTIFY-01, SSOT-TEST-01 |
| Target Stack | PHP 8.1+, PDO, MySQL 8/MariaDB, Risk Engine-ready |
| Target Evolusi | Continuous Identity Risk, Adaptive Authentication, Device Trust, Fraud Detection, External Proofing Providers |

---

# 1. Executive Summary

SSOT-IAM-08 menetapkan governance resmi untuk identity risk, identity proofing, account recovery, compromised-account response, adaptive authentication, dan identity assurance.

Dokumen ini mengatur:

- identity assurance levels;
- authentication assurance;
- identity proofing;
- proofing evidence;
- account recovery;
- recovery channels;
- recovery risk;
- step-up authentication;
- adaptive authentication;
- device trust;
- location and network signals;
- impossible travel;
- behavioral anomaly;
- credential compromise;
- suspicious login;
- session risk;
- recovery fraud;
- social engineering resistance;
- privileged recovery;
- break-glass recovery;
- support-assisted recovery;
- re-verification;
- compromised account containment;
- notifications;
- audit;
- metrics;
- database direction;
- API direction;
- SDK contracts;
- UAT;
- Definition of Done;
- implementation roadmap.

Tujuan akhirnya adalah memastikan bahwa:

- identity benar-benar milik subject yang tepat;
- assurance sesuai dengan risk;
- recovery tidak lebih lemah daripada authentication;
- compromised account dapat dibatasi segera;
- risky behavior memicu step-up atau denial;
- recovery dapat diaudit;
- fraud dan social engineering dapat dikurangi;
- privileged account recovery memiliki kontrol lebih kuat.

---

# 2. Objectives

Framework harus:

- menyediakan assurance model;
- mendukung risk-based authentication;
- mendukung account recovery yang aman;
- menyediakan proofing lifecycle;
- mendeteksi compromised identity;
- mencegah recovery abuse;
- mendukung privileged recovery;
- menyediakan continuous risk signals;
- menghasilkan audit evidence;
- mendukung integration dengan IdP dan fraud tools.

---

# 3. Core Principles

```text
Recovery Must Not Be Weaker Than Authentication
Higher Risk Requires Higher Assurance
Identity Proofing Is Separate from Authentication
No Recovery Through a Single Weak Channel
Privileged Recovery Requires Stronger Controls
Suspicious Recovery Must Be Delayed or Reviewed
Compromised Accounts Must Be Contained Quickly
Every Proofing and Recovery Action Must Be Auditable
Risk Decisions Must Be Explainable
Fail Closed on Critical Uncertainty
```

---

# 4. Scope

Framework berlaku untuk:

```text
Employees
Tenant Administrators
Clinical Users
External Users
Contractors
Privileged Users
Service Owners
Federated Identities
Local Accounts
Recovery Contacts
Support-Assisted Recovery
```

---

# 5. Non-Scope

Dokumen ini tidak menggantikan:

- national identity verification law;
- complete fraud operations process;
- device management platform;
- full SIEM implementation;
- human resources background checks.

---

# 6. Assurance Model

Recommended levels:

```text
IAL0 — Unverified
IAL1 — Basic Verified
IAL2 — Strong Verified
IAL3 — High Assurance
```

---

# 7. Authentication Assurance

```text
AAL1 — Single Factor
AAL2 — Multi-Factor
AAL3 — Phishing-Resistant / Hardware-Backed
```

---

# 8. Federation Assurance

Federated sessions must map external assurance claims into internal assurance model.

---

# 9. Assurance Policy

Example:

| Capability | Minimum |
|---|---|
| Basic user portal | IAL1 + AAL1/AAL2 |
| Sensitive clinical access | IAL2 + AAL2 |
| Tenant administration | IAL2 + AAL2 |
| Privileged access | IAL2/IAL3 + AAL3 preferred |
| Secret reveal | IAL2 + recent AAL3 |
| Break-glass recovery | IAL3-equivalent controls |

---

# 10. Identity Proofing

Identity proofing establishes confidence that a claimed identity belongs to the subject.

---

# 11. Proofing Methods

```text
EMAIL_VERIFICATION
PHONE_VERIFICATION
MANAGER_ATTESTATION
HR_SOURCE_MATCH
DOCUMENT_VERIFICATION
VIDEO_VERIFICATION
IN_PERSON_VERIFICATION
TRUSTED_IDP_ASSERTION
KNOWLEDGE_BASED_APPROVED
```

---

# 12. Weak Proofing

Knowledge-based questions are weak and should not be sole proofing method for high-risk identity.

---

# 13. Proofing Evidence

Minimum:

```text
subject
method
provider
evidence_reference
assurance_level
verified_at
verified_by
expiry
result
```

---

# 14. Evidence Minimization

Store only necessary evidence and references, not unnecessary raw identity documents.

---

# 15. Proofing Lifecycle

```text
Requested
→ Collected
→ Validated
→ Approved
→ Active
→ Reverify
→ Expired
→ Revoked
```

---

# 16. Re-Proofing Triggers

- long inactivity;
- privileged elevation;
- identity mismatch;
- provider change;
- account compromise;
- high-risk recovery;
- major attribute change;
- legal/compliance requirement.

---

# 17. Identity Risk

Identity risk is a score or decision derived from current and historical signals.

---

# 18. Risk Levels

```text
LOW
MODERATE
HIGH
CRITICAL
```

---

# 19. Risk Signals

```text
NEW_DEVICE
UNKNOWN_DEVICE
IMPOSSIBLE_TRAVEL
ANOMALOUS_LOCATION
ANOMALOUS_TIME
TOR_OR_PROXY
COMPROMISED_CREDENTIAL
MULTIPLE_FAILURES
RECOVERY_ATTEMPT
PRIVILEGED_ACTION
SESSION_ANOMALY
MFA_RESET
PASSWORD_RESET
EMAIL_CHANGE
PHONE_CHANGE
```

---

# 20. Risk Signal Sources

- authentication logs;
- device registry;
- IP intelligence;
- session behavior;
- security incidents;
- IdP claims;
- user reports;
- support cases;
- external compromise feeds.

---

# 21. Risk Decision

Possible outcomes:

```text
ALLOW
ALLOW_WITH_MONITORING
REQUIRE_STEP_UP
REQUIRE_REPROOFING
RESTRICT
SUSPEND
DENY
MANUAL_REVIEW
```

---

# 22. Explainability

Risk decisions must expose reason codes without revealing exploitable internal details.

---

# 23. Adaptive Authentication

Authentication requirements change according to risk.

---

# 24. Step-Up Triggers

- privileged access;
- secret reveal;
- sensitive export;
- recovery;
- new device;
- unusual location;
- high-value transaction;
- identity attribute change.

---

# 25. Recent Authentication

Sensitive actions may require authentication within a defined recent window.

---

# 26. Device Trust

Device trust may include:

- registered device;
- managed device;
- hardware-backed key;
- device posture;
- recent successful use;
- compromise state.

---

# 27. Device Trust Is Not Authorization

Trusted device does not grant permission by itself.

---

# 28. Location Risk

Location may influence risk but must account for VPN, travel, and false positives.

---

# 29. Impossible Travel

Impossible travel should trigger review or step-up, not automatic accusation.

---

# 30. Session Risk

Risk can change after login.

---

# 31. Continuous Session Evaluation

High-risk sessions may be:

- reauthenticated;
- downgraded;
- restricted;
- terminated.

---

# 32. Account Recovery

Recovery restores legitimate access after loss of credentials or factors.

---

# 33. Recovery Types

```text
PASSWORD_RESET
MFA_RESET
EMAIL_RECOVERY
PHONE_RECOVERY
ACCOUNT_UNLOCK
FEDERATION_RECOVERY
PRIVILEGED_RECOVERY
SERVICE_OWNER_RECOVERY
```

---

# 34. Recovery Channels

```text
VERIFIED_EMAIL
VERIFIED_PHONE
TRUSTED_DEVICE
RECOVERY_CODE
MANAGER_APPROVAL
IAM_ADMIN_REVIEW
IN_PERSON
TRUSTED_IDP
```

---

# 35. Recovery Channel Strength

Each channel must have assurance rating and risk constraints.

---

# 36. Single-Channel Recovery

Single weak-channel recovery is prohibited for high-risk accounts.

---

# 37. Recovery Preconditions

- identity active;
- recovery channel valid;
- risk evaluated;
- recent suspicious events checked;
- target account matched;
- policy selected;
- audit started.

---

# 38. Recovery Flow

```text
Request
→ Risk Evaluate
→ Verify Subject
→ Step-Up/Proof
→ Approve if Needed
→ Reset Credential/Factor
→ Revoke Sessions
→ Notify
→ Monitor
→ Close
```

---

# 39. Recovery Token

Recovery token must be:

- random;
- single-use;
- short-lived;
- subject-bound;
- purpose-bound;
- tenant-bound;
- revocable.

---

# 40. Recovery Token Storage

Store hashed token reference where possible.

---

# 41. Recovery Delay

High-risk recovery may use cooling-off delay.

---

# 42. Cooling-Off Period

During delay:

- notify existing channels;
- block sensitive changes;
- allow cancellation;
- monitor risk.

---

# 43. Support-Assisted Recovery

Requires strict script, permissions, audit, and anti-social-engineering controls.

---

# 44. Support Agent Restrictions

Support agent cannot:

- view existing password;
- bypass mandatory proofing;
- self-approve privileged recovery;
- disclose secret factors;
- alter audit evidence.

---

# 45. Manager-Assisted Recovery

Manager attestation can support but should not be sole proof for privileged users.

---

# 46. Privileged Account Recovery

Requires:

- strong proofing;
- independent approval;
- phishing-resistant factor enrollment;
- session revocation;
- temporary access limits;
- post-recovery review.

---

# 47. Break-Glass Recovery

Used only when normal recovery unavailable and business continuity is at risk.

---

# 48. Break-Glass Recovery Controls

- named approvers;
- incident reference;
- dual control;
- limited duration;
- strong audit;
- immediate notification;
- forced credential rotation;
- review.

---

# 49. MFA Reset

MFA reset is a high-risk event.

---

# 50. MFA Reset Controls

- re-proof subject;
- revoke old factors;
- revoke sessions;
- notify all verified channels;
- monitor post-reset;
- block sensitive changes temporarily if needed.

---

# 51. Password Reset

Password reset must invalidate existing reset tokens and optionally sessions.

---

# 52. Account Unlock

Unlock should evaluate brute-force and compromise signals.

---

# 53. Email Change

Primary email change requires strong verification and notification to old and new channels.

---

# 54. Phone Change

Primary phone change requires strong verification and notification.

---

# 55. Recovery Contact Change

Recovery contact change must be treated as sensitive action.

---

# 56. Recovery Code

Recovery codes should be:

- one-time;
- hashed;
- limited count;
- regenerable;
- invalidated on regeneration.

---

# 57. Federated Recovery

Local platform should not bypass IdP recovery policy unless approved fallback exists.

---

# 58. Lost IdP Access

Recovery may require alternate trusted proofing and identity admin workflow.

---

# 59. Compromised Account

An account is compromised when unauthorized access is confirmed or strongly suspected.

---

# 60. Compromise Indicators

- user report;
- leaked credential;
- impossible travel;
- malicious session;
- unauthorized factor change;
- unusual privileged action;
- known malware/device compromise.

---

# 61. Compromise Response

```text
Contain
→ Suspend/Restrict
→ Revoke Sessions/Tokens
→ Reset Credentials/Factors
→ Re-Proof Identity
→ Review Activity
→ Restore
→ Monitor
```

---

# 62. Containment

May include:

- account suspension;
- session termination;
- token revocation;
- API key revocation;
- privileged grant revocation;
- device block;
- export block.

---

# 63. Activity Review

Review:

- logins;
- sessions;
- role changes;
- exports;
- data access;
- recovery actions;
- external integrations;
- privileged activity.

---

# 64. Restoration

Requires assurance that:

- subject is legitimate;
- credentials/factors replaced;
- compromise cause addressed;
- access reviewed;
- suspicious sessions removed.

---

# 65. Post-Recovery Monitoring

Enhanced monitoring may continue for defined period.

---

# 66. Recovery Abuse Detection

Detect:

- repeated attempts;
- multiple identities from same source;
- unusual support requests;
- channel changes before recovery;
- rapid reset and export;
- high-risk geography;
- agent anomalies.

---

# 67. Social Engineering Resistance

Controls:

- no disclosure of account existence where sensitive;
- scripted verification;
- no trust in caller-supplied contact alone;
- callback to registered channels;
- dual approval for high risk;
- support training.

---

# 68. Identity Risk Score

Score may be numeric, but final decision must be policy-driven.

---

# 69. Risk Model Versioning

Every decision records risk model version.

---

# 70. Risk Model Governance

Changes require:

- owner;
- validation;
- false-positive analysis;
- explainability review;
- rollback;
- audit.

---

# 71. Risk Overrides

Manual override requires reason, owner, expiry, and audit.

---

# 72. False Positives

Users must have a secure path to resolve false-positive restrictions.

---

# 73. Notifications

Send notifications for:

- password reset;
- MFA reset;
- email/phone change;
- recovery request;
- new device;
- account suspension;
- privileged recovery;
- successful recovery.

---

# 74. Notification Channel

Use verified channels and avoid exposing sensitive details.

---

# 75. Recovery Privacy

Recovery flow must not reveal whether an account exists beyond approved UX policy.

---

# 76. Tenant Isolation

Recovery must be tenant-bound.

---

# 77. Cross-Tenant Identity

Cross-tenant recovery must not transfer access automatically.

---

# 78. Dormant Accounts

Recovery of dormant accounts may require re-proofing.

---

# 79. Terminated Identities

Terminated identities cannot recover access without new lifecycle approval.

---

# 80. External Users

External user recovery may require sponsor involvement and expiry revalidation.

---

# 81. Service Account Recovery

Service identity recovery is owner-driven and should rotate credentials rather than reset human factors.

---

# 82. API Keys

Compromised API keys must be revoked and replaced.

---

# 83. Session Reauthentication

High-risk session may require step-up without full logout.

---

# 84. Session Termination

Critical risk leads to immediate termination.

---

# 85. Risk Context

Minimum:

```text
identity_id
tenant_id
session_id
device_id
ip
location
action
assurance
signals
correlation_id
```

---

# 86. Risk Engine Contract

```php
interface IdentityRiskEngineInterface
{
    public function evaluate(
        IdentityRiskRequest $request
    ): IdentityRiskDecision;
}
```

---

# 87. Recovery Service Contract

```php
interface AccountRecoveryServiceInterface
{
    public function start(
        AccountRecoveryRequest $request
    ): AccountRecoveryChallenge;

    public function complete(
        AccountRecoveryCompletion $completion
    ): AccountRecoveryResult;
}
```

---

# 88. Proofing Service Contract

```php
interface IdentityProofingServiceInterface
{
    public function verify(
        IdentityProofingRequest $request
    ): IdentityProofingResult;
}
```

---

# 89. Assurance Service Contract

```php
interface IdentityAssuranceServiceInterface
{
    public function currentAssurance(
        string $identityId,
        ?string $sessionId
    ): IdentityAssuranceContext;
}
```

---

# 90. Recovery Status

```text
REQUESTED
CHALLENGE_ISSUED
PENDING_PROOF
PENDING_APPROVAL
COOLING_OFF
APPROVED
COMPLETED
REJECTED
EXPIRED
CANCELLED
FRAUD_SUSPECTED
```

---

# 91. Proofing Status

```text
PENDING
VERIFIED
FAILED
EXPIRED
REVOKED
REQUIRES_REVIEW
```

---

# 92. Risk Decision Record

Minimum:

```text
identity_id
risk_level
signals
decision
reason_codes
model_version
evaluated_at
```

---

# 93. Recovery Record

Minimum:

```text
recovery_id
identity_id
tenant_id
recovery_type
channels
risk_level
status
requested_at
completed_at
approved_by
```

---

# 94. Proofing Record

Minimum:

```text
proofing_id
identity_id
method
provider
assurance_level
status
evidence_reference
verified_at
expires_at
```

---

# 95. Reconciliation

Compare:

- identity assurance;
- enrolled factors;
- recovery channels;
- proofing expiry;
- risk restrictions;
- active sessions;
- compromised status;
- recovery events.

---

# 96. Reconciliation Findings

```text
EXPIRED_PROOFING
WEAK_RECOVERY_CHANNEL
MISSING_RECOVERY_OWNER
ACTIVE_COMPROMISED_SESSION
MFA_RESET_WITHOUT_REPROOFING
PRIVILEGED_RECOVERY_WITHOUT_APPROVAL
RISK_RESTRICTION_DRIFT
ORPHAN_RECOVERY_TOKEN
```

---

# 97. Audit Events

```text
IAM_RISK_EVALUATED
IAM_STEP_UP_REQUIRED
IAM_PROOFING_REQUESTED
IAM_PROOFING_VERIFIED
IAM_PROOFING_FAILED
IAM_RECOVERY_REQUESTED
IAM_RECOVERY_CHALLENGE_ISSUED
IAM_RECOVERY_APPROVED
IAM_RECOVERY_COMPLETED
IAM_RECOVERY_REJECTED
IAM_MFA_RESET
IAM_ACCOUNT_COMPROMISED
IAM_ACCOUNT_CONTAINED
IAM_ACCOUNT_RESTORED
```

---

# 98. Audit Metadata

```text
identity_id
tenant_id
risk_level
reason_codes
assurance_before
assurance_after
recovery_type
proofing_method
actor
correlation_id
```

---

# 99. Metrics

```text
iam_risk_evaluation_total
iam_high_risk_decision_total
iam_step_up_total
iam_recovery_request_total
iam_recovery_success_total
iam_recovery_failure_total
iam_recovery_fraud_total
iam_proofing_failure_total
iam_compromised_account_total
iam_reconciliation_failure_total
```

---

# 100. KPIs

```text
Privileged recovery without independent approval = 0
MFA reset without re-proofing = 0
Active compromised sessions = 0
Expired proofing on critical identities = 0
Recovery events without audit = 0
Weak single-channel recovery for privileged accounts = 0
```

---

# 101. KRIs

```text
Recovery attempt spikes
MFA reset frequency
Email/phone change before recovery
High-risk login growth
False-positive restriction rate
Privileged recovery count
Compromised account recurrence
Recovery agent anomaly
```

---

# 102. Database Direction

Potential tables:

```text
iam_identity_assurance
iam_identity_proofing_records
iam_identity_risk_decisions
iam_identity_risk_signals
iam_account_recovery_requests
iam_account_recovery_challenges
iam_account_recovery_approvals
iam_compromised_account_cases
iam_recovery_channel_registry
iam_identity_risk_reconciliation_runs
iam_identity_risk_reconciliation_findings
```

---

# 103. Table: iam_identity_assurance

```sql
CREATE TABLE iam_identity_assurance (
    id CHAR(26) NOT NULL,
    identity_id CHAR(26) NOT NULL,
    identity_assurance_level VARCHAR(20) NOT NULL,
    authentication_assurance_level VARCHAR(20) NULL,
    source_reference VARCHAR(255) NULL,
    status VARCHAR(30) NOT NULL,
    valid_from DATETIME(6) NOT NULL,
    valid_to DATETIME(6) NULL,
    updated_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),

    PRIMARY KEY (id),
    KEY idx_iam_assurance_identity (
        identity_id,
        status,
        valid_to
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

# 104. Table: iam_identity_proofing_records

```sql
CREATE TABLE iam_identity_proofing_records (
    id CHAR(26) NOT NULL,
    identity_id CHAR(26) NOT NULL,
    proofing_method VARCHAR(50) NOT NULL,
    provider_code VARCHAR(100) NULL,
    assurance_level VARCHAR(20) NOT NULL,
    evidence_reference VARCHAR(1000) NULL,
    status VARCHAR(30) NOT NULL,
    verified_at DATETIME(6) NULL,
    expires_at DATETIME(6) NULL,
    verified_by VARCHAR(180) NULL,

    PRIMARY KEY (id),
    KEY idx_iam_proofing_identity (
        identity_id,
        status,
        expires_at
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

# 105. Table: iam_identity_risk_decisions

```sql
CREATE TABLE iam_identity_risk_decisions (
    id CHAR(26) NOT NULL,
    identity_id CHAR(26) NOT NULL,
    tenant_id CHAR(26) NOT NULL,
    session_id CHAR(26) NULL,
    action_code VARCHAR(180) NOT NULL,
    risk_level VARCHAR(30) NOT NULL,
    decision VARCHAR(40) NOT NULL,
    reason_codes_json JSON NOT NULL,
    model_version VARCHAR(100) NOT NULL,
    correlation_id VARCHAR(180) NOT NULL,
    evaluated_at DATETIME(6) NOT NULL,

    PRIMARY KEY (id),
    KEY idx_iam_risk_identity (
        tenant_id,
        identity_id,
        evaluated_at
    ),
    KEY idx_iam_risk_level (
        risk_level,
        decision,
        evaluated_at
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

# 106. Table: iam_account_recovery_requests

```sql
CREATE TABLE iam_account_recovery_requests (
    id CHAR(26) NOT NULL,
    recovery_code VARCHAR(100) NOT NULL,
    identity_id CHAR(26) NOT NULL,
    tenant_id CHAR(26) NOT NULL,
    recovery_type VARCHAR(40) NOT NULL,
    risk_level VARCHAR(30) NOT NULL,
    status VARCHAR(30) NOT NULL,
    requested_at DATETIME(6) NOT NULL,
    cooling_off_until DATETIME(6) NULL,
    completed_at DATETIME(6) NULL,
    approved_by VARCHAR(180) NULL,

    PRIMARY KEY (id),
    UNIQUE KEY uq_iam_recovery_code (
        recovery_code
    ),
    KEY idx_iam_recovery_identity (
        tenant_id,
        identity_id,
        status
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

# 107. Table: iam_compromised_account_cases

```sql
CREATE TABLE iam_compromised_account_cases (
    id CHAR(26) NOT NULL,
    case_code VARCHAR(100) NOT NULL,
    identity_id CHAR(26) NOT NULL,
    tenant_id CHAR(26) NOT NULL,
    severity VARCHAR(30) NOT NULL,
    source VARCHAR(100) NOT NULL,
    status VARCHAR(30) NOT NULL,
    containment_actions_json JSON NULL,
    opened_at DATETIME(6) NOT NULL,
    contained_at DATETIME(6) NULL,
    restored_at DATETIME(6) NULL,

    PRIMARY KEY (id),
    UNIQUE KEY uq_iam_compromised_case_code (
        case_code
    ),
    KEY idx_iam_compromised_identity (
        tenant_id,
        identity_id,
        status
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

# 108. API Direction

```text
POST /api/internal/v1/iam/risk/evaluate
GET  /api/internal/v1/iam/identities/{identityId}/assurance
POST /api/internal/v1/iam/identities/{identityId}/proof
POST /api/internal/v1/iam/recovery/start
POST /api/internal/v1/iam/recovery/{recoveryCode}/complete
POST /api/internal/v1/iam/recovery/{recoveryCode}/approve
POST /api/internal/v1/iam/identities/{identityId}/contain
POST /api/internal/v1/iam/identities/{identityId}/restore
POST /api/internal/v1/iam/risk/reconcile
```

---

# 109. Error Codes

```text
IAM_RISK_EVALUATION_FAILED
IAM_RISK_STEP_UP_REQUIRED
IAM_RISK_ACCESS_DENIED
IAM_PROOFING_FAILED
IAM_PROOFING_EXPIRED
IAM_PROOFING_ASSURANCE_INSUFFICIENT
IAM_RECOVERY_NOT_FOUND
IAM_RECOVERY_EXPIRED
IAM_RECOVERY_CHANNEL_WEAK
IAM_RECOVERY_FRAUD_SUSPECTED
IAM_RECOVERY_APPROVAL_REQUIRED
IAM_RECOVERY_COOLING_OFF_ACTIVE
IAM_COMPROMISED_ACCOUNT_ACTIVE
IAM_ACCOUNT_RESTORE_DENIED
IAM_RISK_RECONCILIATION_FAILED
```

---

# 110. Proofing Checklist

- [ ] Identity active.
- [ ] Proofing purpose defined.
- [ ] Required assurance selected.
- [ ] Method approved.
- [ ] Evidence minimized.
- [ ] Provider validated.
- [ ] Result recorded.
- [ ] Expiry defined.
- [ ] Audit generated.
- [ ] Re-proofing trigger defined.

---

# 111. Recovery Checklist

- [ ] Identity matched.
- [ ] Tenant matched.
- [ ] Recovery type selected.
- [ ] Risk evaluated.
- [ ] Recovery channels validated.
- [ ] Strong proofing applied.
- [ ] Approval obtained where required.
- [ ] Cooling-off applied where required.
- [ ] Sessions/factors revoked.
- [ ] Notifications sent.
- [ ] Audit complete.
- [ ] Post-recovery monitoring enabled.

---

# 112. Compromise Checklist

- [ ] Account restricted/suspended.
- [ ] Sessions terminated.
- [ ] Tokens revoked.
- [ ] Factors reviewed/reset.
- [ ] Privileged grants revoked.
- [ ] Activity reviewed.
- [ ] Subject re-proofed.
- [ ] Access reviewed.
- [ ] Restoration approved.
- [ ] Monitoring enabled.
- [ ] Incident linked.

---

# 113. UAT — Identity Proofing

- [ ] Basic proofing reaches IAL1.
- [ ] Strong proofing reaches IAL2.
- [ ] Weak method rejected for privileged account.
- [ ] Expired proofing triggers re-verification.
- [ ] Evidence minimization enforced.
- [ ] Failed proofing blocks activation.
- [ ] Provider mismatch rejected.
- [ ] History retained.
- [ ] Audit complete.

---

# 114. UAT — Risk Evaluation

- [ ] Normal login allowed.
- [ ] New device requires step-up.
- [ ] High-risk IP triggers review.
- [ ] Impossible travel triggers policy.
- [ ] Compromised credential denied.
- [ ] Risk model version recorded.
- [ ] Manual override requires approval.
- [ ] False-positive resolution works.
- [ ] Session risk can change after login.

---

# 115. UAT — Password Recovery

- [ ] Valid recovery token works.
- [ ] Expired token rejected.
- [ ] Reused token rejected.
- [ ] Wrong tenant rejected.
- [ ] Existing sessions revoked.
- [ ] Notification sent.
- [ ] Weak single channel rejected for high risk.
- [ ] Brute-force rate limit works.
- [ ] Audit complete.

---

# 116. UAT — MFA Recovery

- [ ] MFA reset requires re-proofing.
- [ ] Old factors revoked.
- [ ] All sessions revoked.
- [ ] Privileged recovery requires approval.
- [ ] New factor enrollment enforced.
- [ ] Old channel notified.
- [ ] Post-reset monitoring enabled.
- [ ] Suspicious reset creates case.
- [ ] Audit complete.

---

# 117. UAT — Email/Phone Change

- [ ] Old channel notified.
- [ ] New channel verified.
- [ ] High-risk change uses cooling-off.
- [ ] Pending recovery blocks immediate sensitive actions.
- [ ] Wrong identity denied.
- [ ] Support cannot bypass policy.
- [ ] Audit includes old/new channel references.
- [ ] Recovery contact changes monitored.

---

# 118. UAT — Privileged Recovery

- [ ] Strong proofing required.
- [ ] Independent approval required.
- [ ] Phishing-resistant factor enrolled.
- [ ] Sessions and grants revoked.
- [ ] Temporary restrictions applied.
- [ ] Post-recovery review created.
- [ ] Self-approval denied.
- [ ] Break-glass use requires incident.
- [ ] Audit complete.

---

# 119. UAT — Compromised Account

- [ ] User report opens case.
- [ ] Account contained.
- [ ] Sessions terminated.
- [ ] Tokens/API keys revoked.
- [ ] Activity review generated.
- [ ] Re-proofing required.
- [ ] Access reviewed before restore.
- [ ] Monitoring enabled after restore.
- [ ] Repeated compromise escalates.
- [ ] Case evidence retained.

---

# 120. UAT — Recovery Fraud

- [ ] Repeated attempts detected.
- [ ] Same source targeting multiple users detected.
- [ ] Support anomaly detected.
- [ ] Email change before recovery increases risk.
- [ ] Cooling-off blocks rapid takeover.
- [ ] Old channel cancellation works.
- [ ] Fraud-suspected recovery cannot complete.
- [ ] Manual review workflow works.
- [ ] Metrics updated.

---

# 121. UAT — Reconciliation

- [ ] Expired proofing detected.
- [ ] Weak recovery channel detected.
- [ ] Active compromised session detected.
- [ ] MFA reset without proofing detected.
- [ ] Privileged recovery without approval detected.
- [ ] Orphan token detected.
- [ ] Risk restriction drift detected.
- [ ] Critical finding opens case.
- [ ] Report generated.

---

# 122. Definition of Done — SSOT-IAM-08

SSOT-IAM-08 dianggap selesai bila:

- [ ] assurance model tersedia;
- [ ] identity proofing methods tersedia;
- [ ] proofing evidence/lifecycle tersedia;
- [ ] risk levels/signals tersedia;
- [ ] adaptive authentication tersedia;
- [ ] step-up and device trust tersedia;
- [ ] recovery types/channels tersedia;
- [ ] recovery token controls tersedia;
- [ ] cooling-off tersedia;
- [ ] support-assisted recovery tersedia;
- [ ] privileged recovery tersedia;
- [ ] MFA/password/email/phone recovery tersedia;
- [ ] compromised account response tersedia;
- [ ] recovery fraud controls tersedia;
- [ ] continuous session risk tersedia;
- [ ] notifications and privacy tersedia;
- [ ] reconciliation tersedia;
- [ ] audit/logging/metrics tersedia;
- [ ] database direction tersedia;
- [ ] API direction tersedia;
- [ ] SDK contracts tersedia;
- [ ] error codes tersedia;
- [ ] checklists and UAT tersedia.

---

# 123. Implementation Roadmap

## Phase 1 — Assurance & Proofing

- assurance model;
- proofing registry;
- proofing evidence;
- assurance service;
- re-proofing workflow;
- audit events.

## Phase 2 — Recovery Foundation

- recovery service;
- secure tokens;
- channel registry;
- password/MFA recovery;
- notifications;
- rate limiting.

## Phase 3 — Adaptive Risk

- risk signal ingestion;
- risk engine;
- step-up policies;
- device trust;
- session reevaluation;
- reason codes.

## Phase 4 — Compromise & Fraud

- compromised account cases;
- containment;
- activity review;
- recovery fraud detection;
- cooling-off;
- post-recovery monitoring.

## Phase 5 — Advanced Identity Assurance

- external proofing providers;
- behavioral analytics;
- continuous risk;
- hardware-backed assurance;
- identity intelligence feeds;
- automated reconciliation.

---

# 124. Initial Implementation Backlog

```text
IAM08-001 Assurance Level Registry
IAM08-002 Identity Proofing Service
IAM08-003 Proofing Evidence Registry
IAM08-004 Account Recovery Service
IAM08-005 Recovery Token Service
IAM08-006 Recovery Channel Registry
IAM08-007 MFA Reset Workflow
IAM08-008 Identity Risk Engine
IAM08-009 Risk Signal Collector
IAM08-010 Device Trust Registry
IAM08-011 Session Risk Evaluator
IAM08-012 Compromised Account Case
IAM08-013 Recovery Fraud Detection
IAM08-014 Cooling-Off Workflow
IAM08-015 Reconciliation Engine
IAM08-016 Identity Risk Dashboard
```

---

# 125. Approval Gate

Dokumen dapat menjadi Approved setelah:

- IAM Architecture review;
- Security Architecture review;
- Fraud/Risk review;
- RBAC/Privileged Access review;
- Privacy review;
- Operations/Support review;
- Federation review;
- Audit/Compliance review;
- Quality Engineering review;
- UAT review.

---

# 126. Closing Statement

Identity assurance dan recovery harus memastikan bahwa:

- identity benar;
- assurance sesuai risk;
- recovery tidak menjadi jalur takeover;
- privileged accounts mendapat kontrol lebih kuat;
- compromised accounts dapat ditahan segera;
- risk decisions dapat dijelaskan;
- setiap tindakan dapat diaudit.

Authentication membuktikan bahwa seseorang memiliki credential.

Identity proofing membuktikan siapa orang tersebut.

Risk governance menentukan apakah access masih layak diberikan pada saat itu.
