# SSOT-IAM-05 — API Key & Service Account Architecture

## Status Dokumen

| Item | Nilai |
|---|---|
| Kode Dokumen | SSOT-IAM-05 |
| Nama | API Key & Service Account Architecture |
| Versi | 1.0 |
| Status | Draft Architecture |
| Domain | Platform Kernel / IAM |
| Berlaku Untuk | Multi-tenant, multi-organization, multi-business entity, healthcare, non-healthcare |
| Dependensi | SSOT-IAM-01, SSOT-IAM-02, SSOT-IAM-03, SSOT-IAM-04, SSOT-SCOPE, SSOT-RBAC, SSOT-AUDIT |

---

# 1. Tujuan

Dokumen ini mendefinisikan arsitektur identitas non-manusia untuk platform.

Identitas non-manusia mencakup:

- service account;
- API client;
- API key;
- integration credential;
- scheduler account;
- queue worker account;
- webhook client;
- machine-to-machine authentication.

Tujuannya adalah memastikan integrasi sistem tidak memakai akun manusia, tetap scope-aware, RBAC-aware, dan audit-aware.

---

# 2. Prinsip Dasar

## 2.1 Akun manusia dan akun mesin harus dipisah

Tidak boleh:

```text
cron job memakai akun admin manusia
integrasi SATUSEHAT memakai akun super admin
queue worker memakai user dokter/perawat
```

Harus:

```text
service_account
api_client
system_user
```

## 2.2 Least Privilege

Service account hanya diberi permission minimum sesuai tugas.

## 2.3 Scope-aware

Setiap service account/API client harus memiliki scope.

Contoh:

```text
tenant_id
organization_id
business_entity_id
```

## 2.4 RBAC-aware

Service account memiliki role/permission seperti user, tetapi role-nya khusus machine.

## 2.5 Secret tidak boleh disimpan plain

API key, client secret, token, dan credential harus disimpan dalam bentuk:

```text
hash
encrypted secret
vault reference
```

## 2.6 Semua akses diaudit

Setiap autentikasi dan request penting dari service account/API client wajib masuk audit.

---

# 3. Jenis Identitas Non-Manusia

```text
service_account
api_client
integration_client
webhook_client
scheduler_account
queue_worker_account
system_user
```

## 3.1 Service Account

Digunakan oleh sistem internal.

Contoh:

- scheduler;
- queue worker;
- report generator;
- audit archive job;
- notification worker.

## 3.2 API Client

Digunakan aplikasi eksternal atau modul integrasi.

Contoh:

- mobile app;
- partner system;
- third-party integration;
- SATUSEHAT gateway;
- BPJS gateway.

## 3.3 Integration Client

Client khusus untuk koneksi ke sistem eksternal.

## 3.4 Webhook Client

Identitas pengirim/penerima webhook.

## 3.5 Scheduler Account

Identitas untuk job otomatis.

## 3.6 Queue Worker Account

Identitas untuk worker background.

## 3.7 System User

Identitas internal untuk event sistem yang tidak dilakukan user manusia.

---

# 4. Identity Model

```text
users
└── service_accounts
└── api_clients
└── user_scope_assignments
└── user_role_assignments
```

Service account tetap dapat direpresentasikan sebagai `users.user_type = service_account`.

API client dapat dihubungkan ke user system jika butuh Scope/RBAC.

---

# 5. Service Account Database

```sql
CREATE TABLE service_accounts (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,

    tenant_id BIGINT UNSIGNED NOT NULL,
    user_id BIGINT UNSIGNED NOT NULL,

    code VARCHAR(100) NOT NULL,
    name VARCHAR(150) NOT NULL,
    description TEXT NULL,
    purpose TEXT NOT NULL,

    owner_user_id BIGINT UNSIGNED NULL,
    owner_team_id BIGINT UNSIGNED NULL,

    status ENUM('active','inactive','revoked','expired') NOT NULL DEFAULT 'active',

    valid_from DATETIME NULL,
    valid_until DATETIME NULL,

    last_used_at DATETIME NULL,
    last_used_ip VARCHAR(45) NULL,

    created_by BIGINT UNSIGNED NULL,
    revoked_by BIGINT UNSIGNED NULL,
    revoked_at DATETIME NULL,
    revoke_reason TEXT NULL,

    created_at TIMESTAMP NULL,
    updated_at TIMESTAMP NULL,
    deleted_at TIMESTAMP NULL,

    UNIQUE KEY uq_service_account_code (tenant_id, code),
    INDEX idx_service_account_user (user_id),
    INDEX idx_service_account_status (tenant_id, status),
    INDEX idx_service_account_owner (owner_user_id)
);
```

Rule:

- service account wajib punya owner;
- service account wajib punya tujuan;
- service account wajib punya expiry bila memungkinkan;
- service account wajib punya scope dan role;
- service account tidak boleh login UI.

---

# 6. API Client Database

```sql
CREATE TABLE api_clients (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,

    tenant_id BIGINT UNSIGNED NOT NULL,
    user_id BIGINT UNSIGNED NULL,

    client_id VARCHAR(150) NOT NULL UNIQUE,
    name VARCHAR(150) NOT NULL,
    description TEXT NULL,

    client_type ENUM('public','confidential','internal','partner') NOT NULL DEFAULT 'confidential',

    owner_user_id BIGINT UNSIGNED NULL,
    owner_team_id BIGINT UNSIGNED NULL,

    status ENUM('active','inactive','revoked','expired') NOT NULL DEFAULT 'active',

    allowed_grant_types JSON NULL,
    allowed_scopes JSON NULL,
    allowed_redirect_uris JSON NULL,
    allowed_origins JSON NULL,
    allowed_ips JSON NULL,

    valid_from DATETIME NULL,
    valid_until DATETIME NULL,

    last_used_at DATETIME NULL,
    last_used_ip VARCHAR(45) NULL,

    created_by BIGINT UNSIGNED NULL,
    revoked_by BIGINT UNSIGNED NULL,
    revoked_at DATETIME NULL,
    revoke_reason TEXT NULL,

    created_at TIMESTAMP NULL,
    updated_at TIMESTAMP NULL,
    deleted_at TIMESTAMP NULL,

    INDEX idx_api_clients_tenant_status (tenant_id, status),
    INDEX idx_api_clients_owner (owner_user_id)
);
```

---

# 7. API Key Database

```sql
CREATE TABLE api_keys (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,

    tenant_id BIGINT UNSIGNED NOT NULL,
    api_client_id BIGINT UNSIGNED NULL,
    service_account_id BIGINT UNSIGNED NULL,

    key_prefix VARCHAR(30) NOT NULL,
    key_hash VARCHAR(255) NOT NULL,

    name VARCHAR(150) NOT NULL,
    description TEXT NULL,

    status ENUM('active','inactive','revoked','expired') NOT NULL DEFAULT 'active',

    allowed_scopes JSON NULL,
    allowed_ips JSON NULL,

    valid_from DATETIME NULL,
    valid_until DATETIME NULL,

    last_used_at DATETIME NULL,
    last_used_ip VARCHAR(45) NULL,

    created_by BIGINT UNSIGNED NULL,
    revoked_by BIGINT UNSIGNED NULL,
    revoked_at DATETIME NULL,
    revoke_reason TEXT NULL,

    created_at TIMESTAMP NULL,
    updated_at TIMESTAMP NULL,
    deleted_at TIMESTAMP NULL,

    UNIQUE KEY uq_api_key_prefix (key_prefix),
    INDEX idx_api_key_hash (key_hash),
    INDEX idx_api_key_client (api_client_id),
    INDEX idx_api_key_service_account (service_account_id),
    INDEX idx_api_key_status (tenant_id, status)
);
```

Rule:

- API key asli hanya tampil sekali saat dibuat;
- database hanya menyimpan hash;
- key prefix dipakai untuk lookup cepat;
- API key harus punya expiry;
- API key dapat dirotasi;
- API key revocation wajib audit.

---

# 8. Client Secret Database

```sql
CREATE TABLE api_client_secrets (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,

    tenant_id BIGINT UNSIGNED NOT NULL,
    api_client_id BIGINT UNSIGNED NOT NULL,

    secret_prefix VARCHAR(30) NOT NULL,
    secret_hash VARCHAR(255) NOT NULL,

    status ENUM('active','inactive','revoked','expired') NOT NULL DEFAULT 'active',

    valid_from DATETIME NULL,
    valid_until DATETIME NULL,

    last_used_at DATETIME NULL,

    created_by BIGINT UNSIGNED NULL,
    revoked_by BIGINT UNSIGNED NULL,
    revoked_at DATETIME NULL,
    revoke_reason TEXT NULL,

    created_at TIMESTAMP NULL,
    updated_at TIMESTAMP NULL,

    UNIQUE KEY uq_client_secret_prefix (secret_prefix),
    INDEX idx_client_secret_client (api_client_id),
    INDEX idx_client_secret_status (tenant_id, status)
);
```

---

# 9. Integration Credential Database

Credential eksternal seperti SATUSEHAT, BPJS, payment gateway, email gateway, WhatsApp gateway.

```sql
CREATE TABLE integration_credentials (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,

    tenant_id BIGINT UNSIGNED NOT NULL,
    business_entity_id BIGINT UNSIGNED NULL,

    integration_code VARCHAR(100) NOT NULL,
    credential_name VARCHAR(150) NOT NULL,

    credential_type VARCHAR(50) NOT NULL,
    encrypted_payload TEXT NOT NULL,
    vault_reference VARCHAR(255) NULL,

    status ENUM('active','inactive','revoked','expired') NOT NULL DEFAULT 'active',

    valid_from DATETIME NULL,
    valid_until DATETIME NULL,

    last_used_at DATETIME NULL,
    last_rotation_at DATETIME NULL,
    next_rotation_due_at DATETIME NULL,

    created_by BIGINT UNSIGNED NULL,
    rotated_by BIGINT UNSIGNED NULL,
    revoked_by BIGINT UNSIGNED NULL,
    revoked_at DATETIME NULL,

    created_at TIMESTAMP NULL,
    updated_at TIMESTAMP NULL,
    deleted_at TIMESTAMP NULL,

    INDEX idx_integration_credential_scope (tenant_id, business_entity_id),
    INDEX idx_integration_credential_code (integration_code),
    INDEX idx_integration_credential_status (status)
);
```

Rule:

- jangan simpan credential plain;
- gunakan encryption atau vault;
- akses credential harus diaudit;
- rotation harus didukung.

---

# 10. Credential Rotation

Credential rotation flow:

```text
Create new secret
→ Mark old secret as active until grace period
→ Deploy/update consumer
→ Verify new secret works
→ Revoke old secret
→ Audit rotation
```

Event:

```text
iam.api_key.rotated
iam.client_secret.rotated
iam.integration_credential.rotated
```

---

# 11. API Key Creation Flow

```text
Admin/API owner requests key
→ Validate permission
→ Validate scope
→ Generate random key
→ Store key hash
→ Show key once
→ Audit iam.api_key.created
```

Key format rekomendasi:

```text
nlk_live_xxxxxxxxx
nlk_test_xxxxxxxxx
```

Prefix membantu identifikasi environment.

---

# 12. API Key Authentication Flow

```text
Request masuk
→ Extract API key
→ Parse prefix
→ Lookup api_keys by prefix
→ Verify hash
→ Check status
→ Check expiry
→ Check allowed IP
→ Resolve linked client/service account
→ Resolve scope
→ Resolve permission
→ Audit auth.api_key.success
→ Continue request
```

Jika gagal:

```text
Audit auth.api_key.failed
Return 401
```

---

# 13. Machine-to-Machine Auth

Metode yang dapat didukung:

```text
API Key
Client ID + Client Secret
JWT signed assertion
mTLS
OAuth2 Client Credentials
```

Fase awal:

```text
API Key
Client ID + Client Secret
```

Future-ready:

```text
OAuth2 Client Credentials
mTLS
```

---

# 14. Scope Binding

API key/service account dapat dibatasi ke:

```text
tenant
organization
business_entity
branch
department
service
team
```

Tidak disarankan memberi API key scope platform penuh kecuali untuk internal platform operation.

---

# 15. RBAC Binding

Service account harus punya role khusus.

Contoh role:

```text
integration_satusehat_client
integration_bpjs_client
notification_worker
report_scheduler
audit_archiver
webhook_dispatcher
```

Permission contoh:

```text
integration.message.send
integration.message.read
report.generate
notification.send
audit.archive.run
```

---

# 16. API Client Permissions

API client tidak otomatis boleh semua endpoint.

Endpoint harus tetap dilindungi:

```text
Scope Middleware
API Auth Middleware
Permission Middleware
Rate Limit Middleware
Audit Middleware
```

---

# 17. Rate Limiting

Rate limit berdasarkan:

```text
api_client_id
api_key_id
tenant_id
ip_address
endpoint
```

Default:

- auth endpoint lebih ketat;
- write endpoint lebih ketat;
- read endpoint dapat lebih longgar;
- export endpoint sangat ketat.

---

# 18. IP Allowlist

API key dan client secret dapat dibatasi IP.

Kolom:

```text
allowed_ips JSON
```

Jika IP tidak cocok:

```text
auth.api_key.failed
reason = ip_not_allowed
```

---

# 19. Environment Separation

Pisahkan:

```text
test
staging
production
```

Key production tidak boleh dipakai di staging.

Gunakan prefix:

```text
nlk_test_
nlk_live_
```

---

# 20. Webhook Signature

Webhook keluar harus ditandatangani.

Header contoh:

```text
X-Nerslink-Signature
X-Nerslink-Timestamp
X-Nerslink-Event-Id
```

Verification:

```text
HMAC(payload + timestamp, webhook_secret)
```

---

# 21. Webhook Secret Database

```sql
CREATE TABLE webhook_secrets (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,

    tenant_id BIGINT UNSIGNED NOT NULL,
    api_client_id BIGINT UNSIGNED NULL,

    endpoint_url VARCHAR(500) NOT NULL,
    secret_hash VARCHAR(255) NOT NULL,
    secret_encrypted TEXT NULL,

    status ENUM('active','inactive','revoked') NOT NULL DEFAULT 'active',

    created_at TIMESTAMP NULL,
    updated_at TIMESTAMP NULL,
    revoked_at DATETIME NULL,

    INDEX idx_webhook_secret_client (api_client_id),
    INDEX idx_webhook_secret_status (tenant_id, status)
);
```

---

# 22. Audit Events

Wajib:

```text
iam.service_account.created
iam.service_account.updated
iam.service_account.revoked
iam.api_client.created
iam.api_client.updated
iam.api_client.revoked
iam.api_key.created
iam.api_key.revoked
iam.api_key.rotated
iam.client_secret.created
iam.client_secret.revoked
iam.client_secret.rotated
iam.integration_credential.created
iam.integration_credential.accessed
iam.integration_credential.rotated
auth.api_key.success
auth.api_key.failed
auth.client_secret.success
auth.client_secret.failed
```

Audit menyimpan:

```text
actor
client_id
service_account_id
scope_snapshot
ip_address
endpoint
result
failure_reason
correlation_id
created_at
```

---

# 23. Secret Access Policy

Akses ke secret hanya boleh oleh:

```text
security_admin
integration_operator
system process yang sah
```

Secret tidak boleh tampil ulang setelah dibuat.

Jika perlu tampil, buat secret baru.

---

# 24. Revocation Policy

API key/secret harus bisa dicabut segera.

Revocation harus:

```text
set status revoked
set revoked_at
set revoked_by
set revoke_reason
clear active cache
audit event
```

---

# 25. Cache Strategy

API key lookup dapat di-cache.

Cache harus invalidated saat:

```text
key revoked
key rotated
client revoked
service account revoked
role changed
scope changed
permission changed
```

---

# 26. Monitoring

Pantau:

- failed API auth;
- key expired;
- key near expiry;
- unusual request volume;
- IP mismatch;
- revoked key usage;
- integration credential access.

---

# 27. Anti-Pattern

Hindari:

```text
API key plain di database
API key tanpa expiry
service account tanpa owner
service account memakai super admin
integrasi memakai akun manusia
secret tampil ulang di UI
credential di .env untuk semua tenant
shared API key antar tenant
tanpa audit API auth
tanpa IP/rate limit
```

---

# 28. UAT Scenario

## Scenario 1 — Create API Key

```text
Given admin punya permission iam.api_key.create
When membuat API key
Then key asli tampil sekali
And hash tersimpan
And audit iam.api_key.created tercatat
```

## Scenario 2 — API Key Success

```text
Given API key aktif
When request API dengan key valid
Then request diterima
And scope/service account resolved
And audit auth.api_key.success tercatat
```

## Scenario 3 — Revoked API Key

```text
Given API key revoked
When request API memakai key tersebut
Then request ditolak 401
And audit auth.api_key.failed tercatat
```

## Scenario 4 — IP Not Allowed

```text
Given API key punya allowed_ips
When request dari IP lain
Then request ditolak
And failure_reason = ip_not_allowed
```

## Scenario 5 — Secret Rotation

```text
Given API client punya secret lama
When secret baru dibuat dan lama dicabut
Then secret lama gagal dipakai
And audit rotation tercatat
```

## Scenario 6 — Service Account Scope

```text
Given service account hanya scope Klinik A
When mencoba akses data Klinik B
Then Scope Guard menolak
And audit scope.denied tercatat
```

---

# 29. Definition of Done

API Key & Service Account dianggap siap bila:

- service account tersedia;
- API client tersedia;
- API key disimpan hash;
- client secret disimpan hash;
- integration credential terenkripsi/vault-ready;
- key/secret punya expiry;
- key/secret dapat direvoke;
- rotation tersedia;
- service account scope-aware;
- service account RBAC-aware;
- API auth diaudit;
- rate limit tersedia;
- IP allowlist tersedia;
- webhook signature tersedia;
- tidak ada integrasi memakai akun manusia.

---

# 30. Kesimpulan

Service account dan API key adalah fondasi integrasi enterprise.

Pada platform healthcare, komponen ini akan dipakai untuk:

- SATUSEHAT;
- BPJS;
- payment gateway;
- WhatsApp/email gateway;
- lab/radiology integration;
- mobile app;
- webhook partner;
- background jobs.

Semua identitas non-manusia harus tetap mengikuti prinsip yang sama:

```text
Scope-aware
RBAC-aware
Audit-aware
Least privilege
No plain secret
Rotatable
Revocable
```
