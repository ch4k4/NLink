# SSOT-IAM-06 — Federation, SSO & External Identity Architecture

---

## Status Dokumen

| Item | Nilai |
|---|---|
| Kode | SSOT-IAM-06 |
| Judul | Federation, SSO & External Identity Architecture |
| Versi | 1.0 |
| Status | Draft Architecture |
| Domain | Platform Kernel |
| Kategori | Identity & Access Management |
| Cakupan | SSO, Identity Federation, External Identity Providers, Account Linking, JIT Provisioning, Claims Mapping, Logout, Trust, Tenant Routing |
| Bergantung pada | SSOT-IAM-01, SSOT-IAM-02, SSOT-IAM-03, SSOT-IAM-04, SSOT-IAM-05, SSOT-SCOPE-01, SSOT-RBAC-01, SSOT-AUDIT-01, SSOT-SEC-01 |
| Target Stack | PHP 8.1+, Composer, PSR-4, PDO, MySQL 8/MariaDB, Modular Monolith |
| Target Protocol | OpenID Connect, OAuth 2.0, SAML 2.0 |
| Target Evolusi | Enterprise SSO, Multi-IdP, Partner Federation, B2B/B2E/B2C Identity |

---

# 1. Executive Summary

SSOT-IAM-06 menetapkan arsitektur resmi untuk Single Sign-On, identity federation, dan external identity pada Platform Kernel.

Dokumen ini mengatur:

- external identity provider;
- enterprise SSO;
- OpenID Connect;
- OAuth 2.0;
- SAML 2.0;
- tenant-aware identity provider routing;
- identity brokering;
- account linking;
- just-in-time provisioning;
- pre-provisioned federation;
- claims mapping;
- external group mapping;
- local role assignment;
- MFA assurance;
- login policy;
- logout;
- session correlation;
- identity provider lifecycle;
- certificate and key rotation;
- metadata management;
- failure handling;
- audit;
- observability;
- security;
- UAT;
- Definition of Done.

Tujuan akhirnya adalah memastikan external identity:

- tidak menggantikan local authorization;
- tidak menciptakan account duplicate;
- terikat ke tenant yang benar;
- memiliki trust relationship yang eksplisit;
- memvalidasi issuer, audience, signature, nonce, dan state;
- mendukung revocation dan disablement;
- dapat diaudit;
- dapat dipulihkan;
- tidak menjadi jalur bypass terhadap RBAC, scope, MFA, atau session controls.

---

# 2. Objectives

Framework harus:

- menyediakan SSO yang aman;
- mendukung multiple identity providers;
- menjaga tenant isolation;
- memisahkan authentication dari authorization;
- mengontrol identity linking;
- mendukung JIT provisioning;
- menyediakan claims normalization;
- menjaga session assurance;
- mendukung partner federation;
- menyediakan fail-safe behavior;
- menjaga audit trail lengkap.

---

# 3. Core Principles

```text
External Authentication, Local Authorization
Explicit Trust Relationships
Tenant-Aware Provider Resolution
No Automatic Account Linking by Email Alone
Claims Are Inputs, Not Final Permissions
Fail Closed on Trust Validation Failure
MFA Assurance Must Be Preserved
Federated Sessions Must Be Correlated
Keys and Metadata Must Be Rotatable
Every Federation Decision Must Be Auditable
```

---

# 4. Scope

Framework berlaku untuk:

```text
Enterprise Workforce SSO
Tenant-Specific SSO
Partner Federation
External Practitioner Identity
Customer/Patient Identity Federation
Administrative SSO
Service Portal Federation
Identity Broker Integration
```

---

# 5. Non-Scope

Dokumen ini tidak mengatur secara detail:

- local password hashing;
- local session implementation;
- API key lifecycle;
- service account authentication;
- complete RBAC permission catalog;
- external provider commercial procurement.

Area tersebut diatur oleh SSOT IAM, RBAC, Security, dan Governance terkait.

---

# 6. Terminology

## Identity Provider

Sistem eksternal yang mengautentikasi subject dan menerbitkan assertion atau token.

## Service Provider / Relying Party

Platform yang menerima hasil authentication dari identity provider.

## Federation

Trust relationship antar security domains untuk pertukaran identity assertions.

## Identity Broker

Komponen perantara yang menghubungkan platform dengan satu atau lebih identity providers.

## External Subject

Identifier subject yang diterbitkan oleh external provider.

## Local Identity

Identity internal platform yang menjadi anchor untuk authorization, scope, audit, dan lifecycle.

---

# 7. Supported Protocols

```text
OpenID Connect 1.0
OAuth 2.0 Authorization Code Flow
SAML 2.0 Web Browser SSO
```

---

# 8. Protocol Preference

Urutan preferensi:

```text
OpenID Connect
→ SAML 2.0
→ Approved Broker Adapter
```

OIDC direkomendasikan untuk implementasi baru.

---

# 9. OAuth Flow

Untuk browser-based login gunakan:

```text
Authorization Code Flow
+ PKCE
+ state
+ nonce
```

Implicit flow tidak boleh digunakan untuk implementasi baru.

---

# 10. SAML Binding

Recommended:

```text
HTTP-Redirect for AuthnRequest
HTTP-POST for Response
```

Encrypted assertions dapat diwajibkan berdasarkan risk.

---

# 11. Architecture Overview

```text
User Browser
    │
    ▼
Federation Entry Point
    │
    ├── Tenant Resolver
    ├── Provider Resolver
    ├── Protocol Adapter
    ├── Trust Validator
    ├── Claims Normalizer
    ├── Identity Linker
    ├── Provisioning Policy
    ├── Authentication Assurance Evaluator
    └── Session Issuer
            │
            ▼
Local Identity + Scope + RBAC
```

---

# 12. Separation of Responsibilities

External IdP determines:

- subject authentication;
- authentication method;
- authentication time;
- selected identity claims.

Platform determines:

- local account status;
- tenant membership;
- organization/clinic scope;
- roles;
- permissions;
- feature access;
- session policy;
- step-up requirements.

---

# 13. Trust Model

Every federation relationship must define:

```text
provider_id
protocol
issuer
audience/client_id/entity_id
tenant_scope
metadata_source
signing_keys
encryption_keys
allowed_algorithms
claims_policy
assurance_policy
provisioning_policy
logout_policy
owner
status
```

---

# 14. Trust Levels

```text
INTERNAL_ENTERPRISE
TRUSTED_TENANT
REVIEWED_PARTNER
RESTRICTED_EXTERNAL
EXPERIMENTAL
```

---

# 15. Trust Status

```text
DRAFT
VALIDATING
ACTIVE
SUSPENDED
DEPRECATED
RETIRED
FAILED
```

---

# 16. Provider Types

```text
PLATFORM_GLOBAL
TENANT_SPECIFIC
ORGANIZATION_SPECIFIC
PARTNER
BROKER
```

---

# 17. Provider Ownership

Every provider must have:

- business owner;
- technical owner;
- security reviewer;
- tenant owner where applicable;
- support contact.

---

# 18. Multi-Tenant Provider Resolution

Provider selection may use:

- tenant code;
- verified email domain;
- organization invitation;
- dedicated login URL;
- tenant subdomain;
- explicit provider selection;
- trusted discovery token.

---

# 19. Tenant Routing Rule

Tenant routing must not rely solely on unverified email domain.

---

# 20. Dedicated Login Endpoint

Recommended:

```text
/auth/sso/{tenantCode}
/auth/federation/{providerCode}/start
/auth/federation/{providerCode}/callback
```

---

# 21. Home Realm Discovery

Home Realm Discovery may present approved providers based on tenant context.

---

# 22. Provider Enumeration

Public login pages should avoid unnecessary disclosure of sensitive tenant/provider configuration.

---

# 23. Provider Resolver

```php
interface IdentityProviderResolverInterface
{
    public function resolve(
        FederationStartRequest $request
    ): IdentityProviderConfiguration;
}
```

---

# 24. Provider Configuration

```php
final readonly class IdentityProviderConfiguration
{
    public function __construct(
        public string $providerId,
        public string $protocol,
        public string $issuer,
        public string $tenantId,
        public string $status,
        public array $allowedAlgorithms,
        public array $claimsPolicy,
    ) {
    }
}
```

---

# 25. External Identity Record

Minimum:

```text
external_identity_id
provider_id
issuer
subject
local_user_id
tenant_id
status
linked_at
last_authenticated_at
```

---

# 26. External Subject Uniqueness

Unique key should include:

```text
issuer + subject
```

Email must not be used as external subject identifier.

---

# 27. Pairwise Subject

OIDC pairwise subject identifiers should be supported.

---

# 28. Account Linking Policy

Allowed modes:

```text
ADMIN_PRELINKED
INVITATION_LINKED
USER_CONFIRMED_LINK
JIT_LINK_WITH_STRONG_MATCH
NO_LINKING
```

---

# 29. Prohibited Linking

Automatic linking based only on:

- email;
- display name;
- phone number;
- username similarity

is prohibited.

---

# 30. Strong Match

Strong matching may require:

- verified invitation;
- local authenticated session;
- immutable employee identifier;
- approved partner identifier;
- administrator confirmation;
- multiple verified attributes.

---

# 31. Linking Conflict

If external subject matches multiple local identities, login must fail and create review task.

---

# 32. Unlinking

Unlinking requires:

- authorization;
- assurance verification;
- impact assessment;
- audit;
- fallback login method where required.

---

# 33. Orphan Prevention

Do not remove the last viable login method for required administrative accounts without approved recovery path.

---

# 34. Just-in-Time Provisioning

JIT provisioning may create local identity after successful federation.

---

# 35. JIT Preconditions

- provider trusted;
- tenant active;
- subject valid;
- required claims present;
- invitation or policy allows creation;
- duplicate checks pass;
- default access policy defined;
- audit enabled.

---

# 36. JIT Default Access

JIT-created users must receive minimum access only.

---

# 37. Pre-Provisioned Federation

High-risk users should be provisioned before first login.

Examples:

- administrators;
- privileged clinical users;
- finance approvers;
- security operators.

---

# 38. SCIM Direction

Future lifecycle provisioning may use SCIM 2.0 through separate approved implementation.

Authentication federation and provisioning lifecycle remain separate concerns.

---

# 39. Deprovisioning

External authentication success must not reactivate a locally suspended or terminated identity automatically.

---

# 40. Local Status Precedence

Local status values such as:

```text
SUSPENDED
LOCKED
TERMINATED
DISABLED
```

must override external authentication success.

---

# 41. Claims Categories

```text
IDENTITY
CONTACT
ORGANIZATION
ASSURANCE
GROUP
ENTITLEMENT_HINT
LOCALE
```

---

# 42. Required OIDC Claims

Typical:

```text
iss
sub
aud
exp
iat
nonce
```

Additional claims depend on policy.

---

# 43. Required SAML Elements

Typical:

```text
Issuer
Subject/NameID
AudienceRestriction
Conditions
AuthnStatement
Signature
```

---

# 44. Claims Normalization

External claims must be mapped into canonical internal claims.

---

# 45. Canonical Claims

Potential:

```text
external_subject
verified_email
display_name
employee_id
organization_code
clinic_code
authentication_context
authentication_time
groups
```

---

# 46. Claims Mapping

Claims mapping must be:

- provider-specific;
- versioned;
- validated;
- auditable;
- testable.

---

# 47. Claims Mapping Example

```yaml
provider: tenant-a-entra
version: 1.0
mappings:
  external_subject: sub
  verified_email: email
  employee_id: extension_employee_id
  organization_code: tenant_org
  groups: groups
```

---

# 48. Claims Transformation

Transformations must use allowlisted operations.

Arbitrary executable expressions are prohibited.

---

# 49. Missing Required Claim

Missing required claim must fail authentication or provisioning according to policy.

---

# 50. Claim Validation

Validate:

- type;
- format;
- allowed values;
- maximum length;
- tenant association;
- verified status where relevant.

---

# 51. Group Claims

External groups may be consumed as mapping inputs.

---

# 52. External Group to Local Role

External group must not be treated directly as final platform permission.

Flow:

```text
External Group
→ Approved Mapping
→ Local Role Assignment Policy
→ Scoped Role Assignment
→ Permission Evaluation
```

---

# 53. Group Mapping Registry

Minimum:

```text
provider_id
external_group
local_role
scope_type
scope_reference
mapping_status
effective_dates
owner
```

---

# 54. Group Overages

Providers that truncate group claims must use approved group retrieval strategy or deny mapping-dependent access.

---

# 55. Default Role Prohibition

Do not assign broad default role to all federated users.

---

# 56. Scope Mapping

Tenant, organization, and clinic mappings must resolve to existing trusted internal scope records.

---

# 57. Unknown Scope

Unknown external scope code must not create new organization or clinic automatically unless separate governed provisioning exists.

---

# 58. Authorization Boundary

Federation establishes identity.

RBAC and scope engine establish authorization.

---

# 59. Authentication Assurance

Platform should evaluate external authentication assurance.

---

# 60. Assurance Inputs

Potential:

```text
acr
amr
AuthnContextClassRef
authentication_time
MFA indicator
device assurance
risk signal
```

---

# 61. Assurance Levels

```text
LOW
STANDARD
STRONG
PRIVILEGED
UNKNOWN
```

---

# 62. Unknown Assurance

Unknown assurance must not satisfy privileged access requirements.

---

# 63. MFA Preservation

If external IdP claims MFA, platform must validate accepted assurance context.

---

# 64. Step-Up Authentication

Platform may require local or federated step-up for sensitive actions.

---

# 65. Authentication Age

Sensitive operations may require recent authentication.

---

# 66. IdP-Initiated SSO

IdP-initiated SAML SSO should be disabled by default.

If enabled, require:

- explicit provider;
- audience validation;
- replay protection;
- tenant resolution;
- relay state validation;
- documented risk acceptance.

---

# 67. SP-Initiated SSO

SP-initiated login is preferred.

---

# 68. OIDC State

State must:

- be unpredictable;
- be single-use;
- be session-bound;
- expire quickly;
- be validated exactly.

---

# 69. OIDC Nonce

Nonce must:

- be unpredictable;
- be request-bound;
- be single-use;
- be validated against ID token;
- expire.

---

# 70. PKCE

Use:

```text
S256
```

Plain PKCE challenge is prohibited.

---

# 71. Redirect URI

Redirect URIs must be exact allowlist matches.

Wildcard redirect URIs are prohibited.

---

# 72. Issuer Validation

Issuer must match configured trusted issuer exactly.

---

# 73. Audience Validation

Token/assertion audience must include expected client/entity identifier.

---

# 74. Signature Validation

Only approved algorithms and keys may be used.

---

# 75. Algorithm Controls

Reject:

- `none`;
- unapproved weak algorithms;
- unexpected algorithm downgrade;
- algorithm/key type mismatch.

---

# 76. Token Time Validation

Validate:

```text
exp
nbf
iat
```

with bounded clock skew.

---

# 77. SAML Conditions

Validate:

- NotBefore;
- NotOnOrAfter;
- AudienceRestriction;
- Recipient;
- InResponseTo where applicable.

---

# 78. Replay Protection

Store and reject reused:

- authorization responses;
- SAML response IDs;
- assertion IDs;
- nonce;
- state.

---

# 79. Metadata Management

OIDC discovery and SAML metadata must be controlled.

---

# 80. Metadata Sources

```text
STATIC_APPROVED
SIGNED_REMOTE_METADATA
MANAGED_BROKER
```

---

# 81. Remote Metadata

Remote metadata retrieval requires:

- HTTPS;
- host allowlist;
- timeout;
- size limit;
- cache;
- signature validation where applicable;
- last-known-good fallback.

---

# 82. Key Rotation

Support overlapping old and new keys during controlled rotation.

---

# 83. JWKS Handling

JWKS cache must have:

- bounded TTL;
- refresh on unknown key ID;
- rate limiting;
- last-known-good key set;
- issuer binding.

---

# 84. SAML Certificate Rotation

Support:

- multiple active signing certificates;
- planned overlap;
- expiry alerts;
- emergency revocation.

---

# 85. Client Secret

OIDC confidential client secrets must use secrets management.

---

# 86. Private Key Authentication

For high-assurance clients, private key-based client authentication may be preferred.

---

# 87. Federation Session

Federated login results in local platform session governed by IAM-03.

---

# 88. Session Correlation

Track:

```text
local_session_id
provider_id
external_session_id
subject
authentication_time
assurance
```

---

# 89. Session Lifetime

Local session lifetime must not exceed policy merely because external IdP session remains active.

---

# 90. Reauthentication

Platform may require reauthentication independently of external provider session.

---

# 91. Single Logout

Logout modes:

```text
LOCAL_ONLY
RP_INITIATED
FRONT_CHANNEL
BACK_CHANNEL
SAML_SINGLE_LOGOUT
```

---

# 92. Local Logout Minimum

Local logout must always terminate local session.

---

# 93. Federated Logout Limitations

Failure to terminate upstream IdP session must be communicated and logged where relevant.

---

# 94. Back-Channel Logout

Back-channel logout should validate issuer, audience, signature, events, and session/subject identifiers.

---

# 95. Logout CSRF

Logout endpoints must protect against unwanted logout where policy requires.

---

# 96. Provider Disablement

Disabling provider should:

- block new login;
- optionally revoke related sessions;
- preserve audit and links;
- notify owner;
- support recovery.

---

# 97. Emergency Kill Switch

Every external provider should support emergency suspension.

---

# 98. Provider Lifecycle

```text
REQUESTED
→ DUE_DILIGENCE
→ CONFIGURING
→ TESTING
→ ACTIVE
→ SUSPENDED
→ DEPRECATED
→ RETIRED
```

---

# 99. Provider Onboarding

Flow:

```text
Business Request
→ Security Review
→ Metadata Exchange
→ Configuration
→ Claims Mapping
→ Test
→ Tenant UAT
→ Approval
→ Activate
```

---

# 100. Due Diligence

Assess:

- provider ownership;
- protocol support;
- MFA capability;
- key management;
- availability;
- incident handling;
- data handling;
- support;
- exit plan.

---

# 101. Provider Change Management

Material changes require review:

- issuer;
- entity ID;
- redirect URI;
- certificates;
- signing algorithms;
- claims;
- group mappings;
- assurance;
- logout behavior.

---

# 102. Provider Retirement

Retirement plan must define:

- affected identities;
- alternative login;
- session handling;
- account unlinking;
- metadata removal;
- secret/key revocation;
- communication;
- evidence retention.

---

# 103. Break-Glass Access

Platform must maintain approved emergency access independent of external federation for critical operations.

---

# 104. Break-Glass Controls

- limited accounts;
- strong MFA;
- offline credential handling where required;
- monitoring;
- restricted permissions;
- periodic testing;
- post-use review.

---

# 105. Failure Handling

Failure categories:

```text
PROVIDER_UNAVAILABLE
INVALID_RESPONSE
TRUST_FAILURE
CLAIMS_FAILURE
LINKING_CONFLICT
PROVISIONING_FAILURE
LOCAL_ACCOUNT_BLOCKED
SCOPE_MAPPING_FAILURE
ASSURANCE_INSUFFICIENT
```

---

# 106. Fail-Closed Conditions

Fail closed for:

- signature failure;
- issuer mismatch;
- audience mismatch;
- replay;
- nonce/state failure;
- unknown tenant;
- ambiguous account link;
- disabled local identity;
- insufficient privileged assurance.

---

# 107. Provider Outage

Provider outage must not trigger fallback to weaker unapproved authentication.

---

# 108. Fallback Authentication

Fallback must be explicitly configured per user class and risk level.

---

# 109. Error Disclosure

User-facing errors should avoid revealing sensitive configuration.

---

# 110. Correlation Reference

Federation errors should return safe reference ID for support.

---

# 111. Rate Limiting

Apply rate limits to:

- federation start;
- callback;
- metadata refresh;
- linking;
- discovery;
- failed validations.

---

# 112. Abuse Detection

Detect:

- repeated state failures;
- replay attempts;
- issuer spoofing;
- account linking abuse;
- unusual tenant routing;
- abnormal provisioning spikes.

---

# 113. Logging

Structured logs should include:

```text
event_code
provider_id
protocol
tenant_id
local_user_id
external_subject_hash
result
assurance
correlation_id
```

Do not log raw tokens or assertions.

---

# 114. Audit Events

```text
FEDERATION_PROVIDER_CREATED
FEDERATION_PROVIDER_ACTIVATED
FEDERATION_PROVIDER_SUSPENDED
FEDERATION_LOGIN_STARTED
FEDERATION_LOGIN_SUCCEEDED
FEDERATION_LOGIN_FAILED
EXTERNAL_IDENTITY_LINKED
EXTERNAL_IDENTITY_UNLINKED
JIT_USER_PROVISIONED
FEDERATED_ROLE_MAPPING_APPLIED
FEDERATION_LOGOUT_COMPLETED
FEDERATION_TRUST_VALIDATION_FAILED
```

---

# 115. Privacy

Store only claims necessary for approved purposes.

---

# 116. Claim Retention

Raw token/assertion retention should be avoided.

If evidence requires retention, protect, minimize, encrypt, and expire it.

---

# 117. Subject Hashing in Logs

Use stable or keyed hash only when operationally required and approved.

---

# 118. Tenant Isolation

Every external identity must resolve to exactly one trusted tenant context per login.

---

# 119. Multi-Tenant Identity

A human may have memberships in multiple tenants, but each authenticated session must have explicit active tenant context.

---

# 120. Tenant Switching

Tenant switching must re-evaluate:

- membership;
- provider policy;
- role assignments;
- assurance;
- session authorization context.

---

# 121. Cross-Tenant Linking

One external subject may link to multiple tenant memberships only through explicit governed model.

---

# 122. Provider Configuration Isolation

Tenant provider secrets, keys, mappings, and metadata must remain isolated.

---

# 123. Administrative Permissions

Potential permissions:

```text
iam.federation.view
iam.federation.manage
iam.federation.activate
iam.federation.suspend
iam.external_identity.view
iam.external_identity.link
iam.external_identity.unlink
iam.federation.mapping.manage
iam.federation.audit.view
```

---

# 124. Segregation of Duties

Sensitive provider activation should separate:

- configurator;
- security reviewer;
- approver;
- verifier.

---

# 125. Configuration Model

Minimum settings:

```text
provider_code
protocol
issuer
client_id/entity_id
redirect_uri/acs_url
metadata_url
signing_keys
allowed_algorithms
claims_mapping_version
provisioning_mode
assurance_policy
logout_mode
tenant_scope
```

---

# 126. Configuration Versioning

Provider configuration must be versioned.

---

# 127. Configuration Promotion

Promotion flow:

```text
Development
→ Test
→ Staging
→ Production
```

Secrets remain environment-specific.

---

# 128. Configuration Drift

Detect differences between approved and runtime provider configuration.

---

# 129. Health Checks

Provider health checks may verify:

- metadata availability;
- certificate expiry;
- discovery document;
- JWKS refresh;
- configuration completeness;
- callback readiness.

Do not perform destructive authentication in health checks.

---

# 130. Health Status

```text
HEALTHY
DEGRADED
UNHEALTHY
UNKNOWN
```

---

# 131. Certificate Alerts

Alert thresholds should cover:

- 90 days;
- 60 days;
- 30 days;
- 14 days;
- 7 days;
- expired.

---

# 132. Observability Metrics

```text
federation_login_total
federation_login_failure_total
federation_validation_failure_total
federation_provider_unavailable_total
federation_jit_provision_total
federation_link_conflict_total
federation_login_duration_seconds
federation_certificate_expiry_days
federation_active_provider_total
```

---

# 133. KPIs

Initial targets:

```text
Active providers without owner = 0
Active providers with expired certificate = 0
Federated logins with unresolved tenant = 0
Automatic email-only account links = 0
Privileged federation without accepted MFA assurance = 0
Provider changes without audit = 0
```

---

# 134. KRIs

```text
Trust validation failures
Linking conflicts
JIT provisioning spikes
Unknown assurance logins
Provider outage duration
Expired metadata/certificates
Cross-tenant routing attempts
Emergency provider suspensions
```

---

# 135. Database Direction

Potential tables:

```text
iam_identity_providers
iam_identity_provider_versions
iam_external_identities
iam_federation_transactions
iam_claim_mappings
iam_external_group_mappings
iam_federated_sessions
iam_federation_replay_guards
iam_provider_certificates
iam_federation_audit_links
```

---

# 136. Table: iam_identity_providers

```sql
CREATE TABLE iam_identity_providers (
    id CHAR(26) NOT NULL,
    provider_code VARCHAR(100) NOT NULL,
    name VARCHAR(255) NOT NULL,
    protocol VARCHAR(30) NOT NULL,
    issuer VARCHAR(1000) NOT NULL,
    tenant_id CHAR(26) NULL,
    provider_type VARCHAR(40) NOT NULL,
    trust_level VARCHAR(40) NOT NULL,
    owner_reference VARCHAR(180) NOT NULL,
    lifecycle_status VARCHAR(30) NOT NULL,
    current_version VARCHAR(100) NOT NULL,
    created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    updated_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6)
        ON UPDATE CURRENT_TIMESTAMP(6),

    PRIMARY KEY (id),
    UNIQUE KEY uq_iam_provider_code (provider_code),
    KEY idx_iam_provider_scope (
        tenant_id,
        lifecycle_status
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

# 137. Table: iam_identity_provider_versions

```sql
CREATE TABLE iam_identity_provider_versions (
    id CHAR(26) NOT NULL,
    identity_provider_id CHAR(26) NOT NULL,
    version VARCHAR(100) NOT NULL,
    configuration_json JSON NOT NULL,
    claims_mapping_version VARCHAR(100) NOT NULL,
    checksum_sha256 CHAR(64) NOT NULL,
    status VARCHAR(30) NOT NULL,
    approved_by VARCHAR(180) NULL,
    effective_from DATETIME(6) NOT NULL,
    effective_to DATETIME(6) NULL,

    PRIMARY KEY (id),
    UNIQUE KEY uq_iam_provider_version (
        identity_provider_id,
        version
    ),
    CONSTRAINT fk_iam_provider_version_provider
        FOREIGN KEY (identity_provider_id)
        REFERENCES iam_identity_providers (id)
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

# 138. Table: iam_external_identities

```sql
CREATE TABLE iam_external_identities (
    id CHAR(26) NOT NULL,
    identity_provider_id CHAR(26) NOT NULL,
    issuer VARCHAR(1000) NOT NULL,
    external_subject VARCHAR(500) NOT NULL,
    local_user_id CHAR(26) NOT NULL,
    tenant_id CHAR(26) NOT NULL,
    link_method VARCHAR(40) NOT NULL,
    status VARCHAR(30) NOT NULL,
    linked_at DATETIME(6) NOT NULL,
    last_authenticated_at DATETIME(6) NULL,
    unlinked_at DATETIME(6) NULL,

    PRIMARY KEY (id),
    UNIQUE KEY uq_iam_external_subject (
        identity_provider_id,
        external_subject
    ),
    KEY idx_iam_external_user (
        local_user_id,
        tenant_id,
        status
    ),
    CONSTRAINT fk_iam_external_provider
        FOREIGN KEY (identity_provider_id)
        REFERENCES iam_identity_providers (id)
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

# 139. Table: iam_federation_transactions

```sql
CREATE TABLE iam_federation_transactions (
    id CHAR(26) NOT NULL,
    transaction_code VARCHAR(100) NOT NULL,
    identity_provider_id CHAR(26) NOT NULL,
    tenant_id CHAR(26) NOT NULL,
    protocol VARCHAR(30) NOT NULL,
    state_hash CHAR(64) NULL,
    nonce_hash CHAR(64) NULL,
    status VARCHAR(30) NOT NULL,
    started_at DATETIME(6) NOT NULL,
    completed_at DATETIME(6) NULL,
    expires_at DATETIME(6) NOT NULL,
    error_code VARCHAR(100) NULL,
    correlation_id VARCHAR(100) NOT NULL,

    PRIMARY KEY (id),
    UNIQUE KEY uq_iam_federation_transaction (
        transaction_code
    ),
    KEY idx_iam_federation_status (
        status,
        expires_at
    ),
    CONSTRAINT fk_iam_federation_transaction_provider
        FOREIGN KEY (identity_provider_id)
        REFERENCES iam_identity_providers (id)
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

# 140. Table: iam_claim_mappings

```sql
CREATE TABLE iam_claim_mappings (
    id CHAR(26) NOT NULL,
    identity_provider_id CHAR(26) NOT NULL,
    mapping_version VARCHAR(100) NOT NULL,
    canonical_claim VARCHAR(180) NOT NULL,
    external_claim_path VARCHAR(500) NOT NULL,
    transformation_code VARCHAR(100) NULL,
    required_flag TINYINT(1) NOT NULL DEFAULT 0,
    status VARCHAR(30) NOT NULL,

    PRIMARY KEY (id),
    UNIQUE KEY uq_iam_claim_mapping (
        identity_provider_id,
        mapping_version,
        canonical_claim
    ),
    CONSTRAINT fk_iam_claim_mapping_provider
        FOREIGN KEY (identity_provider_id)
        REFERENCES iam_identity_providers (id)
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

# 141. Table: iam_external_group_mappings

```sql
CREATE TABLE iam_external_group_mappings (
    id CHAR(26) NOT NULL,
    identity_provider_id CHAR(26) NOT NULL,
    external_group VARCHAR(500) NOT NULL,
    local_role_id CHAR(26) NOT NULL,
    scope_type VARCHAR(30) NOT NULL,
    scope_reference CHAR(26) NOT NULL,
    status VARCHAR(30) NOT NULL,
    valid_from DATETIME(6) NULL,
    valid_to DATETIME(6) NULL,
    approved_by VARCHAR(180) NULL,

    PRIMARY KEY (id),
    UNIQUE KEY uq_iam_group_role_scope (
        identity_provider_id,
        external_group,
        local_role_id,
        scope_type,
        scope_reference
    ),
    CONSTRAINT fk_iam_group_mapping_provider
        FOREIGN KEY (identity_provider_id)
        REFERENCES iam_identity_providers (id)
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

# 142. Table: iam_federation_replay_guards

```sql
CREATE TABLE iam_federation_replay_guards (
    id CHAR(26) NOT NULL,
    identity_provider_id CHAR(26) NOT NULL,
    guard_type VARCHAR(30) NOT NULL,
    value_hash CHAR(64) NOT NULL,
    consumed_at DATETIME(6) NOT NULL,
    expires_at DATETIME(6) NOT NULL,

    PRIMARY KEY (id),
    UNIQUE KEY uq_iam_replay_guard (
        identity_provider_id,
        guard_type,
        value_hash
    ),
    KEY idx_iam_replay_guard_expiry (
        expires_at
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

# 143. SDK Contract Direction

Potential contracts:

```text
FederationServiceInterface
IdentityProviderResolverInterface
FederationProtocolAdapterInterface
FederationTrustValidatorInterface
ClaimsNormalizerInterface
ExternalIdentityLinkerInterface
FederatedProvisioningServiceInterface
AuthenticationAssuranceEvaluatorInterface
FederatedLogoutServiceInterface
```

---

# 144. Federation Service

```php
interface FederationServiceInterface
{
    public function start(
        FederationStartRequest $request
    ): FederationRedirect;

    public function complete(
        FederationCallbackRequest $request
    ): FederatedAuthenticationResult;
}
```

---

# 145. Protocol Adapter

```php
interface FederationProtocolAdapterInterface
{
    public function supports(string $protocol): bool;

    public function buildAuthenticationRequest(
        IdentityProviderConfiguration $provider,
        FederationTransaction $transaction
    ): FederationRedirect;

    public function validateResponse(
        IdentityProviderConfiguration $provider,
        FederationCallbackRequest $request
    ): ExternalAuthenticationAssertion;
}
```

---

# 146. Claims Normalizer

```php
interface ClaimsNormalizerInterface
{
    public function normalize(
        IdentityProviderConfiguration $provider,
        ExternalAuthenticationAssertion $assertion
    ): CanonicalExternalIdentityClaims;
}
```

---

# 147. Authentication Result

```php
final readonly class FederatedAuthenticationResult
{
    public function __construct(
        public string $localUserId,
        public string $tenantId,
        public string $providerId,
        public string $assuranceLevel,
        public bool $newlyProvisioned,
    ) {
    }
}
```

---

# 148. Event Codes

```text
IAM_FEDERATION_PROVIDER_REGISTERED
IAM_FEDERATION_PROVIDER_ACTIVATED
IAM_FEDERATION_PROVIDER_SUSPENDED
IAM_FEDERATION_LOGIN_STARTED
IAM_FEDERATION_LOGIN_SUCCEEDED
IAM_FEDERATION_LOGIN_FAILED
IAM_EXTERNAL_IDENTITY_LINKED
IAM_EXTERNAL_IDENTITY_UNLINKED
IAM_FEDERATED_USER_PROVISIONED
IAM_FEDERATED_ROLE_MAPPING_APPLIED
IAM_FEDERATION_LOGOUT_COMPLETED
IAM_FEDERATION_REPLAY_DETECTED
IAM_FEDERATION_CERTIFICATE_EXPIRING
```

---

# 149. Error Codes

```text
IAM_FEDERATION_PROVIDER_NOT_FOUND
IAM_FEDERATION_PROVIDER_INACTIVE
IAM_FEDERATION_PROTOCOL_UNSUPPORTED
IAM_FEDERATION_STATE_INVALID
IAM_FEDERATION_NONCE_INVALID
IAM_FEDERATION_REPLAY_DETECTED
IAM_FEDERATION_ISSUER_INVALID
IAM_FEDERATION_AUDIENCE_INVALID
IAM_FEDERATION_SIGNATURE_INVALID
IAM_FEDERATION_TOKEN_EXPIRED
IAM_FEDERATION_CLAIM_MISSING
IAM_FEDERATION_TENANT_UNRESOLVED
IAM_EXTERNAL_IDENTITY_LINK_CONFLICT
IAM_FEDERATED_PROVISIONING_DENIED
IAM_FEDERATED_ACCOUNT_DISABLED
IAM_FEDERATION_ASSURANCE_INSUFFICIENT
IAM_FEDERATION_SCOPE_MAPPING_INVALID
IAM_FEDERATION_LOGOUT_FAILED
```

---

# 150. Provider Onboarding Checklist

- [ ] Business owner assigned.
- [ ] Technical owner assigned.
- [ ] Security review complete.
- [ ] Tenant scope defined.
- [ ] Protocol approved.
- [ ] Issuer and audience verified.
- [ ] Metadata source approved.
- [ ] Certificates/keys verified.
- [ ] Allowed algorithms defined.
- [ ] Redirect/ACS URLs exact.
- [ ] Claims mapping tested.
- [ ] Account linking policy defined.
- [ ] Provisioning mode defined.
- [ ] MFA assurance policy defined.
- [ ] Logout behavior tested.
- [ ] Recovery and kill switch tested.
- [ ] Audit and metrics enabled.

---

# 151. Claims Mapping Checklist

- [ ] External subject immutable.
- [ ] Required claims identified.
- [ ] Types validated.
- [ ] Length bounded.
- [ ] Transformations allowlisted.
- [ ] Tenant mapping validated.
- [ ] Unknown scopes rejected.
- [ ] Group mappings approved.
- [ ] Broad default role absent.
- [ ] Mapping versioned.
- [ ] Negative tests pass.

---

# 152. Account Linking Checklist

- [ ] Linking method approved.
- [ ] Email-only linking prohibited.
- [ ] Existing local session verified where required.
- [ ] Duplicate check completed.
- [ ] Tenant membership verified.
- [ ] Conflict handling tested.
- [ ] Unlink process defined.
- [ ] Last-login-method protection works.
- [ ] Audit event recorded.

---

# 153. UAT — OIDC

- [ ] Authorization Code Flow works.
- [ ] PKCE S256 validated.
- [ ] State validation works.
- [ ] Nonce validation works.
- [ ] Issuer validation works.
- [ ] Audience validation works.
- [ ] Signature validation works.
- [ ] Expiry and clock skew work.
- [ ] Unknown key refresh works safely.
- [ ] Redirect URI allowlist enforced.
- [ ] Replay is rejected.
- [ ] Raw tokens are not logged.

---

# 154. UAT — SAML

- [ ] SP-initiated flow works.
- [ ] Response signature validated.
- [ ] Assertion signature policy enforced.
- [ ] Audience restriction validated.
- [ ] Recipient validated.
- [ ] InResponseTo validated.
- [ ] Conditions validated.
- [ ] Assertion replay rejected.
- [ ] Certificate rotation works.
- [ ] IdP-initiated mode disabled or explicitly governed.
- [ ] RelayState validated.

---

# 155. UAT — Tenant Routing

- [ ] Dedicated tenant route works.
- [ ] Unknown tenant rejected.
- [ ] Unverified email does not establish tenant.
- [ ] Provider selection deterministic.
- [ ] Cross-tenant provider use denied.
- [ ] Tenant switch re-evaluates access.
- [ ] Provider configuration isolated.
- [ ] Clinic mapping belongs to tenant.
- [ ] Audit includes tenant context.

---

# 156. UAT — Identity Linking & Provisioning

- [ ] Pre-linked identity works.
- [ ] Invitation link works.
- [ ] Email-only automatic link blocked.
- [ ] Duplicate local match creates conflict.
- [ ] JIT provisioning follows policy.
- [ ] JIT receives minimum access.
- [ ] Suspended local account remains blocked.
- [ ] Terminated account is not recreated.
- [ ] Unlinking requires privilege.
- [ ] Orphan account prevention works.

---

# 157. UAT — Claims & Authorization

- [ ] Required claims enforced.
- [ ] Invalid types rejected.
- [ ] Unknown organization code rejected.
- [ ] Unknown clinic code rejected.
- [ ] External groups map through approved registry.
- [ ] Local RBAC remains authoritative.
- [ ] Scope-aware role assignments work.
- [ ] Broad default roles absent.
- [ ] Mapping changes are audited.
- [ ] Mapping rollback works.

---

# 158. UAT — Assurance & Sessions

- [ ] Accepted MFA indicator maps correctly.
- [ ] Unknown assurance cannot satisfy privileged access.
- [ ] Authentication age enforced.
- [ ] Local session policy applies.
- [ ] Federated session correlation works.
- [ ] Local logout terminates local session.
- [ ] Back-channel logout validated.
- [ ] Provider suspension can revoke sessions.
- [ ] Break-glass access remains available.
- [ ] Tenant switching refreshes authorization context.

---

# 159. UAT — Security & Resilience

- [ ] Algorithm downgrade rejected.
- [ ] `none` algorithm rejected.
- [ ] Metadata SSRF controls work.
- [ ] JWKS cache and refresh work.
- [ ] Certificate expiry alerts work.
- [ ] Provider outage fails safely.
- [ ] Weaker fallback is not automatic.
- [ ] Rate limiting works.
- [ ] Replay detection alerts.
- [ ] Kill switch works.
- [ ] Secrets are not exposed.
- [ ] Sensitive claims are minimized.

---

# 160. UAT — Governance & Observability

- [ ] Provider owner exists.
- [ ] Configuration versioning works.
- [ ] SoD enforced for activation.
- [ ] Audit events complete.
- [ ] Metrics available.
- [ ] Health status available.
- [ ] Configuration drift detected.
- [ ] Emergency suspension audited.
- [ ] Retirement workflow works.
- [ ] Evidence retained.

---

# 161. Definition of Done — SSOT-IAM-06

SSOT-IAM-06 dianggap selesai bila:

- [ ] objectives dan principles tersedia;
- [ ] protocol scope tersedia;
- [ ] trust model tersedia;
- [ ] provider types dan lifecycle tersedia;
- [ ] tenant-aware routing tersedia;
- [ ] provider resolver tersedia;
- [ ] external identity model tersedia;
- [ ] account linking controls tersedia;
- [ ] JIT/pre-provisioning tersedia;
- [ ] claims normalization tersedia;
- [ ] group-to-role mapping tersedia;
- [ ] local authorization boundary tersedia;
- [ ] assurance/MFA model tersedia;
- [ ] OIDC security controls tersedia;
- [ ] SAML security controls tersedia;
- [ ] replay protection tersedia;
- [ ] metadata/key rotation tersedia;
- [ ] session/logout integration tersedia;
- [ ] provider failure handling tersedia;
- [ ] kill switch dan break-glass tersedia;
- [ ] privacy dan tenant isolation tersedia;
- [ ] permissions dan SoD tersedia;
- [ ] configuration/versioning/drift tersedia;
- [ ] health, logs, audit, metrics tersedia;
- [ ] database direction tersedia;
- [ ] SDK contracts tersedia;
- [ ] event/error codes tersedia;
- [ ] checklists dan UAT tersedia.

---

# 162. Implementation Roadmap

## Phase 1 — Federation Foundation

- provider registry;
- configuration schema;
- OIDC authorization code flow;
- tenant provider resolver;
- trust validator;
- audit events.

## Phase 2 — Identity Linking

- external identity registry;
- pre-linking;
- invitation linking;
- conflict workflow;
- JIT provisioning;
- local account status enforcement.

## Phase 3 — Claims, Scope & RBAC

- claims normalizer;
- canonical claims;
- organization/clinic mapping;
- external group mapping;
- assurance evaluator;
- step-up integration.

## Phase 4 — Enterprise Operations

- SAML adapter;
- metadata management;
- JWKS/certificate rotation;
- single logout;
- provider health;
- configuration drift;
- break-glass testing.

## Phase 5 — Advanced Federation

- identity broker;
- partner federation;
- SCIM lifecycle provisioning;
- risk-based authentication;
- remote policy integration;
- automated certification.

---

# 163. Initial Implementation Backlog

```text
IAMF-001 Identity Provider Registry
IAMF-002 Provider Configuration Schema
IAMF-003 Tenant Provider Resolver
IAMF-004 OIDC Protocol Adapter
IAMF-005 SAML Protocol Adapter
IAMF-006 Federation Transaction Store
IAMF-007 State/Nonce/Replay Guard
IAMF-008 Trust Validator
IAMF-009 Claims Normalizer
IAMF-010 External Identity Registry
IAMF-011 Account Linking Service
IAMF-012 JIT Provisioning Service
IAMF-013 External Group Mapping
IAMF-014 Assurance Evaluator
IAMF-015 Federated Session Correlation
IAMF-016 Logout Service
IAMF-017 Certificate & JWKS Monitor
IAMF-018 Federation Dashboard
```

---

# 164. Approval Gate

Dokumen dapat menjadi Approved setelah:

- Platform Architecture review;
- IAM Owner review;
- Security Architecture review;
- RBAC and Scope review;
- Multi-tenant isolation review;
- Privacy review;
- Operations review;
- Audit review;
- Tenant administration review;
- federation threat-model review.

---

# 165. Closing Statement

Federation dan SSO harus memastikan bahwa external identity:

- berasal dari provider terpercaya;
- divalidasi secara cryptographic;
- diarahkan ke tenant yang benar;
- ditautkan secara aman;
- tidak memperoleh role langsung dari claim tanpa governance;
- tetap tunduk pada local status, scope, RBAC, MFA, dan session policy;
- dapat dinonaktifkan;
- dapat dirotasi;
- dapat diaudit.

SSO tidak boleh menjadi bypass terhadap platform security.

SSO harus menjadi authentication bridge yang terkontrol antara external identity domain dan local authorization domain.
