# SSOT-IAM-01 — User Management Architecture

## Status Dokumen

| Item | Nilai |
|---|---|
| Kode Dokumen | SSOT-IAM-01 |
| Nama | User Management Architecture |
| Versi | 1.0 |
| Status | Draft Architecture |
| Domain | Platform Kernel / IAM |
| Berlaku Untuk | Multi-tenant, multi-organization, multi-business entity, healthcare, non-healthcare |
| Dependensi | SSOT-SCOPE-01 s.d. SSOT-SCOPE-04, SSOT-RBAC-01 s.d. SSOT-RBAC-03, SSOT-MENU-01, SSOT-AUDIT-01 s.d. SSOT-AUDIT-03 |

---

# 1. Tujuan

User Management adalah fondasi pengelolaan identitas pengguna platform.

Dokumen ini mendefinisikan:

- struktur user;
- lifecycle akun;
- hubungan user dengan staff/person;
- service account;
- status akun;
- provisioning dan deprovisioning;
- integrasi dengan Scope Engine;
- integrasi dengan RBAC;
- integrasi dengan Audit Trail.

User Management tidak boleh hanya berupa tabel `users` sederhana. Pada platform enterprise, user adalah identitas login, sedangkan role, scope, credential, dan profile profesional harus dipisahkan.

---

# 2. Prinsip Dasar

## 2.1 User bukan Role

Salah:

```text
users.role = admin
```

Benar:

```text
users
user_scope_assignments
user_role_assignments
roles
permissions
```

## 2.2 User bukan Staff

User adalah akun login.

Staff adalah orang/pegawai/profesional.

Satu staff bisa memiliki user login, tetapi tidak semua user harus staff.

Contoh user non-staff:

- service account;
- API client;
- vendor portal user;
- auditor eksternal;
- pasien portal user;
- temporary regulator account.

## 2.3 User harus Scope-aware

User tidak boleh aktif penuh tanpa scope assignment.

Minimal user harus punya:

```text
tenant_id
user_scope_assignments
user_role_assignments
```

## 2.4 Lifecycle harus eksplisit

Akun user harus memiliki status jelas:

```text
pending
active
suspended
locked
disabled
terminated
archived
```

## 2.5 Semua perubahan user diaudit

Perubahan status, email, password, role, scope, dan akses harus menghasilkan audit event.

---

# 3. Boundary IAM

IAM mencakup:

- user account;
- user profile;
- account lifecycle;
- user status;
- account lock;
- user identity binding;
- service account;
- API client identity;
- user-device relationship;
- user preference dasar;
- provisioning/deprovisioning.

IAM tidak mencakup secara penuh:

- password policy detail;
- MFA detail;
- session detail;
- API key detail;
- RBAC permission detail;
- credentialing klinis.

Bagian tersebut dibuat di SSOT terpisah.

---

# 4. Entitas Utama

```text
users
user_profiles
staff
user_staff_links
service_accounts
api_clients
user_status_histories
user_identity_providers
user_devices
user_preferences
user_invitations
user_deactivation_requests
```

---

# 5. User Types

Platform harus mendukung tipe user berikut:

```text
human_user
staff_user
patient_user
vendor_user
external_auditor
service_account
api_client
system_user
```

## 5.1 human_user

Akun manusia umum.

## 5.2 staff_user

Akun pengguna internal yang terhubung ke staff.

Contoh:

- dokter;
- perawat;
- admin;
- kasir;
- manager.

## 5.3 patient_user

Akun portal pasien.

## 5.4 vendor_user

Akun vendor/supplier.

## 5.5 external_auditor

Akun auditor eksternal atau regulator.

Biasanya:

- akses terbatas;
- durasi terbatas;
- audit intensif;
- read-only.

## 5.6 service_account

Akun non-manusia untuk sistem internal.

## 5.7 api_client

Identitas aplikasi/integrasi pihak ketiga.

## 5.8 system_user

Identitas sistem untuk background job.

---

# 6. User Status

Status akun:

| Status | Arti |
|---|---|
| pending | akun dibuat tetapi belum aktif |
| invited | undangan dikirim |
| active | dapat login |
| suspended | dibekukan sementara |
| locked | terkunci karena keamanan |
| disabled | dinonaktifkan administratif |
| terminated | hubungan kerja/akses berakhir |
| archived | historis, tidak aktif |

Status tidak boleh sekadar boolean `is_active`.

---

# 7. User Lifecycle

```text
created
→ invited
→ activated
→ active
→ suspended / locked
→ reactivated
→ disabled
→ terminated
→ archived
```

## 7.1 Created

Akun dibuat oleh admin atau provisioning.

## 7.2 Invited

User menerima undangan untuk aktivasi.

## 7.3 Activated

User mengatur password atau metode login.

## 7.4 Active

User dapat login sesuai scope dan role.

## 7.5 Suspended

Akses dihentikan sementara.

## 7.6 Locked

Akun terkunci karena failed login, risiko keamanan, atau kebijakan.

## 7.7 Disabled

Akun dinonaktifkan oleh admin.

## 7.8 Terminated

Akses berakhir permanen karena resign, kontrak selesai, atau organisasi menutup akses.

## 7.9 Archived

Akun disimpan untuk histori dan audit.

---

# 8. Database Core

## 8.1 users

```sql
CREATE TABLE users (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,

    tenant_id BIGINT UNSIGNED NOT NULL,

    user_uuid CHAR(36) NOT NULL UNIQUE,
    username VARCHAR(100) NULL,
    email VARCHAR(150) NULL,
    phone VARCHAR(50) NULL,

    display_name VARCHAR(150) NOT NULL,
    user_type VARCHAR(50) NOT NULL DEFAULT 'human_user',

    status ENUM(
        'pending',
        'invited',
        'active',
        'suspended',
        'locked',
        'disabled',
        'terminated',
        'archived'
    ) NOT NULL DEFAULT 'pending',

    email_verified_at DATETIME NULL,
    phone_verified_at DATETIME NULL,

    password_hash VARCHAR(255) NULL,
    password_changed_at DATETIME NULL,
    must_change_password TINYINT(1) NOT NULL DEFAULT 0,

    last_login_at DATETIME NULL,
    last_login_ip VARCHAR(45) NULL,

    failed_login_count INT NOT NULL DEFAULT 0,
    locked_until DATETIME NULL,

    created_by BIGINT UNSIGNED NULL,
    updated_by BIGINT UNSIGNED NULL,
    disabled_by BIGINT UNSIGNED NULL,
    disabled_at DATETIME NULL,
    disabled_reason TEXT NULL,

    created_at TIMESTAMP NULL,
    updated_at TIMESTAMP NULL,
    deleted_at TIMESTAMP NULL,

    UNIQUE KEY uq_users_tenant_username (tenant_id, username),
    UNIQUE KEY uq_users_tenant_email (tenant_id, email),
    INDEX idx_users_tenant_status (tenant_id, status),
    INDEX idx_users_type (user_type)
);
```

Catatan:

- `email` boleh NULL untuk service account atau user berbasis username.
- Password hash boleh NULL bila user memakai SSO.
- `tenant_id` wajib karena user tidak boleh global tanpa batas kecuali platform super admin yang tetap harus dikelola secara khusus.

---

## 8.2 user_profiles

```sql
CREATE TABLE user_profiles (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id BIGINT UNSIGNED NOT NULL,

    full_name VARCHAR(150) NOT NULL,
    preferred_name VARCHAR(100) NULL,
    avatar_url VARCHAR(255) NULL,
    gender VARCHAR(30) NULL,
    birth_date DATE NULL,

    locale VARCHAR(20) NULL,
    timezone VARCHAR(50) NULL,

    created_at TIMESTAMP NULL,
    updated_at TIMESTAMP NULL,

    UNIQUE KEY uq_user_profile_user (user_id),
    INDEX idx_user_profiles_name (full_name)
);
```

---

## 8.3 staff

Staff sebaiknya domain organisasi, bukan IAM murni. Namun IAM perlu mengetahui hubungan user-staff.

```sql
CREATE TABLE staff (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,

    tenant_id BIGINT UNSIGNED NOT NULL,
    organization_id BIGINT UNSIGNED NULL,
    business_entity_id BIGINT UNSIGNED NULL,

    staff_number VARCHAR(100) NULL,
    full_name VARCHAR(150) NOT NULL,

    employment_type VARCHAR(50) NULL,
    staff_category VARCHAR(50) NULL,

    status ENUM('active','inactive','suspended','terminated') NOT NULL DEFAULT 'active',

    created_at TIMESTAMP NULL,
    updated_at TIMESTAMP NULL,
    deleted_at TIMESTAMP NULL,

    UNIQUE KEY uq_staff_number_scope (tenant_id, business_entity_id, staff_number),
    INDEX idx_staff_scope (tenant_id, organization_id, business_entity_id),
    INDEX idx_staff_status (status)
);
```

---

## 8.4 user_staff_links

```sql
CREATE TABLE user_staff_links (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,

    user_id BIGINT UNSIGNED NOT NULL,
    staff_id BIGINT UNSIGNED NOT NULL,

    tenant_id BIGINT UNSIGNED NOT NULL,
    organization_id BIGINT UNSIGNED NULL,
    business_entity_id BIGINT UNSIGNED NULL,

    link_status ENUM('active','inactive','revoked') NOT NULL DEFAULT 'active',
    linked_at DATETIME NOT NULL,
    linked_by BIGINT UNSIGNED NULL,
    revoked_at DATETIME NULL,
    revoked_by BIGINT UNSIGNED NULL,
    revoke_reason TEXT NULL,

    created_at TIMESTAMP NULL,
    updated_at TIMESTAMP NULL,

    UNIQUE KEY uq_user_staff_active (user_id, staff_id, link_status),
    INDEX idx_user_staff_user (user_id),
    INDEX idx_user_staff_staff (staff_id),
    INDEX idx_user_staff_scope (tenant_id, business_entity_id)
);
```

Rule:

- satu user boleh terhubung ke satu staff aktif;
- jika mendukung multi-entity employment, satu user boleh punya beberapa staff link, tetapi harus ada active scope yang jelas;
- revoke staff link tidak boleh menghapus histori.

---

# 9. Service Account

Service account dipakai untuk sistem internal, scheduler, queue worker, dan integrasi internal.

```sql
CREATE TABLE service_accounts (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,

    tenant_id BIGINT UNSIGNED NOT NULL,
    user_id BIGINT UNSIGNED NOT NULL,

    code VARCHAR(100) NOT NULL,
    name VARCHAR(150) NOT NULL,
    purpose TEXT NOT NULL,

    owner_user_id BIGINT UNSIGNED NULL,
    status ENUM('active','inactive','revoked') NOT NULL DEFAULT 'active',

    valid_from DATETIME NULL,
    valid_until DATETIME NULL,

    created_at TIMESTAMP NULL,
    updated_at TIMESTAMP NULL,
    revoked_at DATETIME NULL,

    UNIQUE KEY uq_service_account_code (tenant_id, code),
    INDEX idx_service_account_user (user_id),
    INDEX idx_service_account_status (status)
);
```

Rule:

- service account tidak boleh login via UI biasa;
- wajib memiliki owner;
- wajib memiliki scope dan role;
- aktivitasnya tetap diaudit.

---

# 10. API Client Identity

API client adalah identitas aplikasi eksternal atau integrasi.

```sql
CREATE TABLE api_clients (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,

    tenant_id BIGINT UNSIGNED NOT NULL,
    user_id BIGINT UNSIGNED NULL,

    client_id VARCHAR(150) NOT NULL UNIQUE,
    name VARCHAR(150) NOT NULL,
    client_type VARCHAR(50) NOT NULL DEFAULT 'confidential',

    owner_user_id BIGINT UNSIGNED NULL,
    status ENUM('active','inactive','revoked') NOT NULL DEFAULT 'active',

    allowed_scopes JSON NULL,
    allowed_redirect_uris JSON NULL,

    created_at TIMESTAMP NULL,
    updated_at TIMESTAMP NULL,
    revoked_at DATETIME NULL,

    INDEX idx_api_clients_tenant (tenant_id),
    INDEX idx_api_clients_status (status)
);
```

Detail API key dan secret rotation dibuat di SSOT-IAM-05.

---

# 11. User Status History

```sql
CREATE TABLE user_status_histories (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,

    user_id BIGINT UNSIGNED NOT NULL,

    old_status VARCHAR(50) NULL,
    new_status VARCHAR(50) NOT NULL,

    reason TEXT NULL,
    changed_by BIGINT UNSIGNED NULL,
    changed_at DATETIME NOT NULL,

    scope_snapshot JSON NULL,

    created_at TIMESTAMP NULL,

    INDEX idx_user_status_user (user_id),
    INDEX idx_user_status_changed_at (changed_at)
);
```

Setiap perubahan status wajib dicatat di sini dan audit trail.

---

# 12. Identity Provider Binding

Untuk SSO/OAuth/LDAP di masa depan.

```sql
CREATE TABLE user_identity_providers (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,

    user_id BIGINT UNSIGNED NOT NULL,

    provider VARCHAR(50) NOT NULL,
    provider_user_id VARCHAR(255) NOT NULL,
    provider_email VARCHAR(150) NULL,

    status ENUM('active','inactive','revoked') NOT NULL DEFAULT 'active',

    linked_at DATETIME NOT NULL,
    last_used_at DATETIME NULL,
    revoked_at DATETIME NULL,

    created_at TIMESTAMP NULL,
    updated_at TIMESTAMP NULL,

    UNIQUE KEY uq_provider_user (provider, provider_user_id),
    INDEX idx_user_identity_user (user_id)
);
```

---

# 13. User Devices

```sql
CREATE TABLE user_devices (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,

    user_id BIGINT UNSIGNED NOT NULL,

    device_id VARCHAR(150) NOT NULL,
    device_name VARCHAR(150) NULL,
    device_type VARCHAR(50) NULL,
    platform VARCHAR(50) NULL,

    trusted TINYINT(1) NOT NULL DEFAULT 0,
    last_ip VARCHAR(45) NULL,
    last_user_agent TEXT NULL,
    last_seen_at DATETIME NULL,

    status ENUM('active','revoked') NOT NULL DEFAULT 'active',

    created_at TIMESTAMP NULL,
    updated_at TIMESTAMP NULL,

    UNIQUE KEY uq_user_device (user_id, device_id),
    INDEX idx_user_device_status (user_id, status)
);
```

Detail session dibuat di SSOT-IAM-03.

---

# 14. User Preferences

```sql
CREATE TABLE user_preferences (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,

    user_id BIGINT UNSIGNED NOT NULL,

    preference_key VARCHAR(100) NOT NULL,
    preference_value TEXT NULL,

    created_at TIMESTAMP NULL,
    updated_at TIMESTAMP NULL,

    UNIQUE KEY uq_user_preference (user_id, preference_key)
);
```

Contoh:

```text
theme
language
default_dashboard
default_scope_id
notification_email_enabled
```

---

# 15. User Invitation

```sql
CREATE TABLE user_invitations (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,

    tenant_id BIGINT UNSIGNED NOT NULL,
    email VARCHAR(150) NOT NULL,

    invited_user_id BIGINT UNSIGNED NULL,
    invited_by BIGINT UNSIGNED NOT NULL,

    invitation_token_hash VARCHAR(255) NOT NULL,
    status ENUM('pending','accepted','expired','revoked') NOT NULL DEFAULT 'pending',

    expires_at DATETIME NOT NULL,
    accepted_at DATETIME NULL,
    revoked_at DATETIME NULL,

    created_at TIMESTAMP NULL,
    updated_at TIMESTAMP NULL,

    INDEX idx_invitation_email (tenant_id, email),
    INDEX idx_invitation_status (status)
);
```

Rule:

- token asli tidak disimpan;
- hanya hash token yang disimpan;
- invitation expired tidak dapat digunakan;
- accept invitation menghasilkan audit event.

---

# 16. Deactivation Request

Untuk organisasi enterprise, deactivation bisa butuh approval.

```sql
CREATE TABLE user_deactivation_requests (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,

    user_id BIGINT UNSIGNED NOT NULL,
    requested_by BIGINT UNSIGNED NOT NULL,

    reason TEXT NOT NULL,
    status ENUM('pending','approved','rejected','cancelled') NOT NULL DEFAULT 'pending',

    approved_by BIGINT UNSIGNED NULL,
    approved_at DATETIME NULL,
    rejected_by BIGINT UNSIGNED NULL,
    rejected_at DATETIME NULL,
    rejection_reason TEXT NULL,

    created_at TIMESTAMP NULL,
    updated_at TIMESTAMP NULL,

    INDEX idx_deactivation_user (user_id),
    INDEX idx_deactivation_status (status)
);
```

---

# 17. User Provisioning Flow

```text
Admin creates user
→ User status = pending/invited
→ Scope assignment created
→ Role assignment created
→ Invitation sent
→ User activates account
→ User status = active
→ Audit event recorded
```

Minimal user baru tidak boleh aktif penuh jika belum punya:

```text
valid tenant
valid scope assignment
valid role assignment
```

---

# 18. User Deprovisioning Flow

```text
Deactivate request
→ Approval if required
→ User status disabled/terminated
→ Revoke active sessions
→ Revoke API credentials if any
→ Revoke or expire role assignments
→ Revoke or expire scope assignments
→ Audit event recorded
```

Rule:

- jangan hard delete user;
- histori user wajib dipertahankan;
- resource yang pernah dibuat user tetap menunjuk actor lama;
- user terminated tidak boleh login.

---

# 19. User Reactivation Flow

```text
Admin reviews user
→ Check employment/status
→ Restore status active
→ Revalidate scope
→ Revalidate role
→ Force password change if needed
→ Audit event recorded
```

---

# 20. Username dan Email Policy

## Username

- unik per tenant;
- tidak boleh mengandung karakter berbahaya;
- tidak boleh memakai reserved words.

Contoh reserved:

```text
admin
root
system
null
undefined
api
support
```

## Email

- unik per tenant;
- boleh sama antar tenant bila SaaS mengizinkan;
- wajib diverifikasi untuk login berbasis email.

---

# 21. User Creation Rules

Saat membuat user:

1. validasi tenant;
2. validasi email/username unik;
3. tentukan user_type;
4. status awal `pending` atau `invited`;
5. jangan langsung memberi platform admin;
6. buat scope assignment;
7. buat role assignment;
8. audit `iam.user.created`.

---

# 22. User Update Rules

Perubahan data user harus dibatasi.

Aksi sensitif:

- ubah email;
- ubah username;
- disable user;
- reset password;
- ubah user_type;
- link/unlink staff;
- assign role;
- assign scope.

Semua wajib audit.

---

# 23. User Deletion Policy

User tidak boleh hard delete.

Gunakan:

```text
disabled
terminated
archived
deleted_at
```

Hard delete hanya boleh untuk data undangan pending yang belum pernah aktif, dan tetap harus mengikuti kebijakan audit.

---

# 24. User Search

User dapat dicari berdasarkan:

```text
username
email
display_name
status
user_type
tenant
business_entity
role
scope
staff_number
```

User search harus scope-aware.

Tenant admin hanya melihat user dalam tenant-nya.

---

# 25. User List Visibility

Daftar user yang terlihat bergantung pada:

```text
active_scope
permission
role
business_entity
department/team
```

Contoh:

- platform admin melihat lintas tenant;
- tenant admin melihat satu tenant;
- business entity admin melihat satu business entity;
- department manager melihat user dalam department;
- team leader melihat user dalam team.

---

# 26. Integration dengan Scope Engine

Setiap user wajib memiliki minimal satu `user_scope_assignments`.

Login flow:

```text
User authenticated
→ Ambil user_scope_assignments aktif
→ Resolve active scope
→ Simpan active scope
→ Audit scope.resolved
```

Jika user tidak punya scope:

```text
login allowed limited / login rejected
```

Rekomendasi: untuk platform klinis, transaksi ditolak sampai scope aktif tersedia.

---

# 27. Integration dengan RBAC

User tidak menyimpan role langsung.

Role disimpan di:

```text
user_role_assignments
```

Role harus memiliki scope.

Saat active scope berubah:

```text
permission aktif berubah
menu berubah
audit tetap mencatat scope baru
```

---

# 28. Integration dengan Dynamic Menu

Menu user dibangun dari:

```text
active_scope
active roles
active permissions
business_entity_type
industry_type
feature flags
```

User Management menyediakan identitas, status, dan preferensi, tetapi tidak menentukan menu secara langsung.

---

# 29. Integration dengan Audit Trail

Event wajib:

```text
iam.user.created
iam.user.updated
iam.user.disabled
iam.user.enabled
iam.user.terminated
iam.user.archived
iam.user.invited
iam.user.invitation.accepted
iam.user.staff_linked
iam.user.staff_unlinked
iam.user.status_changed
iam.user.profile_updated
iam.service_account.created
iam.service_account.revoked
iam.api_client.created
iam.api_client.revoked
```

Audit wajib menyimpan:

```text
actor
target_user
scope_snapshot
old_value/new_value
reason
correlation_id
ip_address
created_at
```

---

# 30. Healthcare-Specific Considerations

Untuk healthcare, user klinis harus terhubung ke staff dan credentialing.

Contoh:

```text
user → staff → nurse_profile → credentialing → clinical_privilege
```

RBAC saja tidak cukup untuk tindakan klinis.

Contoh:

- role `doctor` boleh akses EMR;
- clinical privilege menentukan apakah dokter boleh melakukan tindakan tertentu;
- STR/SIP menentukan legalitas praktik;
- unit assignment menentukan lokasi praktik.

---

# 31. Non-Healthcare Considerations

Untuk retail/manufacturing/education, user tetap memakai pola yang sama.

Contoh retail:

```text
user → staff → branch assignment → role cashier
```

Contoh manufacturing:

```text
user → staff → plant assignment → role production_supervisor
```

Kernel IAM tidak perlu tahu domain bisnisnya.

---

# 32. Service Account Rules

Service account:

- tidak boleh memiliki password login UI;
- tidak boleh MFA human;
- harus punya owner;
- harus punya expiry bila memungkinkan;
- harus punya role dan scope minimum;
- tidak boleh memakai platform super admin kecuali sangat khusus;
- aktivitas wajib audit.

---

# 33. External Auditor Rules

External auditor:

- scope terbatas;
- role read-only;
- waktu akses terbatas;
- tidak boleh export tanpa izin khusus;
- semua read access dicatat;
- akun expired otomatis disabled.

---

# 34. Patient Portal User Rules

Patient portal user:

- hanya boleh melihat data miliknya;
- harus memakai assignment/resource ownership;
- tidak boleh memakai role internal;
- akses rekam medis perlu policy khusus;
- semua download/disclosure dicatat.

---

# 35. Administrative Access Rules

Role admin harus dibedakan:

```text
platform_super_admin
tenant_admin
business_entity_admin
security_admin
rbac_admin
support_agent
```

Support agent tidak otomatis boleh melihat PHI/PII.

---

# 36. Support Access

Support access harus menggunakan:

- permission khusus;
- alasan;
- durasi;
- audit;
- masking data;
- approval bila data sensitif.

Tidak boleh support memiliki akses permanen luas ke data tenant.

---

# 37. Data Privacy

User data termasuk data personal.

Field sensitif:

```text
email
phone
full_name
birth_date
ip_address
device information
```

Akses dan export user data harus diaudit.

---

# 38. Index Strategy

Minimal:

```sql
INDEX idx_users_tenant_status (tenant_id, status)
INDEX idx_users_type (user_type)
INDEX idx_user_staff_user (user_id)
INDEX idx_user_staff_staff (staff_id)
INDEX idx_user_status_changed_at (changed_at)
```

Untuk pencarian:

```text
username
email
display_name
staff_number
```

Gunakan index sesuai engine database.

---

# 39. Data Migration dari Sistem Lama

Jika sistem lama masih memiliki:

```text
users.role_id
users.clinic_id
nurse_profiles.user_id
doctor_profiles.user_id
```

Migrasi bertahap:

1. buat tenant default;
2. map clinic ke business_entity;
3. buat user_scope_assignments;
4. buat roles dan permissions;
5. buat user_role_assignments;
6. hubungkan user ke staff;
7. jangan hapus field lama dulu;
8. buat compatibility layer;
9. audit seluruh repository;
10. setelah stabil, deprecated field lama.

---

# 40. Anti-Pattern

Hindari:

```text
users.role
users.clinic_id sebagai satu-satunya scope
is_admin boolean
hard delete user
user tanpa audit
admin bisa melihat semua tanpa alasan
service account memakai akun manusia
shared account
password disimpan plain
```

---

# 41. UAT Scenario

## Scenario 1 — Create User

```text
Given admin memiliki iam.user.create
When admin membuat user baru
Then user dibuat status invited
And audit iam.user.created tercatat
```

## Scenario 2 — User tanpa Scope

```text
Given user aktif tetapi tidak punya scope
When user login
Then transaksi ditolak
And audit scope.denied tercatat
```

## Scenario 3 — Disable User

```text
Given admin disable user
When status berubah ke disabled
Then user tidak bisa login
And session aktif dicabut
And audit iam.user.disabled tercatat
```

## Scenario 4 — Staff Link

```text
Given user adalah perawat
When admin link user ke staff/nurse profile
Then relasi tersimpan
And audit iam.user.staff_linked tercatat
```

## Scenario 5 — External Auditor

```text
Given auditor eksternal punya akses 7 hari
When masa berlaku habis
Then akun otomatis disabled/expired
And akses ditolak
```

---

# 42. Definition of Done

User Management dianggap siap bila:

- user table mendukung multi-tenant;
- user_type tersedia;
- status lifecycle tersedia;
- user tidak hard delete;
- user bisa dihubungkan ke staff;
- service account tersedia;
- API client identity tersedia;
- user invitation tersedia;
- user status history tersedia;
- user search scope-aware;
- provisioning/deprovisioning jelas;
- integrasi Scope tersedia;
- integrasi RBAC tersedia;
- integrasi Audit tersedia;
- semua event penting diaudit.

---

# 43. Kesimpulan

User Management adalah pondasi identitas platform.

Scope menentukan wilayah data.

RBAC menentukan aksi.

Audit mencatat kejadian.

User Management memastikan identitas yang menjalankan aksi tersebut valid, terlacak, dan dapat dikelola sepanjang lifecycle-nya.
