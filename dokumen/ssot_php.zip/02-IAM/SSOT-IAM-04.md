# SSOT-IAM-04 --- MFA & Privileged Access

## Status

-   Kode: SSOT-IAM-04
-   Domain: Platform Kernel / IAM
-   Dependensi: SSOT-IAM-01..03, Scope, RBAC, Audit

# 1. Tujuan

Menyediakan arsitektur Multi-Factor Authentication (MFA) dan Privileged
Access yang melindungi operasi berisiko tinggi tanpa mengganggu alur
kerja normal.

# 2. Prinsip

-   MFA bersifat risk-based.
-   Step-up authentication digunakan untuk aksi sensitif.
-   Break-glass berbeda dengan MFA.
-   Semua aktivitas privileged diaudit.
-   Least privilege tetap menjadi dasar.

# 3. Faktor Autentikasi

-   Password
-   Authenticator App (TOTP)
-   Passkey/WebAuthn (future-ready)
-   Hardware Security Key (opsional)
-   Email OTP (fallback)
-   SMS OTP (fallback terbatas)

# 4. Level Jaminan

-   AAL1: Password
-   AAL2: Password + MFA
-   AAL3: MFA tahan phishing (mis. passkey/security key)

# 5. Aksi yang Wajib Step-up

-   Reset password pengguna lain
-   Assign/revoke role
-   Permission override
-   Break-glass
-   Export PHI/PII
-   Melihat audit sensitif
-   Mengubah konfigurasi keamanan
-   Menonaktifkan akun
-   Menandatangani dokumen klinis bila kebijakan mewajibkan

# 6. MFA Enrollment

Flow: Create account → Login → Enroll MFA → Verify → Recovery codes →
Active

# 7. Recovery Codes

-   Dibuat saat enrollment
-   Sekali pakai
-   Disimpan dalam bentuk hash
-   Dapat diregenerasi

# 8. Database

## user_mfa_methods

Kolom minimum: - user_id - method - secret_hash/encrypted_secret -
status - enrolled_at - last_used_at

## user_recovery_codes

-   user_id
-   code_hash
-   used_at

## privileged_access_events

-   actor_user_id
-   action
-   resource
-   justification
-   step_up_result
-   correlation_id
-   created_at

# 9. Step-up Authentication

Flow: Authenticated → Sensitive Action → MFA Challenge → Success →
Execute Action → Audit

Jika gagal: - Tolak aksi - Audit auth.step_up.failed

# 10. Break-glass

Break-glass memerlukan: - alasan - MFA (bila memungkinkan) - durasi -
approval sesuai kebijakan - audit lengkap

# 11. Session Interaction

Step-up tidak membuat session baru. Session diberi atribut: -
elevated=true - elevated_until

# 12. Audit

Event: - auth.mfa.enrolled - auth.mfa.removed -
auth.mfa.challenge.success - auth.mfa.challenge.failed -
auth.step_up.success - auth.step_up.failed - auth.recovery_code.used -
privileged.access.granted - privileged.access.denied

# 13. Anti-pattern

-   SMS sebagai satu-satunya MFA
-   Menyimpan secret TOTP plain
-   Recovery code dapat dipakai berulang
-   Step-up berlaku tanpa batas waktu
-   Privileged action tanpa audit

# 14. UAT

-   Enrollment MFA berhasil.
-   Step-up diminta saat export EMR.
-   Recovery code hanya dapat dipakai sekali.
-   Break-glass menghasilkan audit.
-   Elevated session berakhir sesuai waktu.

# 15. Definition of Done

-   MFA modular.
-   Step-up authentication tersedia.
-   Recovery code tersedia.
-   Privileged access diaudit.
-   Break-glass terintegrasi dengan Scope, RBAC, dan Audit.
