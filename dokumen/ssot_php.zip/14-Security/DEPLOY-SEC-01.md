# DEPLOY-SEC-01 — Deployment & UAT Manual
## SSOT-SEC-01 Security Implementation Framework + SSOT-SEC-02 Secure SDLC & Application Security Framework

---

## Status Dokumen

| Item | Nilai |
|---|---|
| Dokumen | DEPLOY-SEC-01 |
| Versi | 1.0 |
| Status | Draft Deployment & UAT Manual |
| Target | Windows 10/11, XAMPP, Apache, PHP 8.1+, MySQL 8/MariaDB |
| Arsitektur | Modular Monolith, Platform Kernel |
| Cakupan | Local/Test, Staging, Production, Migration, Scheduler, UAT, Rollback |
| Bergantung pada | SSOT-SEC-01 dan SSOT-SEC-02 |

---

# 1. Tujuan

Manual ini digunakan untuk:

- menyiapkan environment;
- memasang Security Framework;
- menjalankan database migration;
- menanam permissions dan roles;
- mengaktifkan middleware;
- mengaktifkan Secure SDLC controls;
- menjalankan scheduler;
- melakukan smoke test;
- menjalankan UAT;
- melakukan deployment bertahap;
- melakukan rollback bila diperlukan.

---

# 2. Target Deployment

Urutan environment:

```text
LOCAL
→ TEST
→ STAGING
→ PRE-PRODUCTION
→ PRODUCTION
```

Untuk instalasi kecil, minimum:

```text
LOCAL/TEST
→ STAGING
→ PRODUCTION
```

---

# 3. Activation Mode

Gunakan urutan:

```text
OFF
→ SHADOW
→ MONITOR
→ WARN
→ ENFORCE
```

## OFF

Security module belum aktif.

## SHADOW

Control dihitung tetapi selected legacy flow belum diblokir.

## MONITOR

Control dan alerts aktif, tetapi remediation masih berjalan.

## WARN

Unsafe behavior menghasilkan warning dan deadline.

## ENFORCE

Critical security controls memblokir request/release.

---

# 4. Prasyarat

Pastikan tersedia:

- Windows 10/11;
- XAMPP;
- Apache;
- PHP 8.1 atau lebih baru;
- MySQL 8 atau MariaDB yang kompatibel;
- Git;
- Composer;
- akses administrator Windows bila diperlukan;
- backup database;
- source code terbaru;
- file `SSOT-SEC-01.md`;
- file `SSOT-SEC-02.md`.

---

# 5. Struktur Direktori Target

Contoh:

```text
D:\xampp\htdocs\platform\
├── app\
├── bin\
├── config\
├── database\
├── public\
├── resources\
├── storage\
├── tests\
├── tools\
├── vendor\
├── composer.json
├── composer.lock
└── .env
```

Document root harus menunjuk ke:

```text
D:\xampp\htdocs\platform\public
```

Bukan ke root project.

---

# 6. Backup Awal

## 6.1 Backup Source

```bat
cd /d D:\xampp\htdocs
xcopy platform platform_backup_before_security /E /I /H /Y
```

## 6.2 Backup Database

```bat
D:\xampp\mysql\bin\mysqldump.exe ^
  -u root ^
  -p ^
  --single-transaction ^
  --routines ^
  --triggers ^
  platform_db ^
  > D:\backup\platform_db_before_security.sql
```

Verifikasi file backup tersedia dan ukurannya tidak nol.

---

# 7. Buat Branch Deployment

```bat
cd /d D:\xampp\htdocs\platform
git checkout -b deploy/security-framework-v1
```

Simpan status awal:

```bat
git status
git log -1
```

---

# 8. Install Dependency

```bat
cd /d D:\xampp\htdocs\platform
composer install
```

Production:

```bat
composer install ^
  --no-dev ^
  --no-interaction ^
  --prefer-dist ^
  --classmap-authoritative
```

---

# 9. Validasi PHP

```bat
D:\xampp\php\php.exe -v
D:\xampp\php\php.exe -m
```

Pastikan extension berikut tersedia bila digunakan:

```text
pdo
pdo_mysql
openssl
mbstring
json
fileinfo
sodium
curl
```

---

# 10. Buat Folder Security

```bat
mkdir D:\xampp\htdocs\platform\storage\secure-files
mkdir D:\xampp\htdocs\platform\storage\quarantine
mkdir D:\xampp\htdocs\platform\storage\security-evidence
mkdir D:\xampp\htdocs\platform\storage\security-exports
mkdir D:\xampp\htdocs\platform\storage\secure-sdlc-artifacts
mkdir D:\xampp\htdocs\platform\storage\secure-sdlc-evidence
mkdir D:\xampp\htdocs\platform\storage\secure-sdlc-sboms
mkdir D:\xampp\htdocs\platform\storage\secure-sdlc-reports
```

---

# 11. Lindungi Folder Storage

Pada Apache Virtual Host:

```apache
<Directory "D:/xampp/htdocs/platform/storage">
    Require all denied
    Options -Indexes
</Directory>
```

Jangan letakkan file restricted di `public`.

---

# 12. Apache Virtual Host

Edit:

```text
D:\xampp\apache\conf\extra\httpd-vhosts.conf
```

Tambahkan:

```apache
<VirtualHost *:80>
    ServerName platform.local
    DocumentRoot "D:/xampp/htdocs/platform/public"

    <Directory "D:/xampp/htdocs/platform/public">
        AllowOverride All
        Require all granted
        Options -Indexes
    </Directory>

    <Directory "D:/xampp/htdocs/platform/storage">
        Require all denied
        Options -Indexes
    </Directory>

    <FilesMatch "\.(env|ini|log|sql|bak|md)$">
        Require all denied
    </FilesMatch>

    ErrorLog "logs/platform-security-error.log"
    CustomLog "logs/platform-security-access.log" combined
</VirtualHost>
```

---

# 13. Windows Hosts

Edit sebagai administrator:

```text
C:\Windows\System32\drivers\etc\hosts
```

Tambahkan:

```text
127.0.0.1 platform.local
```

Restart Apache.

---

# 14. Apache Baseline Hardening

Pastikan:

```apache
ServerTokens Prod
ServerSignature Off
TraceEnable Off
Options -Indexes
```

Production juga membutuhkan HTTPS dan HSTS.

---

# 15. PHP Baseline

Development/Test:

```ini
display_errors = On
display_startup_errors = On
log_errors = On
```

Production:

```ini
display_errors = Off
display_startup_errors = Off
log_errors = On
expose_php = Off
session.use_strict_mode = 1
session.cookie_httponly = 1
session.cookie_secure = 1
session.cookie_samesite = Lax
allow_url_include = Off
```

Untuk local HTTP, `session.cookie_secure` dapat sementara `0`, tetapi production wajib `1`.

---

# 16. Environment Configuration

Contoh `.env` local/test:

```dotenv
APP_ENV=test
APP_DEBUG=true
APP_URL=http://platform.local

DB_HOST=127.0.0.1
DB_PORT=3306
DB_DATABASE=platform_db
DB_USERNAME=platform_app
DB_PASSWORD=change_this_local_password

SECURITY_ENABLED=true
SECURITY_POLICY_MODE=SHADOW
SECURITY_DEBUG=true

SECURITY_PRIVILEGED_MFA_REQUIRED=true
SECURITY_MAX_FAILED_ATTEMPTS=5
SECURITY_LOCKOUT_SECONDS=900

SECURITY_SESSION_IDLE_SECONDS=1800
SECURITY_SESSION_ABSOLUTE_SECONDS=28800
SECURITY_DENY_BY_DEFAULT=true
SECURITY_CROSS_TENANT_DEFAULT_DENY=true

SECURITY_SECURE_FILE_PATH=D:/xampp/htdocs/platform/storage/secure-files
SECURITY_QUARANTINE_PATH=D:/xampp/htdocs/platform/storage/quarantine
SECURITY_EVIDENCE_PATH=D:/xampp/htdocs/platform/storage/security-evidence

SEC_SDLC_ENABLED=true
SEC_SDLC_MODE=SHADOW
SEC_SDLC_FAIL_CLOSED_ON_UNKNOWN=false
SEC_SDLC_CRITICAL_FINDINGS_ALLOWED=0
SEC_SDLC_TENANT_TEST_REQUIRED=true
SEC_SDLC_SECRET_SCAN_REQUIRED=true
SEC_SDLC_ARTIFACT_SIGNATURE_REQUIRED=false
SEC_SDLC_SBOM_REQUIRED=false
```

---

# 17. Production Environment Baseline

```dotenv
APP_ENV=production
APP_DEBUG=false
APP_URL=https://platform.example.com

SECURITY_ENABLED=true
SECURITY_POLICY_MODE=ENFORCE
SECURITY_DEBUG=false

SECURITY_PRIVILEGED_MFA_REQUIRED=true
SECURITY_DENY_BY_DEFAULT=true
SECURITY_CROSS_TENANT_DEFAULT_DENY=true

SEC_SDLC_ENABLED=true
SEC_SDLC_MODE=ENFORCE
SEC_SDLC_FAIL_CLOSED_ON_UNKNOWN=true
SEC_SDLC_CRITICAL_FINDINGS_ALLOWED=0
SEC_SDLC_TENANT_TEST_REQUIRED=true
SEC_SDLC_SECRET_SCAN_REQUIRED=true
SEC_SDLC_ARTIFACT_SIGNATURE_REQUIRED=true
SEC_SDLC_SBOM_REQUIRED=true
```

---

# 18. Database Accounts

Jangan gunakan `root` untuk aplikasi.

## 18.1 Application Runtime

```sql
CREATE USER 'platform_app'@'localhost'
IDENTIFIED BY 'replace_with_strong_password';

GRANT SELECT, INSERT, UPDATE, DELETE
ON platform_db.*
TO 'platform_app'@'localhost';
```

## 18.2 Migration Account

```sql
CREATE USER 'platform_migration'@'localhost'
IDENTIFIED BY 'replace_with_strong_password';

GRANT SELECT, INSERT, UPDATE, DELETE,
      CREATE, ALTER, INDEX, DROP,
      REFERENCES
ON platform_db.*
TO 'platform_migration'@'localhost';
```

Gunakan migration account hanya saat migration.

---

# 19. Database Migration Order

Jalankan:

```text
1. Security identities and sessions
2. Roles and permissions
3. Scoped role assignments
4. Privileged access
5. Credentials
6. Keys and secrets metadata
7. Secure files
8. Legal holds and evidence
9. Vulnerabilities and incidents
10. Secure SDLC requirements
11. Threat models and test plans
12. Findings
13. Pipelines and builds
14. Artifacts and signatures
15. SBOM
16. Releases and gates
17. Promotions and deployments
18. Rollbacks and drift
19. Scheduler tables
```

---

# 20. Jalankan Migration

Jika project memiliki migration runner:

```bat
D:\xampp\php\php.exe bin\console migrate --env=test
```

Jika migration berupa SQL:

```bat
D:\xampp\mysql\bin\mysql.exe ^
  -u platform_migration ^
  -p ^
  platform_db ^
  < database\migrations\create_security_framework_tables.sql
```

---

# 21. Verifikasi Migration

```sql
SHOW TABLES LIKE 'security_%';
SHOW TABLES LIKE 'sec_sdlc_%';
```

Periksa jumlah tabel dan foreign keys.

---

# 22. Seed Permissions

Minimum permission groups:

```text
security.identity.*
security.role.*
security.permission.*
security.assignment.*
security.access_review.*
security.privileged_access.*
security.credential.*
security.key.*
security.secret.*
security.file.*
security.legal_hold.*
security.evidence.*
security.vulnerability.*
security.incident.*

secure_sdlc.requirement.*
secure_sdlc.threat_model.*
secure_sdlc.review.*
secure_sdlc.test_plan.*
secure_sdlc.finding.*
secure_sdlc.pipeline.*
secure_sdlc.artifact.*
secure_sdlc.sbom.*
secure_sdlc.release.*
secure_sdlc.gate.*
secure_sdlc.promotion.*
secure_sdlc.deployment.*
secure_sdlc.rollback.*
secure_sdlc.evidence.*
secure_sdlc.drift.*
```

---

# 23. Seed Roles

Minimum:

```text
Security Administrator
IAM Administrator
Security Analyst
Secrets Operator
Key Custodian
Access Reviewer
Privileged Access Approver
Auditor
Application Security Administrator
Security Architect
Security Reviewer
Release Approver
Release Engineer
QA Security Lead
Deployment Operator
Rollback Approver
```

---

# 24. Seed Role-Permission Assignments

Pastikan:

- role privileged memiliki expiry policy;
- role audit read-only;
- deployment role tidak otomatis menjadi release approver;
- key custodian tidak otomatis menjadi secrets operator;
- developer tidak otomatis mendapat production deployment permission.

---

# 25. Migrasi User Lama

Untuk setiap user:

- mapping immutable ID;
- status;
- tenant membership;
- clinic scope;
- role assignment;
- permission version;
- MFA requirement;
- password compatibility.

Jika password hash lama tidak sesuai, paksa reset password.

---

# 26. Migrasi Role Lama

Jangan menyalin role broad secara langsung.

Langkah:

```text
Inventory effective access
→ Map granular permissions
→ Apply tenant/clinic scope
→ Identify toxic combinations
→ Assign owner
→ Review
→ Import
```

---

# 27. Security Bootstrap

Pastikan service container mendaftarkan:

```text
IdentityServiceInterface
AuthenticationServiceInterface
AuthorizationServiceInterface
SessionServiceInterface
PrivilegedAccessServiceInterface
CredentialServiceInterface
KeyManagementServiceInterface
SecretsServiceInterface
SecureFileServiceInterface
VulnerabilityManagementServiceInterface
SecurityEventServiceInterface
SecurityIncidentBridgeInterface
```

---

# 28. Secure SDLC Bootstrap

Daftarkan:

```text
SecurityRequirementServiceInterface
ThreatModelServiceInterface
SecurityReviewServiceInterface
SecurityTestingServiceInterface
FindingManagementServiceInterface
ReleaseGateServiceInterface
ArtifactIntegrityServiceInterface
SbomServiceInterface
EnvironmentPromotionServiceInterface
SecureDeploymentServiceInterface
SecurityEvidenceServiceInterface
```

---

# 29. Middleware Order

Recommended:

```text
RequestIdMiddleware
→ TrustedProxyMiddleware
→ SecurityHeadersMiddleware
→ RequestSizeLimitMiddleware
→ AuthenticationMiddleware
→ SessionValidationMiddleware
→ AuthenticationAssuranceMiddleware
→ RateLimitMiddleware
→ TenantContextMiddleware
→ ActiveScopeMiddleware
→ AuthorizationMiddleware
→ CsrfMiddleware
→ ClassificationMiddleware
→ InputValidationMiddleware
→ AuditContextMiddleware
```

---

# 30. Aktifkan Mode SHADOW

Pada local/test:

```dotenv
SECURITY_POLICY_MODE=SHADOW
SEC_SDLC_MODE=SHADOW
```

Tujuan:

- melihat hasil decision;
- menemukan false positive;
- membandingkan legacy behavior;
- tidak langsung memblokir seluruh flow.

---

# 31. Jalankan Config Check

```bat
D:\xampp\php\php.exe tools\security-config-check.php
```

Expected:

```text
PASS: environment valid
PASS: debug policy valid
PASS: secure file path outside public root
PASS: database account not root
PASS: security storage writable
PASS: required services registered
```

---

# 32. Jalankan Permission Audit

```bat
D:\xampp\php\php.exe tools\security-permission-audit.php
```

Periksa:

- orphan permissions;
- duplicate role codes;
- privileged roles without expiry;
- assignments without tenant/scope;
- toxic combinations;
- disabled users with active assignments.

---

# 33. Jalankan Tenant Isolation Test

```bat
D:\xampp\php\php.exe tools\security-tenant-isolation-test.php
```

Atau:

```bat
D:\xampp\php\php.exe vendor\bin\phpunit tests\TenantIsolation
```

Expected:

```text
Cross-tenant read: PASS
Cross-tenant list: PASS
Cross-tenant update: PASS
Cross-tenant delete: PASS
Cross-clinic access: PASS
File isolation: PASS
Cache isolation: PASS
Queue isolation: PASS
```

---

# 34. Jalankan Unit Tests

```bat
D:\xampp\php\php.exe vendor\bin\phpunit tests\Unit
```

---

# 35. Jalankan Integration Tests

```bat
D:\xampp\php\php.exe vendor\bin\phpunit tests\Integration
```

---

# 36. Jalankan Security Tests

```bat
D:\xampp\php\php.exe vendor\bin\phpunit tests\Security
```

---

# 37. Secret Scan

Jika tool internal tersedia:

```bat
D:\xampp\php\php.exe tools\security-secret-scan.php .
```

Minimum scan:

- `.env`;
- config;
- source;
- logs;
- SQL dumps;
- backup files.

---

# 38. Dependency Audit

```bat
composer audit
```

Critical findings harus diperbaiki atau memiliki risk acceptance sebelum production.

---

# 39. SAST

Jalankan scanner yang dipilih oleh project.

Hasil minimum:

```text
No critical open finding
No SQL injection
No RCE
No hard-coded production secret
No cross-tenant query defect
```

---

# 40. Build Release Artifact

```bat
D:\xampp\php\php.exe tools\build-release.php
```

Artifact harus mengecualikan:

- `.git`;
- `.env`;
- logs;
- tests bila tidak diperlukan;
- local backup;
- SQL dumps;
- development config.

---

# 41. Generate Checksum

```bat
D:\xampp\php\php.exe tools\create-checksum.php
```

Atau PowerShell:

```powershell
Get-FileHash .\build\platform-release.zip -Algorithm SHA256
```

---

# 42. Generate SBOM

```bat
D:\xampp\php\php.exe tools\generate-sbom.php
```

Validasi:

```bat
D:\xampp\php\php.exe tools\secure-sdlc-sbom-validate.php
```

---

# 43. Sign Artifact

```bat
D:\xampp\php\php.exe tools\sign-artifact.php
```

Untuk local/test, signing dapat dimulai sebagai optional.

Production wajib valid.

---

# 44. Evaluate Release Gate

```bat
D:\xampp\php\php.exe tools\secure-sdlc-gate-evaluate.php
```

Expected production:

```text
Secret Scan: PASS
SAST: PASS
Dependency Scan: PASS
Unit Tests: PASS
Integration Tests: PASS
Tenant Isolation: PASS
Artifact Signature: PASS
SBOM Validation: PASS
Critical Findings: 0
Release Approval: PASS
```

---

# 45. Scheduler Setup — Windows Task Scheduler

Gunakan `schtasks`.

## 45.1 Session Cleanup

```bat
schtasks /Create /SC MINUTE /MO 10 ^
 /TN "Platform Security Session Cleanup" ^
 /TR "\"D:\xampp\php\php.exe\" \"D:\xampp\htdocs\platform\bin\console\" security:session:cleanup" ^
 /F
```

## 45.2 Credential Expiry

```bat
schtasks /Create /SC HOURLY /MO 1 ^
 /TN "Platform Security Credential Expiry" ^
 /TR "\"D:\xampp\php\php.exe\" \"D:\xampp\htdocs\platform\bin\console\" security:credential:check-expiry" ^
 /F
```

## 45.3 Key Rotation Check

```bat
schtasks /Create /SC DAILY /ST 01:00 ^
 /TN "Platform Security Key Rotation Check" ^
 /TR "\"D:\xampp\php\php.exe\" \"D:\xampp\htdocs\platform\bin\console\" security:key:check-rotation" ^
 /F
```

## 45.4 Secret Rotation Check

```bat
schtasks /Create /SC DAILY /ST 01:10 ^
 /TN "Platform Security Secret Rotation Check" ^
 /TR "\"D:\xampp\php\php.exe\" \"D:\xampp\htdocs\platform\bin\console\" security:secret:check-rotation" ^
 /F
```

## 45.5 Vulnerability SLA

```bat
schtasks /Create /SC DAILY /ST 01:20 ^
 /TN "Platform Security Vulnerability SLA" ^
 /TR "\"D:\xampp\php\php.exe\" \"D:\xampp\htdocs\platform\bin\console\" security:vulnerability:check-sla" ^
 /F
```

## 45.6 Artifact Verification

```bat
schtasks /Create /SC DAILY /ST 02:00 ^
 /TN "Platform Secure SDLC Artifact Verify" ^
 /TR "\"D:\xampp\php\php.exe\" \"D:\xampp\htdocs\platform\bin\console\" sec-sdlc:artifact:verify" ^
 /F
```

## 45.7 Drift Check

```bat
schtasks /Create /SC HOURLY /MO 1 ^
 /TN "Platform Secure SDLC Drift Check" ^
 /TR "\"D:\xampp\php\php.exe\" \"D:\xampp\htdocs\platform\bin\console\" sec-sdlc:drift:check" ^
 /F
```

---

# 46. Scheduler Verification

```bat
schtasks /Query /TN "Platform Security Session Cleanup" /V /FO LIST
```

Jalankan manual:

```bat
schtasks /Run /TN "Platform Security Session Cleanup"
```

Periksa logs dan tabel scheduler runs.

---

# 47. Smoke Test — Application

Buka:

```text
http://platform.local
```

Periksa:

- homepage/login terbuka;
- tidak ada stack trace;
- tidak ada directory listing;
- `.env` tidak dapat diakses;
- `/storage` tidak dapat diakses;
- health endpoint tersedia.

---

# 48. Smoke Test — Security Headers

Periksa response headers:

```text
X-Content-Type-Options
Content-Security-Policy
Referrer-Policy
Permissions-Policy
```

Production:

```text
Strict-Transport-Security
```

---

# 49. Smoke Test — Authentication

Uji:

1. valid login;
2. invalid login;
3. lockout/throttle;
4. disabled account;
5. MFA privileged;
6. logout;
7. session revocation.

---

# 50. Smoke Test — Authorization

Uji:

- user tanpa permission;
- user dengan permission;
- expired role assignment;
- wrong clinic;
- explicit deny;
- privileged action without AAL2.

---

# 51. Smoke Test — Tenant Isolation

Sampel:

```text
Tenant A / Clinic A1 / User A
Tenant B / Clinic B1 / User B
```

Uji:

- User A tidak dapat melihat Patient B;
- User A tidak dapat update Patient B;
- User A tidak dapat download File B;
- search/list tidak mencampur tenant;
- export hanya tenant aktif.

---

# 52. Smoke Test — Secure File

Uji:

- valid upload;
- oversize;
- MIME spoof;
- path traversal;
- unauthorized download;
- quarantine;
- checksum.

---

# 53. Smoke Test — Security Events

Pastikan event tercatat:

```text
AUTHENTICATION_FAILED
AUTHORIZATION_DENIED
CROSS_TENANT_ACCESS_DENIED
SESSION_REVOKED
PRIVILEGED_ACCESS_APPROVED
SECRET_REVEALED
MALICIOUS_FILE_DETECTED
```

---

# 54. UAT Identity & Authentication

- [ ] User aktif dapat login.
- [ ] User disabled ditolak.
- [ ] Invalid login tidak membocorkan user existence.
- [ ] Throttling aktif.
- [ ] Password hashing aman.
- [ ] MFA privileged aktif.
- [ ] Password reset token single-use.
- [ ] Logout mencabut session.
- [ ] Password reset mencabut session lama.
- [ ] Authentication events tercatat.

---

# 55. UAT Sessions

- [ ] Secure cookie aktif sesuai environment.
- [ ] Session ID berubah setelah login.
- [ ] Session ID berubah setelah MFA.
- [ ] Idle timeout bekerja.
- [ ] Absolute timeout bekerja.
- [ ] Session revoke bekerja.
- [ ] Permission change mencabut stale session.
- [ ] Concurrent session policy bekerja.
- [ ] Session list tersedia.
- [ ] Suspicious session terdeteksi.

---

# 56. UAT RBAC & Tenant Scope

- [ ] Permissions granular tersedia.
- [ ] Role-permission assignments benar.
- [ ] User-role assignments scoped.
- [ ] Clinic scope enforced.
- [ ] Cross-tenant read ditolak.
- [ ] Cross-tenant update ditolak.
- [ ] Cross-clinic update ditolak.
- [ ] Resource-level policy aktif.
- [ ] Explicit deny menang.
- [ ] UI menu tidak menjadi enforcement utama.

---

# 57. UAT Privileged Access

- [ ] Privileged role membutuhkan MFA.
- [ ] JIT request bekerja.
- [ ] Approval bekerja.
- [ ] Self-approval ditolak.
- [ ] Expiry otomatis.
- [ ] Revocation bekerja.
- [ ] Break-glass diaudit.
- [ ] Post-use review tersedia.

---

# 58. UAT Credentials, Keys & Secrets

- [ ] API credential dapat dibuat.
- [ ] Raw credential tampil satu kali.
- [ ] Credential tersimpan sebagai hash/reference.
- [ ] Expired credential ditolak.
- [ ] Rotation bekerja.
- [ ] Key versioning bekerja.
- [ ] Secret reveal membutuhkan high-risk permission.
- [ ] Secret tidak masuk log.
- [ ] Revocation bekerja.
- [ ] Access tercatat.

---

# 59. UAT Secure Files

- [ ] Restricted file di luar public root.
- [ ] MIME validation bekerja.
- [ ] Extension allowlist bekerja.
- [ ] Random storage name digunakan.
- [ ] Download membutuhkan authorization.
- [ ] Cross-tenant file ditolak.
- [ ] Malware quarantine bekerja.
- [ ] Archive bomb/traversal controls bekerja.
- [ ] Checksum tersedia.
- [ ] Legal hold memblokir delete.

---

# 60. UAT Vulnerability & Incidents

- [ ] Findings dapat diimport.
- [ ] Deduplication bekerja.
- [ ] Severity diterapkan.
- [ ] SLA dihitung.
- [ ] Owner assignment bekerja.
- [ ] Risk acceptance time-bound.
- [ ] Remediation verification wajib.
- [ ] Critical overdue menghasilkan alert.
- [ ] Security event dapat menjadi incident.
- [ ] Evidence terhubung ke incident.

---

# 61. UAT Secure SDLC

- [ ] Security manifest tersedia.
- [ ] Threat model tersedia untuk high-risk feature.
- [ ] Secret scan berjalan.
- [ ] SAST berjalan.
- [ ] Dependency scan berjalan.
- [ ] Tenant isolation suite lulus.
- [ ] Artifact checksum tersedia.
- [ ] Artifact signature valid.
- [ ] SBOM valid.
- [ ] Release gate memblokir critical failure.
- [ ] Self-approval restrictions bekerja.
- [ ] Same artifact dipromosikan.

---

# 62. UAT Deployment

- [ ] Artifact diverifikasi sebelum deploy.
- [ ] Migration account terpisah.
- [ ] Backup tersedia.
- [ ] Migration sukses.
- [ ] Health check sukses.
- [ ] Authentication smoke test sukses.
- [ ] Authorization smoke test sukses.
- [ ] Tenant isolation smoke test sukses.
- [ ] Security events aktif.
- [ ] Rollback artifact tersedia.
- [ ] Deployment audit tersedia.

---

# 63. Mode MONITOR

Setelah local/test stabil:

```dotenv
SECURITY_POLICY_MODE=MONITOR
SEC_SDLC_MODE=MONITOR
```

Monitor minimal:

- 3–7 hari di staging;
- false positives;
- denial spikes;
- missing scope;
- role mapping;
- scheduler failures;
- security test gaps.

---

# 64. Mode WARN

Jika findings sudah stabil:

```dotenv
SECURITY_POLICY_MODE=WARN
SEC_SDLC_MODE=WARN
```

Pada tahap ini:

- unsafe access menghasilkan warning;
- owner mendapat deadline;
- release condition mulai ditegakkan;
- exceptions mulai diwajibkan.

---

# 65. Mode ENFORCE

Aktifkan setelah UAT lulus:

```dotenv
SECURITY_POLICY_MODE=ENFORCE
SEC_SDLC_MODE=ENFORCE
```

Production wajib:

- deny by default;
- tenant isolation enforcement;
- privileged MFA;
- expired credentials denied;
- critical findings block release;
- invalid signature blocks deploy;
- missing SBOM blocks production;
- expired exceptions rejected.

---

# 66. Production Deployment Procedure

## Step 1 — Freeze

- hentikan perubahan source;
- tentukan release candidate;
- catat commit SHA.

## Step 2 — Backup

- backup source;
- backup database;
- backup config;
- verify restore path.

## Step 3 — Verify Artifact

- checksum;
- signature;
- SBOM;
- release manifest;
- gate result.

## Step 4 — Maintenance Mode

Aktifkan bila migration berisiko.

## Step 5 — Deploy Artifact

Gunakan artifact yang sama dari staging.

## Step 6 — Migration

Jalankan approved migration.

## Step 7 — Clear/Rebuild Cache

Jika framework menggunakan cache.

## Step 8 — Restart Services

Restart Apache/worker/scheduler jika diperlukan.

## Step 9 — Health Check

Periksa readiness dan dependencies.

## Step 10 — Security Smoke Test

- login;
- MFA;
- RBAC;
- tenant isolation;
- secure file;
- audit/security events.

## Step 11 — Exit Maintenance

Buka akses user.

## Step 12 — Monitor

Pantau error, denial, security events, performance.

---

# 67. Production Go/No-Go Gate

GO hanya jika:

- [ ] backup verified;
- [ ] artifact signature valid;
- [ ] SBOM valid;
- [ ] no critical finding;
- [ ] tenant tests pass;
- [ ] migration tested;
- [ ] rollback ready;
- [ ] release approved;
- [ ] on-call available;
- [ ] monitoring active.

---

# 68. Rollback Triggers

Rollback bila:

- authentication gagal luas;
- authorization regression;
- tenant isolation failure;
- migration failure;
- application unavailable;
- critical error spike;
- security event pipeline gagal;
- secret/key issue;
- severe performance degradation.

---

# 69. Rollback Procedure

1. Aktifkan maintenance mode.
2. Catat deployment dan error.
3. Hentikan scheduler/worker yang dapat memperburuk kondisi.
4. Verifikasi previous artifact.
5. Restore previous artifact.
6. Roll back schema hanya jika aman.
7. Jika schema destructive, gunakan forward fix atau restore backup.
8. Restore configuration snapshot.
9. Restart Apache/services.
10. Jalankan health check.
11. Jalankan security smoke test.
12. Reconcile migration and release state.
13. Simpan evidence.
14. Buat incident/problem record.

---

# 70. Rollback Command Example

```bat
xcopy D:\releases\platform-1.7.0 ^
      D:\xampp\htdocs\platform ^
      /E /I /H /Y
```

Gunakan release directory atau deployment tool yang lebih aman bila tersedia.

---

# 71. Database Restore Example

```bat
D:\xampp\mysql\bin\mysql.exe ^
  -u root ^
  -p ^
  platform_db ^
  < D:\backup\platform_db_before_security.sql
```

Jangan restore production tanpa approval dan verifikasi scope.

---

# 72. Post-Rollback Checks

- [ ] version benar;
- [ ] database state konsisten;
- [ ] login bekerja;
- [ ] tenant isolation bekerja;
- [ ] sessions stale dicabut;
- [ ] key/secret references valid;
- [ ] scheduler berjalan;
- [ ] audit/security events aktif;
- [ ] incident evidence tersimpan.

---

# 73. Troubleshooting — Undefined Security Service

Error:

```text
Service not found / interface not bound
```

Periksa:

- service provider;
- container registration;
- namespace;
- autoload;
- cache container.

Jalankan:

```bat
composer dump-autoload
```

---

# 74. Troubleshooting — Migration Foreign Key

Error:

```text
Cannot add foreign key constraint
```

Periksa:

- engine InnoDB;
- column type sama;
- unsigned consistency;
- collation;
- parent table sudah dibuat;
- migration order.

---

# 75. Troubleshooting — Access Denied Setelah Enforce

Periksa:

- role assignment;
- tenant membership;
- clinic scope;
- permission version;
- session stale;
- explicit deny;
- resource tenant;
- policy exception.

Solusi umum:

- perbaiki assignment;
- increment permission version;
- revoke session;
- login ulang;
- jangan bypass authorization.

---

# 76. Troubleshooting — Semua User Terkunci

Periksa:

- login throttle;
- shared IP handling;
- clock/timezone;
- failed attempt counters;
- lockout reset job.

Jangan mematikan authentication security secara global tanpa incident procedure.

---

# 77. Troubleshooting — Secure Cookie di Local

Pada local HTTP, browser tidak mengirim secure cookie.

Pilihan:

- gunakan HTTPS local; atau
- set secure cookie false hanya pada local/test.

Production wajib true.

---

# 78. Troubleshooting — File Upload Gagal

Periksa:

- Apache request limit;
- `post_max_size`;
- `upload_max_filesize`;
- application limit;
- folder permission;
- fileinfo extension;
- malware scanner;
- MIME allowlist.

---

# 79. Troubleshooting — Scheduler Tidak Jalan

Periksa:

- Task Scheduler status;
- path PHP;
- path project;
- user account;
- working directory;
- exit code;
- log file;
- duplicate lock.

Gunakan absolute paths.

---

# 80. Troubleshooting — Release Gate UNKNOWN

Penyebab umum:

- scanner gagal;
- evidence hilang;
- report invalid;
- tool timeout;
- artifact mismatch.

Critical production gate harus tetap fail closed.

---

# 81. Troubleshooting — Signature Invalid

Periksa:

- artifact berubah;
- wrong key version;
- signature metadata;
- line ending/package mutation;
- wrong checksum;
- revoked signing key.

Jangan deploy ulang artifact invalid.

---

# 82. Troubleshooting — SBOM Invalid

Periksa:

- format;
- version;
- component count;
- dependency lock;
- checksum;
- release linkage.

Regenerate dari final artifact.

---

# 83. Troubleshooting — Drift Detected

Periksa:

- manual file edit;
- config change;
- schema mismatch;
- scheduler mismatch;
- artifact checksum mismatch.

Reconcile ke source-controlled state.

---

# 84. Monitoring Setelah Production

Pantau:

```text
authentication_failure_total
authorization_denial_total
cross_tenant_denial_total
active_session_total
privileged_access_active_total
key_rotation_overdue_total
secret_rotation_overdue_total
vulnerability_overdue_total
security_incident_total
artifact_signature_failure_total
deployment_failure_total
drift_open_total
```

---

# 85. Hypercare

Minimal 24–72 jam setelah production:

- monitor logs;
- review denial spikes;
- review login failures;
- review tenant access attempts;
- verify scheduler;
- verify backup;
- verify artifact state;
- review user reports;
- maintain rollback readiness.

---

# 86. Final Sign-Off

Production deployment dianggap selesai bila:

- [ ] all critical UAT passed;
- [ ] no unresolved critical finding;
- [ ] tenant isolation passed;
- [ ] artifact verified;
- [ ] SBOM valid;
- [ ] migration successful;
- [ ] rollback tested;
- [ ] scheduler active;
- [ ] monitoring active;
- [ ] operations sign-off available;
- [ ] security sign-off available;
- [ ] release evidence complete.

---

# 87. Recommended Next Document

Setelah manual ini, dokumen berikutnya:

```text
UAT-SEC-01 — Executable Security UAT Scenarios
```

Isinya:

- sample tenants;
- sample clinics;
- sample users;
- sample roles;
- sample permissions;
- browser test steps;
- expected database rows;
- expected security events;
- pass/fail criteria.
