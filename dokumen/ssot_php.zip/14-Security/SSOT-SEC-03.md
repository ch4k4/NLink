# SSOT-SEC-03 — Secrets, Key & Certificate Management

---

## Status Dokumen

| Item | Nilai |
|---|---|
| Kode | SSOT-SEC-03 |
| Judul | Secrets, Key & Certificate Management |
| Versi | 1.0 |
| Status | Draft Architecture |
| Domain | Platform Kernel |
| Kategori | Security Architecture, Cryptographic Material & Secret Governance |
| Cakupan | Secrets, Encryption Keys, Certificates, Storage, Distribution, Rotation, Revocation, Recovery, Audit, Integration |
| Bergantung pada | SSOT-GOV-01, SSOT-GOV-04, SSOT-GOV-05, SSOT-IAM-03, SSOT-IAM-04, SSOT-RBAC-05, SSOT-RBAC-08, SSOT-AUDIT-01, SSOT-SEC-01, SSOT-SEC-02, SSOT-DEPLOY-01, SSOT-DEPLOY-SEC-01, SSOT-OBS-01, SSOT-TEST-01 |
| Target Stack | PHP 8.1+, Environment Variables, Secret Vault-compatible, TLS, KMS/HSM-ready, MySQL 8/MariaDB |
| Target Evolusi | Central Secrets Manager, Automated Rotation, Certificate Automation, KMS/HSM Integration, Zero-Trust Workload Identity |

---

# 1. Executive Summary

SSOT-SEC-03 menetapkan tata kelola resmi untuk secrets, encryption keys, signing keys, API credentials, database credentials, certificates, dan material kriptografi pada Platform Kernel.

Dokumen ini mengatur:

- secret classification;
- secret ownership;
- secret inventory;
- secret generation;
- secure storage;
- secure distribution;
- runtime injection;
- secret retrieval;
- access control;
- lease and expiry;
- rotation;
- revocation;
- emergency rotation;
- key lifecycle;
- data encryption keys;
- key encryption keys;
- signing keys;
- asymmetric key pairs;
- TLS certificates;
- client certificates;
- certificate authority trust;
- certificate renewal;
- certificate revocation;
- secret scanning;
- incident response;
- break-glass access;
- backup and recovery;
- audit;
- observability;
- database direction;
- API direction;
- SDK contracts;
- UAT;
- Definition of Done;
- implementation roadmap.

Tujuan akhirnya adalah memastikan material rahasia:

- tidak disimpan sembarangan;
- tidak di-hard-code;
- tidak tersebar tanpa owner;
- hanya dapat diakses oleh subject/workload yang tepat;
- memiliki lifecycle;
- dapat dirotasi;
- dapat dicabut;
- memiliki expiry;
- dapat dipulihkan;
- dapat diaudit;
- tidak membocorkan tenant atau production secrets ke environment lain.

---

# 2. Objectives

Framework harus:

- menyediakan centralized governance;
- mengurangi plaintext secrets;
- mendukung least privilege;
- mendukung workload-specific access;
- mendukung rotation;
- mendukung certificate automation;
- menjaga environment isolation;
- mendukung incident response;
- menjaga cryptographic agility;
- menyediakan audit evidence.

---

# 3. Core Principles

```text
No Secrets in Source Code
No Shared Secrets Without Explicit Approval
Every Secret Has an Owner
Every Secret Has a Purpose
Every Secret Has a Lifecycle
Short-Lived Credentials over Long-Lived Credentials
Automated Rotation over Manual Rotation
Production Secrets Stay in Production Boundaries
Keys and Data Must Be Separated
Every Access Must Be Auditable
```

---

# 4. Scope

Framework berlaku untuk:

```text
Database Credentials
API Keys
OAuth Client Secrets
Webhook Secrets
Encryption Keys
Signing Keys
JWT Keys
TLS Certificates
mTLS Certificates
SSH Keys
Service Account Credentials
Backup Encryption Keys
Integration Credentials
Deployment Credentials
Break-Glass Credentials
```

---

# 5. Non-Scope

Dokumen ini tidak menetapkan:

- complete cryptographic algorithm catalog;
- endpoint authorization;
- identity proofing;
- external certificate authority procurement details;
- vendor-specific vault implementation.

---

# 6. Definitions

## 6.1 Secret

Informasi rahasia yang memberikan access atau capability.

## 6.2 Cryptographic Key

Material yang digunakan untuk encryption, decryption, signing, atau verification.

## 6.3 Certificate

Dokumen digital yang mengikat public key dengan identity atau workload.

## 6.4 Credential

Data authentication seperti password, token, key, atau certificate.

---

# 7. Secret Categories

```text
PASSWORD
API_KEY
CLIENT_SECRET
WEBHOOK_SECRET
TOKEN
PRIVATE_KEY
DATABASE_CREDENTIAL
SERVICE_CREDENTIAL
ENCRYPTION_KEY
SIGNING_KEY
CERTIFICATE_PRIVATE_KEY
RECOVERY_SECRET
```

---

# 8. Secret Classification

```text
INTERNAL
CONFIDENTIAL
RESTRICTED
CRITICAL
```

---

# 9. Critical Secrets

Examples:

```text
Platform root encryption key
Production database administrator credential
Certificate authority private key
Global signing key
Break-glass credential
Cross-tenant administration credential
```

---

# 10. Secret Owner

Setiap secret wajib memiliki:

- business owner;
- technical owner;
- security owner;
- operational custodian where needed.

---

# 11. Secret Inventory

Canonical inventory minimum:

```text
secret_id
secret_code
secret_type
owner
environment
scope
purpose
status
created_at
expires_at
last_rotated_at
next_rotation_at
```

---

# 12. Secret Code

Format:

```text
{environment}.{domain}.{system}.{purpose}
```

Contoh:

```text
prod.billing.payment_gateway.client_secret
prod.platform.database.application_password
staging.homecare.partner.api_key
```

---

# 13. Secret Code Restrictions

Secret code tidak boleh berisi actual secret value.

---

# 14. Secret Status

```text
DRAFT
ACTIVE
EXPIRING
ROTATING
SUSPENDED
REVOKED
EXPIRED
RETIRED
COMPROMISED
```

---

# 15. Secret Lifecycle

```text
Request
→ Approve
→ Generate
→ Store
→ Distribute
→ Use
→ Monitor
→ Rotate
→ Revoke
→ Retire
```

---

# 16. Secret Request

Minimum:

```text
requester
purpose
target system
environment
scope
subject/workload
duration
rotation policy
owner
risk
```

---

# 17. Secret Generation

Secrets harus dihasilkan menggunakan secure random source.

---

# 18. Password Strength

Machine-generated passwords lebih diprioritaskan untuk service credentials.

---

# 19. Manual Secret Entry

Manual entry hanya jika external provider mewajibkan, dengan secure handling.

---

# 20. Secret Storage

Approved options:

```text
Central Secret Manager
KMS/HSM
Encrypted Configuration Store
OS Credential Store
Short-Lived Runtime Injection
```

---

# 21. Prohibited Storage

```text
Source Code
Git History
Plaintext Configuration
Spreadsheet
Chat Message
Ticket Description
Email
Browser Local Storage
Client-Side JavaScript
Unencrypted Backup
```

---

# 22. Environment Variables

Environment variables dapat digunakan sebagai runtime delivery mechanism, bukan canonical secret store.

---

# 23. Environment Variable Risks

- process inspection;
- crash dump;
- debug output;
- inherited process;
- accidental logging;
- deployment manifest exposure.

---

# 24. Runtime Secret Injection

Preferred:

```text
Secret Manager
→ Authorized Workload
→ Short-Lived Retrieval/Injection
→ Memory Use
→ No Persistent Plaintext
```

---

# 25. Secret Retrieval

Retrieval harus:

- authenticated;
- authorized;
- scoped;
- auditable;
- rate-limited where needed;
- fail closed.

---

# 26. Secret Caching

If cached:

- encrypted or memory-only;
- short TTL;
- process-scoped;
- invalidated on rotation/revocation;
- never logged.

---

# 27. Secret Distribution

Distribution harus menggunakan secure channel.

---

# 28. Human Access

Human secret reveal harus exceptional.

---

# 29. Workload Access

Workload identity lebih diprioritaskan daripada shared credential.

---

# 30. Shared Secrets

Shared secret harus:

- memiliki approved use case;
- memiliki subject list;
- memiliki shorter rotation;
- memiliki monitoring;
- memiliki migration plan.

---

# 31. Secret Scope

```text
GLOBAL
ENVIRONMENT
TENANT
ORGANIZATION
MODULE
SERVICE
INTEGRATION
RESOURCE
```

---

# 32. Tenant Secret

Tenant-specific integration credentials harus terisolasi.

---

# 33. Environment Isolation

Production, staging, test, dan local harus memiliki secret terpisah.

---

# 34. Secret Access Control

Access berdasarkan:

- workload identity;
- privileged role;
- environment;
- scope;
- purpose;
- assurance level;
- time;
- network/workstation condition.

---

# 35. Human Secret Permissions

Examples:

```text
security.secret.metadata.read
security.secret.value.reveal
security.secret.rotate
security.secret.revoke
security.secret.assign
security.secret.audit
```

---

# 36. Reveal Permission

Reveal permission harus critical dan short-lived.

---

# 37. Break-Glass Access

Break-glass secret access memerlukan:

- incident;
- strong MFA;
- explicit reason;
- limited time;
- immediate alert;
- post-use review;
- rotation evaluation.

---

# 38. Secret Lease

Temporary secret dapat menggunakan lease.

---

# 39. Lease Metadata

```text
lease_id
secret_id
subject
issued_at
expires_at
renewable
revocable
```

---

# 40. Short-Lived Credentials

Preferred examples:

- temporary database token;
- cloud workload token;
- signed access token;
- short-lived certificate.

---

# 41. Rotation

Rotation adalah penggantian material aktif dengan material baru.

---

# 42. Rotation Types

```text
SCHEDULED
ON_DEMAND
EMERGENCY
COMPROMISE
OWNER_CHANGE
ALGORITHM_CHANGE
PROVIDER_CHANGE
```

---

# 43. Rotation Policy

Minimum:

```text
rotation_interval
overlap_window
activation_strategy
rollback_strategy
dependent_systems
verification
owner
```

---

# 44. Rotation Interval

Ditentukan oleh:

- risk;
- secret type;
- provider limit;
- exposure;
- duration;
- regulation;
- incident history.

---

# 45. Zero-Downtime Rotation

Recommended flow:

```text
Generate New
→ Distribute
→ Activate New
→ Verify Consumers
→ Revoke Old
→ Confirm
```

---

# 46. Dual-Secret Window

May be used for compatible transition but must be bounded.

---

# 47. Rotation Failure

Must:

- preserve last known working state where safe;
- alert;
- stop uncontrolled partial rollout;
- support retry/rollback;
- preserve evidence.

---

# 48. Emergency Rotation

Triggered by:

- suspected compromise;
- leaked secret;
- employee departure;
- unauthorized access;
- vendor incident;
- cryptographic weakness;
- exposed repository.

---

# 49. Revocation

Revocation must propagate rapidly.

---

# 50. Revocation Effects

- mark secret invalid;
- stop new leases;
- invalidate caches;
- terminate sessions/tokens where possible;
- notify owners;
- create incident when appropriate.

---

# 51. Secret Retirement

Retirement only after:

- no active consumers;
- replacement active;
- audit complete;
- retention policy met;
- backups considered.

---

# 52. Cryptographic Key Types

```text
DATA_ENCRYPTION_KEY
KEY_ENCRYPTION_KEY
SIGNING_KEY
VERIFICATION_KEY
TRANSPORT_KEY
BACKUP_KEY
ROOT_KEY
```

---

# 53. Key Hierarchy

Recommended:

```text
Root/Master Key
→ Key Encryption Key
→ Data Encryption Key
→ Encrypted Data
```

---

# 54. Envelope Encryption

Preferred for scalable data encryption.

---

# 55. Key Separation

Separate keys by:

- purpose;
- environment;
- tenant where required;
- data classification;
- application/module;
- lifecycle.

---

# 56. Key Reuse

One key should not be reused across unrelated purposes.

---

# 57. Encryption and Signing

Encryption keys and signing keys must be distinct.

---

# 58. Public and Private Keys

Private key must remain protected.

Public key may be distributed under integrity controls.

---

# 59. Key Generation

Use approved cryptographic provider and secure random source.

---

# 60. Key Storage

Critical private keys should use KMS/HSM or equivalent protected storage.

---

# 61. Key Export

Non-exportable keys are preferred for critical use cases.

---

# 62. Key Versioning

Every key rotation creates new key version.

---

# 63. Key Identifier

Ciphertext/signature metadata should identify key version.

---

# 64. Key Rotation and Data

Rotation strategies:

```text
LAZY_REENCRYPTION
BATCH_REENCRYPTION
ON_READ_REENCRYPTION
NEW_DATA_ONLY
```

---

# 65. Key Revocation

Revocation impact must be assessed because encrypted data may become inaccessible.

---

# 66. Key Destruction

Requires:

- owner approval;
- retention validation;
- backup validation;
- recovery impact analysis;
- irreversible action controls.

---

# 67. Key Recovery

Critical keys may require approved escrow or recovery mechanism.

---

# 68. Key Escrow

If used:

- separation of duties;
- dual control;
- encryption;
- tamper evidence;
- periodic test;
- strict audit.

---

# 69. Signing Keys

Used for:

- JWT;
- package signing;
- webhook signing;
- release signing;
- document signing.

---

# 70. Signing Key Rotation

Verification should support active and recently retired public keys during transition.

---

# 71. JWKS Direction

Public signing keys may be distributed through versioned key set.

---

# 72. Certificate Types

```text
SERVER_TLS
CLIENT_TLS
MUTUAL_TLS
CODE_SIGNING
DOCUMENT_SIGNING
INTERNAL_CA
EXTERNAL_CA
```

---

# 73. Certificate Inventory

Minimum:

```text
certificate_id
subject
issuer
serial_number
fingerprint
environment
owner
valid_from
valid_to
status
private_key_reference
```

---

# 74. Certificate Status

```text
REQUESTED
ISSUED
ACTIVE
EXPIRING
RENEWING
REVOKED
EXPIRED
RETIRED
```

---

# 75. Certificate Lifecycle

```text
Request
→ Validate Identity
→ Issue
→ Deploy
→ Monitor
→ Renew
→ Revoke
→ Retire
```

---

# 76. Certificate Renewal

Renew before expiry with adequate buffer.

---

# 77. Expiry Alert

Suggested:

```text
90 days
60 days
30 days
14 days
7 days
1 day
```

depending on certificate lifetime.

---

# 78. Automated Certificate Management

Preferred for internal services and supported public TLS.

---

# 79. mTLS

mTLS certificate must bind to workload identity and environment.

---

# 80. Certificate Trust Store

Trust store changes require governance.

---

# 81. Private CA

Internal CA keys require critical protection and separation of duties.

---

# 82. Certificate Revocation

Use applicable:

- CRL;
- OCSP;
- trust store removal;
- workload denylist;
- reissuance.

---

# 83. Certificate Pinning

Use cautiously due to operational risk.

---

# 84. SSH Keys

SSH keys must be:

- named;
- owned;
- scoped;
- rotated;
- removed on departure;
- not shared.

---

# 85. API Keys

API keys should:

- be scoped;
- have expiry where supported;
- have last-used tracking;
- be rotated;
- be tenant/environment specific;
- not appear in URLs.

---

# 86. OAuth Client Secrets

Must be separated by client and environment.

---

# 87. Webhook Secrets

Must support:

- signature verification;
- timestamp/nonce;
- replay protection;
- rotation;
- dual-key transition where required.

---

# 88. Database Credentials

Prefer application-specific, least-privilege accounts.

---

# 89. Database Admin Credential

Must not be used by application runtime.

---

# 90. Backup Encryption Keys

Must be recoverable and separately protected.

---

# 91. Secret Scanning

Scan:

- source;
- commit history;
- build artifacts;
- container images;
- logs;
- configuration;
- deployment manifests.

---

# 92. Secret Leak Response

```text
Detect
→ Classify
→ Revoke/Rotate
→ Assess Exposure
→ Notify
→ Remove from History/Artifact
→ Validate
→ Post-Incident Review
```

---

# 93. Git History

Removing current file is not sufficient; leaked secret must be revoked.

---

# 94. Logging

Never log:

- secret values;
- private keys;
- full tokens;
- passwords;
- recovery codes;
- decrypted credentials.

---

# 95. Masking

Logs/UI may show controlled fingerprint:

```text
last 4 characters
hash prefix
secret version
```

---

# 96. Memory Handling

Minimize plaintext lifetime in memory.

---

# 97. Crash Dumps

Production crash dumps must be protected and reviewed for secret exposure.

---

# 98. Clipboard

Human secret reveal should discourage or limit clipboard persistence where feasible.

---

# 99. UI Reveal

Secret value reveal should:

- require reauthentication;
- be time-limited;
- avoid browser caching;
- show warning;
- audit actor and reason.

---

# 100. Backup

Secret store backup must be encrypted and access-controlled.

---

# 101. Recovery

Recovery test must verify:

- secret store restore;
- key availability;
- certificate deployment;
- access policy;
- audit continuity.

---

# 102. Disaster Recovery

Critical secret/key dependencies must be included in DR plan.

---

# 103. Region/Location

Key and secret location may be constrained by policy or regulation.

---

# 104. Vendor Secret Manager

Vendor selection must consider:

- availability;
- audit;
- API;
- rotation;
- KMS/HSM;
- export controls;
- recovery;
- pricing;
- lock-in.

---

# 105. Local Development

Local development secrets:

- non-production only;
- separate accounts;
- minimum privilege;
- developer-specific where possible;
- easy rotation.

---

# 106. Test Environment

Use synthetic/test credentials only.

---

# 107. CI/CD Secrets

Pipeline secrets must be scoped to:

- repository/project;
- environment;
- branch/tag;
- job;
- duration.

---

# 108. Deployment Secrets

Deployment runner should use workload identity or short-lived credentials.

---

# 109. Secret Injection to Containers

Avoid baking secrets into image layers.

---

# 110. Kubernetes/Container Direction

Use secret manager integration or protected runtime secret mechanism.

---

# 111. Application Configuration

Application receives secret references, not values, where possible.

---

# 112. Secret Reference

Example:

```text
secret://prod/billing/payment_gateway/client_secret
```

---

# 113. Secret Provider Interface

```php
interface SecretProviderInterface
{
    public function get(
        SecretReference $reference,
        SecretAccessContext $context
    ): SecretValueLease;
}
```

---

# 114. Key Provider Interface

```php
interface KeyProviderInterface
{
    public function encrypt(
        KeyReference $key,
        string $plaintext,
        EncryptionContext $context
    ): EncryptedPayload;

    public function decrypt(
        EncryptedPayload $payload,
        EncryptionContext $context
    ): string;
}
```

---

# 115. Certificate Provider Interface

```php
interface CertificateProviderInterface
{
    public function issue(
        CertificateRequest $request
    ): CertificateBundle;

    public function renew(
        string $certificateId
    ): CertificateBundle;

    public function revoke(
        string $certificateId,
        string $reason
    ): void;
}
```

---

# 116. Access Context

Minimum:

```text
subject
workload
environment
tenant
purpose
correlation_id
assurance
```

---

# 117. Secret Policy Decision

```text
ALLOW
DENY
REQUIRE_APPROVAL
REQUIRE_STEP_UP
BREAK_GLASS_ONLY
```

---

# 118. Fail-Closed

Secret provider failure must not fall back to insecure default.

---

# 119. Secret Rotation Orchestration

Potential interface:

```php
interface SecretRotationServiceInterface
{
    public function rotate(
        SecretRotationRequest $request
    ): SecretRotationResult;
}
```

---

# 120. Rotation Verification

Verify:

- new secret accepted;
- all consumers updated;
- old secret no longer used;
- logs clean;
- metrics healthy;
- rollback unnecessary or complete.

---

# 121. Consumer Registry

Every secret should know its dependent consumers.

---

# 122. Consumer Types

```text
APPLICATION
JOB
INTEGRATION
DATABASE
CERTIFICATE_DEPLOYMENT
PIPELINE
HUMAN_BREAK_GLASS
```

---

# 123. Orphan Secret

Secret with no known consumer requires review.

---

# 124. Unknown Secret Usage

Usage by unregistered subject/workload must alert or deny.

---

# 125. Reconciliation

Compare:

- inventory;
- secret store;
- application references;
- deployment manifests;
- certificate endpoints;
- key versions;
- access policies;
- consumers;
- rotation state.

---

# 126. Reconciliation Outcomes

```text
MATCHED
MISSING_IN_STORE
MISSING_IN_INVENTORY
ORPHAN_SECRET
UNKNOWN_CONSUMER
EXPIRED_ACTIVE_SECRET
ROTATION_OVERDUE
CERTIFICATE_EXPIRING
ACCESS_POLICY_DRIFT
KEY_VERSION_DRIFT
```

---

# 127. Reconciliation Frequency

- deployment;
- daily;
- before rotation;
- after rotation;
- after incident;
- before certificate expiry;
- periodic audit.

---

# 128. Audit Events

```text
SEC_SECRET_REQUESTED
SEC_SECRET_CREATED
SEC_SECRET_ACCESSED
SEC_SECRET_REVEALED
SEC_SECRET_ROTATION_STARTED
SEC_SECRET_ROTATED
SEC_SECRET_ROTATION_FAILED
SEC_SECRET_REVOKED
SEC_SECRET_COMPROMISED
SEC_KEY_CREATED
SEC_KEY_ROTATED
SEC_KEY_DESTROYED
SEC_CERTIFICATE_ISSUED
SEC_CERTIFICATE_RENEWED
SEC_CERTIFICATE_REVOKED
SEC_RECONCILIATION_FAILED
```

---

# 129. Audit Metadata

```text
secret_or_key_id
secret_code
type
owner
environment
scope
subject/workload
purpose
result
version
correlation_id
```

---

# 130. Metrics

```text
security_secret_total
security_secret_access_total
security_secret_rotation_total
security_secret_rotation_failure_total
security_secret_expired_total
security_secret_overdue_rotation_total
security_certificate_expiring_total
security_certificate_expired_total
security_key_version_total
security_secret_reconciliation_failure_total
```

---

# 131. KPIs

```text
Secrets in source code = 0
Production secrets reused in non-production = 0
Critical secrets without owner = 0
Critical secrets without rotation policy = 0
Expired active certificates = 0
Overdue critical rotations = 0
Shared privileged credentials trend = 0
Secret access without audit = 0
```

---

# 132. KRIs

```text
Long-lived credential count
Shared secret count
Rotation failure rate
Expired certificate count
Secret reveal frequency
Unknown consumer access
Emergency rotations
Orphan secret growth
Unprotected local secrets
```

---

# 133. Database Direction

Metadata only; secret values must not be stored in ordinary application tables.

Potential tables:

```text
security_secret_inventory
security_secret_versions
security_secret_consumers
security_secret_leases
security_secret_rotation_jobs
security_key_inventory
security_certificate_inventory
security_secret_access_reviews
security_secret_reconciliation_runs
security_secret_reconciliation_findings
```

---

# 134. Table: security_secret_inventory

```sql
CREATE TABLE security_secret_inventory (
    id CHAR(26) NOT NULL,
    secret_code VARCHAR(255) NOT NULL,
    secret_type VARCHAR(50) NOT NULL,
    classification VARCHAR(30) NOT NULL,
    owner_reference VARCHAR(180) NOT NULL,
    environment_code VARCHAR(100) NOT NULL,
    scope_type VARCHAR(30) NOT NULL,
    scope_reference VARCHAR(180) NULL,
    provider_reference VARCHAR(1000) NOT NULL,
    status VARCHAR(30) NOT NULL,
    expires_at DATETIME(6) NULL,
    last_rotated_at DATETIME(6) NULL,
    next_rotation_at DATETIME(6) NULL,
    created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),

    PRIMARY KEY (id),
    UNIQUE KEY uq_security_secret_code (secret_code),
    KEY idx_security_secret_rotation (
        status,
        next_rotation_at
    ),
    KEY idx_security_secret_owner (
        owner_reference,
        status
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

# 135. Table: security_secret_versions

```sql
CREATE TABLE security_secret_versions (
    id CHAR(26) NOT NULL,
    secret_id CHAR(26) NOT NULL,
    version_code VARCHAR(100) NOT NULL,
    provider_version_reference VARCHAR(1000) NOT NULL,
    status VARCHAR(30) NOT NULL,
    activated_at DATETIME(6) NULL,
    revoked_at DATETIME(6) NULL,
    fingerprint_sha256 CHAR(64) NULL,

    PRIMARY KEY (id),
    UNIQUE KEY uq_security_secret_version (
        secret_id,
        version_code
    ),
    CONSTRAINT fk_security_secret_version_secret
        FOREIGN KEY (secret_id)
        REFERENCES security_secret_inventory (id)
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

# 136. Table: security_secret_consumers

```sql
CREATE TABLE security_secret_consumers (
    id CHAR(26) NOT NULL,
    secret_id CHAR(26) NOT NULL,
    consumer_type VARCHAR(40) NOT NULL,
    consumer_reference VARCHAR(255) NOT NULL,
    purpose_code VARCHAR(180) NOT NULL,
    status VARCHAR(30) NOT NULL,
    last_accessed_at DATETIME(6) NULL,

    PRIMARY KEY (id),
    UNIQUE KEY uq_security_secret_consumer (
        secret_id,
        consumer_type,
        consumer_reference,
        purpose_code
    ),
    CONSTRAINT fk_security_secret_consumer_secret
        FOREIGN KEY (secret_id)
        REFERENCES security_secret_inventory (id)
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

# 137. Table: security_key_inventory

```sql
CREATE TABLE security_key_inventory (
    id CHAR(26) NOT NULL,
    key_code VARCHAR(255) NOT NULL,
    key_type VARCHAR(50) NOT NULL,
    algorithm_code VARCHAR(100) NOT NULL,
    provider_reference VARCHAR(1000) NOT NULL,
    owner_reference VARCHAR(180) NOT NULL,
    environment_code VARCHAR(100) NOT NULL,
    status VARCHAR(30) NOT NULL,
    current_version VARCHAR(100) NOT NULL,
    next_rotation_at DATETIME(6) NULL,
    created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),

    PRIMARY KEY (id),
    UNIQUE KEY uq_security_key_code (key_code),
    KEY idx_security_key_rotation (
        status,
        next_rotation_at
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

# 138. Table: security_certificate_inventory

```sql
CREATE TABLE security_certificate_inventory (
    id CHAR(26) NOT NULL,
    certificate_code VARCHAR(255) NOT NULL,
    certificate_type VARCHAR(50) NOT NULL,
    subject_name VARCHAR(500) NOT NULL,
    issuer_name VARCHAR(500) NOT NULL,
    serial_number VARCHAR(255) NOT NULL,
    fingerprint_sha256 CHAR(64) NOT NULL,
    owner_reference VARCHAR(180) NOT NULL,
    environment_code VARCHAR(100) NOT NULL,
    provider_reference VARCHAR(1000) NOT NULL,
    status VARCHAR(30) NOT NULL,
    valid_from DATETIME(6) NOT NULL,
    valid_to DATETIME(6) NOT NULL,
    last_renewed_at DATETIME(6) NULL,

    PRIMARY KEY (id),
    UNIQUE KEY uq_security_certificate_code (
        certificate_code
    ),
    KEY idx_security_certificate_expiry (
        status,
        valid_to
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

# 139. API Direction

```text
GET  /api/internal/v1/security/secrets
POST /api/internal/v1/security/secrets
GET  /api/internal/v1/security/secrets/{secretCode}
POST /api/internal/v1/security/secrets/{secretCode}/rotate
POST /api/internal/v1/security/secrets/{secretCode}/revoke
POST /api/internal/v1/security/secrets/{secretCode}/reveal
GET  /api/internal/v1/security/keys
POST /api/internal/v1/security/keys/{keyCode}/rotate
GET  /api/internal/v1/security/certificates
POST /api/internal/v1/security/certificates/{certificateCode}/renew
POST /api/internal/v1/security/certificates/{certificateCode}/revoke
POST /api/internal/v1/security/reconcile
```

---

# 140. Error Codes

```text
SEC_SECRET_NOT_FOUND
SEC_SECRET_ACCESS_DENIED
SEC_SECRET_PROVIDER_UNAVAILABLE
SEC_SECRET_EXPIRED
SEC_SECRET_REVOKED
SEC_SECRET_COMPROMISED
SEC_SECRET_ROTATION_FAILED
SEC_SECRET_REVEAL_DENIED
SEC_KEY_NOT_FOUND
SEC_KEY_VERSION_INVALID
SEC_KEY_ROTATION_FAILED
SEC_KEY_DESTRUCTION_BLOCKED
SEC_CERTIFICATE_NOT_FOUND
SEC_CERTIFICATE_EXPIRED
SEC_CERTIFICATE_RENEWAL_FAILED
SEC_CERTIFICATE_REVOCATION_FAILED
SEC_RECONCILIATION_FAILED
```

---

# 141. Secret Creation Checklist

- [ ] Purpose defined.
- [ ] Owner assigned.
- [ ] Environment defined.
- [ ] Scope defined.
- [ ] Secret type defined.
- [ ] Classification defined.
- [ ] Provider approved.
- [ ] Rotation policy defined.
- [ ] Expiry defined where applicable.
- [ ] Consumers registered.
- [ ] Access policy defined.
- [ ] Audit enabled.

---

# 142. Rotation Checklist

- [ ] New version generated.
- [ ] Consumers identified.
- [ ] Overlap window defined.
- [ ] Distribution complete.
- [ ] Consumer verification passed.
- [ ] Old version usage stopped.
- [ ] Old version revoked.
- [ ] Cache invalidated.
- [ ] Metrics healthy.
- [ ] Audit evidence retained.

---

# 143. Certificate Checklist

- [ ] Subject validated.
- [ ] Owner assigned.
- [ ] Environment correct.
- [ ] Private key protected.
- [ ] Trust chain valid.
- [ ] SANs correct.
- [ ] Expiry monitoring active.
- [ ] Renewal automation configured.
- [ ] Revocation method defined.
- [ ] Deployment verified.

---

# 144. UAT — Secret Storage

- [ ] Secret absent from source code.
- [ ] Secret absent from build artifact.
- [ ] Secret absent from logs.
- [ ] Secret stored in approved provider.
- [ ] Wrong workload denied.
- [ ] Wrong environment denied.
- [ ] Wrong tenant denied.
- [ ] Access audited.
- [ ] Provider outage fails closed.

---

# 145. UAT — Secret Retrieval

- [ ] Authorized workload retrieves secret.
- [ ] Unauthorized workload denied.
- [ ] Human reveal requires strong authentication.
- [ ] Reveal reason required.
- [ ] Reveal event audited.
- [ ] Cache TTL enforced.
- [ ] Revocation invalidates cache.
- [ ] Expired secret rejected.
- [ ] Sensitive value masked in UI/logs.

---

# 146. UAT — Rotation

- [ ] Scheduled rotation starts.
- [ ] New secret version created.
- [ ] Consumers update.
- [ ] Dual-secret window bounded.
- [ ] Old version revoked.
- [ ] Failed consumer blocks completion.
- [ ] Rollback works where supported.
- [ ] Emergency rotation works.
- [ ] Rotation evidence complete.

---

# 147. UAT — Keys

- [ ] Encryption key works.
- [ ] Signing key works.
- [ ] Encryption/signing separation enforced.
- [ ] Key version recorded.
- [ ] Old ciphertext remains decryptable per policy.
- [ ] Revoked key behavior follows policy.
- [ ] Key destruction blocked when data depends on it.
- [ ] Recovery/escrow test works.
- [ ] Non-exportable policy enforced where required.

---

# 148. UAT — Certificates

- [ ] Valid TLS certificate deploys.
- [ ] Expiry alerts fire.
- [ ] Renewal succeeds.
- [ ] Expired certificate rejected.
- [ ] Revoked certificate rejected.
- [ ] Wrong hostname fails.
- [ ] mTLS client identity enforced.
- [ ] Trust store update audited.
- [ ] Private key never exposed.

---

# 149. UAT — Environment & Tenant Isolation

- [ ] Production secret unavailable in staging.
- [ ] Staging secret unavailable in production.
- [ ] Tenant A credential unavailable to Tenant B.
- [ ] Local developer uses non-production credential.
- [ ] Tenant rotation does not affect other tenants.
- [ ] Cross-tenant workload denied.
- [ ] Shared secret exception audited.
- [ ] Backup keys environment-specific.

---

# 150. UAT — Secret Leak Response

- [ ] Scanner detects test secret.
- [ ] Secret marked compromised.
- [ ] Revocation occurs.
- [ ] New version distributed.
- [ ] Repository history finding recorded.
- [ ] Consumers recover.
- [ ] Incident linked.
- [ ] Post-incident review created.
- [ ] No continued use of leaked version.

---

# 151. UAT — CI/CD & Deployment

- [ ] Pipeline secret scoped correctly.
- [ ] Secret unavailable to unapproved branch.
- [ ] Secret not baked into image.
- [ ] Deployment runner uses short-lived credential.
- [ ] Debug logs do not expose secret.
- [ ] Failed deployment does not leak secret.
- [ ] Rotation propagates to workload.
- [ ] Artifact scan passes.
- [ ] Deployment evidence retained.

---

# 152. UAT — Reconciliation

- [ ] Missing store entry detected.
- [ ] Missing inventory entry detected.
- [ ] Orphan secret detected.
- [ ] Unknown consumer detected.
- [ ] Overdue rotation detected.
- [ ] Expiring certificate detected.
- [ ] Key version drift detected.
- [ ] Access policy drift detected.
- [ ] Critical finding opens case.
- [ ] Report generated.

---

# 153. Definition of Done — SSOT-SEC-03

SSOT-SEC-03 dianggap selesai bila:

- [ ] secret definitions and categories tersedia;
- [ ] classification and ownership tersedia;
- [ ] inventory and lifecycle tersedia;
- [ ] generation and storage controls tersedia;
- [ ] runtime injection and retrieval tersedia;
- [ ] access control and lease tersedia;
- [ ] rotation and revocation tersedia;
- [ ] emergency rotation tersedia;
- [ ] key hierarchy and envelope encryption tersedia;
- [ ] key versioning/recovery/destruction tersedia;
- [ ] certificate lifecycle tersedia;
- [ ] mTLS and trust store governance tersedia;
- [ ] API/database/webhook credentials tersedia;
- [ ] secret scanning and leak response tersedia;
- [ ] environment/tenant isolation tersedia;
- [ ] CI/CD and deployment controls tersedia;
- [ ] backup and DR tersedia;
- [ ] reconciliation tersedia;
- [ ] audit/logging/metrics tersedia;
- [ ] database direction tersedia;
- [ ] API direction tersedia;
- [ ] SDK contracts tersedia;
- [ ] error codes tersedia;
- [ ] checklists and UAT tersedia.

---

# 154. Implementation Roadmap

## Phase 1 — Secret Inventory Foundation

- secret metadata registry;
- naming and ownership;
- provider abstraction;
- access policy;
- audit events;
- basic secret references.

## Phase 2 — Runtime Secret Management

- workload identity;
- secret retrieval;
- short-lived leases;
- application injection;
- cache invalidation;
- environment isolation.

## Phase 3 — Rotation & Certificate Automation

- rotation orchestrator;
- consumer registry;
- zero-downtime rotation;
- certificate inventory;
- renewal automation;
- expiry alerts.

## Phase 4 — Key Management

- KMS integration;
- key hierarchy;
- envelope encryption;
- signing key rotation;
- key recovery;
- re-encryption tooling.

## Phase 5 — Advanced Security

- HSM integration;
- non-exportable keys;
- automatic compromise response;
- workload certificates;
- continuous reconciliation;
- cryptographic agility dashboard.

---

# 155. Initial Implementation Backlog

```text
SEC03-001 Secret Inventory
SEC03-002 Secret Provider Interface
SEC03-003 Secret Reference Resolver
SEC03-004 Workload Access Policy
SEC03-005 Secret Lease Service
SEC03-006 Rotation Orchestrator
SEC03-007 Secret Consumer Registry
SEC03-008 Certificate Inventory
SEC03-009 Certificate Renewal Automation
SEC03-010 Key Provider Interface
SEC03-011 Envelope Encryption Service
SEC03-012 Signing Key Rotation
SEC03-013 Secret Scanner Integration
SEC03-014 Leak Response Workflow
SEC03-015 Reconciliation Engine
SEC03-016 Security Material Dashboard
```

---

# 156. Approval Gate

Dokumen dapat menjadi Approved setelah:

- Security Architecture review;
- Platform Architecture review;
- IAM/RBAC review;
- Cryptography review;
- DevOps/Deployment review;
- Operations review;
- Audit/Compliance review;
- Data Protection review;
- Disaster Recovery review;
- UAT review.

---

# 157. Closing Statement

Secrets, keys, dan certificates harus dikelola sebagai critical security assets.

Mereka harus:

- memiliki owner;
- memiliki purpose;
- memiliki scope;
- disimpan aman;
- dibatasi access;
- memiliki expiry;
- dirotasi;
- dapat dicabut;
- dapat dipulihkan;
- diaudit;
- direkonsiliasi.

Secret bukan configuration biasa.

Key bukan sekadar string.

Certificate bukan artefak yang cukup dipasang sekali.

Seluruh lifecycle harus dikendalikan oleh Platform Kernel security governance.
