# SSOT-SEC-02 — Secure SDLC & Application Security Framework

> Single Source of Truth untuk secure software development lifecycle, application security, secure coding, security testing, software supply chain, release assurance, deployment security, dan operational readiness pada Platform Kernel.

## Metadata Dokumen

| Item | Nilai |
|---|---|
| Kode | SSOT-SEC-02 |
| Judul | Secure SDLC & Application Security Framework |
| Versi | 1.0 |
| Status | Draft for Review |
| Domain | Platform Kernel |
| Kategori | Secure Software Development & Application Security |
| Target Stack | PHP 8.1+, PDO, MySQL 8/MariaDB, Apache/XAMPP, HTML5, JavaScript, Git-based CI/CD |
| Bergantung pada | SSOT-SEC-01 |
| Pemilik | Application Security, Security Architecture, Platform Architecture, Release Engineering, Security Operations |
| Reviewer | Backend Engineering, Frontend Engineering, QA, DevOps, Database Administration, Module Owners, Infrastructure Operations |

## Tujuan Dokumen

Dokumen ini menetapkan standar tunggal untuk:

- Secure SDLC vision, lifecycle, risk tiers, security requirements, threat modeling, architecture review, security gates, ownership, metrics, UAT, dan Definition of Done;
- secure coding untuk PHP, HTML, JavaScript, SQL/PDO, APIs, authentication, authorization, tenant isolation, sessions, files, cryptography, secrets, error handling, logging, concurrency, dan background jobs;
- security testing melalui SAST, DAST, dependency scanning, secret scanning, tenant isolation test suite, fuzzing, penetration testing, vulnerability triage, remediation SLA, evidence, dan reporting;
- CI/CD security, build integrity, artifact signing, provenance, SBOM, release gates, environment promotion, deployment security, migration security, rollback, drift detection, scheduler, APIs, database schema, dan sequence diagrams;
- reference implementation, sample manifests, sample policies, pipeline examples, attack simulations, operational runbooks, final UAT, production readiness, roadmap, dan governance.

## Daftar Isi

1. Bagian I — Secure SDLC Foundation
2. Bagian II — Detailed Secure Coding Standard
3. Bagian III — Security Testing Framework
4. Bagian IV — Secure Delivery & Release Assurance
5. Bagian V — Reference Implementation & Operational Readiness
6. Lampiran A — Sumber Penggabungan
7. Lampiran B — Approval Gate

## Status Normatif

Kata **wajib**, **harus**, dan **tidak boleh** menyatakan persyaratan normatif. Kata **direkomendasikan**, **sebaiknya**, dan **dapat** menyatakan panduan yang dapat disesuaikan melalui keputusan arsitektur atau exception yang terdokumentasi.

---

## Bagian I — Secure SDLC Foundation

### 1. Executive Summary

SSOT-SEC-02 menetapkan framework Secure Software Development Lifecycle dan Application Security untuk Platform Kernel dan seluruh module bisnis.

Framework ini memastikan keamanan tidak hanya diperiksa menjelang production, tetapi menjadi bagian dari:

```text
Planning
Architecture
Design
Development
Code Review
Testing
Build
Release
Deployment
Operation
Retirement
```

Part 1 menetapkan:

- Secure SDLC vision;
- security responsibilities;
- security gates;
- threat modeling;
- secure design review;
- secure coding baseline;
- application security controls;
- security requirements;
- dependency governance;
- secrets prevention;
- code review requirements;
- test strategy;
- security metrics;
- exception process;
- UAT;
- Definition of Done.

Tujuan akhirnya adalah memastikan setiap perubahan software:

- memiliki security requirements;
- memahami attack surface;
- memiliki threat model yang proporsional;
- mengikuti secure coding standard;
- diuji sebelum release;
- tidak membawa secret;
- tidak memperkenalkan akses lintas tenant;
- memiliki evidence;
- dapat ditelusuri ke owner dan approval.

---

### 2. Secure SDLC Objectives

Secure SDLC harus:

- mengurangi vulnerability sejak awal;
- mencegah insecure design;
- menjaga tenant isolation;
- mengurangi regression security;
- mengontrol dependency risk;
- mempercepat remediation;
- menghasilkan evidence;
- membuat security menjadi bagian dari Definition of Done.

---

### 3. Secure SDLC Principles

```text
Shift Left
Secure by Design
Secure by Default
Threat-Informed Development
Least Privilege
Defense in Depth
Automated Verification
Human Review for High Risk
Evidence-Based Approval
Continuous Improvement
```

---

### 4. Lifecycle Overview

```text
Idea
→ Security Classification
→ Security Requirements
→ Architecture Review
→ Threat Modeling
→ Implementation
→ Code Review
→ Security Testing
→ Release Gate
→ Deployment
→ Runtime Monitoring
→ Post-Release Review
→ Retirement
```

---

### 5. Secure SDLC Phases

```text
SEC-SDLC-PLAN
SEC-SDLC-DESIGN
SEC-SDLC-BUILD
SEC-SDLC-VERIFY
SEC-SDLC-RELEASE
SEC-SDLC-OPERATE
SEC-SDLC-RETIRE
```

---

### 6. Planning Phase

Planning wajib menentukan:

- business purpose;
- data classification;
- user types;
- tenant/scope model;
- sensitive actions;
- external integrations;
- regulatory impact;
- required security review level.

---

### 7. Design Phase

Design wajib menentukan:

- trust boundaries;
- data flows;
- authentication;
- authorization;
- tenant isolation;
- encryption;
- secrets;
- logging/audit;
- failure modes;
- recovery;
- abuse cases.

---

### 8. Build Phase

Build wajib mengikuti:

- secure coding standard;
- approved libraries;
- prepared statements;
- output encoding;
- input validation;
- server-side authorization;
- secrets policy;
- security logging.

---

### 9. Verify Phase

Verification mencakup:

- unit tests;
- integration tests;
- security tests;
- tenant isolation tests;
- dependency scan;
- secret scan;
- SAST;
- DAST where applicable;
- manual review for high-risk changes.

---

### 10. Release Phase

Release gate memeriksa:

- unresolved critical findings;
- security test status;
- threat model status;
- dependency risk;
- migration risk;
- configuration safety;
- rollback;
- evidence completeness.

---

### 11. Operate Phase

Operation mencakup:

- monitoring;
- security events;
- vulnerability management;
- incident response;
- access review;
- configuration review;
- post-release validation.

---

### 12. Retirement Phase

Retirement harus:

- revoke credentials;
- remove routes;
- remove permissions;
- archive/delete data sesuai policy;
- preserve audit;
- update inventories;
- close security ownership.

---

### 13. Change Risk Classification

```text
LOW
MEDIUM
HIGH
CRITICAL
```

---

### 14. Low-Risk Change

Contoh:

- text-only UI change;
- non-sensitive style adjustment;
- documentation update;
- internal refactor without behavior change.

Minimum:

- standard code review;
- regression test;
- no security regression.

---

### 15. Medium-Risk Change

Contoh:

- new business form;
- new API field;
- new database query;
- permission-aware page.

Minimum:

- security checklist;
- unit/integration test;
- authorization review;
- input/output review.

---

### 16. High-Risk Change

Contoh:

- authentication;
- authorization;
- patient export;
- file upload;
- payment;
- external integration;
- encryption;
- tenant/scope logic.

Minimum:

- threat model;
- security review;
- security tests;
- release approval;
- post-deployment validation.

---

### 17. Critical Change

Contoh:

- privileged access;
- key management;
- secret reveal;
- cross-tenant operation;
- audit integrity;
- backup restore;
- security framework change.

Minimum:

- architecture review;
- formal threat model;
- dual approval;
- penetration/security testing;
- rollback simulation;
- evidence package.

---

### 18. Security Requirements

Setiap feature harus memiliki security requirements yang testable.

Contoh:

```text
REQ-SEC-001
Only users with patient.record.export may export records.

REQ-SEC-002
Export must be limited to the active tenant and clinic scope.

REQ-SEC-003
Export package must expire after 24 hours.

REQ-SEC-004
Export action must create an audit event.
```

---

### 19. Security Requirement Categories

```text
IDENTITY
AUTHENTICATION
AUTHORIZATION
SESSION
TENANT
DATA_PROTECTION
INPUT_VALIDATION
OUTPUT_ENCODING
FILE_SECURITY
API_SECURITY
LOGGING
AUDIT
AVAILABILITY
RECOVERY
PRIVACY
```

---

### 20. Requirement Traceability

Trace:

```text
Security Requirement
→ Design Control
→ Code Change
→ Test Case
→ Evidence
→ Release Decision
```

---

### 21. Security Story Template

```text
As a security-aware system,
I need [control],
so that [threat/risk] is reduced.

Acceptance Criteria:
- ...
- ...
- ...

Evidence:
- test
- screenshot/log
- review
```

---

### 22. Abuse Story Template

```text
As an attacker,
I try to [abuse action],
so that I can [impact].

Expected Defense:
- prevent
- detect
- record
- recover
```

---

### 23. Threat Modeling

Threat modeling dilakukan untuk perubahan medium-high-critical sesuai risk.

---

### 24. Threat Model Inputs

- architecture diagram;
- data flow;
- assets;
- actors;
- trust boundaries;
- entry points;
- dependencies;
- deployment model;
- data classification.

---

### 25. Threat Model Outputs

```text
threat_id
asset
threat_actor
attack_path
likelihood
impact
risk
control
owner
status
evidence
```

---

### 26. STRIDE Categories

```text
Spoofing
Tampering
Repudiation
Information Disclosure
Denial of Service
Elevation of Privilege
```

---

### 27. Threat Modeling Steps

```text
Define Scope
→ Identify Assets
→ Draw Data Flow
→ Mark Trust Boundaries
→ Identify Threats
→ Rate Risk
→ Select Controls
→ Assign Owner
→ Verify
→ Review
```

---

### 28. Threat Example — Cross-Tenant Access

```text
Threat:
User from Tenant A manipulates resource ID from Tenant B.

Risk:
Restricted patient data exposure.

Controls:
- tenant-aware repository
- resource-level authorization
- opaque identifier
- audit
- cross-tenant tests
```

---

### 29. Threat Example — File Upload

```text
Threat:
Attacker uploads executable disguised as an image.

Controls:
- size limit
- MIME detection
- extension allowlist
- malware scan
- storage outside public root
- random storage name
```

---

### 30. Threat Example — Privilege Escalation

```text
Threat:
User modifies role assignment request to assign an admin role.

Controls:
- server-side permission check
- critical role approval
- SoD
- audit
- session invalidation
```

---

### 31. Threat Review Cadence

Review threat model:

- before first release;
- after major architecture change;
- after critical incident;
- after new integration;
- periodically for critical systems.

---

### 32. Security Architecture Review

Architecture review wajib untuk high/critical changes.

---

### 33. Architecture Review Checklist

- [ ] assets identified;
- [ ] trust boundaries identified;
- [ ] tenant model clear;
- [ ] authentication defined;
- [ ] authorization defined;
- [ ] data classification defined;
- [ ] encryption defined;
- [ ] secrets handled;
- [ ] audit defined;
- [ ] recovery defined;
- [ ] abuse cases considered.

---

### 34. Security Gates

```text
Intake Gate
Architecture Gate
Implementation Gate
Verification Gate
Release Gate
Post-Release Gate
Retirement Gate
```

---

### 35. Intake Gate

Checks:

- risk classification;
- data classification;
- owner;
- security reviewer;
- required artifacts.

---

### 36. Architecture Gate

Checks:

- threat model;
- trust boundaries;
- authentication;
- authorization;
- tenant isolation;
- encryption;
- audit;
- recovery.

---

### 37. Implementation Gate

Checks:

- secure coding;
- no hard-coded secret;
- prepared statements;
- output encoding;
- permission enforcement;
- safe error handling;
- code review.

---

### 38. Verification Gate

Checks:

- unit tests;
- integration tests;
- security tests;
- SAST;
- dependency scan;
- secret scan;
- tenant tests;
- DAST/manual test where needed.

---

### 39. Release Gate

Checks:

- no unresolved critical vulnerability;
- high-risk findings accepted or fixed;
- evidence complete;
- rollback ready;
- configuration secure;
- approvals complete.

---

### 40. Post-Release Gate

Checks:

- deployment validation;
- security logs/events;
- no spike in errors/denials;
- configuration matches baseline;
- incident watch.

---

### 41. Retirement Gate

Checks:

- credentials revoked;
- permissions removed;
- routes disabled;
- data handled;
- audit preserved;
- ownership closed.

---

### 42. Secure Coding Domains

```text
INPUT_VALIDATION
OUTPUT_ENCODING
AUTHENTICATION
AUTHORIZATION
SESSION
TENANT_ISOLATION
SQL
FILES
CRYPTOGRAPHY
SECRETS
ERROR_HANDLING
LOGGING
API
DEPENDENCIES
CONCURRENCY
```

---

### 43. Input Validation

Input must be:

- typed;
- length-limited;
- format-validated;
- enum-constrained;
- allowlist-driven;
- normalized carefully.

---

### 44. Output Encoding

Encode based on context:

- HTML;
- attribute;
- URL;
- JavaScript;
- JSON.

---

### 45. Authentication Coding Baseline

Do not:

- compare password manually;
- expose user existence;
- store plaintext password;
- skip throttling;
- keep session ID after login.

---

### 46. Authorization Coding Baseline

Do not:

- trust menu visibility;
- trust hidden fields;
- check role strings ad hoc;
- skip resource ownership;
- skip tenant/scope filters.

---

### 47. Session Coding Baseline

Ensure:

- session rotation;
- server-side session;
- secure cookie;
- expiry;
- revocation;
- permission version validation.

---

### 48. Tenant Isolation Coding Baseline

Every tenant-aware query must:

- receive trusted tenant context;
- include tenant filter;
- validate resource tenant;
- isolate cache keys;
- audit cross-tenant attempts.

---

### 49. SQL Security

Use:

```php
$stmt = $pdo->prepare(
    'SELECT * FROM patients
     WHERE tenant_id = :tenant_id
       AND id = :id'
);

$stmt->execute([
    'tenant_id' => $tenantId,
    'id' => $patientId,
]);
```

---

### 50. Dynamic SQL

Table/column/order inputs must come from server-side allowlists.

---

### 51. File Security

Use:

- MIME detection;
- allowlist;
- size limit;
- random storage name;
- non-public storage;
- authorized download;
- malware scan where available.

---

### 52. Cryptography Coding Baseline

Do not implement custom cryptography.

Use approved service interfaces and libraries.

---

### 53. Secrets Coding Baseline

Do not:

- commit secrets;
- log secrets;
- expose secrets to browser;
- reuse production secrets in development;
- hard-code encryption keys.

---

### 54. Error Handling

Client receives:

- safe message;
- stable error code;
- request ID.

Internal logs receive structured details without secret leakage.

---

### 55. Logging Security

Log:

- failures;
- denials;
- privileged actions;
- security state changes.

Do not log:

- raw password;
- token;
- API key;
- encryption key;
- unnecessary restricted payload.

---

### 56. API Security Baseline

- authentication;
- authorization;
- schema validation;
- rate limiting;
- request size limits;
- idempotency where needed;
- safe errors;
- versioning.

---

### 57. Dependency Governance

Every dependency must have:

```text
name
version
source
owner
license
security status
last reviewed
```

---

### 58. Dependency Rules

Do not:

- use abandoned packages without exception;
- use unpinned versions in production;
- ignore critical advisories;
- install package from untrusted source;
- bypass lock file review.

---

### 59. Dependency Update Process

```text
Detect
→ Assess
→ Test
→ Update
→ Verify
→ Deploy
→ Monitor
```

---

### 60. Supply Chain Controls

Recommended:

- lock files;
- package integrity;
- trusted registries;
- dependency scanning;
- SBOM;
- artifact signing;
- protected CI credentials.

---

### 61. Secret Scanning

Scan:

- source code;
- commits;
- configuration;
- build artifacts;
- logs where applicable.

---

### 62. Secret Detection Response

If secret found:

1. revoke;
2. rotate;
3. remove from history where feasible;
4. identify exposure;
5. create incident if necessary;
6. prevent recurrence.

---

### 63. Code Review Requirements

Every production change requires review.

High-risk changes require reviewer with security competence.

---

### 64. Security Code Review Checklist

- [ ] authorization server-side;
- [ ] tenant/scope enforced;
- [ ] prepared statements;
- [ ] validation complete;
- [ ] output encoded;
- [ ] no secret leakage;
- [ ] error safe;
- [ ] audit/events defined;
- [ ] tests present;
- [ ] migrations safe.

---

### 65. Self-Approval

Developer should not be sole approver for critical security changes.

---

### 66. Branch Protection Direction

Recommended:

- pull request required;
- review required;
- status checks required;
- protected main branch;
- signed commits/releases optional;
- force push disabled.

---

### 67. Security Testing Layers

```text
Unit
Integration
Contract
Tenant Isolation
SAST
Dependency Scan
Secret Scan
DAST
Manual Review
Penetration Test
Runtime Validation
```

---

### 68. Unit Security Tests

Examples:

- validator rejects invalid enum;
- authorization denies missing permission;
- tenant guard denies mismatch;
- masking hides restricted fields;
- retention blocks purge.

---

### 69. Integration Security Tests

Examples:

- login/MFA/session;
- role assignment;
- cross-tenant API access;
- file upload/download;
- secret rotation;
- audit event creation.

---

### 70. Tenant Isolation Tests

Minimum:

- object read;
- list/search;
- create with foreign tenant;
- update;
- delete;
- export;
- cache;
- file;
- async job.

---

### 71. SAST

Static analysis should detect:

- injection;
- unsafe functions;
- insecure deserialization;
- hard-coded secret;
- path traversal;
- weak crypto;
- unsafe output.

---

### 72. Dependency Scan

Must identify:

- known vulnerabilities;
- severity;
- affected version;
- fixed version;
- exploitability;
- owner.

---

### 73. DAST

Use for externally reachable web/API paths where feasible.

---

### 74. Manual Security Testing

Required for:

- authentication;
- authorization;
- tenant isolation;
- file upload;
- critical admin;
- sensitive export;
- high-risk integrations.

---

### 75. Penetration Testing

Recommended:

- before major production launch;
- after major security architecture change;
- periodically for critical systems;
- after serious incident where needed.

---

### 76. Security Test Evidence

Evidence should include:

```text
test_id
requirement
scope
environment
result
tester
date
artifact
finding
```

---

### 77. Finding Severity

```text
LOW
MEDIUM
HIGH
CRITICAL
```

---

### 78. Finding States

```text
OPEN
ASSIGNED
IN_PROGRESS
REMEDIATED
VERIFIED
RISK_ACCEPTED
CLOSED
```

---

### 79. Release Blocking Rules

Block release when:

- critical vulnerability open;
- tenant isolation fails;
- authentication bypass exists;
- privilege escalation exists;
- secret exposed;
- restricted file publicly accessible;
- audit integrity broken.

---

### 80. High Findings

High findings require:

- fix before release; or
- time-bound risk acceptance;
- compensating control;
- explicit approval.

---

### 81. Security Exception

Exception record:

```text
exception_id
control
scope
reason
risk
compensating_control
owner
approver
expires_at
status
```

---

### 82. Exception Restrictions

Exception cannot be:

- indefinite;
- ownerless;
- without evidence;
- used to bypass critical tenant isolation without executive/security approval;
- silently renewed.

---

### 83. AppSec Ownership

```text
Security Architecture
Application Security
Platform Architecture
Engineering Lead
Module Owner
QA
DevOps
Security Operations
```

---

### 84. Security Champion

Each engineering domain should have a Security Champion.

Responsibilities:

- support threat modeling;
- review high-risk changes;
- coordinate remediation;
- improve security practices;
- maintain local evidence.

---

### 85. RACI

| Activity | AppSec | Architect | Dev | QA | DevOps | Module Owner |
|---|---|---|---|---|---|---|
| Security requirements | C | A | R | C | I | C |
| Threat model | R | A | C | C | C | C |
| Secure implementation | C | C | R | C | C | A |
| Security testing | C | I | C | R | C | I |
| Release gate | R | C | C | C | C | A |
| Vulnerability remediation | C | I | R | C | C | A |

---

### 86. AppSec Metrics

```text
security_requirements_coverage_ratio
threat_model_coverage_ratio
security_test_pass_ratio
critical_findings_open_total
high_findings_overdue_total
dependency_vulnerability_total
secret_detection_total
tenant_isolation_test_pass_ratio
security_review_lead_time
remediation_mean_time
```

---

### 87. Initial KPI Targets

```text
Critical findings open at release = 0
Tenant isolation test pass = 100%
Privileged feature threat model coverage = 100%
Secret scan pass = 100%
Critical dependency overdue = 0
High-risk change security review coverage = 100%
```

---

### 88. Security Dashboard

Should display:

- open findings;
- overdue remediation;
- threat model coverage;
- security gate failures;
- dependency risk;
- secret detection;
- tenant isolation results;
- release exceptions.

---

### 89. Secure SDLC Artifacts

Required artifacts may include:

```text
security requirements
threat model
architecture review
code review checklist
security test results
dependency scan
secret scan
release approval
risk exception
post-release validation
```

---

### 90. Evidence Retention

Security release evidence must follow retention policy and remain traceable to:

- release;
- commit;
- build;
- environment;
- owner;
- approval.

---

### 91. Module Security Manifest

```yaml
module_code: patient
owner: patient_domain
risk_level: HIGH
data_classification:
  - RESTRICTED
security_requirements:
  - tenant_isolation
  - resource_authorization
  - audit_access
security_tests:
  - patient_cross_tenant_read
  - patient_cross_clinic_update
  - patient_export_permission
```

---

### 92. Feature Security Manifest

```yaml
feature_code: patient_export
risk_level: CRITICAL
permissions:
  - patient.record.export
authentication_assurance: AAL2
audit_events:
  - PATIENT_EXPORT_REQUESTED
  - PATIENT_EXPORT_COMPLETED
retention_policy: SECURE_EXPORT_24H
```

---

### 93. CI/CD Security Gate Direction

```text
Commit
→ Secret Scan
→ SAST
→ Unit Tests
→ Dependency Scan
→ Build
→ Integration Tests
→ Tenant Tests
→ Security Gate
→ Release
```

---

### 94. Fail-Closed Gates

Critical gates should fail closed for:

- secret detection;
- critical vulnerability;
- tenant isolation failure;
- authentication bypass;
- artifact integrity failure.

---

### 95. Fail-Open Gates

Only for non-critical informational controls with:

- explicit policy;
- logging;
- owner;
- review;
- expiry.

---

### 96. Secure Release Package

Release package should contain:

- build artifact;
- checksum;
- version;
- dependency lock;
- migration;
- security evidence;
- approval;
- rollback instructions.

---

### 97. Post-Deployment Security Validation

Validate:

- authentication;
- authorization;
- tenant isolation;
- security headers;
- audit events;
- secure config;
- vulnerable endpoints;
- file protection;
- monitoring.

---

### 98. Security Regression

Every fixed security vulnerability should produce a regression test where feasible.

---

### 99. Incident Feedback Loop

Security incidents should update:

- threat models;
- coding standards;
- test cases;
- detection rules;
- release gates;
- training.

---

### 100. Developer Security Enablement

Provide:

- secure coding guide;
- examples;
- templates;
- local test tools;
- pre-commit checks;
- security office hours;
- training.

---

### 101. Secure Coding Training

Required for:

- backend developers;
- frontend developers;
- DevOps;
- reviewers;
- technical leads.

---

### 102. Training Topics

- injection;
- XSS;
- CSRF;
- authorization;
- tenant isolation;
- sessions;
- secrets;
- file uploads;
- secure APIs;
- logging;
- privacy.

---

### 103. Anti-Pattern

Avoid:

- security review only before production;
- threat model after coding;
- permission checks only in UI;
- tenant ID trusted from request;
- scanner-only security;
- unresolved critical findings at release;
- dependency updates without testing;
- secret rotation without incident review;
- security exceptions without expiry;
- fixing vulnerability without regression test.

---

### 104. UAT Part 1

#### Secure SDLC Governance

- [ ] Lifecycle phases defined.
- [ ] Risk classification defined.
- [ ] Security owners defined.
- [ ] Security Champion role defined.
- [ ] Security gates defined.
- [ ] Exception process defined.
- [ ] Metrics and KPIs defined.

#### Security Requirements

- [ ] Requirements are testable.
- [ ] Requirements trace to design.
- [ ] Requirements trace to tests.
- [ ] Sensitive actions identified.
- [ ] Tenant/scope requirements explicit.
- [ ] Audit requirements explicit.

#### Threat Modeling

- [ ] Assets identified.
- [ ] Data flows documented.
- [ ] Trust boundaries marked.
- [ ] STRIDE considered.
- [ ] Risks rated.
- [ ] Controls assigned.
- [ ] Threat model reviewed.

#### Secure Coding

- [ ] Input validation standard exists.
- [ ] Output encoding standard exists.
- [ ] Prepared statements required.
- [ ] Authorization server-side.
- [ ] Tenant isolation standard exists.
- [ ] Secrets policy enforced.
- [ ] Safe error handling exists.
- [ ] Secure logging standard exists.

#### Code Review

- [ ] Review required.
- [ ] High-risk changes receive security review.
- [ ] Security checklist used.
- [ ] Critical changes avoid sole self-approval.
- [ ] Branch protection direction exists.

#### Testing

- [ ] Unit security tests exist.
- [ ] Integration security tests exist.
- [ ] Tenant isolation tests exist.
- [ ] SAST direction exists.
- [ ] Dependency scan exists.
- [ ] Secret scan exists.
- [ ] DAST/manual test criteria exist.
- [ ] Penetration test criteria exist.

#### Release

- [ ] Release blocking rules defined.
- [ ] Critical findings block release.
- [ ] High findings require approval.
- [ ] Security evidence retained.
- [ ] Post-deployment validation exists.
- [ ] Security regression tests required.

---

### 105. Definition of Done Part 1

Part 1 dianggap selesai bila:

- [ ] Secure SDLC objectives tersedia;
- [ ] principles tersedia;
- [ ] lifecycle phases tersedia;
- [ ] change risk classification tersedia;
- [ ] security requirements model tersedia;
- [ ] abuse stories tersedia;
- [ ] threat modeling framework tersedia;
- [ ] architecture review tersedia;
- [ ] security gates tersedia;
- [ ] secure coding domains tersedia;
- [ ] dependency governance tersedia;
- [ ] secret scanning tersedia;
- [ ] code review standard tersedia;
- [ ] security testing layers tersedia;
- [ ] finding lifecycle tersedia;
- [ ] release blocking rules tersedia;
- [ ] exception process tersedia;
- [ ] ownership/RACI tersedia;
- [ ] metrics/KPI tersedia;
- [ ] module/feature manifest tersedia;
- [ ] CI/CD gate direction tersedia;
- [ ] post-release validation tersedia;
- [ ] training direction tersedia;
- [ ] UAT tersedia.

---

### 106. Rencana Part Berikutnya

#### Part 2

Detailed secure coding standard untuk PHP, HTML, JavaScript, SQL, APIs, file handling, sessions, authentication, authorization, tenant isolation, cryptography, secrets, error handling, dan logging.

#### Part 3

Security testing framework: SAST, DAST, dependency scanning, secret scanning, tenant isolation test suite, fuzzing, penetration testing, vulnerability triage, remediation SLA, evidence, dan reporting.

#### Part 4

CI/CD security pipelines, build integrity, artifact signing, SBOM, release gates, environment promotion, deployment security, rollback, infrastructure configuration, scheduler, APIs, database schema, dan sequence diagrams.

#### Part 5

Reference implementation, sample manifests, sample policies, pipeline examples, attack simulations, operational runbooks, final UAT, Definition of Done, roadmap, dan merge guidance menjadi `SSOT-SEC-02.md`.

---

## Bagian II — Detailed Secure Coding Standard

### 1. Executive Summary

Part 2 mendefinisikan standar secure coding rinci untuk Platform Kernel dan seluruh module bisnis.

Bagian ini menetapkan kontrol implementasi untuk:

- PHP;
- HTML;
- JavaScript;
- SQL/PDO;
- HTTP APIs;
- input validation;
- output encoding;
- authentication;
- authorization;
- tenant/scope isolation;
- session security;
- CSRF;
- file upload/download;
- cryptography;
- secrets;
- error handling;
- logging;
- concurrency;
- redirects;
- SSRF;
- command execution;
- serialization;
- cache;
- background jobs;
- code review;
- UAT;
- Definition of Done.

Tujuan utamanya adalah memastikan seluruh implementasi:

- aman secara default;
- konsisten;
- mudah direview;
- tenant-aware;
- tidak membocorkan secret;
- tidak mengandalkan UI sebagai enforcement;
- dapat diuji;
- dapat diaudit.

---

### 2. Normative Language

Kata:

```text
MUST / WAJIB
MUST NOT / TIDAK BOLEH
SHOULD / DIREKOMENDASIKAN
MAY / DAPAT
```

digunakan untuk menyatakan tingkat kewajiban.

---

### 3. Secure Coding Principles

```text
Validate Inputs
Encode Outputs
Use Prepared Statements
Authorize Every Sensitive Action
Bind Every Resource to Tenant/Scope
Use Secure Defaults
Fail Secure
Minimize Data
Protect Secrets
Log Security-Relevant Events
Avoid Custom Cryptography
```

---

### 4. General PHP Baseline

Semua file PHP production wajib:

```php
<?php

declare(strict_types=1);
```

---

### 5. Type Safety

Gunakan:

- scalar type declarations;
- return types;
- readonly where appropriate;
- enums for bounded values;
- DTOs for external input;
- immutable value objects where useful.

---

### 6. Avoid Weak Dynamic Behavior

Hindari:

- variable variables;
- dynamic properties;
- `eval`;
- uncontrolled reflection;
- runtime class names dari user input;
- magic behavior tanpa guard.

---

### 7. PHP Error Reporting

Development:

```ini
display_errors = On
log_errors = On
```

Production:

```ini
display_errors = Off
display_startup_errors = Off
log_errors = On
```

---

### 8. No Raw Exception to Client

Jangan kirim:

- stack trace;
- file path;
- SQL;
- secrets;
- internal identifiers;
- raw exception messages.

---

### 9. PHP Input Sources

Treat as untrusted:

```text
$_GET
$_POST
$_COOKIE
$_FILES
$_SERVER
request body
headers
CLI arguments
environment variables
database values from untrusted source
integration payloads
```

---

### 10. Input DTO Pattern

```php
final readonly class PatientUpdateCommand
{
    public function __construct(
        public string $patientId,
        public string $name,
        public ?string $phone
    ) {
    }

    public static function fromArray(array $input): self
    {
        return new self(
            patientId: Input::requiredUlid(
                $input,
                'patient_id'
            ),
            name: Input::requiredString(
                $input,
                'name',
                min: 1,
                max: 150
            ),
            phone: Input::nullablePhone(
                $input,
                'phone'
            )
        );
    }
}
```

---

### 11. Input Validation Rules

Validate:

- presence;
- type;
- length;
- range;
- format;
- enum;
- relationship;
- business constraints;
- tenant/scope membership.

---

### 12. Validation vs Sanitization

Validation determines whether input is accepted.

Sanitization is not a substitute for validation.

---

### 13. Allowlist over Denylist

Use allowlists for:

- file extensions;
- MIME types;
- sort columns;
- status values;
- route actions;
- integration event types;
- redirect hosts.

---

### 14. Canonicalization

Normalize before validating where necessary:

- Unicode normalization;
- line endings;
- phone formats;
- email casing;
- path separators;
- identifiers.

Do not over-normalize security-sensitive values.

---

### 15. Unknown Fields

For sensitive APIs, unknown fields should be rejected.

---

### 16. Mass Assignment

Do not map request arrays directly to entities.

Bad:

```php
$patient->fill($_POST);
```

Good:

```php
$command = PatientUpdateCommand::fromArray(
    $request->json()
);
```

---

### 17. Integer Validation

Avoid loose casting.

Bad:

```php
$id = (int) $_GET['id'];
```

Good:

```php
$id = Input::requiredPositiveInt(
    $_GET,
    'id'
);
```

---

### 18. Boolean Validation

Do not rely on truthy/falsy user input.

---

### 19. Enum Validation

```php
enum PatientStatus: string
{
    case ACTIVE = 'ACTIVE';
    case INACTIVE = 'INACTIVE';
}
```

---

### 20. Date Validation

Validate:

- format;
- timezone;
- range;
- logical consistency;
- future/past policy.

---

### 21. Identifier Validation

Prefer:

- ULID;
- UUID;
- numeric ID with strict parsing.

Opaque IDs reduce enumeration but do not replace authorization.

---

### 22. Output Encoding

Encode based on output context.

---

### 23. HTML Text Context

```php
<?= htmlspecialchars(
    $value,
    ENT_QUOTES | ENT_SUBSTITUTE,
    'UTF-8'
) ?>
```

---

### 24. HTML Attribute Context

Always quote attributes and encode.

---

### 25. URL Context

Build URLs using trusted routing helpers.

Do not concatenate raw user values into URLs.

---

### 26. JavaScript Context

Avoid injecting server values directly into inline JavaScript.

Prefer JSON script data with safe encoding.

---

### 27. JSON Encoding

```php
json_encode(
    $data,
    JSON_THROW_ON_ERROR
    | JSON_UNESCAPED_SLASHES
)
```

Do not manually construct JSON strings.

---

### 28. Rich Text

If rich text is allowed:

- sanitize using approved parser;
- enforce allowlist;
- strip scripts;
- strip event handlers;
- validate URLs;
- apply CSP.

---

### 29. XSS Prevention

Prevent XSS with:

- output encoding;
- safe templating;
- CSP;
- no unsafe inline scripts;
- controlled rich text;
- no `innerHTML` from untrusted data.

---

### 30. HTML Templates

Templates must not contain raw unescaped output unless explicitly reviewed.

---

### 31. JavaScript Baseline

Prefer:

- modules;
- strict mode;
- no `eval`;
- no `new Function`;
- no unsafe DOM sinks;
- no secret in browser code.

---

### 32. Unsafe DOM Sinks

Avoid:

```text
innerHTML
outerHTML
insertAdjacentHTML
document.write
eval
setTimeout(string)
setInterval(string)
```

---

### 33. Safe DOM Updates

Use:

```javascript
element.textContent = value;
```

---

### 34. JavaScript Data Attributes

Treat all DOM data as untrusted.

---

### 35. Client-Side Validation

Client validation is UX only.

Server-side validation remains mandatory.

---

### 36. Browser Storage

Do not store sensitive data in:

- localStorage;
- sessionStorage;
- IndexedDB;

unless specifically approved and protected.

---

### 37. Token Storage

For browser session-based apps, prefer secure HttpOnly cookies.

---

### 38. CORS

CORS must use explicit origins.

Avoid:

```text
Access-Control-Allow-Origin: *
```

for authenticated/sensitive APIs.

---

### 39. CSP

Recommended starting point:

```text
default-src 'self';
script-src 'self';
style-src 'self';
img-src 'self' data:;
object-src 'none';
base-uri 'self';
frame-ancestors 'none';
```

Adjust only with documented need.

---

### 40. SQL Security

Use prepared statements for all untrusted values.

---

### 41. PDO Baseline

```php
$pdo = new PDO(
    $dsn,
    $username,
    $password,
    [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
    ]
);
```

---

### 42. Prepared Statement Example

```php
$stmt = $pdo->prepare(
    'SELECT id, name
     FROM patients
     WHERE tenant_id = :tenant_id
       AND clinic_id = :clinic_id
       AND id = :id'
);

$stmt->execute([
    'tenant_id' => $tenantId,
    'clinic_id' => $clinicId,
    'id' => $patientId,
]);
```

---

### 43. Dynamic Identifier Allowlist

```php
$allowedSorts = [
    'created_at',
    'name',
    'status',
];

if (!in_array($sort, $allowedSorts, true)) {
    throw new ValidationException(
        'Invalid sort field.'
    );
}
```

---

### 44. LIKE Queries

Escape wildcards where literal search is intended.

---

### 45. Pagination

Enforce maximum page size.

---

### 46. Bulk Queries

Bulk operations must:

- be bounded;
- be tenant-scoped;
- be permission-checked;
- create audit events;
- support dry-run where high risk.

---

### 47. Transactions

Use transactions for multi-step state changes.

---

### 48. Transaction Example

```php
$pdo->beginTransaction();

try {
    $repository->save($entity);
    $auditRepository->append($auditEvent);

    $pdo->commit();
} catch (\Throwable $exception) {
    $pdo->rollBack();
    throw $exception;
}
```

---

### 49. Deadlock Handling

Retry only:

- bounded times;
- idempotent operations;
- with backoff;
- with logging.

---

### 50. Database Error Handling

Do not expose raw database errors to client.

---

### 51. Query Authorization

Repository query must not assume controller already authorized.

---

### 52. Tenant-Aware Repository

```php
interface PatientRepositoryInterface
{
    public function findById(
        string $patientId,
        TenantScope $scope
    ): ?Patient;
}
```

---

### 53. Cross-Tenant Queries

Only dedicated privileged services may execute cross-tenant queries.

They must require:

- explicit permission;
- reason/purpose;
- bounded scope;
- audit;
- masking.

---

### 54. Authentication Coding Standard

Authentication code must:

- use generic failure messages;
- throttle attempts;
- protect against enumeration;
- require MFA for privileged roles;
- rotate session after success;
- record security events.

---

### 55. Password Handling

Do not:

- log passwords;
- trim passwords unexpectedly;
- limit to short length;
- email passwords;
- store reversible passwords.

---

### 56. Password Reset

Reset tokens must be:

- cryptographically random;
- single-use;
- hashed at rest;
- time-limited;
- invalidated after use.

---

### 57. MFA

MFA challenge must be:

- linked to identity and session;
- time-limited;
- rate-limited;
- single-use where applicable;
- auditable.

---

### 58. Authentication Response

Bad:

```text
Email not found.
```

Good:

```text
Invalid credentials.
```

---

### 59. Authorization Coding Standard

Every sensitive endpoint must define:

```text
permission
resource
tenant
scope
authentication assurance
conditions
```

---

### 60. Authorization Helper

```php
$this->authorization->assertAllowed(
    request: AuthorizationRequest::forResource(
        permission: 'patient.record.update',
        resource: $patient
    ),
    context: $securityContext
);
```

---

### 61. Avoid Ad Hoc Role Checks

Bad:

```php
if ($user->role === 'admin') {
    // allow
}
```

Good:

```php
$authorization->assertPermission(
    'security.identity.manage',
    $context
);
```

---

### 62. Resource-Level Authorization

Check actual resource context:

- tenant;
- clinic;
- owner;
- classification;
- status;
- purpose.

---

### 63. Explicit Deny

Explicit deny must override allow.

---

### 64. Authorization Failures

Do not reveal cross-tenant resource existence.

Use 403 or 404 according policy.

---

### 65. Tenant Isolation Standard

Every request must resolve trusted tenant context.

---

### 66. Tenant Context Source

Allowed sources:

- authenticated membership;
- server-side selected tenant;
- trusted route context;
- signed token claim validated by server.

Not allowed as sole source:

- hidden input;
- query parameter;
- client-provided header without validation.

---

### 67. Scope Isolation

Scope may include:

```text
organization_id
clinic_id
department_id
module_code
```

---

### 68. Tenant Query Rule

Tenant-aware tables must be queried with tenant filter.

---

### 69. Tenant Insert Rule

Server sets tenant ID.

Client cannot arbitrarily choose tenant ID.

---

### 70. Tenant Update Rule

Update query includes tenant condition.

---

### 71. Tenant Delete Rule

Delete query includes tenant condition and audit.

---

### 72. Tenant Cache Rule

Cache key format:

```text
tenant:{tenant_id}:scope:{scope_id}:resource:{type}:{id}
```

---

### 73. Tenant File Rule

File metadata and storage reference must bind to tenant.

---

### 74. Tenant Queue Rule

Queue messages must include signed/trusted tenant context.

---

### 75. Tenant Search Rule

Search index and reporting must preserve tenant filters.

---

### 76. Tenant Export Rule

Export must:

- be tenant-scoped;
- be permission-checked;
- be auditable;
- expire;
- be encrypted for restricted data.

---

### 77. Session Security Standard

Use server-side session storage.

---

### 78. Session Cookie

```php
session_set_cookie_params([
    'secure' => true,
    'httponly' => true,
    'samesite' => 'Lax',
    'path' => '/',
]);
```

---

### 79. Session Rotation

```php
session_regenerate_id(true);
```

Required after:

- login;
- MFA;
- privilege elevation;
- sensitive authentication changes.

---

### 80. Session Expiry

Validate:

- idle timeout;
- absolute timeout;
- revoked status;
- permission version;
- identity status.

---

### 81. Session Data

Do not store:

- raw password;
- raw secret;
- large sensitive records;
- unrestricted object snapshots.

---

### 82. Remember-Me

Remember-me token must be:

- random;
- hashed at rest;
- revocable;
- rotated after use;
- device-aware;
- time-limited.

---

### 83. CSRF Standard

Required for cookie-authenticated state changes.

---

### 84. CSRF Token

Token must be:

- unpredictable;
- bound to session;
- validated server-side;
- rotated as policy requires.

---

### 85. CSRF Exemptions

Only for:

- stateless bearer-token APIs;
- signed webhooks;
- non-cookie machine clients.

---

### 86. HTTP Method Semantics

Use:

- GET for read-only;
- POST/PUT/PATCH/DELETE for state changes.

GET must not mutate state.

---

### 87. API Request Validation

Validate:

- content type;
- schema;
- size;
- field types;
- enums;
- nesting depth;
- unknown fields.

---

### 88. API Authentication

Use appropriate mechanism:

- session cookie;
- API key;
- signed token;
- mutual TLS;
- workload identity.

---

### 89. API Authorization

Scopes are not enough; resource-level checks still apply.

---

### 90. API Rate Limiting

Rate limits based on:

- identity;
- tenant;
- client;
- route;
- IP;
- risk.

---

### 91. API Idempotency

For retryable write APIs, use idempotency key.

---

### 92. API Replay Protection

For high-risk requests:

- timestamp;
- nonce;
- signature;
- idempotency;
- short token expiry.

---

### 93. API Versioning

Breaking change requires versioning and migration plan.

---

### 94. API Error Response

```json
{
  "error": {
    "code": "AUTHZ_PERMISSION_DENIED",
    "message": "Access denied."
  },
  "meta": {
    "request_id": "01J..."
  }
}
```

---

### 95. File Upload Standard

Flow:

```text
Receive
→ Size Check
→ MIME Check
→ Extension Check
→ Signature Check
→ Malware Scan
→ Randomize Name
→ Store Outside Public
→ Persist Metadata
```

---

### 96. File Size

Enforce at:

- web server;
- PHP;
- application.

---

### 97. MIME Detection

Use server-side MIME detection.

Do not trust browser-provided MIME.

---

### 98. Extension Allowlist

Allow only approved file types per feature.

---

### 99. File Signature

Validate magic bytes where appropriate.

---

### 100. Storage Name

Use generated opaque name.

---

### 101. Original Filename

Treat as metadata only.

Encode on display.

---

### 102. File Path

Never concatenate user input into filesystem paths.

---

### 103. File Download

Download requires:

- authentication;
- authorization;
- tenant/scope;
- classification;
- audit for sensitive files.

---

### 104. Path Traversal Protection

Reject:

```text
../
..\
absolute paths
null bytes
encoded traversal
```

---

### 105. Archive Security

Check:

- zip slip;
- nested archives;
- file count;
- decompressed size;
- compression ratio.

---

### 106. Image Upload

Re-encode images where appropriate and strip metadata if policy requires.

---

### 107. SSRF Prevention

Outbound requests must use:

- allowlisted schemes;
- allowlisted hosts;
- DNS/IP validation;
- blocked private ranges where applicable;
- timeout;
- response size limit;
- no arbitrary redirect chain.

---

### 108. SSRF Unsafe Input

Do not fetch arbitrary user-provided URLs directly.

---

### 109. Redirect Security

Redirect target must be:

- internal path; or
- allowlisted host.

---

### 110. Open Redirect Prevention

Bad:

```php
header('Location: ' . $_GET['next']);
```

Good:

```php
$target = RedirectPolicy::validateInternalPath(
    $request->query('next')
);
```

---

### 111. Command Execution

Avoid shell execution.

If unavoidable:

- fixed executable;
- fixed arguments;
- no shell interpolation;
- allowlisted input;
- isolated worker;
- timeout;
- audit.

---

### 112. Unsafe PHP Functions

High-risk:

```text
eval
assert with string
system
exec
shell_exec
passthru
proc_open
popen
unserialize on untrusted input
```

---

### 113. Serialization

Do not use PHP `unserialize()` on untrusted data.

Prefer JSON with strict schema.

---

### 114. Deserialization Depth

Limit nesting depth and payload size.

---

### 115. Template Injection

Do not allow user-controlled template names or template source.

---

### 116. Email Security

Validate email addresses.

Avoid header injection.

Use trusted mail library.

---

### 117. Webhook Security

Verify:

- signature;
- timestamp;
- replay window;
- content type;
- source if available;
- idempotency.

---

### 118. Cryptography Standard

Use approved services.

Do not write custom crypto primitives.

---

### 119. Encryption

Use authenticated encryption.

---

### 120. Nonce/IV

Must be unique according to algorithm requirements.

---

### 121. Key References

Store key ID/version, not raw key.

---

### 122. Hashing vs Encryption

Use hashing for verification.

Use encryption when plaintext must be recoverable.

---

### 123. Digital Signatures

Verify:

- algorithm;
- public key;
- signature;
- payload canonicalization;
- timestamp/expiry if applicable.

---

### 124. Randomness

Use:

```php
random_bytes()
random_int()
```

---

### 125. Secrets Standard

Secrets must come from approved runtime source.

---

### 126. Secret Access

Use narrow service interface.

---

### 127. Secret Redaction

Redact:

- exact secret;
- common encodings;
- token-like patterns;
- Authorization headers.

---

### 128. Secret Lifetime

Keep in memory only as long as needed.

---

### 129. Environment Variables

Environment variables may hold secret references or secrets depending deployment, but must be protected from logs and diagnostics.

---

### 130. Configuration Dumps

Never dump full production config.

---

### 131. Error Handling Standard

Domain errors map to stable error codes.

---

### 132. Exception Taxonomy

```text
ValidationException
AuthenticationException
AuthorizationException
ResourceNotFoundException
ConflictException
SecurityPolicyException
InfrastructureException
```

---

### 133. Global Error Handler

Responsibilities:

- generate request ID;
- map safe response;
- log structured details;
- redact secrets;
- classify severity;
- emit security event where relevant.

---

### 134. Error Message Rules

User-facing errors should be:

- clear;
- non-sensitive;
- stable;
- localized if needed.

---

### 135. Logging Standard

Structured logs should contain:

```text
timestamp
level
event_code
message
request_id
correlation_id
actor_id
tenant_id
scope_id
result
```

---

### 136. Log Redaction

Mandatory for:

- password;
- token;
- cookie;
- Authorization header;
- API key;
- secret;
- encryption key;
- restricted payload.

---

### 137. Security Event vs Application Log

Security events are explicit records for security-relevant actions.

Application logs are diagnostic.

Do not rely solely on debug logs for audit/security evidence.

---

### 138. Log Injection

Normalize or encode control characters from untrusted values.

---

### 139. PII/PHI Logging

Log only minimum identifiers.

Prefer internal references over full sensitive values.

---

### 140. Audit Logging

Audit:

- who;
- what;
- which resource;
- tenant/scope;
- when;
- result;
- reason;
- before/after where appropriate.

---

### 141. Cache Security

Cache must:

- include tenant/scope in key;
- avoid sensitive plaintext where possible;
- have TTL;
- invalidate on permission changes;
- restrict debug access.

---

### 142. Cache Poisoning

Validate all cache inputs and distinguish trusted/untrusted values.

---

### 143. Background Jobs

Jobs must:

- carry trusted tenant/scope;
- be idempotent;
- re-authorize if acting for user;
- avoid stale permission assumptions;
- log outcome;
- protect secrets.

---

### 144. Job Payloads

Do not include full sensitive records unless necessary.

Prefer references.

---

### 145. Queue Security

Protect:

- transport;
- credentials;
- message integrity;
- dead-letter queue;
- tenant isolation.

---

### 146. Concurrency Security

Use optimistic locking or transactions where concurrent updates can bypass rules.

---

### 147. Race Condition Examples

- duplicate approval;
- double payment;
- role assignment expiry race;
- one-time token reuse;
- inventory decrement;
- file state change.

---

### 148. One-Time Token Consumption

Consume atomically.

---

### 149. Idempotency

Use for:

- payment-like operations;
- exports;
- webhooks;
- integration commands;
- credential rotations.

---

### 150. Time-of-Check to Time-of-Use

Authorization-sensitive operations should minimize gap between check and execution.

---

### 151. Object References

Opaque IDs reduce enumeration but never replace authorization.

---

### 152. Data Export Security

Exports must:

- be scoped;
- be minimized;
- be encrypted if restricted;
- expire;
- be auditable;
- be revocable where possible.

---

### 153. CSV Injection

Prefix or neutralize cells beginning with:

```text
=
+
-
@
```

when exporting untrusted values.

---

### 154. PDF/Document Generation

Sanitize content and avoid remote resource loading from untrusted URLs.

---

### 155. Search Security

Search must:

- apply tenant/scope filters;
- bound result size;
- avoid leaking hidden records;
- respect classification.

---

### 156. Reporting Security

Reports must not bypass normal authorization.

---

### 157. Admin Interface Security

Admin interfaces require:

- MFA;
- short session;
- stricter rate limits;
- explicit permissions;
- full audit.

---

### 158. Debug Tools

Debug endpoints must be disabled in production.

---

### 159. Feature Flags

Security-critical feature flags require:

- owner;
- environment scope;
- expiry/review;
- audit;
- safe default.

---

### 160. Unsafe Default

Do not default to allow when configuration missing.

---

### 161. Dependency Usage

Before adding dependency:

- check maintenance;
- security history;
- license;
- transitive dependencies;
- package source;
- necessity.

---

### 162. Framework Bypass

Do not bypass shared kernel security services without architecture approval.

---

### 163. Secure Coding Checklist — PHP

- [ ] strict types;
- [ ] type-safe DTOs;
- [ ] no eval;
- [ ] no raw unserialize;
- [ ] no unsafe command execution;
- [ ] safe exceptions;
- [ ] approved crypto;
- [ ] secret-safe code;
- [ ] structured logs.

---

### 164. Secure Coding Checklist — HTML/JS

- [ ] output encoded;
- [ ] no unsafe HTML sinks;
- [ ] CSP compatible;
- [ ] no sensitive browser storage;
- [ ] no secret in JS;
- [ ] safe redirects;
- [ ] CORS restricted;
- [ ] client validation not trusted.

---

### 165. Secure Coding Checklist — SQL

- [ ] prepared statements;
- [ ] identifier allowlists;
- [ ] tenant filters;
- [ ] bounded pagination;
- [ ] safe transactions;
- [ ] no raw error exposure;
- [ ] migration reviewed.

---

### 166. Secure Coding Checklist — APIs

- [ ] authentication;
- [ ] authorization;
- [ ] schema validation;
- [ ] size limit;
- [ ] rate limit;
- [ ] idempotency;
- [ ] safe errors;
- [ ] versioning;
- [ ] audit for sensitive actions.

---

### 167. Secure Coding Checklist — Files

- [ ] size checked;
- [ ] MIME detected;
- [ ] extension allowlisted;
- [ ] signature checked;
- [ ] malware scanned;
- [ ] random storage name;
- [ ] outside public root;
- [ ] authorized download;
- [ ] tenant bound.

---

### 168. Pull Request Security Checklist

```text
[ ] Security requirements addressed
[ ] Threat model updated if needed
[ ] Input validation complete
[ ] Output encoding complete
[ ] Authorization server-side
[ ] Tenant/scope enforced
[ ] Prepared statements used
[ ] Secrets absent
[ ] Logs redacted
[ ] Security tests added
[ ] Migrations safe
[ ] Rollback considered
```

---

### 169. Review Severity

Reviewers should classify findings:

```text
BLOCKER
HIGH
MEDIUM
LOW
NOTE
```

---

### 170. Blocker Examples

- authentication bypass;
- cross-tenant exposure;
- SQL injection;
- hard-coded production secret;
- remote code execution;
- unrestricted file upload;
- privilege escalation.

---

### 171. Automated Lint Rules Direction

Automate detection for:

- `eval`;
- raw SQL concatenation;
- unsafe unserialize;
- direct `$_POST` use in domain code;
- unsafe redirects;
- secret patterns;
- missing tenant condition in known repositories;
- unsafe HTML output.

---

### 172. Code Review Evidence

Store:

- pull request;
- reviewers;
- findings;
- resolution;
- test results;
- approval;
- release linkage.

---

### 173. Security Regression Tests

Every verified security bug should create regression coverage where feasible.

---

### 174. UAT Part 2

#### PHP

- [ ] Strict types used.
- [ ] External input converted to DTOs.
- [ ] No eval or unsafe dynamic execution.
- [ ] Raw exceptions hidden.
- [ ] Secure random APIs used.
- [ ] Secret-safe logging implemented.

#### Input & Output

- [ ] Input schema validation works.
- [ ] Unknown critical fields rejected.
- [ ] Length/range/enum checks work.
- [ ] HTML output encoded.
- [ ] JSON generated safely.
- [ ] Rich text sanitized.
- [ ] XSS tests pass.

#### JavaScript

- [ ] Unsafe DOM sinks avoided.
- [ ] No secret in browser code.
- [ ] Client validation not trusted.
- [ ] Browser storage policy followed.
- [ ] CORS restricted.
- [ ] CSP-compatible implementation.

#### SQL & Database

- [ ] PDO prepared statements used.
- [ ] Dynamic identifiers allowlisted.
- [ ] Tenant filters present.
- [ ] Bulk queries bounded.
- [ ] Transactions used where needed.
- [ ] Raw DB errors hidden.
- [ ] Cross-tenant queries restricted.

#### Authentication & Sessions

- [ ] Generic authentication errors.
- [ ] Throttling works.
- [ ] Password reset tokens secure.
- [ ] MFA challenge secure.
- [ ] Session rotated after login/MFA.
- [ ] Idle/absolute expiry works.
- [ ] Session revocation works.
- [ ] Permission version invalidates stale sessions.

#### Authorization & Tenant Isolation

- [ ] No ad hoc role checks.
- [ ] Permission checks server-side.
- [ ] Resource-level policies applied.
- [ ] Tenant context trusted.
- [ ] Scope context validated.
- [ ] Cross-tenant access denied.
- [ ] Cache/file/queue isolation works.
- [ ] Export is tenant-scoped.

#### APIs

- [ ] Content type validated.
- [ ] Schema validated.
- [ ] Request size limited.
- [ ] Rate limit active.
- [ ] Idempotency works where required.
- [ ] Replay controls work where required.
- [ ] Errors are safe.
- [ ] Versioning rules followed.

#### Files

- [ ] Oversize upload rejected.
- [ ] MIME spoof rejected.
- [ ] Extension allowlist works.
- [ ] Malware handling works.
- [ ] Path traversal blocked.
- [ ] Restricted files are non-public.
- [ ] Authorized download works.
- [ ] Archive bomb controls work.

#### Cryptography & Secrets

- [ ] Approved crypto service used.
- [ ] Nonce/IV handling correct.
- [ ] Key references used.
- [ ] No custom crypto.
- [ ] Secret runtime injection works.
- [ ] Secret redaction works.
- [ ] Config dumps are safe.

#### Error Handling & Logging

- [ ] Stable error codes used.
- [ ] Global error handler works.
- [ ] Stack trace hidden in production.
- [ ] Security events distinct from debug logs.
- [ ] Log injection handled.
- [ ] PII/PHI minimized.
- [ ] Audit fields complete.

#### Concurrency & Jobs

- [ ] One-time tokens consumed atomically.
- [ ] Idempotency prevents duplicate actions.
- [ ] Background jobs carry trusted tenant context.
- [ ] Queue payloads minimize sensitive data.
- [ ] Race condition tests pass.

#### Code Review

- [ ] PR security checklist used.
- [ ] Blocker findings prevent merge.
- [ ] Security reviewer involved for high-risk changes.
- [ ] Review evidence retained.
- [ ] Regression tests added for security fixes.

---

### 175. Definition of Done Part 2

Part 2 dianggap selesai bila:

- [ ] PHP secure coding baseline tersedia;
- [ ] input validation standard tersedia;
- [ ] output encoding standard tersedia;
- [ ] JavaScript/DOM security tersedia;
- [ ] SQL/PDO standard tersedia;
- [ ] authentication coding standard tersedia;
- [ ] authorization coding standard tersedia;
- [ ] tenant/scope isolation standard tersedia;
- [ ] session security standard tersedia;
- [ ] CSRF standard tersedia;
- [ ] API security standard tersedia;
- [ ] file upload/download standard tersedia;
- [ ] SSRF/redirect protections tersedia;
- [ ] command execution rules tersedia;
- [ ] serialization rules tersedia;
- [ ] cryptography standard tersedia;
- [ ] secrets coding standard tersedia;
- [ ] error handling standard tersedia;
- [ ] logging/audit standard tersedia;
- [ ] cache security tersedia;
- [ ] background job/queue security tersedia;
- [ ] concurrency/idempotency standard tersedia;
- [ ] export/reporting security tersedia;
- [ ] admin/debug controls tersedia;
- [ ] dependency usage rules tersedia;
- [ ] PR/code review checklist tersedia;
- [ ] automated lint direction tersedia;
- [ ] UAT tersedia.

---

### 176. Rencana Part Berikutnya

#### Part 3

Security testing framework: SAST, DAST, dependency scanning, secret scanning, tenant isolation test suite, fuzzing, penetration testing, vulnerability triage, remediation SLA, evidence, dan reporting.

#### Part 4

CI/CD security pipelines, build integrity, artifact signing, SBOM, release gates, environment promotion, deployment security, rollback, infrastructure configuration, scheduler, APIs, database schema, dan sequence diagrams.

#### Part 5

Reference implementation, sample manifests, sample policies, pipeline examples, attack simulations, operational runbooks, final UAT, Definition of Done, roadmap, dan merge guidance menjadi `SSOT-SEC-02.md`.

---

## Bagian III — Security Testing Framework

### 1. Executive Summary

Part 3 mendefinisikan framework pengujian keamanan untuk Platform Kernel dan seluruh module bisnis.

Bagian ini menetapkan:

- security testing strategy;
- test ownership;
- test environments;
- SAST;
- dependency scanning;
- secret scanning;
- DAST;
- tenant isolation test suite;
- authorization testing;
- API security testing;
- file security testing;
- fuzzing;
- penetration testing;
- manual security review;
- vulnerability intake;
- triage;
- severity;
- remediation SLA;
- risk acceptance;
- verification;
- evidence;
- dashboards;
- reporting;
- UAT;
- Definition of Done.

Tujuan utamanya adalah memastikan vulnerability:

- ditemukan lebih awal;
- diklasifikasikan konsisten;
- memiliki owner;
- memiliki SLA;
- diverifikasi sebelum closure;
- memiliki evidence;
- dapat ditelusuri ke release dan component;
- tidak menjadi regression.

---

### 2. Security Testing Objectives

Security testing harus:

- menemukan insecure design;
- menemukan implementation weakness;
- menguji tenant isolation;
- memverifikasi authentication and authorization;
- menemukan secret leakage;
- mengidentifikasi vulnerable dependencies;
- menguji input/output handling;
- menguji file and API abuse cases;
- memvalidasi security controls;
- menghasilkan evidence untuk release gate.

---

### 3. Security Testing Principles

```text
Risk-Based
Layered
Automated Where Possible
Human Review Where Necessary
Repeatable
Reproducible
Evidence-Based
Tenant-Aware
Non-Destructive by Default
Verified Before Closure
```

---

### 4. Testing Layers

```text
Threat Model Review
Secure Code Review
Unit Security Tests
Integration Security Tests
Contract Tests
Tenant Isolation Tests
SAST
Dependency Scan
Secret Scan
DAST
Fuzzing
Manual Security Testing
Penetration Testing
Runtime Validation
```

---

### 5. Test Coverage Model

Security coverage harus dipetakan ke:

```text
security requirement
threat
control
test case
result
evidence
release
```

---

### 6. Test Risk Tiers

```text
TIER 1 — Standard
TIER 2 — Sensitive
TIER 3 — High Risk
TIER 4 — Critical
```

---

### 7. Tier 1

Contoh:

- non-sensitive CRUD;
- internal UI adjustment;
- documentation-only change.

Minimum:

- unit tests;
- standard code review;
- dependency and secret scan.

---

### 8. Tier 2

Contoh:

- new API endpoint;
- new form;
- scoped data access;
- report.

Minimum:

- unit/integration tests;
- SAST;
- dependency scan;
- tenant/scope checks;
- manual checklist.

---

### 9. Tier 3

Contoh:

- patient data;
- file upload;
- sensitive export;
- external integration;
- session logic.

Minimum:

- threat model;
- SAST;
- DAST;
- tenant isolation suite;
- manual security review;
- regression tests.

---

### 10. Tier 4

Contoh:

- authentication;
- authorization;
- privileged access;
- key/secrets;
- cross-tenant operations;
- audit integrity.

Minimum:

- formal threat model;
- advanced testing;
- penetration testing;
- dual review;
- release blocking gates;
- post-deployment validation.

---

### 11. Security Test Plan

Setiap high/critical feature wajib memiliki test plan.

Minimum fields:

```text
test_plan_id
feature_code
risk_tier
scope
environment
security_requirements
threats
test_types
owners
entry_criteria
exit_criteria
evidence
```

---

### 12. Test Case Template

```text
test_id
title
requirement_reference
threat_reference
preconditions
test_data
steps
expected_result
actual_result
status
evidence_reference
tester
executed_at
```

---

### 13. Test Status

```text
NOT_RUN
PASS
FAIL
BLOCKED
NOT_APPLICABLE
WAIVED
```

---

### 14. Test Environments

```text
LOCAL
CI
TEST
STAGING
PRE_PRODUCTION
PRODUCTION_VALIDATION
```

---

### 15. Environment Rules

Security testing tidak boleh:

- menggunakan production data tanpa approval;
- merusak shared environment;
- membuat uncontrolled external traffic;
- menonaktifkan audit;
- menyimpan real secrets dalam test fixtures.

---

### 16. Test Data

Prefer:

- synthetic data;
- masked data;
- generated identities;
- isolated tenant fixtures;
- deterministic setup.

---

### 17. Test Account Management

Test accounts harus:

- clearly identified;
- non-production;
- least privilege;
- time-bound where possible;
- removed after testing.

---

### 18. SAST

Static Application Security Testing menganalisis source code tanpa menjalankan aplikasi.

---

### 19. SAST Objectives

Detect:

- injection;
- insecure deserialization;
- hard-coded secrets;
- unsafe command execution;
- path traversal;
- weak cryptography;
- unsafe output;
- authorization omissions;
- risky APIs.

---

### 20. SAST Scope

Scan:

```text
PHP
JavaScript
HTML templates
SQL migrations
configuration
build scripts
CLI tools
```

---

### 21. SAST Pipeline Placement

```text
Local Optional
→ Pull Request Required
→ Main Branch Required
→ Release Required
```

---

### 22. SAST Severity

```text
INFO
LOW
MEDIUM
HIGH
CRITICAL
```

---

### 23. SAST Baseline

Existing findings dapat dibaseline sementara jika:

- inventoried;
- owner assigned;
- risk assessed;
- expiry set;
- new findings still blocked according policy.

---

### 24. SAST False Positive

False positive decision requires:

- reviewer;
- rationale;
- evidence;
- rule ID;
- expiry/review where appropriate.

---

### 25. SAST Custom Rules

Recommended custom rules:

- raw `$_GET`/`$_POST` use in domain code;
- SQL string concatenation;
- missing tenant condition in known repositories;
- direct file path concatenation;
- unsafe redirects;
- `eval`;
- `unserialize`;
- output without escaping;
- secret-like strings;
- ad hoc role checks.

---

### 26. SAST Release Rule

Block release for:

- confirmed critical;
- confirmed high in critical path;
- authentication bypass;
- SQL injection;
- cross-tenant exposure;
- RCE;
- hard-coded production secret.

---

### 27. Dependency Scanning

Dependency scanning mengidentifikasi known vulnerabilities pada package dan transitive dependencies.

---

### 28. Dependency Inventory

Minimum:

```text
package
version
direct_or_transitive
source
license
owner
environment
last_scanned_at
```

---

### 29. Dependency Sources

Scan:

- Composer dependencies;
- JavaScript packages;
- system packages if applicable;
- container images;
- build tools;
- test tools where material.

---

### 30. Dependency Finding Fields

```text
advisory_id
package
installed_version
affected_range
fixed_version
severity
cvss
exploitability
reachability
owner
status
```

---

### 31. Reachability

Reachability should refine priority but not automatically dismiss critical findings.

---

### 32. Dependency Pinning

Production dependencies must be pinned through lock files.

---

### 33. Abandoned Packages

Abandoned dependency requires:

- replacement plan;
- owner;
- risk assessment;
- timeline;
- exception if continued.

---

### 34. Dependency Update Verification

After update:

- unit tests;
- integration tests;
- regression tests;
- security tests;
- compatibility review;
- deployment monitoring.

---

### 35. Secret Scanning

Secret scanning mendeteksi credentials and secret material in code and artifacts.

---

### 36. Secret Scan Scope

Scan:

```text
working tree
commit history
pull requests
configuration
CI logs
build artifacts
container/image layers where applicable
```

---

### 37. Secret Patterns

Detect:

- API keys;
- database passwords;
- private keys;
- JWT signing keys;
- cloud credentials;
- webhook secrets;
- tokens;
- environment files.

---

### 38. Secret Detection Response

```text
Stop
→ Revoke
→ Rotate
→ Remove
→ Assess Exposure
→ Record Incident if Needed
→ Add Prevention
```

---

### 39. Secret Scan Release Rule

Confirmed active secret blocks release.

---

### 40. Secret Test Fixtures

Use obvious fake values and documented prefixes.

---

### 41. DAST

Dynamic Application Security Testing menguji aplikasi berjalan dari luar.

---

### 42. DAST Objectives

Detect:

- reflected/stored XSS;
- injection;
- insecure headers;
- authentication weaknesses;
- authorization issues;
- open redirects;
- file upload weaknesses;
- session problems;
- exposed debug endpoints.

---

### 43. DAST Scope

Prioritize:

- public endpoints;
- authentication;
- sensitive APIs;
- admin routes;
- file upload;
- exports;
- integration callbacks.

---

### 44. DAST Authentication

Authenticated DAST should use dedicated test accounts and isolated data.

---

### 45. DAST Safety

DAST configuration must:

- avoid destructive payloads by default;
- limit concurrency;
- limit request rate;
- exclude external integrations unless approved;
- preserve logs;
- identify scan traffic.

---

### 46. DAST Baseline

Known low-risk findings may be baselined with approval.

Critical findings cannot be silently baselined.

---

### 47. DAST Verification

Confirmed findings should be manually verified before escalation where feasible.

---

### 48. Tenant Isolation Test Suite

Tenant isolation is a mandatory security test domain.

---

### 49. Tenant Test Fixture

Create at minimum:

```text
Tenant A
Tenant B
Clinic A1
Clinic A2
Clinic B1
Users with scoped roles
Resources in each scope
```

---

### 50. Cross-Tenant Read Test

User Tenant A requests Tenant B resource.

Expected:

- denied;
- no resource existence leak;
- event recorded.

---

### 51. Cross-Tenant List Test

Tenant A list/search must never include Tenant B records.

---

### 52. Cross-Tenant Update Test

Foreign resource update must affect zero rows and return safe denial.

---

### 53. Cross-Tenant Delete Test

Delete must be denied and audited.

---

### 54. Cross-Tenant Create Test

Client cannot create resource under unauthorized tenant.

---

### 55. Cross-Clinic Test

User in Clinic A1 cannot access Clinic A2 unless explicitly assigned.

---

### 56. Tenant Cache Test

Cache entry from Tenant A must not be returned to Tenant B.

---

### 57. Tenant File Test

Tenant A cannot download Tenant B file even with valid file ID.

---

### 58. Tenant Export Test

Export includes only authorized tenant/scope data.

---

### 59. Tenant Queue Test

Background worker must preserve tenant context and reject malformed context.

---

### 60. Tenant Reporting Test

Reports and aggregates must not include foreign tenant data.

---

### 61. Tenant Search Index Test

Search index queries must be tenant-filtered.

---

### 62. Tenant Test Automation

Tests should run:

- on pull request for affected modules;
- nightly full suite;
- before production release;
- after tenant isolation incident.

---

### 63. Authorization Testing

Authorization tests must cover:

- no permission;
- correct permission;
- expired assignment;
- wrong scope;
- explicit deny;
- resource ownership;
- privileged action;
- cross-tenant path.

---

### 64. IDOR/BOLA Testing

Attempt access by modifying object IDs.

Expected: resource-level authorization denies unauthorized access.

---

### 65. Function-Level Authorization

Test direct access to hidden/admin endpoints without UI navigation.

---

### 66. Mass Assignment Testing

Attempt to submit fields such as:

```text
tenant_id
role
is_admin
owner_id
status
approved_by
```

Server must ignore/reject unauthorized fields.

---

### 67. Authentication Testing

Cover:

- valid login;
- invalid login;
- enumeration;
- brute force;
- lockout;
- MFA bypass;
- reset token reuse;
- expired token;
- session fixation;
- logout revocation.

---

### 68. Session Testing

Cover:

- cookie attributes;
- rotation;
- idle timeout;
- absolute timeout;
- concurrent sessions;
- privilege elevation;
- permission version invalidation.

---

### 69. CSRF Testing

State-changing cookie-authenticated endpoints must reject:

- missing token;
- invalid token;
- token from other session;
- cross-origin submission.

---

### 70. API Security Testing

Cover:

- content type;
- schema validation;
- size limits;
- authentication;
- authorization;
- rate limits;
- idempotency;
- replay;
- safe error response.

---

### 71. API Abuse Tests

Examples:

- oversized JSON;
- deep nesting;
- duplicate keys;
- unknown fields;
- invalid enum;
- negative values;
- malformed identifiers;
- repeated idempotency keys.

---

### 72. File Security Testing

Cover:

- oversize;
- MIME spoof;
- extension mismatch;
- double extension;
- path traversal;
- archive bomb;
- malware signature;
- unauthorized download;
- legal hold deletion.

---

### 73. SSRF Testing

Attempt:

- localhost;
- private IP;
- metadata endpoint;
- alternate IP encodings;
- redirects;
- DNS rebinding patterns where feasible.

---

### 74. Redirect Testing

Test external and protocol-relative redirect targets.

---

### 75. Injection Testing

Cover:

- SQL;
- HTML/JS;
- command;
- template;
- LDAP where applicable;
- header injection;
- log injection.

---

### 76. Fuzzing

Fuzzing supplies malformed or unexpected input to find crashes, bypasses, and parser weaknesses.

---

### 77. Fuzzing Targets

Recommended:

- API parsers;
- importers;
- file metadata parsers;
- webhook handlers;
- date/identifier parsers;
- search filters;
- serialization boundaries.

---

### 78. Fuzzing Input Classes

```text
empty
null
very long
deeply nested
invalid UTF-8
boundary values
duplicate fields
unexpected types
special characters
control characters
```

---

### 79. Fuzzing Safety

Use isolated environments and bounded resource consumption.

---

### 80. Fuzzing Success Criteria

Application should:

- reject safely;
- avoid crash;
- avoid resource exhaustion;
- avoid sensitive error leakage;
- preserve integrity.

---

### 81. Manual Security Testing

Manual testing is required when automated tools cannot adequately validate business logic.

---

### 82. Manual Review Focus

- authorization;
- tenant isolation;
- workflow abuse;
- race conditions;
- privilege escalation;
- data export;
- approval bypass;
- sensitive state transitions.

---

### 83. Business Logic Abuse

Examples:

- approving own request;
- reusing expired approval;
- bypassing workflow sequence;
- modifying hidden status;
- duplicate processing;
- partial rollback abuse.

---

### 84. Race Condition Testing

Test:

- duplicate approval;
- one-time token reuse;
- role assignment;
- export generation;
- payment-like workflow;
- file state changes.

---

### 85. Penetration Testing

Penetration testing simulates realistic attacker behavior under approved scope.

---

### 86. Penetration Test Triggers

Recommended:

- initial production launch;
- major architecture change;
- critical authentication/authorization change;
- new internet-facing API;
- after severe incident;
- periodic critical system review.

---

### 87. Penetration Test Scope

Define:

```text
targets
environments
accounts
allowed techniques
excluded systems
time window
contacts
data handling
stop conditions
```

---

### 88. Rules of Engagement

Must define:

- authorization;
- safe hours;
- notification path;
- destructive test restrictions;
- evidence handling;
- emergency stop;
- reporting deadline.

---

### 89. Penetration Test Findings

Each finding must contain:

- title;
- severity;
- affected component;
- reproduction;
- impact;
- evidence;
- remediation;
- owner;
- status.

---

### 90. Retest

Critical/high findings require retest before closure.

---

### 91. Vulnerability Intake

Sources:

```text
SAST
DAST
Dependency Scan
Secret Scan
Penetration Test
Manual Review
Bug Report
Incident
Vendor Advisory
External Researcher
```

---

### 92. Vulnerability Normalization

Normalize:

- title;
- type;
- component;
- version;
- environment;
- tenant impact;
- severity;
- exploitability;
- evidence.

---

### 93. Deduplication

Deduplicate using:

- advisory ID;
- component;
- vulnerable path;
- root cause;
- environment;
- version.

---

### 94. Vulnerability Severity Model

Consider:

```text
technical severity
exploitability
exposure
data sensitivity
privilege required
tenant blast radius
business impact
detectability
```

---

### 95. Severity Levels

```text
CRITICAL
HIGH
MEDIUM
LOW
INFORMATIONAL
```

---

### 96. Critical Examples

- remote code execution;
- authentication bypass;
- unrestricted cross-tenant exposure;
- active secret compromise;
- critical key compromise;
- SQL injection on sensitive data;
- admin privilege escalation.

---

### 97. High Examples

- stored XSS in privileged interface;
- limited cross-scope exposure;
- sensitive IDOR;
- SSRF with internal access;
- critical dependency in reachable path.

---

### 98. Medium Examples

- missing security headers;
- constrained reflected XSS;
- information disclosure;
- weak rate limits;
- moderate dependency issue.

---

### 99. Low Examples

- minor information leak;
- low-impact misconfiguration;
- defense-in-depth issue.

---

### 100. Vulnerability States

```text
NEW
TRIAGED
ASSIGNED
IN_PROGRESS
REMEDIATED
VERIFICATION_PENDING
VERIFIED
RISK_ACCEPTED
FALSE_POSITIVE
CLOSED
```

---

### 101. Triage SLA

Recommended:

| Severity | Triage |
|---|---:|
| Critical | 4 hours |
| High | 1 business day |
| Medium | 3 business days |
| Low | 10 business days |

---

### 102. Remediation SLA

Initial recommendation:

| Severity | Remediation |
|---|---:|
| Critical | 24–72 hours |
| High | 7–14 days |
| Medium | 30–60 days |
| Low | 90–180 days |

Adjust based on exposure and exploitability.

---

### 103. Emergency Remediation

For actively exploited critical issue:

- contain immediately;
- disable feature if needed;
- revoke credentials;
- rotate secrets;
- patch;
- verify;
- monitor.

---

### 104. Vulnerability Ownership

Every finding must have:

- engineering owner;
- security reviewer;
- target date;
- affected release/component.

---

### 105. Risk Acceptance

Risk acceptance must include:

```text
finding
scope
reason
residual risk
compensating control
owner
approver
expires_at
review_date
```

---

### 106. Risk Acceptance Restrictions

Cannot be:

- indefinite;
- ownerless;
- without compensating control;
- silently renewed;
- used to hide active exploitation.

---

### 107. False Positive Closure

Requires:

- rationale;
- evidence;
- reviewer;
- rule/tool reference;
- review date if uncertain.

---

### 108. Remediation Verification

Verification must confirm:

- code/config fixed;
- deployed version;
- exploit no longer works;
- no regression;
- evidence stored.

---

### 109. Security Regression Test

Every verified critical/high application vulnerability should produce a regression test where feasible.

---

### 110. Evidence Architecture

```text
Test Execution
→ Result
→ Artifact
→ Checksum
→ Metadata
→ Secure Storage
→ Release Link
```

---

### 111. Evidence Types

```text
SAST_REPORT
DAST_REPORT
DEPENDENCY_REPORT
SECRET_SCAN_REPORT
TENANT_TEST_RESULT
PENETRATION_REPORT
MANUAL_TEST_RESULT
RETEST_RESULT
RISK_ACCEPTANCE
RELEASE_SECURITY_APPROVAL
```

---

### 112. Evidence Metadata

```text
evidence_id
test_type
tool
tool_version
scope
commit
build
release
environment
result
checksum
classification
owner
created_at
valid_until
```

---

### 113. Evidence Integrity

Reports should have checksum and controlled storage.

---

### 114. Evidence Access

Access based on:

- classification;
- project/module;
- tenant if applicable;
- role;
- purpose.

---

### 115. Evidence Retention

Retain according to:

- release policy;
- compliance needs;
- vulnerability lifecycle;
- incident/legal hold.

---

### 116. Security Test Report

Minimum sections:

```text
Executive Summary
Scope
Methodology
Environment
Test Results
Findings
Risk Summary
Exceptions
Release Recommendation
Evidence References
```

---

### 117. Release Recommendation

```text
APPROVE
APPROVE_WITH_CONDITIONS
REJECT
```

---

### 118. Security Dashboard Metrics

```text
tests_executed_total
security_test_pass_ratio
sast_findings_total
dast_findings_total
dependency_vulnerabilities_total
secret_findings_total
tenant_isolation_failures_total
critical_findings_open_total
high_findings_overdue_total
mean_time_to_triage
mean_time_to_remediate
retest_pass_ratio
```

---

### 119. Dashboard Views

Recommended:

- by severity;
- by module;
- by owner;
- by age;
- by environment;
- by release;
- by test type;
- by tenant impact.

---

### 120. Trend Analysis

Track:

- recurring root causes;
- repeated modules;
- false-positive rates;
- scan coverage;
- remediation speed;
- regression rate.

---

### 121. Root Cause Categories

```text
INSECURE_DESIGN
MISSING_AUTHORIZATION
MISSING_TENANT_FILTER
INPUT_VALIDATION
OUTPUT_ENCODING
SECRET_HANDLING
DEPENDENCY
MISCONFIGURATION
TEST_GAP
PROCESS_GAP
```

---

### 122. Quality Gates

Security testing gates:

```text
Pull Request Gate
Main Branch Gate
Release Candidate Gate
Production Promotion Gate
Post-Deployment Validation Gate
```

---

### 123. Pull Request Gate

Required:

- unit tests;
- SAST;
- secret scan;
- dependency scan;
- affected tenant tests.

---

### 124. Main Branch Gate

Required:

- full integration;
- broader SAST;
- dependency report;
- security regression suite.

---

### 125. Release Candidate Gate

Required:

- DAST;
- full tenant isolation suite;
- unresolved finding review;
- release evidence package.

---

### 126. Production Promotion Gate

Block if:

- critical open;
- tenant isolation failed;
- active secret exposed;
- required evidence missing;
- risk acceptance expired.

---

### 127. Post-Deployment Validation Gate

Validate:

- security headers;
- authentication;
- authorization;
- tenant isolation;
- file protection;
- audit/security events.

---

### 128. Test Automation Architecture

```text
Source Change
→ CI Trigger
→ Security Scanners
→ Test Suites
→ Normalize Findings
→ Policy Evaluation
→ Evidence Store
→ Gate Decision
```

---

### 129. Scanner Isolation

Scanners should run with:

- least privilege;
- isolated credentials;
- limited network access;
- no production secrets;
- auditable execution.

---

### 130. Tool Failure

Tool failure must not be silently treated as PASS.

Possible result:

```text
UNKNOWN
```

Critical gates should fail closed when required scanner is unavailable.

---

### 131. Test Flakiness

Flaky security tests must:

- be tracked;
- have owner;
- not be permanently ignored;
- be stabilized;
- not silently bypass release policy.

---

### 132. Manual Override

Override requires:

- reason;
- owner;
- approver;
- evidence;
- expiry;
- audit.

---

### 133. Security Test Data Cleanup

After test:

- remove temporary accounts;
- revoke credentials;
- delete test exports;
- clean uploaded files;
- preserve only required evidence.

---

### 134. Researcher Reports

External reports should follow coordinated intake.

Minimum:

- acknowledgment;
- triage;
- safe communication;
- remediation;
- closure.

---

### 135. Security Test Ownership

```text
AppSec
QA
Engineering
DevOps
Security Operations
Module Owner
```

---

### 136. RACI

| Activity | AppSec | QA | Engineering | DevOps | Module Owner |
|---|---|---|---|---|---|
| Test strategy | A/R | C | C | C | I |
| Unit/integration security tests | C | C | R | I | A |
| SAST/dependency/secret scans | A | I | C | R | I |
| DAST | R | C | C | C | I |
| Tenant isolation suite | C | R | R | C | A |
| Penetration testing | A/R | I | C | C | I |
| Remediation | C | C | R | C | A |
| Verification | R | C | C | I | A |

---

### 137. UAT Part 3

#### Strategy & Planning

- [ ] Security testing layers defined.
- [ ] Risk tiers defined.
- [ ] Test plan template available.
- [ ] Test case template available.
- [ ] Environment rules defined.
- [ ] Synthetic/masked data used.
- [ ] Test account lifecycle controlled.

#### SAST

- [ ] PHP/JS/config scanned.
- [ ] PR scan active.
- [ ] Main/release scans active.
- [ ] Custom rules identified.
- [ ] False-positive process exists.
- [ ] Critical findings block release.
- [ ] Baseline is controlled.

#### Dependency Scanning

- [ ] Composer dependencies scanned.
- [ ] Transitive dependencies included.
- [ ] Lock files enforced.
- [ ] Abandoned packages identified.
- [ ] Fixed versions reported.
- [ ] Reachability considered.
- [ ] Critical advisories escalated.

#### Secret Scanning

- [ ] Working tree scanned.
- [ ] Commit history/PR scanned.
- [ ] Build artifacts scanned where applicable.
- [ ] Active secret blocks release.
- [ ] Revoke/rotate process works.
- [ ] Fake fixtures do not trigger uncontrolled noise.

#### DAST

- [ ] Public/sensitive endpoints covered.
- [ ] Authenticated scan accounts exist.
- [ ] Safe scan profile configured.
- [ ] Findings manually verified.
- [ ] Critical findings block release.
- [ ] Scan traffic identifiable.

#### Tenant Isolation

- [ ] Cross-tenant read denied.
- [ ] Cross-tenant list clean.
- [ ] Cross-tenant update denied.
- [ ] Cross-tenant delete denied.
- [ ] Cross-clinic access denied.
- [ ] Cache isolation passes.
- [ ] File isolation passes.
- [ ] Queue/report/search isolation passes.
- [ ] Full suite runs before release.

#### Authentication & Authorization

- [ ] Enumeration tests pass.
- [ ] Brute-force controls pass.
- [ ] MFA bypass tests fail safely.
- [ ] Session fixation prevented.
- [ ] IDOR/BOLA tests pass.
- [ ] Function-level authorization passes.
- [ ] Mass assignment tests pass.
- [ ] Expired assignment denied.

#### API & File Security

- [ ] Schema abuse tests pass.
- [ ] Size limits enforced.
- [ ] Idempotency/replay tests pass.
- [ ] MIME spoof rejected.
- [ ] Path traversal blocked.
- [ ] Archive bomb controls pass.
- [ ] Unauthorized download denied.
- [ ] SSRF tests blocked.

#### Fuzzing & Manual Testing

- [ ] Parser targets identified.
- [ ] Boundary cases covered.
- [ ] Resource limits enforced.
- [ ] Business logic abuse tested.
- [ ] Race conditions tested.
- [ ] Manual results recorded.

#### Penetration Testing

- [ ] Trigger criteria defined.
- [ ] Rules of engagement defined.
- [ ] Scope approved.
- [ ] Evidence handling defined.
- [ ] Critical/high findings retested.
- [ ] Final report stored securely.

#### Vulnerability Management

- [ ] Findings normalized.
- [ ] Deduplication works.
- [ ] Severity model applied.
- [ ] Triage SLA applied.
- [ ] Remediation SLA applied.
- [ ] Owner assigned.
- [ ] Risk acceptance time-bound.
- [ ] False positive reviewed.
- [ ] Verification required before closure.
- [ ] Regression tests added where feasible.

#### Evidence & Reporting

- [ ] Evidence metadata complete.
- [ ] Checksums available.
- [ ] Release linkage available.
- [ ] Reports classified.
- [ ] Retention defined.
- [ ] Dashboard metrics available.
- [ ] Gate decisions reproducible.
- [ ] Tool failure not treated as PASS.

---

### 138. Definition of Done Part 3

Part 3 dianggap selesai bila:

- [ ] security testing objectives tersedia;
- [ ] testing layers tersedia;
- [ ] risk tiers tersedia;
- [ ] test plan and case templates tersedia;
- [ ] environment/data rules tersedia;
- [ ] SAST standard tersedia;
- [ ] dependency scanning standard tersedia;
- [ ] secret scanning standard tersedia;
- [ ] DAST standard tersedia;
- [ ] tenant isolation suite tersedia;
- [ ] authentication/authorization tests tersedia;
- [ ] API/file/SSRF tests tersedia;
- [ ] fuzzing standard tersedia;
- [ ] manual security testing tersedia;
- [ ] penetration testing standard tersedia;
- [ ] vulnerability intake/normalization tersedia;
- [ ] severity model tersedia;
- [ ] triage/remediation SLA tersedia;
- [ ] risk acceptance tersedia;
- [ ] verification/regression process tersedia;
- [ ] evidence architecture tersedia;
- [ ] reporting/dashboard metrics tersedia;
- [ ] CI/CD test gates tersedia;
- [ ] tool failure/override policy tersedia;
- [ ] ownership/RACI tersedia;
- [ ] UAT tersedia.

---

### 139. Rencana Part Berikutnya

#### Part 4

CI/CD security pipelines, build integrity, artifact signing, SBOM, release gates, environment promotion, deployment security, rollback, infrastructure configuration, scheduler, APIs, database schema, dan sequence diagrams.

#### Part 5

Reference implementation, sample manifests, sample policies, pipeline examples, attack simulations, operational runbooks, final UAT, Definition of Done, roadmap, dan merge guidance menjadi `SSOT-SEC-02.md`.

---

## Bagian IV — Secure Delivery & Release Assurance

### 1. Executive Summary

Part 4 mendefinisikan secure delivery pipeline untuk Platform Kernel dan seluruh module bisnis.

Bagian ini menetapkan:

- source control security;
- branch protection;
- CI runner security;
- pipeline security;
- build integrity;
- dependency and lockfile verification;
- secret scanning;
- SAST;
- dependency scanning;
- test gates;
- tenant isolation gates;
- artifact generation;
- checksum;
- artifact signing;
- provenance;
- SBOM;
- release gates;
- environment promotion;
- deployment security;
- migration security;
- configuration validation;
- rollback;
- scheduler;
- security release APIs;
- database schema;
- audit;
- metrics;
- sequence diagrams;
- UAT;
- Definition of Done.

Tujuan utamanya adalah memastikan software yang dipromosikan ke production:

- berasal dari source yang disetujui;
- dibangun melalui pipeline yang terkendali;
- memiliki dependency dan provenance yang dapat ditelusuri;
- telah melewati security gates;
- tidak membawa secret;
- memiliki artifact integrity;
- memiliki SBOM;
- dapat dirollback;
- memiliki evidence dan audit.

---

### 2. Secure Delivery Architecture

```text
Source Commit
    │
    ▼
Source Control Protections
    │
    ├── Branch Protection
    ├── Review
    ├── Signed Commit Optional
    └── Secret Scan
    │
    ▼
CI Security Pipeline
    │
    ├── Dependency Restore
    ├── Lockfile Verify
    ├── SAST
    ├── Dependency Scan
    ├── Unit Tests
    ├── Integration Tests
    ├── Tenant Isolation Tests
    ├── Build
    ├── SBOM
    ├── Artifact Hash
    └── Artifact Signature
    │
    ▼
Release Gate
    │
    ├── Security Policy
    ├── Finding Review
    ├── Evidence Check
    ├── Approval
    └── Promotion Decision
    │
    ▼
Deployment
    │
    ├── Config Validation
    ├── Migration
    ├── Artifact Verification
    ├── Health Check
    ├── Security Validation
    └── Rollback
```

---

### 3. Secure Delivery Principles

```text
Build Once, Promote Many
No Manual Artifact Mutation
Immutable Release Artifacts
Protected Source
Least-Privilege CI
No Production Secrets in Build
Evidence-Based Gates
Reproducible Builds Where Feasible
Traceable Provenance
Fail Closed for Critical Controls
```

---

### 4. Build Once, Promote Many

Artifact yang sama harus dipromosikan antar environment.

Tidak boleh rebuild dengan source yang sama tetapi dependency atau configuration berbeda tanpa release baru.

---

### 5. Immutable Artifact

Setelah artifact ditandatangani dan dipublikasikan:

- tidak boleh diubah;
- checksum harus tetap sama;
- metadata harus immutable;
- replacement membutuhkan version baru.

---

### 6. Source Control Security

Source repository wajib:

- private where appropriate;
- require authenticated access;
- restrict admin privileges;
- maintain audit history;
- use protected branches;
- require review.

---

### 7. Branch Protection

Recommended:

```text
Pull request required
Minimum reviewer count
Status checks required
Force push disabled
Branch deletion restricted
Direct push to main disabled
Stale approval dismissal
Code owner review for sensitive paths
```

---

### 8. Sensitive Paths

Examples:

```text
app/Platform/Security/
app/Platform/Kernel/
config/security*.php
database/migrations/
public/.htaccess
composer.json
composer.lock
ci/
deployment/
```

---

### 9. CODEOWNERS Direction

Sensitive paths should require designated reviewers.

---

### 10. Commit Traceability

Each release must trace to:

```text
repository
branch
commit_sha
pull_request
reviewers
build_id
artifact_id
release_id
```

---

### 11. Signed Commits

Optional but recommended for critical repositories.

If used, signing verification must be automated.

---

### 12. CI Runner Security

CI runners must:

- use least privilege;
- isolate jobs;
- avoid persistent secrets;
- clean workspace;
- restrict network access where possible;
- rotate credentials;
- log activity.

---

### 13. Shared Runner Risk

Shared runners require:

- stronger isolation;
- no long-lived production secrets;
- ephemeral workspaces;
- artifact access restrictions;
- cache segregation.

---

### 14. Self-Hosted Runner

Self-hosted runner must:

- be patched;
- dedicated by trust level;
- not run arbitrary untrusted code with production access;
- use short-lived credentials;
- have monitoring.

---

### 15. CI Credentials

Use:

- short-lived tokens;
- environment-scoped secrets;
- least privilege;
- masked output;
- rotation;
- revocation.

---

### 16. CI Secret Exposure Prevention

Do not:

- echo secrets;
- pass secrets in command-line arguments if visible;
- store secrets in artifacts;
- expose full environment dump;
- allow untrusted pull requests access to protected secrets.

---

### 17. Pull Request from Forks

Untrusted contributions must not receive protected secrets.

---

### 18. Pipeline Stages

```text
SOURCE
VALIDATE
SCAN
TEST
BUILD
PACKAGE
ATTEST
PUBLISH
PROMOTE
DEPLOY
VERIFY
```

---

### 19. Source Stage

Checks:

- commit exists;
- branch trusted;
- review complete;
- required signatures;
- no forbidden files;
- source checksum.

---

### 20. Validate Stage

Checks:

- syntax;
- config schema;
- migration syntax;
- manifests;
- module security manifest;
- dependency lockfile consistency.

---

### 21. Scan Stage

Runs:

- secret scan;
- SAST;
- dependency scan;
- license scan optional;
- infrastructure/config scan;
- malware scan for bundled assets if required.

---

### 22. Test Stage

Runs:

- unit tests;
- integration tests;
- contract tests;
- tenant isolation tests;
- security regression tests;
- migration tests;
- rollback tests where feasible.

---

### 23. Build Stage

Build must be deterministic as feasible and use pinned dependencies.

---

### 24. Package Stage

Package includes only required runtime files.

Exclude:

- `.git`;
- test fixtures;
- local secrets;
- logs;
- backups;
- development configuration;
- temporary files.

---

### 25. Attest Stage

Generate:

- checksum;
- provenance;
- SBOM;
- signature;
- test summary;
- security gate result.

---

### 26. Publish Stage

Artifact repository must:

- enforce access control;
- preserve immutability;
- record publisher;
- retain checksum and signature;
- support versioning.

---

### 27. Promote Stage

Promotion changes environment state, not artifact content.

---

### 28. Deploy Stage

Deployment must verify:

- artifact checksum;
- signature;
- version;
- environment eligibility;
- approvals;
- configuration;
- migration plan.

---

### 29. Verify Stage

Post-deployment checks:

- health;
- readiness;
- authentication;
- authorization;
- tenant isolation;
- security headers;
- audit/events;
- critical business path.

---

### 30. Pipeline Status

```text
PENDING
RUNNING
PASSED
FAILED
CANCELLED
BLOCKED
OVERRIDDEN
```

---

### 31. Security Gate Result

```text
PASS
WARN
FAIL
PASS_WITH_EXCEPTION
UNKNOWN
```

---

### 32. Critical Gate Behavior

Critical gate failure must block release.

Examples:

- secret detected;
- critical vulnerability;
- tenant isolation test failure;
- artifact signature invalid;
- required evidence missing;
- migration integrity failure.

---

### 33. Tool Unavailability

Required security tool unavailable must produce:

```text
UNKNOWN
```

For critical gates, UNKNOWN should fail closed unless approved exception exists.

---

### 34. Pipeline Caching

Cache must:

- be keyed by dependency lock and environment;
- avoid secrets;
- be isolated by repository/trust level;
- be invalidated safely;
- not bypass scanning.

---

### 35. Dependency Restore

Use lock files.

For PHP:

```text
composer.lock
```

Install should prefer:

```bash
composer install --no-interaction --no-dev --prefer-dist --classmap-authoritative
```

for production packaging where appropriate.

---

### 36. Lockfile Verification

Pipeline must detect:

- manifest changed without lockfile;
- lockfile mismatch;
- untrusted registry;
- unpinned dependency.

---

### 37. Composer Security

Recommended:

- trusted Packagist/registry;
- audit;
- plugin allowlist;
- no script execution from untrusted package;
- lock file committed.

---

### 38. Composer Plugin Control

Only approved plugins may execute during install.

---

### 39. Build Environment

Build environment must be versioned.

Track:

```text
PHP version
Composer version
OS/image
Build tool versions
Scanner versions
```

---

### 40. Reproducible Build Direction

Record sufficient metadata to rebuild:

- commit;
- dependency lock;
- tool versions;
- build configuration;
- environment image.

---

### 41. Artifact Contents

Recommended runtime package:

```text
app/
config/
public/
resources/runtime/
vendor/
database/migrations/
bin/
composer.lock
release-manifest.json
sbom.json
checksums.txt
signature/
```

---

### 42. Release Manifest

```json
{
  "release_id": "REL-2026-07-001",
  "version": "1.8.0",
  "commit_sha": "abc123...",
  "build_id": "BUILD-901",
  "artifact_sha256": "...",
  "sbom_sha256": "...",
  "built_at": "2026-07-05T12:00:00Z",
  "security_gate": "PASS"
}
```

---

### 43. Artifact Checksum

Minimum:

```text
SHA-256
```

---

### 44. Artifact Signing

Signing verifies artifact origin and integrity.

---

### 45. Signing Key Security

Signing key must:

- be restricted;
- not available to untrusted PR jobs;
- be environment/trust scoped;
- be rotated;
- be auditable.

---

### 46. Signature Verification

Required before:

- publishing release;
- promoting environment;
- production deployment;
- rollback deployment.

---

### 47. Signature Failure

Must block deployment and create security alert.

---

### 48. Provenance

Provenance should record:

```text
source repository
commit
builder identity
pipeline
build environment
inputs
outputs
timestamp
```

---

### 49. SBOM

Software Bill of Materials must list software components in the release.

---

### 50. SBOM Fields

Minimum:

```text
component name
version
supplier/source
dependency type
license
hash where available
```

---

### 51. SBOM Formats

Use standard machine-readable format where feasible.

Examples:

```text
CycloneDX
SPDX
```

---

### 52. SBOM Generation

Generate from final artifact/dependency lock, not only source manifest.

---

### 53. SBOM Validation

Validate:

- parseable;
- contains direct dependencies;
- contains transitive dependencies where supported;
- matches release;
- checksum recorded.

---

### 54. SBOM Retention

Retain per release.

---

### 55. Vulnerability Correlation

SBOM should support matching newly disclosed vulnerabilities to deployed releases.

---

### 56. Release Evidence Package

Include:

```text
release manifest
source reference
review evidence
test summary
SAST report
dependency report
secret scan result
tenant isolation result
SBOM
artifact checksum
artifact signature
approval
migration plan
rollback plan
```

---

### 57. Release Gate Architecture

```text
Evidence Collection
→ Policy Evaluation
→ Finding Review
→ Exception Validation
→ Approval
→ Promotion Token
```

---

### 58. Release Gate Inputs

```text
release
artifact
environment
risk tier
findings
test results
exceptions
approvals
deployment window
```

---

### 59. Release Gate Policies

Examples:

```text
No critical open findings
No expired security exception
Tenant isolation suite passed
Artifact signature valid
SBOM present
Rollback plan present
Production approval present
```

---

### 60. Release Decision

```text
APPROVED
APPROVED_WITH_CONDITIONS
REJECTED
EXPIRED
REVOKED
```

---

### 61. Conditional Approval

Conditions must have:

- owner;
- due date;
- verification;
- consequence if unmet.

---

### 62. Release Approval Segregation

Critical releases should avoid sole self-approval.

---

### 63. Promotion Model

```text
DEV
→ TEST
→ STAGING
→ PRE_PRODUCTION
→ PRODUCTION
```

---

### 64. Environment Promotion

Promotion requires:

- source environment success;
- artifact unchanged;
- target configuration validated;
- target approval;
- no expired exceptions;
- signature valid.

---

### 65. Environment-Specific Configuration

Config may differ, artifact may not.

---

### 66. Promotion Token

A promotion token/reference should bind:

```text
release_id
artifact_hash
source_environment
target_environment
approved_by
expires_at
```

---

### 67. Production Change Window

Production deployment may require:

- approved window;
- on-call availability;
- backup readiness;
- rollback readiness;
- communication plan.

---

### 68. Deployment Strategies

```text
IN_PLACE
BLUE_GREEN
CANARY
ROLLING
MAINTENANCE_WINDOW
```

Select based on platform capability.

---

### 69. In-Place Deployment

Requires stronger backup and rollback discipline.

---

### 70. Blue-Green

Allows switching between old and new environments.

---

### 71. Canary

Gradual exposure with monitoring and rollback thresholds.

---

### 72. Deployment Preconditions

- artifact verified;
- configuration valid;
- migration approved;
- backup ready;
- health endpoints ready;
- monitoring active;
- rollback artifact available.

---

### 73. Pre-Deployment Backup

Required for destructive/critical migration.

---

### 74. Database Migration Security

Migration must be:

- versioned;
- reviewed;
- tested;
- tenant-safe;
- backup-aware;
- rollback-aware;
- least-privilege executed;
- audited.

---

### 75. Migration Account

Use dedicated migration credential.

Do not use application runtime credential for DDL if avoidable.

---

### 76. Migration Validation

Check:

- syntax;
- constraints;
- indexes;
- tenant columns;
- default values;
- data exposure;
- destructive statements;
- lock duration.

---

### 77. Destructive Migration

Requires:

- explicit approval;
- backup;
- data retention review;
- rollback/restore plan;
- maintenance window if needed.

---

### 78. Expand-Migrate-Contract Pattern

Recommended:

```text
Expand schema
→ Deploy compatible code
→ Migrate data
→ Verify
→ Remove old schema later
```

---

### 79. Deployment Configuration Validation

Validate:

- APP_ENV;
- debug;
- base URL;
- secure cookie;
- TLS;
- trusted proxies;
- CORS;
- key/secret references;
- database account;
- file paths;
- scheduler;
- observability/security events.

---

### 80. Production Security Guard

Deployment must fail if:

- debug enabled;
- default credentials detected;
- secure cookie disabled;
- root DB credential used;
- storage under public root;
- critical secret missing;
- artifact signature invalid.

---

### 81. Apache Deployment Checks

Validate:

- document root points to `public`;
- directory listing disabled;
- sensitive files blocked;
- storage denied;
- HTTPS configured in production;
- server signature reduced.

---

### 82. PHP Deployment Checks

Validate:

- supported version;
- production error settings;
- session strict mode;
- secure cookie;
- upload limits;
- extension inventory;
- dangerous functions reviewed.

---

### 83. Deployment Identity

Deployment must use dedicated service identity.

---

### 84. Deployment Permissions

Deployment identity should have only:

- artifact read;
- target write/deploy;
- health check;
- migration permission if applicable;
- rollback permission.

---

### 85. Manual Production Changes

Manual changes should be exceptional.

Must include:

- reason;
- approver;
- command/action;
- operator;
- timestamp;
- evidence;
- reconciliation back to source.

---

### 86. Drift Detection

Detect differences between:

- source-controlled config;
- deployed config;
- database schema version;
- artifact checksum;
- scheduled jobs.

---

### 87. Configuration Drift

Drift should create:

- finding;
- owner;
- severity;
- remediation;
- audit.

---

### 88. Post-Deployment Validation

Validate:

```text
release version
artifact checksum
database migration version
health/readiness
login
authorization
tenant isolation
security headers
audit/security events
critical workflow
```

---

### 89. Smoke Test Identity

Use dedicated non-privileged synthetic account where possible.

---

### 90. Production Security Validation

Must be non-destructive and minimal.

---

### 91. Rollback Principles

```text
Fast
Tested
Auditable
Data-Aware
Security-Preserving
```

---

### 92. Rollback Triggers

Examples:

- health failure;
- authentication failure;
- authorization regression;
- tenant isolation failure;
- migration failure;
- critical error spike;
- security event pipeline failure.

---

### 93. Rollback Inputs

```text
previous artifact
previous signature
database state
migration state
configuration snapshot
backup
rollback instructions
```

---

### 94. Rollback Artifact

Must be verified and available before deployment.

---

### 95. Rollback with Database Change

Options:

- backward-compatible rollback;
- forward fix;
- restore backup;
- compensating migration.

Avoid unsafe automatic rollback of destructive migrations.

---

### 96. Rollback Decision

Critical rollback may require incident commander or change approver.

---

### 97. Rollback Evidence

Record:

- trigger;
- decision;
- operator;
- artifact;
- database action;
- result;
- follow-up.

---

### 98. Roll-Forward

For irreversible schema/data changes, roll-forward may be safer than rollback.

---

### 99. Scheduler Architecture

```text
Secure Delivery Scheduler
    │
    ├── Dependency Advisory Refresh
    ├── SBOM Vulnerability Correlation
    ├── Artifact Integrity Verification
    ├── Signature Expiry/Key Check
    ├── Release Exception Expiry
    ├── Deployment Drift Check
    ├── Security Evidence Retention
    ├── Stale Release Cleanup
    └── Release Reconciliation
```

---

### 100. Required Jobs

```text
sec-sdlc-dependency-refresh
sec-sdlc-sbom-correlate
sec-sdlc-artifact-verify
sec-sdlc-signing-key-check
sec-sdlc-exception-expiry
sec-sdlc-drift-check
sec-sdlc-evidence-retention
sec-sdlc-release-cleanup
sec-sdlc-release-reconcile
```

---

### 101. Job Frequency

| Job | Frequency |
|---|---:|
| Dependency advisory refresh | hourly/daily |
| SBOM correlation | daily |
| Artifact verification | daily/on promotion |
| Signing key check | daily |
| Exception expiry | hourly |
| Drift check | hourly/daily |
| Evidence retention | daily |
| Release cleanup | weekly |
| Release reconciliation | hourly |

---

### 102. Job Locking

Examples:

```text
sec-sdlc-sbom:{release_id}
sec-sdlc-artifact:{artifact_id}
sec-sdlc-drift:{environment}
sec-sdlc-reconcile:{release_id}:{environment}
```

---

### 103. Job Idempotency

Required for:

- artifact verification;
- SBOM correlation;
- finding creation;
- exception expiration;
- promotion reconciliation;
- deployment state updates.

---

### 104. API Base Paths

```text
/api/internal/v1/sec-sdlc/pipelines
/api/internal/v1/sec-sdlc/builds
/api/internal/v1/sec-sdlc/artifacts
/api/internal/v1/sec-sdlc/sboms
/api/internal/v1/sec-sdlc/releases
/api/internal/v1/sec-sdlc/gates
/api/internal/v1/sec-sdlc/promotions
/api/internal/v1/sec-sdlc/deployments
/api/internal/v1/sec-sdlc/rollbacks
/api/internal/v1/sec-sdlc/evidence
/api/internal/v1/sec-sdlc/drift
/api/internal/v1/sec-sdlc/health
```

---

### 105. Pipeline API

```text
GET  /api/internal/v1/sec-sdlc/pipelines
GET  /api/internal/v1/sec-sdlc/pipelines/{pipelineId}
POST /api/internal/v1/sec-sdlc/pipelines/{pipelineId}/evaluate
POST /api/internal/v1/sec-sdlc/pipelines/{pipelineId}/cancel
```

---

### 106. Build API

```text
GET  /api/internal/v1/sec-sdlc/builds
GET  /api/internal/v1/sec-sdlc/builds/{buildId}
POST /api/internal/v1/sec-sdlc/builds
POST /api/internal/v1/sec-sdlc/builds/{buildId}/complete
POST /api/internal/v1/sec-sdlc/builds/{buildId}/fail
```

---

### 107. Artifact API

```text
GET  /api/internal/v1/sec-sdlc/artifacts
GET  /api/internal/v1/sec-sdlc/artifacts/{artifactId}
POST /api/internal/v1/sec-sdlc/artifacts
POST /api/internal/v1/sec-sdlc/artifacts/{artifactId}/verify
POST /api/internal/v1/sec-sdlc/artifacts/{artifactId}/sign
POST /api/internal/v1/sec-sdlc/artifacts/{artifactId}/revoke
```

---

### 108. SBOM API

```text
GET  /api/internal/v1/sec-sdlc/sboms
GET  /api/internal/v1/sec-sdlc/sboms/{sbomId}
POST /api/internal/v1/sec-sdlc/sboms
POST /api/internal/v1/sec-sdlc/sboms/{sbomId}/validate
POST /api/internal/v1/sec-sdlc/sboms/{sbomId}/correlate
```

---

### 109. Release API

```text
GET  /api/internal/v1/sec-sdlc/releases
GET  /api/internal/v1/sec-sdlc/releases/{releaseId}
POST /api/internal/v1/sec-sdlc/releases
POST /api/internal/v1/sec-sdlc/releases/{releaseId}/submit
POST /api/internal/v1/sec-sdlc/releases/{releaseId}/approve
POST /api/internal/v1/sec-sdlc/releases/{releaseId}/reject
POST /api/internal/v1/sec-sdlc/releases/{releaseId}/revoke
```

---

### 110. Gate API

```text
GET  /api/internal/v1/sec-sdlc/gates
GET  /api/internal/v1/sec-sdlc/gates/{gateId}
POST /api/internal/v1/sec-sdlc/gates/evaluate
POST /api/internal/v1/sec-sdlc/gates/{gateId}/override
```

---

### 111. Promotion API

```text
GET  /api/internal/v1/sec-sdlc/promotions
POST /api/internal/v1/sec-sdlc/promotions
POST /api/internal/v1/sec-sdlc/promotions/{promotionId}/approve
POST /api/internal/v1/sec-sdlc/promotions/{promotionId}/execute
POST /api/internal/v1/sec-sdlc/promotions/{promotionId}/cancel
```

---

### 112. Deployment API

```text
GET  /api/internal/v1/sec-sdlc/deployments
GET  /api/internal/v1/sec-sdlc/deployments/{deploymentId}
POST /api/internal/v1/sec-sdlc/deployments
POST /api/internal/v1/sec-sdlc/deployments/{deploymentId}/start
POST /api/internal/v1/sec-sdlc/deployments/{deploymentId}/verify
POST /api/internal/v1/sec-sdlc/deployments/{deploymentId}/complete
POST /api/internal/v1/sec-sdlc/deployments/{deploymentId}/fail
```

---

### 113. Rollback API

```text
GET  /api/internal/v1/sec-sdlc/rollbacks
POST /api/internal/v1/sec-sdlc/rollbacks
POST /api/internal/v1/sec-sdlc/rollbacks/{rollbackId}/approve
POST /api/internal/v1/sec-sdlc/rollbacks/{rollbackId}/execute
POST /api/internal/v1/sec-sdlc/rollbacks/{rollbackId}/verify
```

---

### 114. Drift API

```text
GET  /api/internal/v1/sec-sdlc/drift
POST /api/internal/v1/sec-sdlc/drift/check
POST /api/internal/v1/sec-sdlc/drift/{driftId}/acknowledge
POST /api/internal/v1/sec-sdlc/drift/{driftId}/resolve
```

---

### 115. Canonical Release Request

```json
{
  "version": "1.8.0",
  "commit_sha": "abc123...",
  "build_id": "BUILD-901",
  "artifact_id": "ART-901",
  "sbom_id": "SBOM-901",
  "risk_tier": "TIER_3",
  "target_environment": "PRODUCTION"
}
```

---

### 116. Canonical Promotion Request

```json
{
  "release_id": "REL-2026-07-001",
  "artifact_id": "ART-901",
  "source_environment": "STAGING",
  "target_environment": "PRODUCTION",
  "deployment_strategy": "IN_PLACE",
  "window_start": "2026-07-06T01:00:00Z"
}
```

---

### 117. Controller Responsibilities

Controllers may:

- validate request;
- call release services;
- project results;
- map errors;
- attach audit context.

Controllers must not:

- sign artifacts directly;
- bypass gates;
- mutate release evidence;
- deploy arbitrary artifact;
- accept client-provided approval identity;
- execute shell commands from request.

---

### 118. Release Service Contract

```php
interface SecureReleaseServiceInterface
{
    public function create(
        ReleaseCreateCommand $command,
        SecurityContext $context
    ): SecureRelease;

    public function evaluate(
        string $releaseId,
        SecurityContext $context
    ): ReleaseGateResult;

    public function approve(
        string $releaseId,
        ReleaseApprovalCommand $command,
        SecurityContext $context
    ): SecureRelease;
}
```

---

### 119. Artifact Service Contract

```php
interface ArtifactIntegrityServiceInterface
{
    public function register(
        ArtifactRegisterCommand $command,
        SecurityContext $context
    ): ReleaseArtifact;

    public function verify(
        string $artifactId,
        SecurityContext $context
    ): ArtifactVerificationResult;

    public function sign(
        string $artifactId,
        SecurityContext $context
    ): ArtifactSignature;
}
```

---

### 120. SBOM Service Contract

```php
interface SbomServiceInterface
{
    public function register(
        SbomRegisterCommand $command,
        SecurityContext $context
    ): SoftwareBillOfMaterials;

    public function validate(
        string $sbomId,
        SecurityContext $context
    ): SbomValidationResult;

    public function correlateVulnerabilities(
        string $sbomId,
        SecurityContext $context
    ): VulnerabilityCorrelationResult;
}
```

---

### 121. Promotion Service Contract

```php
interface EnvironmentPromotionServiceInterface
{
    public function request(
        PromotionRequestCommand $command,
        SecurityContext $context
    ): EnvironmentPromotion;

    public function execute(
        string $promotionId,
        SecurityContext $context
    ): EnvironmentPromotion;
}
```

---

### 122. Deployment Service Contract

```php
interface SecureDeploymentServiceInterface
{
    public function start(
        DeploymentStartCommand $command,
        SecurityContext $context
    ): SecureDeployment;

    public function verify(
        string $deploymentId,
        SecurityContext $context
    ): DeploymentVerificationResult;

    public function rollback(
        string $deploymentId,
        RollbackCommand $command,
        SecurityContext $context
    ): RollbackExecution;
}
```

---

### 123. Database Schema Overview

Tables:

```text
sec_sdlc_pipelines
sec_sdlc_pipeline_runs
sec_sdlc_pipeline_stages
sec_sdlc_builds
sec_sdlc_artifacts
sec_sdlc_artifact_signatures
sec_sdlc_sboms
sec_sdlc_sbom_components
sec_sdlc_releases
sec_sdlc_release_gates
sec_sdlc_release_findings
sec_sdlc_release_exceptions
sec_sdlc_promotions
sec_sdlc_deployments
sec_sdlc_deployment_events
sec_sdlc_rollbacks
sec_sdlc_evidence
sec_sdlc_drift_findings
sec_sdlc_scheduler_runs
```

---

### 124. Table: sec_sdlc_pipelines

```sql
CREATE TABLE sec_sdlc_pipelines (
    id CHAR(26) NOT NULL,
    pipeline_code VARCHAR(180) NOT NULL,
    repository VARCHAR(500) NOT NULL,
    branch_policy VARCHAR(100) NOT NULL,
    owner_reference VARCHAR(180) NOT NULL,
    status VARCHAR(30) NOT NULL DEFAULT 'ACTIVE',
    created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    updated_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6)
        ON UPDATE CURRENT_TIMESTAMP(6),

    PRIMARY KEY (id),
    UNIQUE KEY uq_sec_sdlc_pipeline_code (
        pipeline_code
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

### 125. Table: sec_sdlc_pipeline_runs

```sql
CREATE TABLE sec_sdlc_pipeline_runs (
    id CHAR(26) NOT NULL,
    pipeline_id CHAR(26) NOT NULL,
    commit_sha CHAR(64) NOT NULL,
    branch_name VARCHAR(255) NOT NULL,
    trigger_type VARCHAR(50) NOT NULL,
    status VARCHAR(30) NOT NULL,
    started_at DATETIME(6) NOT NULL,
    completed_at DATETIME(6) NULL,
    actor_reference VARCHAR(180) NULL,
    evidence_reference VARCHAR(500) NULL,

    PRIMARY KEY (id),
    KEY idx_pipeline_run_commit (
        commit_sha,
        started_at
    ),
    KEY idx_pipeline_run_status (
        status,
        started_at
    ),
    CONSTRAINT fk_pipeline_run_pipeline
        FOREIGN KEY (pipeline_id)
        REFERENCES sec_sdlc_pipelines (id)
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

### 126. Table: sec_sdlc_builds

```sql
CREATE TABLE sec_sdlc_builds (
    id CHAR(26) NOT NULL,
    pipeline_run_id CHAR(26) NOT NULL,
    build_number VARCHAR(100) NOT NULL,
    builder_identity VARCHAR(180) NOT NULL,
    build_environment_json JSON NOT NULL,
    dependency_lock_hash CHAR(64) NOT NULL,
    status VARCHAR(30) NOT NULL,
    started_at DATETIME(6) NOT NULL,
    completed_at DATETIME(6) NULL,

    PRIMARY KEY (id),
    UNIQUE KEY uq_sec_sdlc_build_number (
        build_number
    ),
    CONSTRAINT fk_build_pipeline_run
        FOREIGN KEY (pipeline_run_id)
        REFERENCES sec_sdlc_pipeline_runs (id)
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

### 127. Table: sec_sdlc_artifacts

```sql
CREATE TABLE sec_sdlc_artifacts (
    id CHAR(26) NOT NULL,
    build_id CHAR(26) NOT NULL,
    artifact_name VARCHAR(255) NOT NULL,
    artifact_version VARCHAR(100) NOT NULL,
    storage_reference VARCHAR(1000) NOT NULL,
    sha256 CHAR(64) NOT NULL,
    size_bytes BIGINT UNSIGNED NOT NULL,
    status VARCHAR(30) NOT NULL DEFAULT 'REGISTERED',
    immutable_at DATETIME(6) NULL,
    created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),

    PRIMARY KEY (id),
    UNIQUE KEY uq_sec_sdlc_artifact_version_hash (
        artifact_name,
        artifact_version,
        sha256
    ),
    KEY idx_artifact_build (
        build_id,
        status
    ),
    CONSTRAINT fk_artifact_build
        FOREIGN KEY (build_id)
        REFERENCES sec_sdlc_builds (id)
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

### 128. Table: sec_sdlc_artifact_signatures

```sql
CREATE TABLE sec_sdlc_artifact_signatures (
    id CHAR(26) NOT NULL,
    artifact_id CHAR(26) NOT NULL,
    signing_key_reference VARCHAR(500) NOT NULL,
    signing_key_version VARCHAR(100) NOT NULL,
    algorithm VARCHAR(80) NOT NULL,
    signature_reference VARCHAR(1000) NOT NULL,
    signature_hash CHAR(64) NOT NULL,
    signed_by VARCHAR(180) NOT NULL,
    signed_at DATETIME(6) NOT NULL,
    status VARCHAR(30) NOT NULL DEFAULT 'VALID',

    PRIMARY KEY (id),
    KEY idx_artifact_signature (
        artifact_id,
        status
    ),
    CONSTRAINT fk_signature_artifact
        FOREIGN KEY (artifact_id)
        REFERENCES sec_sdlc_artifacts (id)
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

### 129. Table: sec_sdlc_sboms

```sql
CREATE TABLE sec_sdlc_sboms (
    id CHAR(26) NOT NULL,
    artifact_id CHAR(26) NOT NULL,
    format VARCHAR(50) NOT NULL,
    format_version VARCHAR(50) NOT NULL,
    document_reference VARCHAR(1000) NOT NULL,
    sha256 CHAR(64) NOT NULL,
    component_count INT UNSIGNED NOT NULL,
    validation_status VARCHAR(30) NOT NULL,
    generated_at DATETIME(6) NOT NULL,
    validated_at DATETIME(6) NULL,

    PRIMARY KEY (id),
    UNIQUE KEY uq_sbom_artifact (
        artifact_id
    ),
    CONSTRAINT fk_sbom_artifact
        FOREIGN KEY (artifact_id)
        REFERENCES sec_sdlc_artifacts (id)
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

### 130. Table: sec_sdlc_sbom_components

```sql
CREATE TABLE sec_sdlc_sbom_components (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    sbom_id CHAR(26) NOT NULL,
    component_name VARCHAR(255) NOT NULL,
    component_version VARCHAR(100) NOT NULL,
    component_type VARCHAR(50) NOT NULL,
    supplier VARCHAR(255) NULL,
    license_expression VARCHAR(255) NULL,
    component_hash CHAR(64) NULL,

    PRIMARY KEY (id),
    KEY idx_sbom_component_lookup (
        component_name,
        component_version
    ),
    CONSTRAINT fk_sbom_component_sbom
        FOREIGN KEY (sbom_id)
        REFERENCES sec_sdlc_sboms (id)
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

### 131. Table: sec_sdlc_releases

```sql
CREATE TABLE sec_sdlc_releases (
    id CHAR(26) NOT NULL,
    release_code VARCHAR(180) NOT NULL,
    version VARCHAR(100) NOT NULL,
    commit_sha CHAR(64) NOT NULL,
    build_id CHAR(26) NOT NULL,
    artifact_id CHAR(26) NOT NULL,
    sbom_id CHAR(26) NOT NULL,
    risk_tier VARCHAR(30) NOT NULL,
    target_environment VARCHAR(40) NOT NULL,
    status VARCHAR(30) NOT NULL DEFAULT 'DRAFT',
    submitted_at DATETIME(6) NULL,
    approved_at DATETIME(6) NULL,
    revoked_at DATETIME(6) NULL,
    created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),

    PRIMARY KEY (id),
    UNIQUE KEY uq_sec_sdlc_release_code (
        release_code
    ),
    UNIQUE KEY uq_sec_sdlc_release_version (
        version,
        target_environment
    ),
    KEY idx_sec_sdlc_release_status (
        target_environment,
        status
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

### 132. Table: sec_sdlc_release_gates

```sql
CREATE TABLE sec_sdlc_release_gates (
    id CHAR(26) NOT NULL,
    release_id CHAR(26) NOT NULL,
    gate_code VARCHAR(180) NOT NULL,
    gate_type VARCHAR(80) NOT NULL,
    result VARCHAR(30) NOT NULL,
    severity VARCHAR(30) NOT NULL,
    evidence_reference VARCHAR(1000) NULL,
    exception_reference VARCHAR(255) NULL,
    evaluated_at DATETIME(6) NOT NULL,
    evaluator_version VARCHAR(100) NOT NULL,

    PRIMARY KEY (id),
    UNIQUE KEY uq_release_gate (
        release_id,
        gate_code
    ),
    KEY idx_release_gate_result (
        result,
        severity,
        evaluated_at
    ),
    CONSTRAINT fk_release_gate_release
        FOREIGN KEY (release_id)
        REFERENCES sec_sdlc_releases (id)
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

### 133. Table: sec_sdlc_promotions

```sql
CREATE TABLE sec_sdlc_promotions (
    id CHAR(26) NOT NULL,
    release_id CHAR(26) NOT NULL,
    artifact_id CHAR(26) NOT NULL,
    source_environment VARCHAR(40) NOT NULL,
    target_environment VARCHAR(40) NOT NULL,
    deployment_strategy VARCHAR(50) NOT NULL,
    status VARCHAR(30) NOT NULL DEFAULT 'REQUESTED',
    requested_by VARCHAR(180) NOT NULL,
    approved_by VARCHAR(180) NULL,
    expires_at DATETIME(6) NULL,
    executed_at DATETIME(6) NULL,
    created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),

    PRIMARY KEY (id),
    KEY idx_promotion_status (
        target_environment,
        status
    ),
    CONSTRAINT fk_promotion_release
        FOREIGN KEY (release_id)
        REFERENCES sec_sdlc_releases (id)
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

### 134. Table: sec_sdlc_deployments

```sql
CREATE TABLE sec_sdlc_deployments (
    id CHAR(26) NOT NULL,
    promotion_id CHAR(26) NOT NULL,
    release_id CHAR(26) NOT NULL,
    artifact_id CHAR(26) NOT NULL,
    environment VARCHAR(40) NOT NULL,
    strategy VARCHAR(50) NOT NULL,
    status VARCHAR(30) NOT NULL DEFAULT 'PENDING',
    deployed_by VARCHAR(180) NULL,
    started_at DATETIME(6) NULL,
    completed_at DATETIME(6) NULL,
    verification_status VARCHAR(30) NULL,
    previous_release_id CHAR(26) NULL,

    PRIMARY KEY (id),
    KEY idx_deployment_environment (
        environment,
        status,
        started_at
    ),
    CONSTRAINT fk_deployment_promotion
        FOREIGN KEY (promotion_id)
        REFERENCES sec_sdlc_promotions (id)
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

### 135. Table: sec_sdlc_rollbacks

```sql
CREATE TABLE sec_sdlc_rollbacks (
    id CHAR(26) NOT NULL,
    deployment_id CHAR(26) NOT NULL,
    reason VARCHAR(3000) NOT NULL,
    target_release_id CHAR(26) NULL,
    rollback_strategy VARCHAR(80) NOT NULL,
    status VARCHAR(30) NOT NULL DEFAULT 'REQUESTED',
    requested_by VARCHAR(180) NOT NULL,
    approved_by VARCHAR(180) NULL,
    executed_by VARCHAR(180) NULL,
    requested_at DATETIME(6) NOT NULL,
    executed_at DATETIME(6) NULL,
    verified_at DATETIME(6) NULL,

    PRIMARY KEY (id),
    KEY idx_rollback_status (
        status,
        requested_at
    ),
    CONSTRAINT fk_rollback_deployment
        FOREIGN KEY (deployment_id)
        REFERENCES sec_sdlc_deployments (id)
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

### 136. Table: sec_sdlc_drift_findings

```sql
CREATE TABLE sec_sdlc_drift_findings (
    id CHAR(26) NOT NULL,
    environment VARCHAR(40) NOT NULL,
    drift_type VARCHAR(80) NOT NULL,
    expected_value_hash CHAR(64) NULL,
    actual_value_hash CHAR(64) NULL,
    severity VARCHAR(30) NOT NULL,
    status VARCHAR(30) NOT NULL DEFAULT 'OPEN',
    owner_reference VARCHAR(180) NULL,
    detected_at DATETIME(6) NOT NULL,
    resolved_at DATETIME(6) NULL,
    details_json JSON NULL,

    PRIMARY KEY (id),
    KEY idx_drift_environment_status (
        environment,
        status,
        detected_at
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

### 137. Security Event Codes

```text
SDLC_PIPELINE_STARTED
SDLC_PIPELINE_FAILED
SDLC_SECRET_FOUND
SDLC_SAST_BLOCKED
SDLC_DEPENDENCY_BLOCKED
SDLC_TENANT_TEST_FAILED
SDLC_ARTIFACT_REGISTERED
SDLC_ARTIFACT_SIGNATURE_INVALID
SDLC_SBOM_VALIDATION_FAILED
SDLC_RELEASE_APPROVED
SDLC_RELEASE_REJECTED
SDLC_GATE_OVERRIDDEN
SDLC_PROMOTION_EXECUTED
SDLC_DEPLOYMENT_STARTED
SDLC_DEPLOYMENT_FAILED
SDLC_ROLLBACK_EXECUTED
SDLC_DRIFT_DETECTED
```

---

### 138. Audit Integration

Audit required for:

- gate override;
- release approval;
- promotion approval;
- artifact signing;
- artifact revocation;
- deployment start;
- rollback;
- manual production change;
- exception use.

---

### 139. Metrics

```text
sec_sdlc_pipeline_total
sec_sdlc_pipeline_failure_total
sec_sdlc_gate_failure_total
sec_sdlc_secret_detection_total
sec_sdlc_artifact_signature_failure_total
sec_sdlc_sbom_validation_failure_total
sec_sdlc_release_approved_total
sec_sdlc_release_rejected_total
sec_sdlc_deployment_total
sec_sdlc_deployment_failure_total
sec_sdlc_rollback_total
sec_sdlc_drift_open_total
sec_sdlc_release_lead_time_seconds
```

---

### 140. Alert Candidates

```text
critical_gate_failed
active_secret_detected
artifact_signature_invalid
sbom_missing_or_invalid
tenant_isolation_gate_failed
production_deployment_failed
rollback_failed
production_drift_detected
expired_release_exception_used
signing_key_rotation_overdue
```

---

### 141. Error Codes

```text
SDLC_PIPELINE_NOT_FOUND
SDLC_BUILD_NOT_FOUND
SDLC_BUILD_STATE_INVALID
SDLC_ARTIFACT_NOT_FOUND
SDLC_ARTIFACT_HASH_MISMATCH
SDLC_ARTIFACT_SIGNATURE_INVALID
SDLC_SBOM_NOT_FOUND
SDLC_SBOM_INVALID
SDLC_RELEASE_NOT_FOUND
SDLC_RELEASE_GATE_FAILED
SDLC_RELEASE_APPROVAL_REQUIRED
SDLC_RELEASE_EXCEPTION_EXPIRED
SDLC_PROMOTION_NOT_ALLOWED
SDLC_DEPLOYMENT_CONFIG_INVALID
SDLC_DEPLOYMENT_FAILED
SDLC_ROLLBACK_NOT_ALLOWED
SDLC_ROLLBACK_FAILED
SDLC_DRIFT_DETECTED
```

---

### 142. CLI Commands

```bash
php bin/console sec-sdlc:pipeline:evaluate
php bin/console sec-sdlc:artifact:verify
php bin/console sec-sdlc:artifact:sign
php bin/console sec-sdlc:sbom:validate
php bin/console sec-sdlc:sbom:correlate
php bin/console sec-sdlc:release:evaluate
php bin/console sec-sdlc:promotion:execute
php bin/console sec-sdlc:deployment:verify
php bin/console sec-sdlc:rollback:execute
php bin/console sec-sdlc:drift:check
php bin/console sec-sdlc:release:reconcile
```

---

### 143. Sequence Diagram — Secure Build

```mermaid
sequenceDiagram
    participant Dev
    participant Repo
    participant CI
    participant Scanner
    participant Build
    participant Artifact
    participant Signer

    Dev->>Repo: Push reviewed commit
    Repo->>CI: Trigger pipeline
    CI->>Scanner: Secret/SAST/dependency scans
    Scanner-->>CI: PASS
    CI->>Build: Run tests and build
    Build-->>CI: Artifact
    CI->>Artifact: Register hash and metadata
    Artifact->>Signer: Sign artifact
    Signer-->>Artifact: Signature
    Artifact-->>CI: Attested artifact
```

---

### 144. Sequence Diagram — Release Gate

```mermaid
sequenceDiagram
    participant Release
    participant Gate
    participant Evidence
    participant Policy
    participant Approver

    Release->>Gate: Submit release
    Gate->>Evidence: Load reports and artifact metadata
    Evidence-->>Gate: Evidence package
    Gate->>Policy: Evaluate release policies
    Policy-->>Gate: PASS/WARN/FAIL
    alt Pass
        Gate->>Approver: Request approval
        Approver-->>Release: Approved
    else Fail
        Gate-->>Release: Rejected
    end
```

---

### 145. Sequence Diagram — Environment Promotion

```mermaid
sequenceDiagram
    participant Operator
    participant Promotion
    participant Artifact
    participant Gate
    participant Deployment

    Operator->>Promotion: Request staging to production
    Promotion->>Artifact: Verify hash/signature
    Artifact-->>Promotion: Valid
    Promotion->>Gate: Verify release approval
    Gate-->>Promotion: Approved
    Promotion->>Deployment: Execute same artifact
    Deployment-->>Promotion: Deployment started
```

---

### 146. Sequence Diagram — Deployment Verification

```mermaid
sequenceDiagram
    participant Deployment
    participant Config
    participant Database
    participant Application
    participant Security
    participant Audit

    Deployment->>Config: Validate production configuration
    Config-->>Deployment: Valid
    Deployment->>Database: Apply approved migration
    Database-->>Deployment: Migration complete
    Deployment->>Application: Deploy artifact
    Application-->>Deployment: Ready
    Deployment->>Security: Run post-deploy checks
    Security-->>Deployment: PASS
    Deployment->>Audit: Record completion
```

---

### 147. Sequence Diagram — Rollback

```mermaid
sequenceDiagram
    participant Monitor
    participant Deployment
    participant Rollback
    participant Artifact
    participant Database
    participant Audit

    Monitor->>Deployment: Critical failure detected
    Deployment->>Rollback: Request rollback
    Rollback->>Artifact: Verify previous artifact
    Artifact-->>Rollback: Valid
    Rollback->>Database: Apply safe rollback/compensation
    Rollback->>Deployment: Restore previous release
    Deployment->>Audit: Record rollback result
```

---

### 148. Sequence Diagram — Drift Detection

```mermaid
sequenceDiagram
    participant Scheduler
    participant Drift
    participant Environment
    participant Repository
    participant Security

    Scheduler->>Drift: Run drift check
    Drift->>Environment: Read deployed state
    Drift->>Repository: Load expected state
    Drift->>Drift: Compare hashes/config/schema
    alt Drift found
        Drift->>Security: Create finding and alert
    end
```

---

### 149. Performance Targets

| Operation | Target |
|---|---:|
| Gate evaluation p95 | < 2 s excluding scans |
| Artifact metadata lookup p95 | < 100 ms |
| Signature verification p95 | < 500 ms |
| SBOM validation typical | < 10 s |
| Release overview p95 | < 1.5 s |
| Promotion request p95 | < 500 ms |
| Deployment state update p95 | < 200 ms |
| Drift lookup p95 | < 500 ms |

---

### 150. Testing Strategy

#### Unit

- gate policies;
- artifact hash verification;
- signature verification;
- SBOM validation;
- promotion eligibility;
- rollback eligibility;
- drift comparison;
- config validation.

#### Integration

- pipeline run persistence;
- artifact register/sign/verify;
- release submission/approval;
- promotion;
- deployment events;
- rollback;
- scheduler locks;
- audit integration.

#### Security

- tampered artifact;
- forged signature;
- missing SBOM;
- expired exception;
- unauthorized promotion;
- manual artifact mutation;
- secret leakage from CI;
- production config bypass;
- rollback to vulnerable release.

---

### 151. UAT Part 4

#### Source & CI Security

- [ ] Protected branches active.
- [ ] Required review active.
- [ ] Sensitive paths have designated reviewers.
- [ ] Untrusted PRs cannot access protected secrets.
- [ ] Runner isolation configured.
- [ ] CI credentials are least privilege.
- [ ] Workspaces are cleaned.
- [ ] Pipeline audit is available.

#### Pipeline Stages

- [ ] Source validation works.
- [ ] Config/manifest validation works.
- [ ] Secret scan runs.
- [ ] SAST runs.
- [ ] Dependency scan runs.
- [ ] Unit/integration tests run.
- [ ] Tenant isolation tests run.
- [ ] Build/package stages work.
- [ ] Evidence/attestation stages work.

#### Build Integrity

- [ ] Lockfile verified.
- [ ] Tool versions recorded.
- [ ] Build environment recorded.
- [ ] Production package excludes development files.
- [ ] Artifact checksum generated.
- [ ] Artifact immutable after publication.
- [ ] Provenance available.
- [ ] Rebuild metadata available.

#### Signing & SBOM

- [ ] Signing key access restricted.
- [ ] Artifact signing works.
- [ ] Signature verification blocks invalid artifact.
- [ ] SBOM generated from release artifact.
- [ ] SBOM validation works.
- [ ] Direct/transitive components included where supported.
- [ ] SBOM linked to release.
- [ ] Vulnerability correlation works.

#### Release Gates

- [ ] Critical findings block release.
- [ ] Secret detection blocks release.
- [ ] Tenant test failure blocks release.
- [ ] Missing evidence blocks release.
- [ ] Expired exception is rejected.
- [ ] Conditional approval is controlled.
- [ ] Self-approval restrictions work.
- [ ] Gate override is audited.

#### Promotion

- [ ] Same artifact promoted.
- [ ] Artifact hash remains unchanged.
- [ ] Target configuration is validated.
- [ ] Promotion token is scoped and expires.
- [ ] Production approval is required.
- [ ] Unauthorized promotion is rejected.
- [ ] Promotion history is immutable.

#### Deployment

- [ ] Artifact verification occurs before deploy.
- [ ] Dedicated deployment identity is used.
- [ ] Migration credential is separated.
- [ ] Production guard rejects insecure config.
- [ ] Backup readiness is checked.
- [ ] Health/readiness validation works.
- [ ] Security smoke tests run.
- [ ] Deployment audit is available.

#### Migration

- [ ] Migrations are versioned.
- [ ] Tenant columns/constraints are reviewed.
- [ ] Destructive migrations require approval.
- [ ] Expand-migrate-contract supported.
- [ ] Migration rollback/compensation tested.
- [ ] Lock duration considered.
- [ ] Backup exists before critical migration.

#### Rollback

- [ ] Previous artifact available.
- [ ] Previous signature valid.
- [ ] Rollback triggers defined.
- [ ] Database rollback strategy documented.
- [ ] Rollback execution is audited.
- [ ] Post-rollback verification works.
- [ ] Roll-forward option documented.
- [ ] Rollback to vulnerable release is controlled.

#### Drift & Scheduler

- [ ] Artifact drift detected.
- [ ] Config drift detected.
- [ ] Schema drift detected.
- [ ] Scheduled jobs are locked/idempotent.
- [ ] SBOM correlation runs.
- [ ] Signature/key checks run.
- [ ] Exception expiry runs.
- [ ] Release reconciliation runs.
- [ ] Drift findings have owners.

#### APIs & Database

- [ ] Pipeline/build/artifact APIs work.
- [ ] SBOM/release/gate APIs work.
- [ ] Promotion/deployment/rollback APIs work.
- [ ] Authorization is enforced.
- [ ] Database migrations succeed.
- [ ] Unique constraints prevent duplicate state.
- [ ] Release/gate histories are preserved.
- [ ] Indexes support operational queries.

---

### 152. Anti-Pattern

Hindari:

- rebuild per environment;
- mutable release artifact;
- production secrets in CI logs;
- signing key exposed to PR jobs;
- release without SBOM;
- gate failure manually ignored;
- deployment from developer workstation;
- root DB credential for migration;
- destructive migration without backup;
- manual production change without reconciliation;
- rollback artifact not verified;
- tool unavailable treated as PASS;
- drift ignored;
- release approval without evidence.

---

### 153. Definition of Done Part 4

Part 4 dianggap selesai bila:

- [ ] secure delivery architecture tersedia;
- [ ] source control protections tersedia;
- [ ] CI runner security tersedia;
- [ ] pipeline stages tersedia;
- [ ] lockfile/dependency controls tersedia;
- [ ] build integrity controls tersedia;
- [ ] artifact packaging standard tersedia;
- [ ] checksum/signing/provenance tersedia;
- [ ] SBOM standard tersedia;
- [ ] release evidence package tersedia;
- [ ] release gate model tersedia;
- [ ] promotion model tersedia;
- [ ] deployment security tersedia;
- [ ] migration security tersedia;
- [ ] production config guard tersedia;
- [ ] rollback model tersedia;
- [ ] drift detection tersedia;
- [ ] scheduler/jobs tersedia;
- [ ] APIs tersedia;
- [ ] service contracts tersedia;
- [ ] database schema tersedia;
- [ ] event/audit integration tersedia;
- [ ] metrics/alerts tersedia;
- [ ] CLI commands tersedia;
- [ ] sequence diagrams tersedia;
- [ ] testing strategy tersedia;
- [ ] UAT tersedia.

---

### 154. Rencana Part Berikutnya

#### Part 5

Reference implementation, sample manifests, sample policies, pipeline examples, attack simulations, operational runbooks, final UAT, Definition of Done, roadmap, dan merge guidance menjadi `SSOT-SEC-02.md`.

---

## Bagian V — Reference Implementation & Operational Readiness

### 1. Executive Summary

Part 5 menutup rangkaian SSOT-SEC-02 dengan reference implementation dan operational readiness untuk Secure SDLC dan Application Security.

Bagian ini mencakup:

- final folder structure;
- secure SDLC kernel bootstrap;
- sample security manifests;
- sample policy-as-code;
- pull request security workflow;
- CI/CD pipeline examples;
- release gate evaluation;
- artifact verification;
- SBOM registration;
- deployment and rollback orchestration;
- attack simulations;
- operational runbooks;
- final UAT;
- Definition of Done;
- production readiness;
- roadmap;
- merge guidance menjadi `SSOT-SEC-02.md`.

Tujuan akhirnya adalah memastikan secure development lifecycle dapat:

- dijalankan secara konsisten;
- diotomatisasi;
- menghasilkan evidence;
- memblokir release berisiko;
- menjaga tenant isolation;
- mencegah secret leakage;
- memverifikasi artifact integrity;
- mendukung remediation dan rollback;
- diterapkan oleh seluruh module.

---

### 2. Final Implementation Scope

Initial production-ready release wajib mencakup:

```text
Security Requirement Registry
Threat Model Registry
Security Review Workflow
Secure Coding Checklists
SAST Integration
Dependency Scan Integration
Secret Scan Integration
Tenant Isolation Test Suite
DAST Integration
Security Finding Registry
Remediation Workflow
Release Gate Engine
Artifact Integrity Service
SBOM Registry
Promotion Workflow
Deployment Verification
Rollback Workflow
Evidence Registry
Security Dashboard
```

---

### 3. Final Folder Structure

```text
app/
└── Platform/
    └── SecureSdlc/
        ├── Domain/
        │   ├── SecurityRequirement.php
        │   ├── ThreatModel.php
        │   ├── Threat.php
        │   ├── SecurityReview.php
        │   ├── SecurityTestPlan.php
        │   ├── SecurityTestCase.php
        │   ├── SecurityFinding.php
        │   ├── ReleaseArtifact.php
        │   ├── ArtifactSignature.php
        │   ├── SoftwareBillOfMaterials.php
        │   ├── SecureRelease.php
        │   ├── ReleaseGate.php
        │   ├── EnvironmentPromotion.php
        │   ├── SecureDeployment.php
        │   ├── RollbackExecution.php
        │   └── SecurityEvidence.php
        │
        ├── Application/
        │   ├── SecurityRequirementService.php
        │   ├── ThreatModelService.php
        │   ├── SecurityReviewService.php
        │   ├── SecurityTestingService.php
        │   ├── FindingManagementService.php
        │   ├── ReleaseGateService.php
        │   ├── ArtifactIntegrityService.php
        │   ├── SbomService.php
        │   ├── EnvironmentPromotionService.php
        │   ├── SecureDeploymentService.php
        │   ├── SecurityEvidenceService.php
        │   └── Contracts/
        │
        ├── Infrastructure/
        │   ├── Persistence/
        │   ├── Scanners/
        │   ├── Pipeline/
        │   ├── Artifact/
        │   ├── Signing/
        │   ├── Sbom/
        │   ├── Deployment/
        │   ├── Scheduler/
        │   └── Reporting/
        │
        └── Presentation/
            ├── Http/
            │   ├── Controllers/
            │   └── Middleware/
            └── Cli/

config/
├── secure-sdlc.php
├── secure-sdlc-gates.php
├── secure-sdlc-scanners.php
├── secure-sdlc-artifacts.php
├── secure-sdlc-sbom.php
└── secure-sdlc-deployment.php

resources/
└── secure-sdlc/
    ├── manifests/
    ├── policies/
    ├── threat-models/
    ├── test-plans/
    ├── runbooks/
    └── pipeline-templates/

storage/
├── secure-sdlc-evidence/
├── secure-sdlc-artifacts/
├── secure-sdlc-sboms/
└── secure-sdlc-reports/

tests/
├── Unit/SecureSdlc/
├── Integration/SecureSdlc/
├── Security/
├── TenantIsolation/
└── Uat/SecureSdlc/

tools/
├── secure-sdlc-manifest-validate.php
├── secure-sdlc-gate-evaluate.php
├── secure-sdlc-artifact-verify.php
├── secure-sdlc-sbom-validate.php
├── secure-sdlc-release-report.php
└── secure-sdlc-reconcile.php
```

---

### 4. Secure SDLC Bootstrap

```php
<?php

declare(strict_types=1);

namespace App\Platform\SecureSdlc;

final class SecureSdlcBootstrap
{
    public static function build(
        array $config,
        object $container
    ): SecureSdlcKernel {
        return new SecureSdlcKernel(
            requirements: $container->get(
                SecurityRequirementServiceInterface::class
            ),
            threatModels: $container->get(
                ThreatModelServiceInterface::class
            ),
            reviews: $container->get(
                SecurityReviewServiceInterface::class
            ),
            testing: $container->get(
                SecurityTestingServiceInterface::class
            ),
            findings: $container->get(
                FindingManagementServiceInterface::class
            ),
            gates: $container->get(
                ReleaseGateServiceInterface::class
            ),
            artifacts: $container->get(
                ArtifactIntegrityServiceInterface::class
            ),
            sboms: $container->get(
                SbomServiceInterface::class
            ),
            promotions: $container->get(
                EnvironmentPromotionServiceInterface::class
            ),
            deployments: $container->get(
                SecureDeploymentServiceInterface::class
            ),
            evidence: $container->get(
                SecurityEvidenceServiceInterface::class
            )
        );
    }
}
```

---

### 5. Secure SDLC Kernel

```php
final class SecureSdlcKernel
{
    public function __construct(
        public readonly SecurityRequirementServiceInterface $requirements,
        public readonly ThreatModelServiceInterface $threatModels,
        public readonly SecurityReviewServiceInterface $reviews,
        public readonly SecurityTestingServiceInterface $testing,
        public readonly FindingManagementServiceInterface $findings,
        public readonly ReleaseGateServiceInterface $gates,
        public readonly ArtifactIntegrityServiceInterface $artifacts,
        public readonly SbomServiceInterface $sboms,
        public readonly EnvironmentPromotionServiceInterface $promotions,
        public readonly SecureDeploymentServiceInterface $deployments,
        public readonly SecurityEvidenceServiceInterface $evidence
    ) {
    }
}
```

---

### 6. Module Security Manifest

```yaml
module_code: patient
module_name: Patient Management
owner: patient_domain
risk_tier: TIER_3
data_classification:
  - RESTRICTED
tenant_aware: true
trust_boundaries:
  - browser_to_web
  - app_to_database
  - app_to_secure_file_storage
permissions:
  - patient.record.read
  - patient.record.create
  - patient.record.update
  - patient.record.export
security_requirements:
  - tenant_isolation
  - resource_authorization
  - audit_sensitive_access
  - encryption_in_transit
  - secure_export
required_tests:
  - unit
  - integration
  - tenant_isolation
  - sast
  - dependency_scan
  - secret_scan
  - dast
```

---

### 7. Feature Security Manifest

```yaml
feature_code: patient_export
module_code: patient
owner: patient_domain
risk_tier: TIER_4
data_classification:
  - RESTRICTED
authentication_assurance: AAL2
permissions:
  - patient.record.export
tenant_scope_required: true
sensitive_actions:
  - bulk_export
audit_events:
  - PATIENT_EXPORT_REQUESTED
  - PATIENT_EXPORT_COMPLETED
  - PATIENT_EXPORT_DOWNLOADED
retention_policy: SECURE_EXPORT_24H
required_reviews:
  - architecture
  - security
  - privacy
required_tests:
  - tenant_isolation
  - authorization
  - export_scope
  - csv_injection
  - secure_file_download
  - expiration
```

---

### 8. Security Requirement Manifest

```yaml
requirement_code: REQ-SEC-PATIENT-EXPORT-001
feature_code: patient_export
category: AUTHORIZATION
statement: Only users with patient.record.export may export patient records.
risk_level: CRITICAL
verification:
  - test_id: SEC-AUTHZ-EXPORT-001
  - test_type: integration
owner: patient_domain
status: ACTIVE
```

---

### 9. Threat Model Manifest

```yaml
threat_model_code: TM-PATIENT-EXPORT-001
feature_code: patient_export
risk_tier: TIER_4
assets:
  - patient_records
  - export_package
trust_boundaries:
  - browser_to_web
  - application_to_secure_storage
threats:
  - threat_id: THR-001
    category: INFORMATION_DISCLOSURE
    scenario: Tenant A exports Tenant B patient records.
    likelihood: MEDIUM
    impact: CRITICAL
    risk: CRITICAL
    controls:
      - tenant_scope_guard
      - resource_authorization
      - export_query_scope
      - audit_event
      - tenant_isolation_test
```

---

### 10. Security Test Plan Manifest

```yaml
test_plan_code: STP-PATIENT-EXPORT-001
feature_code: patient_export
risk_tier: TIER_4
entry_criteria:
  - threat_model_approved
  - feature_deployed_to_staging
test_types:
  - integration
  - tenant_isolation
  - sast
  - dast
  - manual_security
exit_criteria:
  - no_critical_open
  - no_high_unapproved
  - tenant_tests_pass
evidence_required:
  - test_report
  - scanner_reports
  - reviewer_approval
```

---

### 11. Release Manifest

```yaml
release_code: REL-2026-07-001
version: 1.8.0
repository: platform
commit_sha: abc123
build_id: BUILD-901
artifact_id: ART-901
sbom_id: SBOM-901
risk_tier: TIER_3
target_environment: PRODUCTION
required_gates:
  - secret_scan
  - sast
  - dependency_scan
  - unit_tests
  - integration_tests
  - tenant_isolation
  - artifact_signature
  - sbom_validation
  - release_approval
```

---

### 12. Sample Policy — Security Requirement Coverage

```php
return [
    'policy_code' => 'SDLC_SECURITY_REQUIREMENT_COVERAGE',
    'version' => '1.0',
    'category' => 'REQUIREMENT',
    'severity' => 'BLOCKING',
    'scope' => [
        'risk_tier_in' => [
            'TIER_3',
            'TIER_4',
        ],
    ],
    'require' => [
        'security_requirements_present' => true,
        'test_traceability_complete' => true,
    ],
    'owner' => 'application_security',
    'status' => 'ACTIVE',
];
```

---

### 13. Sample Policy — Threat Model Required

```php
return [
    'policy_code' => 'SDLC_THREAT_MODEL_REQUIRED',
    'version' => '1.0',
    'category' => 'DESIGN',
    'severity' => 'BLOCKING',
    'scope' => [
        'risk_tier_in' => [
            'TIER_3',
            'TIER_4',
        ],
    ],
    'require' => [
        'threat_model_status' => 'APPROVED',
    ],
    'owner' => 'security_architecture',
    'status' => 'ACTIVE',
];
```

---

### 14. Sample Policy — Critical Finding Block

```php
return [
    'policy_code' => 'SDLC_NO_CRITICAL_OPEN_FINDINGS',
    'version' => '1.0',
    'category' => 'RELEASE',
    'severity' => 'CRITICAL',
    'scope' => [
        'target_environment' => 'PRODUCTION',
    ],
    'require' => [
        'critical_open_total' => 0,
    ],
    'owner' => 'application_security',
    'status' => 'ACTIVE',
];
```

---

### 15. Sample Policy — Tenant Isolation Required

```php
return [
    'policy_code' => 'SDLC_TENANT_ISOLATION_GATE',
    'version' => '1.0',
    'category' => 'TESTING',
    'severity' => 'CRITICAL',
    'scope' => [
        'tenant_aware' => true,
    ],
    'require' => [
        'tenant_isolation_test_result' => 'PASS',
    ],
    'owner' => 'platform_architecture',
    'status' => 'ACTIVE',
];
```

---

### 16. Sample Policy — Secret Scan Pass

```php
return [
    'policy_code' => 'SDLC_SECRET_SCAN_PASS',
    'version' => '1.0',
    'category' => 'SOURCE_SECURITY',
    'severity' => 'CRITICAL',
    'scope' => [
        'all_releases' => true,
    ],
    'require' => [
        'active_secret_findings' => 0,
    ],
    'owner' => 'security_operations',
    'status' => 'ACTIVE',
];
```

---

### 17. Sample Policy — Artifact Signature

```php
return [
    'policy_code' => 'SDLC_ARTIFACT_SIGNATURE_REQUIRED',
    'version' => '1.0',
    'category' => 'SUPPLY_CHAIN',
    'severity' => 'CRITICAL',
    'scope' => [
        'target_environment_in' => [
            'STAGING',
            'PRE_PRODUCTION',
            'PRODUCTION',
        ],
    ],
    'require' => [
        'artifact_signature_status' => 'VALID',
    ],
    'owner' => 'platform_release_engineering',
    'status' => 'ACTIVE',
];
```

---

### 18. Sample Policy — SBOM Required

```php
return [
    'policy_code' => 'SDLC_SBOM_REQUIRED',
    'version' => '1.0',
    'category' => 'SUPPLY_CHAIN',
    'severity' => 'BLOCKING',
    'scope' => [
        'target_environment' => 'PRODUCTION',
    ],
    'require' => [
        'sbom_present' => true,
        'sbom_validation_status' => 'VALID',
    ],
    'owner' => 'application_security',
    'status' => 'ACTIVE',
];
```

---

### 19. Sample Policy — Release Approval

```php
return [
    'policy_code' => 'SDLC_PRODUCTION_APPROVAL_REQUIRED',
    'version' => '1.0',
    'category' => 'RELEASE',
    'severity' => 'BLOCKING',
    'scope' => [
        'target_environment' => 'PRODUCTION',
    ],
    'require' => [
        'approval_count_gte' => 1,
        'self_approval_only' => false,
    ],
    'owner' => 'release_governance',
    'status' => 'ACTIVE',
];
```

---

### 20. Pull Request Security Workflow

```text
Developer Opens PR
→ Risk Tier Detected
→ Security Manifest Validated
→ Secret Scan
→ SAST
→ Dependency Scan
→ Unit Tests
→ Affected Tenant Tests
→ Review Checklist
→ Security Reviewer if Required
→ Merge Decision
```

---

### 21. Pull Request Template

```markdown
## Change Summary

## Risk Tier
- [ ] TIER 1
- [ ] TIER 2
- [ ] TIER 3
- [ ] TIER 4

## Security Impact
- [ ] Authentication
- [ ] Authorization
- [ ] Tenant Isolation
- [ ] Sensitive Data
- [ ] File Upload
- [ ] External Integration
- [ ] Cryptography/Secrets

## Security Checklist
- [ ] Requirements updated
- [ ] Threat model updated
- [ ] Input validation added
- [ ] Output encoding verified
- [ ] Authorization server-side
- [ ] Tenant/scope filters added
- [ ] Security tests added
- [ ] No secrets included
```

---

### 22. Pipeline Example — Generic

```yaml
name: secure-sdlc

stages:
  - validate
  - scan
  - test
  - build
  - attest
  - release

validate:
  script:
    - php tools/secure-sdlc-manifest-validate.php
    - composer validate --strict

secret_scan:
  stage: scan
  script:
    - security-secret-scan .

sast:
  stage: scan
  script:
    - security-sast-scan .

dependency_scan:
  stage: scan
  script:
    - composer audit

unit_tests:
  stage: test
  script:
    - vendor/bin/phpunit tests/Unit

integration_tests:
  stage: test
  script:
    - vendor/bin/phpunit tests/Integration

tenant_isolation_tests:
  stage: test
  script:
    - vendor/bin/phpunit tests/TenantIsolation

build:
  stage: build
  script:
    - composer install --no-dev --classmap-authoritative
    - php tools/build-release.php

attest:
  stage: attest
  script:
    - php tools/generate-sbom.php
    - php tools/create-checksum.php
    - php tools/sign-artifact.php

release_gate:
  stage: release
  script:
    - php tools/secure-sdlc-gate-evaluate.php
```

---

### 23. Pipeline Example — Windows/XAMPP Local Validation

```bat
@echo off
set PHP_EXE=D:\xampp\php\php.exe

%PHP_EXE% tools\secure-sdlc-manifest-validate.php
if errorlevel 1 exit /b 1

%PHP_EXE% vendor\bin\phpunit tests\Unit
if errorlevel 1 exit /b 1

%PHP_EXE% vendor\bin\phpunit tests\Integration
if errorlevel 1 exit /b 1

%PHP_EXE% vendor\bin\phpunit tests\TenantIsolation
if errorlevel 1 exit /b 1

%PHP_EXE% tools\secure-sdlc-gate-evaluate.php
if errorlevel 1 exit /b 1
```

---

### 24. Security Requirement Service Reference

```php
final class SecurityRequirementService
    implements SecurityRequirementServiceInterface
{
    public function register(
        SecurityRequirementCommand $command,
        SecurityContext $context
    ): SecurityRequirement {
        $requirement = SecurityRequirement::create(
            id: $this->ids->ulid(),
            code: $command->code,
            featureCode: $command->featureCode,
            category: $command->category,
            statement: $command->statement,
            riskLevel: $command->riskLevel,
            ownerReference: $command->ownerReference,
            createdAt: $this->clock->now()
        );

        $this->requirements->save($requirement);

        return $requirement;
    }
}
```

---

### 25. Threat Model Service Reference

```php
final class ThreatModelService
    implements ThreatModelServiceInterface
{
    public function evaluate(
        ThreatModelCommand $command,
        SecurityContext $context
    ): ThreatModel {
        $model = ThreatModel::create(
            id: $this->ids->ulid(),
            code: $command->code,
            scope: $command->scope,
            riskTier: $command->riskTier,
            ownerReference: $command->ownerReference
        );

        foreach ($command->threats as $threatInput) {
            $model->addThreat(
                Threat::create(
                    id: $this->ids->ulid(),
                    category: $threatInput->category,
                    scenario: $threatInput->scenario,
                    likelihood: $threatInput->likelihood,
                    impact: $threatInput->impact,
                    risk: $this->risk->calculate(
                        $threatInput->likelihood,
                        $threatInput->impact
                    ),
                    controls: $threatInput->controls
                )
            );
        }

        $this->models->save($model);

        return $model;
    }
}
```

---

### 26. Finding Management Reference

```php
final class FindingManagementService
    implements FindingManagementServiceInterface
{
    public function ingest(
        FindingIngestCommand $command,
        SecurityContext $context
    ): SecurityFinding {
        $normalized = $this->normalizer->normalize(
            $command
        );

        $existing = $this->findings->findDuplicate(
            $normalized
        );

        if ($existing !== null) {
            $existing->refresh(
                evidence: $normalized->evidence,
                detectedAt: $this->clock->now()
            );

            $this->findings->save($existing);

            return $existing;
        }

        $finding = SecurityFinding::create(
            id: $this->ids->ulid(),
            source: $normalized->source,
            title: $normalized->title,
            severity: $normalized->severity,
            component: $normalized->component,
            ownerReference: $normalized->ownerReference,
            dueAt: $this->sla->dueAt(
                $normalized->severity,
                $this->clock->now()
            ),
            detectedAt: $this->clock->now()
        );

        $this->findings->save($finding);

        return $finding;
    }
}
```

---

### 27. Release Gate Service Reference

```php
final class ReleaseGateService
    implements ReleaseGateServiceInterface
{
    public function evaluate(
        SecureRelease $release,
        SecurityContext $context
    ): ReleaseGateResult {
        $evidence = $this->evidence->forRelease(
            $release->id()
        );

        $findings = $this->findings->forRelease(
            $release->id()
        );

        $exceptions = $this->exceptions->activeForRelease(
            $release->id(),
            $this->clock->now()
        );

        $results = [];

        foreach ($this->policies->forRelease($release) as $policy) {
            $results[] = $this->evaluator->evaluate(
                policy: $policy,
                release: $release,
                evidence: $evidence,
                findings: $findings,
                exceptions: $exceptions
            );
        }

        return ReleaseGateResult::fromResults(
            releaseId: $release->id(),
            results: $results
        );
    }
}
```

---

### 28. Artifact Integrity Service Reference

```php
final class ArtifactIntegrityService
    implements ArtifactIntegrityServiceInterface
{
    public function verify(
        string $artifactId,
        SecurityContext $context
    ): ArtifactVerificationResult {
        $artifact = $this->artifacts->findById(
            $artifactId
        );

        if ($artifact === null) {
            throw new ArtifactNotFoundException();
        }

        $actualHash = $this->hashes->sha256File(
            $artifact->storageReference()
        );

        if (!hash_equals(
            $artifact->sha256(),
            $actualHash
        )) {
            $this->events->record(
                SecurityEvent::artifactHashMismatch(
                    artifactId: $artifact->id(),
                    context: $context
                )
            );

            return ArtifactVerificationResult::failed(
                'HASH_MISMATCH'
            );
        }

        return $this->signatures->verify($artifact);
    }
}
```

---

### 29. SBOM Service Reference

```php
final class SbomService
    implements SbomServiceInterface
{
    public function validate(
        string $sbomId,
        SecurityContext $context
    ): SbomValidationResult {
        $sbom = $this->sboms->findById($sbomId);

        if ($sbom === null) {
            throw new SbomNotFoundException();
        }

        $document = $this->documents->read(
            $sbom->documentReference()
        );

        $result = $this->validator->validate(
            format: $sbom->format(),
            document: $document
        );

        $sbom->recordValidation(
            result: $result,
            validatedAt: $this->clock->now()
        );

        $this->sboms->save($sbom);

        return $result;
    }
}
```

---

### 30. Environment Promotion Reference

```php
final class EnvironmentPromotionService
    implements EnvironmentPromotionServiceInterface
{
    public function execute(
        string $promotionId,
        SecurityContext $context
    ): EnvironmentPromotion {
        $promotion = $this->promotions->findById(
            $promotionId
        );

        if ($promotion === null) {
            throw new PromotionNotFoundException();
        }

        $this->authorization->assertAllowed(
            AuthorizationRequest::permission(
                'secure_sdlc.promotion.execute'
            ),
            $context
        );

        $verification = $this->artifacts->verify(
            $promotion->artifactId(),
            $context
        );

        if (!$verification->isValid()) {
            throw new ArtifactVerificationFailedException();
        }

        $gate = $this->gates->evaluateRelease(
            $promotion->releaseId(),
            $context
        );

        if (!$gate->allowsPromotion()) {
            throw new ReleaseGateFailedException();
        }

        $promotion->markExecuting(
            $this->clock->now()
        );

        $this->promotions->save($promotion);

        return $promotion;
    }
}
```

---

### 31. Deployment Verification Reference

```php
final class SecureDeploymentService
    implements SecureDeploymentServiceInterface
{
    public function verify(
        string $deploymentId,
        SecurityContext $context
    ): DeploymentVerificationResult {
        $deployment = $this->deployments->findById(
            $deploymentId
        );

        if ($deployment === null) {
            throw new DeploymentNotFoundException();
        }

        $checks = [
            $this->checks->artifact($deployment),
            $this->checks->configuration($deployment),
            $this->checks->database($deployment),
            $this->checks->health($deployment),
            $this->checks->authentication($deployment),
            $this->checks->authorization($deployment),
            $this->checks->tenantIsolation($deployment),
            $this->checks->securityEvents($deployment),
        ];

        return DeploymentVerificationResult::fromChecks(
            $checks
        );
    }
}
```

---

### 32. Pipeline Gate Evaluation Pseudocode

```text
Load Release
→ Validate Artifact
→ Validate Signature
→ Validate SBOM
→ Load Test Evidence
→ Load Open Findings
→ Validate Exceptions
→ Evaluate Policies
→ Require Approval
→ Issue Decision
```

---

### 33. Initial Database Migration Order

```text
1. sec_sdlc_security_requirements
2. sec_sdlc_threat_models
3. sec_sdlc_threats
4. sec_sdlc_security_reviews
5. sec_sdlc_test_plans
6. sec_sdlc_test_cases
7. sec_sdlc_test_results
8. sec_sdlc_findings
9. sec_sdlc_finding_events
10. sec_sdlc_pipelines
11. sec_sdlc_pipeline_runs
12. sec_sdlc_pipeline_stages
13. sec_sdlc_builds
14. sec_sdlc_artifacts
15. sec_sdlc_artifact_signatures
16. sec_sdlc_sboms
17. sec_sdlc_sbom_components
18. sec_sdlc_releases
19. sec_sdlc_release_gates
20. sec_sdlc_release_findings
21. sec_sdlc_release_exceptions
22. sec_sdlc_promotions
23. sec_sdlc_deployments
24. sec_sdlc_deployment_events
25. sec_sdlc_rollbacks
26. sec_sdlc_evidence
27. sec_sdlc_drift_findings
28. sec_sdlc_scheduler_runs
```

---

### 34. Seed Permissions

```text
secure_sdlc.requirement.read
secure_sdlc.requirement.manage
secure_sdlc.threat_model.read
secure_sdlc.threat_model.manage
secure_sdlc.review.read
secure_sdlc.review.manage
secure_sdlc.test_plan.read
secure_sdlc.test_plan.manage
secure_sdlc.finding.read
secure_sdlc.finding.manage
secure_sdlc.finding.verify
secure_sdlc.pipeline.read
secure_sdlc.pipeline.manage
secure_sdlc.artifact.read
secure_sdlc.artifact.manage
secure_sdlc.artifact.sign
secure_sdlc.sbom.read
secure_sdlc.sbom.manage
secure_sdlc.release.read
secure_sdlc.release.manage
secure_sdlc.release.approve
secure_sdlc.gate.override
secure_sdlc.promotion.request
secure_sdlc.promotion.approve
secure_sdlc.promotion.execute
secure_sdlc.deployment.read
secure_sdlc.deployment.execute
secure_sdlc.rollback.request
secure_sdlc.rollback.approve
secure_sdlc.rollback.execute
secure_sdlc.evidence.read
secure_sdlc.evidence.export
secure_sdlc.drift.manage
```

---

### 35. Role Mapping

| Role | Capability |
|---|---|
| Application Security Administrator | Full Secure SDLC administration |
| Security Architect | Threat models and architecture approvals |
| Security Reviewer | Review and gate evaluation |
| Release Approver | Production release approval |
| Release Engineer | Build, artifact, promotion, deployment |
| QA Security Lead | Test plans and evidence |
| Finding Owner | Scoped remediation |
| Deployment Operator | Execute approved deployment |
| Rollback Approver | Approve critical rollback |
| Auditor | Read-only evidence and release history |

---

### 36. Configuration

```php
return [
    'enabled' => true,

    'risk_tiers' => [
        'default' => 'TIER_2',
        'critical_paths' => [
            'app/Platform/Security/',
            'app/Platform/Kernel/',
            'config/security',
            'database/migrations/',
        ],
    ],

    'gates' => [
        'fail_closed_on_unknown' => true,
        'critical_findings_allowed' => 0,
        'tenant_isolation_required' => true,
        'secret_scan_required' => true,
        'artifact_signature_required' => true,
        'sbom_required_for_production' => true,
    ],

    'artifacts' => [
        'storage_path' => dirname(__DIR__) . '/storage/secure-sdlc-artifacts',
        'hash_algorithm' => 'sha256',
        'immutable' => true,
    ],

    'evidence' => [
        'storage_path' => dirname(__DIR__) . '/storage/secure-sdlc-evidence',
        'checksum_algorithm' => 'sha256',
    ],

    'deployment' => [
        'production_approval_required' => true,
        'post_deploy_security_validation' => true,
        'rollback_artifact_required' => true,
    ],
];
```

---

### 37. Environment Variables

```text
SEC_SDLC_ENABLED=true
SEC_SDLC_FAIL_CLOSED_ON_UNKNOWN=true
SEC_SDLC_CRITICAL_FINDINGS_ALLOWED=0
SEC_SDLC_TENANT_TEST_REQUIRED=true
SEC_SDLC_SECRET_SCAN_REQUIRED=true
SEC_SDLC_ARTIFACT_SIGNATURE_REQUIRED=true
SEC_SDLC_SBOM_REQUIRED=true
SEC_SDLC_ARTIFACT_PATH=D:/xampp/htdocs/platform/storage/secure-sdlc-artifacts
SEC_SDLC_EVIDENCE_PATH=D:/xampp/htdocs/platform/storage/secure-sdlc-evidence
SEC_SDLC_PRODUCTION_APPROVAL_REQUIRED=true
SEC_SDLC_POST_DEPLOY_VALIDATION=true
```

---

### 38. Pre-Implementation Checklist

- [ ] SSOT-SEC-01 implemented sufficiently.
- [ ] Repository ownership defined.
- [ ] Branch protection available.
- [ ] CI runner selected.
- [ ] Scanner integrations selected.
- [ ] Tenant isolation test fixtures available.
- [ ] Artifact storage available.
- [ ] Signing mechanism selected.
- [ ] SBOM format selected.
- [ ] Release owner assigned.
- [ ] Deployment identity available.
- [ ] Rollback process documented.

---

### 39. Implementation Steps

```text
1. Create Secure SDLC module structure.
2. Create requirement and threat model registry.
3. Create test plan and finding registry.
4. Integrate secret scanning.
5. Integrate SAST.
6. Integrate dependency scanning.
7. Implement tenant isolation suite.
8. Implement release gate engine.
9. Implement artifact registration and hashing.
10. Implement artifact signing.
11. Implement SBOM registration.
12. Implement release workflow.
13. Implement promotion workflow.
14. Implement deployment verification.
15. Implement rollback workflow.
16. Enable scheduler and dashboards.
17. Run full UAT.
18. Move gates from MONITOR to ENFORCE.
```

---

### 40. Activation Strategy

```text
OFF
→ SHADOW
→ MONITOR
→ WARN
→ ENFORCE
```

#### SHADOW

- findings collected;
- gates evaluated;
- no blocking;
- false positives reviewed.

#### MONITOR

- dashboards active;
- owner assignment active;
- SLA tracking active;
- release recommendations generated.

#### WARN

- high-risk failures require documented acknowledgment;
- expired exceptions highlighted;
- insecure changes receive deadlines.

#### ENFORCE

- critical gates block;
- secret exposure blocks;
- tenant isolation failures block;
- invalid artifact signature blocks;
- missing SBOM blocks production;
- expired exception rejected.

---

### 41. Legacy Repository Adoption

For existing repositories:

```text
Inventory
→ Baseline
→ Classify Risks
→ Add Manifests
→ Add Scanners
→ Add Tests
→ Track Findings
→ Reduce Baseline
→ Enforce Gates
```

---

### 42. Legacy Finding Baseline

Baseline allowed only if:

- finding known;
- owner assigned;
- severity confirmed;
- deadline set;
- new findings not ignored;
- critical tenant/auth issues excluded.

---

### 43. Rollout by Module

Recommended order:

```text
Platform Kernel
→ Security/IAM
→ Patient/Clinical
→ Files/Exports
→ Billing
→ Integrations
→ Remaining Modules
```

---

### 44. Attack Simulation — Secret in Commit

Scenario:

Developer commits an active API key.

Expected:

- secret scan fails;
- merge blocked;
- key revoked and rotated;
- incident created if exposed;
- evidence recorded.

---

### 45. Attack Simulation — SQL Injection Regression

Scenario:

Developer concatenates request filter into SQL.

Expected:

- SAST finds issue;
- code review blocks;
- security test fails;
- no release artifact approved.

---

### 46. Attack Simulation — Cross-Tenant Repository Bug

Scenario:

Tenant filter removed from repository query.

Expected:

- tenant isolation tests fail;
- release gate rejects;
- finding created as critical;
- regression test retained.

---

### 47. Attack Simulation — Missing Authorization

Scenario:

New admin endpoint lacks permission check.

Expected:

- function-level authorization test fails;
- manual review detects;
- release blocked.

---

### 48. Attack Simulation — Malicious Dependency

Scenario:

Dependency includes known critical vulnerability.

Expected:

- dependency scan detects;
- SBOM correlation records;
- critical gate blocks;
- owner assigned;
- fixed version required.

---

### 49. Attack Simulation — Tampered Artifact

Scenario:

Artifact modified after signing.

Expected:

- checksum mismatch;
- signature invalid;
- deployment blocked;
- security alert and incident candidate.

---

### 50. Attack Simulation — Missing SBOM

Scenario:

Production release has no valid SBOM.

Expected:

- production gate fails;
- promotion denied;
- evidence records missing requirement.

---

### 51. Attack Simulation — Gate Override Abuse

Scenario:

Unauthorized user attempts to override failed gate.

Expected:

- authorization denied;
- event recorded;
- no release state change;
- alert for repeated attempts.

---

### 52. Attack Simulation — Expired Exception

Scenario:

Release uses security exception after expiry.

Expected:

- exception invalid;
- gate fails;
- release rejected.

---

### 53. Attack Simulation — CI Runner Secret Theft

Scenario:

Untrusted PR attempts to print protected environment variables.

Expected:

- protected secret not injected;
- runner isolation prevents access;
- suspicious action logged.

---

### 54. Attack Simulation — Unsigned Deployment

Scenario:

Operator tries to deploy an artifact without valid signature.

Expected:

- deployment rejected;
- alert created;
- no target state change.

---

### 55. Attack Simulation — Production Config Downgrade

Scenario:

Deployment enables debug or disables secure cookie.

Expected:

- configuration guard fails;
- deployment blocked/rolled back;
- finding created.

---

### 56. Attack Simulation — Manual Production Drift

Scenario:

Operator edits production file directly.

Expected:

- artifact/config drift detected;
- owner assigned;
- security alert;
- reconciliation or rollback required.

---

### 57. Attack Simulation — Rollback to Vulnerable Release

Scenario:

Previous release contains critical known vulnerability.

Expected:

- rollback risk evaluated;
- default rollback blocked or conditional emergency approval;
- compensating controls required;
- evidence preserved.

---

### 58. Attack Simulation — Scanner Unavailable

Scenario:

Required secret scanner fails to start.

Expected:

```text
UNKNOWN
```

Critical release gate fails closed.

---

### 59. Attack Simulation — Fake Test Evidence

Scenario:

A release references evidence from a different commit.

Expected:

- commit/build linkage mismatch;
- evidence rejected;
- release gate fails;
- security event recorded.

---

### 60. Attack Simulation — Self-Approval

Scenario:

Developer attempts sole approval of critical release.

Expected:

- segregation rule blocks;
- second approver required;
- audit event recorded.

---

### 61. Operational Runbook — Secret Detection

1. Stop pipeline.
2. Identify secret type.
3. Confirm whether active.
4. Revoke and rotate.
5. Remove from code and artifacts.
6. Assess repository/history exposure.
7. Create incident if needed.
8. Add detection pattern/test.
9. Re-run pipeline.
10. Preserve evidence.

---

### 62. Operational Runbook — Critical SAST Finding

1. Validate finding.
2. Determine exploitability.
3. Assign engineering owner.
4. Block release.
5. Fix root cause.
6. Add regression test.
7. Re-run scan.
8. Perform manual verification.
9. Store evidence.
10. Close after verification.

---

### 63. Operational Runbook — Dependency Vulnerability

1. Validate advisory.
2. Identify deployed releases.
3. Assess reachability and exposure.
4. Assign owner.
5. Upgrade or replace dependency.
6. Run compatibility/security tests.
7. Regenerate SBOM.
8. Deploy.
9. Verify correlation cleared.
10. Close finding.

---

### 64. Operational Runbook — Tenant Isolation Failure

1. Stop release.
2. Classify as critical.
3. Identify affected query/path.
4. Fix tenant/scope enforcement.
5. Add regression test.
6. Run full tenant suite.
7. Review similar repositories.
8. Assess deployed versions.
9. Create incident if exposure occurred.
10. Resume release only after verification.

---

### 65. Operational Runbook — Artifact Signature Failure

1. Block promotion/deployment.
2. Verify artifact hash.
3. Verify signature metadata.
4. Check signing key status.
5. Identify tampering or process error.
6. Rebuild from trusted source if needed.
7. Sign new artifact.
8. Re-run release gates.
9. Create incident if tampering suspected.
10. Preserve original evidence.

---

### 66. Operational Runbook — SBOM Failure

1. Stop production gate.
2. Verify SBOM format.
3. Regenerate from final artifact.
4. Validate component count.
5. Recalculate checksum.
6. Re-run vulnerability correlation.
7. Attach evidence.
8. Resume gate evaluation.

---

### 67. Operational Runbook — Failed Production Deployment

1. Freeze further changes.
2. Assess health and security impact.
3. Determine rollback or roll-forward.
4. Preserve deployment logs.
5. Execute approved recovery.
6. Verify artifact/config/database state.
7. Run post-recovery security checks.
8. Notify stakeholders.
9. Create incident/problem record.
10. Perform post-implementation review.

---

### 68. Operational Runbook — Configuration Drift

1. Confirm expected state.
2. Compare deployed state.
3. Identify operator/process.
4. Assess security impact.
5. Reconcile from source.
6. Rotate credentials if exposed.
7. Verify application.
8. Record finding and audit.
9. Update prevention controls.
10. Close after verification.

---

### 69. Operational Runbook — Pipeline Compromise

1. Stop pipelines.
2. Revoke CI credentials.
3. Disable affected runners.
4. Preserve logs and artifacts.
5. Identify compromised builds.
6. Revoke affected releases/artifacts.
7. Rotate signing credentials if needed.
8. Rebuild from trusted baseline.
9. Revalidate deployed environments.
10. Conduct incident review.

---

### 70. Operational Runbook — Scanner Failure

1. Confirm tool/service failure.
2. Mark result UNKNOWN.
3. Fail closed for critical gate.
4. Check fallback/manual procedure.
5. Restore scanner.
6. Re-run scan.
7. Reconcile missed commits/builds.
8. Document outage and evidence.

---

### 71. Operational Runbook — Expired Security Exception

1. Block release/use.
2. Notify owner.
3. Reassess risk.
4. Verify remediation status.
5. Close exception if fixed.
6. Create new exception only with fresh approval.
7. Never silently extend.
8. Record audit.

---

### 72. Operational Runbook — Rollback

1. Confirm rollback trigger.
2. Verify previous artifact and signature.
3. Review vulnerability status of target release.
4. Check database compatibility.
5. Approve rollback.
6. Execute.
7. Verify security and health.
8. Reconcile configuration/schema.
9. Record evidence.
10. Open corrective action.

---

### 73. Final UAT — Governance & Requirements

- [ ] Secure SDLC owners assigned.
- [ ] Risk tiers applied.
- [ ] Module manifests available.
- [ ] Feature manifests available.
- [ ] Security requirements are traceable.
- [ ] Threat models are approved.
- [ ] Security reviews are recorded.
- [ ] Exceptions are time-bound.
- [ ] Evidence ownership exists.
- [ ] Dashboards are available.

---

### 74. Final UAT — Secure Coding

- [ ] PHP strict typing used.
- [ ] Input DTOs used.
- [ ] Output encoding works.
- [ ] Prepared statements used.
- [ ] No unsafe deserialization.
- [ ] No unsafe shell execution.
- [ ] Authentication controls work.
- [ ] Authorization is server-side.
- [ ] Tenant/scope guards work.
- [ ] Session controls work.
- [ ] File controls work.
- [ ] Secrets are not hard-coded.
- [ ] Errors/logs are safe.

---

### 75. Final UAT — Security Testing

- [ ] SAST runs.
- [ ] Dependency scanning runs.
- [ ] Secret scanning runs.
- [ ] DAST runs where required.
- [ ] Tenant isolation suite passes.
- [ ] Authentication tests pass.
- [ ] Authorization tests pass.
- [ ] API abuse tests pass.
- [ ] File security tests pass.
- [ ] Fuzzing/manual tests run where required.
- [ ] Penetration testing criteria are met.
- [ ] Regression tests exist for critical fixes.

---

### 76. Final UAT — Findings & Remediation

- [ ] Findings are normalized.
- [ ] Duplicate detection works.
- [ ] Severity is consistent.
- [ ] Owners and deadlines exist.
- [ ] Triage SLA works.
- [ ] Remediation SLA works.
- [ ] Risk acceptance is controlled.
- [ ] False positives require evidence.
- [ ] Verification is required before closure.
- [ ] Overdue alerts work.

---

### 77. Final UAT — Source & Pipeline Security

- [ ] Protected branches active.
- [ ] Required reviewers active.
- [ ] Sensitive paths protected.
- [ ] Untrusted PRs cannot access secrets.
- [ ] CI runners are isolated.
- [ ] CI credentials are least privilege.
- [ ] Required pipeline stages run.
- [ ] Tool failure is not treated as PASS.
- [ ] Gate overrides are audited.
- [ ] Pipeline history is retained.

---

### 78. Final UAT — Artifact & Supply Chain

- [ ] Artifact is immutable.
- [ ] SHA-256 checksum exists.
- [ ] Artifact signing works.
- [ ] Invalid signature blocks deployment.
- [ ] Provenance is available.
- [ ] SBOM is generated.
- [ ] SBOM validation works.
- [ ] Vulnerability correlation works.
- [ ] Release evidence package is complete.
- [ ] Signing key access is restricted.

---

### 79. Final UAT — Release & Promotion

- [ ] Critical findings block release.
- [ ] Secret findings block release.
- [ ] Tenant test failure blocks release.
- [ ] Expired exception blocks release.
- [ ] Production approval is required.
- [ ] Self-approval restriction works.
- [ ] Same artifact is promoted.
- [ ] Promotion token is scoped.
- [ ] Unauthorized promotion is denied.
- [ ] Promotion history is preserved.

---

### 80. Final UAT — Deployment & Rollback

- [ ] Artifact verified before deployment.
- [ ] Production configuration guard works.
- [ ] Migration is approved and tested.
- [ ] Backup readiness is checked.
- [ ] Health/readiness checks pass.
- [ ] Post-deployment security validation runs.
- [ ] Previous artifact is available.
- [ ] Rollback is tested.
- [ ] Rollback evidence is retained.
- [ ] Drift detection works.
- [ ] Manual production change is reconciled.
- [ ] Rollback to vulnerable release is controlled.

---

### 81. Production Readiness Checklist

- [ ] SSOT-SEC-01 controls are available.
- [ ] Secure SDLC kernel implemented.
- [ ] Security manifests validated.
- [ ] Requirement registry active.
- [ ] Threat model workflow active.
- [ ] Code review checklist active.
- [ ] SAST active.
- [ ] Dependency scanning active.
- [ ] Secret scanning active.
- [ ] Tenant isolation tests active.
- [ ] DAST/manual testing process active.
- [ ] Finding management active.
- [ ] Release gates active.
- [ ] Artifact integrity active.
- [ ] Signing active.
- [ ] SBOM active.
- [ ] Promotion workflow active.
- [ ] Deployment verification active.
- [ ] Rollback workflow active.
- [ ] Scheduler active.
- [ ] Metrics and alerts active.
- [ ] Final UAT passed.
- [ ] Operations sign-off available.

---

### 82. Ownership Matrix

| Area | Owner |
|---|---|
| Secure SDLC Framework | Application Security |
| Security Requirements | Module Owner + AppSec |
| Threat Modeling | Security Architecture |
| Secure Coding Standard | Application Security |
| Security Testing | AppSec + QA |
| Tenant Isolation Suite | Platform Architecture + QA |
| Vulnerability Triage | Security Operations |
| Remediation | Engineering Owner |
| Release Gates | Release Governance |
| Artifact Integrity | Release Engineering |
| Signing | Security/Release Engineering |
| SBOM | Application Security |
| CI/CD Security | DevOps/Platform Engineering |
| Deployment Security | Release Engineering |
| Rollback | Operations + Release Governance |
| Evidence | Compliance/AppSec |

---

### 83. Definition of Done — SSOT-SEC-02

#### Secure SDLC Foundation

- [ ] objectives;
- [ ] lifecycle;
- [ ] risk tiers;
- [ ] requirements;
- [ ] threat modeling;
- [ ] architecture reviews;
- [ ] security gates;
- [ ] ownership;
- [ ] metrics.

#### Secure Coding

- [ ] PHP;
- [ ] HTML/JavaScript;
- [ ] SQL/PDO;
- [ ] authentication;
- [ ] authorization;
- [ ] tenant isolation;
- [ ] sessions;
- [ ] CSRF;
- [ ] APIs;
- [ ] files;
- [ ] cryptography;
- [ ] secrets;
- [ ] errors/logging;
- [ ] concurrency/jobs.

#### Security Testing

- [ ] SAST;
- [ ] dependency scan;
- [ ] secret scan;
- [ ] DAST;
- [ ] tenant isolation suite;
- [ ] authorization tests;
- [ ] API/file tests;
- [ ] fuzzing;
- [ ] penetration testing;
- [ ] finding lifecycle;
- [ ] SLA;
- [ ] evidence/reporting.

#### Secure Delivery

- [ ] source protections;
- [ ] runner security;
- [ ] pipeline stages;
- [ ] build integrity;
- [ ] artifact checksums;
- [ ] signing;
- [ ] provenance;
- [ ] SBOM;
- [ ] release gates;
- [ ] promotion;
- [ ] deployment;
- [ ] migration security;
- [ ] rollback;
- [ ] drift detection;
- [ ] scheduler;
- [ ] APIs/schema.

#### Reference Implementation

- [ ] manifests;
- [ ] policies;
- [ ] service references;
- [ ] pipeline examples;
- [ ] attack simulations;
- [ ] runbooks;
- [ ] final UAT;
- [ ] production readiness;
- [ ] roadmap;
- [ ] merge guidance.

---

### 84. Implementation Definition of Done

Implementation selesai bila:

- [ ] Secure SDLC module created;
- [ ] database migrations succeed;
- [ ] permissions and roles seeded;
- [ ] requirement registry active;
- [ ] threat model workflow active;
- [ ] security review workflow active;
- [ ] SAST integrated;
- [ ] dependency scanning integrated;
- [ ] secret scanning integrated;
- [ ] tenant isolation suite integrated;
- [ ] DAST/manual test workflow active;
- [ ] finding registry active;
- [ ] release gate engine active;
- [ ] artifact integrity active;
- [ ] signing active;
- [ ] SBOM active;
- [ ] promotion active;
- [ ] deployment verification active;
- [ ] rollback active;
- [ ] scheduler active;
- [ ] metrics/alerts active;
- [ ] unit tests pass;
- [ ] integration tests pass;
- [ ] security tests pass;
- [ ] UAT passes;
- [ ] performance targets met;
- [ ] deployment/rollback tested;
- [ ] operations sign-off available.

---

### 85. Roadmap

#### Phase 1 — Secure Development Baseline

- security requirements;
- secure coding checklist;
- code review;
- secret scanning;
- dependency scanning;
- SAST;
- basic findings registry.

#### Phase 2 — Managed Application Security

- threat models;
- tenant isolation suite;
- DAST;
- release gates;
- SLA tracking;
- security evidence;
- dashboards.

#### Phase 3 — Secure Supply Chain

- artifact immutability;
- checksums;
- signing;
- provenance;
- SBOM;
- promotion workflow;
- drift detection.

#### Phase 4 — Continuous Security Assurance

- policy-as-code;
- automated release decisions;
- continuous vulnerability correlation;
- advanced testing;
- continuous authorization verification;
- adaptive risk gates;
- automated rollback guardrails.

---

### 86. Future Evolution

- WebAuthn-aware security testing;
- advanced SAST custom rules;
- interactive application security testing;
- automated API schema fuzzing;
- mutation testing for security controls;
- dynamic tenant test generation;
- binary/artifact transparency log;
- hardware-backed signing;
- centralized SBOM service;
- continuous dependency reachability;
- automated exploitability scoring;
- policy engine integration;
- supply-chain attestations;
- continuous compliance evidence;
- AI-assisted threat modeling;
- AI-assisted vulnerability triage with human approval.

---

### 87. Merge Guidance

Gabungkan:

```text
SSOT-SEC-02-Part-1.md
SSOT-SEC-02-Part-2.md
SSOT-SEC-02-Part-3.md
SSOT-SEC-02-Part-4.md
SSOT-SEC-02-Part-5.md
```

menjadi:

```text
SSOT-SEC-02.md
```

Urutan:

```text
Part 1 — Secure SDLC Foundation
Part 2 — Detailed Secure Coding Standard
Part 3 — Security Testing Framework
Part 4 — Secure Delivery & Release Assurance
Part 5 — Reference Implementation & Operational Readiness
```

---

### 88. Merge Quality Checklist

- [ ] heading tidak duplikat;
- [ ] terminology konsisten;
- [ ] risk tiers konsisten;
- [ ] policy codes konsisten;
- [ ] permission names konsisten;
- [ ] table names konsisten;
- [ ] endpoint paths konsisten;
- [ ] finding states konsisten;
- [ ] release/gate states konsisten;
- [ ] artifact/SBOM terminology konsisten;
- [ ] duplicate sections dihapus;
- [ ] temporary roadmap sections dibersihkan;
- [ ] metadata final diperbarui;
- [ ] daftar isi dibuat;
- [ ] status final diset Draft for Review/Approved.

---

### 89. Final Metadata

```yaml
document_code: SSOT-SEC-02
title: Secure SDLC & Application Security Framework
version: 1.0
status: Draft for Review
domain: Platform Kernel
category: Secure Software Development & Application Security
owners:
  - Application Security
  - Security Architecture
  - Platform Architecture
  - Release Engineering
  - Security Operations
reviewers:
  - Backend Engineering
  - Frontend Engineering
  - QA
  - DevOps
  - Database Administration
  - Module Owners
  - Infrastructure Operations
```

---

### 90. Approval Gate

Dokumen dapat menjadi Approved setelah:

- Secure SDLC governance review;
- secure coding standard review;
- threat modeling review;
- SAST/dependency/secret scan review;
- tenant isolation test review;
- DAST/manual testing review;
- penetration testing process review;
- vulnerability management review;
- release gate review;
- artifact integrity and signing review;
- SBOM review;
- CI/CD runner security review;
- deployment and migration security review;
- rollback and drift review;
- database schema review;
- QA/UAT review;
- operations sign-off.

---

### 91. Closing Statement

Secure SDLC harus memastikan setiap requirement, threat, code change, test result, finding, artifact, SBOM, release, promotion, deployment, dan rollback:

- memiliki owner;
- memiliki evidence;
- memiliki lifecycle;
- dapat diaudit;
- dapat diverifikasi;
- dapat diblokir saat tidak aman;
- dapat dipulihkan;
- dapat ditingkatkan.

Framework tidak boleh:

- mengandalkan scanner sebagai satu-satunya kontrol;
- menganggap code review cukup tanpa testing;
- mengizinkan critical finding pada production release;
- mengizinkan secret aktif masuk source atau artifact;
- melewati tenant isolation test;
- mempromosikan artifact berbeda antar environment;
- menyebarkan artifact tanpa verification;
- menonaktifkan release gate tanpa exception dan audit;
- menutup finding tanpa verification;
- menjalankan rollback tanpa menilai risiko release target.

Secure SDLC adalah capability platform yang menghubungkan desain, coding, testing, supply chain, release, deployment, dan operation dalam satu control system yang konsisten.

---

## Lampiran A — Sumber Penggabungan

Dokumen final ini digabung dan dinormalisasi dari:

- `SSOT-SEC-02-Part-1.md`
- `SSOT-SEC-02-Part-2.md`
- `SSOT-SEC-02-Part-3.md`
- `SSOT-SEC-02-Part-4.md`
- `SSOT-SEC-02-Part-5.md`

## Lampiran B — Approval Gate

Status dokumen dapat diubah menjadi **Approved** setelah:

- Secure SDLC governance review selesai;
- secure coding standard review selesai;
- security requirements dan threat modeling review selesai;
- SAST, dependency scanning, dan secret scanning review selesai;
- tenant isolation test review selesai;
- DAST, fuzzing, manual security testing, dan penetration testing process review selesai;
- vulnerability triage, remediation SLA, risk acceptance, dan verification review selesai;
- CI/CD runner dan pipeline security review selesai;
- artifact integrity, signing, provenance, dan SBOM review selesai;
- release gate, promotion, dan deployment security review selesai;
- migration, rollback, dan drift detection review selesai;
- APIs, database schema, scheduler, audit, metrics, dan alerting review selesai;
- QA/UAT review selesai;
- performance review selesai;
- deployment dan rollback simulation selesai;
- operations sign-off tersedia.
