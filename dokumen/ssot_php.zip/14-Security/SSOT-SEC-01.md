# SSOT-SEC-01 — Security Implementation Framework

> Single Source of Truth untuk security architecture, identity, authentication, authorization, tenant isolation, data protection, cryptography, secrets, secure storage, vulnerability management, security operations, incident response, dan operational readiness pada Platform Kernel.

## Metadata Dokumen

| Item | Nilai |
|---|---|
| Kode | SSOT-SEC-01 |
| Judul | Security Implementation Framework |
| Versi | 1.0 |
| Status | Draft for Review |
| Domain | Platform Kernel |
| Kategori | Security Architecture & Implementation |
| Target Stack | PHP 8.1+, PDO, MySQL 8/MariaDB, Apache/XAMPP, Modular Monolith |
| Integrasi | RBAC, Audit Trail, Observability, Secrets, Encryption, OWASP, HIPAA-oriented Controls |
| Pemilik | Security Architecture, Platform Architecture, Security Operations, Compliance |
| Reviewer | Backend Engineering, Frontend Engineering, DevOps, Database Administration, QA, Service Owners, Infrastructure Operations |

## Tujuan Dokumen

Dokumen ini menetapkan standar tunggal untuk:

- security vision, architecture, control domains, trust boundaries, ownership, baseline controls, governance, threat model, maturity, UAT, dan Definition of Done;
- identity, authentication, authorization, session security, tenant/scope isolation, privileged access, account lifecycle, access review, service accounts, API credentials, dan policy-as-code;
- data protection, encryption, key management, secrets management, secure storage, database security, file security, backup security, retention, legal hold, privacy, dan evidence integrity;
- HTTP middleware, controllers, security services, database schema, secure configuration, Apache/PHP hardening, security event pipeline, vulnerability management, scheduler, incident integration, APIs, dan sequence diagrams;
- reference implementation, sample policies, migration, deployment, rollback, attack simulations, security test plan, operational runbooks, final UAT, dan roadmap.

## Daftar Isi

1. Bagian I — Security Foundation
2. Bagian II — Identity & Access Security
3. Bagian III — Data Protection & Cryptography
4. Bagian IV — Security Infrastructure & Operations
5. Bagian V — Reference Implementation & Operational Readiness
6. Lampiran A — Sumber Penggabungan
7. Lampiran B — Approval Gate

## Status Normatif

Kata **wajib**, **harus**, dan **tidak boleh** menyatakan persyaratan normatif. Kata **direkomendasikan**, **sebaiknya**, dan **dapat** menyatakan panduan yang dapat disesuaikan melalui keputusan arsitektur terdokumentasi.

---

## Bagian I — Security Foundation

### 1. Executive Summary

SSOT-SEC-01 menetapkan framework implementasi keamanan untuk Platform Kernel.

Framework ini menyatukan:

```text
Identity & Access Management
Authentication
Authorization
Session Security
Tenant & Scope Isolation
Data Protection
Encryption
Secrets Management
Secure Configuration
Application Security
API Security
Database Security
Infrastructure Security
Logging & Audit
Monitoring & Detection
Incident Response
Vulnerability Management
Backup & Recovery
Privacy
Compliance
Security Governance
```

Tujuan utamanya adalah memastikan keamanan:

- dibangun sejak desain;
- terintegrasi dengan kernel;
- tidak bergantung pada satu module bisnis;
- memiliki owner;
- memiliki evidence;
- dapat diuji;
- dapat diaudit;
- dapat dioperasikan;
- dapat ditingkatkan;
- konsisten antar tenant, organization, clinic, dan module.

---

### 2. Security Objective

Framework harus melindungi:

- confidentiality;
- integrity;
- availability;
- authenticity;
- accountability;
- privacy;
- resilience;
- tenant isolation;
- business continuity.

---

### 3. Security Principles

```text
Secure by Design
Secure by Default
Least Privilege
Zero Trust
Defense in Depth
Fail Secure
Explicit Authorization
Complete Mediation
Separation of Duties
Data Minimization
Tenant Isolation
Auditability
Recoverability
```

---

### 4. Secure by Design

Keamanan harus ditentukan sebelum implementasi.

Setiap capability wajib menjawab:

- aset apa yang dilindungi;
- siapa aktornya;
- trust boundary;
- attack surface;
- authorization rule;
- data classification;
- failure mode;
- logging/audit;
- recovery.

---

### 5. Secure by Default

Default harus aman.

Contoh:

```text
access denied by default
debug disabled in production
directory listing disabled
secure cookie enabled
cross-tenant access denied
sensitive export disabled
unknown role has no permissions
```

---

### 6. Least Privilege

Setiap user, service, process, dan credential hanya memiliki akses minimum yang dibutuhkan.

---

### 7. Zero Trust

Jangan mempercayai:

- network location;
- internal request;
- client-provided tenant;
- client-provided role;
- forwarded headers;
- uploaded file;
- integration payload;
- administrator identity tanpa re-authentication.

---

### 8. Defense in Depth

Kontrol diterapkan pada beberapa layer:

```text
UI
HTTP Middleware
Controller
Application Service
Domain Policy
Repository
Database
Infrastructure
Monitoring
Audit
```

---

### 9. Fail Secure

Saat kontrol keamanan gagal, sistem harus:

- deny;
- stop privileged operation;
- preserve evidence;
- create alert;
- avoid silent bypass.

---

### 10. Explicit Authorization

Authentication tidak sama dengan authorization.

Setiap privileged action wajib melewati permission dan scope check.

---

### 11. Complete Mediation

Authorization harus diperiksa setiap kali resource diakses, bukan hanya saat login atau menu ditampilkan.

---

### 12. Separation of Duties

Contoh:

- requestor bukan approver;
- developer bukan production secret custodian;
- auditor read-only;
- database admin tidak otomatis dapat decrypt application data;
- security admin tidak otomatis dapat mengubah audit evidence.

---

### 13. Security Scope

Framework mencakup:

```text
Platform Kernel
SDK Modules
Business Modules
Internal APIs
External APIs
Web Applications
Background Workers
Schedulers
Database
File Storage
Integrations
Observability
Deployment
Operations
```

---

### 14. Non-Goals Part 1

Part 1 belum mendefinisikan detail:

- exact database schema;
- full middleware code;
- key management implementation;
- secrets rotation engine;
- vulnerability scanning pipeline;
- incident response automation;
- compliance evidence automation.

Hal tersebut dibahas pada Part 2–5.

---

### 15. Security Architecture Overview

```text
User / Service / Integration
            │
            ▼
Edge Security
            │
            ├── TLS
            ├── Reverse Proxy
            ├── Security Headers
            ├── Rate Limit
            └── Request Size Limits
            │
            ▼
Application Security Layer
            │
            ├── Authentication
            ├── Session Security
            ├── Tenant Context
            ├── Scope Context
            ├── Authorization
            ├── CSRF
            ├── Input Validation
            └── Audit Context
            │
            ▼
Domain Security Layer
            │
            ├── Business Policy
            ├── Ownership Rules
            ├── Sensitive Operation Guard
            └── Segregation of Duties
            │
            ▼
Data Security Layer
            │
            ├── Encryption
            ├── Row/Scope Filtering
            ├── Secrets Isolation
            ├── Backup Protection
            └── Retention
            │
            ▼
Security Operations
            ├── Logging
            ├── Detection
            ├── Alerting
            ├── Incident Response
            └── Recovery
```

---

### 16. Security Control Domains

```text
SEC-IAM
SEC-AUTHN
SEC-AUTHZ
SEC-SESSION
SEC-TENANT
SEC-DATA
SEC-CRYPTO
SEC-SECRETS
SEC-APP
SEC-API
SEC-DB
SEC-FILE
SEC-INFRA
SEC-LOGGING
SEC-AUDIT
SEC-MONITORING
SEC-INCIDENT
SEC-VULNERABILITY
SEC-BACKUP
SEC-PRIVACY
SEC-COMPLIANCE
SEC-GOVERNANCE
```

---

### 17. IAM Domain

Mencakup:

- user identity;
- service identity;
- role;
- permission;
- role assignment;
- organization/clinic binding;
- lifecycle;
- joiner/mover/leaver;
- privileged access.

---

### 18. Authentication Domain

Mencakup:

- password policy;
- MFA;
- service authentication;
- account lockout;
- login throttling;
- identity verification;
- re-authentication.

---

### 19. Authorization Domain

Mencakup:

- deny by default;
- permission evaluation;
- resource ownership;
- tenant;
- organization;
- clinic;
- department;
- context;
- sensitive action approval.

---

### 20. Session Security Domain

Mencakup:

- secure cookie;
- session ID rotation;
- inactivity timeout;
- absolute timeout;
- concurrent session policy;
- logout;
- revocation;
- device/session listing.

---

### 21. Tenant Isolation Domain

Mencakup:

- tenant context;
- scope binding;
- row filtering;
- cache isolation;
- file isolation;
- queue/message isolation;
- audit segregation;
- cross-tenant guard.

---

### 22. Data Protection Domain

Mencakup:

- classification;
- minimization;
- masking;
- encryption;
- tokenization;
- secure export;
- retention;
- disposal.

---

### 23. Cryptography Domain

Mencakup:

- encryption at rest;
- encryption in transit;
- key lifecycle;
- key rotation;
- algorithm policy;
- signing;
- hashing;
- random generation.

---

### 24. Secrets Management Domain

Mencakup:

- environment secrets;
- database credentials;
- API keys;
- encryption keys;
- signing keys;
- rotation;
- revocation;
- access audit.

---

### 25. Application Security Domain

Mencakup:

- input validation;
- output encoding;
- CSRF;
- XSS;
- SQL injection;
- command injection;
- path traversal;
- SSRF;
- deserialization;
- upload security;
- error handling.

---

### 26. API Security Domain

Mencakup:

- authentication;
- authorization;
- rate limit;
- schema validation;
- idempotency;
- replay protection;
- request signing optional;
- versioning;
- error minimization.

---

### 27. Database Security Domain

Mencakup:

- least privilege;
- parameterized queries;
- credential separation;
- backup encryption;
- database audit;
- schema migration control;
- restricted administration.

---

### 28. File Security Domain

Mencakup:

- upload validation;
- MIME validation;
- size limit;
- malware scan;
- storage outside public path;
- random filenames;
- authorization on download;
- expiry;
- evidence preservation.

---

### 29. Infrastructure Security Domain

Mencakup:

- Apache hardening;
- PHP hardening;
- OS permissions;
- network segmentation;
- TLS;
- patching;
- service accounts;
- secure deployment.

---

### 30. Logging & Audit Domain

Mencakup:

- security event;
- audit trail;
- immutable records;
- no secret leakage;
- correlation;
- access monitoring;
- retention.

---

### 31. Monitoring & Detection Domain

Mencakup:

- suspicious login;
- privilege escalation;
- cross-tenant attempt;
- export anomaly;
- credential abuse;
- integrity failure;
- malware indicator;
- unusual access.

---

### 32. Incident Response Domain

Mencakup:

- detection;
- triage;
- containment;
- eradication;
- recovery;
- evidence;
- communication;
- post-incident review.

---

### 33. Vulnerability Management Domain

Mencakup:

- dependency inventory;
- vulnerability scanning;
- severity;
- remediation SLA;
- exception;
- verification;
- reporting.

---

### 34. Backup & Recovery Domain

Mencakup:

- encrypted backup;
- access restriction;
- restore test;
- RPO/RTO;
- ransomware resilience;
- key availability;
- integrity verification.

---

### 35. Privacy Domain

Mencakup:

- purpose limitation;
- consent where applicable;
- minimization;
- access;
- correction;
- export;
- deletion;
- retention;
- audit.

---

### 36. Compliance Domain

Framework dapat mendukung requirement-oriented controls untuk:

- HIPAA-oriented safeguards;
- ISO 27001 alignment;
- OWASP ASVS;
- OWASP Top 10;
- NIST-aligned security practices;
- local privacy obligations.

Dokumen ini tidak otomatis menyatakan sertifikasi atau legal compliance.

---

### 37. Security Governance Domain

Mencakup:

- policy;
- ownership;
- exception;
- review;
- risk;
- evidence;
- maturity;
- audit;
- roadmap.

---

### 38. Asset Categories

```text
IDENTITY
CREDENTIAL
SESSION
PERMISSION
PATIENT_DATA
CLINICAL_DATA
FINANCIAL_DATA
AUDIT_DATA
SECURITY_DATA
CONFIGURATION
SOURCE_CODE
BACKUP
ENCRYPTION_KEY
SECRET
INTEGRATION_DATA
```

---

### 39. Asset Classification

```text
PUBLIC
INTERNAL
CONFIDENTIAL
RESTRICTED
SECURITY_RESTRICTED
```

---

### 40. Critical Assets

Critical assets minimum:

- patient data;
- clinical records;
- credentials;
- role/permission assignments;
- audit trail;
- encryption keys;
- secrets;
- backups;
- security event records.

---

### 41. Threat Actors

```text
Anonymous External Attacker
Authenticated Malicious User
Compromised Account
Privileged Insider
Compromised Service Account
Malicious Integration
Supply Chain Attacker
Ransomware Operator
Accidental User
Administrator Error
```

---

### 42. Threat Categories

```text
Spoofing
Tampering
Repudiation
Information Disclosure
Denial of Service
Elevation of Privilege
```

---

### 43. Threat Examples

- credential stuffing;
- session hijacking;
- broken access control;
- cross-tenant data exposure;
- SQL injection;
- file upload abuse;
- privilege escalation;
- audit tampering;
- secret leakage;
- backup theft;
- malicious dependency;
- denial of service.

---

### 44. Trust Boundaries

```text
Browser ↔ Web Application
External Integration ↔ API
Application ↔ Database
Application ↔ File Storage
Application ↔ Message Queue
Application ↔ Secrets Store
Application ↔ Observability Platform
Scheduler/Worker ↔ Application
Administrator ↔ Production
Tenant A ↔ Tenant B
Clinic A ↔ Clinic B
```

---

### 45. Trust Boundary Rule

Semua data yang melewati trust boundary wajib:

- authenticated where applicable;
- authorized;
- validated;
- classified;
- size-limited;
- logged appropriately;
- protected in transit.

---

### 46. Browser Boundary

Risks:

- XSS;
- CSRF;
- session theft;
- clickjacking;
- insecure storage;
- malicious input.

Controls:

- secure cookie;
- CSP;
- CSRF token;
- output encoding;
- same-site policy;
- no sensitive local storage.

---

### 47. Integration Boundary

Risks:

- forged payload;
- replay;
- schema mismatch;
- rate abuse;
- credential compromise.

Controls:

- authentication;
- request validation;
- replay protection;
- rate limit;
- idempotency;
- audit.

---

### 48. Database Boundary

Risks:

- SQL injection;
- overprivileged credential;
- direct admin access;
- backup exposure.

Controls:

- parameterized query;
- separated credentials;
- access control;
- encryption;
- audit;
- backup protection.

---

### 49. Tenant Boundary

Tenant boundary adalah security boundary utama.

Tidak boleh ada akses silang tenant kecuali:

- explicit use case;
- permission khusus;
- purpose valid;
- approval if required;
- audit;
- response masking.

---

### 50. Clinic Boundary

Pada tenant yang memiliki banyak clinic, clinic dapat menjadi active scope.

Access harus memperhatikan:

```text
tenant_id
organization_id
clinic_id
role_assignment_scope
resource_scope
```

---

### 51. Security Context

Setiap request internal harus memiliki:

```text
request_id
correlation_id
actor_id
actor_type
tenant_id
scope_id
authentication_strength
session_id
source_ip masked
device_context
```

---

### 52. Security Context Source

Security context harus berasal dari trusted server-side resolution.

Jangan menerima:

- tenant_id;
- role;
- permission;
- clinic_id;

langsung dari hidden form sebagai source of truth.

---

### 53. Security Decision Model

```text
Authenticated?
→ Account Active?
→ Session Valid?
→ Tenant Allowed?
→ Scope Allowed?
→ Permission Granted?
→ Resource Allowed?
→ Sensitive Action Guard Passed?
→ Execute
```

---

### 54. Deny by Default

Jika policy atau context tidak dapat ditentukan:

```text
DENY
```

---

### 55. Resource-Level Authorization

Permission global saja tidak cukup.

Contoh:

```text
patient.read
```

tetap harus memeriksa:

- patient tenant;
- patient clinic;
- assignment;
- ownership;
- consent/restriction if applicable.

---

### 56. Authentication Assurance Levels

```text
AAL1 — password
AAL2 — password + MFA
AAL3 — high-assurance / hardware-backed optional
```

Sensitive action dapat membutuhkan AAL2 atau re-authentication.

---

### 57. Sensitive Actions

Contoh:

- role assignment;
- permission change;
- cross-tenant access;
- bulk export;
- key rotation;
- secret reveal;
- audit export;
- legal hold;
- user disable;
- backup restore.

---

### 58. Re-Authentication

Re-authentication dapat diwajibkan untuk:

- critical admin change;
- secret reveal;
- high-risk export;
- MFA reset;
- password change;
- account recovery.

---

### 59. Security Baseline — Authentication

Minimum:

- strong password hashing;
- login throttling;
- account lock policy;
- generic error response;
- MFA for privileged role;
- password reset token expiry;
- session rotation;
- audit login events.

---

### 60. Password Storage

Gunakan:

```text
Argon2id
```

atau secure PHP password API dengan approved configuration.

Jangan simpan plaintext atau reversible password.

---

### 61. Security Baseline — Authorization

Minimum:

- deny by default;
- permission registry;
- scoped role assignment;
- tenant filter;
- resource policy;
- cross-tenant deny;
- privileged action audit.

---

### 62. Security Baseline — Session

Minimum:

```text
HttpOnly
Secure in production
SameSite=Lax/Strict as appropriate
session rotation after login
idle timeout
absolute timeout
logout invalidation
```

---

### 63. Security Baseline — Input Validation

Semua input harus:

- type-validated;
- length-limited;
- format-validated;
- enum-constrained;
- normalized carefully;
- rejected when unknown where appropriate.

---

### 64. Security Baseline — Output Encoding

Output encoding berdasarkan context:

- HTML;
- attribute;
- JavaScript;
- URL;
- JSON.

---

### 65. Security Baseline — SQL

Gunakan PDO prepared statements.

Tidak boleh menyusun SQL dengan concatenation input user.

---

### 66. Security Baseline — CSRF

Mutation berbasis cookie/session wajib CSRF protection.

---

### 67. Security Baseline — Security Headers

Recommended:

```text
Content-Security-Policy
X-Content-Type-Options
Referrer-Policy
Permissions-Policy
Strict-Transport-Security in HTTPS
frame-ancestors via CSP
```

---

### 68. Security Baseline — Error Handling

Production response tidak boleh menampilkan:

- stack trace;
- SQL;
- path internal;
- credentials;
- secret;
- raw exception.

---

### 69. Security Baseline — File Upload

Minimum:

- size limit;
- MIME detection;
- extension allowlist;
- random storage name;
- outside public path;
- malware scan where available;
- authorization on download;
- audit for sensitive files.

---

### 70. Security Baseline — API

Minimum:

- authenticated;
- authorized;
- rate limited;
- schema validated;
- request size limited;
- idempotency where needed;
- error minimized;
- audit sensitive operations.

---

### 71. Security Baseline — Database

Minimum:

- separate credentials;
- no root from application;
- least privilege;
- encrypted backup;
- migration control;
- direct production access restricted.

---

### 72. Security Baseline — Secrets

Minimum:

- no secret in repository;
- no secret in log;
- environment-specific;
- rotation;
- revocation;
- access audit;
- masked display.

---

### 73. Security Baseline — Encryption

Minimum:

- TLS for production;
- approved encryption algorithms;
- key separation;
- key versioning;
- no hard-coded key;
- integrity protection.

---

### 74. Security Baseline — Logging

Log security-relevant events:

- login success/failure;
- account lock;
- MFA change;
- role/permission change;
- cross-tenant denial;
- sensitive export;
- secret access;
- key rotation;
- security configuration change.

---

### 75. Security Baseline — Audit

Audit privileged business and administrative actions.

Audit tidak boleh bergantung pada debug log.

---

### 76. Security Baseline — Backup

Minimum:

- encrypted;
- restricted access;
- off-host copy;
- restore test;
- integrity check;
- retention;
- documented RPO/RTO.

---

### 77. Security Baseline — Deployment

Minimum:

- production debug off;
- dependency lock file;
- environment validation;
- secrets present;
- secure permissions;
- migration reviewed;
- rollback ready.

---

### 78. Security Ownership

Ownership types:

```text
Security Capability Owner
System Owner
Data Owner
Control Owner
Risk Owner
Incident Owner
Evidence Owner
Exception Owner
```

---

### 79. Security Capability Owner

Bertanggung jawab atas control domain.

Contoh:

- IAM;
- encryption;
- secrets;
- vulnerability management.

---

### 80. System Owner

Bertanggung jawab atas risk dan operation aplikasi/service.

---

### 81. Data Owner

Bertanggung jawab atas:

- classification;
- access rule;
- retention;
- permitted use;
- export.

---

### 82. Control Owner

Bertanggung jawab atas implementasi dan evidence kontrol tertentu.

---

### 83. Risk Owner

Menerima atau menolak residual risk.

---

### 84. Security RACI

| Aktivitas | Security | Platform | Service Owner | Compliance | QA | Operations |
|---|---|---|---|---|---|---|
| Define baseline | A/R | C | C | C | I | C |
| Implement control | C | R | R | I | C | C |
| Security test | A | C | C | I | R | I |
| Approve exception | R | C | A | C | I | I |
| Incident response | R | C | C | I | I | A/R |
| Evidence review | C | C | C | A/R | I | I |

---

### 85. Security Governance Lifecycle

```text
Identify
→ Assess
→ Design
→ Implement
→ Validate
→ Approve
→ Operate
→ Monitor
→ Improve
→ Retire
```

---

### 86. Security Quality Gates

```text
Architecture Gate
Implementation Gate
Pre-Production Gate
Production Gate
Operational Review Gate
Retirement Gate
```

---

### 87. Architecture Gate

Check:

- assets;
- threats;
- trust boundaries;
- data classification;
- authentication;
- authorization;
- tenant isolation;
- audit;
- recovery.

---

### 88. Implementation Gate

Check:

- secure coding;
- dependency risk;
- secrets;
- validation;
- authorization;
- tests;
- error handling;
- logging.

---

### 89. Pre-Production Gate

Check:

- security test;
- vulnerability scan;
- tenant isolation test;
- permissions;
- headers;
- TLS;
- backup;
- runbooks;
- incident contacts.

---

### 90. Production Gate

Check:

- secure config;
- monitoring;
- alerting;
- audit;
- access review;
- no debug;
- secrets loaded;
- rollback.

---

### 91. Operational Review Gate

Check:

- failed logins;
- access anomalies;
- open vulnerabilities;
- stale secrets;
- privileged accounts;
- exceptions;
- incidents;
- restore tests.

---

### 92. Retirement Gate

Check:

- credentials revoked;
- secrets removed;
- data retained/disposed;
- integrations disabled;
- audit preserved;
- DNS/routes removed;
- backups handled.

---

### 93. Security Exception

Exception wajib memiliki:

```text
exception_id
control_reference
scope
reason
risk
compensating_control
owner
approver
effective_from
expires_at
review_date
status
```

---

### 94. Exception Rules

Exception tidak boleh:

- tanpa expiry;
- tanpa owner;
- tanpa risk assessment;
- tanpa compensating control;
- tanpa approval;
- menjadi permanent bypass.

---

### 95. Risk Levels

```text
LOW
MEDIUM
HIGH
CRITICAL
```

---

### 96. Security Risk Formula

Contoh:

```text
Risk = Likelihood × Impact
```

Dengan modifier:

- exposure;
- detectability;
- privilege;
- data sensitivity;
- tenant blast radius.

---

### 97. Risk Treatment

```text
MITIGATE
AVOID
TRANSFER
ACCEPT
```

Risk acceptance harus dilakukan oleh risk owner.

---

### 98. Security Evidence

Evidence dapat berupa:

- configuration;
- test result;
- audit record;
- scan report;
- review approval;
- restore result;
- access review;
- key rotation report;
- incident report.

---

### 99. Security Metrics

```text
authentication_failure_total
account_lock_total
mfa_coverage_ratio
privileged_account_total
cross_tenant_denial_total
authorization_denial_total
critical_vulnerability_total
secret_rotation_overdue_total
security_exception_active_total
security_incident_total
backup_restore_success_ratio
security_control_compliance_ratio
```

---

### 100. Security KPIs

Initial targets:

```text
Privileged MFA coverage = 100%
Critical vulnerabilities overdue = 0
Active critical exceptions overdue = 0
Tenant isolation test pass = 100%
Quarterly access review completion = 100%
Backup restore test success = 100%
```

---

### 101. Security Alerts

Candidates:

```text
credential_stuffing_detected
privileged_login_anomaly
cross_tenant_access_attempt
permission_escalation
secret_access_anomaly
audit_integrity_failure
malware_upload_detected
critical_vulnerability_detected
backup_restore_failure
security_configuration_changed
```

---

### 102. Security Review Cadence

| Artifact | Cadence |
|---|---|
| Privileged access | monthly/quarterly |
| User access | quarterly |
| Secrets | quarterly |
| Encryption keys | according policy |
| Vulnerabilities | continuous/weekly |
| Security policies | annual |
| Threat model | major change + annual |
| Incident plan | semiannual |
| Backup restore | quarterly |
| Tenant isolation | every release + periodic |

---

### 103. Security Maturity Levels

```text
LEVEL 0 — Ad Hoc
LEVEL 1 — Baseline
LEVEL 2 — Standardized
LEVEL 3 — Managed
LEVEL 4 — Optimized
LEVEL 5 — Adaptive
```

---

### 104. Level 0 — Ad Hoc

- security reactive;
- shared credentials;
- weak logging;
- no owner;
- no systematic testing.

---

### 105. Level 1 — Baseline

- password hashing;
- basic RBAC;
- secure session;
- input validation;
- basic audit;
- backups.

---

### 106. Level 2 — Standardized

- scoped RBAC;
- MFA privileged;
- secrets policy;
- tenant isolation;
- secure SDLC;
- vulnerability process.

---

### 107. Level 3 — Managed

- risk register;
- access review;
- incident exercises;
- key rotation;
- policy enforcement;
- metrics and alerts.

---

### 108. Level 4 — Optimized

- automated controls;
- continuous testing;
- advanced detection;
- policy-as-code;
- threat-informed defense;
- resilience testing.

---

### 109. Level 5 — Adaptive

- dynamic risk;
- adaptive authentication;
- predictive detection;
- automated containment with guardrails;
- continuous compliance evidence.

---

### 110. Security Architecture Decisions

Setiap major decision harus didokumentasikan:

```text
decision_id
context
threat
options
decision
trade_off
risk
owner
review_date
```

---

### 111. Security Documentation Set

Required:

```text
Security Architecture
Threat Model
IAM Standard
Authentication Standard
Authorization Standard
Encryption Standard
Secrets Standard
Secure Coding Standard
API Security Standard
Database Security Standard
Incident Response Plan
Vulnerability Management Standard
Backup Security Standard
Security Test Plan
Exception Register
```

---

### 112. Integration with Observability

Security menggunakan observability untuk:

- detection;
- investigation;
- evidence;
- correlation;
- alerting;
- incident response;
- maturity.

Tetapi security audit dan observability logs harus tetap dibedakan sesuai SSOT-OBS-10.

---

### 113. Integration with RBAC

Security framework menggunakan:

```text
roles
permissions
role_permission_assignments
user_role_assignments
scope bindings
```

Menu visibility bukan enforcement utama.

---

### 114. Integration with Audit Trail

Audit mencatat:

- privileged changes;
- sensitive data access where required;
- approvals;
- exports;
- security configuration;
- key/secret lifecycle;
- incident evidence access.

---

### 115. Integration with Encryption

Classification menentukan:

- encryption requirement;
- masking;
- storage;
- transport;
- access;
- retention.

---

### 116. Integration with Secrets

Secrets tidak boleh masuk:

- source code;
- logs;
- audit payload;
- error response;
- client-side code;
- version control.

---

### 117. Integration with Dynamic Menu

Dynamic menu hanya menampilkan item yang sesuai permission.

Backend tetap wajib authorize.

---

### 118. Integration with Modular Monolith

Kernel menyediakan:

- authentication;
- authorization;
- security context;
- encryption interfaces;
- secrets interfaces;
- audit;
- security events;
- policy evaluation.

Business modules menggunakan SDK/kernel contract.

---

### 119. Security Baseline for Modules

Setiap module wajib:

- register permissions;
- define resource policies;
- classify data;
- register audit events;
- define sensitive actions;
- define input schemas;
- define threat model;
- provide security tests.

---

### 120. Module Security Manifest

```yaml
module_code: patient
owner: patient_domain
data_classification:
  - RESTRICTED
permissions:
  - patient.read
  - patient.create
  - patient.update
  - patient.export
sensitive_actions:
  - patient.export
  - patient.merge
audit_actions:
  - PATIENT_VIEWED
  - PATIENT_UPDATED
  - PATIENT_EXPORTED
```

---

### 121. Security Acceptance Criteria

Setiap feature dianggap security-ready bila:

- threat identified;
- authorization defined;
- input validated;
- output encoded;
- audit defined;
- error handling safe;
- tests available;
- owner assigned;
- no secret leakage;
- tenant isolation verified.

---

### 122. Anti-Pattern

Hindari:

- permission hanya di UI;
- tenant ID dipercaya dari request;
- shared admin account;
- hard-coded secret;
- reversible password;
- application memakai root DB;
- audit menggunakan debug log;
- raw exception ke user;
- upload di public directory;
- exception tanpa expiry;
- cross-tenant query tanpa guard;
- security review hanya menjelang production;
- backup tanpa restore test.

---

### 123. UAT Part 1

#### Architecture

- [ ] Security architecture tersedia.
- [ ] Control domains tersedia.
- [ ] Trust boundaries tersedia.
- [ ] Critical assets teridentifikasi.
- [ ] Threat actors teridentifikasi.
- [ ] Threat categories tersedia.

#### Authentication

- [ ] Password hashing aman.
- [ ] Login throttling tersedia.
- [ ] Account lock policy tersedia.
- [ ] Privileged MFA wajib.
- [ ] Reset token expiry tersedia.
- [ ] Re-authentication untuk sensitive action tersedia.

#### Authorization

- [ ] Deny by default.
- [ ] Permission evaluation server-side.
- [ ] Tenant guard aktif.
- [ ] Scope guard aktif.
- [ ] Resource-level authorization aktif.
- [ ] Cross-tenant access default denied.
- [ ] Privileged action diaudit.

#### Session

- [ ] Secure cookie configuration tersedia.
- [ ] Session rotation setelah login.
- [ ] Idle timeout tersedia.
- [ ] Absolute timeout tersedia.
- [ ] Logout invalidation bekerja.
- [ ] Session revocation tersedia.

#### Application Security

- [ ] Input validation tersedia.
- [ ] Output encoding tersedia.
- [ ] PDO prepared statements digunakan.
- [ ] CSRF aktif.
- [ ] Security headers tersedia.
- [ ] Production error aman.
- [ ] Upload protection tersedia.

#### Data & Secrets

- [ ] Classification tersedia.
- [ ] Encryption policy tersedia.
- [ ] Secret tidak hard-coded.
- [ ] Secret masking tersedia.
- [ ] Key/secret owner tersedia.
- [ ] Backup encrypted.
- [ ] Restore test tersedia.

#### Governance

- [ ] Security owners tersedia.
- [ ] RACI tersedia.
- [ ] Quality gates tersedia.
- [ ] Exception process tersedia.
- [ ] Risk levels tersedia.
- [ ] Evidence requirements tersedia.
- [ ] Review cadence tersedia.
- [ ] Security metrics tersedia.

#### Module Integration

- [ ] Module security manifest tersedia.
- [ ] Permission catalog tersedia.
- [ ] Sensitive actions tersedia.
- [ ] Audit actions tersedia.
- [ ] Threat model tersedia.
- [ ] Security test tersedia.

---

### 124. Definition of Done Part 1

Part 1 dianggap selesai bila:

- [ ] security objectives tersedia;
- [ ] security principles tersedia;
- [ ] security architecture tersedia;
- [ ] control domains tersedia;
- [ ] asset categories/classification tersedia;
- [ ] threat actors/categories tersedia;
- [ ] trust boundaries tersedia;
- [ ] security context tersedia;
- [ ] authorization decision model tersedia;
- [ ] authentication baseline tersedia;
- [ ] authorization baseline tersedia;
- [ ] session baseline tersedia;
- [ ] application/API/database/file baseline tersedia;
- [ ] encryption/secrets baseline tersedia;
- [ ] logging/audit/monitoring baseline tersedia;
- [ ] backup/deployment baseline tersedia;
- [ ] ownership/RACI tersedia;
- [ ] governance lifecycle tersedia;
- [ ] quality gates tersedia;
- [ ] exception/risk model tersedia;
- [ ] evidence/metrics/KPI tersedia;
- [ ] maturity levels tersedia;
- [ ] module security manifest tersedia;
- [ ] UAT tersedia.

---

### 125. Rencana Part Berikutnya

#### Part 2

Identity, authentication, authorization, session security, tenant/scope isolation, privileged access, access review, account lifecycle, service accounts, API credentials, dan policy-as-code.

#### Part 3

Data protection, encryption, key management, secrets management, secure storage, database security, file security, backup security, retention, legal hold, privacy, dan evidence integrity.

#### Part 4

HTTP middleware, controllers, security services, database schema, secure configuration, Apache/PHP hardening, security event pipeline, vulnerability management, scheduler, incident integration, APIs, dan sequence diagrams.

#### Part 5

Reference implementation, sample policies, migration, deployment, rollback, attack simulations, security test plan, operational runbooks, final UAT, Definition of Done, roadmap, dan merge guidance.

---

## Bagian II — Identity & Access Security

### 1. Executive Summary

Part 2 mendefinisikan identity and access security untuk Platform Kernel.

Bagian ini menetapkan:

- identity model;
- user identity;
- service identity;
- authentication;
- multi-factor authentication;
- password security;
- session security;
- authorization;
- RBAC;
- resource-level policy;
- tenant and scope isolation;
- privileged access;
- account lifecycle;
- access review;
- service accounts;
- API credentials;
- credential rotation;
- policy-as-code;
- security events;
- metrics;
- UAT;
- Definition of Done.

Tujuan utamanya adalah memastikan setiap akses:

- berasal dari identity yang dapat diverifikasi;
- memakai authentication strength yang sesuai;
- melewati authorization server-side;
- dibatasi oleh tenant dan scope;
- menggunakan least privilege;
- dapat dicabut;
- dapat diaudit;
- tidak bergantung pada UI atau hidden input;
- memiliki lifecycle yang terkendali.

---

### 2. IAM Architecture

```text
Identity Source
    │
    ▼
Authentication Service
    │
    ├── Password
    ├── MFA
    ├── Service Credential
    └── API Credential
    │
    ▼
Session / Token Service
    │
    ▼
Authorization Engine
    │
    ├── Role
    ├── Permission
    ├── Resource Policy
    ├── Tenant
    ├── Scope
    ├── Ownership
    └── Sensitive Action Guard
    │
    ▼
Application / Module / API
```

---

### 3. Identity Types

```text
HUMAN_USER
SERVICE_ACCOUNT
INTEGRATION_CLIENT
SYSTEM_PROCESS
TEMPORARY_OPERATOR
BREAK_GLASS_IDENTITY
```

---

### 4. Human User Identity

Human identity wajib memiliki:

```text
user_id
username/email
status
tenant memberships
scope assignments
roles
authentication methods
security state
created_at
disabled_at
```

---

### 5. Service Identity

Service identity wajib memiliki:

```text
service_account_id
service_code
owner
environment
allowed_scopes
permissions
credential_type
credential_version
status
rotation_due_at
```

---

### 6. Integration Client Identity

Integration client wajib memiliki:

```text
client_id
integration_code
owner
tenant binding
allowed APIs
allowed scopes
credential status
rate limit profile
rotation policy
```

---

### 7. Break-Glass Identity

Break-glass identity hanya untuk emergency.

Wajib:

- disabled by default where possible;
- strong MFA;
- short activation;
- dual approval;
- full audit;
- immediate review;
- credential rotation after use.

---

### 8. Identity States

```text
PENDING
ACTIVE
LOCKED
SUSPENDED
DISABLED
EXPIRED
DELETED
```

---

### 9. Identity Source of Truth

Sumber kebenaran identity harus eksplisit.

Contoh:

```text
users
service_accounts
integration_clients
```

Role atau tenant dari request client bukan source of truth.

---

### 10. Identity Uniqueness

Username/email/client ID harus unik sesuai scope yang ditentukan.

---

### 11. Identity Linking

External identity dapat dipetakan ke internal identity melalui immutable external subject.

---

### 12. Account Enumeration Protection

Login/reset endpoint tidak boleh mengungkap apakah account ada.

Gunakan generic response.

---

### 13. Authentication Factors

```text
KNOWLEDGE
POSSESSION
INHERENCE
```

---

### 14. Authentication Assurance Levels

```text
AAL1 — Single factor
AAL2 — Multi-factor
AAL3 — High assurance optional
```

---

### 15. AAL Requirements

| Action | Minimum |
|---|---|
| Standard login | AAL1/AAL2 policy |
| Privileged login | AAL2 |
| Secret reveal | AAL2 + re-authentication |
| Role/permission change | AAL2 |
| Bulk sensitive export | AAL2 |
| Break-glass | AAL2/AAL3 |

---

### 16. Password Policy

Minimum requirements:

- minimum length;
- deny common password;
- no plaintext storage;
- no reversible encryption;
- password history optional;
- breached password screening where available;
- rate-limited login.

---

### 17. Password Length

Recommended minimum:

```text
Standard account: 12 characters
Privileged account: 14+ characters
```

Passphrase diperbolehkan.

---

### 18. Password Hashing

Gunakan:

```php
password_hash($password, PASSWORD_ARGON2ID);
```

Verifikasi:

```php
password_verify($password, $storedHash);
```

---

### 19. Password Rehash

Gunakan `password_needs_rehash()` setelah login sukses.

---

### 20. Password Reset Token

Token harus:

- random;
- single-use;
- short-lived;
- hashed at rest;
- revoked after use;
- invalidated after password change.

---

### 21. Password Reset Security

Setelah reset:

- revoke sessions;
- audit event;
- notify user;
- require MFA as configured;
- prevent enumeration.

---

### 22. Login Throttling

Rate limit berdasarkan kombinasi:

```text
account identifier
source IP
device/session fingerprint
tenant
```

---

### 23. Account Lockout

Lockout policy harus menghindari denial-of-service abuse.

Recommended:

- progressive delay;
- temporary lock;
- security alert for suspicious pattern;
- admin unlock audited.

---

### 24. MFA

MFA wajib untuk:

- privileged accounts;
- security/compliance roles;
- production operators;
- break-glass identities.

---

### 25. MFA Methods

Preferred:

```text
TOTP
WebAuthn/FIDO2
Hardware-backed authenticator
```

SMS hanya fallback bila diterima policy.

---

### 26. MFA Enrollment

Enrollment membutuhkan:

- authenticated session;
- re-authentication;
- confirmation;
- recovery mechanism;
- audit.

---

### 27. MFA Reset

MFA reset adalah high-risk operation.

Wajib:

- identity verification;
- approval or strong recovery;
- session revocation;
- audit;
- notification.

---

### 28. Recovery Codes

Recovery codes harus:

- one-time;
- hashed;
- displayed once;
- revocable;
- auditable.

---

### 29. Authentication Service Contract

```php
interface AuthenticationServiceInterface
{
    public function authenticate(
        AuthenticationCommand $command,
        AuthenticationContext $context
    ): AuthenticationResult;

    public function verifySecondFactor(
        MfaVerificationCommand $command,
        AuthenticationContext $context
    ): AuthenticationResult;
}
```

---

### 30. Authentication Result

```text
SUCCESS
FAILURE
LOCKED
MFA_REQUIRED
PASSWORD_CHANGE_REQUIRED
ACCOUNT_DISABLED
```

---

### 31. Authentication Events

```text
AUTH_LOGIN_SUCCEEDED
AUTH_LOGIN_FAILED
AUTH_ACCOUNT_LOCKED
AUTH_MFA_CHALLENGE_CREATED
AUTH_MFA_SUCCEEDED
AUTH_MFA_FAILED
AUTH_PASSWORD_RESET_REQUESTED
AUTH_PASSWORD_RESET_COMPLETED
AUTH_SESSION_REVOKED
```

---

### 32. Session Architecture

```text
Authenticated Identity
→ Session Created
→ Session ID Rotated
→ Security Context Bound
→ Activity Monitored
→ Timeout/Revocation
```

---

### 33. Session Cookie Baseline

```text
HttpOnly = true
Secure = true in production
SameSite = Lax or Strict
Path = /
Domain restricted
```

---

### 34. Session ID Rotation

Rotate:

- after login;
- after MFA;
- after privilege elevation;
- after password change;
- after tenant switch if high risk.

---

### 35. Session Timeouts

Recommended initial:

```text
Idle timeout: 15–30 minutes for privileged
Idle timeout: 30–60 minutes for standard
Absolute timeout: 8–12 hours
Remember-me: separate controlled policy
```

---

### 36. Session Binding

Optional context:

- user agent class;
- device ID;
- authentication strength;
- tenant;
- session version.

Do not rely solely on IP binding.

---

### 37. Session Revocation

Revoke on:

- logout;
- password reset;
- account disable;
- role removal if critical;
- suspicious activity;
- MFA reset;
- administrator action.

---

### 38. Concurrent Session Policy

Configurable by role.

Privileged users dapat dibatasi lebih ketat.

---

### 39. Session Listing

User dapat melihat:

- active sessions;
- device;
- last activity;
- approximate location;
- revoke action.

---

### 40. Session Store

Session store harus:

- server-side;
- encrypted/protected;
- expiry-aware;
- tenant-aware;
- revocation-aware.

---

### 41. Session Security Events

```text
SESSION_CREATED
SESSION_ROTATED
SESSION_EXPIRED
SESSION_REVOKED
SESSION_CONTEXT_CHANGED
SESSION_ANOMALY_DETECTED
```

---

### 42. Authorization Model

Authorization adalah kombinasi:

```text
Role-Based Access Control
+ Resource-Level Policy
+ Tenant Constraint
+ Scope Constraint
+ Context Constraint
+ Sensitive Action Guard
```

---

### 43. RBAC Entities

```text
roles
permissions
role_permission_assignments
user_role_assignments
```

---

### 44. Permission Naming

Format:

```text
domain.resource.action
```

Contoh:

```text
patient.record.read
patient.record.update
patient.record.export
security.user.disable
security.role.assign
```

---

### 45. Permission Granularity

Permission harus cukup granular untuk memisahkan:

- read;
- create;
- update;
- delete;
- approve;
- export;
- manage;
- administer.

---

### 46. Role Types

```text
SYSTEM_ROLE
TENANT_ROLE
ORGANIZATION_ROLE
CLINIC_ROLE
MODULE_ROLE
PRIVILEGED_ROLE
```

---

### 47. Role Inheritance

Role inheritance hanya jika:

- sederhana;
- terdokumentasi;
- tidak menciptakan privilege tidak terlihat;
- dapat dievaluasi deterministik.

---

### 48. Role Assignment Scope

Assignment dapat terikat pada:

```text
tenant_id
organization_id
clinic_id
department_id
module_code
```

---

### 49. Scoped Assignment

Satu user dapat memiliki role berbeda pada clinic berbeda.

---

### 50. Authorization Decision

```text
DENY
ALLOW
ALLOW_WITH_CONDITIONS
```

---

### 51. Authorization Service Contract

```php
interface AuthorizationServiceInterface
{
    public function decide(
        AuthorizationRequest $request,
        SecurityContext $context
    ): AuthorizationDecision;
}
```

---

### 52. Authorization Request

```text
actor
permission
resource
tenant
scope
context
authentication_strength
```

---

### 53. Resource Policy

Resource policy memeriksa:

- resource tenant;
- resource clinic;
- owner;
- assignment;
- sensitivity;
- current state;
- purpose.

---

### 54. Policy Example — Patient Read

```text
ALLOW if:
permission patient.record.read
AND patient.tenant_id = context.tenant_id
AND patient.clinic_id in actor.allowed_clinics
AND patient not restricted by policy
```

---

### 55. Deny Precedence

Explicit deny harus mengalahkan allow.

---

### 56. Menu vs Authorization

Dynamic menu hanya UX.

Backend authorization tetap wajib.

---

### 57. Controller Authorization

Controller memanggil policy/service.

Controller tidak membaca role string manual.

---

### 58. Repository Scope Enforcement

Repository tenant-aware wajib menerima tenant/scope context.

---

### 59. Query Scope Rule

Tidak boleh query tenant-aware table tanpa tenant condition kecuali privileged cross-tenant service.

---

### 60. Cross-Tenant Access

Cross-tenant access wajib:

- explicit permission;
- approved use case;
- purpose;
- bounded query;
- masking;
- audit.

---

### 61. Tenant Context Resolution

Tenant context berasal dari:

- authenticated membership;
- trusted route/context;
- server-side selected tenant;
- validated active session.

---

### 62. Tenant Switch

Tenant switch harus:

- validate membership;
- rotate session or context token;
- clear tenant caches;
- audit;
- refresh permissions.

---

### 63. Scope Context Resolution

Scope seperti clinic harus divalidasi terhadap assignment aktif.

---

### 64. Cache Isolation

Cache key wajib memasukkan tenant dan scope.

---

### 65. File Isolation

File path/reference wajib tenant-aware dan authorization-checked.

---

### 66. Queue Isolation

Message wajib membawa trusted tenant/scope context.

Consumer wajib memvalidasi.

---

### 67. Tenant Isolation Tests

Minimum:

- read cross-tenant;
- update cross-tenant;
- export cross-tenant;
- cache bleed;
- file access;
- queue message;
- search/report;
- admin path.

---

### 68. Privileged Access Management

Privileged access mencakup:

- platform admin;
- security admin;
- database admin;
- secrets operator;
- backup operator;
- auditor;
- break-glass.

---

### 69. Privileged Role Rules

Wajib:

- MFA;
- shorter session;
- re-authentication;
- explicit assignment;
- expiry where possible;
- periodic review;
- full audit.

---

### 70. Just-in-Time Access

Recommended untuk privilege tinggi.

Flow:

```text
Request
→ Approve
→ Activate
→ Use
→ Expire
→ Review
```

---

### 71. Time-Bound Assignment

Privileged assignment wajib memiliki:

```text
effective_from
expires_at
reason
approver
```

---

### 72. Privilege Elevation

Elevation harus:

- require MFA/re-auth;
- bounded duration;
- scoped permission;
- audit;
- visible banner/session state.

---

### 73. Break-Glass Workflow

```text
Emergency Declared
→ Dual Approval
→ Credential Activated
→ Short Session
→ Full Audit
→ Automatic Expiry
→ Post-Use Review
→ Rotate Credential
```

---

### 74. Privileged Session Monitoring

Track:

- start/end;
- actions;
- target scope;
- export;
- configuration changes;
- failures.

---

### 75. Sensitive Operation Approval

Contoh:

- cross-tenant export;
- role administration;
- key rotation;
- backup restore;
- audit export;
- account impersonation.

---

### 76. Impersonation

Impersonation jika tersedia wajib:

- explicit permission;
- reason;
- time-bound;
- visible indicator;
- no credential access;
- full audit;
- restricted actions.

---

### 77. Account Lifecycle

```text
Request
→ Verify
→ Create
→ Assign Access
→ Activate
→ Review
→ Modify
→ Suspend
→ Disable
→ Delete/Archive
```

---

### 78. Joiner Process

Wajib:

- approved request;
- identity verification;
- minimum role;
- scope assignment;
- MFA enrollment where required;
- owner/manager association;
- audit.

---

### 79. Mover Process

Saat perubahan posisi:

- remove obsolete access;
- grant new access;
- recalculate risk;
- revoke sessions if critical;
- audit.

---

### 80. Leaver Process

Wajib:

- disable account promptly;
- revoke sessions;
- revoke tokens;
- remove assignments;
- transfer ownership;
- preserve audit;
- rotate shared secrets if affected.

---

### 81. Dormant Account

Dormant account harus:

- detected;
- reviewed;
- suspended/disabled according policy;
- excluded from privileged access.

---

### 82. Temporary Account

Temporary account wajib:

- expiry;
- sponsor;
- limited role;
- no shared identity;
- review.

---

### 83. Shared Accounts

Shared human accounts dilarang kecuali documented technical necessity.

---

### 84. Account Ownership

Setiap non-human account wajib memiliki human/team owner.

---

### 85. Account Lifecycle Events

```text
IDENTITY_CREATED
IDENTITY_ACTIVATED
IDENTITY_LOCKED
IDENTITY_SUSPENDED
IDENTITY_DISABLED
IDENTITY_EXPIRED
IDENTITY_DELETED
IDENTITY_OWNER_CHANGED
```

---

### 86. Access Review

Access review memastikan assignment masih diperlukan.

---

### 87. Review Types

```text
USER_ACCESS_REVIEW
PRIVILEGED_ACCESS_REVIEW
SERVICE_ACCOUNT_REVIEW
ROLE_PERMISSION_REVIEW
CROSS_TENANT_ACCESS_REVIEW
```

---

### 88. Review Cadence

| Review | Cadence |
|---|---|
| Privileged access | monthly/quarterly |
| Standard user access | quarterly/semiannual |
| Service accounts | quarterly |
| Role permissions | quarterly |
| Cross-tenant permissions | monthly/quarterly |

---

### 89. Access Review Record

```text
review_id
subject
assignments
reviewer
decision
reason
reviewed_at
next_review_at
```

---

### 90. Review Decisions

```text
RETAIN
MODIFY
REVOKE
ESCALATE
```

---

### 91. Review Evidence

Simpan:

- assignment snapshot;
- reviewer;
- decision;
- reason;
- changes;
- completion evidence.

---

### 92. Orphaned Assignment

Assignment tanpa owner atau valid identity harus dinonaktifkan.

---

### 93. Toxic Combination

Contoh segregation conflict:

```text
create_vendor + approve_payment
request_access + approve_access
manage_role + approve_role
backup_restore + audit_delete
```

---

### 94. SoD Policy

Authorization engine harus dapat mendeteksi toxic combinations.

---

### 95. Service Accounts

Service account bukan user biasa.

Wajib:

- non-interactive by default;
- no shared use;
- minimum permissions;
- owner;
- environment binding;
- rotation;
- audit.

---

### 96. Service Account Credential Types

```text
CLIENT_SECRET
API_KEY
MUTUAL_TLS
SIGNED_TOKEN
WORKLOAD_IDENTITY optional
```

---

### 97. Service Account Restrictions

Tidak boleh:

- login ke UI kecuali explicitly designed;
- memakai human password;
- memiliki wildcard permissions tanpa justification;
- tidak memiliki owner;
- credential tidak pernah expire.

---

### 98. Service Account Creation

Wajib:

- request;
- owner;
- purpose;
- permissions;
- environment;
- expiry/rotation;
- approval.

---

### 99. Service Account Rotation

Rotation process:

```text
Create New Credential
→ Deploy
→ Verify
→ Revoke Old
→ Audit
```

---

### 100. Service Account Disable

Disable bila:

- unused;
- owner missing;
- expired;
- compromised;
- integration retired.

---

### 101. API Credentials

API credential wajib:

- unique client;
- scoped permissions;
- tenant binding;
- expiration;
- rotation;
- rate limit;
- audit.

---

### 102. API Key Storage

Simpan hash dari API key jika verification model memungkinkan.

Display raw key hanya sekali.

---

### 103. API Key Format

Gunakan prefix untuk identification:

```text
nl_live_
nl_test_
nl_dev_
```

Jangan menyimpan secret penuh pada log.

---

### 104. API Key Authentication

Flow:

```text
Read Credential
→ Identify Client
→ Verify Hash/Signature
→ Check Status
→ Check Expiry
→ Resolve Tenant/Scope
→ Resolve Permissions
→ Rate Limit
```

---

### 105. Signed Token

Token harus memiliki:

```text
issuer
subject
audience
issued_at
expires_at
token_id
scopes
tenant
```

---

### 106. Token Validation

Validate:

- signature;
- issuer;
- audience;
- expiry;
- not-before;
- token ID revocation where required;
- tenant;
- scopes.

---

### 107. Replay Protection

Untuk sensitive API:

- nonce;
- timestamp;
- idempotency key;
- token ID;
- request signature optional.

---

### 108. Credential Revocation

Revocation harus cepat dan auditable.

---

### 109. Credential Events

```text
CREDENTIAL_CREATED
CREDENTIAL_ROTATED
CREDENTIAL_REVOKED
CREDENTIAL_EXPIRED
CREDENTIAL_USED
CREDENTIAL_FAILED
```

---

### 110. Policy-as-Code

IAM policy-as-code mengubah aturan akses menjadi rule terstruktur.

---

### 111. Policy Categories

```text
AUTHENTICATION
AUTHORIZATION
SESSION
TENANT
PRIVILEGED_ACCESS
ACCOUNT_LIFECYCLE
SERVICE_ACCOUNT
CREDENTIAL
SEGREGATION_OF_DUTIES
```

---

### 112. Policy Example — Privileged MFA

```yaml
policy_code: SEC_PRIVILEGED_MFA_REQUIRED
version: "1.0"
severity: CRITICAL
scope:
  role_type: PRIVILEGED_ROLE
require:
  authentication_assurance_minimum: AAL2
```

---

### 113. Policy Example — Assignment Expiry

```yaml
policy_code: SEC_PRIVILEGED_ASSIGNMENT_EXPIRY
version: "1.0"
severity: BLOCKING
scope:
  role_type: PRIVILEGED_ROLE
require:
  expires_at_required: true
```

---

### 114. Policy Example — Cross-Tenant Access

```yaml
policy_code: SEC_CROSS_TENANT_EXPLICIT_PERMISSION
version: "1.0"
severity: CRITICAL
scope:
  access_type: CROSS_TENANT
require:
  permission: security.cross_tenant.access
  purpose_required: true
  audit_required: true
```

---

### 115. Policy Example — Service Account Owner

```yaml
policy_code: SEC_SERVICE_ACCOUNT_OWNER_REQUIRED
version: "1.0"
severity: BLOCKING
scope:
  identity_type: SERVICE_ACCOUNT
require:
  owner_not_empty: true
  rotation_due_at_required: true
```

---

### 116. Policy Example — Dormant Account

```yaml
policy_code: SEC_DORMANT_ACCOUNT_DISABLE
version: "1.0"
severity: WARNING
scope:
  identity_type: HUMAN_USER
condition:
  inactive_days_gte: 90
require:
  status_in:
    - SUSPENDED
    - DISABLED
```

---

### 117. Policy Evaluation Result

```text
PASS
WARN
FAIL
PASS_WITH_EXCEPTION
UNKNOWN
```

---

### 118. Policy Exception

Exception harus:

- time-bound;
- owner;
- risk;
- compensating control;
- approval;
- audit.

---

### 119. Authorization Cache

Authorization cache harus:

- short-lived;
- keyed by user, tenant, scope, permission version;
- invalidated on assignment changes;
- never shared cross-tenant.

---

### 120. Permission Version

User security context dapat memiliki permission version.

Saat role berubah, version meningkat dan session/cache di-refresh.

---

### 121. Security Context Payload

```json
{
  "actor_id": 123,
  "actor_type": "HUMAN_USER",
  "tenant_id": 10,
  "scope_id": 5,
  "roles": [
    "clinic_nurse"
  ],
  "permission_version": 42,
  "authentication_assurance": "AAL2",
  "session_id": "01J..."
}
```

---

### 122. Permission Registry

Setiap permission wajib memiliki:

```text
permission_code
name
description
owner
risk_level
scope_model
status
```

---

### 123. Role Registry

Setiap role wajib memiliki:

```text
role_code
name
role_type
owner
default_scope
review_due_at
status
```

---

### 124. Role Composition

Role harus dibuat dari permission yang diperlukan, bukan dari menu.

---

### 125. Default Roles

Default roles harus minimal dan tidak terlalu luas.

---

### 126. Role Change Control

Role/permission change membutuhkan:

- review;
- impact analysis;
- approval;
- versioning;
- audit;
- cache/session invalidation.

---

### 127. Sensitive Permission

Contoh:

```text
security.role.manage
security.permission.manage
security.user.disable
security.cross_tenant.access
security.secret.reveal
security.audit.export
security.backup.restore
```

---

### 128. Permission Risk Levels

```text
LOW
MEDIUM
HIGH
CRITICAL
```

---

### 129. Critical Permission Assignment

Critical permission assignment membutuhkan:

- explicit approver;
- MFA;
- expiry;
- reason;
- audit;
- periodic review.

---

### 130. Security Metrics

```text
authentication_success_total
authentication_failure_total
mfa_challenge_total
mfa_failure_total
account_lock_total
active_session_total
session_revocation_total
authorization_denial_total
cross_tenant_denial_total
privileged_assignment_total
privileged_assignment_expiring_total
dormant_account_total
service_account_rotation_overdue_total
api_credential_failure_total
access_review_overdue_total
```

---

### 131. Alert Candidates

```text
credential_stuffing_detected
privileged_mfa_disabled
cross_tenant_access_attempt
critical_permission_assigned
service_account_owner_missing
service_credential_expired
dormant_privileged_account
session_anomaly_detected
access_review_overdue
toxic_role_combination_detected
```

---

### 132. Error Codes

```text
AUTH_INVALID_CREDENTIALS
AUTH_ACCOUNT_LOCKED
AUTH_ACCOUNT_DISABLED
AUTH_MFA_REQUIRED
AUTH_MFA_FAILED
AUTH_SESSION_EXPIRED
AUTH_SESSION_REVOKED
AUTH_REAUTH_REQUIRED
AUTHZ_PERMISSION_DENIED
AUTHZ_RESOURCE_DENIED
AUTHZ_TENANT_DENIED
AUTHZ_SCOPE_DENIED
AUTHZ_SOD_CONFLICT
IDENTITY_NOT_FOUND
IDENTITY_STATE_INVALID
ROLE_NOT_FOUND
PERMISSION_NOT_FOUND
ROLE_ASSIGNMENT_EXPIRED
SERVICE_ACCOUNT_DISABLED
API_CREDENTIAL_INVALID
API_CREDENTIAL_EXPIRED
API_CREDENTIAL_REVOKED
CROSS_TENANT_ACCESS_DENIED
```

---

### 133. Security Test Strategy

#### Unit

- password validation;
- MFA state;
- session expiry;
- permission resolution;
- resource policy;
- tenant guard;
- scope guard;
- SoD rule;
- credential expiry;
- policy evaluation.

#### Integration

- login flow;
- MFA flow;
- password reset;
- session rotation;
- role assignment;
- tenant switch;
- service credential rotation;
- API key verification;
- access review workflow.

#### Security

- brute force;
- enumeration;
- session fixation;
- session hijacking;
- cross-tenant access;
- privilege escalation;
- toxic combination;
- expired token;
- replay;
- cache bleed.

---

### 134. UAT Part 2

#### Identity

- [ ] Human identity states bekerja.
- [ ] Service identity states bekerja.
- [ ] Identity uniqueness enforced.
- [ ] Disabled identity tidak dapat login.
- [ ] Break-glass identity controlled.
- [ ] Identity lifecycle diaudit.

#### Authentication

- [ ] Password hashing Argon2id/PHP secure API.
- [ ] Login throttling bekerja.
- [ ] Account lock policy bekerja.
- [ ] Enumeration protection bekerja.
- [ ] Password reset token single-use.
- [ ] MFA wajib untuk privileged.
- [ ] MFA reset high-risk control bekerja.
- [ ] Re-authentication bekerja.

#### Session

- [ ] Secure cookie aktif.
- [ ] Session ID rotation bekerja.
- [ ] Idle timeout bekerja.
- [ ] Absolute timeout bekerja.
- [ ] Logout invalidation bekerja.
- [ ] Session revocation bekerja.
- [ ] Concurrent session policy bekerja.
- [ ] Session listing tersedia.

#### Authorization

- [ ] Deny by default.
- [ ] Permission registry tersedia.
- [ ] Role registry tersedia.
- [ ] Role assignment scope bekerja.
- [ ] Resource policy bekerja.
- [ ] Explicit deny precedence bekerja.
- [ ] Menu bukan enforcement utama.
- [ ] Permission cache invalidation bekerja.

#### Tenant & Scope

- [ ] Tenant context server-side.
- [ ] Scope membership divalidasi.
- [ ] Cross-tenant read ditolak.
- [ ] Cross-tenant update ditolak.
- [ ] Cache isolation bekerja.
- [ ] File isolation bekerja.
- [ ] Queue isolation bekerja.
- [ ] Tenant switch diaudit.

#### Privileged Access

- [ ] Privileged MFA bekerja.
- [ ] Assignment expiry bekerja.
- [ ] JIT access bekerja jika diterapkan.
- [ ] Privilege elevation time-bound.
- [ ] Break-glass workflow bekerja.
- [ ] Impersonation controlled.
- [ ] Privileged actions diaudit.
- [ ] Post-use review tersedia.

#### Account Lifecycle

- [ ] Joiner process tersedia.
- [ ] Mover process mencabut akses lama.
- [ ] Leaver process cepat.
- [ ] Sessions/tokens dicabut.
- [ ] Dormant account terdeteksi.
- [ ] Temporary account expire.
- [ ] Shared human account dilarang.
- [ ] Ownership transfer bekerja.

#### Access Review

- [ ] User access review tersedia.
- [ ] Privileged review tersedia.
- [ ] Service account review tersedia.
- [ ] Review decision tersimpan.
- [ ] Orphaned assignment terdeteksi.
- [ ] Overdue review menghasilkan alert.
- [ ] Toxic combination terdeteksi.
- [ ] Revocation hasil review diterapkan.

#### Service Accounts & API Credentials

- [ ] Owner wajib.
- [ ] Environment binding tersedia.
- [ ] Least privilege diterapkan.
- [ ] Credential rotation bekerja.
- [ ] Raw key ditampilkan sekali.
- [ ] Credential revocation bekerja.
- [ ] Expired credential ditolak.
- [ ] Rate limit profile diterapkan.
- [ ] Token claims divalidasi.
- [ ] Replay protection tersedia.

#### Policy-as-Code

- [ ] Privileged MFA policy bekerja.
- [ ] Assignment expiry policy bekerja.
- [ ] Cross-tenant policy bekerja.
- [ ] Service account owner policy bekerja.
- [ ] Dormant account policy bekerja.
- [ ] Valid exception dapat digunakan.
- [ ] Expired exception ditolak.
- [ ] Policy evaluation diaudit.

---

### 135. Definition of Done Part 2

Part 2 dianggap selesai bila:

- [ ] identity types tersedia;
- [ ] identity states tersedia;
- [ ] authentication assurance tersedia;
- [ ] password policy tersedia;
- [ ] MFA policy tersedia;
- [ ] reset/recovery control tersedia;
- [ ] session architecture tersedia;
- [ ] session revocation tersedia;
- [ ] authorization model tersedia;
- [ ] RBAC entities tersedia;
- [ ] permission/role registries tersedia;
- [ ] scoped assignment tersedia;
- [ ] resource policies tersedia;
- [ ] tenant/scope isolation tersedia;
- [ ] cross-tenant controls tersedia;
- [ ] privileged access model tersedia;
- [ ] JIT/time-bound access tersedia;
- [ ] break-glass workflow tersedia;
- [ ] account lifecycle tersedia;
- [ ] access review tersedia;
- [ ] SoD/toxic combination tersedia;
- [ ] service account standard tersedia;
- [ ] API credential standard tersedia;
- [ ] credential rotation/revocation tersedia;
- [ ] policy-as-code tersedia;
- [ ] metrics/alerts tersedia;
- [ ] error codes tersedia;
- [ ] security testing tersedia;
- [ ] UAT tersedia.

---

### 136. Rencana Part Berikutnya

#### Part 3

Data protection, encryption, key management, secrets management, secure storage, database security, file security, backup security, retention, legal hold, privacy, dan evidence integrity.

#### Part 4

HTTP middleware, controllers, security services, database schema, secure configuration, Apache/PHP hardening, security event pipeline, vulnerability management, scheduler, incident integration, APIs, dan sequence diagrams.

#### Part 5

Reference implementation, sample policies, migration, deployment, rollback, attack simulations, security test plan, operational runbooks, final UAT, Definition of Done, roadmap, dan merge guidance.

---

## Bagian III — Data Protection & Cryptography

### 1. Executive Summary

Part 3 mendefinisikan standar perlindungan data untuk Platform Kernel.

Bagian ini menetapkan:

- data classification;
- data minimization;
- encryption in transit;
- encryption at rest;
- field-level encryption;
- hashing;
- digital signature;
- key management;
- key rotation;
- key revocation;
- secrets management;
- secure configuration;
- database security;
- file storage security;
- backup security;
- retention;
- legal hold;
- privacy;
- secure deletion;
- evidence integrity;
- chain of custody;
- UAT;
- Definition of Done.

Tujuan utamanya adalah memastikan data sensitif:

- diklasifikasikan;
- dibatasi;
- dienkripsi;
- hanya dapat diakses oleh identity yang berwenang;
- tidak bocor ke log atau error;
- memiliki retention yang benar;
- dapat dipertahankan saat legal hold;
- dapat diverifikasi integritasnya;
- dapat dipulihkan;
- dapat dihapus secara aman saat eligible.

---

### 2. Data Protection Architecture

```text
Data Source
    │
    ▼
Classification
    │
    ├── Public
    ├── Internal
    ├── Confidential
    ├── Restricted
    └── Security Restricted
    │
    ▼
Protection Policy
    │
    ├── Access Control
    ├── Encryption
    ├── Masking
    ├── Tokenization
    ├── Retention
    ├── Audit
    └── Legal Hold
    │
    ▼
Storage / Transfer / Processing
    │
    ▼
Monitoring / Evidence / Recovery
```

---

### 3. Data Protection Principles

```text
Data Minimization
Purpose Limitation
Least Privilege
Need to Know
Encryption by Default
Key Separation
Retention by Policy
Secure Disposal
Integrity Verification
Tenant Isolation
```

---

### 4. Data Categories

```text
IDENTITY_DATA
AUTHENTICATION_DATA
AUTHORIZATION_DATA
PATIENT_DATA
CLINICAL_DATA
CONTACT_DATA
FINANCIAL_DATA
AUDIT_DATA
SECURITY_DATA
OPERATIONAL_DATA
CONFIGURATION_DATA
SECRET_DATA
BACKUP_DATA
EVIDENCE_DATA
```

---

### 5. Data Classification Levels

```text
PUBLIC
INTERNAL
CONFIDENTIAL
RESTRICTED
SECURITY_RESTRICTED
```

---

### 6. PUBLIC

Contoh:

- public website content;
- public service information;
- published contact information.

Kontrol:

- integrity;
- availability;
- change control.

---

### 7. INTERNAL

Contoh:

- internal documentation;
- non-sensitive operational metadata;
- internal service names.

Kontrol:

- authenticated access;
- no public exposure;
- standard retention.

---

### 8. CONFIDENTIAL

Contoh:

- employee data;
- business data;
- internal reports;
- non-clinical customer data.

Kontrol:

- role-based access;
- encryption;
- audit for sensitive operations;
- restricted export.

---

### 9. RESTRICTED

Contoh:

- patient data;
- clinical record;
- financial record;
- sensitive identity data;
- privileged audit detail.

Kontrol:

- strict authorization;
- encryption;
- masking;
- access logging;
- secure export;
- longer retention controls;
- stronger review.

---

### 10. SECURITY_RESTRICTED

Contoh:

- passwords/hashes;
- encryption keys;
- API secrets;
- security incident evidence;
- privileged access data.

Kontrol:

- isolated storage;
- strong encryption;
- minimal access;
- dual control where applicable;
- no general application exposure;
- dedicated audit.

---

### 11. Classification Ownership

Setiap data domain wajib memiliki Data Owner.

Data Owner bertanggung jawab atas:

- classification;
- permitted use;
- access rule;
- masking;
- retention;
- legal hold;
- export;
- disposal.

---

### 12. Classification Metadata

Minimum:

```text
data_category
classification
owner
tenant_scope
retention_policy
encryption_policy
masking_policy
export_policy
legal_hold_policy
```

---

### 13. Data Inventory

Setiap module wajib menginventarisasi:

- tables;
- fields;
- files;
- events;
- logs;
- backups;
- integrations;
- exports.

---

### 14. Data Flow Mapping

Map:

```text
Source
→ Processing
→ Storage
→ Integration
→ Reporting
→ Archive
→ Disposal
```

---

### 15. Data Minimization

Hanya simpan dan kirim data yang diperlukan.

Tidak boleh:

- mengirim full patient object jika hanya reference diperlukan;
- menaruh secret pada log;
- menyalin data restricted ke cache umum;
- menyimpan duplicate sensitive data tanpa kebutuhan.

---

### 16. Purpose Limitation

Data hanya digunakan untuk purpose yang disetujui.

---

### 17. Field-Level Protection Matrix

| Classification | Access | Encryption | Masking | Audit |
|---|---|---|---|---|
| PUBLIC | broad | optional | no | change audit |
| INTERNAL | authenticated | transport | optional | selected |
| CONFIDENTIAL | scoped | at rest + transit | recommended | sensitive actions |
| RESTRICTED | strict | at rest + transit + optional field | required in UI/log | access/export |
| SECURITY_RESTRICTED | minimal | strong field/storage | always | all access |

---

### 18. Encryption Domains

```text
IN_TRANSIT
AT_REST
FIELD_LEVEL
BACKUP
ARCHIVE
EXPORT
MESSAGE
```

---

### 19. Encryption in Transit

Production wajib menggunakan TLS.

---

### 20. TLS Baseline

Minimum:

- modern TLS version;
- valid certificate;
- strong ciphers;
- hostname validation;
- no plaintext fallback;
- HSTS where applicable.

---

### 21. Internal TLS

Internal service/database connection sebaiknya memakai TLS jika infrastructure mendukung.

---

### 22. Encryption at Rest

At-rest protection dapat berupa:

- disk encryption;
- database encryption;
- encrypted volume;
- encrypted object storage;
- encrypted backup.

---

### 23. Field-Level Encryption

Digunakan untuk field sangat sensitif.

Contoh:

- national identifier;
- API secret;
- bank account;
- recovery secret;
- selected clinical identifiers.

---

### 24. Field-Level Encryption Requirements

Wajib memiliki:

```text
algorithm
key_id
key_version
nonce/IV
ciphertext
authentication_tag
associated_data
```

---

### 25. Authenticated Encryption

Gunakan AEAD.

Contoh:

```text
AES-256-GCM
XChaCha20-Poly1305
```

Pilih berdasarkan library yang tersedia dan approved policy.

---

### 26. Associated Data

Associated data dapat mengikat ciphertext ke:

```text
tenant_id
record_type
record_id
field_name
key_version
```

---

### 27. Encryption Envelope

```json
{
  "ciphertext": "...",
  "algorithm": "AES-256-GCM",
  "key_id": "patient-data-key",
  "key_version": 3,
  "nonce": "...",
  "tag": "..."
}
```

---

### 28. Decryption Authorization

Memiliki ciphertext tidak berarti boleh decrypt.

Decrypt wajib:

- permission;
- tenant/scope check;
- purpose;
- audit for sensitive categories;
- key access.

---

### 29. Masking

Contoh:

```text
NIK: 3174********1234
Email: a***@example.com
Phone: 0812****5678
API key: nl_live_****abcd
```

---

### 30. Masking Rules

Masking dilakukan:

- pada UI;
- API response;
- logs;
- exports;
- support tools;
- audit projector.

---

### 31. Tokenization

Tokenization dapat digunakan untuk:

- patient external reference;
- payment reference;
- integration identifier.

---

### 32. Hashing

Hashing digunakan untuk:

- password;
- token verification;
- API key verification;
- integrity;
- deduplication.

---

### 33. Password Hashing

Gunakan Argon2id/PHP password API.

---

### 34. Token Hashing

Reset token, recovery token, dan API key dapat disimpan dalam bentuk hash.

---

### 35. Cryptographic Hash

Gunakan approved hash seperti SHA-256/SHA-512 sesuai purpose.

---

### 36. HMAC

Gunakan HMAC untuk:

- message authentication;
- signed references;
- webhook verification;
- integrity with shared secret.

---

### 37. Digital Signature

Dapat digunakan untuk:

- evidence manifest;
- audit archive;
- release artifacts;
- high-assurance approval packages.

---

### 38. Random Number Generation

Gunakan cryptographically secure random source.

PHP:

```php
random_bytes(32);
```

---

### 39. Key Management Architecture

```text
Key Policy
    │
    ▼
Key Generation
    │
    ▼
Key Storage
    │
    ▼
Key Distribution
    │
    ▼
Key Use
    │
    ▼
Rotation
    │
    ▼
Revocation
    │
    ▼
Destruction
```

---

### 40. Key Types

```text
MASTER_KEY
DATA_ENCRYPTION_KEY
KEY_ENCRYPTION_KEY
SIGNING_KEY
HMAC_KEY
BACKUP_KEY
EXPORT_KEY
SESSION_SIGNING_KEY
```

---

### 41. Key Ownership

Setiap key wajib memiliki:

```text
key_id
purpose
owner
algorithm
environment
status
version
created_at
rotation_due_at
```

---

### 42. Key Separation

Jangan gunakan key yang sama untuk:

- different environments;
- different purposes;
- encryption dan signing;
- production dan development;
- tenant-separated high-risk data bila policy membutuhkan.

---

### 43. Envelope Encryption

Model:

```text
Data encrypted with DEK
DEK encrypted with KEK
KEK protected in secure key store
```

---

### 44. Key Generation

Key harus dibuat dengan approved cryptographic RNG.

---

### 45. Key Storage

Key tidak boleh disimpan:

- di source code;
- di database yang sama tanpa protection;
- di log;
- di client-side code;
- di plain config committed to repository.

---

### 46. Key Rotation

Rotation dapat dipicu oleh:

- schedule;
- compromise;
- personnel change;
- policy change;
- algorithm change;
- environment migration.

---

### 47. Key Rotation Modes

```text
REWRAP
LAZY_REENCRYPT
FULL_REENCRYPT
DUAL_READ
```

---

### 48. Rewrap

Re-encrypt DEK dengan KEK baru tanpa decrypt seluruh data.

---

### 49. Lazy Re-encryption

Data dienkripsi ulang saat dibaca/diubah.

---

### 50. Full Re-encryption

Digunakan bila compromise atau policy mengharuskan.

---

### 51. Dual Read

Aplikasi sementara dapat membaca beberapa key version.

Write hanya dengan active version.

---

### 52. Key Revocation

Revocation harus:

- menghentikan penggunaan baru;
- memblokir decrypt jika compromised sesuai policy;
- membuat incident;
- memulai rotation/re-encryption;
- audit.

---

### 53. Key Destruction

Key hanya dihancurkan jika:

- retention/legal hold memungkinkan;
- data sudah tidak diperlukan;
- approval tersedia;
- evidence dibuat.

---

### 54. Key Access Control

Akses key wajib:

- least privilege;
- service identity;
- purpose-bound;
- audited;
- no general developer access in production.

---

### 55. Key Custodian

Critical key dapat memerlukan dual control.

---

### 56. Key Backup

Key backup harus:

- encrypted;
- isolated;
- access controlled;
- tested;
- aligned with recovery plan.

---

### 57. Key Loss

Key loss dapat berarti permanent data loss.

Rencana recovery wajib tersedia.

---

### 58. Key Metrics

```text
key_active_total
key_rotation_overdue_total
key_access_total
key_revocation_total
key_decryption_failure_total
```

---

### 59. Secrets Management Architecture

```text
Secret Source
→ Secret Store
→ Authorized Retrieval
→ Runtime Injection
→ Use
→ Rotation
→ Revocation
→ Audit
```

---

### 60. Secret Types

```text
DATABASE_PASSWORD
API_KEY
CLIENT_SECRET
ENCRYPTION_KEY_REFERENCE
SIGNING_KEY_REFERENCE
SMTP_CREDENTIAL
WEBHOOK_SECRET
BACKUP_CREDENTIAL
```

---

### 61. Secret Rules

Tidak boleh:

- hard-coded;
- committed;
- logged;
- returned in API;
- displayed repeatedly;
- shared across environment;
- emailed/chat without approved secure process.

---

### 62. Secret Store

Recommended:

- dedicated secrets manager;
- protected environment variables;
- OS-protected configuration;
- encrypted local secrets for development.

---

### 63. Secret Retrieval

Retrieval harus:

- authenticated;
- authorized;
- scoped;
- auditable;
- short-lived where possible.

---

### 64. Runtime Secret Injection

Application menerima secret saat runtime.

Jangan bake secret ke image/repository.

---

### 65. Secret Caching

Jika cache diperlukan:

- in memory;
- short TTL;
- no disk;
- clear on rotation/reload.

---

### 66. Secret Rotation

Rotation flow:

```text
Create New Secret
→ Deploy New Secret
→ Verify
→ Revoke Old Secret
→ Audit
```

---

### 67. Secret Versioning

Application dapat mendukung current dan previous version selama transition terbatas.

---

### 68. Secret Reveal

Raw secret hanya ditampilkan jika benar-benar diperlukan.

Wajib:

- high-risk permission;
- re-authentication;
- masking by default;
- audit;
- short-lived display.

---

### 69. Secret Compromise

Response:

- revoke;
- rotate;
- identify usage;
- review logs without exposing secret;
- create incident;
- notify owners;
- verify recovery.

---

### 70. Secret Inventory

Minimum:

```text
secret_id
type
owner
environment
service
status
created_at
rotation_due_at
last_rotated_at
```

---

### 71. Secret Metrics

```text
secret_active_total
secret_rotation_overdue_total
secret_access_total
secret_reveal_total
secret_revocation_total
```

---

### 72. Secure Configuration

Configuration categories:

```text
PUBLIC_CONFIG
INTERNAL_CONFIG
SECRET_CONFIG
SECURITY_CRITICAL_CONFIG
```

---

### 73. Secure Config Validation

Startup harus memvalidasi:

- environment;
- debug mode;
- secrets present;
- secure cookie;
- encryption key reference;
- database credential;
- allowed origins;
- trusted proxies.

---

### 74. Production Config Guard

Production harus gagal start atau health menjadi NOT_READY jika critical security config invalid.

---

### 75. Environment Separation

```text
development
testing
staging
production
```

Masing-masing memiliki:

- credentials;
- keys;
- databases;
- endpoints;
- secrets.

---

### 76. Database Security Architecture

```text
Application
→ PDO Prepared Statements
→ Least-Privilege Credential
→ Tenant-Aware Repository
→ Database
→ Backup / Audit / Monitoring
```

---

### 77. Database Accounts

Recommended separation:

```text
app_runtime_rw
app_runtime_ro
migration_operator
backup_operator
reporting_read
security_audit_read
```

---

### 78. Application DB Credential

Tidak boleh menggunakan root/superuser.

---

### 79. Database Least Privilege

Grant hanya:

- required schemas;
- required operations;
- no admin capability;
- no file privilege;
- no user management.

---

### 80. Prepared Statements

Semua parameter user wajib bound.

---

### 81. Dynamic SQL

Dynamic table/column names harus berasal dari allowlist, bukan raw user input.

---

### 82. Database Row Isolation

Tenant-aware query wajib memiliki tenant filter.

---

### 83. Database Views

Views dapat digunakan untuk:

- masking;
- reporting isolation;
- restricted projections.

---

### 84. Database Encryption

Gunakan storage encryption dan field encryption sesuai classification.

---

### 85. Database Backup

Backup harus encrypted dan access controlled.

---

### 86. Database Audit

Audit:

- schema changes;
- privileged access;
- bulk export;
- user/permission changes;
- restore.

---

### 87. Migration Security

Migration wajib:

- reviewed;
- versioned;
- backup-aware;
- rollback-aware;
- no plaintext secret;
- no unauthorized destructive change.

---

### 88. Production DB Access

Direct access harus:

- restricted;
- time-bound where possible;
- approved;
- audited;
- read-only by default.

---

### 89. File Security Architecture

```text
Upload
→ Validate Size
→ Validate MIME
→ Validate Extension
→ Scan
→ Rename
→ Store Outside Public
→ Register Metadata
→ Authorized Download
```

---

### 90. File Categories

```text
PUBLIC_ASSET
INTERNAL_DOCUMENT
PATIENT_DOCUMENT
CLINICAL_IMAGE
SECURITY_EVIDENCE
EXPORT_PACKAGE
BACKUP_FILE
```

---

### 91. Upload Validation

Check:

- content length;
- MIME by server-side detection;
- extension allowlist;
- file signature;
- archive bomb;
- malware;
- filename normalization.

---

### 92. Filename

Jangan gunakan user-supplied filename sebagai storage name.

Gunakan random ID.

---

### 93. File Metadata

```text
file_id
original_name
storage_name
mime_type
size
checksum
classification
tenant_id
scope_id
owner
created_at
retention_policy
```

---

### 94. File Storage

Restricted file disimpan di luar web root.

---

### 95. File Download

Download harus melewati:

- authentication;
- authorization;
- tenant/scope;
- classification;
- audit if sensitive.

---

### 96. Signed Download Link

Jika digunakan:

- short-lived;
- scoped;
- one-time optional;
- no sensitive object path;
- revocable where possible.

---

### 97. File Integrity

Gunakan checksum.

---

### 98. File Malware Handling

Malicious/suspicious file:

- quarantine;
- no processing;
- alert;
- preserve evidence;
- incident if needed.

---

### 99. Image Processing Security

Image libraries harus:

- patched;
- resource-limited;
- validate content;
- strip metadata where required.

---

### 100. Archive File Security

ZIP/TAR upload harus dicek untuk:

- path traversal;
- decompression bomb;
- nested archive;
- excessive file count.

---

### 101. File Deletion

Deletion mengikuti retention/legal hold.

---

### 102. Backup Security Architecture

```text
Source Data
→ Backup Job
→ Encrypt
→ Manifest
→ Transfer
→ Isolated Storage
→ Integrity Verification
→ Restore Test
```

---

### 103. Backup Types

```text
FULL
INCREMENTAL
DIFFERENTIAL
SNAPSHOT
LOG_BACKUP
```

---

### 104. Backup Requirements

- encrypted;
- access controlled;
- off-host;
- immutable copy recommended;
- retention;
- checksum;
- restore test;
- key recovery.

---

### 105. Backup Credentials

Separate credential from application runtime.

---

### 106. Backup Encryption Key

Key harus tersedia saat recovery tetapi terpisah dari backup media.

---

### 107. Ransomware Resilience

Recommended:

- immutable backup;
- offline/offsite copy;
- separate credentials;
- MFA for delete;
- retention lock;
- restore exercise.

---

### 108. Backup Integrity

Use:

- checksums;
- manifests;
- verification logs;
- periodic restore.

---

### 109. Restore Security

Restore membutuhkan:

- approval;
- isolated environment;
- malware/integrity checks;
- key access;
- audit;
- validation before production.

---

### 110. Restore Data Leakage

Restore ke non-production harus menggunakan masking or synthetic data where possible.

---

### 111. Backup Metrics

```text
backup_success_total
backup_failure_total
backup_integrity_failure_total
restore_test_success_ratio
backup_age_seconds
```

---

### 112. Retention Governance

Setiap data category wajib memiliki retention policy.

---

### 113. Retention Policy Fields

```text
policy_code
data_category
classification
retention_period
start_point
archive_rule
purge_rule
legal_hold_rule
owner
```

---

### 114. Retention Start Point

Contoh:

```text
created_at
record_closed_at
patient_relationship_end
contract_end
incident_closed_at
```

---

### 115. Retention States

```text
ACTIVE
ARCHIVE_ELIGIBLE
ARCHIVED
PURGE_ELIGIBLE
LEGAL_HOLD
PURGED
```

---

### 116. Legal Hold

Legal hold memblokir:

- purge;
- destructive anonymization;
- crypto erasure;
- backup expiration if included;
- archive deletion.

---

### 117. Legal Hold Record

```text
hold_id
case_reference
scope
data_categories
tenant_id
time_range
reason
owner
effective_from
released_at
status
```

---

### 118. Legal Hold Access

Hanya role berwenang dapat:

- create;
- modify;
- release;
- export evidence.

---

### 119. Purge Eligibility

Data hanya dapat dipurge bila:

- retention expired;
- no legal hold;
- no active investigation;
- no unresolved audit requirement;
- approval if required.

---

### 120. Secure Deletion

Metode:

```text
logical deletion
physical deletion
crypto erasure
storage lifecycle deletion
```

Pilih sesuai storage dan compliance.

---

### 121. Crypto Erasure

Menghapus key dapat membuat data tidak terbaca.

Hanya jika:

- no legal hold;
- approved;
- recovery not required;
- evidence generated.

---

### 122. Purge Evidence

```text
purge_batch_id
data_category
scope
record_count
policy_code
executed_by
executed_at
verification_hash
```

---

### 123. Privacy Principles

```text
Lawful/Purpose-Based Processing
Data Minimization
Accuracy
Storage Limitation
Integrity & Confidentiality
Accountability
```

---

### 124. Privacy by Design

Feature baru harus menilai:

- personal data;
- purpose;
- necessity;
- access;
- retention;
- sharing;
- user rights;
- risk.

---

### 125. Privacy Data Subjects

Contoh:

- patient;
- staff;
- provider;
- contact;
- customer;
- integration user.

---

### 126. Privacy Rights Support

Framework dapat mendukung:

- access;
- correction;
- export;
- restriction;
- deletion where legally allowed;
- audit.

---

### 127. Privacy Request Workflow

```text
Request
→ Identity Verification
→ Scope Validation
→ Legal/Policy Review
→ Fulfillment
→ Evidence
→ Closure
```

---

### 128. Privacy Export

Export wajib:

- verify requester;
- minimize data;
- encrypt;
- expire;
- audit;
- chain of custody.

---

### 129. Privacy Deletion

Deletion harus mempertimbangkan:

- legal retention;
- audit requirement;
- legal hold;
- clinical obligation;
- backups.

---

### 130. Anonymization

Anonymization harus irreversible sesuai accepted method.

---

### 131. Pseudonymization

Pseudonymization masih dianggap sensitive jika mapping tersedia.

---

### 132. Data Masking for Non-Production

Production data tidak boleh langsung disalin ke dev/test tanpa:

- approval;
- masking;
- minimization;
- restricted access;
- audit.

---

### 133. Logging Privacy

Tidak boleh log:

- plaintext password;
- full API key;
- session token;
- encryption key;
- full restricted clinical payload;
- unnecessary identifiers.

---

### 134. Error Privacy

Error response tidak boleh membocorkan sensitive data.

---

### 135. Evidence Integrity Architecture

```text
Evidence Created
→ Hash
→ Metadata
→ Secure Storage
→ Access Audit
→ Chain of Custody
→ Verification
→ Archive
```

---

### 136. Evidence Types

```text
SECURITY_TEST
VULNERABILITY_REPORT
ACCESS_REVIEW
KEY_ROTATION_REPORT
SECRET_ROTATION_REPORT
BACKUP_RESTORE_RESULT
INCIDENT_EVIDENCE
POLICY_APPROVAL
LEGAL_HOLD_RECORD
PURGE_EVIDENCE
```

---

### 137. Evidence Metadata

```text
evidence_id
type
source
scope
classification
checksum
owner
created_at
valid_until
retention_policy
legal_hold_status
```

---

### 138. Evidence Checksum

Gunakan SHA-256 atau approved algorithm.

---

### 139. Evidence Signature

Critical evidence dapat ditandatangani.

---

### 140. Chain of Custody

Events:

```text
CREATED
COLLECTED
VIEWED
EXPORTED
TRANSFERRED
ARCHIVED
VERIFIED
PURGED
```

---

### 141. Custody Record

```text
custody_id
evidence_id
action
actor
source
destination
reason
checksum_before
checksum_after
occurred_at
```

---

### 142. Evidence Access

Wajib:

- permission;
- purpose;
- tenant/scope;
- classification;
- audit.

---

### 143. Evidence Export

Export package harus:

- encrypted;
- checksum;
- manifest;
- short-lived;
- access logged.

---

### 144. Evidence Integrity Failure

Jika checksum gagal:

- mark SUSPECT;
- block export/approval dependency;
- alert;
- incident;
- preserve copies;
- investigate.

---

### 145. Encryption Service Contract

```php
interface EncryptionServiceInterface
{
    public function encrypt(
        string $plaintext,
        EncryptionContext $context
    ): EncryptedValue;

    public function decrypt(
        EncryptedValue $value,
        DecryptionContext $context
    ): string;
}
```

---

### 146. Key Management Contract

```php
interface KeyManagementServiceInterface
{
    public function activeKey(
        string $purpose,
        string $environment
    ): KeyReference;

    public function rotate(
        KeyRotationCommand $command
    ): KeyRotationResult;

    public function revoke(
        string $keyId,
        string $reason
    ): void;
}
```

---

### 147. Secrets Service Contract

```php
interface SecretsServiceInterface
{
    public function get(
        string $secretId,
        SecretAccessContext $context
    ): SecretValue;

    public function rotate(
        SecretRotationCommand $command
    ): SecretRotationResult;

    public function revoke(
        string $secretId,
        string $reason
    ): void;
}
```

---

### 148. File Storage Contract

```php
interface SecureFileStorageInterface
{
    public function store(
        SecureFileUpload $upload,
        FileSecurityContext $context
    ): StoredSecureFile;

    public function open(
        string $fileId,
        FileAccessContext $context
    ): SecureFileStream;

    public function delete(
        string $fileId,
        FileDeletionContext $context
    ): void;
}
```

---

### 149. Retention Service Contract

```php
interface RetentionServiceInterface
{
    public function evaluate(
        RetentionSubject $subject,
        \DateTimeImmutable $at
    ): RetentionDecision;

    public function placeLegalHold(
        LegalHoldCommand $command
    ): LegalHold;

    public function releaseLegalHold(
        string $holdId,
        LegalHoldReleaseCommand $command
    ): LegalHold;
}
```

---

### 150. Data Protection Policy-as-Code

Categories:

```text
CLASSIFICATION
ENCRYPTION
KEY_MANAGEMENT
SECRETS
DATABASE
FILE
BACKUP
RETENTION
LEGAL_HOLD
PRIVACY
EVIDENCE
```

---

### 151. Policy Example — Restricted Encryption

```yaml
policy_code: SEC_RESTRICTED_DATA_ENCRYPTION
version: "1.0"
severity: CRITICAL
scope:
  classification_in:
    - RESTRICTED
    - SECURITY_RESTRICTED
require:
  encryption_at_rest: true
  encryption_in_transit: true
```

---

### 152. Policy Example — Key Rotation

```yaml
policy_code: SEC_KEY_ROTATION_REQUIRED
version: "1.0"
severity: BLOCKING
scope:
  key_status: ACTIVE
require:
  rotation_due_at_not_overdue: true
```

---

### 153. Policy Example — Secret Owner

```yaml
policy_code: SEC_SECRET_OWNER_REQUIRED
version: "1.0"
severity: BLOCKING
scope:
  secret_status: ACTIVE
require:
  owner_not_empty: true
  rotation_due_at_required: true
```

---

### 154. Policy Example — File Outside Public Root

```yaml
policy_code: SEC_RESTRICTED_FILE_NONPUBLIC
version: "1.0"
severity: CRITICAL
scope:
  classification_in:
    - RESTRICTED
    - SECURITY_RESTRICTED
require:
  public_path: false
```

---

### 155. Policy Example — Legal Hold Purge Block

```yaml
policy_code: SEC_LEGAL_HOLD_PURGE_DENY
version: "1.0"
severity: CRITICAL
scope:
  legal_hold_status: ACTIVE
require:
  purge_allowed: false
```

---

### 156. Security Events

```text
DATA_DECRYPTED
KEY_CREATED
KEY_ROTATED
KEY_REVOKED
SECRET_ACCESSED
SECRET_REVEALED
SECRET_ROTATED
SECRET_REVOKED
RESTRICTED_FILE_DOWNLOADED
BACKUP_RESTORE_STARTED
BACKUP_RESTORE_COMPLETED
LEGAL_HOLD_CREATED
LEGAL_HOLD_RELEASED
PURGE_EXECUTED
EVIDENCE_INTEGRITY_FAILED
```

---

### 157. Metrics

```text
encrypted_field_total
decryption_failure_total
key_rotation_overdue_total
secret_rotation_overdue_total
secret_reveal_total
restricted_file_access_total
malware_upload_total
backup_success_total
restore_test_success_ratio
legal_hold_active_total
purge_eligible_total
evidence_integrity_failure_total
privacy_request_total
```

---

### 158. Alert Candidates

```text
key_rotation_overdue
secret_rotation_overdue
secret_access_anomaly
decryption_failure_spike
restricted_file_public_exposure
malware_upload_detected
backup_failure
restore_test_failed
legal_hold_purge_attempt
evidence_integrity_failed
restricted_export_anomaly
```

---

### 159. Error Codes

```text
DATA_CLASSIFICATION_REQUIRED
DATA_ENCRYPTION_REQUIRED
DATA_DECRYPTION_DENIED
DATA_DECRYPTION_FAILED
KEY_NOT_FOUND
KEY_VERSION_UNSUPPORTED
KEY_ROTATION_OVERDUE
KEY_REVOKED
SECRET_NOT_FOUND
SECRET_ACCESS_DENIED
SECRET_ROTATION_OVERDUE
SECRET_REVOKED
FILE_TYPE_NOT_ALLOWED
FILE_SIZE_EXCEEDED
FILE_MALWARE_DETECTED
FILE_ACCESS_DENIED
BACKUP_ENCRYPTION_REQUIRED
BACKUP_RESTORE_DENIED
RETENTION_POLICY_NOT_FOUND
LEGAL_HOLD_ACTIVE
PURGE_NOT_ALLOWED
EVIDENCE_INTEGRITY_FAILED
PRIVACY_REQUEST_DENIED
```

---

### 160. Security Test Strategy

#### Unit

- classification resolver;
- encryption/decryption;
- key versioning;
- secret masking;
- retention decision;
- legal hold;
- file validation;
- evidence checksum.

#### Integration

- encrypted field persistence;
- key rotation;
- secret rotation;
- database credential separation;
- secure upload/download;
- backup encryption;
- restore validation;
- privacy export;
- purge workflow.

#### Security

- key leakage;
- secret leakage;
- path traversal;
- MIME spoofing;
- archive bomb;
- cross-tenant file access;
- unauthorized decrypt;
- backup theft;
- legal hold bypass;
- evidence tampering.

---

### 161. UAT Part 3

#### Classification & Minimization

- [ ] Data inventory tersedia.
- [ ] Classification metadata tersedia.
- [ ] Data owner tersedia.
- [ ] Restricted data teridentifikasi.
- [ ] Data flow mapping tersedia.
- [ ] Minimization diterapkan.
- [ ] Purpose limitation tersedia.
- [ ] Non-production masking tersedia.

#### Encryption

- [ ] TLS aktif di production.
- [ ] Restricted data encrypted at rest.
- [ ] Field-level encryption tersedia.
- [ ] AEAD digunakan.
- [ ] Associated data tersedia.
- [ ] Decryption authorization bekerja.
- [ ] Masking bekerja.
- [ ] No hard-coded encryption key.

#### Key Management

- [ ] Key inventory tersedia.
- [ ] Purpose/environment separation.
- [ ] Key generation aman.
- [ ] Rotation bekerja.
- [ ] Dual-read/write-current bekerja jika diterapkan.
- [ ] Revocation bekerja.
- [ ] Key access diaudit.
- [ ] Key recovery diuji.

#### Secrets

- [ ] Secret inventory tersedia.
- [ ] Secret tidak di repository.
- [ ] Secret tidak di log.
- [ ] Runtime injection bekerja.
- [ ] Masking bekerja.
- [ ] Rotation bekerja.
- [ ] Revocation bekerja.
- [ ] Secret reveal membutuhkan high-risk control.

#### Database

- [ ] Application tidak memakai root.
- [ ] Credentials terpisah.
- [ ] Prepared statements digunakan.
- [ ] Tenant filter diterapkan.
- [ ] Migration direview.
- [ ] Direct production access dibatasi.
- [ ] Backup encrypted.
- [ ] Privileged access diaudit.

#### Files

- [ ] Size limit bekerja.
- [ ] MIME/extension validation bekerja.
- [ ] Random storage name digunakan.
- [ ] Restricted file di luar web root.
- [ ] Authorization download bekerja.
- [ ] Malware quarantine tersedia.
- [ ] Archive traversal/bomb protection tersedia.
- [ ] Checksum tersedia.

#### Backup

- [ ] Backup encrypted.
- [ ] Credential terpisah.
- [ ] Off-host/immutable copy tersedia.
- [ ] Integrity verification bekerja.
- [ ] Restore test berhasil.
- [ ] Key recovery berhasil.
- [ ] Non-production restore dimasking.
- [ ] RPO/RTO tersedia.

#### Retention & Legal Hold

- [ ] Retention policy tersedia.
- [ ] Start point eksplisit.
- [ ] Archive eligibility bekerja.
- [ ] Purge eligibility bekerja.
- [ ] Legal hold memblokir purge.
- [ ] Legal hold release controlled.
- [ ] Purge evidence dibuat.
- [ ] Crypto erasure membutuhkan approval.

#### Privacy

- [ ] Privacy impact dinilai.
- [ ] Access/export workflow tersedia.
- [ ] Correction workflow tersedia.
- [ ] Deletion mempertimbangkan retention.
- [ ] Export terenkripsi.
- [ ] Pseudonymization/anonymization dibedakan.
- [ ] Logs tidak membocorkan personal data.
- [ ] Privacy actions diaudit.

#### Evidence Integrity

- [ ] Evidence metadata tersedia.
- [ ] Checksum diverifikasi.
- [ ] Chain of custody tersedia.
- [ ] Restricted evidence access dibatasi.
- [ ] Export package terenkripsi.
- [ ] Integrity failure menghasilkan alert.
- [ ] Suspect evidence dipertahankan.
- [ ] Evidence retention tersedia.

#### Policy-as-Code

- [ ] Restricted encryption policy bekerja.
- [ ] Key rotation policy bekerja.
- [ ] Secret owner policy bekerja.
- [ ] Non-public file policy bekerja.
- [ ] Legal hold purge policy bekerja.
- [ ] Blocking policy memblokir.
- [ ] Valid exception dapat digunakan.
- [ ] Expired exception ditolak.

---

### 162. Definition of Done Part 3

Part 3 dianggap selesai bila:

- [ ] data categories tersedia;
- [ ] classification levels tersedia;
- [ ] ownership tersedia;
- [ ] inventory/flow mapping tersedia;
- [ ] minimization/purpose limitation tersedia;
- [ ] encryption domains tersedia;
- [ ] field-level encryption standard tersedia;
- [ ] key management lifecycle tersedia;
- [ ] key rotation/revocation tersedia;
- [ ] secrets management tersedia;
- [ ] secure configuration tersedia;
- [ ] database security tersedia;
- [ ] file security tersedia;
- [ ] backup security tersedia;
- [ ] retention model tersedia;
- [ ] legal hold tersedia;
- [ ] secure deletion/purge evidence tersedia;
- [ ] privacy principles/workflows tersedia;
- [ ] non-production masking tersedia;
- [ ] evidence integrity tersedia;
- [ ] chain of custody tersedia;
- [ ] service contracts tersedia;
- [ ] policy-as-code tersedia;
- [ ] metrics/alerts tersedia;
- [ ] error codes tersedia;
- [ ] security tests tersedia;
- [ ] UAT tersedia.

---

### 163. Rencana Part Berikutnya

#### Part 4

HTTP middleware, controllers, security services, database schema, secure configuration, Apache/PHP hardening, security event pipeline, vulnerability management, scheduler, incident integration, APIs, dan sequence diagrams.

#### Part 5

Reference implementation, sample policies, migration, deployment, rollback, attack simulations, security test plan, operational runbooks, final UAT, Definition of Done, roadmap, dan merge guidance.

---

## Bagian IV — Security Infrastructure & Operations

### 1. Executive Summary

Part 4 mendefinisikan interface, infrastructure, runtime enforcement, hardening, vulnerability management, security events, scheduler, dan incident integration untuk Security Implementation Framework.

Bagian ini menetapkan:

- HTTP security middleware;
- controller responsibilities;
- security application services;
- authentication and authorization APIs;
- session APIs;
- privileged access APIs;
- service account and credential APIs;
- key and secrets APIs;
- file security APIs;
- legal hold and evidence APIs;
- database schema;
- secure configuration validation;
- Apache hardening;
- PHP hardening;
- security event pipeline;
- detection rules;
- vulnerability management;
- scheduler jobs;
- incident integration;
- audit integration;
- metrics and alerts;
- sequence diagrams;
- UAT;
- Definition of Done.

Tujuan utamanya adalah memastikan kontrol keamanan dapat dijalankan secara konsisten pada setiap request, background process, integration, dan administrative operation.

---

### 2. Runtime Security Architecture

```text
Client / Service / Integration
            │
            ▼
Edge Security
            │
            ├── TLS
            ├── Reverse Proxy Validation
            ├── Request Size Limit
            ├── Rate Limit
            └── Security Headers
            │
            ▼
HTTP Security Middleware
            │
            ├── Request ID
            ├── Trusted Proxy
            ├── Authentication
            ├── Session Validation
            ├── MFA / AAL
            ├── Tenant Context
            ├── Scope Context
            ├── Authorization
            ├── CSRF
            ├── Classification
            ├── Input Validation
            └── Audit Context
            │
            ▼
Controller
            │
            ▼
Security Application Services
            │
            ├── Identity Service
            ├── Authentication Service
            ├── Authorization Service
            ├── Session Service
            ├── Privileged Access Service
            ├── Credential Service
            ├── Encryption Service
            ├── Secrets Service
            ├── Secure File Service
            ├── Retention Service
            ├── Vulnerability Service
            ├── Security Event Service
            └── Incident Bridge
            │
            ▼
Repositories / Database / Secure Storage / Scheduler
```

---

### 3. Middleware Order

Recommended order:

```text
RequestIdMiddleware
→ TrustedProxyMiddleware
→ SecurityHeadersMiddleware
→ RequestSizeLimitMiddleware
→ AuthenticationMiddleware
→ SessionValidationMiddleware
→ AuthenticationAssuranceMiddleware
→ RateLimitMiddleware
→ TenantContextMiddleware
→ ActiveScopeMiddleware
→ AuthorizationMiddleware
→ CsrfMiddleware
→ ClassificationMiddleware
→ InputValidationMiddleware
→ AuditContextMiddleware
→ Controller
```

---

### 4. Request ID Middleware

Responsibilities:

- generate request ID if absent;
- validate trusted incoming request ID;
- attach correlation ID;
- expose to logs, audit, security events;
- return request ID in response.

---

### 5. Trusted Proxy Middleware

Wajib:

- trust only configured proxies;
- reject spoofed forwarding headers;
- resolve client IP safely;
- preserve proxy chain for security analysis;
- mask IP in user-facing output.

---

### 6. Security Headers Middleware

Recommended headers:

```text
Content-Security-Policy
X-Content-Type-Options: nosniff
Referrer-Policy
Permissions-Policy
Strict-Transport-Security
Cross-Origin-Opener-Policy
Cross-Origin-Resource-Policy
```

Gunakan `frame-ancestors` melalui CSP.

---

### 7. Request Size Limit Middleware

Batas berbeda untuk:

- standard JSON request;
- file upload;
- import;
- export;
- security evidence.

Request yang melebihi limit harus ditolak sebelum parsing penuh.

---

### 8. Authentication Middleware

Responsibilities:

- resolve human/service/integration identity;
- verify credential/session/token;
- reject disabled or expired identity;
- attach security context;
- emit authentication failure event;
- avoid user enumeration.

---

### 9. Session Validation Middleware

Check:

```text
session exists
session active
idle timeout valid
absolute timeout valid
session version valid
identity still active
permission version valid
```

---

### 10. Authentication Assurance Middleware

Sensitive route dapat meminta:

```text
AAL1
AAL2
AAL3
REAUTH_REQUIRED
```

---

### 11. Rate Limit Middleware

Rate limit dimensions:

```text
identity
credential
tenant
IP
route
risk profile
```

---

### 12. Tenant Context Middleware

Wajib:

- resolve tenant from server-side membership;
- reject client-supplied unauthorized tenant;
- attach tenant context;
- audit tenant switch;
- clear tenant-specific cache.

---

### 13. Active Scope Middleware

Resolve and validate:

```text
organization_id
clinic_id
department_id
module_scope
```

---

### 14. Authorization Middleware

Responsibilities:

- resolve permission requirement;
- resolve resource if available;
- call authorization service;
- enforce explicit deny;
- emit denial event;
- avoid revealing resource existence across tenant.

---

### 15. CSRF Middleware

Required for cookie/session mutation.

Exempt only for:

- stateless authenticated API;
- signed webhook;
- machine credential endpoint with separate control.

---

### 16. Classification Middleware

Determines response projection based on:

- resource classification;
- actor permission;
- tenant/scope;
- purpose;
- masking policy.

---

### 17. Input Validation Middleware

Validation must be:

- schema-based;
- type-safe;
- length-limited;
- allowlist-driven;
- rejecting unknown critical fields.

---

### 18. Audit Context Middleware

Attach:

```text
actor
tenant
scope
session
request_id
correlation_id
source
purpose
authentication_assurance
```

---

### 19. Controller Responsibilities

Controller boleh:

- parse request;
- validate DTO;
- resolve route identifiers;
- call application service;
- map domain errors;
- project response.

Controller tidak boleh:

- menulis SQL;
- decrypt langsung;
- membaca secret langsung;
- memutuskan permission manual;
- mem-bypass tenant guard;
- mengubah audit history;
- menerima role/tenant dari hidden input sebagai source of truth.

---

### 20. AuthenticationController Example

```php
final class AuthenticationController
{
    public function __construct(
        private readonly AuthenticationServiceInterface $authentication,
        private readonly SecurityContextFactoryInterface $contexts
    ) {
    }

    public function login(HttpRequest $request): HttpResponse
    {
        $result = $this->authentication->authenticate(
            AuthenticationCommand::fromArray(
                $request->json()
            ),
            $this->contexts->authenticationContext($request)
        );

        return JsonResponse::ok(
            AuthenticationPresenter::present($result)
        );
    }
}
```

---

### 21. AuthorizationController Example

Authorization API bukan endpoint umum untuk client menentukan permission sendiri.

Dapat digunakan internal untuk:

- access simulation;
- admin diagnostics;
- policy test.

```php
final class AuthorizationController
{
    public function __construct(
        private readonly AuthorizationServiceInterface $authorization,
        private readonly SecurityContextFactoryInterface $contexts
    ) {
    }

    public function simulate(HttpRequest $request): HttpResponse
    {
        $context = $this->contexts->fromRequest($request);

        $decision = $this->authorization->decide(
            AuthorizationRequest::fromArray(
                $request->json()
            ),
            $context
        );

        return JsonResponse::ok(
            AuthorizationPresenter::present($decision)
        );
    }
}
```

---

### 22. PrivilegedAccessController Example

```php
final class PrivilegedAccessController
{
    public function __construct(
        private readonly PrivilegedAccessServiceInterface $service,
        private readonly SecurityContextFactoryInterface $contexts
    ) {
    }

    public function request(HttpRequest $request): HttpResponse
    {
        $context = $this->contexts->fromRequest($request);

        $access = $this->service->request(
            PrivilegedAccessRequestCommand::fromArray(
                $request->json()
            ),
            $context
        );

        return JsonResponse::created(
            PrivilegedAccessPresenter::present($access)
        );
    }
}
```

---

### 23. SecretsController Example

Raw secret reveal should be rare.

```php
final class SecretsController
{
    public function __construct(
        private readonly SecretsServiceInterface $secrets,
        private readonly SecurityContextFactoryInterface $contexts
    ) {
    }

    public function reveal(
        HttpRequest $request,
        string $secretId
    ): HttpResponse {
        $context = $this->contexts->fromRequest($request);

        $secret = $this->secrets->reveal(
            secretId: $secretId,
            command: SecretRevealCommand::fromArray(
                $request->json()
            ),
            context: $context
        );

        return JsonResponse::ok(
            SecretPresenter::singleUse($secret)
        );
    }
}
```

---

### 24. SecureFileController Example

```php
final class SecureFileController
{
    public function __construct(
        private readonly SecureFileServiceInterface $files,
        private readonly SecurityContextFactoryInterface $contexts
    ) {
    }

    public function download(
        HttpRequest $request,
        string $fileId
    ): HttpResponse {
        $context = $this->contexts->fromRequest($request);

        $file = $this->files->open(
            fileId: $fileId,
            context: $context
        );

        return StreamResponse::download(
            stream: $file->stream,
            filename: $file->safeDownloadName,
            mimeType: $file->mimeType
        );
    }
}
```

---

### 25. Base API Paths

```text
/api/internal/v1/security/authentication
/api/internal/v1/security/sessions
/api/internal/v1/security/identities
/api/internal/v1/security/roles
/api/internal/v1/security/permissions
/api/internal/v1/security/access-reviews
/api/internal/v1/security/privileged-access
/api/internal/v1/security/service-accounts
/api/internal/v1/security/credentials
/api/internal/v1/security/keys
/api/internal/v1/security/secrets
/api/internal/v1/security/files
/api/internal/v1/security/legal-holds
/api/internal/v1/security/evidence
/api/internal/v1/security/vulnerabilities
/api/internal/v1/security/incidents
/api/internal/v1/security/events
/api/internal/v1/security/health
```

---

### 26. Authentication API

```text
POST /api/internal/v1/security/authentication/login
POST /api/internal/v1/security/authentication/mfa/verify
POST /api/internal/v1/security/authentication/password/reset/request
POST /api/internal/v1/security/authentication/password/reset/complete
POST /api/internal/v1/security/authentication/reauthenticate
POST /api/internal/v1/security/authentication/logout
```

---

### 27. Session API

```text
GET    /api/internal/v1/security/sessions
GET    /api/internal/v1/security/sessions/{sessionId}
POST   /api/internal/v1/security/sessions/{sessionId}/revoke
POST   /api/internal/v1/security/sessions/revoke-all
```

---

### 28. Identity API

```text
GET    /api/internal/v1/security/identities
GET    /api/internal/v1/security/identities/{identityId}
POST   /api/internal/v1/security/identities
PUT    /api/internal/v1/security/identities/{identityId}
POST   /api/internal/v1/security/identities/{identityId}/activate
POST   /api/internal/v1/security/identities/{identityId}/suspend
POST   /api/internal/v1/security/identities/{identityId}/disable
POST   /api/internal/v1/security/identities/{identityId}/unlock
```

---

### 29. Role and Permission API

```text
GET  /api/internal/v1/security/roles
POST /api/internal/v1/security/roles
PUT  /api/internal/v1/security/roles/{roleCode}
GET  /api/internal/v1/security/permissions
POST /api/internal/v1/security/roles/{roleCode}/permissions
POST /api/internal/v1/security/assignments
POST /api/internal/v1/security/assignments/{assignmentId}/revoke
```

---

### 30. Access Review API

```text
GET  /api/internal/v1/security/access-reviews
POST /api/internal/v1/security/access-reviews
POST /api/internal/v1/security/access-reviews/{reviewId}/submit
POST /api/internal/v1/security/access-reviews/{reviewId}/decide
POST /api/internal/v1/security/access-reviews/{reviewId}/close
```

---

### 31. Privileged Access API

```text
GET  /api/internal/v1/security/privileged-access
POST /api/internal/v1/security/privileged-access/requests
POST /api/internal/v1/security/privileged-access/{requestId}/approve
POST /api/internal/v1/security/privileged-access/{requestId}/reject
POST /api/internal/v1/security/privileged-access/{requestId}/activate
POST /api/internal/v1/security/privileged-access/{requestId}/revoke
```

---

### 32. Service Account API

```text
GET  /api/internal/v1/security/service-accounts
POST /api/internal/v1/security/service-accounts
PUT  /api/internal/v1/security/service-accounts/{serviceAccountId}
POST /api/internal/v1/security/service-accounts/{serviceAccountId}/rotate
POST /api/internal/v1/security/service-accounts/{serviceAccountId}/disable
```

---

### 33. Credential API

```text
GET  /api/internal/v1/security/credentials
POST /api/internal/v1/security/credentials
POST /api/internal/v1/security/credentials/{credentialId}/rotate
POST /api/internal/v1/security/credentials/{credentialId}/revoke
GET  /api/internal/v1/security/credentials/{credentialId}/usage
```

---

### 34. Key API

```text
GET  /api/internal/v1/security/keys
POST /api/internal/v1/security/keys
POST /api/internal/v1/security/keys/{keyId}/rotate
POST /api/internal/v1/security/keys/{keyId}/revoke
GET  /api/internal/v1/security/keys/{keyId}/versions
```

---

### 35. Secrets API

```text
GET  /api/internal/v1/security/secrets
POST /api/internal/v1/security/secrets
POST /api/internal/v1/security/secrets/{secretId}/rotate
POST /api/internal/v1/security/secrets/{secretId}/revoke
POST /api/internal/v1/security/secrets/{secretId}/reveal
```

---

### 36. Secure File API

```text
POST   /api/internal/v1/security/files
GET    /api/internal/v1/security/files/{fileId}
GET    /api/internal/v1/security/files/{fileId}/download
POST   /api/internal/v1/security/files/{fileId}/quarantine
DELETE /api/internal/v1/security/files/{fileId}
```

---

### 37. Legal Hold API

```text
GET  /api/internal/v1/security/legal-holds
POST /api/internal/v1/security/legal-holds
POST /api/internal/v1/security/legal-holds/{holdId}/release
GET  /api/internal/v1/security/legal-holds/{holdId}/scope
```

---

### 38. Evidence API

```text
GET  /api/internal/v1/security/evidence
POST /api/internal/v1/security/evidence
POST /api/internal/v1/security/evidence/{evidenceId}/verify
POST /api/internal/v1/security/evidence/{evidenceId}/export
GET  /api/internal/v1/security/evidence/{evidenceId}/custody
```

---

### 39. Vulnerability API

```text
GET  /api/internal/v1/security/vulnerabilities
GET  /api/internal/v1/security/vulnerabilities/{vulnerabilityId}
POST /api/internal/v1/security/vulnerabilities/import
POST /api/internal/v1/security/vulnerabilities/{vulnerabilityId}/assign
POST /api/internal/v1/security/vulnerabilities/{vulnerabilityId}/accept-risk
POST /api/internal/v1/security/vulnerabilities/{vulnerabilityId}/remediate
POST /api/internal/v1/security/vulnerabilities/{vulnerabilityId}/verify
```

---

### 40. Incident API

```text
GET  /api/internal/v1/security/incidents
POST /api/internal/v1/security/incidents
POST /api/internal/v1/security/incidents/{incidentId}/triage
POST /api/internal/v1/security/incidents/{incidentId}/contain
POST /api/internal/v1/security/incidents/{incidentId}/recover
POST /api/internal/v1/security/incidents/{incidentId}/close
```

---

### 41. Canonical Success Envelope

```json
{
  "data": {},
  "meta": {
    "request_id": "01J...",
    "generated_at": "2026-07-05T12:00:00Z",
    "classification": "INTERNAL"
  }
}
```

---

### 42. Canonical Error Envelope

```json
{
  "error": {
    "code": "AUTHZ_TENANT_DENIED",
    "message": "Access denied.",
    "details": []
  },
  "meta": {
    "request_id": "01J...",
    "timestamp": "2026-07-05T12:00:00Z"
  }
}
```

---

### 43. HTTP Status Mapping

| Kondisi | HTTP |
|---|---:|
| success | 200 |
| created | 201 |
| accepted | 202 |
| validation | 422 |
| unauthenticated | 401 |
| forbidden | 403 |
| not found | 404 |
| conflict | 409 |
| expired | 410 |
| rate limited | 429 |
| unavailable | 503 |
| unexpected | 500 |

---

### 44. Security Service Contracts

#### Identity Service

```php
interface IdentityServiceInterface
{
    public function create(
        IdentityCreateCommand $command,
        SecurityContext $context
    ): Identity;

    public function disable(
        string $identityId,
        IdentityDisableCommand $command,
        SecurityContext $context
    ): Identity;
}
```

---

### 45. Session Service

```php
interface SessionServiceInterface
{
    public function create(
        AuthenticatedIdentity $identity,
        SessionCreateContext $context
    ): SecuritySession;

    public function revoke(
        string $sessionId,
        string $reason,
        SecurityContext $context
    ): void;
}
```

---

### 46. Privileged Access Service

```php
interface PrivilegedAccessServiceInterface
{
    public function request(
        PrivilegedAccessRequestCommand $command,
        SecurityContext $context
    ): PrivilegedAccessRequest;

    public function approve(
        string $requestId,
        PrivilegedAccessDecisionCommand $command,
        SecurityContext $context
    ): PrivilegedAccessRequest;
}
```

---

### 47. Credential Service

```php
interface CredentialServiceInterface
{
    public function issue(
        CredentialIssueCommand $command,
        SecurityContext $context
    ): IssuedCredential;

    public function rotate(
        string $credentialId,
        SecurityContext $context
    ): CredentialRotationResult;

    public function revoke(
        string $credentialId,
        string $reason,
        SecurityContext $context
    ): void;
}
```

---

### 48. Vulnerability Service

```php
interface VulnerabilityManagementServiceInterface
{
    public function import(
        VulnerabilityImportCommand $command,
        SecurityContext $context
    ): VulnerabilityImportResult;

    public function assign(
        string $vulnerabilityId,
        VulnerabilityAssignmentCommand $command,
        SecurityContext $context
    ): Vulnerability;

    public function verify(
        string $vulnerabilityId,
        VulnerabilityVerificationCommand $command,
        SecurityContext $context
    ): Vulnerability;
}
```

---

### 49. Security Event Service

```php
interface SecurityEventServiceInterface
{
    public function record(
        SecurityEvent $event
    ): void;

    public function raiseIncidentCandidate(
        SecurityEvent $event
    ): ?string;
}
```

---

### 50. Incident Bridge

```php
interface SecurityIncidentBridgeInterface
{
    public function createFromEvent(
        SecurityEvent $event,
        IncidentCreationContext $context
    ): string;

    public function attachEvidence(
        string $incidentId,
        string $evidenceId
    ): void;
}
```

---

### 51. Database Schema Overview

Tables:

```text
security_identities
security_identity_memberships
security_authentication_methods
security_mfa_methods
security_password_reset_tokens
security_sessions
security_roles
security_permissions
security_role_permissions
security_role_assignments
security_access_reviews
security_access_review_items
security_privileged_access_requests
security_service_accounts
security_credentials
security_key_registry
security_key_versions
security_secret_registry
security_secret_versions
security_secure_files
security_legal_holds
security_evidence
security_chain_of_custody
security_vulnerabilities
security_vulnerability_events
security_events
security_incidents
security_scheduler_runs
```

---

### 52. Table: security_identities

```sql
CREATE TABLE security_identities (
    id CHAR(26) NOT NULL,
    identity_type VARCHAR(40) NOT NULL,
    username VARCHAR(190) NULL,
    email VARCHAR(190) NULL,
    display_name VARCHAR(255) NOT NULL,
    status VARCHAR(30) NOT NULL DEFAULT 'PENDING',
    owner_reference VARCHAR(180) NULL,
    password_hash VARCHAR(255) NULL,
    permission_version BIGINT UNSIGNED NOT NULL DEFAULT 1,
    locked_until DATETIME(6) NULL,
    disabled_at DATETIME(6) NULL,
    created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    updated_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6)
        ON UPDATE CURRENT_TIMESTAMP(6),

    PRIMARY KEY (id),
    UNIQUE KEY uq_security_identity_username (username),
    UNIQUE KEY uq_security_identity_email (email),
    KEY idx_security_identity_status (identity_type, status)
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

### 53. Table: security_identity_memberships

```sql
CREATE TABLE security_identity_memberships (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    identity_id CHAR(26) NOT NULL,
    tenant_id BIGINT UNSIGNED NOT NULL,
    organization_id BIGINT UNSIGNED NULL,
    clinic_id BIGINT UNSIGNED NULL,
    status VARCHAR(30) NOT NULL DEFAULT 'ACTIVE',
    effective_from DATETIME(6) NOT NULL,
    expires_at DATETIME(6) NULL,

    PRIMARY KEY (id),
    KEY idx_identity_membership_scope (
        identity_id,
        tenant_id,
        organization_id,
        clinic_id,
        status
    ),
    CONSTRAINT fk_identity_membership_identity
        FOREIGN KEY (identity_id)
        REFERENCES security_identities (id)
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

### 54. Table: security_authentication_methods

```sql
CREATE TABLE security_authentication_methods (
    id CHAR(26) NOT NULL,
    identity_id CHAR(26) NOT NULL,
    method_type VARCHAR(40) NOT NULL,
    status VARCHAR(30) NOT NULL DEFAULT 'ACTIVE',
    secret_reference VARCHAR(255) NULL,
    enrolled_at DATETIME(6) NOT NULL,
    last_used_at DATETIME(6) NULL,
    revoked_at DATETIME(6) NULL,

    PRIMARY KEY (id),
    KEY idx_auth_method_identity (
        identity_id,
        method_type,
        status
    ),
    CONSTRAINT fk_auth_method_identity
        FOREIGN KEY (identity_id)
        REFERENCES security_identities (id)
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

### 55. Table: security_sessions

```sql
CREATE TABLE security_sessions (
    id CHAR(26) NOT NULL,
    identity_id CHAR(26) NOT NULL,
    tenant_id BIGINT UNSIGNED NULL,
    scope_type VARCHAR(50) NULL,
    scope_reference VARCHAR(255) NULL,
    authentication_assurance VARCHAR(20) NOT NULL,
    permission_version BIGINT UNSIGNED NOT NULL,
    session_hash CHAR(64) NOT NULL,
    created_at DATETIME(6) NOT NULL,
    last_activity_at DATETIME(6) NOT NULL,
    idle_expires_at DATETIME(6) NOT NULL,
    absolute_expires_at DATETIME(6) NOT NULL,
    revoked_at DATETIME(6) NULL,
    revoke_reason VARCHAR(1000) NULL,

    PRIMARY KEY (id),
    UNIQUE KEY uq_security_session_hash (session_hash),
    KEY idx_security_session_identity (
        identity_id,
        revoked_at,
        absolute_expires_at
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

### 56. Table: security_roles

```sql
CREATE TABLE security_roles (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    role_code VARCHAR(180) NOT NULL,
    name VARCHAR(255) NOT NULL,
    role_type VARCHAR(50) NOT NULL,
    owner_reference VARCHAR(180) NOT NULL,
    risk_level VARCHAR(30) NOT NULL,
    status VARCHAR(30) NOT NULL DEFAULT 'ACTIVE',
    review_due_at DATETIME(6) NULL,
    created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    updated_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6)
        ON UPDATE CURRENT_TIMESTAMP(6),

    PRIMARY KEY (id),
    UNIQUE KEY uq_security_role_code (role_code),
    KEY idx_security_role_status (role_type, status)
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

### 57. Table: security_permissions

```sql
CREATE TABLE security_permissions (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    permission_code VARCHAR(220) NOT NULL,
    name VARCHAR(255) NOT NULL,
    description VARCHAR(1000) NULL,
    owner_reference VARCHAR(180) NOT NULL,
    risk_level VARCHAR(30) NOT NULL,
    scope_model VARCHAR(80) NOT NULL,
    status VARCHAR(30) NOT NULL DEFAULT 'ACTIVE',
    created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),

    PRIMARY KEY (id),
    UNIQUE KEY uq_security_permission_code (permission_code),
    KEY idx_security_permission_status (risk_level, status)
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

### 58. Table: security_role_permissions

```sql
CREATE TABLE security_role_permissions (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    role_id BIGINT UNSIGNED NOT NULL,
    permission_id BIGINT UNSIGNED NOT NULL,
    effect VARCHAR(10) NOT NULL DEFAULT 'ALLOW',
    conditions_json JSON NULL,
    created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),

    PRIMARY KEY (id),
    UNIQUE KEY uq_security_role_permission (
        role_id,
        permission_id
    ),
    CONSTRAINT fk_security_role_permission_role
        FOREIGN KEY (role_id)
        REFERENCES security_roles (id),
    CONSTRAINT fk_security_role_permission_permission
        FOREIGN KEY (permission_id)
        REFERENCES security_permissions (id)
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

### 59. Table: security_role_assignments

```sql
CREATE TABLE security_role_assignments (
    id CHAR(26) NOT NULL,
    identity_id CHAR(26) NOT NULL,
    role_id BIGINT UNSIGNED NOT NULL,
    tenant_id BIGINT UNSIGNED NULL,
    organization_id BIGINT UNSIGNED NULL,
    clinic_id BIGINT UNSIGNED NULL,
    reason VARCHAR(1000) NULL,
    approved_by VARCHAR(180) NULL,
    effective_from DATETIME(6) NOT NULL,
    expires_at DATETIME(6) NULL,
    status VARCHAR(30) NOT NULL DEFAULT 'ACTIVE',
    created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),

    PRIMARY KEY (id),
    KEY idx_role_assignment_identity (
        identity_id,
        status,
        expires_at
    ),
    KEY idx_role_assignment_scope (
        tenant_id,
        organization_id,
        clinic_id,
        status
    ),
    CONSTRAINT fk_role_assignment_identity
        FOREIGN KEY (identity_id)
        REFERENCES security_identities (id),
    CONSTRAINT fk_role_assignment_role
        FOREIGN KEY (role_id)
        REFERENCES security_roles (id)
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

### 60. Table: security_access_reviews

```sql
CREATE TABLE security_access_reviews (
    id CHAR(26) NOT NULL,
    review_type VARCHAR(60) NOT NULL,
    scope_type VARCHAR(50) NOT NULL,
    scope_reference VARCHAR(255) NOT NULL,
    reviewer_reference VARCHAR(180) NOT NULL,
    status VARCHAR(30) NOT NULL DEFAULT 'DRAFT',
    due_at DATETIME(6) NOT NULL,
    submitted_at DATETIME(6) NULL,
    closed_at DATETIME(6) NULL,
    created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),

    PRIMARY KEY (id),
    KEY idx_access_review_due (
        status,
        due_at
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

### 61. Table: security_access_review_items

```sql
CREATE TABLE security_access_review_items (
    id CHAR(26) NOT NULL,
    review_id CHAR(26) NOT NULL,
    subject_type VARCHAR(50) NOT NULL,
    subject_reference VARCHAR(255) NOT NULL,
    assignment_reference VARCHAR(255) NOT NULL,
    decision VARCHAR(30) NULL,
    reason VARCHAR(2000) NULL,
    decided_at DATETIME(6) NULL,

    PRIMARY KEY (id),
    KEY idx_access_review_item_review (
        review_id,
        decision
    ),
    CONSTRAINT fk_access_review_item_review
        FOREIGN KEY (review_id)
        REFERENCES security_access_reviews (id)
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

### 62. Table: security_privileged_access_requests

```sql
CREATE TABLE security_privileged_access_requests (
    id CHAR(26) NOT NULL,
    identity_id CHAR(26) NOT NULL,
    permission_scope_json JSON NOT NULL,
    reason VARCHAR(2000) NOT NULL,
    risk_level VARCHAR(30) NOT NULL,
    requested_from DATETIME(6) NOT NULL,
    requested_until DATETIME(6) NOT NULL,
    status VARCHAR(30) NOT NULL DEFAULT 'REQUESTED',
    approved_by VARCHAR(180) NULL,
    activated_at DATETIME(6) NULL,
    revoked_at DATETIME(6) NULL,
    created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),

    PRIMARY KEY (id),
    KEY idx_privileged_access_status (
        status,
        requested_until
    ),
    CONSTRAINT fk_privileged_access_identity
        FOREIGN KEY (identity_id)
        REFERENCES security_identities (id)
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

### 63. Table: security_service_accounts

```sql
CREATE TABLE security_service_accounts (
    id CHAR(26) NOT NULL,
    service_code VARCHAR(180) NOT NULL,
    owner_reference VARCHAR(180) NOT NULL,
    environment VARCHAR(30) NOT NULL,
    tenant_id BIGINT UNSIGNED NULL,
    status VARCHAR(30) NOT NULL DEFAULT 'ACTIVE',
    rotation_due_at DATETIME(6) NOT NULL,
    last_rotated_at DATETIME(6) NULL,
    created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),

    PRIMARY KEY (id),
    UNIQUE KEY uq_service_account_code_env (
        service_code,
        environment
    ),
    KEY idx_service_account_rotation (
        status,
        rotation_due_at
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

### 64. Table: security_credentials

```sql
CREATE TABLE security_credentials (
    id CHAR(26) NOT NULL,
    subject_type VARCHAR(50) NOT NULL,
    subject_reference VARCHAR(255) NOT NULL,
    credential_type VARCHAR(50) NOT NULL,
    credential_prefix VARCHAR(50) NULL,
    credential_hash VARCHAR(255) NOT NULL,
    status VARCHAR(30) NOT NULL DEFAULT 'ACTIVE',
    issued_at DATETIME(6) NOT NULL,
    expires_at DATETIME(6) NULL,
    rotation_due_at DATETIME(6) NULL,
    revoked_at DATETIME(6) NULL,
    last_used_at DATETIME(6) NULL,

    PRIMARY KEY (id),
    KEY idx_security_credential_subject (
        subject_type,
        subject_reference,
        status
    ),
    KEY idx_security_credential_expiry (
        status,
        expires_at,
        rotation_due_at
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

### 65. Table: security_key_registry

```sql
CREATE TABLE security_key_registry (
    id CHAR(26) NOT NULL,
    key_code VARCHAR(180) NOT NULL,
    purpose VARCHAR(80) NOT NULL,
    owner_reference VARCHAR(180) NOT NULL,
    environment VARCHAR(30) NOT NULL,
    algorithm VARCHAR(80) NOT NULL,
    active_version INT UNSIGNED NOT NULL,
    status VARCHAR(30) NOT NULL DEFAULT 'ACTIVE',
    rotation_due_at DATETIME(6) NOT NULL,
    created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),

    PRIMARY KEY (id),
    UNIQUE KEY uq_security_key_code_env (
        key_code,
        environment
    ),
    KEY idx_security_key_rotation (
        status,
        rotation_due_at
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

### 66. Table: security_key_versions

```sql
CREATE TABLE security_key_versions (
    id CHAR(26) NOT NULL,
    key_registry_id CHAR(26) NOT NULL,
    key_version INT UNSIGNED NOT NULL,
    key_reference VARCHAR(500) NOT NULL,
    status VARCHAR(30) NOT NULL,
    created_at DATETIME(6) NOT NULL,
    activated_at DATETIME(6) NULL,
    revoked_at DATETIME(6) NULL,

    PRIMARY KEY (id),
    UNIQUE KEY uq_security_key_version (
        key_registry_id,
        key_version
    ),
    CONSTRAINT fk_security_key_version_registry
        FOREIGN KEY (key_registry_id)
        REFERENCES security_key_registry (id)
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

### 67. Table: security_secret_registry

```sql
CREATE TABLE security_secret_registry (
    id CHAR(26) NOT NULL,
    secret_code VARCHAR(180) NOT NULL,
    secret_type VARCHAR(80) NOT NULL,
    owner_reference VARCHAR(180) NOT NULL,
    environment VARCHAR(30) NOT NULL,
    service_code VARCHAR(180) NULL,
    active_version INT UNSIGNED NOT NULL,
    status VARCHAR(30) NOT NULL DEFAULT 'ACTIVE',
    rotation_due_at DATETIME(6) NOT NULL,
    created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),

    PRIMARY KEY (id),
    UNIQUE KEY uq_security_secret_code_env (
        secret_code,
        environment
    ),
    KEY idx_security_secret_rotation (
        status,
        rotation_due_at
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

### 68. Table: security_secure_files

```sql
CREATE TABLE security_secure_files (
    id CHAR(26) NOT NULL,
    tenant_id BIGINT UNSIGNED NOT NULL,
    scope_type VARCHAR(50) NULL,
    scope_reference VARCHAR(255) NULL,
    original_name VARCHAR(255) NOT NULL,
    storage_reference VARCHAR(1000) NOT NULL,
    mime_type VARCHAR(180) NOT NULL,
    size_bytes BIGINT UNSIGNED NOT NULL,
    checksum CHAR(64) NOT NULL,
    classification VARCHAR(40) NOT NULL,
    owner_reference VARCHAR(180) NOT NULL,
    status VARCHAR(30) NOT NULL DEFAULT 'ACTIVE',
    retention_policy_code VARCHAR(180) NOT NULL,
    legal_hold_status VARCHAR(30) NOT NULL DEFAULT 'NONE',
    created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),

    PRIMARY KEY (id),
    KEY idx_secure_file_scope (
        tenant_id,
        scope_type,
        scope_reference,
        status
    ),
    KEY idx_secure_file_retention (
        retention_policy_code,
        legal_hold_status,
        status
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

### 69. Table: security_vulnerabilities

```sql
CREATE TABLE security_vulnerabilities (
    id CHAR(26) NOT NULL,
    source VARCHAR(100) NOT NULL,
    external_reference VARCHAR(255) NULL,
    component VARCHAR(255) NOT NULL,
    component_version VARCHAR(100) NULL,
    severity VARCHAR(30) NOT NULL,
    cvss_score DECIMAL(4,1) NULL,
    description VARCHAR(3000) NOT NULL,
    owner_reference VARCHAR(180) NULL,
    status VARCHAR(30) NOT NULL DEFAULT 'OPEN',
    due_at DATETIME(6) NULL,
    risk_acceptance_reference VARCHAR(255) NULL,
    detected_at DATETIME(6) NOT NULL,
    remediated_at DATETIME(6) NULL,
    verified_at DATETIME(6) NULL,

    PRIMARY KEY (id),
    KEY idx_vulnerability_status (
        severity,
        status,
        due_at
    ),
    KEY idx_vulnerability_component (
        component,
        component_version
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

### 70. Table: security_events

```sql
CREATE TABLE security_events (
    id CHAR(26) NOT NULL,
    event_code VARCHAR(180) NOT NULL,
    severity VARCHAR(30) NOT NULL,
    actor_reference VARCHAR(180) NULL,
    tenant_id BIGINT UNSIGNED NULL,
    scope_reference VARCHAR(255) NULL,
    resource_type VARCHAR(80) NULL,
    resource_reference VARCHAR(255) NULL,
    result VARCHAR(30) NOT NULL,
    request_id VARCHAR(100) NULL,
    correlation_id VARCHAR(100) NULL,
    source_ip_hash CHAR(64) NULL,
    details_json JSON NULL,
    occurred_at DATETIME(6) NOT NULL,
    created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),

    PRIMARY KEY (id),
    KEY idx_security_event_code_time (
        event_code,
        occurred_at
    ),
    KEY idx_security_event_tenant_time (
        tenant_id,
        occurred_at
    ),
    KEY idx_security_event_severity (
        severity,
        occurred_at
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

### 71. Secure Configuration Architecture

```text
Environment
→ Configuration Loader
→ Schema Validation
→ Security Guard
→ Secrets Resolution
→ Runtime Configuration
```

---

### 72. Configuration Validation

Validate at startup:

- environment;
- debug mode;
- base URL;
- HTTPS requirement;
- secure cookie;
- trusted proxies;
- allowed origins;
- encryption key reference;
- secrets availability;
- database credential;
- upload limits;
- evidence path;
- log redaction;
- session timeouts.

---

### 73. Production Configuration Guard

Production should fail readiness if:

- debug enabled;
- secure cookie disabled;
- encryption key missing;
- default secret detected;
- database root credential used;
- evidence path under public root;
- HSTS required but absent;
- wildcard CORS enabled without justification.

---

### 74. Sample Security Config

```php
return [
    'environment' => getenv('APP_ENV') ?: 'production',
    'debug' => false,

    'session' => [
        'secure' => true,
        'http_only' => true,
        'same_site' => 'Lax',
        'idle_timeout_seconds' => 1800,
        'absolute_timeout_seconds' => 28800,
    ],

    'authentication' => [
        'privileged_mfa_required' => true,
        'max_failed_attempts' => 5,
        'lockout_seconds' => 900,
    ],

    'authorization' => [
        'deny_by_default' => true,
        'cross_tenant_default_deny' => true,
    ],

    'uploads' => [
        'max_bytes' => 10 * 1024 * 1024,
        'storage_path' => dirname(__DIR__) . '/storage/secure-files',
    ],
];
```

---

### 75. Apache Hardening

Recommended:

```apache
ServerTokens Prod
ServerSignature Off
TraceEnable Off
Options -Indexes
```

---

### 76. Apache Virtual Host

```apache
<VirtualHost *:80>
    ServerName platform.local
    DocumentRoot "D:/xampp/htdocs/platform/public"

    <Directory "D:/xampp/htdocs/platform/public">
        AllowOverride All
        Require all granted
        Options -Indexes
    </Directory>

    <Directory "D:/xampp/htdocs/platform/storage">
        Require all denied
        Options -Indexes
    </Directory>

    <FilesMatch "\.(env|ini|log|sql|bak|md)$">
        Require all denied
    </FilesMatch>

    ErrorLog "logs/platform-error.log"
    CustomLog "logs/platform-access.log" combined
</VirtualHost>
```

---

### 77. Apache HTTPS Production Direction

Production should use:

- TLS certificate;
- HTTP to HTTPS redirect;
- HSTS;
- modern cipher configuration;
- OCSP/stapling where supported;
- secure proxy headers.

---

### 78. `.htaccess`

```apache
RewriteEngine On

Options -Indexes

<FilesMatch "^\.">
    Require all denied
</FilesMatch>

<FilesMatch "\.(env|ini|log|sql|bak|md)$">
    Require all denied
</FilesMatch>

RewriteCond %{REQUEST_FILENAME} -f [OR]
RewriteCond %{REQUEST_FILENAME} -d
RewriteRule ^ - [L]

RewriteRule ^ index.php [QSA,L]
```

---

### 79. PHP Hardening

Production recommendations:

```ini
display_errors = Off
display_startup_errors = Off
log_errors = On
expose_php = Off
session.use_strict_mode = 1
session.cookie_httponly = 1
session.cookie_secure = 1
session.cookie_samesite = Lax
allow_url_include = Off
file_uploads = On
upload_max_filesize = 10M
post_max_size = 12M
max_execution_time = 30
```

---

### 80. PHP Function Restrictions

Evaluate environment needs before disabling risky functions.

Potential candidates:

```text
exec
shell_exec
system
passthru
proc_open
popen
```

Do not disable blindly if required by controlled workers.

---

### 81. Error Handling

Use:

- generic user response;
- structured internal log;
- correlation ID;
- no stack trace to client;
- no secret or SQL exposure.

---

### 82. Security Event Pipeline

```text
Security-Relevant Action
→ Event Factory
→ Redaction
→ Classification
→ Persist
→ Correlate
→ Detection Rules
→ Alert / Incident Candidate
→ Retention
```

---

### 83. Security Event Categories

```text
AUTHENTICATION
AUTHORIZATION
SESSION
TENANT
PRIVILEGED_ACCESS
CREDENTIAL
KEY
SECRET
FILE
BACKUP
VULNERABILITY
CONFIGURATION
EVIDENCE
INCIDENT
```

---

### 84. Security Event Minimum Fields

```text
event_id
event_code
severity
actor
tenant
scope
resource
result
request_id
correlation_id
occurred_at
classification
```

---

### 85. Security Event Redaction

Never include:

- raw password;
- raw API key;
- session token;
- encryption key;
- secret value;
- full restricted payload.

---

### 86. Detection Rules

Initial rules:

```text
multiple_failed_logins
privileged_login_from_new_context
cross_tenant_denial_spike
permission_escalation
secret_reveal_anomaly
key_access_anomaly
malicious_upload
audit_integrity_failure
critical_vulnerability_overdue
backup_restore_failure
```

---

### 87. Detection Result

```text
INFO
SUSPICIOUS
HIGH_RISK
INCIDENT_CANDIDATE
```

---

### 88. Incident Candidate Criteria

Example:

- confirmed cross-tenant access;
- key compromise;
- secret exfiltration;
- malware execution;
- audit tampering;
- ransomware indicator;
- critical vulnerability exploited.

---

### 89. Vulnerability Management Lifecycle

```text
Discover
→ Normalize
→ Deduplicate
→ Assess
→ Assign
→ Remediate
→ Verify
→ Close
```

---

### 90. Vulnerability Sources

```text
Dependency Scan
SAST
DAST
Container/Image Scan
Infrastructure Scan
Manual Test
Penetration Test
Vendor Advisory
Incident Finding
```

---

### 91. Severity

```text
LOW
MEDIUM
HIGH
CRITICAL
```

---

### 92. Remediation SLA

Initial recommendation:

| Severity | Target |
|---|---:|
| Critical | 24–72 hours |
| High | 7–14 days |
| Medium | 30–60 days |
| Low | 90–180 days |

Final berdasarkan exploitability, exposure, dan business impact.

---

### 93. Risk Acceptance

Risk acceptance wajib:

- owner;
- reason;
- compensating control;
- expiry;
- approval;
- audit.

---

### 94. Vulnerability Verification

Close only after:

- remediation deployed;
- scan/test confirms;
- version verified;
- evidence stored.

---

### 95. Dependency Inventory

Maintain:

```text
package
version
source
license
owner
environment
last_scan
```

---

### 96. SBOM Direction

Generate Software Bill of Materials where feasible.

---

### 97. Scheduler Architecture

```text
Security Scheduler
    │
    ├── Session Cleanup
    ├── Credential Expiry Check
    ├── Privileged Access Expiry
    ├── Access Review Due Check
    ├── Key Rotation Check
    ├── Secret Rotation Check
    ├── Vulnerability SLA Check
    ├── Evidence Integrity Check
    ├── Legal Hold Reconciliation
    ├── Backup Verification
    ├── Security Event Correlation
    └── Incident Reconciliation
```

---

### 98. Required Jobs

```text
security-session-cleanup
security-credential-expiry-check
security-privileged-access-expire
security-access-review-due
security-key-rotation-check
security-secret-rotation-check
security-vulnerability-sla-check
security-evidence-integrity-check
security-legal-hold-reconcile
security-backup-verify
security-event-correlate
security-incident-reconcile
```

---

### 99. Job Frequency

| Job | Frequency |
|---|---:|
| Session cleanup | every 5–15 minutes |
| Credential expiry | hourly |
| Privileged access expiry | every 5 minutes |
| Access review due | daily |
| Key rotation check | daily |
| Secret rotation check | daily |
| Vulnerability SLA | daily |
| Evidence integrity | daily/weekly |
| Legal hold reconcile | hourly/daily |
| Backup verify | daily |
| Event correlation | near-real-time/hourly |
| Incident reconcile | hourly |

---

### 100. Job Locking

Examples:

```text
security-session-cleanup:{minute}
security-credential-expiry:{hour}
security-key-rotation:{date}
security-vulnerability-sla:{date}
security-evidence-verify:{batch}
security-event-correlation:{window}
```

---

### 101. Job Idempotency

Required for:

- session revocation;
- credential expiry;
- privileged access expiry;
- vulnerability escalation;
- evidence verification;
- incident creation.

---

### 102. Incident Integration

Security events can create or enrich incidents.

Flow:

```text
Security Event
→ Detection
→ Triage
→ Incident Candidate
→ Incident Created
→ Evidence Attached
→ Containment
→ Recovery
→ Post-Incident Review
```

---

### 103. Incident Severity

```text
SEV1 — Critical compromise/business impact
SEV2 — Major security impact
SEV3 — Limited impact
SEV4 — Low-risk investigation
```

---

### 104. Incident Evidence

Attach:

- event timeline;
- access records;
- audit records;
- file hashes;
- affected identities;
- affected tenants;
- containment actions;
- recovery evidence.

---

### 105. Containment Actions

Possible actions:

- revoke session;
- disable identity;
- revoke credential;
- rotate secret;
- revoke key;
- quarantine file;
- block IP/client;
- disable integration;
- freeze privileged assignment.

---

### 106. Incident Automation Guardrails

Automation must not:

- delete evidence;
- rotate destructive key without approval;
- disable all tenants accidentally;
- purge affected data;
- alter audit history.

---

### 107. Audit Integration

Security actions requiring audit:

```text
IDENTITY_CREATED
IDENTITY_DISABLED
ROLE_CHANGED
PERMISSION_CHANGED
ROLE_ASSIGNED
PRIVILEGED_ACCESS_APPROVED
CREDENTIAL_ROTATED
KEY_ROTATED
SECRET_REVEALED
LEGAL_HOLD_CREATED
EVIDENCE_EXPORTED
VULNERABILITY_RISK_ACCEPTED
INCIDENT_CLOSED
```

---

### 108. Structured Logging Example

```json
{
  "event_code": "SEC_CROSS_TENANT_ACCESS_DENIED",
  "level": "WARNING",
  "actor_id": "01J...",
  "tenant_id": 10,
  "target_tenant_id": 11,
  "resource_type": "patient",
  "result": "DENIED",
  "request_id": "01J...",
  "correlation_id": "01J..."
}
```

---

### 109. Metrics

```text
security_api_request_total
security_api_error_total
authentication_failure_total
mfa_failure_total
authorization_denial_total
cross_tenant_denial_total
active_session_total
privileged_access_active_total
credential_expired_total
key_rotation_overdue_total
secret_rotation_overdue_total
vulnerability_open_total
vulnerability_overdue_total
security_event_total
security_incident_total
evidence_integrity_failure_total
backup_verification_failure_total
```

---

### 110. Alert Candidates

```text
credential_stuffing_detected
privileged_mfa_failure_spike
cross_tenant_access_attempt
critical_permission_assigned
credential_expired_in_use
key_rotation_overdue
secret_rotation_overdue
malware_upload_detected
critical_vulnerability_overdue
audit_integrity_failure
evidence_integrity_failure
backup_verification_failed
incident_candidate_created
```

---

### 111. Error Codes

```text
SEC_CONFIG_INVALID
SEC_MIDDLEWARE_CONTEXT_MISSING
SEC_TRUSTED_PROXY_INVALID
SEC_REQUEST_TOO_LARGE
AUTH_INVALID_CREDENTIALS
AUTH_MFA_REQUIRED
AUTH_SESSION_EXPIRED
AUTH_REAUTH_REQUIRED
AUTHZ_PERMISSION_DENIED
AUTHZ_TENANT_DENIED
AUTHZ_SCOPE_DENIED
SEC_ROLE_ASSIGNMENT_CONFLICT
SEC_PRIVILEGED_ACCESS_EXPIRED
SEC_CREDENTIAL_EXPIRED
SEC_KEY_ROTATION_OVERDUE
SEC_SECRET_ROTATION_OVERDUE
SEC_FILE_QUARANTINED
SEC_EVIDENCE_INTEGRITY_FAILED
SEC_VULNERABILITY_OVERDUE
SEC_INCIDENT_CREATION_FAILED
```

---

### 112. Route Registration

```php
$router->group('/api/internal/v1/security', [
    'middleware' => [
        RequestIdMiddleware::class,
        TrustedProxyMiddleware::class,
        SecurityHeadersMiddleware::class,
        RequestSizeLimitMiddleware::class,
        AuthenticationMiddleware::class,
        SessionValidationMiddleware::class,
        RateLimitMiddleware::class,
        TenantContextMiddleware::class,
        ActiveScopeMiddleware::class,
        AuthorizationMiddleware::class,
        ClassificationMiddleware::class,
        AuditContextMiddleware::class,
    ],
], function ($router): void {
    $router->get('/sessions', [
        SessionController::class,
        'index',
    ]);

    $router->post('/privileged-access/requests', [
        PrivilegedAccessController::class,
        'request',
    ]);

    $router->post('/credentials/{credentialId}/rotate', [
        CredentialController::class,
        'rotate',
    ]);

    $router->post('/keys/{keyId}/rotate', [
        KeyController::class,
        'rotate',
    ]);

    $router->post('/secrets/{secretId}/reveal', [
        SecretsController::class,
        'reveal',
    ]);

    $router->get('/files/{fileId}/download', [
        SecureFileController::class,
        'download',
    ]);
});
```

---

### 113. CLI Commands

```bash
php bin/console security:session:cleanup
php bin/console security:credential:check-expiry
php bin/console security:privileged-access:expire
php bin/console security:access-review:check-due
php bin/console security:key:check-rotation
php bin/console security:secret:check-rotation
php bin/console security:vulnerability:check-sla
php bin/console security:evidence:verify
php bin/console security:legal-hold:reconcile
php bin/console security:backup:verify
php bin/console security:event:correlate
php bin/console security:incident:reconcile
```

---

### 114. Sequence Diagram — Login with MFA

```mermaid
sequenceDiagram
    participant User
    participant API
    participant Auth
    participant Identity
    participant MFA
    participant Session
    participant Events

    User->>API: Submit username/password
    API->>Auth: Authenticate
    Auth->>Identity: Load active identity
    Identity-->>Auth: Identity
    Auth->>Auth: Verify password
    Auth->>MFA: Check MFA requirement
    MFA-->>API: MFA required
    User->>API: Submit MFA code
    API->>MFA: Verify factor
    MFA-->>Session: Authentication success
    Session->>Events: SESSION_CREATED
    Session-->>User: Secure session
```

---

### 115. Sequence Diagram — Authorization with Tenant Scope

```mermaid
sequenceDiagram
    participant Client
    participant Middleware
    participant Tenant
    participant AuthZ
    participant Resource
    participant Audit

    Client->>Middleware: Request resource
    Middleware->>Tenant: Resolve active tenant/scope
    Tenant-->>Middleware: Trusted context
    Middleware->>Resource: Load resource metadata
    Resource-->>Middleware: Tenant/scope/classification
    Middleware->>AuthZ: Decide permission + resource
    alt Allowed
        AuthZ-->>Middleware: ALLOW
        Middleware-->>Client: Resource response
    else Denied
        AuthZ->>Audit: Record denial
        AuthZ-->>Middleware: DENY
        Middleware-->>Client: 403/404
    end
```

---

### 116. Sequence Diagram — Privileged Access

```mermaid
sequenceDiagram
    participant User
    participant API
    participant Privileged
    participant Approver
    participant Session
    participant Audit

    User->>API: Request temporary access
    API->>Privileged: Validate scope/risk
    Privileged->>Approver: Request approval
    Approver-->>Privileged: Approve
    Privileged->>Session: Require re-authentication/MFA
    Session-->>Privileged: AAL2 confirmed
    Privileged->>Audit: Record activation
    Privileged-->>User: Time-bound access active
```

---

### 117. Sequence Diagram — Secret Rotation

```mermaid
sequenceDiagram
    participant Scheduler
    participant Secrets
    participant Store
    participant Service
    participant Audit

    Scheduler->>Secrets: Rotate due secret
    Secrets->>Store: Create new version
    Store-->>Secrets: New secret reference
    Secrets->>Service: Deploy new reference
    Service-->>Secrets: Verification success
    Secrets->>Store: Revoke old version
    Secrets->>Audit: Record rotation
```

---

### 118. Sequence Diagram — Vulnerability Lifecycle

```mermaid
sequenceDiagram
    participant Scanner
    participant API
    participant Vuln
    participant Owner
    participant Verifier
    participant Audit

    Scanner->>API: Import finding
    API->>Vuln: Normalize/deduplicate
    Vuln->>Owner: Assign remediation
    Owner->>Vuln: Mark remediated
    Vuln->>Verifier: Request verification
    Verifier-->>Vuln: Verified
    Vuln->>Audit: Record closure
```

---

### 119. Sequence Diagram — Security Event to Incident

```mermaid
sequenceDiagram
    participant Event
    participant Detection
    participant Incident
    participant Evidence
    participant Response

    Event->>Detection: Evaluate rule
    Detection-->>Incident: Incident candidate
    Incident->>Evidence: Attach event timeline
    Incident->>Response: Trigger triage
    Response->>Response: Contain and recover
    Response->>Incident: Close with evidence
```

---

### 120. Performance Targets

| Operation | Target |
|---|---:|
| Session validation p95 | < 25 ms |
| Authorization decision p95 | < 30 ms |
| Tenant context resolution p95 | < 20 ms |
| Credential verification p95 | < 100 ms |
| Security event write p95 | < 100 ms |
| Session revoke p95 | < 100 ms |
| Secure file metadata lookup p95 | < 100 ms |
| Vulnerability list p95 | < 500 ms |
| Security dashboard p95 | < 1.5 s |

---

### 121. Testing Strategy

#### Unit

- middleware order;
- trusted proxy validation;
- session timeout;
- AAL requirement;
- authorization decision;
- tenant/scope guard;
- config validation;
- vulnerability SLA;
- incident candidate rule.

#### Integration

- login/MFA/session;
- role assignment;
- privilege activation/expiry;
- credential rotation;
- key/secret rotation;
- secure file download;
- vulnerability import/verification;
- event-to-incident bridge;
- scheduler locks.

#### Security

- header spoofing;
- session fixation;
- CSRF;
- cross-tenant access;
- path traversal;
- secret reveal abuse;
- key access abuse;
- vulnerability risk acceptance bypass;
- incident evidence tampering.

---

### 122. UAT Part 4

#### Middleware

- [ ] Request ID tersedia.
- [ ] Trusted proxy validation bekerja.
- [ ] Security headers aktif.
- [ ] Request size limit aktif.
- [ ] Authentication middleware aktif.
- [ ] Session validation aktif.
- [ ] AAL/re-authentication aktif.
- [ ] Tenant/scope middleware aktif.
- [ ] Authorization aktif.
- [ ] CSRF aktif.
- [ ] Classification/masking aktif.
- [ ] Audit context tersedia.

#### APIs

- [ ] Authentication API bekerja.
- [ ] Session API bekerja.
- [ ] Identity API bekerja.
- [ ] Role/permission API bekerja.
- [ ] Access review API bekerja.
- [ ] Privileged access API bekerja.
- [ ] Credential/key/secret API bekerja.
- [ ] Secure file API bekerja.
- [ ] Legal hold/evidence API bekerja.
- [ ] Vulnerability API bekerja.
- [ ] Incident API bekerja.

#### Database

- [ ] Migrations berhasil.
- [ ] Identity/session schema aktif.
- [ ] Role/permission schema aktif.
- [ ] Scoped assignments aktif.
- [ ] Privileged access schema aktif.
- [ ] Credential/key/secret schema aktif.
- [ ] Secure file schema aktif.
- [ ] Vulnerability schema aktif.
- [ ] Security event schema aktif.
- [ ] Index mendukung query utama.

#### Secure Configuration

- [ ] Production debug off.
- [ ] Secure cookie enforced.
- [ ] Trusted proxies configured.
- [ ] Default secrets rejected.
- [ ] Root DB credential rejected.
- [ ] Public evidence path rejected.
- [ ] Upload limits configured.
- [ ] Readiness fails on critical misconfiguration.

#### Apache/PHP Hardening

- [ ] Directory listing off.
- [ ] Sensitive extensions blocked.
- [ ] Storage directory blocked.
- [ ] Server signature reduced.
- [ ] PHP errors hidden from client.
- [ ] Session strict mode active.
- [ ] Upload limits active.
- [ ] HTTPS/HSTS plan available.

#### Security Events & Detection

- [ ] Security events persisted.
- [ ] Redaction works.
- [ ] Correlation IDs available.
- [ ] Detection rules execute.
- [ ] High-risk event creates alert.
- [ ] Incident candidate created.
- [ ] No secrets in event payload.
- [ ] Retention applied.

#### Vulnerability Management

- [ ] Findings imported.
- [ ] Deduplication works.
- [ ] Severity/SLA available.
- [ ] Owner assignment works.
- [ ] Risk acceptance time-bound.
- [ ] Overdue alert works.
- [ ] Remediation verification works.
- [ ] Closure evidence stored.

#### Scheduler

- [ ] Session cleanup works.
- [ ] Credential expiry check works.
- [ ] Privileged access expiry works.
- [ ] Access review due check works.
- [ ] Key/secret rotation check works.
- [ ] Vulnerability SLA check works.
- [ ] Evidence integrity check works.
- [ ] Backup verification works.
- [ ] Event correlation works.
- [ ] Incident reconciliation works.
- [ ] Locks/idempotency work.

#### Incident Integration

- [ ] Incident created from security event.
- [ ] Evidence attached.
- [ ] Containment actions available.
- [ ] Credential/session revocation works.
- [ ] File quarantine works.
- [ ] Recovery evidence captured.
- [ ] Post-incident review linked.
- [ ] Audit preserved.

---

### 123. Anti-Pattern

Hindari:

- authorization manual di controller;
- tenant dari hidden input dipercaya;
- middleware order tidak konsisten;
- security event berisi secret;
- root DB credential untuk aplikasi;
- evidence/file storage di web root;
- risk acceptance tanpa expiry;
- vulnerability close tanpa verification;
- scheduler tanpa lock;
- incident automation menghapus evidence;
- production debug aktif;
- wildcard CORS tanpa alasan;
- role/permission update tanpa session/cache invalidation.

---

### 124. Definition of Done Part 4

Part 4 dianggap selesai bila:

- [ ] middleware architecture tersedia;
- [ ] middleware order tersedia;
- [ ] controller standards tersedia;
- [ ] security service contracts tersedia;
- [ ] authentication/session APIs tersedia;
- [ ] identity/role/permission APIs tersedia;
- [ ] privileged access APIs tersedia;
- [ ] credential/key/secret APIs tersedia;
- [ ] file/legal hold/evidence APIs tersedia;
- [ ] vulnerability/incident APIs tersedia;
- [ ] database schema tersedia;
- [ ] secure configuration validation tersedia;
- [ ] Apache hardening tersedia;
- [ ] PHP hardening tersedia;
- [ ] security event pipeline tersedia;
- [ ] detection rules tersedia;
- [ ] vulnerability lifecycle tersedia;
- [ ] scheduler architecture tersedia;
- [ ] incident integration tersedia;
- [ ] audit integration tersedia;
- [ ] metrics/alerts tersedia;
- [ ] error codes tersedia;
- [ ] route registration tersedia;
- [ ] CLI commands tersedia;
- [ ] sequence diagrams tersedia;
- [ ] performance targets tersedia;
- [ ] testing strategy tersedia;
- [ ] UAT tersedia.

---

### 125. Rencana Part Berikutnya

#### Part 5

Reference implementation, sample policies, migration, deployment, rollback, attack simulations, security test plan, operational runbooks, final UAT, Definition of Done, roadmap, dan merge guidance menjadi `SSOT-SEC-01.md`.

---

## Bagian V — Reference Implementation & Operational Readiness

### 1. Executive Summary

Part 5 menutup rangkaian SSOT-SEC-01 dengan reference implementation dan operational readiness untuk Security Implementation Framework.

Bagian ini mencakup:

- bootstrap wiring;
- security kernel composition;
- sample identity and access policies;
- authentication and session implementation;
- authorization and tenant isolation;
- privileged access;
- credentials, keys, and secrets;
- secure file handling;
- vulnerability management;
- security event pipeline;
- migration;
- deployment;
- rollback;
- attack simulations;
- security test plan;
- operational runbooks;
- final UAT;
- Definition of Done;
- roadmap;
- merge guidance menjadi `SSOT-SEC-01.md`.

Tujuan akhirnya adalah memastikan security framework dapat:

- dijalankan;
- diuji;
- diaudit;
- dipantau;
- dipulihkan;
- ditingkatkan;
- diterapkan konsisten oleh seluruh module.

---

### 2. Initial Implementation Scope

Initial release wajib mencakup:

```text
Identity Registry
Authentication Service
MFA Support
Session Service
Authorization Engine
Tenant/Scope Guard
Role & Permission Registry
Privileged Access Workflow
Credential Registry
Key Registry
Secret Registry
Secure File Service
Security Event Pipeline
Vulnerability Registry
Security Scheduler
Incident Bridge
```

---

### 3. Final Folder Structure

```text
app/
└── Platform/
    └── Security/
        ├── Domain/
        │   ├── Identity.php
        │   ├── SecuritySession.php
        │   ├── Role.php
        │   ├── Permission.php
        │   ├── RoleAssignment.php
        │   ├── AuthorizationDecision.php
        │   ├── PrivilegedAccessRequest.php
        │   ├── ServiceAccount.php
        │   ├── SecurityCredential.php
        │   ├── KeyRegistry.php
        │   ├── SecretRegistry.php
        │   ├── SecureFile.php
        │   ├── Vulnerability.php
        │   ├── SecurityEvent.php
        │   └── SecurityIncident.php
        │
        ├── Application/
        │   ├── IdentityService.php
        │   ├── AuthenticationService.php
        │   ├── AuthorizationService.php
        │   ├── SessionService.php
        │   ├── AccessReviewService.php
        │   ├── PrivilegedAccessService.php
        │   ├── CredentialService.php
        │   ├── KeyManagementService.php
        │   ├── SecretsService.php
        │   ├── SecureFileService.php
        │   ├── VulnerabilityService.php
        │   ├── SecurityEventService.php
        │   ├── SecurityIncidentBridge.php
        │   └── Contracts/
        │
        ├── Infrastructure/
        │   ├── Persistence/
        │   ├── Authentication/
        │   ├── Authorization/
        │   ├── Crypto/
        │   ├── Secrets/
        │   ├── Files/
        │   ├── Events/
        │   ├── Scheduler/
        │   ├── Vulnerability/
        │   └── Incident/
        │
        └── Presentation/
            ├── Http/
            │   ├── Controllers/
            │   └── Middleware/
            └── Cli/

config/
├── security.php
├── security-authentication.php
├── security-authorization.php
├── security-crypto.php
├── security-secrets.php
├── security-files.php
├── security-vulnerability.php
└── security-scheduler.php

database/
└── migrations/
    └── create_security_framework_tables.sql

resources/
├── security/
│   ├── policies/
│   ├── runbooks/
│   ├── threat-models/
│   └── test-cases/
└── security-evidence/

storage/
├── secure-files/
├── security-evidence/
├── quarantine/
└── security-exports/

tests/
├── Unit/Security/
├── Integration/Security/
├── Security/
└── Uat/Security/

tools/
├── security-config-check.php
├── security-permission-audit.php
├── security-tenant-isolation-test.php
├── security-secret-scan.php
├── security-vulnerability-import.php
├── security-evidence-verify.php
└── security-reconcile.php
```

---

### 4. Security Bootstrap

```php
<?php

declare(strict_types=1);

namespace App\Platform\Security;

final class SecurityBootstrap
{
    public static function build(
        array $config,
        object $container
    ): SecurityKernel {
        return new SecurityKernel(
            identities: $container->get(
                IdentityServiceInterface::class
            ),
            authentication: $container->get(
                AuthenticationServiceInterface::class
            ),
            authorization: $container->get(
                AuthorizationServiceInterface::class
            ),
            sessions: $container->get(
                SessionServiceInterface::class
            ),
            privilegedAccess: $container->get(
                PrivilegedAccessServiceInterface::class
            ),
            credentials: $container->get(
                CredentialServiceInterface::class
            ),
            keys: $container->get(
                KeyManagementServiceInterface::class
            ),
            secrets: $container->get(
                SecretsServiceInterface::class
            ),
            files: $container->get(
                SecureFileServiceInterface::class
            ),
            vulnerabilities: $container->get(
                VulnerabilityManagementServiceInterface::class
            ),
            events: $container->get(
                SecurityEventServiceInterface::class
            ),
            incidents: $container->get(
                SecurityIncidentBridgeInterface::class
            )
        );
    }
}
```

---

### 5. Security Kernel

```php
final class SecurityKernel
{
    public function __construct(
        public readonly IdentityServiceInterface $identities,
        public readonly AuthenticationServiceInterface $authentication,
        public readonly AuthorizationServiceInterface $authorization,
        public readonly SessionServiceInterface $sessions,
        public readonly PrivilegedAccessServiceInterface $privilegedAccess,
        public readonly CredentialServiceInterface $credentials,
        public readonly KeyManagementServiceInterface $keys,
        public readonly SecretsServiceInterface $secrets,
        public readonly SecureFileServiceInterface $files,
        public readonly VulnerabilityManagementServiceInterface $vulnerabilities,
        public readonly SecurityEventServiceInterface $events,
        public readonly SecurityIncidentBridgeInterface $incidents
    ) {
    }
}
```

---

### 6. Password Hasher Reference

```php
final class PasswordHasher
{
    public function hash(string $password): string
    {
        $hash = password_hash(
            $password,
            PASSWORD_ARGON2ID
        );

        if ($hash === false) {
            throw new \RuntimeException(
                'Unable to hash password.'
            );
        }

        return $hash;
    }

    public function verify(
        string $password,
        string $hash
    ): bool {
        return password_verify($password, $hash);
    }

    public function needsRehash(string $hash): bool
    {
        return password_needs_rehash(
            $hash,
            PASSWORD_ARGON2ID
        );
    }
}
```

---

### 7. Authentication Service Reference

```php
final class AuthenticationService
    implements AuthenticationServiceInterface
{
    public function __construct(
        private readonly IdentityRepositoryInterface $identities,
        private readonly PasswordHasher $passwords,
        private readonly LoginThrottleInterface $throttle,
        private readonly MfaPolicyInterface $mfaPolicy,
        private readonly SecurityEventServiceInterface $events,
        private readonly ClockInterface $clock
    ) {
    }

    public function authenticate(
        AuthenticationCommand $command,
        AuthenticationContext $context
    ): AuthenticationResult {
        $this->throttle->assertAllowed(
            $command->identifier,
            $context
        );

        $identity = $this->identities->findByIdentifier(
            $command->identifier
        );

        if (
            $identity === null
            || !$identity->canAuthenticate()
            || !$this->passwords->verify(
                $command->password,
                $identity->passwordHash()
            )
        ) {
            $this->events->record(
                SecurityEvent::authenticationFailed(
                    identifierHash: hash(
                        'sha256',
                        $command->identifier
                    ),
                    context: $context,
                    occurredAt: $this->clock->now()
                )
            );

            $this->throttle->recordFailure(
                $command->identifier,
                $context
            );

            return AuthenticationResult::failure();
        }

        $this->throttle->recordSuccess(
            $command->identifier,
            $context
        );

        if ($this->mfaPolicy->requiresMfa($identity)) {
            return AuthenticationResult::mfaRequired(
                identityId: $identity->id()
            );
        }

        return AuthenticationResult::success(
            identity: $identity,
            assurance: AuthenticationAssurance::AAL1
        );
    }
}
```

---

### 8. MFA Verification Reference

```php
final class MfaVerificationService
{
    public function verify(
        MfaVerificationCommand $command,
        AuthenticationContext $context
    ): AuthenticationResult {
        $challenge = $this->challenges->findActive(
            $command->challengeId
        );

        if ($challenge === null) {
            throw new MfaChallengeNotFoundException();
        }

        if (!$this->verifier->verify(
            $challenge,
            $command->code
        )) {
            $this->events->record(
                SecurityEvent::mfaFailed(
                    challengeId: $challenge->id(),
                    context: $context
                )
            );

            return AuthenticationResult::mfaFailure();
        }

        $challenge->complete($this->clock->now());
        $this->challenges->save($challenge);

        return AuthenticationResult::success(
            identity: $challenge->identity(),
            assurance: AuthenticationAssurance::AAL2
        );
    }
}
```

---

### 9. Session Service Reference

```php
final class SessionService
    implements SessionServiceInterface
{
    public function create(
        AuthenticatedIdentity $identity,
        SessionCreateContext $context
    ): SecuritySession {
        $rawToken = bin2hex(random_bytes(32));
        $tokenHash = hash('sha256', $rawToken);

        $session = SecuritySession::create(
            id: $this->ids->ulid(),
            identityId: $identity->id(),
            tenantId: $context->tenantId,
            scopeType: $context->scopeType,
            scopeReference: $context->scopeReference,
            authenticationAssurance: $identity->assurance(),
            permissionVersion: $identity->permissionVersion(),
            sessionHash: $tokenHash,
            createdAt: $this->clock->now(),
            idleExpiresAt: $this->clock->now()->modify(
                '+' . $this->idleTimeoutSeconds . ' seconds'
            ),
            absoluteExpiresAt: $this->clock->now()->modify(
                '+' . $this->absoluteTimeoutSeconds . ' seconds'
            )
        );

        $this->sessions->save($session);

        return $session->withRawToken($rawToken);
    }
}
```

---

### 10. Session Validation Reference

```php
final class SessionValidator
{
    public function validate(
        string $rawToken,
        \DateTimeImmutable $now
    ): SecuritySession {
        $hash = hash('sha256', $rawToken);
        $session = $this->sessions->findByHash($hash);

        if ($session === null) {
            throw new SessionNotFoundException();
        }

        if (!$session->isValidAt($now)) {
            throw new SessionExpiredException();
        }

        $identity = $this->identities->findById(
            $session->identityId()
        );

        if (
            $identity === null
            || !$identity->isActive()
            || $identity->permissionVersion()
                !== $session->permissionVersion()
        ) {
            throw new SessionRevokedException();
        }

        return $session;
    }
}
```

---

### 11. Authorization Service Reference

```php
final class AuthorizationService
    implements AuthorizationServiceInterface
{
    public function decide(
        AuthorizationRequest $request,
        SecurityContext $context
    ): AuthorizationDecision {
        if (!$context->identity()->isActive()) {
            return AuthorizationDecision::deny(
                'IDENTITY_INACTIVE'
            );
        }

        if (!$this->tenantGuard->allows(
            $request,
            $context
        )) {
            return AuthorizationDecision::deny(
                'TENANT_DENIED'
            );
        }

        if (!$this->scopeGuard->allows(
            $request,
            $context
        )) {
            return AuthorizationDecision::deny(
                'SCOPE_DENIED'
            );
        }

        $permissions = $this->permissions->resolve(
            identityId: $context->identity()->id(),
            tenantId: $context->tenantId(),
            scope: $context->scope()
        );

        if (!$permissions->allows($request->permission)) {
            return AuthorizationDecision::deny(
                'PERMISSION_DENIED'
            );
        }

        if ($request->resource !== null) {
            $resourceDecision = $this->resourcePolicies->decide(
                $request->resource,
                $request,
                $context
            );

            if ($resourceDecision->isDenied()) {
                return $resourceDecision;
            }
        }

        return AuthorizationDecision::allow();
    }
}
```

---

### 12. Tenant Guard Reference

```php
final class TenantGuard
{
    public function allows(
        AuthorizationRequest $request,
        SecurityContext $context
    ): bool {
        if ($request->resourceTenantId === null) {
            return true;
        }

        if (
            $request->resourceTenantId
            === $context->tenantId()
        ) {
            return true;
        }

        return $context->hasPermission(
            'security.cross_tenant.access'
        ) && $request->purpose !== null;
    }
}
```

---

### 13. Role Assignment Service Reference

```php
final class RoleAssignmentService
{
    public function assign(
        RoleAssignmentCommand $command,
        SecurityContext $context
    ): RoleAssignment {
        $role = $this->roles->findByCode(
            $command->roleCode
        );

        if ($role === null) {
            throw new RoleNotFoundException();
        }

        $this->sod->assertNoConflict(
            identityId: $command->identityId,
            role: $role,
            tenantId: $command->tenantId,
            scope: $command->scope
        );

        if ($role->isPrivileged()) {
            $this->privilegedGuard->assertAssignmentAllowed(
                $command,
                $context
            );
        }

        $assignment = RoleAssignment::create(
            id: $this->ids->ulid(),
            identityId: $command->identityId,
            roleId: $role->id(),
            tenantId: $command->tenantId,
            organizationId: $command->organizationId,
            clinicId: $command->clinicId,
            reason: $command->reason,
            approvedBy: $context->actorReference(),
            effectiveFrom: $command->effectiveFrom,
            expiresAt: $command->expiresAt
        );

        $this->assignments->save($assignment);
        $this->identities->incrementPermissionVersion(
            $command->identityId
        );

        return $assignment;
    }
}
```

---

### 14. Privileged Access Reference

```php
final class PrivilegedAccessService
    implements PrivilegedAccessServiceInterface
{
    public function activate(
        string $requestId,
        SecurityContext $context
    ): PrivilegedAccessRequest {
        $request = $this->requests->findById($requestId);

        if ($request === null) {
            throw new PrivilegedAccessRequestNotFoundException();
        }

        if (!$context->authenticationAssurance()->isAtLeastAal2()) {
            throw new ReauthenticationRequiredException();
        }

        if (!$request->isApproved()) {
            throw new PrivilegedAccessNotApprovedException();
        }

        $request->activate(
            activatedAt: $this->clock->now()
        );

        $this->requests->save($request);

        return $request;
    }
}
```

---

### 15. Credential Issue Reference

```php
final class CredentialService
    implements CredentialServiceInterface
{
    public function issue(
        CredentialIssueCommand $command,
        SecurityContext $context
    ): IssuedCredential {
        $rawSecret = $this->generator->generate(
            $command->credentialType
        );

        $credential = SecurityCredential::issue(
            id: $this->ids->ulid(),
            subjectType: $command->subjectType,
            subjectReference: $command->subjectReference,
            credentialType: $command->credentialType,
            prefix: $command->prefix,
            credentialHash: $this->hasher->hash($rawSecret),
            issuedAt: $this->clock->now(),
            expiresAt: $command->expiresAt,
            rotationDueAt: $command->rotationDueAt
        );

        $this->credentials->save($credential);

        return IssuedCredential::create(
            credential: $credential,
            rawSecret: $rawSecret
        );
    }
}
```

---

### 16. Key Rotation Reference

```php
final class KeyManagementService
    implements KeyManagementServiceInterface
{
    public function rotate(
        KeyRotationCommand $command
    ): KeyRotationResult {
        $registry = $this->keys->findByCode(
            $command->keyCode,
            $command->environment
        );

        if ($registry === null) {
            throw new KeyNotFoundException();
        }

        $newVersion = $registry->nextVersion();
        $reference = $this->provider->generateKey(
            keyCode: $registry->keyCode(),
            version: $newVersion,
            algorithm: $registry->algorithm()
        );

        $registry->activateVersion(
            version: $newVersion,
            keyReference: $reference,
            activatedAt: $this->clock->now()
        );

        $this->keys->save($registry);

        return KeyRotationResult::success(
            keyCode: $registry->keyCode(),
            newVersion: $newVersion
        );
    }
}
```

---

### 17. Secret Rotation Reference

```php
final class SecretsService
    implements SecretsServiceInterface
{
    public function rotate(
        SecretRotationCommand $command
    ): SecretRotationResult {
        $secret = $this->secrets->findByCode(
            $command->secretCode,
            $command->environment
        );

        if ($secret === null) {
            throw new SecretNotFoundException();
        }

        $newValue = $this->generator->generate(
            $secret->type()
        );

        $newReference = $this->provider->store(
            secretCode: $secret->code(),
            version: $secret->nextVersion(),
            value: $newValue
        );

        $secret->activateNewVersion(
            reference: $newReference,
            rotatedAt: $this->clock->now()
        );

        $this->secrets->save($secret);

        return SecretRotationResult::success(
            secretCode: $secret->code(),
            version: $secret->activeVersion()
        );
    }
}
```

---

### 18. Secure File Service Reference

```php
final class SecureFileService
    implements SecureFileServiceInterface
{
    public function store(
        SecureFileUploadCommand $command,
        SecurityContext $context
    ): SecureFile {
        $this->validator->validate(
            stream: $command->stream,
            originalName: $command->originalName,
            expectedClassification: $command->classification
        );

        $scan = $this->malwareScanner->scan(
            $command->stream
        );

        if ($scan->isMalicious()) {
            $this->quarantine->store(
                $command->stream,
                $command->originalName
            );

            throw new MalwareDetectedException();
        }

        $storageName = $this->ids->ulid();
        $stored = $this->storage->store(
            storageName: $storageName,
            stream: $command->stream
        );

        $file = SecureFile::create(
            id: $this->ids->ulid(),
            tenantId: $context->tenantId(),
            scope: $context->scope(),
            originalName: $command->originalName,
            storageReference: $stored->reference,
            mimeType: $stored->mimeType,
            sizeBytes: $stored->sizeBytes,
            checksum: $stored->checksum,
            classification: $command->classification,
            ownerReference: $context->actorReference(),
            retentionPolicyCode: $command->retentionPolicyCode
        );

        $this->files->save($file);

        return $file;
    }
}
```

---

### 19. Security Event Factory Reference

```php
final class SecurityEventFactory
{
    public function create(
        string $eventCode,
        string $severity,
        SecurityContext $context,
        array $details = []
    ): SecurityEvent {
        return SecurityEvent::create(
            id: $this->ids->ulid(),
            eventCode: $eventCode,
            severity: $severity,
            actorReference: $context->actorReference(),
            tenantId: $context->tenantId(),
            scopeReference: $context->scopeReference(),
            requestId: $context->requestId(),
            correlationId: $context->correlationId(),
            result: $details['result'] ?? 'UNKNOWN',
            details: $this->redactor->redact($details),
            occurredAt: $this->clock->now()
        );
    }
}
```

---

### 20. Vulnerability Import Reference

```php
final class VulnerabilityManagementService
    implements VulnerabilityManagementServiceInterface
{
    public function import(
        VulnerabilityImportCommand $command,
        SecurityContext $context
    ): VulnerabilityImportResult {
        $created = [];
        $updated = [];

        foreach ($command->findings as $finding) {
            $normalized = $this->normalizer->normalize(
                $finding
            );

            $existing = $this->vulnerabilities->findDuplicate(
                $normalized
            );

            if ($existing !== null) {
                $existing->refreshFrom(
                    $normalized,
                    $this->clock->now()
                );

                $this->vulnerabilities->save($existing);
                $updated[] = $existing;
                continue;
            }

            $vulnerability = Vulnerability::create(
                id: $this->ids->ulid(),
                source: $normalized->source,
                externalReference: $normalized->externalReference,
                component: $normalized->component,
                componentVersion: $normalized->componentVersion,
                severity: $normalized->severity,
                cvssScore: $normalized->cvssScore,
                description: $normalized->description,
                dueAt: $this->sla->dueAt(
                    $normalized->severity,
                    $this->clock->now()
                ),
                detectedAt: $this->clock->now()
            );

            $this->vulnerabilities->save($vulnerability);
            $created[] = $vulnerability;
        }

        return new VulnerabilityImportResult(
            created: $created,
            updated: $updated
        );
    }
}
```

---

### 21. Sample Security Policy — Privileged MFA

```php
return [
    'policy_code' => 'SEC_PRIVILEGED_MFA_REQUIRED',
    'version' => '1.0',
    'category' => 'AUTHENTICATION',
    'severity' => 'CRITICAL',
    'scope' => [
        'role_type' => 'PRIVILEGED_ROLE',
    ],
    'require' => [
        'authentication_assurance_minimum' => 'AAL2',
    ],
    'owner' => 'security_governance',
    'status' => 'ACTIVE',
];
```

---

### 22. Sample Security Policy — Tenant Isolation

```php
return [
    'policy_code' => 'SEC_TENANT_ISOLATION_REQUIRED',
    'version' => '1.0',
    'category' => 'TENANT',
    'severity' => 'CRITICAL',
    'scope' => [
        'resource_scope' => 'TENANT_AWARE',
    ],
    'require' => [
        'tenant_context_required' => true,
        'cross_tenant_default_deny' => true,
        'audit_cross_tenant_attempt' => true,
    ],
    'owner' => 'platform_security',
    'status' => 'ACTIVE',
];
```

---

### 23. Sample Security Policy — Privileged Assignment Expiry

```php
return [
    'policy_code' => 'SEC_PRIVILEGED_ASSIGNMENT_EXPIRY',
    'version' => '1.0',
    'category' => 'PRIVILEGED_ACCESS',
    'severity' => 'BLOCKING',
    'scope' => [
        'role_type' => 'PRIVILEGED_ROLE',
    ],
    'require' => [
        'expires_at_required' => true,
        'reason_required' => true,
        'approval_required' => true,
    ],
    'owner' => 'security_governance',
    'status' => 'ACTIVE',
];
```

---

### 24. Sample Security Policy — Restricted Data Encryption

```php
return [
    'policy_code' => 'SEC_RESTRICTED_DATA_ENCRYPTION',
    'version' => '1.0',
    'category' => 'DATA_PROTECTION',
    'severity' => 'CRITICAL',
    'scope' => [
        'classification_in' => [
            'RESTRICTED',
            'SECURITY_RESTRICTED',
        ],
    ],
    'require' => [
        'encryption_at_rest' => true,
        'encryption_in_transit' => true,
    ],
    'owner' => 'security_architecture',
    'status' => 'ACTIVE',
];
```

---

### 25. Sample Security Policy — Secret Rotation

```php
return [
    'policy_code' => 'SEC_SECRET_ROTATION_REQUIRED',
    'version' => '1.0',
    'category' => 'SECRETS',
    'severity' => 'BLOCKING',
    'scope' => [
        'secret_status' => 'ACTIVE',
    ],
    'require' => [
        'owner_not_empty' => true,
        'rotation_due_at_not_overdue' => true,
    ],
    'owner' => 'security_operations',
    'status' => 'ACTIVE',
];
```

---

### 26. Sample Security Policy — Secure File Storage

```php
return [
    'policy_code' => 'SEC_RESTRICTED_FILE_NONPUBLIC',
    'version' => '1.0',
    'category' => 'FILE_SECURITY',
    'severity' => 'CRITICAL',
    'scope' => [
        'classification_in' => [
            'RESTRICTED',
            'SECURITY_RESTRICTED',
        ],
    ],
    'require' => [
        'public_path' => false,
        'authorization_required' => true,
        'checksum_required' => true,
    ],
    'owner' => 'security_architecture',
    'status' => 'ACTIVE',
];
```

---

### 27. Sample Security Policy — Vulnerability SLA

```php
return [
    'policy_code' => 'SEC_CRITICAL_VULNERABILITY_SLA',
    'version' => '1.0',
    'category' => 'VULNERABILITY',
    'severity' => 'CRITICAL',
    'scope' => [
        'vulnerability_severity' => 'CRITICAL',
    ],
    'require' => [
        'due_within_hours' => 72,
        'owner_required' => true,
        'verification_required' => true,
    ],
    'owner' => 'security_operations',
    'status' => 'ACTIVE',
];
```

---

### 28. Initial Migration Order

```text
1. security_identities
2. security_identity_memberships
3. security_authentication_methods
4. security_mfa_methods
5. security_password_reset_tokens
6. security_sessions
7. security_roles
8. security_permissions
9. security_role_permissions
10. security_role_assignments
11. security_access_reviews
12. security_access_review_items
13. security_privileged_access_requests
14. security_service_accounts
15. security_credentials
16. security_key_registry
17. security_key_versions
18. security_secret_registry
19. security_secret_versions
20. security_secure_files
21. security_legal_holds
22. security_evidence
23. security_chain_of_custody
24. security_vulnerabilities
25. security_vulnerability_events
26. security_events
27. security_incidents
28. security_scheduler_runs
```

---

### 29. Seed Permissions

```text
security.identity.read
security.identity.manage
security.identity.disable
security.role.read
security.role.manage
security.permission.read
security.permission.manage
security.assignment.read
security.assignment.manage
security.access_review.read
security.access_review.manage
security.privileged_access.read
security.privileged_access.request
security.privileged_access.approve
security.credential.read
security.credential.manage
security.key.read
security.key.manage
security.secret.read
security.secret.manage
security.secret.reveal
security.file.read
security.file.manage
security.legal_hold.read
security.legal_hold.manage
security.evidence.read
security.evidence.export
security.vulnerability.read
security.vulnerability.manage
security.incident.read
security.incident.manage
security.cross_tenant.access
```

---

### 30. Role Mapping

| Role | Capability |
|---|---|
| Security Administrator | Full security administration |
| IAM Administrator | Identity, role, permission, assignment |
| Security Analyst | Events, vulnerabilities, incidents |
| Secrets Operator | Secrets lifecycle without general app admin |
| Key Custodian | Key lifecycle with dual control |
| Access Reviewer | Access review only |
| Privileged Access Approver | JIT/privileged approval |
| Auditor | Read-only audit and evidence |
| Service Owner | Scoped service account and credential ownership |
| Helpdesk Security | Limited unlock/reset functions |

---

### 31. Configuration

```php
return [
    'enabled' => true,

    'authentication' => [
        'privileged_mfa_required' => true,
        'max_failed_attempts' => 5,
        'lockout_seconds' => 900,
        'password_min_length' => 12,
    ],

    'session' => [
        'idle_timeout_seconds' => 1800,
        'absolute_timeout_seconds' => 28800,
        'secure_cookie' => true,
        'same_site' => 'Lax',
    ],

    'authorization' => [
        'deny_by_default' => true,
        'cross_tenant_default_deny' => true,
        'permission_cache_ttl_seconds' => 60,
    ],

    'privileged_access' => [
        'maximum_duration_seconds' => 14400,
        'four_eyes_required_for_critical' => true,
    ],

    'files' => [
        'max_bytes' => 10 * 1024 * 1024,
        'storage_path' => dirname(__DIR__) . '/storage/secure-files',
        'quarantine_path' => dirname(__DIR__) . '/storage/quarantine',
    ],

    'vulnerability' => [
        'critical_sla_hours' => 72,
        'high_sla_days' => 14,
        'medium_sla_days' => 60,
        'low_sla_days' => 180,
    ],
];
```

---

### 32. Environment Variables

```text
SECURITY_ENABLED=true
SECURITY_DEBUG=false
SECURITY_PRIVILEGED_MFA_REQUIRED=true
SECURITY_MAX_FAILED_ATTEMPTS=5
SECURITY_LOCKOUT_SECONDS=900
SECURITY_SESSION_IDLE_SECONDS=1800
SECURITY_SESSION_ABSOLUTE_SECONDS=28800
SECURITY_DENY_BY_DEFAULT=true
SECURITY_CROSS_TENANT_DEFAULT_DENY=true
SECURITY_PERMISSION_CACHE_TTL=60
SECURITY_SECURE_FILE_PATH=D:/xampp/htdocs/platform/storage/secure-files
SECURITY_QUARANTINE_PATH=D:/xampp/htdocs/platform/storage/quarantine
SECURITY_VULN_CRITICAL_SLA_HOURS=72
```

---

### 33. Pre-Deployment Checklist

- [ ] Database backup tersedia.
- [ ] Migration direview.
- [ ] Permissions disetujui.
- [ ] Role mapping disetujui.
- [ ] MFA untuk privileged aktif.
- [ ] Secure cookie aktif.
- [ ] Production debug off.
- [ ] Trusted proxy dikonfigurasi.
- [ ] Tenant/scope guard diuji.
- [ ] Secret/key references tersedia.
- [ ] Secure file path di luar public root.
- [ ] Scheduler dikonfigurasi.
- [ ] Security events aktif.
- [ ] Vulnerability import tersedia.
- [ ] Incident contacts tersedia.
- [ ] Rollback plan tersedia.

---

### 34. Deployment Steps

```text
1. Deploy code.
2. Jalankan migration.
3. Seed permissions.
4. Seed system/security roles.
5. Migrate user identities.
6. Migrate role assignments.
7. Enable secure session config.
8. Enable authentication throttling.
9. Enable tenant/scope guards in SHADOW.
10. Enable authorization audit.
11. Register service accounts.
12. Register credentials.
13. Register keys and secrets metadata.
14. Configure secure file storage.
15. Enable security events.
16. Enable scheduler.
17. Enable vulnerability management.
18. Enable enforcement gradually.
```

---

### 35. Activation Strategy

```text
OFF
→ SHADOW
→ MONITOR
→ WARN
→ ENFORCE
```

#### SHADOW

- authorization decision dihitung;
- belum memblokir selected legacy path;
- tenant mismatch dicatat;
- false positive dianalisis.

#### MONITOR

- security dashboards aktif;
- alerts aktif;
- access review mulai berjalan.

#### WARN

- deprecated access menghasilkan warning;
- owner diberi remediation deadline;
- exception workflow aktif.

#### ENFORCE

- deny-by-default aktif;
- tenant/scope mismatch diblokir;
- privileged MFA wajib;
- expired credentials ditolak;
- blocking policies aktif.

---

### 36. Legacy Migration Strategy

Inventory:

- users;
- legacy roles;
- permissions;
- clinic bindings;
- service accounts;
- API keys;
- secrets;
- files;
- privileged users.

Process:

```text
Inventory
→ Normalize
→ Map
→ Assign Owner
→ Validate Scope
→ Import
→ Compare
→ Review
→ Enforce
```

---

### 37. Legacy User Migration

For each user:

- map immutable ID;
- normalize username/email;
- assign status;
- map tenant membership;
- map clinic scope;
- preserve password hash only if compatible and secure;
- otherwise force password reset;
- mark privileged roles;
- require MFA.

---

### 38. Legacy Role Migration

Do not copy broad roles blindly.

Steps:

1. inventory effective access;
2. map to granular permissions;
3. identify toxic combinations;
4. assign scope;
5. review owner;
6. set expiry for privileged assignment;
7. validate with UAT.

---

### 39. Legacy Credential Migration

Unknown/raw credentials must be:

- inventoried;
- assigned owner;
- rotated;
- stored securely;
- revoked after transition;
- audited.

---

### 40. Rollback Plan

1. Set selected controls to SHADOW.
2. Disable new blocking gates only.
3. Keep authentication and audit active.
4. Preserve security events and evidence.
5. Restore previous code.
6. Restore previous schema if safe.
7. Reconcile sessions and assignments.
8. Revalidate tenant/scope mapping.
9. Re-enable controls gradually.
10. Document rollback reason and residual risk.

---

### 41. Emergency Kill Switch

```text
SECURITY_ENABLED=true
SECURITY_POLICY_ENFORCEMENT=false
SECURITY_TENANT_GUARD_ENFORCEMENT=false
SECURITY_PRIVILEGED_MFA_REQUIRED=true
SECURITY_AUDIT_ENABLED=true
SECURITY_EVENTS_ENABLED=true
SECURITY_FILE_PROTECTION_ENABLED=true
```

Kill switch tidak boleh menonaktifkan:

- authentication;
- session validation;
- audit;
- secret protection;
- file protection;
- evidence preservation.

---

### 42. Attack Simulation — Credential Stuffing

Scenario:

- many login attempts;
- reused usernames;
- distributed IPs.

Expected:

- progressive throttle;
- account protection;
- security event;
- alert;
- no account enumeration;
- no mass lockout abuse.

---

### 43. Attack Simulation — Session Fixation

Scenario:

- attacker supplies known session ID before login.

Expected:

- session ID rotated after authentication;
- old session invalid;
- event recorded.

---

### 44. Attack Simulation — Session Replay

Scenario:

- stolen token reused after logout/password reset.

Expected:

- revoked token rejected;
- session version check fails;
- event recorded;
- alert if repeated.

---

### 45. Attack Simulation — Cross-Tenant Read

Scenario:

Tenant A requests patient resource from Tenant B.

Expected:

```text
AUTHZ_TENANT_DENIED
```

Additional:

- response does not reveal resource existence;
- event recorded;
- alert on repeated attempts.

---

### 46. Attack Simulation — Cross-Clinic Update

Scenario:

User has role in Clinic A but updates Clinic B resource.

Expected:

```text
AUTHZ_SCOPE_DENIED
```

---

### 47. Attack Simulation — Privilege Escalation

Scenario:

Standard user tries to assign privileged role.

Expected:

- permission denied;
- no assignment created;
- security event;
- alert if suspicious.

---

### 48. Attack Simulation — Toxic Combination

Scenario:

User receives both request and approval permissions.

Expected:

- SoD conflict detected;
- assignment blocked;
- review required.

---

### 49. Attack Simulation — Expired Privileged Access

Scenario:

JIT access used after expiry.

Expected:

- denied;
- session/context invalidated if needed;
- event recorded.

---

### 50. Attack Simulation — API Key Leakage

Scenario:

API key exposed and used from unusual context.

Expected:

- anomaly detected;
- credential revoked;
- owner notified;
- incident candidate created;
- replacement key issued.

---

### 51. Attack Simulation — Secret Reveal Abuse

Scenario:

User repeatedly reveals secret.

Expected:

- re-authentication required;
- rate limit;
- audit;
- anomaly alert;
- possible privilege suspension.

---

### 52. Attack Simulation — Key Compromise

Scenario:

Encryption key suspected compromised.

Expected:

- key revoked;
- incident created;
- new key generated;
- re-encryption plan;
- affected data scope identified;
- audit preserved.

---

### 53. Attack Simulation — Malicious Upload

Scenario:

Executable disguised as image.

Expected:

- MIME/signature mismatch or malware detection;
- quarantine;
- no public access;
- event/alert;
- incident if execution attempted.

---

### 54. Attack Simulation — Path Traversal

Scenario:

Filename includes `../../`.

Expected:

- normalized/rejected;
- random storage name;
- no filesystem escape.

---

### 55. Attack Simulation — SQL Injection

Scenario:

Malicious payload in filter/input.

Expected:

- schema validation;
- prepared statements;
- no SQL execution;
- safe error.

---

### 56. Attack Simulation — CSRF

Scenario:

External site submits privileged mutation.

Expected:

- CSRF validation fails;
- no state change;
- event recorded if repeated.

---

### 57. Attack Simulation — Security Header Downgrade

Scenario:

Production deployment misses CSP/HSTS.

Expected:

- readiness warning/failure according policy;
- deployment gate blocks critical misconfiguration.

---

### 58. Attack Simulation — Vulnerable Dependency

Scenario:

Critical CVE found in package.

Expected:

- vulnerability imported;
- severity and SLA assigned;
- owner notified;
- deployment gate may block;
- remediation verified before closure.

---

### 59. Attack Simulation — Audit Tampering

Scenario:

Attempt to update/delete security event or audit record.

Expected:

- database permission denied;
- integrity alert;
- incident candidate;
- evidence preserved.

---

### 60. Attack Simulation — Backup Theft

Scenario:

Backup file copied without key.

Expected:

- data remains encrypted;
- access event detected where possible;
- key separate;
- incident response initiated.

---

### 61. Attack Simulation — Legal Hold Bypass

Scenario:

Purge job targets data under legal hold.

Expected:

```text
LEGAL_HOLD_ACTIVE
```

No deletion occurs.

---

### 62. Security Test Plan

#### Authentication

- valid login;
- invalid login;
- locked account;
- disabled account;
- MFA required;
- MFA failure;
- reset token reuse;
- breached password policy.

#### Sessions

- rotation;
- idle expiry;
- absolute expiry;
- revoke;
- permission version change;
- concurrent session policy.

#### Authorization

- allow;
- deny;
- explicit deny;
- resource ownership;
- tenant mismatch;
- clinic mismatch;
- cross-tenant privileged path.

#### Privileged Access

- request;
- approval;
- self-approval denial;
- AAL2;
- activation;
- expiry;
- revocation;
- post-use review.

#### Credentials/Secrets/Keys

- issue;
- verify;
- rotate;
- revoke;
- expired use;
- reveal control;
- key version compatibility.

#### Files

- valid upload;
- MIME spoof;
- oversize;
- malware;
- traversal;
- unauthorized download;
- legal hold delete.

#### Vulnerability

- import;
- deduplicate;
- assign;
- SLA;
- risk acceptance;
- remediation;
- verification;
- closure.

---

### 63. Operational Runbook — Credential Stuffing

1. Confirm pattern.
2. Identify targeted accounts.
3. Apply throttle/risk rule.
4. Avoid mass lockout abuse.
5. Notify affected owners/users if needed.
6. Force reset for compromised accounts.
7. Revoke suspicious sessions.
8. Review MFA status.
9. Preserve evidence.
10. Close with findings.

---

### 64. Operational Runbook — Compromised Account

1. Disable/suspend identity.
2. Revoke all sessions.
3. Revoke credentials.
4. Preserve events and audit.
5. Identify accessed resources.
6. Assess tenant impact.
7. Reset password and MFA.
8. Review role assignments.
9. Re-enable only after validation.
10. Conduct post-incident review.

---

### 65. Operational Runbook — Cross-Tenant Attempt

1. Validate event.
2. Identify actor and target tenant.
3. Confirm whether denied or successful.
4. Revoke session if malicious.
5. Check similar events.
6. Review authorization path.
7. Create incident if exposure occurred.
8. Notify affected owners.
9. Fix policy/query issue.
10. Verify tenant isolation tests.

---

### 66. Operational Runbook — Privileged Access Abuse

1. Revoke elevated access.
2. Revoke active sessions.
3. Preserve privileged action timeline.
4. Identify changed resources.
5. Roll back unauthorized changes.
6. Review approval chain.
7. Disable identity if needed.
8. Review SoD rules.
9. Update policy.
10. Close with evidence.

---

### 67. Operational Runbook — Secret Compromise

1. Revoke secret.
2. Generate replacement.
3. Deploy replacement.
4. Verify service health.
5. Identify usages.
6. Search for leakage indicators.
7. Preserve evidence.
8. Notify owner.
9. Review source of compromise.
10. Prevent recurrence.

---

### 68. Operational Runbook — Key Compromise

1. Declare security incident.
2. Revoke affected key version.
3. Activate new key.
4. Determine affected data.
5. Start rewrap/re-encryption.
6. Verify decrypt paths.
7. Preserve evidence.
8. Review key access logs.
9. Validate backup recovery.
10. Close after full verification.

---

### 69. Operational Runbook — Malicious File

1. Quarantine file.
2. Block download.
3. Identify uploader and scope.
4. Scan related files.
5. Preserve checksum/evidence.
6. Revoke account if malicious.
7. Check execution attempts.
8. Patch parser if exploited.
9. Notify affected owner.
10. Close after verification.

---

### 70. Operational Runbook — Critical Vulnerability

1. Validate finding.
2. Identify exposure and exploitability.
3. Assign owner.
4. Apply containment.
5. Patch/upgrade.
6. Test.
7. Deploy.
8. Re-scan.
9. Store evidence.
10. Close or document time-bound risk acceptance.

---

### 71. Operational Runbook — Security Event Pipeline Failure

1. Check event writer.
2. Check storage.
3. Check queue/worker.
4. Enable fallback buffering.
5. Preserve local evidence.
6. Alert operations/security.
7. Recover pipeline.
8. Reconcile missing window.
9. Verify counts.
10. Document gap.

---

### 72. Operational Runbook — Security Platform Unavailable

1. Validate scope of outage.
2. Keep authentication/session controls fail-secure.
3. Block high-risk administration if uncertain.
4. Preserve local audit/events.
5. Activate emergency operating procedure.
6. Restore security services.
7. Reconcile assignments, credentials, events.
8. Verify audit integrity.
9. Re-enable normal operations.
10. Review incident.

---

### 73. Backup & Restore Validation

Validate:

- security identities;
- memberships;
- roles;
- permissions;
- assignments;
- sessions not restored as active unless intended;
- credentials;
- key references;
- secret references;
- files/evidence metadata;
- vulnerabilities;
- events;
- incidents;
- legal holds.

---

### 74. Restore Rules

After restore:

- revoke stale sessions;
- validate permission version;
- verify key availability;
- verify secret references;
- re-run credential expiry;
- re-run privileged access expiry;
- verify legal holds;
- verify event/audit integrity.

---

### 75. Performance Test Plan

Scenarios:

```text
100.000 identities
1.000 roles
10.000 permissions
1.000.000 assignments
100.000 active sessions
10.000 authentication attempts/minute
1.000 authorization decisions/second
100.000 credentials
10.000 secure files
1.000.000 security events/day
100.000 vulnerabilities historical
```

---

### 76. Performance Acceptance

| Operation | Target |
|---|---:|
| Session validation p95 | < 25 ms |
| Authorization decision p95 | < 30 ms |
| Tenant context p95 | < 20 ms |
| Credential verification p95 | < 100 ms |
| Role resolution p95 | < 50 ms |
| Security event write p95 | < 100 ms |
| Session revoke p95 | < 100 ms |
| Secure file metadata p95 | < 100 ms |
| Vulnerability list p95 | < 500 ms |
| Security dashboard p95 | < 1.5 s |

---

### 77. Final UAT — Identity & Authentication

- [ ] Human identity lifecycle bekerja.
- [ ] Service identity lifecycle bekerja.
- [ ] Disabled account tidak dapat login.
- [ ] Password hashing aman.
- [ ] Login throttling bekerja.
- [ ] Account enumeration dilindungi.
- [ ] MFA privileged wajib.
- [ ] MFA reset controlled.
- [ ] Re-authentication bekerja.
- [ ] Authentication events tercatat.

---

### 78. Final UAT — Sessions

- [ ] Secure cookie aktif.
- [ ] Session ID rotation bekerja.
- [ ] Idle timeout bekerja.
- [ ] Absolute timeout bekerja.
- [ ] Logout invalidation bekerja.
- [ ] Password reset mencabut session.
- [ ] Permission version invalidation bekerja.
- [ ] Concurrent session policy bekerja.
- [ ] Session listing/revocation tersedia.
- [ ] Session anomalies terdeteksi.

---

### 79. Final UAT — Authorization & Tenant Isolation

- [ ] Deny by default aktif.
- [ ] Role/permission registry tersedia.
- [ ] Scoped assignment bekerja.
- [ ] Resource-level policy bekerja.
- [ ] Explicit deny precedence bekerja.
- [ ] Cross-tenant read ditolak.
- [ ] Cross-tenant update ditolak.
- [ ] Cross-clinic update ditolak.
- [ ] Cache isolation bekerja.
- [ ] File/queue isolation bekerja.
- [ ] Cross-tenant privileged path diaudit.
- [ ] Menu bukan enforcement utama.

---

### 80. Final UAT — Privileged Access

- [ ] Privileged MFA wajib.
- [ ] Time-bound assignment bekerja.
- [ ] JIT request/approval bekerja.
- [ ] Self-approval ditolak.
- [ ] Four-eyes bekerja untuk critical.
- [ ] Re-authentication required.
- [ ] Expiry otomatis.
- [ ] Revocation bekerja.
- [ ] Break-glass controlled.
- [ ] Post-use review tersedia.

---

### 81. Final UAT — Credentials, Keys & Secrets

- [ ] Credential issue bekerja.
- [ ] Raw credential ditampilkan sekali.
- [ ] Credential hash tersimpan.
- [ ] Expired/revoked credential ditolak.
- [ ] Rotation bekerja.
- [ ] Key registry/version tersedia.
- [ ] Key rotation bekerja.
- [ ] Secret registry/version tersedia.
- [ ] Secret reveal controlled.
- [ ] Secret rotation/revocation bekerja.
- [ ] No secret leakage ke log/error.
- [ ] Access diaudit.

---

### 82. Final UAT — Files & Evidence

- [ ] Upload validation bekerja.
- [ ] MIME spoof ditolak.
- [ ] Oversize ditolak.
- [ ] Malware dikarantina.
- [ ] Random storage name digunakan.
- [ ] Restricted files di luar public root.
- [ ] Authorization download bekerja.
- [ ] Cross-tenant file access ditolak.
- [ ] Checksum tersedia.
- [ ] Legal hold memblokir delete.
- [ ] Evidence export terenkripsi.
- [ ] Chain of custody tersedia.

---

### 83. Final UAT — Vulnerabilities & Incidents

- [ ] Findings dapat diimport.
- [ ] Deduplication bekerja.
- [ ] SLA dihitung.
- [ ] Owner assignment bekerja.
- [ ] Risk acceptance time-bound.
- [ ] Overdue alerts bekerja.
- [ ] Remediation verification wajib.
- [ ] Security event menjadi incident candidate.
- [ ] Evidence terhubung ke incident.
- [ ] Containment actions tersedia.
- [ ] Post-incident review tersedia.
- [ ] Closure membutuhkan evidence.

---

### 84. Final UAT — Configuration & Hardening

- [ ] Production debug off.
- [ ] Secure cookie enforced.
- [ ] Trusted proxies configured.
- [ ] Directory listing disabled.
- [ ] Sensitive files blocked.
- [ ] Storage outside public root.
- [ ] Default secrets rejected.
- [ ] Root DB credential rejected.
- [ ] PHP errors hidden.
- [ ] Upload limits enforced.
- [ ] HTTPS/HSTS direction tersedia.
- [ ] Readiness fails on critical misconfiguration.

---

### 85. Final UAT — Scheduler & Recovery

- [ ] Session cleanup berjalan.
- [ ] Credential expiry check berjalan.
- [ ] Privileged access expiry berjalan.
- [ ] Access review due check berjalan.
- [ ] Key rotation check berjalan.
- [ ] Secret rotation check berjalan.
- [ ] Vulnerability SLA check berjalan.
- [ ] Evidence integrity check berjalan.
- [ ] Backup verification berjalan.
- [ ] Event correlation berjalan.
- [ ] Incident reconciliation berjalan.
- [ ] Job lock/idempotency bekerja.
- [ ] Backup/restore diuji.
- [ ] Rollback diuji.
- [ ] Emergency procedure diuji.

---

### 86. Production Readiness Checklist

- [ ] Security owners ditetapkan.
- [ ] Threat model tersedia.
- [ ] Asset/data inventory tersedia.
- [ ] Identity registry aktif.
- [ ] MFA privileged aktif.
- [ ] Sessions hardened.
- [ ] Authorization engine aktif.
- [ ] Tenant/scope guards aktif.
- [ ] Role/permission review selesai.
- [ ] Privileged access workflow aktif.
- [ ] Credentials/keys/secrets terinventarisasi.
- [ ] Secure file storage aktif.
- [ ] Security event pipeline aktif.
- [ ] Vulnerability management aktif.
- [ ] Incident integration aktif.
- [ ] Scheduler aktif.
- [ ] Alerts dan dashboards aktif.
- [ ] Backup/restore lulus.
- [ ] Security tests lulus.
- [ ] Operations sign-off tersedia.

---

### 87. Ownership Matrix

| Area | Owner |
|---|---|
| Security Framework | Security Architecture |
| IAM | Platform IAM |
| Authentication/MFA | Platform Security |
| Authorization/RBAC | Platform Kernel |
| Tenant Isolation | Platform Architecture |
| Privileged Access | Security Governance |
| Credentials/Secrets | Security Operations |
| Key Management | Key Custodian/Security |
| Secure Files | Platform Storage |
| Vulnerability Management | Security Operations |
| Security Events | SOC/Security Operations |
| Incident Response | Security + Operations |
| Compliance Evidence | Compliance |
| Backup Security | Infrastructure Operations |

---

### 88. Definition of Done — SSOT-SEC-01

#### Foundation

- [ ] security objectives;
- [ ] principles;
- [ ] architecture;
- [ ] control domains;
- [ ] assets;
- [ ] threats;
- [ ] trust boundaries;
- [ ] baseline controls;
- [ ] ownership/RACI;
- [ ] risk/governance.

#### Identity & Access

- [ ] identity model;
- [ ] authentication;
- [ ] MFA;
- [ ] sessions;
- [ ] RBAC;
- [ ] resource policies;
- [ ] tenant/scope isolation;
- [ ] privileged access;
- [ ] account lifecycle;
- [ ] access review;
- [ ] service accounts;
- [ ] API credentials.

#### Data Protection

- [ ] classification;
- [ ] minimization;
- [ ] encryption;
- [ ] key management;
- [ ] secrets;
- [ ] database security;
- [ ] file security;
- [ ] backup security;
- [ ] retention;
- [ ] legal hold;
- [ ] privacy;
- [ ] evidence integrity.

#### Infrastructure & Operations

- [ ] middleware;
- [ ] controllers;
- [ ] APIs;
- [ ] service contracts;
- [ ] database schema;
- [ ] secure configuration;
- [ ] Apache/PHP hardening;
- [ ] security event pipeline;
- [ ] vulnerability management;
- [ ] scheduler;
- [ ] incident integration;
- [ ] metrics/alerts;
- [ ] sequence diagrams.

#### Reference Implementation

- [ ] bootstrap wiring;
- [ ] sample policies;
- [ ] migration;
- [ ] deployment;
- [ ] rollback;
- [ ] attack simulations;
- [ ] test plan;
- [ ] runbooks;
- [ ] final UAT;
- [ ] production readiness.

---

### 89. Implementation Definition of Done

Implementation selesai bila:

- [ ] core security services dibuat;
- [ ] migrations berhasil;
- [ ] permissions dan roles tersedia;
- [ ] identity/authentication aktif;
- [ ] MFA aktif untuk privileged;
- [ ] session controls aktif;
- [ ] authorization dan tenant guards aktif;
- [ ] privileged access aktif;
- [ ] credentials/keys/secrets aktif;
- [ ] secure files aktif;
- [ ] events/detection aktif;
- [ ] vulnerability management aktif;
- [ ] incident bridge aktif;
- [ ] scheduler aktif;
- [ ] unit test lulus;
- [ ] integration test lulus;
- [ ] security test lulus;
- [ ] UAT lulus;
- [ ] performance target tercapai;
- [ ] backup/restore lulus;
- [ ] deployment/rollback diuji;
- [ ] operations sign-off tersedia.

---

### 90. Roadmap

#### Phase 1 — Baseline Security

- identity registry;
- password security;
- basic MFA;
- secure sessions;
- RBAC;
- tenant guard;
- audit/security events;
- secure configuration.

#### Phase 2 — Managed Security

- resource policies;
- access review;
- privileged access;
- credential rotation;
- key/secret registry;
- secure file pipeline;
- vulnerability management.

#### Phase 3 — Enterprise Security

- JIT privileged access;
- advanced detection;
- legal hold;
- evidence chain;
- automated vulnerability gates;
- cross-tenant oversight;
- security dashboards.

#### Phase 4 — Adaptive Security

- risk-based authentication;
- policy-as-code;
- continuous authorization;
- automated containment with guardrails;
- behavioral analytics;
- continuous compliance evidence;
- predictive vulnerability prioritization.

---

### 91. Future Evolution

- WebAuthn/FIDO2;
- external identity provider integration;
- workload identity;
- hardware-backed key protection;
- centralized secrets manager;
- policy engine adapter;
- continuous access evaluation;
- zero-trust service communication;
- SBOM automation;
- software supply chain signing;
- behavioral detection;
- automated tenant isolation tests;
- continuous security control validation;
- AI-assisted incident triage;
- adaptive access policy.

---

### 92. Merge Guidance

Gabungkan:

```text
SSOT-SEC-01-Part-1.md
SSOT-SEC-01-Part-2.md
SSOT-SEC-01-Part-3.md
SSOT-SEC-01-Part-4.md
SSOT-SEC-01-Part-5.md
```

menjadi:

```text
SSOT-SEC-01.md
```

Urutan:

```text
Part 1 — Security Foundation
Part 2 — Identity & Access Security
Part 3 — Data Protection & Cryptography
Part 4 — Security Infrastructure & Operations
Part 5 — Reference Implementation & Operational Readiness
```

---

### 93. Merge Quality Checklist

- [ ] heading tidak duplikat;
- [ ] terminology konsisten;
- [ ] identity states konsisten;
- [ ] session states konsisten;
- [ ] role/permission names konsisten;
- [ ] tenant/scope terminology konsisten;
- [ ] policy codes konsisten;
- [ ] table names konsisten;
- [ ] endpoint konsisten;
- [ ] error codes konsisten;
- [ ] key/secret terminology konsisten;
- [ ] security event codes konsisten;
- [ ] duplicate sections dihapus;
- [ ] metadata final diperbarui;
- [ ] daftar isi dibuat;
- [ ] status final diset Draft for Review/Approved.

---

### 94. Final Metadata

```yaml
document_code: SSOT-SEC-01
title: Security Implementation Framework
version: 1.0
status: Draft for Review
domain: Platform Kernel
category: Security Architecture & Implementation
owners:
  - Security Architecture
  - Platform Architecture
  - Security Operations
  - Compliance
reviewers:
  - Backend Engineering
  - Frontend Engineering
  - DevOps
  - Database Administration
  - QA
  - Service Owners
  - Infrastructure Operations
```

---

### 95. Approval Gate

Dokumen dapat menjadi Approved setelah:

- security architecture review;
- threat model review;
- IAM review;
- authentication/MFA review;
- authorization/RBAC review;
- tenant isolation review;
- privileged access review;
- cryptography/key management review;
- secrets management review;
- file/database/backup security review;
- vulnerability management review;
- incident response review;
- database schema review;
- Apache/PHP hardening review;
- QA/UAT review;
- performance review;
- backup/restore review;
- deployment/rollback review;
- operations sign-off.

---

### 96. Closing Statement

Security implementation harus memastikan setiap identity, session, permission, tenant, scope, credential, key, secret, file, event, dan incident:

- memiliki owner;
- memiliki policy;
- memiliki lifecycle;
- memiliki audit;
- memiliki evidence;
- memiliki recovery path;
- dapat diuji;
- dapat direvoke;
- dapat ditingkatkan.

Framework tidak boleh:

- mempercayai client-supplied tenant/role;
- menggunakan UI sebagai enforcement utama;
- menyimpan secret di repository atau log;
- membiarkan privileged access tanpa expiry;
- membiarkan cross-tenant access tanpa explicit permission dan audit;
- menutup vulnerability tanpa verification;
- menyimpan restricted file di public path;
- menonaktifkan evidence preservation saat incident;
- menganggap keamanan selesai hanya karena login tersedia.

Security harus menjadi capability kernel yang konsisten, terukur, dapat diaudit, dapat dipulihkan, dan digunakan oleh seluruh module bisnis.

---

## Lampiran A — Sumber Penggabungan

Dokumen final ini digabung dan dinormalisasi dari:

- `SSOT-SEC-01-Part-1.md`
- `SSOT-SEC-01-Part-2.md`
- `SSOT-SEC-01-Part-3.md`
- `SSOT-SEC-01-Part-4.md`
- `SSOT-SEC-01-Part-5.md`

## Lampiran B — Approval Gate

Status dokumen dapat diubah menjadi **Approved** setelah:

- security architecture review selesai;
- threat model review selesai;
- IAM review selesai;
- authentication dan MFA review selesai;
- authorization dan RBAC review selesai;
- tenant isolation review selesai;
- privileged access review selesai;
- cryptography dan key management review selesai;
- secrets management review selesai;
- database, file, dan backup security review selesai;
- retention, legal hold, privacy, dan evidence integrity review selesai;
- vulnerability management review selesai;
- security event pipeline dan incident response review selesai;
- database schema review selesai;
- Apache dan PHP hardening review selesai;
- QA/UAT review selesai;
- performance review selesai;
- backup dan restore review selesai;
- deployment dan rollback review selesai;
- operations sign-off tersedia.
