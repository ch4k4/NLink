# SSOT-RBAC-07 — Segregation of Duties & Conflict Policy

---

## Status Dokumen

| Item | Nilai |
|---|---|
| Kode | SSOT-RBAC-07 |
| Judul | Segregation of Duties & Conflict Policy |
| Versi | 1.0 |
| Status | Draft Architecture |
| Domain | Platform Kernel |
| Kategori | Authorization Governance, Risk & Compliance |
| Cakupan | Static SoD, Dynamic SoD, Transactional SoD, Conflict Matrix, Exception, Compensating Control, Monitoring, Review |
| Bergantung pada | SSOT-GOV-01, SSOT-GOV-04, SSOT-GOV-05, SSOT-IAM-01, SSOT-IAM-04, SSOT-RBAC-01, SSOT-RBAC-02, SSOT-RBAC-03, SSOT-RBAC-04, SSOT-RBAC-05, SSOT-RBAC-06, SSOT-AUDIT-01, SSOT-AUDIT-02, SSOT-OBS-01 |
| Target Stack | PHP 8.1+, Composer, PSR-4, PDO, MySQL 8/MariaDB, Modular Monolith |
| Target Evolusi | Policy Engine-ready, Continuous Access Evaluation, Compliance Evidence Automation |

---

# 1. Executive Summary

SSOT-RBAC-07 menetapkan standar resmi Segregation of Duties dan conflict policy pada Platform Kernel.

Dokumen ini mengatur:

- static segregation of duties;
- dynamic segregation of duties;
- transactional segregation of duties;
- toxic role combinations;
- toxic permission combinations;
- conflict matrix;
- process-stage conflicts;
- actor-versus-approver separation;
- creator-versus-verifier separation;
- requester-versus-approver separation;
- assignment-time preventive controls;
- runtime preventive controls;
- detective controls;
- exception;
- compensating controls;
- temporary conflict waivers;
- emergency access;
- evidence;
- periodic review;
- reconciliation;
- audit;
- metrics;
- database direction;
- API direction;
- SDK contracts;
- UAT;
- Definition of Done;
- implementation roadmap.

Tujuan akhirnya adalah memastikan satu actor tidak memiliki kombinasi access atau menjalankan kombinasi tindakan yang memungkinkan:

- self-approval;
- unauthorized privilege escalation;
- fraud;
- concealment;
- bypass kontrol;
- manipulation of evidence;
- cross-tenant abuse;
- uncontrolled financial or clinical decisions;
- conflicting operational duties.

---

# 2. Objectives

Framework harus:

- mencegah toxic access combinations;
- menjaga maker-checker;
- menjaga least privilege;
- mendukung preventive dan detective control;
- mendukung static, dynamic, dan transactional conflict;
- mengendalikan exception;
- menyediakan compensating control;
- menjaga tenant isolation;
- menyediakan continuous monitoring;
- menghasilkan audit evidence.

---

# 3. Core Principles

```text
No One Person Controls an Entire Critical Process
Maker and Checker Must Be Independent
Requester Must Not Approve Own Request
Creator Must Not Verify Own Critical Record
Privilege Grantor Must Not Self-Grant
Exceptions Must Be Time-Bound
Compensating Controls Must Be Explicit
High-Risk Conflicts Fail Closed
Every Conflict Decision Must Be Auditable
SoD Policy Must Be Testable
```

---

# 4. Scope

Framework berlaku untuk:

```text
Human Users
Privileged Administrators
Tenant Administrators
Clinic Administrators
Finance Users
Clinical Users
Auditors
Security Operators
Service Accounts where applicable
Delegated Administrators
Federated Users
```

---

# 5. Non-Scope

Dokumen ini tidak menggantikan:

- fraud detection;
- business approval workflow;
- authentication assurance;
- privileged access management;
- transaction limits;
- clinical governance.

SoD bekerja bersama kontrol tersebut.

---

# 6. Segregation of Duties Definition

Segregation of Duties adalah pemisahan responsibility agar satu actor tidak dapat menyelesaikan seluruh rangkaian critical action tanpa independent control.

---

# 7. SoD Types

```text
STATIC
DYNAMIC
TRANSACTIONAL
CONTEXTUAL
TEMPORAL
CROSS_SCOPE
```

---

# 8. Static SoD

Static SoD mencegah assignment role atau permission yang toxic pada subject yang sama.

Contoh:

```text
Role: Role Administrator
conflicts with
Role: Access Reviewer
```

---

# 9. Dynamic SoD

Dynamic SoD memungkinkan subject memiliki beberapa role, tetapi membatasi activation atau penggunaan bersamaan.

---

# 10. Transactional SoD

Transactional SoD mencegah actor melakukan dua atau lebih action yang konflik pada transaksi/resource yang sama.

Contoh:

```text
Create Invoice
→ Approve Same Invoice
```

---

# 11. Contextual SoD

Conflict berlaku hanya pada kondisi tertentu:

- tenant;
- clinic;
- department;
- amount;
- data classification;
- workflow;
- patient/case;
- project.

---

# 12. Temporal SoD

Conflict berlaku dalam periode waktu tertentu.

Contoh:

```text
Actor who configured payment account
cannot approve payment for 24 hours.
```

---

# 13. Cross-Scope SoD

Conflict dapat terjadi antar-scope yang saling terkait.

Contoh:

- tenant administrator;
- tenant access auditor;
- clinic finance approver;
- organization finance reconciler.

---

# 14. Conflict Subjects

Conflict dapat didefinisikan atas:

```text
ROLE_VS_ROLE
PERMISSION_VS_PERMISSION
ROLE_VS_PERMISSION
ACTION_VS_ACTION
STAGE_VS_STAGE
SUBJECT_VS_RESOURCE_RELATIONSHIP
```

---

# 15. Conflict Severity

```text
LOW
MODERATE
HIGH
CRITICAL
```

---

# 16. Conflict Enforcement Mode

```text
WARN
REQUIRE_REVIEW
BLOCK
BLOCK_WITH_EXCEPTION
DETECT_ONLY
```

---

# 17. Default Enforcement

High dan critical conflicts harus menggunakan:

```text
BLOCK
```

atau:

```text
BLOCK_WITH_EXCEPTION
```

---

# 18. Conflict Rule Minimum Fields

```text
rule_code
name
description
conflict_type
left_operand
right_operand
scope_model
severity
enforcement_mode
owner
status
```

---

# 19. Conflict Rule Status

```text
DRAFT
IN_REVIEW
APPROVED
ACTIVE
SUSPENDED
DEPRECATED
RETIRED
```

---

# 20. Conflict Rule Lifecycle

```text
Propose
→ Analyze
→ Test
→ Approve
→ Activate
→ Monitor
→ Review
→ Update/Retire
```

---

# 21. Conflict Matrix

Conflict matrix memetakan toxic combinations secara authoritative.

---

# 22. Role Conflict Matrix Example

| Left Role | Right Role | Scope | Severity | Mode |
|---|---|---|---|---|
| `rbac_admin` | `access_reviewer` | Tenant | Critical | Block |
| `billing_creator` | `billing_approver` | Clinic | High | Block |
| `security_admin` | `audit_admin` | Global | Critical | Block |
| `vendor_manager` | `payment_approver` | Tenant | High | Review |

---

# 23. Permission Conflict Matrix Example

| Left Permission | Right Permission | Context | Severity |
|---|---|---|---|
| `rbac.assignment.create` | `rbac.assignment.approve` | Same request | Critical |
| `billing.invoice.create` | `billing.invoice.approve` | Same invoice | High |
| `audit.event.delete` | `audit.event.review` | Same tenant | Critical |
| `security.secret.rotate` | `security.secret.audit` | Same secret | High |

---

# 24. Process Conflict Matrix

Examples:

```text
REQUEST → APPROVE
CREATE → VERIFY
SUBMIT → AUTHORIZE
CONFIGURE → CERTIFY
PAY → RECONCILE
ASSIGN → REVIEW
IMPORT → APPROVE
```

---

# 25. Actor Relations

Transactional conflict may inspect:

```text
created_by
requested_by
submitted_by
approved_by
verified_by
assigned_by
reviewed_by
```

---

# 26. Same-Actor Rule

For critical workflow steps:

```text
created_by != approved_by
requested_by != approved_by
assigned_by != reviewed_by
configured_by != certified_by
```

---

# 27. Role-Level Static SoD

Role-level conflict is preferred for broad toxic duties.

---

# 28. Permission-Level Static SoD

Permission-level conflict is used when roles vary but capability conflict remains.

---

# 29. Hybrid Conflict

Role and permission rules may coexist.

---

# 30. Assignment-Time Evaluation

Before assignment activation:

```text
Load Current Active Assignments
→ Resolve Effective Permissions
→ Evaluate Static Conflict Rules
→ Evaluate Scope Overlap
→ Evaluate Exceptions
→ Block/Allow
```

---

# 31. Scope Overlap

Conflict applies only when relevant scopes overlap.

---

# 32. Scope Overlap Types

```text
EXACT
ANCESTOR_DESCENDANT
SAME_TENANT
SAME_ORGANIZATION
SAME_CLINIC
RESOURCE_MATCH
GLOBAL
```

---

# 33. Cross-Tenant Rule

Cross-tenant assignments must not be treated as non-conflicting solely because tenant IDs differ when platform-wide privilege exists.

---

# 34. Runtime Evaluation

Dynamic dan transactional SoD harus dievaluasi sebelum side effect.

---

# 35. Runtime Inputs

```text
subject
active roles
effective permissions
resource
workflow state
prior actors
scope
time
exception
```

---

# 36. Conflict Decision

```text
NO_CONFLICT
WARNING
REVIEW_REQUIRED
BLOCKED
EXCEPTION_APPLIED
INDETERMINATE
```

---

# 37. Fail-Closed Rule

Indeterminate pada high/critical conflict harus dianggap blocked.

---

# 38. Conflict Decision Contract

```php
final readonly class ConflictDecision
{
    public function __construct(
        public string $result,
        public string $ruleCode,
        public string $severity,
        public string $reasonCode,
        public array $evidence,
        public ?string $exceptionId = null,
    ) {
    }
}
```

---

# 39. Conflict Evaluation Contract

```php
interface SegregationOfDutiesServiceInterface
{
    public function evaluate(
        ConflictEvaluationRequest $request
    ): ConflictDecision;
}
```

---

# 40. Assignment Conflict Request

```php
final readonly class AssignmentConflictRequest
{
    public function __construct(
        public string $subjectId,
        public string $roleId,
        public ScopeContext $scope,
        public ?string $assignmentId = null,
    ) {
    }
}
```

---

# 41. Transaction Conflict Request

```php
final readonly class TransactionConflictRequest
{
    public function __construct(
        public string $subjectId,
        public string $action,
        public string $resourceType,
        public string $resourceId,
        public ScopeContext $scope,
        public array $priorActors,
    ) {
    }
}
```

---

# 42. Preventive Controls

Preventive controls:

- block assignment;
- block role activation;
- block transaction;
- require different approver;
- require step-up;
- require second approver;
- require exception approval.

---

# 43. Detective Controls

Detective controls:

- daily conflict scan;
- access review;
- transaction analysis;
- audit correlation;
- dormant conflict detection;
- scope overlap review;
- emergency access review.

---

# 44. Corrective Controls

Corrective controls:

- revoke role;
- suspend assignment;
- cancel approval;
- rollback transaction;
- invalidate session;
- create incident;
- remediate conflict mapping.

---

# 45. Compensating Controls

Compensating controls may include:

- independent post-review;
- dual approval;
- transaction limit;
- enhanced logging;
- short-lived access;
- session recording;
- daily reconciliation;
- mandatory notification;
- restricted scope.

---

# 46. Compensating Control Requirements

Must be:

- explicit;
- owned;
- effective;
- testable;
- time-bound where applicable;
- audited;
- reviewed.

---

# 47. Exception

Exception permits temporary conflict under approved risk acceptance.

---

# 48. Exception Minimum Fields

```text
exception_id
rule_code
subject_id
scope
reason
risk
compensating_controls
valid_from
valid_to
owner
approver
status
```

---

# 49. Exception Status

```text
REQUESTED
IN_REVIEW
APPROVED
ACTIVE
EXPIRED
REVOKED
REJECTED
CLOSED
```

---

# 50. Exception Rules

Exception must not be:

- permanent;
- ownerless;
- silently renewed;
- broader than requested;
- used to bypass cross-tenant controls;
- used to self-approve critical access.

---

# 51. Exception Approval

| Severity | Approval |
|---|---|
| Low | Domain Owner |
| Moderate | Domain + Risk Owner |
| High | Security/Compliance + Domain |
| Critical | Governance + Security + Executive/Designated Authority |

---

# 52. Exception Duration

Critical exception should use shortest viable duration.

---

# 53. Automatic Expiry

Expired exception must stop affecting decisions automatically.

---

# 54. Renewal

Renewal requires fresh assessment.

---

# 55. Emergency Exception

Emergency exception requires:

- incident reference;
- strong MFA;
- short duration;
- restricted scope;
- full audit;
- retrospective review.

---

# 56. Exception Scope

Exception may be scoped by:

```text
subject
role
permission
tenant
organization
clinic
resource
workflow
time window
```

---

# 57. Exception Matching

All matching dimensions must be validated.

---

# 58. Exception Precedence

Exception may override only the specific rule and context it references.

---

# 59. Non-Overridable Rules

Examples:

- cross-tenant isolation;
- self-grant platform super-admin;
- audit evidence destruction;
- disabled/terminated identity;
- prohibited legal/compliance controls.

---

# 60. Maker-Checker

Maker-checker applies to:

- role assignment;
- access approval;
- payment;
- billing adjustment;
- master data critical changes;
- security configuration;
- key rotation;
- deployment approval;
- audit finding closure.

---

# 61. Four-Eyes Principle

Critical action may require two independent actors.

---

# 62. Dual Approval

Dual approval should record ordered or unordered approvals.

---

# 63. Independence Criteria

Approvers should not be:

- same user;
- same delegated identity;
- same service account;
- subordinate where policy forbids;
- actor who initiated transaction;
- actor with conflict exception unless approved.

---

# 64. Self-Approval

Self-approval is blocked by default.

---

# 65. Self-Review

Actor should not certify their own privileged assignment.

---

# 66. Self-Revocation Exception

Self-revocation may be allowed because it reduces privilege.

---

# 67. Role Assignment SoD

Before role assignment:

- evaluate current roles;
- evaluate effective permissions;
- evaluate scope overlap;
- evaluate active exceptions;
- evaluate delegated authority.

---

# 68. Role Activation SoD

Dynamic role activation may be restricted per session.

---

# 69. Active Role Set

Session may activate subset of assigned roles.

---

# 70. Mutually Exclusive Roles

Mutually exclusive roles cannot be active simultaneously.

---

# 71. Session Role Activation

Activation must be server-side and audited for privileged roles.

---

# 72. Session Conflict

If conflict arises after policy update, active session must refresh or terminate.

---

# 73. Permission Conflict

Permission conflict evaluation uses effective permission set, not only direct assignments.

---

# 74. Inherited Permission

Inherited permissions participate in SoD.

---

# 75. Denied Permission

Denied/inactive permissions should not create false active conflict unless policy requires historical review.

---

# 76. Group-Derived Assignment

Group-derived roles participate in conflict evaluation.

---

# 77. Federated Group Mapping

External group mappings cannot bypass SoD.

---

# 78. Service Account SoD

Service account SoD may separate:

- create;
- approve;
- publish;
- reconcile;
- rotate;
- verify.

---

# 79. Machine Identity

One service account should not hold end-to-end critical process capabilities without explicit architecture review.

---

# 80. Human-on-Behalf-of

Actor and subject must both be recorded.

---

# 81. Delegated Administration

Delegated administrator cannot approve assignments they requested.

---

# 82. Delegation Conflict

Delegator/delegate relationships may form conflict conditions.

---

# 83. Nested Delegation

Disabled by default.

---

# 84. Scope-Aware Conflict

Conflict engine must evaluate:

- exact scope;
- parent scope;
- child scope;
- sibling scope where process overlaps;
- global role effect.

---

# 85. Example Scope Conflict

Tenant finance admin and clinic payment approver may conflict because tenant role covers clinic.

---

# 86. Resource-Level Conflict

Actor who created a patient merge request cannot approve same merge request.

---

# 87. Case-Level Conflict

Nurse who documents visit may not independently close audit exception for same visit if policy requires separation.

---

# 88. Workflow Integration

Workflow engine should expose:

```text
current_stage
prior_actor_ids
required_separation_rules
approval_count
```

---

# 89. Workflow Enforcement

Before transition:

```text
Authorization Decision
→ SoD Decision
→ Workflow Preconditions
→ Side Effect
```

---

# 90. Transaction State

Conflict decision must use current authoritative transaction state.

---

# 91. Race Condition

Concurrent approvals require transactional locking or unique constraints.

---

# 92. Idempotency

Duplicate approval request must not bypass SoD.

---

# 93. Bulk Operations

Bulk operations must evaluate conflict per resource or approved homogeneous set.

---

# 94. Import Operations

Importer and approver should be separated for high-risk bulk import.

---

# 95. Data Correction

Data correction and correction approval may require separate actors.

---

# 96. Financial SoD Examples

```text
Vendor Create vs Payment Approve
Invoice Create vs Invoice Approve
Payment Execute vs Payment Reconcile
Refund Request vs Refund Approve
Pricing Configure vs Discount Approve
```

---

# 97. Clinical SoD Examples

```text
Clinical Entry vs Independent Verification
Medication Order vs Dispense Confirmation
Assessment Entry vs Audit Closure
Patient Merge Request vs Merge Approval
```

Applicability depends on business model and regulation.

---

# 98. IAM/RBAC SoD Examples

```text
User Create vs User Activate
Role Create vs Role Approve
Assignment Request vs Assignment Approve
Permission Register vs Permission Certify
Privileged Access Grant vs Access Review
```

---

# 99. Security SoD Examples

```text
Secret Rotate vs Rotation Audit
Key Admin vs Key Usage Approver
Incident Investigator vs Evidence Purger
Security Policy Author vs Final Approver
```

---

# 100. Deployment SoD Examples

```text
Code Author vs Production Approver
Release Builder vs Release Verifier
Infrastructure Change vs Compliance Approval
Emergency Change Executor vs Retrospective Reviewer
```

---

# 101. Audit SoD Examples

```text
Audit Event Administrator vs Audit Reviewer
Finding Owner vs Finding Verifier
Evidence Producer vs Evidence Certifier
```

---

# 102. Rule Ownership

Every conflict rule requires:

- business owner;
- control owner;
- risk owner;
- technical owner.

---

# 103. Rule Description

Must explain:

- toxic combination;
- risk;
- scope;
- enforcement;
- exception policy;
- evidence.

---

# 104. Rule Versioning

Conflict rules must be immutable by version.

---

# 105. Rule Change Types

```text
METADATA
SCOPE_EXPANSION
SCOPE_RESTRICTION
SEVERITY_CHANGE
ENFORCEMENT_CHANGE
SEMANTIC_CHANGE
RETIREMENT
```

---

# 106. Rule Testing

Each active rule needs:

- positive conflict test;
- negative test;
- scope test;
- exception test;
- expiry test;
- runtime test.

---

# 107. Shadow Mode

New rule may run in detect-only shadow mode before blocking.

---

# 108. Shadow Analysis

Measure:

- affected users;
- affected transactions;
- false positives;
- operational impact;
- exception volume.

---

# 109. Activation Gate

Blocking rule activation requires impact analysis.

---

# 110. Conflict Reconciliation

Compare current assignments and transactions against active rules.

---

# 111. Reconciliation Findings

```text
ACTIVE_CONFLICT
EXPIRED_EXCEPTION
UNOWNED_RULE
MISSING_COMPENSATING_CONTROL
SCOPE_DRIFT
POLICY_DRIFT
UNREVIEWED_CONFLICT
```

---

# 112. Reconciliation Frequency

- real-time assignment check;
- runtime transaction check;
- daily static scan;
- periodic access review;
- pre-release scan;
- post-policy-change scan.

---

# 113. Historical Conflict

Historical conflict may require investigation even after access revoked.

---

# 114. Conflict Review

Review outcome:

```text
REMEDIATE
ACCEPT_WITH_EXCEPTION
FALSE_POSITIVE
RULE_UPDATE
ESCALATE
CLOSE
```

---

# 115. Access Certification

Access certification should surface SoD conflicts prominently.

---

# 116. Revocation Priority

For critical conflict, recommended priority:

```text
Temporary/Emergency Grant
→ Delegated Grant
→ Group-Derived Grant
→ Direct Privileged Grant
```

Actual decision requires owner review.

---

# 117. Auto-Remediation

Auto-remediation may suspend newest conflicting assignment.

---

# 118. Auto-Remediation Guardrails

- approved policy;
- deterministic newest assignment;
- notification;
- audit;
- rollback path;
- no silent deletion.

---

# 119. Notifications

Notify:

- subject;
- requester;
- approver;
- role owner;
- control owner;
- security/compliance for critical conflict.

---

# 120. Conflict Case

Critical conflict should create case/work item.

---

# 121. Conflict Case Fields

```text
case_id
rule_code
subject
scope
severity
detected_at
source
status
owner
due_date
resolution
```

---

# 122. Case Status

```text
OPEN
ASSIGNED
IN_REVIEW
REMEDIATION
EXCEPTION_REQUESTED
RESOLVED
VERIFIED
CLOSED
```

---

# 123. SLA

Suggested:

| Severity | Response |
|---|---:|
| Critical | Immediate / same day |
| High | 1 business day |
| Moderate | 5 business days |
| Low | Next review cycle |

---

# 124. Escalation

Escalate when:

- critical conflict active;
- exception expired;
- owner missing;
- remediation overdue;
- compensating control failed;
- repeated self-approval attempt;
- cross-tenant conflict.

---

# 125. Audit Events

```text
RBAC_SOD_RULE_CREATED
RBAC_SOD_RULE_APPROVED
RBAC_SOD_RULE_ACTIVATED
RBAC_SOD_CONFLICT_DETECTED
RBAC_SOD_ASSIGNMENT_BLOCKED
RBAC_SOD_TRANSACTION_BLOCKED
RBAC_SOD_EXCEPTION_REQUESTED
RBAC_SOD_EXCEPTION_APPROVED
RBAC_SOD_EXCEPTION_EXPIRED
RBAC_SOD_CONFLICT_REMEDIATED
RBAC_SOD_RECONCILIATION_COMPLETED
```

---

# 126. Audit Metadata

```text
rule_code
conflict_type
subject_id
left_operand
right_operand
scope
resource
severity
decision
exception_id
actor
approver
correlation_id
```

---

# 127. Logging

Do not log unnecessary sensitive payload.

---

# 128. Metrics

```text
rbac_sod_rule_total
rbac_sod_active_rule_total
rbac_sod_conflict_total
rbac_sod_assignment_block_total
rbac_sod_transaction_block_total
rbac_sod_exception_total
rbac_sod_expired_exception_total
rbac_sod_open_case_total
rbac_sod_remediation_overdue_total
rbac_sod_false_positive_total
```

---

# 129. KPIs

```text
Critical active conflicts = 0
Expired active exceptions = 0
Critical rules without owner = 0
Critical conflict remediation SLA compliance = 100%
Self-approval success = 0
Assignments activated without SoD evaluation = 0
High-risk transactions without SoD evaluation = 0
```

---

# 130. KRIs

```text
Conflict growth
Exception growth
Repeated exception renewals
False-positive rate
Overdue remediation
Conflict recurrence
Emergency access conflicts
Cross-tenant conflict attempts
```

---

# 131. Database Direction

Potential tables:

```text
rbac_sod_rules
rbac_sod_rule_versions
rbac_sod_rule_operands
rbac_sod_conflict_cases
rbac_sod_conflict_evidence
rbac_sod_exceptions
rbac_sod_compensating_controls
rbac_sod_evaluations
rbac_sod_reconciliation_runs
rbac_sod_reconciliation_findings
```

---

# 132. Table: rbac_sod_rules

```sql
CREATE TABLE rbac_sod_rules (
    id CHAR(26) NOT NULL,
    rule_code VARCHAR(180) NOT NULL,
    name VARCHAR(255) NOT NULL,
    description_text VARCHAR(2000) NOT NULL,
    conflict_type VARCHAR(40) NOT NULL,
    severity VARCHAR(30) NOT NULL,
    enforcement_mode VARCHAR(40) NOT NULL,
    scope_overlap_mode VARCHAR(50) NOT NULL,
    owner_reference VARCHAR(180) NOT NULL,
    status VARCHAR(30) NOT NULL,
    active_version VARCHAR(100) NULL,
    created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    updated_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6)
        ON UPDATE CURRENT_TIMESTAMP(6),

    PRIMARY KEY (id),
    UNIQUE KEY uq_rbac_sod_rule_code (rule_code),
    KEY idx_rbac_sod_rule_status (
        status,
        severity
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

# 133. Table: rbac_sod_rule_versions

```sql
CREATE TABLE rbac_sod_rule_versions (
    id CHAR(26) NOT NULL,
    sod_rule_id CHAR(26) NOT NULL,
    version VARCHAR(100) NOT NULL,
    rule_document_json JSON NOT NULL,
    checksum_sha256 CHAR(64) NOT NULL,
    status VARCHAR(30) NOT NULL,
    approved_by VARCHAR(180) NULL,
    effective_from DATETIME(6) NULL,
    effective_to DATETIME(6) NULL,

    PRIMARY KEY (id),
    UNIQUE KEY uq_rbac_sod_rule_version (
        sod_rule_id,
        version
    ),
    CONSTRAINT fk_rbac_sod_rule_version_rule
        FOREIGN KEY (sod_rule_id)
        REFERENCES rbac_sod_rules (id)
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

# 134. Table: rbac_sod_rule_operands

```sql
CREATE TABLE rbac_sod_rule_operands (
    id CHAR(26) NOT NULL,
    sod_rule_id CHAR(26) NOT NULL,
    operand_side VARCHAR(20) NOT NULL,
    operand_type VARCHAR(40) NOT NULL,
    operand_code VARCHAR(180) NOT NULL,
    metadata_json JSON NULL,

    PRIMARY KEY (id),
    UNIQUE KEY uq_rbac_sod_operand (
        sod_rule_id,
        operand_side,
        operand_type,
        operand_code
    ),
    CONSTRAINT fk_rbac_sod_operand_rule
        FOREIGN KEY (sod_rule_id)
        REFERENCES rbac_sod_rules (id)
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

# 135. Table: rbac_sod_conflict_cases

```sql
CREATE TABLE rbac_sod_conflict_cases (
    id CHAR(26) NOT NULL,
    case_code VARCHAR(100) NOT NULL,
    sod_rule_id CHAR(26) NOT NULL,
    subject_id CHAR(26) NOT NULL,
    tenant_id CHAR(26) NOT NULL,
    scope_type VARCHAR(30) NOT NULL,
    scope_id CHAR(26) NOT NULL,
    resource_type VARCHAR(180) NULL,
    resource_id CHAR(26) NULL,
    severity VARCHAR(30) NOT NULL,
    status VARCHAR(30) NOT NULL,
    owner_reference VARCHAR(180) NULL,
    detected_at DATETIME(6) NOT NULL,
    due_at DATETIME(6) NULL,
    resolved_at DATETIME(6) NULL,
    resolution_code VARCHAR(100) NULL,

    PRIMARY KEY (id),
    UNIQUE KEY uq_rbac_sod_case_code (case_code),
    KEY idx_rbac_sod_case_status (
        status,
        severity,
        due_at
    ),
    CONSTRAINT fk_rbac_sod_case_rule
        FOREIGN KEY (sod_rule_id)
        REFERENCES rbac_sod_rules (id)
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

# 136. Table: rbac_sod_exceptions

```sql
CREATE TABLE rbac_sod_exceptions (
    id CHAR(26) NOT NULL,
    exception_code VARCHAR(100) NOT NULL,
    sod_rule_id CHAR(26) NOT NULL,
    subject_id CHAR(26) NOT NULL,
    tenant_id CHAR(26) NOT NULL,
    scope_type VARCHAR(30) NOT NULL,
    scope_id CHAR(26) NOT NULL,
    reason_text VARCHAR(2000) NOT NULL,
    compensating_controls_json JSON NOT NULL,
    status VARCHAR(30) NOT NULL,
    valid_from DATETIME(6) NOT NULL,
    valid_to DATETIME(6) NOT NULL,
    requested_by CHAR(26) NOT NULL,
    approved_by CHAR(26) NULL,
    created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),

    PRIMARY KEY (id),
    UNIQUE KEY uq_rbac_sod_exception_code (exception_code),
    KEY idx_rbac_sod_exception_active (
        status,
        valid_to
    ),
    CONSTRAINT fk_rbac_sod_exception_rule
        FOREIGN KEY (sod_rule_id)
        REFERENCES rbac_sod_rules (id)
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

# 137. Table: rbac_sod_evaluations

```sql
CREATE TABLE rbac_sod_evaluations (
    id CHAR(26) NOT NULL,
    evaluation_code VARCHAR(100) NOT NULL,
    subject_id CHAR(26) NOT NULL,
    tenant_id CHAR(26) NOT NULL,
    evaluation_type VARCHAR(40) NOT NULL,
    decision VARCHAR(40) NOT NULL,
    rule_code VARCHAR(180) NULL,
    severity VARCHAR(30) NULL,
    exception_id CHAR(26) NULL,
    context_hash CHAR(64) NOT NULL,
    correlation_id VARCHAR(100) NOT NULL,
    duration_microseconds BIGINT UNSIGNED NOT NULL,
    evaluated_at DATETIME(6) NOT NULL,

    PRIMARY KEY (id),
    UNIQUE KEY uq_rbac_sod_evaluation_code (
        evaluation_code
    ),
    KEY idx_rbac_sod_evaluation_subject (
        tenant_id,
        subject_id,
        evaluated_at
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

# 138. API Direction

```text
GET  /api/internal/v1/rbac/sod/rules
POST /api/internal/v1/rbac/sod/rules
GET  /api/internal/v1/rbac/sod/rules/{ruleCode}
POST /api/internal/v1/rbac/sod/rules/{ruleCode}/submit
POST /api/internal/v1/rbac/sod/rules/{ruleCode}/approve
POST /api/internal/v1/rbac/sod/rules/{ruleCode}/activate
POST /api/internal/v1/rbac/sod/evaluate-assignment
POST /api/internal/v1/rbac/sod/evaluate-transaction
GET  /api/internal/v1/rbac/sod/conflicts
POST /api/internal/v1/rbac/sod/exceptions
POST /api/internal/v1/rbac/sod/exceptions/{id}/approve
POST /api/internal/v1/rbac/sod/reconcile
```

---

# 139. SDK Contracts

Potential contracts:

```text
SegregationOfDutiesServiceInterface
ConflictRuleRepositoryInterface
ConflictEvaluationContextFactoryInterface
SoDExceptionServiceInterface
CompensatingControlServiceInterface
SoDReconciliationServiceInterface
```

---

# 140. Error Codes

```text
RBAC_SOD_RULE_NOT_FOUND
RBAC_SOD_RULE_INACTIVE
RBAC_SOD_CONFLICT_DETECTED
RBAC_SOD_ASSIGNMENT_BLOCKED
RBAC_SOD_TRANSACTION_BLOCKED
RBAC_SOD_SCOPE_UNRESOLVED
RBAC_SOD_EVALUATION_INDETERMINATE
RBAC_SOD_EXCEPTION_REQUIRED
RBAC_SOD_EXCEPTION_INVALID
RBAC_SOD_EXCEPTION_EXPIRED
RBAC_SOD_EXCEPTION_SCOPE_MISMATCH
RBAC_SOD_COMPENSATING_CONTROL_MISSING
RBAC_SOD_SELF_APPROVAL_DENIED
RBAC_SOD_DUAL_APPROVAL_REQUIRED
RBAC_SOD_RECONCILIATION_FAILED
```

---

# 141. Rule Proposal Checklist

- [ ] Risk scenario documented.
- [ ] Conflict type selected.
- [ ] Operands defined.
- [ ] Scope overlap defined.
- [ ] Severity assigned.
- [ ] Enforcement mode assigned.
- [ ] Owner assigned.
- [ ] Exception policy defined.
- [ ] Compensating control defined.
- [ ] Positive test defined.
- [ ] Negative test defined.
- [ ] Impact analysis complete.

---

# 142. Assignment Evaluation Checklist

- [ ] Subject active.
- [ ] Existing assignments loaded.
- [ ] Effective permissions resolved.
- [ ] Inherited grants included.
- [ ] Group/federated grants included.
- [ ] Scope overlap evaluated.
- [ ] Active exceptions evaluated.
- [ ] Indeterminate fails closed.
- [ ] Decision audited.
- [ ] Activation blocked when required.

---

# 143. Transaction Evaluation Checklist

- [ ] Current actor identified.
- [ ] Resource identified.
- [ ] Prior actors loaded.
- [ ] Workflow stage loaded.
- [ ] Scope validated.
- [ ] Applicable rule loaded.
- [ ] Exception checked.
- [ ] Dual approval checked.
- [ ] Decision enforced before side effect.
- [ ] Evidence persisted.

---

# 144. Exception Checklist

- [ ] Rule identified.
- [ ] Subject identified.
- [ ] Scope restricted.
- [ ] Business reason documented.
- [ ] Risk assessed.
- [ ] Compensating controls assigned.
- [ ] Owner assigned.
- [ ] Approver independent.
- [ ] Start/end defined.
- [ ] Renewal prohibited without review.
- [ ] Notification enabled.
- [ ] Audit evidence complete.

---

# 145. UAT — Static SoD

- [ ] Conflicting role assignment blocked.
- [ ] Non-conflicting role assignment allowed.
- [ ] Permission-level conflict detected.
- [ ] Inherited permission conflict detected.
- [ ] Group-derived conflict detected.
- [ ] Federated mapping conflict detected.
- [ ] Cross-scope overlap works.
- [ ] Cross-tenant guardrail remains enforced.
- [ ] Rule owner present.
- [ ] Decision reason stable.

---

# 146. UAT — Dynamic SoD

- [ ] Mutually exclusive role activation blocked.
- [ ] Allowed role subset activates.
- [ ] Session refresh after policy change.
- [ ] Suspended rule no longer blocks.
- [ ] Active exception permits exact context.
- [ ] Exception does not permit broader context.
- [ ] Expired exception stops working.
- [ ] Runtime decision audited.

---

# 147. UAT — Transactional SoD

- [ ] Creator cannot approve same resource.
- [ ] Requester cannot approve own request.
- [ ] Assigner cannot review own privileged assignment.
- [ ] Different actor can approve.
- [ ] Same actor on different unrelated resource follows policy.
- [ ] Resource relation accurately resolved.
- [ ] Concurrent approvals protected.
- [ ] Duplicate request remains idempotent.
- [ ] Side effect does not occur after block.

---

# 148. UAT — Scope

- [ ] Exact scope conflict works.
- [ ] Parent-child overlap works.
- [ ] Sibling scope does not conflict unless configured.
- [ ] Global role conflicts with child scope role.
- [ ] Resource-level conflict works.
- [ ] Tenant mismatch blocks.
- [ ] Scope move triggers re-evaluation.
- [ ] Unknown scope fails closed.

---

# 149. UAT — Exceptions

- [ ] Valid exception applied.
- [ ] Expired exception rejected.
- [ ] Revoked exception rejected.
- [ ] Wrong subject rejected.
- [ ] Wrong scope rejected.
- [ ] Missing compensating control rejected.
- [ ] Critical exception requires elevated approval.
- [ ] Emergency exception short-lived.
- [ ] Renewal requires fresh approval.
- [ ] Non-overridable rule remains blocked.

---

# 150. UAT — Compensating Controls

- [ ] Dual approval enforced.
- [ ] Transaction limit enforced.
- [ ] Enhanced audit enabled.
- [ ] Daily review task generated.
- [ ] Short-lived role expires.
- [ ] Failed compensating control alerts.
- [ ] Exception revoked after control failure.
- [ ] Evidence retained.

---

# 151. UAT — Reconciliation

- [ ] Existing toxic assignment detected.
- [ ] Expired exception detected.
- [ ] Unowned rule detected.
- [ ] Missing control detected.
- [ ] Policy drift detected.
- [ ] Scope drift detected.
- [ ] Case generated.
- [ ] Remediation closes conflict.
- [ ] Recurrence detected.
- [ ] Report generated.

---

# 152. UAT — Governance

- [ ] Draft rule cannot block production.
- [ ] Rule requires approval.
- [ ] Version change audited.
- [ ] Shadow mode works.
- [ ] Impact report generated.
- [ ] Blocking activation requires tests.
- [ ] Rule retirement preserves history.
- [ ] Conflict case SLA tracked.
- [ ] Critical escalation works.

---

# 153. UAT — Performance & Resilience

- [ ] Assignment evaluation P95 measured.
- [ ] Transaction evaluation P95 measured.
- [ ] Large role set tested.
- [ ] Large conflict matrix tested.
- [ ] Cache invalidates on rule activation.
- [ ] Cache invalidates on exception expiry.
- [ ] Evaluation timeout fails closed.
- [ ] Audit persistence failure handled.
- [ ] Reconciliation bounded.

---

# 154. UAT — Security & Audit

- [ ] Unauthorized rule changes denied.
- [ ] Self-approval denied.
- [ ] Cross-tenant attempts audited.
- [ ] Sensitive payload not logged.
- [ ] Conflict decisions retain correlation ID.
- [ ] Exception approvals audited.
- [ ] Emergency conflict overrides visible.
- [ ] Evidence tamper controls work.
- [ ] Audit search by subject/rule works.

---

# 155. Definition of Done — SSOT-RBAC-07

SSOT-RBAC-07 dianggap selesai bila:

- [ ] SoD types tersedia;
- [ ] conflict subjects tersedia;
- [ ] severity dan enforcement modes tersedia;
- [ ] conflict matrix tersedia;
- [ ] assignment-time evaluation tersedia;
- [ ] runtime evaluation tersedia;
- [ ] scope-overlap model tersedia;
- [ ] decision contract tersedia;
- [ ] preventive/detective/corrective controls tersedia;
- [ ] compensating controls tersedia;
- [ ] exception lifecycle tersedia;
- [ ] non-overridable rules tersedia;
- [ ] maker-checker tersedia;
- [ ] dual approval tersedia;
- [ ] role activation controls tersedia;
- [ ] workflow integration tersedia;
- [ ] service account SoD tersedia;
- [ ] domain examples tersedia;
- [ ] rule lifecycle/versioning/testing tersedia;
- [ ] shadow mode tersedia;
- [ ] reconciliation/case management tersedia;
- [ ] SLA/escalation tersedia;
- [ ] audit/logging/metrics tersedia;
- [ ] database direction tersedia;
- [ ] API direction tersedia;
- [ ] SDK contracts tersedia;
- [ ] error codes tersedia;
- [ ] checklists dan UAT tersedia.

---

# 156. Implementation Roadmap

## Phase 1 — Rule Foundation

- conflict rule schema;
- role-role matrix;
- permission-permission matrix;
- assignment-time evaluator;
- audit events;
- administrative UI/API.

## Phase 2 — Runtime SoD

- transaction context;
- prior actor resolver;
- maker-checker;
- dual approval;
- workflow integration;
- fail-closed enforcement.

## Phase 3 — Exception & Controls

- exception lifecycle;
- compensating controls;
- emergency exception;
- expiry processor;
- owner notifications;
- case management.

## Phase 4 — Reconciliation & Certification

- full assignment scan;
- transaction analytics;
- conflict case dashboard;
- access certification;
- remediation workflows;
- SLA escalation.

## Phase 5 — Advanced Continuous Controls

- shadow policy analytics;
- continuous access evaluation;
- risk-based SoD;
- cross-service transaction correlation;
- automated evidence;
- anomaly-assisted conflict detection.

---

# 157. Initial Implementation Backlog

```text
RBACS-001 SoD Rule Schema
RBACS-002 Conflict Matrix Registry
RBACS-003 Assignment Conflict Evaluator
RBACS-004 Scope Overlap Resolver
RBACS-005 Transaction Actor Resolver
RBACS-006 Transactional SoD Evaluator
RBACS-007 Maker-Checker Guard
RBACS-008 Dual Approval Guard
RBACS-009 SoD Exception Service
RBACS-010 Compensating Control Registry
RBACS-011 Exception Expiry Processor
RBACS-012 Conflict Case Management
RBACS-013 Reconciliation Engine
RBACS-014 Shadow Evaluation
RBACS-015 SoD Dashboard
RBACS-016 Access Certification Integration
```

---

# 158. Approval Gate

Dokumen dapat menjadi Approved setelah:

- Platform Architecture review;
- RBAC Owner review;
- Security Governance review;
- Risk & Compliance review;
- Audit review;
- Finance/Clinical Domain review where applicable;
- Workflow Architecture review;
- Multi-tenant isolation review;
- Operations review;
- UAT review.

---

# 159. Closing Statement

Segregation of Duties harus memastikan bahwa satu actor tidak dapat:

- meminta dan menyetujui access sendiri;
- membuat dan mengesahkan transaksi kritis sendiri;
- memberikan dan mensertifikasi privilege sendiri;
- mengubah dan mengaudit kontrol yang sama tanpa independent review;
- menjalankan seluruh critical process tanpa pemisahan tanggung jawab.

SoD bukan sekadar role conflict matrix.

SoD adalah kontrol berlapis yang mencakup assignment, session activation, workflow, transaction, exception, compensating control, monitoring, review, dan audit evidence.
