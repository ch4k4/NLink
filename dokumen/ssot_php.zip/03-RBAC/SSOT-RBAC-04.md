# SSOT-RBAC-04 — Scoped Role Assignment & Authorization Scope

---

## Status Dokumen

| Item | Nilai |
|---|---|
| Kode | SSOT-RBAC-04 |
| Judul | Scoped Role Assignment & Authorization Scope |
| Versi | 1.0 |
| Status | Draft Architecture |
| Domain | Platform Kernel |
| Kategori | Identity, Authorization & Access Governance |
| Cakupan | Role Assignment, Scope Binding, Inheritance, Delegation, Temporary Grants, Deny Boundaries, Authorization Context, Review & Revocation |
| Bergantung pada | SSOT-SCOPE-01, SSOT-SCOPE-01A, SSOT-SCOPE-02, SSOT-SCOPE-03, SSOT-SCOPE-04, SSOT-IAM-01, SSOT-IAM-03, SSOT-IAM-04, SSOT-IAM-06, SSOT-RBAC-01, SSOT-RBAC-02, SSOT-RBAC-03, SSOT-AUDIT-01 |
| Target Stack | PHP 8.1+, PDO, MySQL 8/MariaDB, Composer, PSR-4, Modular Monolith |
| Target Evolusi | Policy Engine-ready, ABAC-ready, Delegated Administration, Microservice Authorization Context |

---

# 1. Executive Summary

SSOT-RBAC-04 menetapkan standar resmi untuk scoped role assignment dan authorization scope pada Platform Kernel.

Dokumen ini mengatur:

- role assignment;
- tenant, organization, clinic, department, dan resource scope;
- assignment inheritance;
- direct dan inherited grants;
- deny boundaries;
- temporary grants;
- delegated administration;
- maker-checker;
- segregation of duties;
- assignment lifecycle;
- effective dating;
- activation dan expiry;
- revocation;
- authorization context;
- scope resolution;
- cache invalidation;
- access review;
- orphan assignment detection;
- cross-tenant protection;
- audit;
- metrics;
- UAT;
- Definition of Done.

Tujuan akhirnya adalah memastikan setiap role assignment:

- memiliki subject;
- memiliki role;
- memiliki scope;
- memiliki owner;
- memiliki lifecycle;
- memiliki effective dates;
- memiliki source;
- memiliki approval;
- tidak lintas tenant secara tidak sah;
- dapat direview;
- dapat dicabut;
- dapat diaudit;
- menghasilkan authorization decision yang deterministic.

---

# 2. Objectives

Framework harus:

- mengikat role ke scope yang eksplisit;
- mencegah role global yang tidak terkendali;
- menjaga tenant isolation;
- mendukung hierarchy scope;
- mendukung delegation;
- mendukung temporary access;
- mengendalikan privileged roles;
- menyediakan review dan revocation;
- menghasilkan authorization context konsisten;
- mendukung future policy engine.

---

# 3. Core Principles

```text
No Role Without Scope
No Scope Without Trusted Context
Least Privilege by Default
Local Authorization Remains Authoritative
Inheritance Must Be Explicit
Deny Boundaries Override Broad Grants
Temporary Access Must Expire
Privileged Assignments Require Stronger Approval
Every Assignment Must Be Reviewable
Every Decision Must Be Auditable
```

---

# 4. Scope

Framework berlaku untuk:

```text
Human Users
Service Accounts
API Clients
External Federated Identities
Tenant Administrators
Clinic Administrators
Operational Staff
Privileged Security Operators
Module-Specific Actors
```

---

# 5. Non-Scope

Dokumen ini tidak mendefinisikan:

- authentication protocol;
- role catalog detail;
- permission naming detail;
- menu rendering;
- session management;
- complete ABAC policy model.

Area tersebut diatur oleh SSOT IAM, MENU, RBAC, dan Scope terkait.

---

# 6. Core Definitions

## Subject

Identity yang menerima assignment.

## Role

Kumpulan permission yang dikelola secara governance.

## Scope

Boundary tempat role berlaku.

## Assignment

Relasi subject-role-scope dengan lifecycle dan approval.

## Effective Permission

Permission final hasil evaluasi assignment, inheritance, deny, constraint, dan context.

## Authorization Context

Konteks trusted yang digunakan untuk menghasilkan decision.

---

# 7. Assignment Model

```text
Subject
  + Role
  + Scope
  + Constraints
  + Effective Dates
  + Source
  + Approval
  = Scoped Role Assignment
```

---

# 8. Subject Types

```text
USER
SERVICE_ACCOUNT
API_CLIENT
GROUP
EXTERNAL_IDENTITY
SYSTEM_ACTOR
```

---

# 9. Scope Types

```text
GLOBAL
TENANT
ORGANIZATION
CLINIC
DEPARTMENT
TEAM
MODULE
RESOURCE
SELF
```

---

# 10. Scope Hierarchy

Recommended baseline:

```text
GLOBAL
└── TENANT
    └── ORGANIZATION
        └── CLINIC
            └── DEPARTMENT
                └── TEAM
```

Module dan resource scopes dapat menjadi orthogonal scope sesuai policy.

---

# 11. Global Scope

Global assignment hanya untuk platform-level operations yang disetujui.

---

# 12. Tenant Scope

Assignment berlaku pada satu tenant.

---

# 13. Organization Scope

Assignment berlaku pada organization di dalam tenant.

---

# 14. Clinic Scope

Assignment berlaku pada clinic di dalam organization dan tenant.

---

# 15. Department Scope

Assignment berlaku pada unit operasional tertentu.

---

# 16. Module Scope

Assignment berlaku hanya pada module/capability tertentu.

---

# 17. Resource Scope

Assignment berlaku pada resource individual atau collection terbatas.

---

# 18. Self Scope

Assignment hanya berlaku terhadap subject sendiri.

---

# 19. Scope Ownership

Every scope must have:

- canonical ID;
- scope type;
- parent scope;
- tenant binding;
- lifecycle status;
- owner.

---

# 20. Trusted Scope Context

Scope must originate from:

- authenticated session;
- trusted route binding;
- server-side lookup;
- approved job context;
- signed service context.

Raw request parameter alone is not trusted scope.

---

# 21. Assignment Types

```text
DIRECT
INHERITED
DELEGATED
TEMPORARY
EMERGENCY
SYSTEM
GROUP_DERIVED
FEDERATED_MAPPING
```

---

# 22. Direct Assignment

Created explicitly for a subject.

---

# 23. Inherited Assignment

Derived from parent scope or group membership according to policy.

---

# 24. Delegated Assignment

Granted by authorized delegated administrator.

---

# 25. Temporary Assignment

Time-bound assignment with mandatory expiry.

---

# 26. Emergency Assignment

High-risk assignment for incident or break-glass operation.

---

# 27. System Assignment

Managed by platform bootstrap or system governance.

---

# 28. Federated Mapping Assignment

Created from approved external group-to-role mapping.

External claim itself is not the final permission.

---

# 29. Assignment Status

```text
REQUESTED
PENDING_APPROVAL
SCHEDULED
ACTIVE
SUSPENDED
EXPIRED
REVOKED
REJECTED
CANCELLED
SUPERSEDED
```

---

# 30. Assignment Lifecycle

```text
Request
→ Validate
→ Conflict Check
→ Approve
→ Schedule/Activate
→ Monitor
→ Review
→ Renew/Revoke/Expire
```

---

# 31. Assignment Minimum Fields

```text
assignment_id
subject_type
subject_id
role_id
scope_type
scope_id
tenant_id
assignment_type
status
valid_from
valid_to
source
requested_by
approved_by
reason
```

---

# 32. Assignment Identity

Assignment ID must be immutable and globally unique.

---

# 33. Assignment Uniqueness

Active duplicate assignment should be prevented for the same:

```text
subject + role + scope + effective period
```

---

# 34. Effective Dating

Every assignment should support:

```text
valid_from
valid_to
activated_at
revoked_at
```

---

# 35. Open-Ended Assignment

Open-ended assignment may be allowed for normal non-privileged roles, but still requires review cadence.

---

# 36. Temporary Assignment

Temporary assignment must always have `valid_to`.

---

# 37. Scheduled Assignment

Future assignments may be approved before activation.

---

# 38. Expiry Processing

Expired assignments must become ineffective automatically.

---

# 39. Time Source

Use trusted server clock abstraction.

---

# 40. Role Assignment Constraints

Potential constraints:

```text
working_hours
network_zone
device_assurance
authentication_assurance
resource_filter
purpose
case_assignment
approval_reference
```

---

# 41. Constraint Evaluation

Constraints must be deterministic, testable, and auditable.

---

# 42. Unknown Constraint Result

Unknown result for restrictive constraint should fail closed.

---

# 43. Inheritance Model

Inheritance modes:

```text
NONE
DOWNWARD
EXPLICIT_CHILDREN
SELECTIVE
```

---

# 44. Downward Inheritance

Parent scope assignment may apply to child scopes if role policy allows.

---

# 45. Explicit Children

Assignment applies only to listed child scopes.

---

# 46. Selective Inheritance

Role policy determines which permissions inherit.

---

# 47. Role Inheritance vs Scope Inheritance

Role inheritance and scope inheritance are separate concerns.

---

# 48. Inheritance Preconditions

- role allows inheritance;
- target scope descends from source scope;
- tenant remains same;
- deny boundary absent;
- assignment active;
- constraints satisfied.

---

# 49. Cross-Tenant Inheritance

Prohibited.

---

# 50. Scope Cycle

Scope hierarchy cycles must block inheritance evaluation.

---

# 51. Inheritance Evidence

Decision should record source assignment and inheritance path.

---

# 52. Deny Boundaries

Deny boundary limits or blocks broad grants.

---

# 53. Deny Types

```text
SUBJECT_DENY
ROLE_DENY
PERMISSION_DENY
SCOPE_DENY
RESOURCE_DENY
TEMPORARY_DENY
```

---

# 54. Deny Precedence

Recommended:

```text
Explicit Deny
→ Constraint Failure
→ No Matching Grant
→ Allow
```

---

# 55. Deny Scope

Deny must be scope-aware and effective-dated.

---

# 56. Deny Governance

Privileged deny changes require audit and owner.

---

# 57. Permission Resolution

Effective permissions derive from:

```text
Active Assignments
+ Role Permissions
+ Scope Inheritance
+ Group/Federated Mapping
- Deny Boundaries
- Expired/Suspended Assignments
- Constraint Failures
```

---

# 58. Authorization Context

Minimum:

```text
subject_id
subject_type
tenant_id
active_scope
authentication_assurance
session_id
request_id
correlation_id
purpose
time
```

---

# 59. Authorization Context Immutability

Authorization context should be immutable during one decision.

---

# 60. Active Scope

Every interactive session should have explicit active scope where applicable.

---

# 61. Scope Switching

Scope switching must re-evaluate:

- membership;
- assignments;
- role permissions;
- denies;
- assurance;
- session authorization snapshot.

---

# 62. Authorization Decision

Decision result:

```text
ALLOW
DENY
NOT_APPLICABLE
INDETERMINATE
```

---

# 63. Indeterminate Result

Indeterminate should fail closed for protected operations.

---

# 64. Decision Explanation

Decision should provide safe machine-readable explanation.

Example:

```text
ALLOW: assignment RA-001 via clinic scope
DENY: assignment expired
DENY: cross-tenant scope mismatch
```

---

# 65. Permission Checker Contract

```php
interface AuthorizationServiceInterface
{
    public function decide(
        AuthorizationRequest $request
    ): AuthorizationDecision;
}
```

---

# 66. Authorization Request

```php
final readonly class AuthorizationRequest
{
    public function __construct(
        public string $subjectId,
        public string $permission,
        public ScopeContext $scope,
        public array $attributes = [],
    ) {
    }
}
```

---

# 67. Authorization Decision

```php
final readonly class AuthorizationDecision
{
    public function __construct(
        public string $result,
        public string $reasonCode,
        public array $matchedAssignments = [],
        public array $constraints = [],
    ) {
    }
}
```

---

# 68. Evaluation Order

Recommended:

```text
Validate Subject
→ Validate Tenant
→ Validate Scope
→ Load Active Assignments
→ Resolve Role Permissions
→ Apply Inheritance
→ Apply Constraints
→ Apply Denies
→ Produce Decision
→ Emit Audit/Metric
```

---

# 69. Local Authorization Authority

Federated claims, menu visibility, and client-side state must not bypass server-side decision.

---

# 70. Assignment Request

Request must include:

- subject;
- requested role;
- target scope;
- business reason;
- duration;
- requester;
- ticket/reference;
- risk classification.

---

# 71. Request Validation

Validate:

- subject active;
- role active;
- scope active;
- tenant consistency;
- requester authority;
- duration;
- conflict;
- SoD;
- privileged policy.

---

# 72. Approval Levels

```text
STANDARD
ELEVATED
PRIVILEGED
EMERGENCY
```

---

# 73. Standard Approval

May be approved by authorized scope administrator.

---

# 74. Elevated Approval

Requires role owner or data/system owner.

---

# 75. Privileged Approval

Requires maker-checker and stronger assurance.

---

# 76. Emergency Approval

May use expedited process with mandatory retrospective.

---

# 77. Maker-Checker

Requester and approver must differ for privileged assignments.

---

# 78. Self-Approval

Self-approval is prohibited for privileged assignments.

---

# 79. Segregation of Duties

Conflicting role combinations must be detected before activation.

---

# 80. SoD Conflict Types

```text
STATIC
DYNAMIC
TRANSACTIONAL
```

---

# 81. Static SoD

Two roles cannot be assigned simultaneously.

---

# 82. Dynamic SoD

Roles may coexist but not be used in the same process or transaction.

---

# 83. Transactional SoD

A subject cannot perform conflicting steps on the same transaction.

---

# 84. Conflict Result

```text
NO_CONFLICT
WARNING
BLOCK
REQUIRES_EXCEPTION
```

---

# 85. SoD Exception

Must be:

- documented;
- approved;
- time-bound;
- monitored;
- reviewed.

---

# 86. Delegated Administration

Delegated admin may assign only approved roles within approved scopes.

---

# 87. Delegation Record

Minimum:

```text
delegation_id
delegator
delegate
allowed_roles
allowed_scope
valid_from
valid_to
approval
status
```

---

# 88. Delegation Boundaries

Delegate cannot grant:

- role above own authority;
- broader scope than delegated;
- longer duration than delegation;
- prohibited privileged role;
- cross-tenant assignment.

---

# 89. Delegation Chaining

Disabled by default.

If enabled, maximum depth must be explicit.

---

# 90. Delegation Revocation

Revoking delegation should stop future grants and optionally review grants already issued.

---

# 91. Temporary Access

Temporary grants are recommended for:

- support;
- audit;
- migration;
- incident;
- project access;
- vendor access.

---

# 92. Temporary Grant Requirements

- reason;
- owner;
- approval;
- start;
- expiry;
- review;
- monitoring;
- auto-revocation.

---

# 93. Emergency Access

Emergency role assignment must:

- be short-lived;
- require strong MFA;
- be highly monitored;
- have restricted scope;
- trigger post-use review.

---

# 94. Break-Glass Assignment

Break-glass accounts and assignments follow IAM-04 controls.

---

# 95. Group-Based Assignment

Group membership may generate role assignments through approved mapping.

---

# 96. Group Source

Group source must be trusted and lifecycle-aware.

---

# 97. Group Removal

Removal from group should revoke derived assignment within defined SLA.

---

# 98. Federated Assignment

External groups map to local roles through IAM-06 registry.

---

# 99. Assignment Source Priority

Potential priority:

```text
SYSTEM
DIRECT
DELEGATED
GROUP_DERIVED
FEDERATED_MAPPING
```

Priority does not override deny or tenant boundaries.

---

# 100. Privileged Roles

Privileged roles include:

- platform administrator;
- tenant administrator;
- security administrator;
- audit administrator;
- key/secrets administrator;
- database operator;
- emergency operator.

---

# 101. Privileged Assignment Controls

- stronger approval;
- strong MFA;
- shorter review interval;
- temporary-by-default where feasible;
- session monitoring;
- no self-approval;
- complete audit.

---

# 102. Service Account Assignments

Service accounts should receive narrowly scoped roles.

---

# 103. Machine Scope

Machine identities should bind to:

- service;
- environment;
- tenant;
- module;
- allowed operations.

---

# 104. Human vs Machine Roles

Avoid assigning human administrative roles to service accounts.

---

# 105. Assignment Review

Review types:

```text
PERIODIC
EVENT_DRIVEN
PRIVILEGED
OWNER_CHANGE
TENANT_OFFBOARDING
INCIDENT
```

---

# 106. Review Frequency

Suggested:

| Assignment | Review |
|---|---:|
| Privileged | monthly/quarterly |
| Tenant admin | quarterly |
| Standard business role | 6–12 months |
| Temporary | before expiry |
| Service account | quarterly |

---

# 107. Review Outcome

```text
RETAIN
MODIFY
REVOKE
EXPIRE
ESCALATE
```

---

# 108. Review Evidence

Record reviewer, scope, decision, reason, and timestamp.

---

# 109. Automatic Review Triggers

- user termination;
- role retirement;
- scope retirement;
- tenant suspension;
- manager change;
- incident;
- SoD policy change;
- external group removal;
- provider suspension.

---

# 110. Revocation

Revocation must become effective within policy SLA.

---

# 111. Immediate Revocation

Required for:

- terminated identity;
- compromised account;
- cross-tenant assignment;
- severe SoD violation;
- revoked delegation;
- emergency kill switch.

---

# 112. Session Impact

Revocation of critical assignments may require session invalidation or authorization cache refresh.

---

# 113. Orphan Assignments

Orphan assignment references:

- missing subject;
- missing role;
- missing scope;
- inactive tenant;
- retired role;
- expired delegation.

---

# 114. Orphan Detection

Run during:

- deployment;
- migration;
- periodic reconciliation;
- role/scope retirement;
- tenant offboarding.

---

# 115. Cache Strategy

Authorization caches must include:

```text
subject
tenant
scope
role/assignment version
permission catalog version
deny version
```

---

# 116. Cache Invalidation

Invalidate on:

- assignment activation;
- revocation;
- expiry;
- role permission change;
- deny change;
- scope move;
- user status change;
- group mapping change.

---

# 117. Stale Authorization Risk

Critical revocation must not wait for long cache TTL.

---

# 118. Versioning

Assignments may carry:

```text
record_version
policy_version
role_version
scope_version
```

---

# 119. Optimistic Locking

Use for administrative updates to prevent lost changes.

---

# 120. Bulk Assignment

Bulk assignment requires:

- approved source;
- preview;
- conflict scan;
- tenant validation;
- partial failure reporting;
- rollback/compensation;
- audit.

---

# 121. Import

Imported assignments must not bypass approval and SoD policy.

---

# 122. Migration

Legacy assignment migration should classify:

```text
VALID
AMBIGUOUS_SCOPE
CONFLICTING
ORPHAN
OVER_PRIVILEGED
```

---

# 123. Cross-Tenant Protection

Every assignment must carry or derive tenant binding.

---

# 124. Global Role Restrictions

Global roles should be rare and centrally governed.

---

# 125. Tenant Administrator

Tenant administrator may manage only authorized tenant scopes and assignable roles.

---

# 126. Clinic Administrator

Clinic administrator cannot grant organization- or tenant-wide role unless explicitly delegated.

---

# 127. Resource Ownership

Resource-level authorization may additionally check ownership relationship.

---

# 128. Contextual Authorization

RBAC may be combined with context attributes, but base role and scope remain explicit.

---

# 129. Future ABAC Direction

Potential attributes:

- purpose;
- sensitivity;
- time;
- location;
- device assurance;
- relationship to resource;
- workflow state.

---

# 130. Audit Events

```text
RBAC_ASSIGNMENT_REQUESTED
RBAC_ASSIGNMENT_APPROVED
RBAC_ASSIGNMENT_REJECTED
RBAC_ASSIGNMENT_ACTIVATED
RBAC_ASSIGNMENT_SUSPENDED
RBAC_ASSIGNMENT_EXPIRED
RBAC_ASSIGNMENT_REVOKED
RBAC_ASSIGNMENT_REVIEWED
RBAC_DELEGATION_CREATED
RBAC_DELEGATION_REVOKED
RBAC_SOD_CONFLICT_DETECTED
RBAC_AUTHORIZATION_DENIED
RBAC_CROSS_TENANT_ASSIGNMENT_BLOCKED
```

---

# 131. Audit Metadata

Include:

```text
assignment_id
subject_id
role_id
scope_type
scope_id
tenant_id
requester
approver
reason
source
validity
correlation_id
```

---

# 132. Logging

Operational logs must not expose unnecessary sensitive data.

---

# 133. Metrics

```text
rbac_assignment_total
rbac_active_assignment_total
rbac_privileged_assignment_total
rbac_temporary_assignment_total
rbac_expired_assignment_total
rbac_orphan_assignment_total
rbac_sod_conflict_total
rbac_assignment_review_overdue_total
rbac_cross_tenant_block_total
rbac_authorization_denial_total
```

---

# 134. KPIs

Initial targets:

```text
Active assignments without scope = 0
Cross-tenant assignments = 0
Expired assignments still effective = 0
Privileged assignments without approval = 0
Temporary assignments without expiry = 0
Orphan assignments unresolved = 0
Overdue privileged reviews = 0
```

---

# 135. KRIs

```text
Privileged assignment growth
Long-lived temporary access
Repeated SoD exceptions
Delegated admin abuse
High authorization denial rate
Orphan assignment count
Stale cache incidents
Emergency grant frequency
```

---

# 136. Administrative Permissions

Potential:

```text
rbac.assignment.view
rbac.assignment.request
rbac.assignment.approve
rbac.assignment.revoke
rbac.assignment.review
rbac.delegation.manage
rbac.temporary_grant.manage
rbac.privileged_assignment.manage
rbac.sod_exception.manage
```

---

# 137. API Direction

```text
GET  /api/internal/v1/rbac/assignments
POST /api/internal/v1/rbac/assignments
GET  /api/internal/v1/rbac/assignments/{id}
POST /api/internal/v1/rbac/assignments/{id}/approve
POST /api/internal/v1/rbac/assignments/{id}/activate
POST /api/internal/v1/rbac/assignments/{id}/suspend
POST /api/internal/v1/rbac/assignments/{id}/revoke
POST /api/internal/v1/rbac/assignments/{id}/review
GET  /api/internal/v1/rbac/effective-permissions
POST /api/internal/v1/rbac/decisions
```

---

# 138. Database Direction

Potential tables:

```text
rbac_role_assignments
rbac_assignment_constraints
rbac_assignment_approvals
rbac_assignment_reviews
rbac_assignment_denies
rbac_delegations
rbac_sod_rules
rbac_sod_exceptions
rbac_authorization_decisions
rbac_assignment_reconciliation_runs
```

---

# 139. Table: rbac_role_assignments

```sql
CREATE TABLE rbac_role_assignments (
    id CHAR(26) NOT NULL,
    subject_type VARCHAR(30) NOT NULL,
    subject_id CHAR(26) NOT NULL,
    role_id CHAR(26) NOT NULL,
    tenant_id CHAR(26) NOT NULL,
    scope_type VARCHAR(30) NOT NULL,
    scope_id CHAR(26) NOT NULL,
    assignment_type VARCHAR(30) NOT NULL,
    status VARCHAR(30) NOT NULL,
    valid_from DATETIME(6) NOT NULL,
    valid_to DATETIME(6) NULL,
    source_code VARCHAR(100) NOT NULL,
    reason_text VARCHAR(1000) NOT NULL,
    requested_by CHAR(26) NOT NULL,
    approved_by CHAR(26) NULL,
    activated_at DATETIME(6) NULL,
    revoked_at DATETIME(6) NULL,
    record_version BIGINT UNSIGNED NOT NULL DEFAULT 1,
    created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    updated_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6)
        ON UPDATE CURRENT_TIMESTAMP(6),

    PRIMARY KEY (id),
    KEY idx_rbac_assignment_subject (
        tenant_id,
        subject_type,
        subject_id,
        status
    ),
    KEY idx_rbac_assignment_scope (
        tenant_id,
        scope_type,
        scope_id,
        status
    ),
    KEY idx_rbac_assignment_expiry (
        status,
        valid_to
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

# 140. Table: rbac_assignment_constraints

```sql
CREATE TABLE rbac_assignment_constraints (
    id CHAR(26) NOT NULL,
    role_assignment_id CHAR(26) NOT NULL,
    constraint_type VARCHAR(50) NOT NULL,
    constraint_json JSON NOT NULL,
    status VARCHAR(30) NOT NULL,

    PRIMARY KEY (id),
    KEY idx_rbac_constraint_assignment (
        role_assignment_id,
        status
    ),
    CONSTRAINT fk_rbac_constraint_assignment
        FOREIGN KEY (role_assignment_id)
        REFERENCES rbac_role_assignments (id)
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

# 141. Table: rbac_assignment_approvals

```sql
CREATE TABLE rbac_assignment_approvals (
    id CHAR(26) NOT NULL,
    role_assignment_id CHAR(26) NOT NULL,
    approval_level VARCHAR(30) NOT NULL,
    approver_reference CHAR(26) NOT NULL,
    decision VARCHAR(30) NOT NULL,
    comments_text VARCHAR(1000) NULL,
    decided_at DATETIME(6) NOT NULL,

    PRIMARY KEY (id),
    KEY idx_rbac_approval_assignment (
        role_assignment_id,
        decided_at
    ),
    CONSTRAINT fk_rbac_approval_assignment
        FOREIGN KEY (role_assignment_id)
        REFERENCES rbac_role_assignments (id)
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

# 142. Table: rbac_assignment_denies

```sql
CREATE TABLE rbac_assignment_denies (
    id CHAR(26) NOT NULL,
    tenant_id CHAR(26) NOT NULL,
    subject_id CHAR(26) NULL,
    role_id CHAR(26) NULL,
    permission_code VARCHAR(180) NULL,
    scope_type VARCHAR(30) NOT NULL,
    scope_id CHAR(26) NOT NULL,
    deny_type VARCHAR(30) NOT NULL,
    reason_text VARCHAR(1000) NOT NULL,
    valid_from DATETIME(6) NOT NULL,
    valid_to DATETIME(6) NULL,
    status VARCHAR(30) NOT NULL,
    approved_by CHAR(26) NOT NULL,

    PRIMARY KEY (id),
    KEY idx_rbac_deny_scope (
        tenant_id,
        scope_type,
        scope_id,
        status
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

# 143. Table: rbac_delegations

```sql
CREATE TABLE rbac_delegations (
    id CHAR(26) NOT NULL,
    tenant_id CHAR(26) NOT NULL,
    delegator_id CHAR(26) NOT NULL,
    delegate_id CHAR(26) NOT NULL,
    scope_type VARCHAR(30) NOT NULL,
    scope_id CHAR(26) NOT NULL,
    allowed_roles_json JSON NOT NULL,
    valid_from DATETIME(6) NOT NULL,
    valid_to DATETIME(6) NOT NULL,
    status VARCHAR(30) NOT NULL,
    approved_by CHAR(26) NOT NULL,

    PRIMARY KEY (id),
    KEY idx_rbac_delegation_delegate (
        tenant_id,
        delegate_id,
        status,
        valid_to
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

# 144. Table: rbac_assignment_reviews

```sql
CREATE TABLE rbac_assignment_reviews (
    id CHAR(26) NOT NULL,
    role_assignment_id CHAR(26) NOT NULL,
    review_type VARCHAR(30) NOT NULL,
    reviewer_reference CHAR(26) NOT NULL,
    outcome VARCHAR(30) NOT NULL,
    reason_text VARCHAR(1000) NULL,
    reviewed_at DATETIME(6) NOT NULL,
    next_review_at DATETIME(6) NULL,

    PRIMARY KEY (id),
    KEY idx_rbac_review_due (
        next_review_at,
        outcome
    ),
    CONSTRAINT fk_rbac_review_assignment
        FOREIGN KEY (role_assignment_id)
        REFERENCES rbac_role_assignments (id)
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

# 145. Event Codes

```text
RBAC_ROLE_ASSIGNMENT_REQUESTED
RBAC_ROLE_ASSIGNMENT_APPROVED
RBAC_ROLE_ASSIGNMENT_ACTIVATED
RBAC_ROLE_ASSIGNMENT_SUSPENDED
RBAC_ROLE_ASSIGNMENT_REVOKED
RBAC_ROLE_ASSIGNMENT_EXPIRED
RBAC_ROLE_ASSIGNMENT_REVIEWED
RBAC_DELEGATION_GRANTED
RBAC_DELEGATION_REVOKED
RBAC_SOD_CONFLICT_BLOCKED
RBAC_AUTHORIZATION_DECISION_RECORDED
```

---

# 146. Error Codes

```text
RBAC_ASSIGNMENT_NOT_FOUND
RBAC_ASSIGNMENT_DUPLICATE
RBAC_ASSIGNMENT_SCOPE_INVALID
RBAC_ASSIGNMENT_TENANT_MISMATCH
RBAC_ASSIGNMENT_ROLE_INACTIVE
RBAC_ASSIGNMENT_SUBJECT_INACTIVE
RBAC_ASSIGNMENT_EXPIRED
RBAC_ASSIGNMENT_APPROVAL_REQUIRED
RBAC_ASSIGNMENT_SELF_APPROVAL_DENIED
RBAC_ASSIGNMENT_SOD_CONFLICT
RBAC_ASSIGNMENT_DELEGATION_INVALID
RBAC_ASSIGNMENT_PRIVILEGE_ESCALATION
RBAC_AUTHORIZATION_SCOPE_UNRESOLVED
RBAC_AUTHORIZATION_INDETERMINATE
RBAC_CROSS_TENANT_ACCESS_DENIED
```

---

# 147. Assignment Request Checklist

- [ ] Subject active.
- [ ] Role active.
- [ ] Scope exists.
- [ ] Tenant binding valid.
- [ ] Business reason present.
- [ ] Duration appropriate.
- [ ] Requester authorized.
- [ ] SoD check passed.
- [ ] Delegation valid.
- [ ] Approval level determined.
- [ ] Privileged controls applied.
- [ ] Audit reference created.

---

# 148. Approval Checklist

- [ ] Requester differs from approver where required.
- [ ] Scope reviewed.
- [ ] Role reviewed.
- [ ] Duration reviewed.
- [ ] SoD conflict reviewed.
- [ ] Existing assignments reviewed.
- [ ] Temporary expiry present.
- [ ] Privileged MFA requirement confirmed.
- [ ] Decision recorded.
- [ ] Activation conditions clear.

---

# 149. Revocation Checklist

- [ ] Reason recorded.
- [ ] Assignment identified.
- [ ] Dependent access assessed.
- [ ] Session impact assessed.
- [ ] Cache invalidated.
- [ ] Derived assignments reviewed.
- [ ] Emergency SLA met.
- [ ] Audit event recorded.
- [ ] Subject/owner notified where appropriate.

---

# 150. UAT — Assignment Creation

- [ ] Valid tenant assignment succeeds.
- [ ] Missing scope rejected.
- [ ] Cross-tenant scope rejected.
- [ ] Inactive subject rejected.
- [ ] Inactive role rejected.
- [ ] Duplicate active assignment rejected.
- [ ] Temporary assignment requires expiry.
- [ ] Scheduled assignment activates correctly.
- [ ] Business reason required.
- [ ] Record version increments.

---

# 151. UAT — Inheritance

- [ ] Tenant role inherits to allowed organization.
- [ ] Organization role inherits to allowed clinic.
- [ ] Non-inheritable role does not propagate.
- [ ] Selective permission inheritance works.
- [ ] Cross-tenant inheritance denied.
- [ ] Scope cycle blocks evaluation.
- [ ] Inheritance path appears in decision evidence.
- [ ] Scope move invalidates cache.

---

# 152. UAT — Deny & Constraints

- [ ] Explicit deny overrides grant.
- [ ] Expired deny stops applying.
- [ ] Working-hour constraint works.
- [ ] Assurance constraint works.
- [ ] Unknown restrictive constraint fails closed.
- [ ] Resource deny works.
- [ ] Tenant boundary remains absolute.
- [ ] Decision reason is safe and clear.

---

# 153. UAT — Approval & SoD

- [ ] Standard approval works.
- [ ] Privileged maker-checker enforced.
- [ ] Self-approval denied.
- [ ] Static SoD conflict blocks activation.
- [ ] Dynamic SoD evaluated.
- [ ] Exception requires expiry.
- [ ] Emergency approval is audited.
- [ ] Approval revocation blocks activation.

---

# 154. UAT — Delegation

- [ ] Delegated admin can assign allowed role.
- [ ] Broader scope grant denied.
- [ ] Unlisted role denied.
- [ ] Expired delegation denied.
- [ ] Cross-tenant delegation denied.
- [ ] Delegation chaining disabled by default.
- [ ] Revocation blocks future grants.
- [ ] Existing delegated grants are reviewable.

---

# 155. UAT — Temporary & Emergency Access

- [ ] Temporary grant auto-expires.
- [ ] Expired grant no longer authorizes.
- [ ] Emergency role requires strong MFA.
- [ ] Emergency grant has short expiry.
- [ ] Session invalidation works on revoke.
- [ ] Post-use review created.
- [ ] Long-lived temporary grant alerts.
- [ ] Kill switch works.

---

# 156. UAT — Authorization Decision

- [ ] Matching assignment allows permission.
- [ ] No assignment denies.
- [ ] Suspended assignment denies.
- [ ] Scope mismatch denies.
- [ ] Tenant mismatch denies.
- [ ] Deny boundary overrides allow.
- [ ] Indeterminate fails closed.
- [ ] Decision includes matched assignment.
- [ ] Local RBAC overrides external claim.
- [ ] Menu visibility does not bypass checker.

---

# 157. UAT — Review & Reconciliation

- [ ] Review due dates calculate.
- [ ] Overdue reviews alert.
- [ ] Retain outcome works.
- [ ] Modify outcome creates controlled update.
- [ ] Revoke outcome removes access.
- [ ] Orphan assignment detected.
- [ ] Retired role assignments detected.
- [ ] External group removal revokes derived access.
- [ ] Reconciliation report generated.

---

# 158. UAT — Performance & Cache

- [ ] Permission lookup meets target.
- [ ] Cache is tenant-aware.
- [ ] Activation invalidates cache.
- [ ] Revocation invalidates cache.
- [ ] Role change invalidates cache.
- [ ] Deny change invalidates cache.
- [ ] Stale cache does not preserve critical access.
- [ ] Concurrent updates use optimistic locking.

---

# 159. UAT — Security & Audit

- [ ] Unauthorized assignment API denied.
- [ ] Sensitive changes require privilege.
- [ ] Cross-tenant attempts audited.
- [ ] Raw sensitive context not logged.
- [ ] Privileged assignments visible.
- [ ] Full assignment history retained.
- [ ] SoD exceptions visible.
- [ ] Emergency grants visible.
- [ ] Audit events carry correlation ID.

---

# 160. Definition of Done — SSOT-RBAC-04

SSOT-RBAC-04 dianggap selesai bila:

- [ ] objectives dan principles tersedia;
- [ ] assignment model tersedia;
- [ ] subject dan scope types tersedia;
- [ ] trusted scope context tersedia;
- [ ] assignment lifecycle tersedia;
- [ ] effective dating tersedia;
- [ ] inheritance model tersedia;
- [ ] deny boundaries tersedia;
- [ ] permission resolution tersedia;
- [ ] authorization context tersedia;
- [ ] decision contract tersedia;
- [ ] approval model tersedia;
- [ ] maker-checker tersedia;
- [ ] SoD tersedia;
- [ ] delegation tersedia;
- [ ] temporary/emergency access tersedia;
- [ ] group/federated assignments tersedia;
- [ ] privileged role controls tersedia;
- [ ] service account assignment tersedia;
- [ ] review/revocation tersedia;
- [ ] orphan reconciliation tersedia;
- [ ] cache/versioning tersedia;
- [ ] bulk/migration controls tersedia;
- [ ] tenant isolation tersedia;
- [ ] API/database direction tersedia;
- [ ] event/error codes tersedia;
- [ ] metrics/KPI/KRI tersedia;
- [ ] checklists dan UAT tersedia.

---

# 161. Implementation Roadmap

## Phase 1 — Assignment Foundation

- role assignment entity;
- scope binding;
- lifecycle;
- effective dating;
- assignment APIs;
- audit events.

## Phase 2 — Authorization Evaluation

- authorization context;
- inheritance;
- deny boundaries;
- deterministic permission resolution;
- decision explanation;
- cache strategy.

## Phase 3 — Governance Controls

- approval workflow;
- maker-checker;
- SoD engine;
- delegated administration;
- temporary grants;
- emergency access.

## Phase 4 — Review & Reconciliation

- access review;
- orphan detection;
- expiry processor;
- external group reconciliation;
- dashboards;
- review evidence.

## Phase 5 — Advanced Policy

- contextual constraints;
- ABAC attributes;
- risk-based decisions;
- distributed authorization context;
- policy decision service;
- automated certification.

---

# 162. Initial Implementation Backlog

```text
RBACA-001 Scoped Role Assignment Entity
RBACA-002 Assignment Repository
RBACA-003 Scope Binding Validator
RBACA-004 Assignment Lifecycle Service
RBACA-005 Effective Date Processor
RBACA-006 Authorization Context
RBACA-007 Permission Resolution Engine
RBACA-008 Scope Inheritance Resolver
RBACA-009 Deny Boundary Engine
RBACA-010 Approval Workflow
RBACA-011 SoD Conflict Engine
RBACA-012 Delegation Service
RBACA-013 Temporary Grant Service
RBACA-014 Access Review Service
RBACA-015 Assignment Reconciliation
RBACA-016 Authorization Cache
RBACA-017 RBAC Dashboard
```

---

# 163. Approval Gate

Dokumen dapat menjadi Approved setelah:

- Platform Architecture review;
- IAM Owner review;
- RBAC Owner review;
- Scope Architecture review;
- Security Governance review;
- Multi-tenant isolation review;
- Audit review;
- Operations review;
- Module Owner review;
- privileged-access review.

---

# 164. Closing Statement

Scoped role assignment harus memastikan bahwa setiap access grant:

- diberikan kepada subject yang valid;
- menggunakan role yang valid;
- terikat ke scope yang valid;
- tidak melintasi tenant tanpa authority;
- memiliki alasan;
- memiliki approval;
- memiliki lifecycle;
- dapat dibatasi;
- dapat direview;
- dapat dicabut;
- dapat diaudit.

Role tanpa scope adalah sumber privilege escalation.

Authorization harus selalu mengevaluasi identity, role, permission, scope, constraint, deny, dan lifecycle secara server-side dan deterministic.
