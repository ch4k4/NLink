# SSOT-RBAC-08 — Privileged Access & Temporary Grant Governance

---

## Status Dokumen

| Item | Nilai |
|---|---|
| Kode | SSOT-RBAC-08 |
| Judul | Privileged Access & Temporary Grant Governance |
| Versi | 1.0 |
| Status | Draft Architecture |
| Domain | Platform Kernel |
| Kategori | Privileged Access Management, Authorization Governance |
| Cakupan | Privileged Roles, Just-in-Time Access, Temporary Grants, Break-Glass, Approval, Session Controls, Expiry, Revocation, Review, Monitoring |
| Bergantung pada | SSOT-GOV-01, SSOT-GOV-04, SSOT-GOV-05, SSOT-IAM-01, SSOT-IAM-03, SSOT-IAM-04, SSOT-IAM-06, SSOT-RBAC-01, SSOT-RBAC-04, SSOT-RBAC-05, SSOT-RBAC-06, SSOT-RBAC-07, SSOT-AUDIT-01, SSOT-OBS-01, SSOT-SEC-01 |
| Target Stack | PHP 8.1+, Composer, PSR-4, PDO, MySQL 8/MariaDB, Modular Monolith |
| Target Evolusi | PAM-ready, Just-in-Time Elevation, Continuous Access Evaluation, Session Recording, Microservice-ready |

---

# 1. Executive Summary

SSOT-RBAC-08 menetapkan governance resmi untuk privileged access dan temporary grant pada Platform Kernel.

Dokumen ini mengatur:

- privileged roles;
- privileged permissions;
- privileged subjects;
- just-in-time access;
- time-bound grants;
- emergency and break-glass access;
- request and approval;
- maker-checker;
- strong authentication;
- step-up authentication;
- session restriction;
- privileged session correlation;
- command/action monitoring;
- temporary scope;
- automatic expiry;
- immediate revocation;
- periodic review;
- access certification;
- dormant privilege detection;
- standing privilege reduction;
- exception;
- compensating controls;
- audit;
- metrics;
- database direction;
- API direction;
- SDK contracts;
- UAT;
- Definition of Done;
- implementation roadmap.

Tujuan akhirnya adalah memastikan privileged access:

- diberikan hanya saat dibutuhkan;
- menggunakan least privilege;
- terikat ke scope;
- dibatasi waktu;
- disetujui secara independen;
- menggunakan strong authentication;
- dipantau;
- dapat dicabut segera;
- tidak menjadi standing privilege tanpa alasan;
- dapat direview;
- dapat diaudit;
- menghasilkan evidence yang lengkap.

---

# 2. Objectives

Framework harus:

- mengurangi standing privilege;
- mendukung just-in-time elevation;
- menjaga tenant isolation;
- mengontrol break-glass access;
- memastikan temporary grant selalu berakhir;
- mencegah self-approval;
- menyediakan session assurance;
- menyediakan revocation cepat;
- mendukung review dan certification;
- menyediakan complete audit evidence.

---

# 3. Core Principles

```text
No Privilege Without Business Need
Just-in-Time over Standing Access
Temporary Means Expiring
No Self-Approval
Strong Authentication Is Mandatory
Scope Must Be Explicit
Privileged Sessions Must Be Observable
Emergency Access Must Be Exceptional
Revocation Must Be Immediate
Every Privileged Action Must Be Auditable
```

---

# 4. Scope

Framework berlaku untuk:

```text
Platform Administrators
Tenant Administrators
Security Administrators
Audit Administrators
Database Operators
Secrets and Key Administrators
Deployment Operators
Support Engineers
Emergency Responders
Service Accounts with Elevated Capability
External Support Personnel
```

---

# 5. Non-Scope

Dokumen ini tidak menggantikan:

- standard role assignment;
- authentication implementation;
- password vault product design;
- infrastructure-specific sudo policy;
- business approval workflow;
- incident response plan.

---

# 6. Privileged Access Definition

Privileged access adalah capability yang dapat:

- mengubah security boundary;
- mengubah authorization;
- mengakses restricted data;
- memengaruhi banyak tenant;
- mengelola secrets/keys;
- mengubah production;
- menghapus atau memodifikasi evidence;
- melakukan impersonation;
- menonaktifkan controls;
- mengakses emergency functions.

---

# 7. Privileged Subject Types

```text
HUMAN_ADMIN
SECURITY_OPERATOR
SUPPORT_ENGINEER
DATABASE_OPERATOR
DEPLOYMENT_OPERATOR
SERVICE_ACCOUNT
BREAK_GLASS_ACCOUNT
EXTERNAL_SUPPORT
```

---

# 8. Privileged Access Types

```text
STANDING
JUST_IN_TIME
TEMPORARY
EMERGENCY
BREAK_GLASS
DELEGATED
SERVICE
```

---

# 9. Standing Privilege

Standing privilege harus diminimalkan dan dibatasi pada kebutuhan operasional yang dapat dibuktikan.

---

# 10. Just-in-Time Access

JIT access diberikan hanya setelah request, policy evaluation, dan approval.

---

# 11. Temporary Grant

Temporary grant memiliki `valid_from` dan `valid_to` wajib.

---

# 12. Emergency Access

Emergency access digunakan untuk incident atau service recovery.

---

# 13. Break-Glass Access

Break-glass access adalah emergency capability dengan control paling ketat dan audit penuh.

---

# 14. Delegated Privilege

Delegated privilege diberikan oleh authority yang memiliki hak delegasi.

---

# 15. Service Privilege

Service identities harus memiliki narrow machine-only capabilities.

---

# 16. Privileged Role Classification

Recommended classes:

```text
PLATFORM_ADMIN
TENANT_ADMIN
SECURITY_ADMIN
AUDIT_ADMIN
IAM_ADMIN
RBAC_ADMIN
DATABASE_OPERATOR
DEPLOYMENT_OPERATOR
KEY_ADMIN
SECRET_ADMIN
SUPPORT_OPERATOR
BREAK_GLASS_OPERATOR
```

---

# 17. Privileged Permission Classification

Permission dapat diklasifikasikan privileged berdasarkan:

- risk tier;
- scope breadth;
- sensitivity;
- irreversible impact;
- bypass capability;
- cross-tenant effect.

---

# 18. Critical Privileged Permissions

Examples:

```text
rbac.assignment.approve
rbac.policy.activate
iam.user.impersonate
security.secret.rotate
security.key.manage
audit.evidence.purge
deployment.production.execute
system.feature.kill_switch
```

---

# 19. Privilege Metadata

Minimum:

```text
role_or_permission
privilege_class
risk_tier
allowed_subject_types
allowed_scope
requires_mfa
requires_approval
max_duration
session_controls
audit_level
owner
```

---

# 20. Privileged Access Lifecycle

```text
Request
→ Validate
→ Risk Assess
→ SoD Check
→ Approve
→ Activate
→ Monitor
→ Expire/Revoke
→ Review
→ Close
```

---

# 21. Request Minimum Fields

```text
request_id
subject_id
requested_role_or_permission
target_scope
business_reason
ticket_or_incident
requested_from
requested_until
requester
```

---

# 22. Request Reason

Business reason must be specific and actionable.

Bad:

```text
Need admin access.
```

Good:

```text
Investigate production incident INC-2026-0142 affecting tenant T-102.
```

---

# 23. Requested Duration

Duration must be the shortest practical period.

---

# 24. Maximum Duration

Each privileged capability must define maximum duration.

---

# 25. Duration Examples

| Privilege | Recommended Maximum |
|---|---:|
| Break-glass | 1–4 hours |
| Incident response | 4–12 hours |
| Support access | 1 business day |
| Project access | 7–30 days |
| Standing admin | Exceptional, review quarterly |

---

# 26. Scope Requirement

Privileged grant must bind to:

```text
GLOBAL
TENANT
ORGANIZATION
CLINIC
MODULE
RESOURCE
ENVIRONMENT
```

---

# 27. Global Privilege

Global privilege requires highest approval level.

---

# 28. Environment Scope

Production privilege must be separate from development or staging privilege.

---

# 29. Multi-Tenant Privilege

Cross-tenant access must be explicit and centrally governed.

---

# 30. Resource-Limited Privilege

Prefer resource-limited grants where possible.

---

# 31. Request Validation

Validate:

- subject active;
- role/permission active;
- scope valid;
- tenant binding;
- request duration;
- business reason;
- requester authority;
- SoD conflict;
- assurance capability;
- standing privilege duplication.

---

# 32. Approval Levels

```text
STANDARD_PRIVILEGED
HIGH_PRIVILEGED
CRITICAL_PRIVILEGED
EMERGENCY
```

---

# 33. Standard Privileged Approval

Requires:

- line/domain owner;
- role owner or scope owner.

---

# 34. High Privileged Approval

Requires:

- role owner;
- security reviewer;
- independent approver.

---

# 35. Critical Privileged Approval

Requires:

- governance authority;
- security authority;
- designated executive or system owner.

---

# 36. Emergency Approval

May be expedited but must preserve:

- incident reference;
- approver;
- time limit;
- evidence;
- retrospective review.

---

# 37. Maker-Checker

Requester, approver, and activator should be distinct where risk requires.

---

# 38. Self-Approval

Self-approval is prohibited.

---

# 39. Self-Activation

Self-activation after approved request may be allowed only if policy permits and activation is audited.

---

# 40. Approval Expiry

Approved but unused request should expire.

---

# 41. SoD Integration

Every privileged request must pass SSOT-RBAC-07 evaluation.

---

# 42. Existing Privilege Check

System should detect redundant or overlapping grants.

---

# 43. Just-in-Time Flow

```text
Request
→ Approval
→ Step-Up Authentication
→ Activation
→ Session Binding
→ Monitoring
→ Automatic Expiry
```

---

# 44. JIT Activation Preconditions

- request approved;
- approval still valid;
- subject active;
- strong MFA satisfied;
- SoD check current;
- scope valid;
- no kill switch;
- no incident block.

---

# 45. Step-Up Authentication

Required for privileged activation and sensitive actions.

---

# 46. Accepted Assurance

Policy may require:

```text
MFA_STANDARD
MFA_PHISHING_RESISTANT
HARDWARE_BACKED
PRIVILEGED_WORKSTATION
```

---

# 47. Authentication Age

Privileged activation should require recent authentication.

---

# 48. Reauthentication

Reauthentication may be required for:

- impersonation;
- secret rotation;
- key management;
- audit purge;
- production deployment;
- cross-tenant operations.

---

# 49. Privileged Session

Privileged access should create distinct session context.

---

# 50. Session Correlation

Track:

```text
base_session_id
privileged_session_id
grant_id
subject_id
scope
assurance
activated_at
expires_at
```

---

# 51. Session Separation

Privileged session should be distinguishable from ordinary user session.

---

# 52. Session Duration

Must not exceed grant duration.

---

# 53. Idle Timeout

Privileged sessions require shorter idle timeout.

---

# 54. Concurrent Session Limit

Critical privileged access may limit concurrent sessions.

---

# 55. Session Binding

Privileged session may bind to:

- device;
- network zone;
- browser/session;
- privileged workstation;
- source IP range.

---

# 56. Session Recording

Where technically and legally appropriate, privileged sessions may be recorded.

---

# 57. Session Activity

Capture:

- start;
- end;
- commands/actions;
- affected resources;
- results;
- errors;
- exports/downloads;
- privilege changes.

---

# 58. Sensitive Recording

Do not capture secrets or credentials in plaintext.

---

# 59. Privileged Action Audit

Every high/critical privileged action should emit audit event.

---

# 60. Monitoring

Real-time or near-real-time monitoring for:

- unusual duration;
- cross-tenant access;
- bulk exports;
- repeated denials;
- policy changes;
- secret/key actions;
- audit evidence changes;
- impersonation.

---

# 61. Temporary Grant Status

```text
REQUESTED
PENDING_APPROVAL
APPROVED
SCHEDULED
ACTIVE
SUSPENDED
EXPIRED
REVOKED
REJECTED
CANCELLED
CLOSED
```

---

# 62. Automatic Activation

May be allowed for approved scheduled grants after final checks.

---

# 63. Automatic Expiry

Mandatory for all temporary grants.

---

# 64. Expiry Enforcement

At expiry:

- grant becomes ineffective;
- session loses privilege;
- caches invalidate;
- active tasks stop or reauthorize;
- audit event emitted.

---

# 65. Grace Period

Grace period is disabled by default.

---

# 66. Extension

Extension requires new or renewed approval.

---

# 67. Silent Renewal

Prohibited.

---

# 68. Revocation

Revocation may be:

```text
USER_REQUESTED
OWNER_REQUESTED
SECURITY_REQUESTED
AUTOMATIC
INCIDENT_DRIVEN
POLICY_DRIVEN
```

---

# 69. Immediate Revocation Conditions

- subject terminated;
- account compromised;
- incident;
- SoD violation;
- scope retired;
- approval revoked;
- anomalous behavior;
- control failure;
- provider suspension.

---

# 70. Revocation Effects

- disable grant;
- invalidate privileged session;
- invalidate caches;
- stop active delegation;
- alert owner;
- preserve evidence.

---

# 71. Kill Switch

Privileged capability may have emergency kill switch.

---

# 72. Break-Glass Accounts

Break-glass accounts must be:

- few;
- named/owned;
- strongly protected;
- not used for routine work;
- independently monitored;
- periodically tested;
- stored securely.

---

# 73. Break-Glass Credentials

Credentials should be protected by approved vault or equivalent control.

---

# 74. Break-Glass Preconditions

Where feasible:

- incident declared;
- reason entered;
- strong authentication;
- notification sent;
- session monitored.

---

# 75. Break-Glass Usage

Break-glass use must trigger immediate alert.

---

# 76. Break-Glass Duration

Shortest viable duration.

---

# 77. Break-Glass Post-Review

Mandatory post-use review.

---

# 78. Break-Glass Rotation

Credentials/keys should be rotated after use if risk warrants.

---

# 79. Dormant Privilege

Dormant standing access should be detected and removed.

---

# 80. Dormancy Threshold

Examples:

- 30 days for critical admin;
- 60 days for high-risk support;
- 90 days for standard admin.

---

# 81. Standing Privilege Review

Standing privileged access should be reviewed quarterly or more frequently.

---

# 82. Certification Outcomes

```text
RETAIN
CONVERT_TO_JIT
REDUCE_SCOPE
REDUCE_DURATION
SUSPEND
REVOKE
ESCALATE
```

---

# 83. Privileged Access Review

Review includes:

- business need;
- last use;
- scope;
- role/permissions;
- SoD;
- incidents;
- owner;
- alternative lower privilege.

---

# 84. External Support Access

External support must use:

- named identity;
- temporary grant;
- limited scope;
- strong MFA;
- monitored session;
- contractual controls;
- automatic expiry.

---

# 85. Shared Accounts

Shared privileged accounts are prohibited except approved break-glass scenarios.

---

# 86. Named Accountability

Every privileged action must resolve to a human or service owner.

---

# 87. Service Account Privilege

Service accounts must use:

- machine-only permissions;
- non-interactive authentication;
- limited scope;
- credential rotation;
- owner;
- monitoring;
- no human login.

---

# 88. Service Account Temporary Elevation

May be used for deployment/migration with strict scheduling and expiry.

---

# 89. Impersonation

Impersonation is critical privileged access.

---

# 90. Impersonation Preconditions

- dedicated permission;
- business reason;
- approval;
- target scope;
- strong MFA;
- user/tenant policy;
- full audit;
- visible banner;
- no silent impersonation.

---

# 91. Impersonation Restrictions

Cannot:

- change own approval;
- erase evidence;
- bypass tenant boundaries;
- access secrets unless separately authorized;
- continue beyond grant expiry.

---

# 92. Support Session

Support session should distinguish:

```text
support_actor
effective_subject
tenant
scope
grant
```

---

# 93. Data Export

Privileged export requires separate permission and policy.

---

# 94. Production Deployment

Production deployment privilege should be JIT where feasible.

---

# 95. Database Access

Direct production database access should be exceptional, monitored, and time-bound.

---

# 96. Secret and Key Access

Separate:

```text
secret.read
secret.rotate
key.manage
key.use
key.audit
```

---

# 97. Audit Evidence Access

Audit administrators should not have uncontrolled delete/purge capability.

---

# 98. Control Bypass

Any bypass permission must be critical, short-lived, and highly audited.

---

# 99. Exception

Exception to privileged access policy must follow governance.

---

# 100. Exception Rules

Exception must have:

- reason;
- risk;
- owner;
- compensating control;
- expiry;
- approval;
- review.

---

# 101. Non-Overridable Controls

Examples:

- terminated identity;
- cross-tenant isolation;
- no audit trail;
- self-approval for critical access;
- indefinite emergency access.

---

# 102. Compensating Controls

Examples:

- second approver;
- session recording;
- command allowlist;
- reduced duration;
- reduced scope;
- enhanced monitoring;
- after-action review;
- transaction limit.

---

# 103. Privileged Grant Record

Minimum:

```text
grant_id
subject_id
privilege_reference
scope
grant_type
status
valid_from
valid_to
request_id
approved_by
activated_at
revoked_at
```

---

# 104. Approval Record

Minimum:

```text
approval_id
grant_id
approval_level
approver
decision
comments
decided_at
```

---

# 105. Session Record

Minimum:

```text
privileged_session_id
grant_id
base_session_id
subject_id
scope
assurance
started_at
ended_at
end_reason
```

---

# 106. Access Review Record

Minimum:

```text
review_id
grant_id_or_subject
reviewer
outcome
reason
reviewed_at
next_review_at
```

---

# 107. Audit Events

```text
RBAC_PRIVILEGED_ACCESS_REQUESTED
RBAC_PRIVILEGED_ACCESS_APPROVED
RBAC_PRIVILEGED_ACCESS_REJECTED
RBAC_PRIVILEGED_ACCESS_ACTIVATED
RBAC_PRIVILEGED_ACCESS_SUSPENDED
RBAC_PRIVILEGED_ACCESS_EXPIRED
RBAC_PRIVILEGED_ACCESS_REVOKED
RBAC_PRIVILEGED_SESSION_STARTED
RBAC_PRIVILEGED_SESSION_ENDED
RBAC_BREAK_GLASS_USED
RBAC_IMPERSONATION_STARTED
RBAC_IMPERSONATION_ENDED
RBAC_PRIVILEGED_REVIEW_COMPLETED
```

---

# 108. Audit Metadata

```text
grant_id
subject_id
privilege
scope
grant_type
requester
approver
session_id
assurance
reason
ticket
correlation_id
```

---

# 109. Logging

Do not log:

- secrets;
- passwords;
- raw tokens;
- private keys;
- unrestricted sensitive payloads.

---

# 110. Metrics

```text
rbac_privileged_grant_total
rbac_privileged_active_grant_total
rbac_privileged_standing_access_total
rbac_privileged_jit_grant_total
rbac_privileged_expired_grant_total
rbac_privileged_revocation_total
rbac_break_glass_usage_total
rbac_impersonation_total
rbac_privileged_review_overdue_total
rbac_privileged_session_duration_seconds
```

---

# 111. KPIs

```text
Temporary grants without expiry = 0
Critical grants without approval = 0
Critical activation without strong MFA = 0
Expired grants still effective = 0
Privileged shared accounts = 0
Break-glass use without review = 0
Overdue critical access reviews = 0
Standing privilege reduction trend improves
```

---

# 112. KRIs

```text
Standing privilege growth
Repeated emergency access
Long privileged sessions
Cross-tenant privileged attempts
Dormant admin accounts
Privilege extension frequency
Failed revocation
Unreviewed break-glass use
High-volume privileged export
```

---

# 113. Database Direction

Potential tables:

```text
rbac_privileged_access_requests
rbac_privileged_grants
rbac_privileged_approvals
rbac_privileged_sessions
rbac_privileged_session_events
rbac_break_glass_accounts
rbac_privileged_access_reviews
rbac_privileged_exceptions
rbac_privileged_reconciliation_runs
rbac_privileged_reconciliation_findings
```

---

# 114. Table: rbac_privileged_access_requests

```sql
CREATE TABLE rbac_privileged_access_requests (
    id CHAR(26) NOT NULL,
    request_code VARCHAR(100) NOT NULL,
    subject_id CHAR(26) NOT NULL,
    privilege_type VARCHAR(40) NOT NULL,
    privilege_reference VARCHAR(180) NOT NULL,
    tenant_id CHAR(26) NOT NULL,
    scope_type VARCHAR(30) NOT NULL,
    scope_id CHAR(26) NOT NULL,
    business_reason VARCHAR(2000) NOT NULL,
    ticket_reference VARCHAR(180) NULL,
    requested_from DATETIME(6) NOT NULL,
    requested_until DATETIME(6) NOT NULL,
    status VARCHAR(30) NOT NULL,
    requested_by CHAR(26) NOT NULL,
    created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),

    PRIMARY KEY (id),
    UNIQUE KEY uq_rbac_priv_request_code (request_code),
    KEY idx_rbac_priv_request_subject (
        tenant_id,
        subject_id,
        status
    ),
    KEY idx_rbac_priv_request_period (
        requested_from,
        requested_until,
        status
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

# 115. Table: rbac_privileged_grants

```sql
CREATE TABLE rbac_privileged_grants (
    id CHAR(26) NOT NULL,
    grant_code VARCHAR(100) NOT NULL,
    request_id CHAR(26) NOT NULL,
    subject_id CHAR(26) NOT NULL,
    privilege_reference VARCHAR(180) NOT NULL,
    grant_type VARCHAR(30) NOT NULL,
    tenant_id CHAR(26) NOT NULL,
    scope_type VARCHAR(30) NOT NULL,
    scope_id CHAR(26) NOT NULL,
    status VARCHAR(30) NOT NULL,
    valid_from DATETIME(6) NOT NULL,
    valid_to DATETIME(6) NOT NULL,
    activated_at DATETIME(6) NULL,
    expired_at DATETIME(6) NULL,
    revoked_at DATETIME(6) NULL,
    revocation_reason VARCHAR(1000) NULL,
    created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),

    PRIMARY KEY (id),
    UNIQUE KEY uq_rbac_priv_grant_code (grant_code),
    KEY idx_rbac_priv_grant_subject (
        tenant_id,
        subject_id,
        status
    ),
    KEY idx_rbac_priv_grant_expiry (
        status,
        valid_to
    ),
    CONSTRAINT fk_rbac_priv_grant_request
        FOREIGN KEY (request_id)
        REFERENCES rbac_privileged_access_requests (id)
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

# 116. Table: rbac_privileged_approvals

```sql
CREATE TABLE rbac_privileged_approvals (
    id CHAR(26) NOT NULL,
    request_id CHAR(26) NOT NULL,
    approval_level VARCHAR(30) NOT NULL,
    approver_id CHAR(26) NOT NULL,
    decision VARCHAR(30) NOT NULL,
    comments_text VARCHAR(2000) NULL,
    decided_at DATETIME(6) NOT NULL,

    PRIMARY KEY (id),
    KEY idx_rbac_priv_approval_request (
        request_id,
        decided_at
    ),
    CONSTRAINT fk_rbac_priv_approval_request
        FOREIGN KEY (request_id)
        REFERENCES rbac_privileged_access_requests (id)
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

# 117. Table: rbac_privileged_sessions

```sql
CREATE TABLE rbac_privileged_sessions (
    id CHAR(26) NOT NULL,
    session_code VARCHAR(100) NOT NULL,
    grant_id CHAR(26) NOT NULL,
    base_session_id CHAR(26) NULL,
    subject_id CHAR(26) NOT NULL,
    tenant_id CHAR(26) NOT NULL,
    scope_type VARCHAR(30) NOT NULL,
    scope_id CHAR(26) NOT NULL,
    assurance_level VARCHAR(50) NOT NULL,
    status VARCHAR(30) NOT NULL,
    started_at DATETIME(6) NOT NULL,
    expires_at DATETIME(6) NOT NULL,
    ended_at DATETIME(6) NULL,
    end_reason VARCHAR(100) NULL,

    PRIMARY KEY (id),
    UNIQUE KEY uq_rbac_priv_session_code (session_code),
    KEY idx_rbac_priv_session_subject (
        tenant_id,
        subject_id,
        status
    ),
    KEY idx_rbac_priv_session_expiry (
        status,
        expires_at
    ),
    CONSTRAINT fk_rbac_priv_session_grant
        FOREIGN KEY (grant_id)
        REFERENCES rbac_privileged_grants (id)
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

# 118. Table: rbac_break_glass_accounts

```sql
CREATE TABLE rbac_break_glass_accounts (
    id CHAR(26) NOT NULL,
    account_reference CHAR(26) NOT NULL,
    owner_reference VARCHAR(180) NOT NULL,
    scope_type VARCHAR(30) NOT NULL,
    scope_id CHAR(26) NOT NULL,
    status VARCHAR(30) NOT NULL,
    last_tested_at DATETIME(6) NULL,
    last_used_at DATETIME(6) NULL,
    next_review_at DATETIME(6) NOT NULL,
    created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),

    PRIMARY KEY (id),
    UNIQUE KEY uq_rbac_break_glass_account (
        account_reference
    ),
    KEY idx_rbac_break_glass_review (
        status,
        next_review_at
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

# 119. Table: rbac_privileged_access_reviews

```sql
CREATE TABLE rbac_privileged_access_reviews (
    id CHAR(26) NOT NULL,
    subject_id CHAR(26) NULL,
    grant_id CHAR(26) NULL,
    review_type VARCHAR(40) NOT NULL,
    reviewer_id CHAR(26) NOT NULL,
    outcome VARCHAR(40) NOT NULL,
    reason_text VARCHAR(2000) NULL,
    reviewed_at DATETIME(6) NOT NULL,
    next_review_at DATETIME(6) NULL,

    PRIMARY KEY (id),
    KEY idx_rbac_priv_review_due (
        next_review_at,
        outcome
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

# 120. API Direction

```text
GET  /api/internal/v1/rbac/privileged-access/requests
POST /api/internal/v1/rbac/privileged-access/requests
GET  /api/internal/v1/rbac/privileged-access/requests/{id}
POST /api/internal/v1/rbac/privileged-access/requests/{id}/approve
POST /api/internal/v1/rbac/privileged-access/requests/{id}/reject
POST /api/internal/v1/rbac/privileged-access/grants/{id}/activate
POST /api/internal/v1/rbac/privileged-access/grants/{id}/suspend
POST /api/internal/v1/rbac/privileged-access/grants/{id}/revoke
POST /api/internal/v1/rbac/privileged-access/grants/{id}/extend
POST /api/internal/v1/rbac/privileged-access/break-glass/start
POST /api/internal/v1/rbac/privileged-access/impersonation/start
POST /api/internal/v1/rbac/privileged-access/reconcile
```

---

# 121. SDK Contracts

Potential contracts:

```text
PrivilegedAccessRequestServiceInterface
PrivilegedGrantServiceInterface
PrivilegedApprovalServiceInterface
PrivilegedSessionServiceInterface
BreakGlassServiceInterface
ImpersonationServiceInterface
PrivilegedAccessReviewServiceInterface
PrivilegedAccessReconciliationServiceInterface
```

---

# 122. Privileged Access Request Contract

```php
interface PrivilegedAccessRequestServiceInterface
{
    public function request(
        PrivilegedAccessRequest $request
    ): PrivilegedAccessRequestResult;
}
```

---

# 123. Grant Activation Contract

```php
interface PrivilegedGrantServiceInterface
{
    public function activate(
        string $grantId,
        AuthenticationAssurance $assurance
    ): PrivilegedSession;

    public function revoke(
        string $grantId,
        string $reason
    ): void;
}
```

---

# 124. Break-Glass Contract

```php
interface BreakGlassServiceInterface
{
    public function start(
        BreakGlassRequest $request
    ): PrivilegedSession;

    public function end(
        string $privilegedSessionId,
        string $reason
    ): void;
}
```

---

# 125. Error Codes

```text
RBAC_PRIVILEGED_REQUEST_INVALID
RBAC_PRIVILEGED_REQUEST_NOT_FOUND
RBAC_PRIVILEGED_APPROVAL_REQUIRED
RBAC_PRIVILEGED_SELF_APPROVAL_DENIED
RBAC_PRIVILEGED_SOD_CONFLICT
RBAC_PRIVILEGED_SCOPE_INVALID
RBAC_PRIVILEGED_DURATION_INVALID
RBAC_PRIVILEGED_ASSURANCE_INSUFFICIENT
RBAC_PRIVILEGED_GRANT_NOT_ACTIVE
RBAC_PRIVILEGED_GRANT_EXPIRED
RBAC_PRIVILEGED_GRANT_REVOKED
RBAC_PRIVILEGED_SESSION_EXPIRED
RBAC_PRIVILEGED_BREAK_GLASS_DENIED
RBAC_PRIVILEGED_IMPERSONATION_DENIED
RBAC_PRIVILEGED_REVIEW_OVERDUE
RBAC_PRIVILEGED_RECONCILIATION_FAILED
```

---

# 126. Request Checklist

- [ ] Subject active.
- [ ] Privilege active.
- [ ] Scope valid.
- [ ] Tenant binding valid.
- [ ] Business reason specific.
- [ ] Ticket/incident included where required.
- [ ] Duration minimal.
- [ ] SoD check passed.
- [ ] Existing privilege reviewed.
- [ ] Approval level determined.
- [ ] MFA capability verified.
- [ ] Audit reference created.

---

# 127. Approval Checklist

- [ ] Approver independent.
- [ ] Self-approval blocked.
- [ ] Scope reviewed.
- [ ] Duration reviewed.
- [ ] Risk reviewed.
- [ ] SoD reviewed.
- [ ] Compensating controls assigned.
- [ ] Incident/ticket validated.
- [ ] Decision recorded.
- [ ] Approval expiry set.

---

# 128. Activation Checklist

- [ ] Request approved.
- [ ] Approval still valid.
- [ ] Subject active.
- [ ] Strong MFA completed.
- [ ] Authentication age acceptable.
- [ ] Grant not expired.
- [ ] SoD still clear.
- [ ] Kill switch inactive.
- [ ] Privileged session created.
- [ ] Monitoring enabled.
- [ ] Audit event emitted.

---

# 129. Revocation Checklist

- [ ] Reason recorded.
- [ ] Grant disabled.
- [ ] Privileged session ended.
- [ ] Authorization cache invalidated.
- [ ] Delegations reviewed.
- [ ] Active actions reauthorized/stopped.
- [ ] Owner notified.
- [ ] Evidence preserved.
- [ ] Incident linked where applicable.

---

# 130. Break-Glass Checklist

- [ ] Incident or emergency reason present.
- [ ] Named actor identified.
- [ ] Strong authentication completed.
- [ ] Scope restricted.
- [ ] Duration minimal.
- [ ] Alert sent.
- [ ] Session monitored.
- [ ] Sensitive data masking policy applied.
- [ ] Post-use review created.
- [ ] Credential rotation evaluated.

---

# 131. UAT — Request & Approval

- [ ] Valid request succeeds.
- [ ] Missing business reason rejected.
- [ ] Excessive duration rejected.
- [ ] Invalid scope rejected.
- [ ] Cross-tenant scope rejected.
- [ ] Self-approval denied.
- [ ] SoD conflict blocks approval.
- [ ] Critical request requires multiple approvals.
- [ ] Approval expires if unused.
- [ ] Rejected request cannot activate.

---

# 132. UAT — JIT Activation

- [ ] Approved grant activates.
- [ ] Strong MFA required.
- [ ] Old authentication rejected.
- [ ] Wrong scope rejected.
- [ ] Expired grant rejected.
- [ ] Suspended subject rejected.
- [ ] Privileged session created.
- [ ] Session expiry equals or precedes grant expiry.
- [ ] Activation audited.
- [ ] Cache updated.

---

# 133. UAT — Temporary Grant

- [ ] `valid_to` required.
- [ ] Scheduled grant activates at correct time.
- [ ] Grant auto-expires.
- [ ] Expired grant no longer authorizes.
- [ ] Extension requires approval.
- [ ] Silent renewal blocked.
- [ ] Session ends at expiry.
- [ ] Owner notified before expiry.
- [ ] Expiry event audited.

---

# 134. UAT — Revocation

- [ ] Manual revocation works.
- [ ] Security revocation works immediately.
- [ ] Session terminated.
- [ ] Cache invalidated.
- [ ] Active privileged operation rechecks.
- [ ] Delegated privilege reviewed.
- [ ] Revoked grant cannot reactivate.
- [ ] Revocation reason retained.
- [ ] Audit event complete.

---

# 135. UAT — Break-Glass

- [ ] Break-glass unavailable for routine request.
- [ ] Emergency reason required.
- [ ] Strong MFA required.
- [ ] Immediate alert sent.
- [ ] Session highly monitored.
- [ ] Scope limited.
- [ ] Duration limited.
- [ ] Post-use review generated.
- [ ] Repeated use alerts.
- [ ] Credential rotation workflow works.

---

# 136. UAT — Impersonation

- [ ] Dedicated permission required.
- [ ] Target tenant validated.
- [ ] Approval required.
- [ ] Visible impersonation indicator shown.
- [ ] Actor and effective subject recorded.
- [ ] Cross-tenant impersonation denied unless explicitly approved.
- [ ] Sensitive actions separately authorized.
- [ ] Session ends at grant expiry.
- [ ] Audit contains actor and subject.
- [ ] Silent impersonation impossible.

---

# 137. UAT — Privileged Session

- [ ] Session uses distinct ID.
- [ ] Short idle timeout enforced.
- [ ] Concurrent session policy enforced.
- [ ] Device/network binding works.
- [ ] Session activity logged.
- [ ] Secrets are not recorded.
- [ ] Session end reason captured.
- [ ] Session terminated on revocation.
- [ ] Correlation ID preserved.

---

# 138. UAT — Standing Privilege Review

- [ ] Dormant privilege detected.
- [ ] Last-used date visible.
- [ ] Quarterly review generated.
- [ ] Convert-to-JIT outcome works.
- [ ] Reduce-scope outcome works.
- [ ] Revoke outcome works.
- [ ] Overdue review alerts.
- [ ] Ownerless privilege detected.
- [ ] Review evidence retained.

---

# 139. UAT — Service Account Privilege

- [ ] Human login blocked.
- [ ] Machine-only permission enforced.
- [ ] Scope limited.
- [ ] Credential rotation policy applied.
- [ ] Owner required.
- [ ] JIT elevation works for migration.
- [ ] Grant auto-expires.
- [ ] Service actions audited.
- [ ] Shared service identity misuse detected.

---

# 140. UAT — Monitoring & Security

- [ ] Cross-tenant attempt alerts.
- [ ] Bulk export alerts.
- [ ] Long session alerts.
- [ ] Repeated denial alerts.
- [ ] Kill switch works.
- [ ] Privileged grant anomaly visible.
- [ ] Raw secrets not logged.
- [ ] Audit tamper controls work.
- [ ] Monitoring failure escalates.

---

# 141. UAT — Reconciliation

- [ ] Expired active grant detected.
- [ ] Standing privilege without review detected.
- [ ] Orphan privilege detected.
- [ ] Missing owner detected.
- [ ] Shared account detected.
- [ ] Break-glass without review detected.
- [ ] Grant/session mismatch detected.
- [ ] Failed revocation detected.
- [ ] Report generated.
- [ ] Critical finding opens case.

---

# 142. UAT — Performance & Resilience

- [ ] Request lookup P95 measured.
- [ ] Activation latency measured.
- [ ] Revocation propagation measured.
- [ ] Expiry processor handles volume.
- [ ] Session termination remains reliable.
- [ ] Audit persistence failure handled.
- [ ] Monitoring degradation visible.
- [ ] Duplicate activation idempotent.
- [ ] Concurrent approval safe.

---

# 143. Definition of Done — SSOT-RBAC-08

SSOT-RBAC-08 dianggap selesai bila:

- [ ] privileged access definition tersedia;
- [ ] subject and access types tersedia;
- [ ] privileged classification tersedia;
- [ ] lifecycle tersedia;
- [ ] request and approval model tersedia;
- [ ] duration and scope controls tersedia;
- [ ] maker-checker tersedia;
- [ ] SoD integration tersedia;
- [ ] JIT flow tersedia;
- [ ] step-up authentication tersedia;
- [ ] privileged session model tersedia;
- [ ] temporary grant lifecycle tersedia;
- [ ] automatic expiry tersedia;
- [ ] revocation tersedia;
- [ ] break-glass governance tersedia;
- [ ] dormant privilege review tersedia;
- [ ] external support governance tersedia;
- [ ] service account controls tersedia;
- [ ] impersonation governance tersedia;
- [ ] exception and compensating controls tersedia;
- [ ] audit/logging/metrics tersedia;
- [ ] database direction tersedia;
- [ ] API direction tersedia;
- [ ] SDK contracts tersedia;
- [ ] error codes tersedia;
- [ ] checklists dan UAT tersedia.

---

# 144. Implementation Roadmap

## Phase 1 — Privileged Grant Foundation

- request entity;
- approval workflow;
- grant lifecycle;
- scope/duration validation;
- audit events;
- basic administration UI/API.

## Phase 2 — JIT Activation

- step-up authentication;
- activation service;
- privileged session;
- automatic expiry;
- cache invalidation;
- immediate revocation.

## Phase 3 — Break-Glass & Impersonation

- break-glass account registry;
- emergency activation;
- notifications;
- impersonation session;
- actor/subject audit;
- post-use review.

## Phase 4 — Monitoring & Certification

- privileged session events;
- standing privilege review;
- dormant access detection;
- reconciliation;
- dashboards;
- SLA/escalation.

## Phase 5 — Advanced PAM

- privileged workstation binding;
- session recording;
- command allowlist;
- continuous access evaluation;
- anomaly detection;
- external PAM integration.

---

# 145. Initial Implementation Backlog

```text
RBACPAM-001 Privileged Access Request
RBACPAM-002 Privileged Approval Workflow
RBACPAM-003 Privileged Grant Entity
RBACPAM-004 Duration & Scope Validator
RBACPAM-005 JIT Activation Service
RBACPAM-006 Step-Up Integration
RBACPAM-007 Privileged Session Service
RBACPAM-008 Automatic Expiry Processor
RBACPAM-009 Immediate Revocation Service
RBACPAM-010 Break-Glass Registry
RBACPAM-011 Break-Glass Activation
RBACPAM-012 Impersonation Service
RBACPAM-013 Privileged Session Monitoring
RBACPAM-014 Standing Privilege Review
RBACPAM-015 Reconciliation Engine
RBACPAM-016 Privileged Access Dashboard
```

---

# 146. Approval Gate

Dokumen dapat menjadi Approved setelah:

- Platform Architecture review;
- IAM Owner review;
- RBAC Owner review;
- Security Governance review;
- Risk & Compliance review;
- Audit review;
- Operations review;
- Multi-tenant isolation review;
- Incident Response review;
- UAT review.

---

# 147. Closing Statement

Privileged access harus memastikan bahwa elevated capability:

- hanya diberikan saat dibutuhkan;
- memiliki alasan;
- memiliki approval;
- terikat ke scope;
- dibatasi waktu;
- menggunakan strong authentication;
- berjalan dalam privileged session;
- dipantau;
- dapat dicabut segera;
- berakhir otomatis;
- direview;
- dapat diaudit.

Standing privilege adalah exception, bukan default.

Temporary grant, JIT access, break-glass, impersonation, dan service privilege harus berada dalam satu governance model yang konsisten, fail-safe, dan evidence-driven.
