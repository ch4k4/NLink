# SSOT-RBAC-10 — Role Catalog & Role Lifecycle Governance

## Status Dokumen

| Item | Nilai |
|---|---|
| Kode | SSOT-RBAC-10 |
| Judul | Role Catalog & Role Lifecycle Governance |
| Versi | 1.0 |
| Status | Draft Architecture |
| Domain | Platform Kernel |
| Kategori | Role Engineering, Role Catalog & Lifecycle |
| Cakupan | Role Design, Ownership, Composition, Inheritance, Eligibility, Lifecycle, Versioning, Deprecation, Retirement, Reconciliation |
| Bergantung pada | SSOT-GOV-01, SSOT-GOV-04, SSOT-GOV-05, SSOT-SCOPE-01, SSOT-IAM-07, SSOT-RBAC-04, SSOT-RBAC-05, SSOT-RBAC-06, SSOT-RBAC-07, SSOT-RBAC-08, SSOT-RBAC-09, SSOT-AUDIT-01, SSOT-TEST-01 |
| Target Stack | PHP 8.1+, PDO, MySQL 8/MariaDB |
| Target Evolusi | Role Mining, Dynamic Role Eligibility, Policy-Assisted Role Design, Continuous Role Optimization |

# 1. Executive Summary

SSOT-RBAC-10 menetapkan governance resmi untuk katalog role, desain role, ownership, composition, inheritance, eligibility, versioning, activation, deprecation, retirement, dan reconciliation.

Tujuan utamanya adalah memastikan bahwa role:

- memiliki business purpose;
- memiliki owner;
- hanya berisi permission yang relevan;
- tidak tumpang tindih tanpa alasan;
- tidak menciptakan konflik SoD;
- memiliki scope model;
- memiliki eligibility rules;
- memiliki lifecycle;
- dapat direview;
- dapat direkonsiliasi;
- tidak menjadi kumpulan permission tanpa governance.

# 2. Objectives

Framework harus:

- menyediakan canonical role catalog;
- menjaga role design tetap minimal;
- mendukung scoped roles;
- mengatur composition dan inheritance;
- mencegah role explosion;
- mencegah hidden privilege;
- mendukung eligibility;
- menyediakan lifecycle dan versioning;
- mendukung certification;
- menyediakan reconciliation dan evidence.

# 3. Core Principles

```text
Every Role Has a Business Purpose
Every Role Has an Owner
Roles Contain Capabilities, Not Convenience
Least Privilege by Design
Inheritance Must Be Explicit
Composition Must Be Reviewable
No Circular Inheritance
No Hidden Permissions
Deprecated Roles Must Migrate
Every Role Must Be Certifiable
```

# 4. Scope

Berlaku untuk:

```text
Platform Roles
Tenant Roles
Organization Roles
Clinic Roles
Department Roles
Business Roles
Technical Roles
Privileged Roles
Service Roles
External Roles
Temporary Roles
```

# 5. Role Types

```text
BUSINESS
TECHNICAL
PLATFORM
TENANT_ADMIN
PRIVILEGED
SERVICE
EXTERNAL
TEMPORARY
COMPOSITE
```

# 6. Role Identity

Format role code:

```text
{domain}.{role_name}
```

Contoh:

```text
homecare.nurse
woundcare.nurse
billing.officer
tenant.admin
security.auditor
```

# 7. Role Code Rules

Role code harus:

- unik;
- stabil;
- lowercase;
- tidak mengandung tenant ID;
- tidak mengandung nama orang;
- tidak bergantung pada label UI;
- tidak berubah karena localization.

# 8. Role Metadata

Minimum:

```text
role_code
name_key
description_key
role_type
owner
risk_tier
scope_model
eligibility_policy
status
version
```

# 9. Role Owner

Setiap role wajib memiliki:

- business owner;
- technical owner;
- security reviewer untuk high-risk role;
- data owner bila role mengakses regulated data.

# 10. Role Purpose

Purpose harus menjelaskan:

- siapa yang menggunakan role;
- capability apa yang dibutuhkan;
- scope yang berlaku;
- apa yang tidak termasuk;
- risk yang terkait.

# 11. Role Scope Model

Possible:

```text
GLOBAL
TENANT
ORGANIZATION
CLINIC
DEPARTMENT
RESOURCE
SELF
```

# 12. Scope Compatibility

Permission dalam role harus kompatibel dengan scope model role.

# 13. Role Composition

Role dapat mengandung:

- permission langsung;
- child roles;
- policy references;
- scope constraints;
- obligations.

# 14. Role Inheritance

Inheritance harus:

- eksplisit;
- acyclic;
- versioned;
- bounded;
- dapat divisualisasikan;
- dapat diaudit.

# 15. Circular Inheritance

Dilarang.

# 16. Maximum Inheritance Depth

Recommended maksimum:

```text
3 levels
```

lebih dari itu membutuhkan architecture review.

# 17. Composite Role

Composite role menggabungkan role lain untuk business convenience.

# 18. Composite Role Rules

- tidak boleh menyembunyikan privileged role;
- harus memiliki owner;
- harus lolos SoD;
- harus memiliki eligibility;
- harus memiliki reason;
- harus dapat di-expand.

# 19. Direct Permission vs Child Role

Gunakan direct permissions bila capability kecil dan stabil.

Gunakan child role bila capability reusable dan memiliki owner sendiri.

# 20. Eligibility

Eligibility menentukan siapa yang boleh menerima role.

Inputs:

- identity type;
- employment type;
- tenant;
- organization;
- clinic;
- department;
- job function;
- assurance level;
- training/certification;
- contract status;
- risk level.

# 21. Eligibility Outcomes

```text
ELIGIBLE
INELIGIBLE
REQUIRES_APPROVAL
REQUIRES_TRAINING
REQUIRES_STEP_UP
REQUIRES_EXCEPTION
```

# 22. Birthright Role

Birthright role harus minimal, deterministic, dan direview.

# 23. Requestable Role

Role yang dapat diminta melalui workflow.

# 24. Privileged Role

Privileged role harus:

- high/critical risk;
- time-bound atau JIT bila memungkinkan;
- membutuhkan strong MFA;
- membutuhkan independent approval;
- direview lebih sering.

# 25. Service Role

Service role:

- machine-only;
- non-interactive;
- memiliki owner;
- memiliki scope sempit;
- tidak digunakan oleh manusia.

# 26. External Role

External role:

- sponsor required;
- expiry required;
- tenant-bound;
- limited scope;
- periodic review.

# 27. Temporary Role

Temporary role memiliki `valid_from` dan `valid_to`.

# 28. Role Risk Tier

```text
LOW
MODERATE
HIGH
CRITICAL
```

# 29. Risk Determination

Berdasarkan:

- sensitive data access;
- privileged actions;
- cross-tenant reach;
- destructive capability;
- SoD impact;
- export capability;
- security control bypass.

# 30. Role Permission Design

Role harus menggunakan canonical permission catalog dari RBAC-06.

# 31. Wildcard Permission

Wildcard tidak boleh digunakan dalam production role kecuali sangat terbatas dan disetujui.

# 32. Redundant Permission

Permissions yang sudah diwarisi tidak boleh diduplikasi tanpa alasan.

# 33. Hidden Permission

Permission tidak boleh berasal dari hard-coded logic yang tidak tercatat di role catalog.

# 34. Role Overlap

Overlap harus diukur dan direview.

# 35. Role Explosion

Role baru tidak boleh dibuat hanya untuk variasi kecil yang dapat ditangani oleh scope atau policy.

# 36. Role Mining

Role mining dapat digunakan untuk menemukan pola access, tetapi hasilnya harus direview manusia.

# 37. Role Lifecycle

```text
PROPOSED
DESIGNING
IN_REVIEW
APPROVED
ACTIVE
SUSPENDED
DEPRECATED
RETIRED
REJECTED
```

# 38. Role Proposal

Minimum:

```text
role_code
business_purpose
target_population
permissions
scope_model
owner
risk_tier
eligibility
conflicts
alternatives
```

# 39. Role Approval

Review:

- purpose;
- overlap;
- least privilege;
- permission compatibility;
- scope;
- SoD;
- ownership;
- eligibility;
- operational need.

# 40. Role Activation

Role dapat aktif setelah:

- approved;
- owner assigned;
- permissions active;
- SoD checks passed;
- tests passed;
- documentation complete.

# 41. Role Versioning

Setiap material change menghasilkan versi baru.

# 42. Material Changes

- permission added/removed;
- scope model changed;
- eligibility changed;
- inheritance changed;
- risk tier changed;
- owner changed for critical role.

# 43. Breaking Role Change

Perubahan yang mengurangi atau mengubah semantics secara material membutuhkan migration plan.

# 44. Role Assignment Migration

Role version change harus memetakan:

- retained assignments;
- invalid assignments;
- required reapproval;
- revoked permissions;
- new conflicts.

# 45. Role Suspension

Role dapat disuspend karena:

- security incident;
- owner missing;
- permission drift;
- unresolved SoD conflict;
- module inactive;
- certification expired.

# 46. Role Deprecation

Deprecation harus menentukan:

- reason;
- replacement;
- migration deadline;
- affected assignments;
- owner;
- communication plan.

# 47. Role Retirement

Preconditions:

- no active assignments;
- no child role dependencies;
- no active menu/route assumptions;
- replacement complete;
- audit retained.

# 48. Role Alias

Alias harus temporary dan resolve ke canonical role code.

# 49. Role Certification

Role owner secara periodik meninjau:

- purpose;
- permissions;
- risk;
- eligibility;
- scope;
- usage;
- conflicts;
- ownership;
- lifecycle.

# 50. Role Usage Analytics

Metrics:

- assignment count;
- last assignment;
- last use;
- unused permissions;
- dormant role;
- overlap score;
- conflict count.

# 51. Unused Role

Role tanpa assignment/use harus direview untuk retirement.

# 52. Unused Permission in Role

Permission yang tidak pernah digunakan harus direview.

# 53. Over-Privileged Role

Role dengan access di luar kebutuhan population harus direduksi.

# 54. Role Conflict

Role conflict mengikuti RBAC-07.

# 55. Role Combination Conflict

Dua role yang masing-masing aman dapat konflik saat digabung.

# 56. Role Eligibility Drift

Assignment menjadi invalid bila identity tidak lagi eligible.

# 57. Mover Integration

IAM-07 mover event harus mengevaluasi eligibility semua role.

# 58. Leaver Integration

Terminated identity kehilangan semua active role assignments.

# 59. Access Review Integration

RBAC-09 campaign menggunakan role metadata, owner, risk, dan usage.

# 60. Privileged Access Integration

RBAC-08 mengontrol JIT/temporary assignment untuk privileged roles.

# 61. Menu Projection Integration

Role tidak langsung menentukan UI; effective permissions dan scope menentukan projection.

# 62. Module Integration

Business module boleh mengkontribusikan role manifest, tetapi Platform Kernel mengatur registry.

# 63. Role Manifest

Example:

```yaml
module: homecare
version: 2.0.0
roles:
  - code: homecare.nurse
    type: BUSINESS
    owner: homecare-domain
    risk: MODERATE
    scope_model: CLINIC
    permissions:
      - homecare.visit.list
      - homecare.visit.read
      - homecare.visit.update
    eligibility:
      job_functions:
        - nurse
```

# 64. Manifest Validation

Checks:

- code;
- owner;
- type;
- risk;
- scope;
- permissions;
- eligibility;
- conflicts;
- inheritance;
- version;
- checksum.

# 65. Role Registry

Canonical role registry menyimpan metadata, versions, permissions, inheritance, eligibility, dan status.

# 66. Role Catalog API

Catalog harus dapat dicari berdasarkan:

- domain;
- owner;
- type;
- risk;
- scope;
- status;
- eligibility.

# 67. Role Assignment Guard

Sebelum assignment:

```text
Role Active?
Identity Eligible?
Scope Valid?
Permissions Active?
SoD Clear?
Approval Complete?
Duration Valid?
```

# 68. Role Removal

Removal harus:

- segera efektif;
- invalidate cache;
- terminate privileged session bila perlu;
- update menu projection;
- emit audit event.

# 69. Reconciliation

Compare:

- manifests;
- registry;
- permissions;
- assignments;
- inheritance;
- owners;
- eligibility;
- module status;
- certification status.

# 70. Reconciliation Findings

```text
MISSING_ROLE
ORPHAN_ROLE
OWNER_MISSING
PERMISSION_MISSING
INHERITANCE_CYCLE
ELIGIBILITY_DRIFT
ROLE_VERSION_DRIFT
UNUSED_ROLE
OVERLAP_EXCESSIVE
RETIRED_ROLE_ASSIGNED
```

# 71. Audit Events

```text
RBAC_ROLE_PROPOSED
RBAC_ROLE_APPROVED
RBAC_ROLE_ACTIVATED
RBAC_ROLE_UPDATED
RBAC_ROLE_SUSPENDED
RBAC_ROLE_DEPRECATED
RBAC_ROLE_RETIRED
RBAC_ROLE_PERMISSION_CHANGED
RBAC_ROLE_INHERITANCE_CHANGED
RBAC_ROLE_RECONCILIATION_FAILED
```

# 72. Metrics

```text
rbac_role_total
rbac_role_active_total
rbac_role_privileged_total
rbac_role_unused_total
rbac_role_overlap_score
rbac_role_owner_missing_total
rbac_role_conflict_total
rbac_role_eligibility_drift_total
rbac_role_reconciliation_failure_total
```

# 73. KPIs

```text
Active roles without owner = 0
Active roles with missing permission = 0
Circular inheritance = 0
Retired roles with active assignments = 0
Critical roles without certification = 0
Role eligibility drift unresolved = 0
Privileged role without JIT/exception review = 0
```

# 74. KRIs

```text
Role count growth
Composite role depth
Permission count per role
Role overlap growth
Unused role count
Ownerless role count
Privilege concentration
Exception frequency
```

# 75. Database Direction

Potential tables:

```text
rbac_roles
rbac_role_versions
rbac_role_permissions
rbac_role_inheritance
rbac_role_eligibility_rules
rbac_role_conflicts
rbac_role_owners
rbac_role_certifications
rbac_role_reconciliation_runs
rbac_role_reconciliation_findings
```

# 76. Table: rbac_roles

```sql
CREATE TABLE rbac_roles (
    id CHAR(26) NOT NULL,
    role_code VARCHAR(180) NOT NULL,
    role_type VARCHAR(40) NOT NULL,
    name_key VARCHAR(255) NOT NULL,
    description_key VARCHAR(255) NULL,
    owner_reference VARCHAR(180) NOT NULL,
    risk_tier VARCHAR(30) NOT NULL,
    scope_model VARCHAR(30) NOT NULL,
    status VARCHAR(30) NOT NULL,
    current_version VARCHAR(100) NOT NULL,
    created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),

    PRIMARY KEY (id),
    UNIQUE KEY uq_rbac_role_code (role_code),
    KEY idx_rbac_role_status (
        status,
        role_type,
        risk_tier
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

# 77. Table: rbac_role_versions

```sql
CREATE TABLE rbac_role_versions (
    id CHAR(26) NOT NULL,
    role_id CHAR(26) NOT NULL,
    version_code VARCHAR(100) NOT NULL,
    definition_json JSON NOT NULL,
    checksum_sha256 CHAR(64) NOT NULL,
    status VARCHAR(30) NOT NULL,
    approved_by VARCHAR(180) NULL,
    approved_at DATETIME(6) NULL,

    PRIMARY KEY (id),
    UNIQUE KEY uq_rbac_role_version (
        role_id,
        version_code
    ),
    CONSTRAINT fk_rbac_role_version_role
        FOREIGN KEY (role_id)
        REFERENCES rbac_roles (id)
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

# 78. Table: rbac_role_permissions

```sql
CREATE TABLE rbac_role_permissions (
    id CHAR(26) NOT NULL,
    role_version_id CHAR(26) NOT NULL,
    permission_code VARCHAR(180) NOT NULL,
    effect VARCHAR(20) NOT NULL DEFAULT 'ALLOW',
    status VARCHAR(30) NOT NULL,

    PRIMARY KEY (id),
    UNIQUE KEY uq_rbac_role_permission (
        role_version_id,
        permission_code,
        effect
    ),
    CONSTRAINT fk_rbac_role_permission_version
        FOREIGN KEY (role_version_id)
        REFERENCES rbac_role_versions (id)
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

# 79. Table: rbac_role_inheritance

```sql
CREATE TABLE rbac_role_inheritance (
    id CHAR(26) NOT NULL,
    parent_role_code VARCHAR(180) NOT NULL,
    child_role_code VARCHAR(180) NOT NULL,
    status VARCHAR(30) NOT NULL,
    valid_from DATETIME(6) NOT NULL,
    valid_to DATETIME(6) NULL,

    PRIMARY KEY (id),
    UNIQUE KEY uq_rbac_role_inheritance (
        parent_role_code,
        child_role_code
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

# 80. Table: rbac_role_eligibility_rules

```sql
CREATE TABLE rbac_role_eligibility_rules (
    id CHAR(26) NOT NULL,
    role_code VARCHAR(180) NOT NULL,
    rule_code VARCHAR(180) NOT NULL,
    rule_document_json JSON NOT NULL,
    status VARCHAR(30) NOT NULL,
    current_version VARCHAR(100) NOT NULL,

    PRIMARY KEY (id),
    UNIQUE KEY uq_rbac_role_eligibility (
        role_code,
        rule_code
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

# 81. API Direction

```text
GET  /api/internal/v1/rbac/roles
POST /api/internal/v1/rbac/roles
GET  /api/internal/v1/rbac/roles/{roleCode}
POST /api/internal/v1/rbac/roles/{roleCode}/approve
POST /api/internal/v1/rbac/roles/{roleCode}/activate
POST /api/internal/v1/rbac/roles/{roleCode}/suspend
POST /api/internal/v1/rbac/roles/{roleCode}/deprecate
POST /api/internal/v1/rbac/roles/{roleCode}/retire
POST /api/internal/v1/rbac/roles/{roleCode}/certify
POST /api/internal/v1/rbac/roles/reconcile
```

# 82. SDK Contracts

Potential:

```text
RoleCatalogInterface
RoleDefinitionValidatorInterface
RoleLifecycleServiceInterface
RoleEligibilityServiceInterface
RoleInheritanceResolverInterface
RoleCertificationServiceInterface
RoleReconciliationServiceInterface
```

# 83. Role Catalog Contract

```php
interface RoleCatalogInterface
{
    public function find(string $roleCode): ?RoleDefinition;

    public function requireActive(string $roleCode): RoleDefinition;
}
```

# 84. Eligibility Contract

```php
interface RoleEligibilityServiceInterface
{
    public function evaluate(
        RoleEligibilityRequest $request
    ): RoleEligibilityDecision;
}
```

# 85. Error Codes

```text
RBAC_ROLE_NOT_FOUND
RBAC_ROLE_CODE_INVALID
RBAC_ROLE_OWNER_REQUIRED
RBAC_ROLE_PERMISSION_INVALID
RBAC_ROLE_SCOPE_INCOMPATIBLE
RBAC_ROLE_INHERITANCE_CYCLE
RBAC_ROLE_ELIGIBILITY_FAILED
RBAC_ROLE_SOD_CONFLICT
RBAC_ROLE_VERSION_CONFLICT
RBAC_ROLE_RETIREMENT_BLOCKED
RBAC_ROLE_CERTIFICATION_EXPIRED
RBAC_ROLE_RECONCILIATION_FAILED
```

# 86. Role Proposal Checklist

- [ ] Business purpose defined.
- [ ] Role code valid.
- [ ] Owner assigned.
- [ ] Target population defined.
- [ ] Scope model defined.
- [ ] Risk tier defined.
- [ ] Permissions minimal.
- [ ] Eligibility defined.
- [ ] Overlap assessed.
- [ ] SoD checked.
- [ ] Alternatives assessed.
- [ ] Documentation complete.

# 87. Role Review Checklist

- [ ] Purpose still valid.
- [ ] Owner active.
- [ ] Permissions active.
- [ ] Scope model correct.
- [ ] Eligibility correct.
- [ ] Inheritance acyclic.
- [ ] Usage reviewed.
- [ ] Unused permissions reviewed.
- [ ] Conflicts reviewed.
- [ ] Replacement/deprecation assessed.

# 88. UAT — Role Registration

- [ ] Valid role registers.
- [ ] Duplicate code rejected.
- [ ] Missing owner rejected.
- [ ] Invalid permission rejected.
- [ ] Invalid scope model rejected.
- [ ] Circular inheritance rejected.
- [ ] Same version/checksum idempotent.
- [ ] Changed checksum/same version rejected.
- [ ] Audit generated.

# 89. UAT — Eligibility

- [ ] Eligible identity accepted.
- [ ] Wrong job function rejected.
- [ ] Wrong tenant rejected.
- [ ] Wrong clinic rejected.
- [ ] Missing training requires review.
- [ ] Expired contract rejected.
- [ ] Privileged role requires stronger assurance.
- [ ] External role requires sponsor.
- [ ] Decision reason recorded.

# 90. UAT — Composition & Inheritance

- [ ] Child role permissions resolve.
- [ ] Maximum depth enforced.
- [ ] Circular graph blocked.
- [ ] Duplicate inherited permission deduplicated.
- [ ] Composite role expands correctly.
- [ ] Privileged child role flagged.
- [ ] SoD conflict detected after composition.
- [ ] Version change recalculates effective permissions.

# 91. UAT — Lifecycle

- [ ] Proposed role not assignable.
- [ ] Approved role can activate.
- [ ] Suspended role cannot be newly assigned.
- [ ] Deprecated role warns and blocks new assignment by policy.
- [ ] Retirement blocked with active assignments.
- [ ] Replacement migration works.
- [ ] History retained.
- [ ] Certification expiry triggers review.

# 92. UAT — Reconciliation

- [ ] Missing role detected.
- [ ] Orphan role detected.
- [ ] Missing owner detected.
- [ ] Missing permission detected.
- [ ] Inheritance cycle detected.
- [ ] Eligibility drift detected.
- [ ] Version drift detected.
- [ ] Retired role assignment detected.
- [ ] Report generated.
- [ ] Critical finding opens case.

# 93. Definition of Done — SSOT-RBAC-10

SSOT-RBAC-10 dianggap selesai bila:

- [ ] role types tersedia;
- [ ] role code and metadata tersedia;
- [ ] ownership and purpose tersedia;
- [ ] scope model tersedia;
- [ ] composition and inheritance tersedia;
- [ ] eligibility tersedia;
- [ ] privileged/service/external roles tersedia;
- [ ] risk tier tersedia;
- [ ] permission design rules tersedia;
- [ ] overlap/role explosion controls tersedia;
- [ ] lifecycle tersedia;
- [ ] versioning/migration tersedia;
- [ ] suspension/deprecation/retirement tersedia;
- [ ] certification/usage analytics tersedia;
- [ ] IAM/RBAC/MENU/MODULE integration tersedia;
- [ ] manifest/registry tersedia;
- [ ] reconciliation tersedia;
- [ ] audit/metrics tersedia;
- [ ] database direction tersedia;
- [ ] API direction tersedia;
- [ ] SDK contracts tersedia;
- [ ] UAT and DoD tersedia.

# 94. Implementation Roadmap

## Phase 1 — Role Catalog Foundation

- role registry;
- metadata schema;
- ownership;
- permission mapping;
- lifecycle service;
- basic administration API.

## Phase 2 — Eligibility & Scope

- eligibility engine;
- scope compatibility;
- birthright rules;
- requestable roles;
- mover integration;
- external/service roles.

## Phase 3 — Composition & Versioning

- inheritance resolver;
- cycle detection;
- composite roles;
- versioning;
- migration planning;
- impact analysis.

## Phase 4 — Certification & Optimization

- role certification;
- usage analytics;
- overlap scoring;
- unused permission detection;
- role mining;
- deprecation/retirement workflow.

## Phase 5 — Continuous Role Governance

- automated drift detection;
- policy-assisted design;
- dynamic eligibility;
- continuous certification;
- role optimization dashboard;
- external IGA integration.

# 95. Initial Implementation Backlog

```text
RBAC10-001 Role Catalog
RBAC10-002 Role Metadata Schema
RBAC10-003 Role Lifecycle Service
RBAC10-004 Role Permission Validator
RBAC10-005 Role Eligibility Engine
RBAC10-006 Scope Compatibility Validator
RBAC10-007 Inheritance Resolver
RBAC10-008 Cycle Detector
RBAC10-009 Composite Role Builder
RBAC10-010 Role Versioning
RBAC10-011 Role Migration Planner
RBAC10-012 Role Certification
RBAC10-013 Role Usage Analytics
RBAC10-014 Overlap Analyzer
RBAC10-015 Reconciliation Engine
RBAC10-016 Role Governance Dashboard
```

# 96. Approval Gate

Dokumen dapat menjadi Approved setelah:

- RBAC Architecture review;
- IAM Governance review;
- Security review;
- Business Architecture review;
- Tenant Administration review;
- Audit/Compliance review;
- Module SDK review;
- Quality Engineering review;
- UAT review.

# 97. Closing Statement

Role harus menjadi business capability container yang terkelola.

Role tidak boleh menjadi kumpulan permission acak.

Setiap role harus memiliki purpose, owner, scope, eligibility, risk, lifecycle, dan evidence yang jelas.
