# SSOT-RBAC-06 — Permission Catalog Governance

---

## Status Dokumen

| Item | Nilai |
|---|---|
| Kode | SSOT-RBAC-06 |
| Judul | Permission Catalog Governance |
| Versi | 1.0 |
| Status | Draft Architecture |
| Domain | Platform Kernel |
| Kategori | Authorization Governance |
| Cakupan | Permission Naming, Ownership, Registration, Risk Classification, Lifecycle, Versioning, Deprecation, Route/Action Binding, Reconciliation |
| Bergantung pada | SSOT-GOV-01, SSOT-GOV-02, SSOT-GOV-03, SSOT-SCOPE-01, SSOT-IAM-01, SSOT-IAM-04, SSOT-RBAC-01, SSOT-RBAC-02, SSOT-RBAC-03, SSOT-RBAC-04, SSOT-RBAC-05, SSOT-MENU-01, SSOT-AUDIT-01 |
| Target Stack | PHP 8.1+, Composer, PSR-4, PDO, MySQL 8/MariaDB, Modular Monolith |
| Target Evolusi | Permission Registry Service, Module Self-Registration, Policy Engine-ready, Microservice-ready |

---

# 1. Executive Summary

SSOT-RBAC-06 menetapkan governance resmi untuk permission catalog pada Platform Kernel dan seluruh module bisnis.

Dokumen ini mengatur:

- struktur permission code;
- domain dan namespace;
- permission owner;
- risk classification;
- sensitivity;
- lifecycle;
- registration;
- approval;
- activation;
- deprecation;
- retirement;
- alias dan compatibility;
- route/action binding;
- UI/menu projection reference;
- module permission manifest;
- seed dan migration;
- collision detection;
- orphan permission detection;
- unused permission detection;
- wildcard governance;
- batch dan bulk permission;
- machine/service permissions;
- tenant dan scope applicability;
- evidence;
- audit;
- metrics;
- database direction;
- API direction;
- SDK contracts;
- UAT;
- Definition of Done;
- roadmap.

Tujuan akhirnya adalah memastikan permission catalog:

- menjadi single source of truth;
- memiliki kode yang stabil;
- memiliki owner;
- memiliki makna yang jelas;
- tidak duplikatif;
- tidak ambigu;
- tidak berubah diam-diam;
- dapat dipetakan ke action nyata;
- dapat direview;
- dapat diaudit;
- mendukung backward compatibility;
- mendukung modular monolith dan evolusi microservice.

---

# 2. Objectives

Permission catalog governance harus:

- menyediakan kode permission yang konsisten;
- mencegah collision;
- memisahkan role dari permission;
- menjaga least privilege;
- mendukung scope-aware authorization;
- mendukung module registration;
- menjaga compatibility;
- menyediakan deprecation path;
- mendukung audit dan evidence;
- mendukung automation dan CI gate.

---

# 3. Core Principles

```text
One Permission, One Meaning
Stable Codes, Explicit Semantics
Permissions Describe Actions, Not Job Titles
No Permission Without Owner
No Permission Without Enforcement Point
No Wildcard Without Governance
No Silent Semantic Change
Deprecate Before Retire
Catalog Is Authoritative
Every Permission Must Be Testable
```

---

# 4. Scope

Framework berlaku untuk permission yang digunakan pada:

```text
Platform Kernel
Module SDK
Business Modules
HTTP APIs
Web UI
CLI
Background Jobs
Event Consumers
File Operations
Search
Reporting
Administration
Integration
Security Operations
```

---

# 5. Non-Scope

Dokumen ini tidak mendefinisikan:

- role catalog secara lengkap;
- assignment lifecycle;
- authentication;
- session management;
- detailed menu structure;
- complete business process design.

---

# 6. Permission Definition

Permission adalah capability atomik yang memberikan hak untuk melakukan action tertentu pada resource atau domain tertentu.

Format konseptual:

```text
domain.resource.action
```

---

# 7. Permission Code Standard

Format dasar:

```text
{domain}.{resource}.{action}
```

Contoh:

```text
patient.profile.read
patient.profile.update
homecare.visit.assign
rbac.assignment.approve
audit.event.export
```

---

# 8. Extended Permission Code

Jika diperlukan:

```text
{domain}.{resource}.{subresource}.{action}
```

Contoh:

```text
patient.dm_profile.read
patient.dm_profile.update
woundcare.assessment.photo.upload
```

---

# 9. Naming Rules

Permission code harus:

- lowercase;
- menggunakan titik sebagai separator;
- menggunakan snake_case pada segment multi-word;
- bersifat action-oriented;
- stabil;
- mudah dicari;
- tidak mengandung tenant/clinic identifier;
- tidak mengandung versi runtime.

---

# 10. Prohibited Naming

Hindari:

```text
admin
superuser
full_access
manage_everything
can_do_x
access_page_1
menu_patient
button_save
```

---

# 11. Domain Segment

Recommended baseline:

```text
iam
rbac
scope
menu
audit
system
config
tenant
organization
clinic
staff
patient
appointment
emr
homecare
woundcare
crm
billing
payment
report
file
search
notification
workflow
integration
security
observability
deployment
```

---

# 12. Resource Segment

Resource harus berupa kata benda yang stabil.

Examples:

```text
user
role
assignment
patient
visit
assessment
invoice
report
file
provider
```

---

# 13. Action Segment

Recommended verbs:

```text
create
read
update
delete
list
view
approve
reject
assign
unassign
activate
deactivate
suspend
restore
archive
export
import
download
upload
publish
execute
retry
cancel
configure
manage
rotate
revoke
impersonate
```

---

# 14. Action Semantics

Action `manage` harus dihindari bila atomic actions dapat digunakan.

---

# 15. Read vs View

Gunakan `read` untuk akses resource detail.

Gunakan `list` untuk collection.

Gunakan `view` hanya untuk projection/dashboard khusus bila memang berbeda.

---

# 16. Create vs Register

Gunakan `create` untuk resource umum.

Gunakan `register` bila domain memiliki lifecycle registrasi eksplisit.

---

# 17. Delete vs Archive

`delete` berarti removal sesuai policy.

`archive` berarti perubahan lifecycle tanpa penghapusan fisik.

---

# 18. Approve vs Activate

`approve` adalah governance decision.

`activate` adalah lifecycle transition.

---

# 19. Export Permission

Export harus dipisahkan dari read bila memiliki risiko berbeda.

---

# 20. Import Permission

Import harus dipisahkan dari create/update biasa.

---

# 21. Privileged Actions

Actions berikut umumnya high-risk:

```text
impersonate
rotate
revoke
restore
purge
export
override
approve
configure
assign
```

---

# 22. Permission Metadata

Minimum:

```text
permission_code
name
description
domain
resource
action
owner
risk_tier
scope_model
status
introduced_version
```

---

# 23. Optional Metadata

```text
data_classification
requires_mfa
requires_approval
audit_level
export_control
tenant_customizable
module_code
replacement_permission
```

---

# 24. Permission Status

```text
DRAFT
IN_REVIEW
APPROVED
ACTIVE
DEPRECATED
SUSPENDED
RETIRED
REJECTED
```

---

# 25. Lifecycle

```text
Propose
→ Review
→ Approve
→ Register
→ Activate
→ Monitor
→ Deprecate
→ Retire
```

---

# 26. Draft

Permission belum boleh digunakan production.

---

# 27. In Review

Permission sedang direview dari sisi semantics, scope, risk, dan duplication.

---

# 28. Approved

Permission telah disetujui tetapi belum tentu active.

---

# 29. Active

Permission boleh digunakan oleh role, policy, route, menu, dan service.

---

# 30. Deprecated

Permission masih berfungsi selama transition period.

---

# 31. Suspended

Permission dinonaktifkan sementara karena incident atau risk.

---

# 32. Retired

Permission tidak boleh lagi digunakan.

---

# 33. Permission Owner

Every permission must have an accountable owner.

---

# 34. Owner Types

```text
PLATFORM_OWNER
DOMAIN_OWNER
MODULE_OWNER
SECURITY_OWNER
DATA_OWNER
OPERATIONS_OWNER
```

---

# 35. Owner Responsibilities

- semantics;
- risk classification;
- lifecycle;
- reviews;
- deprecation;
- replacement;
- documentation;
- UAT;
- audit response.

---

# 36. Permission Steward

Steward dapat mengelola metadata operasional tetapi tidak menggantikan accountability owner.

---

# 37. Approval Model

Approval depends on risk tier.

---

# 38. Risk Tiers

```text
LOW
MODERATE
HIGH
CRITICAL
```

---

# 39. Low Risk

Examples:

- read low-sensitivity reference data;
- list public taxonomy;
- view non-sensitive dashboard.

---

# 40. Moderate Risk

Examples:

- update ordinary master data;
- create appointment;
- manage own profile.

---

# 41. High Risk

Examples:

- export patient data;
- assign role;
- approve billing adjustment;
- configure integration.

---

# 42. Critical Risk

Examples:

- impersonate user;
- rotate secrets;
- manage encryption keys;
- cross-tenant administration;
- purge audit data;
- break-glass access.

---

# 43. Approval Requirements

| Risk | Minimum Approval |
|---|---|
| Low | Module/Domain Owner |
| Moderate | Domain Owner + Architecture Review |
| High | Domain Owner + Security/Data Review |
| Critical | Governance + Security + Executive/Designated Authority |

---

# 44. Permission Description

Description must explain:

- what action is allowed;
- on which resource;
- within what scope;
- exclusions;
- key risks.

---

# 45. Good Description

```text
Allows assigning an active homecare nurse to a homecare visit within the actor's authorized clinic scope.
```

---

# 46. Bad Description

```text
Can assign nurse.
```

---

# 47. Atomicity

Permission should represent one meaningful authorization decision.

---

# 48. Overly Broad Permission

Avoid:

```text
patient.manage
billing.full_access
system.admin
```

unless formally approved as composite or break-glass permission.

---

# 49. Composite Permission

Composite permissions should be modeled as role or policy bundles, not hidden permission expansion.

---

# 50. Wildcard Permission

Wildcards are disabled by default.

---

# 51. Wildcard Examples

```text
patient.*
*.read
system.*
```

---

# 52. Wildcard Governance

If allowed:

- platform-only;
- explicit owner;
- critical risk;
- strong MFA;
- short validity;
- full audit;
- no tenant-admin self-grant.

---

# 53. Scope Model

Every permission must define allowed scope model.

---

# 54. Scope Applicability

```text
GLOBAL_ONLY
TENANT
ORGANIZATION
CLINIC
DEPARTMENT
RESOURCE
SELF
MULTI_SCOPE
```

---

# 55. Scope Compatibility

Permission must not be assigned at scope broader than allowed.

---

# 56. Example

```text
patient.profile.read
scope_model = CLINIC|RESOURCE
```

---

# 57. Global Permission Restriction

Global-only permissions require platform governance.

---

# 58. Self Permissions

Examples:

```text
iam.user.self.read
iam.user.self.update
```

---

# 59. Scope Inheritance

Permission metadata should indicate whether role assignment inheritance is allowed.

---

# 60. Inheritance Modes

```text
NONE
DOWNWARD
SELECTIVE
```

---

# 61. Data Classification

Permission may reference data classification:

```text
PUBLIC
INTERNAL
CONFIDENTIAL
RESTRICTED
REGULATED
```

---

# 62. MFA Requirement

High-risk permission may require strong authentication assurance.

---

# 63. Approval Requirement

Certain actions may require transaction-level approval despite user having permission.

---

# 64. Audit Level

```text
NONE
STANDARD
HIGH
CRITICAL
```

---

# 65. Audit Requirement

High/critical permissions should generate business/security audit event.

---

# 66. Registration Sources

Permissions may originate from:

```text
PLATFORM_MANIFEST
MODULE_MANIFEST
MIGRATION
ADMIN_PROPOSAL
EXTERNAL_PACKAGE
```

---

# 67. Permission Manifest

Every module should publish permission manifest.

---

# 68. Manifest Example

```yaml
module: homecare
version: 1.4.0
permissions:
  - code: homecare.visit.read
    name: Read Homecare Visit
    risk_tier: MODERATE
    scope_model:
      - CLINIC
    audit_level: STANDARD
  - code: homecare.visit.assign
    name: Assign Homecare Visit
    risk_tier: HIGH
    scope_model:
      - CLINIC
    requires_mfa: false
    audit_level: HIGH
```

---

# 69. Manifest Requirements

- module code;
- module version;
- permission code;
- metadata;
- owner;
- checksum;
- compatibility declaration.

---

# 70. Module Registration

Module registration must validate manifest before activation.

---

# 71. Collision Detection

Collision occurs when:

- same code, different meaning;
- same code, different owner;
- same code, incompatible scope;
- same code, incompatible risk;
- same semantic, duplicate code.

---

# 72. Collision Result

```text
NO_COLLISION
COMPATIBLE_DUPLICATE
CONFLICT
REQUIRES_REVIEW
```

---

# 73. Conflict Handling

Conflict blocks module activation.

---

# 74. Namespace Ownership

Each domain prefix must have registered owner.

---

# 75. Reserved Prefixes

Platform may reserve:

```text
system
security
iam
rbac
audit
scope
config
deployment
```

---

# 76. Module Prefix

Business module should use owned prefix.

---

# 77. Cross-Domain Permission

Cross-domain permission requires joint ownership or platform ownership.

---

# 78. Canonical Catalog

Permission catalog is authoritative over:

- seed files;
- menu references;
- routes;
- policies;
- role definitions;
- documentation.

---

# 79. Seed Governance

Seed files must be generated or validated from canonical catalog.

---

# 80. Seed Idempotency

Permission seed must be idempotent.

---

# 81. Seed Example

```sql
INSERT INTO rbac_permissions (
    id,
    permission_code,
    name,
    domain_code,
    resource_code,
    action_code,
    risk_tier,
    status
)
VALUES (
    '01J...',
    'homecare.visit.assign',
    'Assign Homecare Visit',
    'homecare',
    'visit',
    'assign',
    'HIGH',
    'ACTIVE'
)
ON DUPLICATE KEY UPDATE
    name = VALUES(name),
    risk_tier = VALUES(risk_tier),
    status = VALUES(status);
```

---

# 82. Migration Governance

Schema and permission changes should be separated but coordinated.

---

# 83. Destructive Permission Change

Removing active permission requires impact analysis.

---

# 84. Semantic Change

Changing meaning of active permission is prohibited.

Create a new permission code instead.

---

# 85. Rename

Permission rename is modeled as:

```text
new permission
+ alias
+ migration
+ deprecation
+ retirement
```

---

# 86. Alias

Alias may support compatibility temporarily.

---

# 87. Alias Rules

- one canonical target;
- no alias chain;
- expiry required;
- audit;
- no new assignments to deprecated alias.

---

# 88. Replacement Permission

Deprecated permission should declare replacement where available.

---

# 89. Deprecation Lifecycle

```text
ACTIVE
→ DEPRECATED
→ BLOCK_NEW_USAGE
→ RETIRED
```

---

# 90. Deprecation Notice

Must include:

- reason;
- replacement;
- affected roles;
- affected routes;
- affected modules;
- deadline;
- owner.

---

# 91. Retirement Preconditions

- no active role references;
- no active route references;
- no policy references;
- no menu references;
- no service references;
- migration complete;
- audit evidence retained.

---

# 92. Backward Compatibility

Permission compatibility follows semantic meaning, not only code stability.

---

# 93. Compatibility Classes

```text
NON_BREAKING_METADATA
NON_BREAKING_SCOPE_EXPANSION_REVIEW
BREAKING_SCOPE_RESTRICTION
BREAKING_SEMANTIC_CHANGE
BREAKING_RETIREMENT
```

---

# 94. Metadata Change

Description typo is non-breaking.

---

# 95. Risk Tier Change

Risk tier increase requires review and may affect approval/MFA.

---

# 96. Scope Expansion

Scope expansion may be security-breaking even if code unchanged.

---

# 97. Scope Restriction

Scope restriction may break workflows and requires migration plan.

---

# 98. Route Binding

Protected routes must declare permission code.

---

# 99. Route Binding Example

```php
#[RequiresPermission('homecare.visit.assign')]
public function assignVisit(): Response
{
    // ...
}
```

---

# 100. Route Registry

Minimum:

```text
route_name
http_method
path
permission_code
resource_resolver
scope_resolver
```

---

# 101. Route Without Permission

Protected route without binding fails quality gate.

---

# 102. Permission Without Enforcement

Active permission without known enforcement point must be reviewed.

---

# 103. Application Action Binding

Use case/command may declare permission independently from route.

---

# 104. CLI Binding

CLI commands must declare permission or system actor policy.

---

# 105. Job Binding

Background job must declare service capability.

---

# 106. Event Consumer Binding

Consumer must declare required service permission/capability.

---

# 107. Menu Binding

Menu may reference active permission for visibility projection.

---

# 108. Menu Rule

Menu visibility is derived from permission but does not grant access.

---

# 109. Button/Action Binding

UI actions may reference permission for projection.

---

# 110. Client-Side Security

Client-side permission state is advisory only.

---

# 111. API Documentation

API docs should reference required permission.

---

# 112. Permission-to-Action Matrix

Recommended columns:

```text
permission_code
route/use_case
resource
scope
risk
audit
owner
tests
```

---

# 113. Role Permission Mapping

Role definitions must reference active canonical permissions.

---

# 114. Orphan Role Mapping

Role mapping to missing/retired permission must fail validation.

---

# 115. Permission Reconciliation

Compare catalog against:

- database;
- manifests;
- routes;
- menus;
- policies;
- roles;
- tests;
- documentation.

---

# 116. Reconciliation Outcomes

```text
MATCHED
MISSING_IN_DATABASE
MISSING_IN_CATALOG
ORPHAN_REFERENCE
SEMANTIC_DRIFT
STATUS_DRIFT
OWNER_MISSING
RISK_DRIFT
```

---

# 117. Reconciliation Frequency

- CI on every change;
- deployment;
- nightly/weekly;
- before release;
- after module activation.

---

# 118. Orphan Permission

Permission exists but has no active consumer or role mapping.

---

# 119. Unused Permission

Unused permission should be reviewed, not immediately deleted.

---

# 120. Zombie Permission

Retired permission still used by route/role/policy.

---

# 121. Shadow Permission

Code referenced in application but absent from catalog.

---

# 122. Duplicate Semantics

Different codes with same meaning should be consolidated through governance.

---

# 123. Catalog Search

Catalog must support search by:

- code;
- domain;
- resource;
- action;
- owner;
- risk;
- status;
- module;
- scope.

---

# 124. Permission Discovery

Developers should be able to discover existing permissions before proposing new ones.

---

# 125. Proposal Workflow

```text
Search Existing
→ Draft Proposal
→ Semantic Review
→ Scope Review
→ Risk Review
→ Owner Approval
→ Register
→ Test
→ Activate
```

---

# 126. Proposal Fields

```text
proposed_code
name
description
domain
resource
action
owner
risk
scope
justification
enforcement_points
alternatives_considered
```

---

# 127. Proposal Rejection Reasons

```text
DUPLICATE
TOO_BROAD
AMBIGUOUS
WRONG_DOMAIN
INVALID_ACTION
MISSING_OWNER
MISSING_ENFORCEMENT
RISK_UNASSESSED
```

---

# 128. Permission Review

Review includes:

- semantics;
- least privilege;
- scope;
- risk;
- data sensitivity;
- audit;
- MFA;
- duplicates;
- enforcement.

---

# 129. Periodic Review

Critical/high permissions should be reviewed at least annually or upon major change.

---

# 130. Event-Driven Review

Trigger when:

- incident;
- privilege escalation;
- data breach;
- scope redesign;
- module split;
- role redesign;
- regulatory change.

---

# 131. Permission Certification

Certification confirms:

- code valid;
- owner active;
- semantics current;
- scope correct;
- enforcement exists;
- tests pass;
- risk current.

---

# 132. Certification Status

```text
CERTIFIED
CONDITIONAL
EXPIRED
REVOKED
```

---

# 133. Delegated Catalog Administration

Domain owners may propose permissions within owned namespace.

---

# 134. Delegation Boundaries

Domain owner cannot:

- modify reserved prefix;
- lower critical risk without approval;
- expand global scope;
- activate wildcard;
- retire cross-domain permission alone.

---

# 135. Tenant-Defined Permission

Tenant-specific custom permission should be avoided in core catalog.

---

# 136. Tenant Extensions

If supported:

```text
tenant.{tenant_extension_namespace}.{resource}.{action}
```

and must remain isolated.

---

# 137. Platform Guardrails

Tenant extension cannot override platform permission semantics.

---

# 138. Service Permissions

Service account capabilities should be separately identifiable.

Examples:

```text
integration.claim.submit
event.outbox.publish
report.snapshot.generate
```

---

# 139. Human vs Service Permission

Permission metadata should declare allowed subject types.

---

# 140. Allowed Subject Types

```text
USER
SERVICE_ACCOUNT
API_CLIENT
SYSTEM_ACTOR
ANY_APPROVED
```

---

# 141. Machine-Only Permission

Machine-only permission must not be assignable to human role.

---

# 142. Human-Only Permission

Human-only high-risk permission should not be assignable to service account.

---

# 143. Break-Glass Permission

Break-glass permission requires:

- critical tier;
- restricted subject;
- short assignment;
- strong MFA;
- full audit;
- post-use review.

---

# 144. Sensitive Data Permission

Examples:

```text
patient.record.export
audit.event.export
security.secret.read
```

---

# 145. Read Sensitive vs Read Metadata

Split permission when access sensitivity differs.

---

# 146. Bulk Permission

Bulk action should be separate from single-resource action where risk differs.

Examples:

```text
patient.record.update
patient.record.bulk_update
```

---

# 147. Override Permission

Override must be separate and high-risk.

---

# 148. Impersonation Permission

Must never be implied by ordinary admin role.

---

# 149. Emergency Permission Suspension

Security owner may suspend permission globally with governance evidence.

---

# 150. Kill Switch

Critical permission may have runtime kill switch.

---

# 151. Permission Version

Catalog record should carry metadata version.

---

# 152. Semantic Versioning Direction

Potential:

```text
MAJOR.MINOR
```

- major for breaking semantics;
- minor for metadata additions.

---

# 153. Immutable History

Catalog history must preserve prior versions.

---

# 154. Change Record

Minimum:

```text
change_id
permission_code
change_type
old_value
new_value
owner
approver
timestamp
reason
```

---

# 155. Audit Events

```text
RBAC_PERMISSION_PROPOSED
RBAC_PERMISSION_APPROVED
RBAC_PERMISSION_ACTIVATED
RBAC_PERMISSION_UPDATED
RBAC_PERMISSION_DEPRECATED
RBAC_PERMISSION_RETIRED
RBAC_PERMISSION_SUSPENDED
RBAC_PERMISSION_ALIAS_CREATED
RBAC_PERMISSION_COLLISION_DETECTED
RBAC_PERMISSION_RECONCILIATION_FAILED
```

---

# 156. Audit Metadata

```text
permission_code
domain
owner
risk_tier
scope_model
change_type
module_code
actor
approver
correlation_id
```

---

# 157. Metrics

```text
rbac_permission_total
rbac_permission_active_total
rbac_permission_deprecated_total
rbac_permission_orphan_total
rbac_permission_shadow_total
rbac_permission_collision_total
rbac_permission_without_owner_total
rbac_permission_without_enforcement_total
rbac_permission_reconciliation_failure_total
rbac_permission_review_overdue_total
```

---

# 158. KPIs

Initial targets:

```text
Active permissions without owner = 0
Active permissions without description = 0
Active permissions without enforcement point = 0
Role references to retired permissions = 0
Permission collisions = 0
Wildcard permissions outside approved set = 0
Critical permissions without audit = 0
Critical permissions without annual review = 0
```

---

# 159. KRIs

```text
Permission count growth
Broad permission growth
Wildcard usage
Critical permission assignment volume
Deprecated permission usage
Semantic drift
Shadow permissions
Unowned permissions
```

---

# 160. Database Direction

Potential tables:

```text
rbac_permissions
rbac_permission_versions
rbac_permission_aliases
rbac_permission_owners
rbac_permission_scope_models
rbac_permission_bindings
rbac_permission_reviews
rbac_permission_certifications
rbac_permission_reconciliation_runs
rbac_permission_reconciliation_findings
```

---

# 161. Table: rbac_permissions

```sql
CREATE TABLE rbac_permissions (
    id CHAR(26) NOT NULL,
    permission_code VARCHAR(180) NOT NULL,
    name VARCHAR(255) NOT NULL,
    description_text VARCHAR(2000) NOT NULL,
    domain_code VARCHAR(100) NOT NULL,
    resource_code VARCHAR(100) NOT NULL,
    action_code VARCHAR(100) NOT NULL,
    module_code VARCHAR(100) NULL,
    owner_reference VARCHAR(180) NOT NULL,
    risk_tier VARCHAR(30) NOT NULL,
    scope_model VARCHAR(100) NOT NULL,
    audit_level VARCHAR(30) NOT NULL,
    requires_mfa TINYINT(1) NOT NULL DEFAULT 0,
    requires_approval TINYINT(1) NOT NULL DEFAULT 0,
    status VARCHAR(30) NOT NULL,
    introduced_version VARCHAR(100) NOT NULL,
    replacement_permission_code VARCHAR(180) NULL,
    created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    updated_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6)
        ON UPDATE CURRENT_TIMESTAMP(6),

    PRIMARY KEY (id),
    UNIQUE KEY uq_rbac_permission_code (permission_code),
    KEY idx_rbac_permission_domain (
        domain_code,
        status
    ),
    KEY idx_rbac_permission_owner (
        owner_reference,
        status
    ),
    KEY idx_rbac_permission_risk (
        risk_tier,
        status
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

# 162. Table: rbac_permission_versions

```sql
CREATE TABLE rbac_permission_versions (
    id CHAR(26) NOT NULL,
    permission_id CHAR(26) NOT NULL,
    version VARCHAR(100) NOT NULL,
    metadata_json JSON NOT NULL,
    checksum_sha256 CHAR(64) NOT NULL,
    change_type VARCHAR(50) NOT NULL,
    change_reason VARCHAR(1000) NOT NULL,
    approved_by VARCHAR(180) NULL,
    effective_from DATETIME(6) NOT NULL,
    effective_to DATETIME(6) NULL,

    PRIMARY KEY (id),
    UNIQUE KEY uq_rbac_permission_version (
        permission_id,
        version
    ),
    CONSTRAINT fk_rbac_permission_version_permission
        FOREIGN KEY (permission_id)
        REFERENCES rbac_permissions (id)
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

# 163. Table: rbac_permission_aliases

```sql
CREATE TABLE rbac_permission_aliases (
    id CHAR(26) NOT NULL,
    alias_code VARCHAR(180) NOT NULL,
    canonical_permission_id CHAR(26) NOT NULL,
    valid_from DATETIME(6) NOT NULL,
    valid_to DATETIME(6) NOT NULL,
    status VARCHAR(30) NOT NULL,
    reason_text VARCHAR(1000) NOT NULL,

    PRIMARY KEY (id),
    UNIQUE KEY uq_rbac_permission_alias (alias_code),
    CONSTRAINT fk_rbac_permission_alias_canonical
        FOREIGN KEY (canonical_permission_id)
        REFERENCES rbac_permissions (id)
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

# 164. Table: rbac_permission_bindings

```sql
CREATE TABLE rbac_permission_bindings (
    id CHAR(26) NOT NULL,
    permission_id CHAR(26) NOT NULL,
    binding_type VARCHAR(40) NOT NULL,
    binding_reference VARCHAR(500) NOT NULL,
    module_code VARCHAR(100) NULL,
    status VARCHAR(30) NOT NULL,
    metadata_json JSON NULL,

    PRIMARY KEY (id),
    UNIQUE KEY uq_rbac_permission_binding (
        permission_id,
        binding_type,
        binding_reference
    ),
    KEY idx_rbac_binding_reference (
        binding_type,
        binding_reference,
        status
    ),
    CONSTRAINT fk_rbac_binding_permission
        FOREIGN KEY (permission_id)
        REFERENCES rbac_permissions (id)
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

# 165. Table: rbac_permission_reviews

```sql
CREATE TABLE rbac_permission_reviews (
    id CHAR(26) NOT NULL,
    permission_id CHAR(26) NOT NULL,
    review_type VARCHAR(40) NOT NULL,
    reviewer_reference VARCHAR(180) NOT NULL,
    outcome VARCHAR(30) NOT NULL,
    findings_json JSON NULL,
    reviewed_at DATETIME(6) NOT NULL,
    next_review_at DATETIME(6) NULL,

    PRIMARY KEY (id),
    KEY idx_rbac_permission_review_due (
        next_review_at,
        outcome
    ),
    CONSTRAINT fk_rbac_permission_review_permission
        FOREIGN KEY (permission_id)
        REFERENCES rbac_permissions (id)
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

# 166. Table: rbac_permission_reconciliation_runs

```sql
CREATE TABLE rbac_permission_reconciliation_runs (
    id CHAR(26) NOT NULL,
    run_code VARCHAR(100) NOT NULL,
    source_set_json JSON NOT NULL,
    status VARCHAR(30) NOT NULL,
    started_at DATETIME(6) NOT NULL,
    completed_at DATETIME(6) NULL,
    finding_count INT NOT NULL DEFAULT 0,

    PRIMARY KEY (id),
    UNIQUE KEY uq_rbac_permission_reconciliation_run (
        run_code
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

# 167. API Direction

```text
GET  /api/internal/v1/rbac/permissions
POST /api/internal/v1/rbac/permissions
GET  /api/internal/v1/rbac/permissions/{permissionCode}
PATCH /api/internal/v1/rbac/permissions/{permissionCode}
POST /api/internal/v1/rbac/permissions/{permissionCode}/submit
POST /api/internal/v1/rbac/permissions/{permissionCode}/approve
POST /api/internal/v1/rbac/permissions/{permissionCode}/activate
POST /api/internal/v1/rbac/permissions/{permissionCode}/deprecate
POST /api/internal/v1/rbac/permissions/{permissionCode}/retire
POST /api/internal/v1/rbac/permissions/reconcile
GET  /api/internal/v1/rbac/permissions/reconciliation-runs/{runId}
```

---

# 168. SDK Contracts

Potential contracts:

```text
PermissionCatalogInterface
PermissionRegistryInterface
PermissionManifestValidatorInterface
PermissionBindingRegistryInterface
PermissionReconciliationServiceInterface
PermissionCompatibilityCheckerInterface
```

---

# 169. Permission Catalog Contract

```php
interface PermissionCatalogInterface
{
    public function find(string $permissionCode): ?PermissionDefinition;

    public function requireActive(string $permissionCode): PermissionDefinition;

    public function search(PermissionSearchCriteria $criteria): iterable;
}
```

---

# 170. Permission Registry Contract

```php
interface PermissionRegistryInterface
{
    public function register(
        PermissionManifest $manifest
    ): PermissionRegistrationResult;
}
```

---

# 171. Binding Registry Contract

```php
interface PermissionBindingRegistryInterface
{
    public function bind(
        string $permissionCode,
        PermissionBinding $binding
    ): void;

    public function bindingsFor(
        string $permissionCode
    ): iterable;
}
```

---

# 172. Compatibility Checker

```php
interface PermissionCompatibilityCheckerInterface
{
    public function compare(
        PermissionDefinition $current,
        PermissionDefinition $proposed
    ): CompatibilityAssessment;
}
```

---

# 173. Error Codes

```text
RBAC_PERMISSION_NOT_FOUND
RBAC_PERMISSION_INACTIVE
RBAC_PERMISSION_CODE_INVALID
RBAC_PERMISSION_DUPLICATE
RBAC_PERMISSION_COLLISION
RBAC_PERMISSION_OWNER_REQUIRED
RBAC_PERMISSION_SCOPE_INVALID
RBAC_PERMISSION_RISK_INVALID
RBAC_PERMISSION_WILDCARD_FORBIDDEN
RBAC_PERMISSION_BINDING_MISSING
RBAC_PERMISSION_SEMANTIC_CHANGE_FORBIDDEN
RBAC_PERMISSION_DEPRECATION_INVALID
RBAC_PERMISSION_RETIREMENT_BLOCKED
RBAC_PERMISSION_ALIAS_CHAIN_FORBIDDEN
RBAC_PERMISSION_MANIFEST_INVALID
RBAC_PERMISSION_RECONCILIATION_FAILED
```

---

# 174. Proposal Checklist

- [ ] Existing catalog searched.
- [ ] Code follows naming standard.
- [ ] Domain owner identified.
- [ ] Resource and action clear.
- [ ] Description complete.
- [ ] Scope model defined.
- [ ] Risk tier assessed.
- [ ] Data classification assessed.
- [ ] MFA requirement assessed.
- [ ] Audit level defined.
- [ ] Enforcement points identified.
- [ ] Alternatives considered.
- [ ] Duplicate semantics checked.
- [ ] Tests planned.

---

# 175. Review Checklist

- [ ] Meaning is singular.
- [ ] Code is stable.
- [ ] Permission is atomic.
- [ ] Permission is not role-like.
- [ ] Scope is least-privilege.
- [ ] Risk is accurate.
- [ ] Wildcard absent or approved.
- [ ] Owner valid.
- [ ] Route/use-case binding exists.
- [ ] Audit requirement appropriate.
- [ ] Compatibility impact reviewed.
- [ ] Module namespace valid.

---

# 176. Activation Checklist

- [ ] Approved status.
- [ ] Manifest validated.
- [ ] Database registered.
- [ ] Binding registered.
- [ ] Role mappings validated.
- [ ] Policy references validated.
- [ ] Menu references valid.
- [ ] Tests pass.
- [ ] Audit event emitted.
- [ ] Documentation published.

---

# 177. Deprecation Checklist

- [ ] Reason documented.
- [ ] Replacement defined.
- [ ] Consumers identified.
- [ ] Roles identified.
- [ ] Routes identified.
- [ ] Policies identified.
- [ ] Menus identified.
- [ ] Deadline defined.
- [ ] Owner assigned.
- [ ] Migration tested.
- [ ] New usage blocked.

---

# 178. Retirement Checklist

- [ ] No active role references.
- [ ] No active policy references.
- [ ] No active route references.
- [ ] No active menu references.
- [ ] No service references.
- [ ] Alias expired.
- [ ] Migration completed.
- [ ] Reconciliation clean.
- [ ] Evidence retained.
- [ ] Retirement approved.

---

# 179. UAT — Naming & Registration

- [ ] Valid code accepted.
- [ ] Uppercase rejected.
- [ ] Invalid separator rejected.
- [ ] Duplicate code rejected.
- [ ] Duplicate semantics detected.
- [ ] Reserved prefix protected.
- [ ] Module prefix ownership enforced.
- [ ] Missing owner rejected.
- [ ] Invalid action rejected.
- [ ] Invalid scope model rejected.

---

# 180. UAT — Manifest

- [ ] Valid module manifest registers.
- [ ] Invalid checksum rejected.
- [ ] Missing metadata rejected.
- [ ] Same code/same meaning is idempotent.
- [ ] Same code/different meaning blocked.
- [ ] Unknown module rejected.
- [ ] Incompatible version blocked.
- [ ] Registration audited.
- [ ] Rollback works.

---

# 181. UAT — Risk & Scope

- [ ] Low-risk permission approval works.
- [ ] Critical permission requires elevated approval.
- [ ] Global scope requires governance.
- [ ] Clinic-only permission cannot bind tenant-wide.
- [ ] MFA metadata enforced by policy.
- [ ] Audit level used by enforcement.
- [ ] Human-only permission rejects service role.
- [ ] Machine-only permission rejects human role.

---

# 182. UAT — Binding

- [ ] Protected route resolves active permission.
- [ ] Route with missing permission fails gate.
- [ ] Retired permission binding fails.
- [ ] CLI binding validated.
- [ ] Job binding validated.
- [ ] Menu references active permission.
- [ ] UI visibility does not bypass endpoint.
- [ ] API docs show permission requirement.
- [ ] Binding search works.

---

# 183. UAT — Lifecycle

- [ ] Draft cannot be used.
- [ ] Approved can register.
- [ ] Active can map to role.
- [ ] Deprecated remains functional during transition.
- [ ] New role mapping to deprecated permission blocked.
- [ ] Suspended permission denies.
- [ ] Retirement blocked while references exist.
- [ ] Retired permission no longer resolves.
- [ ] History preserved.

---

# 184. UAT — Compatibility & Alias

- [ ] Metadata typo change is non-breaking.
- [ ] Semantic change blocked.
- [ ] Scope expansion triggers review.
- [ ] Scope restriction triggers migration.
- [ ] Alias resolves canonical permission.
- [ ] Alias chain rejected.
- [ ] Alias expiry enforced.
- [ ] New assignments use canonical code.
- [ ] Replacement shown in catalog.

---

# 185. UAT — Reconciliation

- [ ] Missing database permission detected.
- [ ] Missing catalog permission detected.
- [ ] Shadow code reference detected.
- [ ] Orphan role mapping detected.
- [ ] Zombie retired permission detected.
- [ ] Risk drift detected.
- [ ] Owner drift detected.
- [ ] Status drift detected.
- [ ] Report generated.
- [ ] CI fails on critical finding.

---

# 186. UAT — Wildcard & Privileged Permission

- [ ] Wildcard rejected by default.
- [ ] Approved wildcard restricted.
- [ ] Critical wildcard requires strong MFA.
- [ ] Break-glass assignment expires.
- [ ] Impersonation permission separate.
- [ ] Export permission separate from read.
- [ ] Override permission separate.
- [ ] Emergency suspension works.
- [ ] Kill switch audited.

---

# 187. UAT — Security & Audit

- [ ] Unauthorized catalog change denied.
- [ ] Self-approval blocked for critical permission.
- [ ] Changes audited.
- [ ] Owner changes audited.
- [ ] Risk changes audited.
- [ ] Alias creation audited.
- [ ] Retirement audited.
- [ ] Sensitive metadata protected.
- [ ] Correlation ID present.

---

# 188. UAT — Performance

- [ ] Catalog lookup P95 measured.
- [ ] Search by code fast.
- [ ] Search by domain fast.
- [ ] Registration idempotent.
- [ ] Large catalog tested.
- [ ] Reconciliation bounded.
- [ ] Binding lookup cached safely.
- [ ] Cache invalidated on lifecycle change.

---

# 189. Definition of Done — SSOT-RBAC-06

SSOT-RBAC-06 dianggap selesai bila:

- [ ] permission definition tersedia;
- [ ] naming standard tersedia;
- [ ] domain/resource/action rules tersedia;
- [ ] metadata standard tersedia;
- [ ] owner model tersedia;
- [ ] risk classification tersedia;
- [ ] scope applicability tersedia;
- [ ] subject-type applicability tersedia;
- [ ] wildcard governance tersedia;
- [ ] manifest model tersedia;
- [ ] registration flow tersedia;
- [ ] namespace ownership tersedia;
- [ ] collision detection tersedia;
- [ ] seed/migration governance tersedia;
- [ ] compatibility model tersedia;
- [ ] alias/deprecation/retirement tersedia;
- [ ] route/action/menu binding tersedia;
- [ ] reconciliation tersedia;
- [ ] review/certification tersedia;
- [ ] privileged permission controls tersedia;
- [ ] audit/logging/metrics tersedia;
- [ ] database direction tersedia;
- [ ] API direction tersedia;
- [ ] SDK contracts tersedia;
- [ ] error codes tersedia;
- [ ] checklists dan UAT tersedia.

---

# 190. Implementation Roadmap

## Phase 1 — Catalog Foundation

- canonical permission schema;
- naming validator;
- owner registry;
- risk and scope metadata;
- catalog search;
- basic API.

## Phase 2 — Module Registration

- manifest schema;
- manifest validator;
- namespace ownership;
- collision detection;
- idempotent registration;
- module activation gate.

## Phase 3 — Binding & Enforcement Integration

- route binding;
- use-case binding;
- CLI/job binding;
- menu references;
- API documentation;
- enforcement-point validation.

## Phase 4 — Lifecycle & Compatibility

- deprecation;
- alias;
- replacement;
- compatibility checker;
- retirement gate;
- migration tooling.

## Phase 5 — Reconciliation & Certification

- source scanners;
- database reconciliation;
- orphan/shadow/zombie detection;
- dashboards;
- periodic certification;
- CI/CD quality gates.

---

# 191. Initial Implementation Backlog

```text
RBACC-001 Permission Catalog Schema
RBACC-002 Permission Naming Validator
RBACC-003 Permission Owner Registry
RBACC-004 Permission Risk Classifier
RBACC-005 Permission Scope Model
RBACC-006 Permission Manifest Schema
RBACC-007 Manifest Validator
RBACC-008 Namespace Ownership Registry
RBACC-009 Collision Detector
RBACC-010 Permission Registration Service
RBACC-011 Permission Binding Registry
RBACC-012 Route Binding Scanner
RBACC-013 Menu/Policy Reference Scanner
RBACC-014 Compatibility Checker
RBACC-015 Alias & Deprecation Service
RBACC-016 Retirement Gate
RBACC-017 Reconciliation Engine
RBACC-018 Catalog Dashboard
```

---

# 192. Approval Gate

Dokumen dapat menjadi Approved setelah:

- Platform Architecture review;
- RBAC Owner review;
- IAM review;
- Scope Architecture review;
- Security review;
- Audit review;
- Module SDK review;
- API review;
- Data Governance review;
- Operations review;
- developer experience review.

---

# 193. Closing Statement

Permission catalog harus memastikan bahwa setiap authorization capability:

- memiliki kode yang stabil;
- memiliki satu makna;
- memiliki owner;
- memiliki scope;
- memiliki risk tier;
- memiliki enforcement point;
- memiliki lifecycle;
- dapat diuji;
- dapat direview;
- dapat didepresiasi;
- dapat direkonsiliasi;
- dapat diaudit.

Permission bukan label UI dan bukan jabatan.

Permission adalah kontrak authorization atomik antara business capability, policy engine, enforcement point, role model, dan audit evidence.
