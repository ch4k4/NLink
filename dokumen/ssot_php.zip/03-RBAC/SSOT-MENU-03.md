# SSOT-MENU-03 — Menu Projection by Role, Scope & Feature Flag

---

## Status Dokumen

| Item | Nilai |
|---|---|
| Kode | SSOT-MENU-03 |
| Judul | Menu Projection by Role, Scope & Feature Flag |
| Versi | 1.0 |
| Status | Draft Architecture |
| Domain | Platform Kernel |
| Kategori | Navigation Projection, Authorization Projection & Runtime Personalization |
| Cakupan | User Menu Projection, Effective Permission, Active Scope, Feature Flag, Tenant Capability, Module Status, Device Context, Caching, Reconciliation |
| Bergantung pada | SSOT-SCOPE-01, SSOT-SCOPE-02, SSOT-SCOPE-04, SSOT-IAM-01, SSOT-IAM-03, SSOT-IAM-06, SSOT-RBAC-04, SSOT-RBAC-05, SSOT-RBAC-06, SSOT-MENU-01, SSOT-MENU-02, SSOT-OBS-01 |
| Target Stack | PHP 8.1+, Composer, PSR-4, PDO, MySQL 8/MariaDB, HTML5, CSS3, Vanilla JavaScript |
| Target Evolusi | Server-Driven Navigation, Multi-Tenant Projection, Policy Decision Integration, Microfrontend-ready |

---

# 1. Executive Summary

SSOT-MENU-03 menetapkan arsitektur resmi untuk memproyeksikan menu final kepada user atau service-facing workspace berdasarkan registry yang telah disahkan.

Dokumen ini mengatur:

- menu projection request;
- trusted user context;
- effective role dan permission;
- active tenant, organization, clinic, department, dan resource scope;
- feature flags;
- tenant capabilities;
- module activation;
- industry pack;
- locale;
- device form factor;
- workspace;
- visibility rules;
- ancestor retention;
- disabled versus hidden behavior;
- badge projection;
- ordering;
- personalization;
- cache dan invalidation;
- projection versioning;
- consistency dengan authorization engine;
- observability;
- database direction;
- API direction;
- SDK contracts;
- UAT;
- Definition of Done;
- implementation roadmap.

Tujuan akhirnya adalah memastikan menu yang diterima user:

- hanya berasal dari registry aktif;
- sesuai permission efektif;
- sesuai scope aktif;
- sesuai feature flag dan tenant capability;
- tidak menampilkan module yang tidak aktif;
- tersusun deterministic;
- tidak menjadi pengganti server-side authorization;
- dapat di-cache dengan aman;
- dapat dijelaskan;
- dapat direkonsiliasi;
- dapat diaudit.

---

# 2. Objectives

Projection engine harus:

- menghasilkan menu final yang deterministic;
- menggunakan trusted authorization context;
- menjaga tenant isolation;
- mendukung role dan permission projection;
- mendukung active scope;
- mendukung feature flag dan module state;
- mendukung responsive navigation;
- mendukung personalization tanpa mengubah authorization;
- menjaga cache consistency;
- menyediakan explainability dan audit.

---

# 3. Core Principles

```text
Registry Defines Availability
Authorization Defines Eligibility
Scope Defines Applicability
Feature Flags Define Enablement
Tenant Capability Defines Entitlement
Projection Never Grants Access
Hidden Menu Is Not a Security Control
Parent Visibility Follows Eligible Descendants
Projection Must Be Deterministic
Every Projection Must Be Traceable
```

---

# 4. Scope

Framework berlaku untuk:

```text
Primary Sidebar
Top Navigation
Mobile Navigation
Workspace Navigation
Module Navigation
Administration Navigation
Context Actions
Quick Actions
Favorites
Tenant-Specific Navigation
Industry-Specific Navigation
```

---

# 5. Non-Scope

Dokumen ini tidak mengatur secara rinci:

- canonical menu registration;
- permission catalog lifecycle;
- server-side authorization decision internals;
- page design system;
- business transaction authorization.

---

# 6. Projection Architecture

```text
Canonical Menu Registry
        │
        ├── User/Subject Context
        ├── Effective Permissions
        ├── Active Scope
        ├── Module Status
        ├── Tenant Capabilities
        ├── Feature Flags
        ├── Industry Pack
        ├── Locale
        ├── Device Context
        └── User Personalization
        │
        ▼
Menu Projection Engine
        │
        ├── Eligibility Evaluation
        ├── Ancestor Retention
        ├── Ordering
        ├── Label/Icon Resolution
        ├── Badge Resolution
        └── Snapshot Generation
        │
        ▼
Projected Menu Snapshot
```

---

# 7. Projection Inputs

Minimum inputs:

```text
subject_id
subject_type
tenant_id
active_scope
session_id
authentication_assurance
registry_version
permission_version
feature_flag_version
module_state_version
locale
device_class
workspace
```

---

# 8. Trusted Context

Context harus berasal dari:

- authenticated session;
- server-side scope resolver;
- permission decision service;
- tenant capability service;
- feature flag service;
- module registry;
- approved personalization store.

---

# 9. Untrusted Context

Tidak boleh mempercayai langsung:

- role dari JavaScript;
- permission dari hidden input;
- tenant dari query string;
- clinic dari local storage;
- feature flag dari client;
- menu code buatan client.

---

# 10. Projection Request Contract

```php
final readonly class MenuProjectionRequest
{
    public function __construct(
        public SubjectContext $subject,
        public ScopeContext $scope,
        public string $workspace,
        public string $locale,
        public string $deviceClass,
        public string $registryVersion,
    ) {
    }
}
```

---

# 11. Projection Context

```php
final readonly class MenuProjectionContext
{
    public function __construct(
        public array $effectivePermissions,
        public array $tenantCapabilities,
        public array $featureFlags,
        public array $activeModules,
        public array $industryPacks,
        public array $personalization,
    ) {
    }
}
```

---

# 12. Projection Result

```php
final readonly class ProjectedMenuSnapshot
{
    public function __construct(
        public string $projectionId,
        public string $registryVersion,
        public string $contextVersion,
        public array $nodes,
        public string $checksum,
        public \DateTimeImmutable $generatedAt,
        public \DateTimeImmutable $expiresAt,
    ) {
    }
}
```

---

# 13. Eligibility Model

Node eligible bila seluruh mandatory dimensions terpenuhi:

```text
Registry Active
AND Source Module Active
AND Tenant Capability Eligible
AND Feature Flag Eligible
AND Scope Applicable
AND Permission Expression Satisfied
AND Workspace Applicable
AND Device Policy Eligible
AND Lifecycle Valid
```

---

# 14. Projection Decision

```text
VISIBLE
HIDDEN
DISABLED
NOT_APPLICABLE
INDETERMINATE
```

---

# 15. Default Behavior

Untuk node protected:

```text
NOT_APPLICABLE → HIDDEN
INDETERMINATE → HIDDEN
```

---

# 16. Visible

Node dapat ditampilkan dan digunakan untuk navigasi.

---

# 17. Hidden

Node tidak dikirim atau tidak dirender kepada user.

---

# 18. Disabled

Node dapat terlihat tetapi tidak dapat digunakan.

Disabled state hanya digunakan untuk UX yang jelas, bukan security enforcement.

---

# 19. Not Applicable

Node tidak relevan untuk context aktif.

---

# 20. Indeterminate

Projection tidak dapat mengevaluasi secara andal.

Fail closed dengan menyembunyikan node protected.

---

# 21. Permission Projection

Permission projection harus memakai effective permission yang berasal dari authorization layer.

---

# 22. Role Projection

Role dapat digunakan sebagai metadata atau optimization, tetapi permission efektif tetap menjadi dasar utama.

---

# 23. Role-Only Visibility

Role-only menu rule tidak direkomendasikan kecuali role tersebut merupakan stable platform contract.

---

# 24. Permission Modes

```text
ANY_OF
ALL_OF
NONE_OF
PUBLIC
```

---

# 25. ANY_OF

Node visible jika minimal satu permission aktif terpenuhi.

---

# 26. ALL_OF

Node visible jika seluruh permission terpenuhi.

---

# 27. NONE_OF

Dapat digunakan untuk explicit exclusion yang disetujui, tetapi tidak boleh menggantikan deny policy.

---

# 28. PUBLIC

Hanya untuk menu yang benar-benar public atau authenticated-without-permission.

---

# 29. Permission Validation

Semua permission harus active di canonical catalog.

---

# 30. Permission Evaluation Consistency

Projection permission result harus konsisten dengan PDP/authorization service pada policy version yang sama.

---

# 31. Scope Projection

Scope projection memakai active scope yang telah tervalidasi.

---

# 32. Scope Types

```text
GLOBAL
TENANT
ORGANIZATION
CLINIC
DEPARTMENT
RESOURCE_CONTEXT
SELF
```

---

# 33. Active Scope

Interactive user session harus memiliki active scope yang eksplisit bila platform multi-organization atau multi-clinic.

---

# 34. Scope Switching

Saat scope berubah:

- authorization context diperbarui;
- menu projection diulang;
- cache lama tidak digunakan;
- badge di-refresh;
- route context diverifikasi.

---

# 35. Cross-Tenant Protection

Projection cache dan result tidak boleh dibagikan lintas tenant.

---

# 36. Parent Scope Applicability

Node tenant-level dapat tetap visible saat active scope adalah clinic jika policy menyatakan downward applicability.

---

# 37. Resource Context Menu

Resource-specific actions hanya diproyeksikan bila resource context trusted tersedia.

---

# 38. Feature Flag Projection

Feature flag dapat menentukan:

```text
ENABLED
DISABLED
ROLLOUT
TARGETED
EXPERIMENTAL
```

---

# 39. Feature Flag Rule

Feature flag tidak pernah memberikan permission.

---

# 40. Targeted Rollout

Target dapat didasarkan pada:

- tenant;
- user cohort;
- industry;
- environment;
- percentage bucket;
- explicit allowlist.

---

# 41. Stable Bucketing

Percentage rollout harus menggunakan stable deterministic bucketing.

---

# 42. Feature Flag Failure

Protected feature harus fail closed saat flag service tidak dapat menentukan state.

---

# 43. Module Status

Menu node hanya eligible bila owning module berstatus:

```text
ACTIVE
```

atau status lain yang secara eksplisit diperbolehkan.

---

# 44. Module Status Values

```text
INSTALLED
ACTIVE
SUSPENDED
DISABLED
DEPRECATED
UNINSTALLED
```

---

# 45. Suspended Module

Seluruh menu contribution module harus hilang atau disabled sesuai policy.

---

# 46. Tenant Capability

Tenant capability merepresentasikan entitlement atau capability yang aktif untuk tenant.

---

# 47. Capability Examples

```text
HOMECARE_ENABLED
WOUNDCARE_ENABLED
BILLING_ENABLED
ADVANCED_REPORTING_ENABLED
```

---

# 48. Entitlement Boundary

Tenant capability bukan permission user.

Eligibility membutuhkan capability dan permission bila keduanya disyaratkan.

---

# 49. Industry Pack

Industry pack dapat menentukan default workspace, section, label, dan applicable nodes.

---

# 50. Industry Pack Priority

Platform guardrails tetap mengungguli industry pack.

---

# 51. Workspace Projection

Workspace values dapat meliputi:

```text
DEFAULT
CLINICAL
OPERATIONS
FINANCE
ADMINISTRATION
SECURITY
MOBILE
```

---

# 52. Workspace Eligibility

Node dapat tersedia pada satu atau lebih workspace.

---

# 53. Workspace Switching

Workspace switching tidak boleh mengubah permission atau scope.

---

# 54. Device Context

Device classes:

```text
DESKTOP
TABLET
MOBILE
EMBEDDED
```

---

# 55. Device Projection

Device context hanya mengubah presentation dan prioritization, bukan authorization.

---

# 56. Mobile Priority

Node penting dapat ditandai:

```text
PRIMARY
SECONDARY
OVERFLOW
HIDDEN_ON_MOBILE
```

---

# 57. Ancestor Retention

Parent node tetap diproyeksikan bila memiliki descendant eligible.

---

# 58. Empty Parent

Parent non-navigable tanpa child eligible harus disembunyikan.

---

# 59. Navigable Parent

Parent dengan route sendiri dapat tetap visible bila memenuhi eligibility meskipun tidak memiliki child eligible.

---

# 60. Separator Projection

Separator hanya diproyeksikan bila memiliki visible sibling sebelum dan sesudahnya.

---

# 61. Section Projection

Empty section harus disembunyikan.

---

# 62. Ordering

Projected ordering harus mengikuti registry order setelah override yang sah.

---

# 63. Deterministic Ordering

Tie-breaking:

```text
order_weight
→ label_key
→ menu_code
```

---

# 64. Tenant Override

Tenant override dapat memengaruhi:

- ordering;
- hidden preference dalam guardrail;
- label override;
- default workspace;
- grouping.

---

# 65. Tenant Override Restrictions

Tenant override tidak boleh:

- menambah permission;
- mengganti route ke route lain;
- membuka module inactive;
- melewati feature flag mandatory;
- mengubah platform guardrail;
- membuat cross-tenant reference.

---

# 66. User Personalization

User personalization dapat meliputi:

```text
favorites
collapsed_sections
pinned_items
recent_items
default_workspace
```

---

# 67. Personalization Boundary

Personalization hanya memengaruhi presentation.

---

# 68. Favorite Eligibility

Favorite yang tidak lagi eligible harus dihapus dari projection atau ditandai unavailable.

---

# 69. Stale Personalization

Registry reconciliation harus mendeteksi personalization yang merujuk menu retired.

---

# 70. Badge Projection

Badge harus dievaluasi setelah node eligible.

---

# 71. Badge Authorization

Badge query harus memakai permission dan scope yang sama atau lebih ketat dari destination.

---

# 72. Badge States

```text
COUNT
DOT
STATUS
NONE
```

---

# 73. Badge Failure

Badge failure tidak boleh menggagalkan seluruh menu projection.

---

# 74. Badge Timeout

Badge provider harus memiliki timeout pendek dan bounded.

---

# 75. Projection Pipeline

```text
Load Registry Snapshot
→ Validate Context Versions
→ Filter Lifecycle
→ Filter Module State
→ Filter Tenant Capability
→ Filter Industry/Workspace
→ Evaluate Feature Flags
→ Evaluate Scope
→ Evaluate Permission Expression
→ Retain Ancestors
→ Apply Tenant Overrides
→ Apply Personalization
→ Resolve Labels/Icons
→ Resolve Badges
→ Sort
→ Build Snapshot
```

---

# 76. Evaluation Order Rationale

Filter murah dan global dilakukan lebih awal untuk mengurangi authorization checks yang tidak perlu.

---

# 77. Projection Engine Contract

```php
interface MenuProjectionEngineInterface
{
    public function project(
        MenuProjectionRequest $request
    ): ProjectedMenuSnapshot;
}
```

---

# 78. Eligibility Evaluator Contract

```php
interface MenuEligibilityEvaluatorInterface
{
    public function evaluate(
        MenuDefinition $menu,
        MenuProjectionContext $context
    ): MenuEligibilityDecision;
}
```

---

# 79. Feature Flag Resolver Contract

```php
interface MenuFeatureFlagResolverInterface
{
    public function isEnabled(
        string $flagCode,
        FeatureFlagContext $context
    ): bool;
}
```

---

# 80. Scope Applicability Contract

```php
interface MenuScopeApplicabilityInterface
{
    public function applies(
        MenuDefinition $menu,
        ScopeContext $scope
    ): bool;
}
```

---

# 81. Projection Explanation

Internal explanation dapat memuat:

```text
menu_code
final_decision
matched_permission
failed_condition
scope_result
feature_flag_result
module_result
ancestor_reason
```

---

# 82. Client Payload

Client hanya menerima data yang diperlukan untuk render.

---

# 83. Example Payload

```json
{
  "data": {
    "projection_id": "01J...",
    "registry_version": "2026.07.001",
    "nodes": [
      {
        "code": "homecare.visits.list",
        "type": "ITEM",
        "label": "Kunjungan Homecare",
        "route": "homecare.visits.index",
        "icon": "calendar-home",
        "children": []
      }
    ]
  },
  "meta": {
    "scope": "clinic:01C...",
    "checksum": "..."
  }
}
```

---

# 84. Sensitive Metadata

Client payload tidak perlu memuat:

- hidden permissions;
- denied role list;
- internal reason codes;
- policy internals;
- other tenant configuration.

---

# 85. Projection Cache

Projection snapshot dapat di-cache.

---

# 86. Cache Key

Minimum:

```text
subject_id
tenant_id
active_scope
workspace
locale
device_class
registry_version
assignment_version
permission_version
feature_flag_version
module_state_version
tenant_capability_version
personalization_version
```

---

# 87. Cache Isolation

Cache harus terisolasi per tenant dan subject.

---

# 88. Cache TTL

TTL dapat singkat hingga menengah, tetapi tidak boleh memperlambat critical revocation.

---

# 89. Cache Invalidation

Invalidate saat:

- role assignment berubah;
- permission berubah;
- scope berubah;
- user status berubah;
- registry publish;
- module state berubah;
- feature flag berubah;
- tenant capability berubah;
- tenant override berubah;
- personalization berubah.

---

# 90. Critical Revocation

Critical access revocation harus menginvalidasi projection segera.

---

# 91. ETag

Projected snapshot dapat menggunakan ETag berbasis checksum.

---

# 92. Conditional Fetch

Client dapat menggunakan `If-None-Match`.

---

# 93. Stale-While-Revalidate

Hanya untuk low-risk presentation dan tidak boleh mempertahankan sensitive menu setelah revocation.

---

# 94. Projection Version

Projection version menggabungkan registry dan context versions.

---

# 95. Projection Checksum

Checksum harus deterministic terhadap payload canonical.

---

# 96. Concurrency

Concurrent projection requests untuk key sama dapat menggunakan request coalescing.

---

# 97. Performance Targets

Initial targets:

```text
P95 cached projection <= 50 ms
P95 uncached projection <= 200 ms
P99 uncached projection <= 500 ms
```

Target harus diuji pada environment nyata.

---

# 98. Large Menu Registry

Projection harus diuji pada ribuan nodes dan ratusan permissions.

---

# 99. N+1 Prevention

Permission, flags, capabilities, and badge queries harus dibatch.

---

# 100. Resilience

Projection failure tidak boleh menghasilkan menu yang lebih luas dari seharusnya.

---

# 101. Authorization Service Failure

Protected menu nodes fail closed.

---

# 102. Feature Flag Service Failure

Mandatory feature-gated nodes fail closed.

---

# 103. Badge Service Failure

Menu tetap diproyeksikan tanpa badge.

---

# 104. Translation Failure

Gunakan fallback key/label yang aman dan emit finding.

---

# 105. Module Registry Failure

Tidak boleh menganggap semua modules aktif.

---

# 106. Observability Logs

Structured logs:

```text
projection_id
subject_id_hash
tenant_id
active_scope
registry_version
node_count_before
node_count_after
cache_hit
duration_ms
result
correlation_id
```

---

# 107. Audit Events

```text
MENU_PROJECTION_GENERATED
MENU_PROJECTION_CACHE_INVALIDATED
MENU_PROJECTION_FAILED
MENU_PROJECTION_SCOPE_CHANGED
MENU_PROJECTION_FEATURE_FLAG_CHANGED
MENU_PROJECTION_TENANT_OVERRIDE_APPLIED
MENU_PROJECTION_PERSONALIZATION_APPLIED
```

---

# 108. Audit Boundary

Tidak semua projection request perlu full compliance audit; sensitive administrative projection dan configuration changes wajib diaudit.

---

# 109. Metrics

```text
menu_projection_total
menu_projection_failure_total
menu_projection_duration_seconds
menu_projection_cache_hit_ratio
menu_projection_node_count
menu_projection_hidden_node_total
menu_projection_indeterminate_total
menu_projection_badge_failure_total
menu_projection_invalidation_total
```

---

# 110. KPIs

```text
Cross-tenant projection leakage = 0
Protected nodes visible without permission = 0
Inactive module nodes visible = 0
Disabled mandatory feature nodes visible = 0
Critical revocation stale projection incidents = 0
Projection without registry version = 0
```

---

# 111. KRIs

```text
Projection failure spikes
Indeterminate eligibility growth
Cache invalidation backlog
Node-count anomalies
Feature flag mismatch
Permission/projection drift
Badge latency growth
Cross-scope projection attempts
```

---

# 112. Database Direction

Potential tables:

```text
menu_projection_snapshots
menu_projection_context_versions
menu_projection_cache_invalidations
menu_user_personalizations
menu_user_favorites
menu_projection_audit_links
menu_projection_reconciliation_runs
menu_projection_reconciliation_findings
```

---

# 113. Table: menu_projection_snapshots

```sql
CREATE TABLE menu_projection_snapshots (
    id CHAR(26) NOT NULL,
    projection_code VARCHAR(100) NOT NULL,
    subject_id CHAR(26) NOT NULL,
    tenant_id CHAR(26) NOT NULL,
    scope_type VARCHAR(30) NOT NULL,
    scope_id CHAR(26) NOT NULL,
    workspace_code VARCHAR(100) NOT NULL,
    locale_code VARCHAR(20) NOT NULL,
    device_class VARCHAR(30) NOT NULL,
    registry_version VARCHAR(100) NOT NULL,
    context_version VARCHAR(255) NOT NULL,
    checksum_sha256 CHAR(64) NOT NULL,
    snapshot_json JSON NOT NULL,
    generated_at DATETIME(6) NOT NULL,
    expires_at DATETIME(6) NOT NULL,

    PRIMARY KEY (id),
    UNIQUE KEY uq_menu_projection_code (projection_code),
    KEY idx_menu_projection_subject (
        tenant_id,
        subject_id,
        generated_at
    ),
    KEY idx_menu_projection_expiry (
        expires_at
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

# 114. Table: menu_user_personalizations

```sql
CREATE TABLE menu_user_personalizations (
    id CHAR(26) NOT NULL,
    subject_id CHAR(26) NOT NULL,
    tenant_id CHAR(26) NOT NULL,
    workspace_code VARCHAR(100) NOT NULL,
    personalization_json JSON NOT NULL,
    version BIGINT UNSIGNED NOT NULL DEFAULT 1,
    updated_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6)
        ON UPDATE CURRENT_TIMESTAMP(6),

    PRIMARY KEY (id),
    UNIQUE KEY uq_menu_personalization (
        tenant_id,
        subject_id,
        workspace_code
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

# 115. Table: menu_user_favorites

```sql
CREATE TABLE menu_user_favorites (
    id CHAR(26) NOT NULL,
    subject_id CHAR(26) NOT NULL,
    tenant_id CHAR(26) NOT NULL,
    menu_code VARCHAR(180) NOT NULL,
    order_weight INT NOT NULL DEFAULT 100,
    status VARCHAR(30) NOT NULL,
    created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),

    PRIMARY KEY (id),
    UNIQUE KEY uq_menu_user_favorite (
        tenant_id,
        subject_id,
        menu_code
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

# 116. Table: menu_projection_cache_invalidations

```sql
CREATE TABLE menu_projection_cache_invalidations (
    id CHAR(26) NOT NULL,
    invalidation_code VARCHAR(100) NOT NULL,
    tenant_id CHAR(26) NULL,
    subject_id CHAR(26) NULL,
    scope_type VARCHAR(30) NULL,
    scope_id CHAR(26) NULL,
    reason_code VARCHAR(100) NOT NULL,
    source_version VARCHAR(255) NULL,
    status VARCHAR(30) NOT NULL,
    requested_at DATETIME(6) NOT NULL,
    completed_at DATETIME(6) NULL,

    PRIMARY KEY (id),
    UNIQUE KEY uq_menu_projection_invalidation (
        invalidation_code
    ),
    KEY idx_menu_invalidation_status (
        status,
        requested_at
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

# 117. API Direction

```text
GET  /api/internal/v1/menu/projection
GET  /api/internal/v1/menu/projection/explain/{menuCode}
POST /api/internal/v1/menu/projection/invalidate
GET  /api/internal/v1/menu/personalization
PUT  /api/internal/v1/menu/personalization
GET  /api/internal/v1/menu/favorites
POST /api/internal/v1/menu/favorites
DELETE /api/internal/v1/menu/favorites/{menuCode}
POST /api/internal/v1/menu/projection/reconcile
```

---

# 118. Error Codes

```text
MENU_PROJECTION_CONTEXT_INVALID
MENU_PROJECTION_SUBJECT_INACTIVE
MENU_PROJECTION_SCOPE_INVALID
MENU_PROJECTION_TENANT_MISMATCH
MENU_PROJECTION_REGISTRY_UNAVAILABLE
MENU_PROJECTION_PERMISSION_UNAVAILABLE
MENU_PROJECTION_FEATURE_FLAG_UNAVAILABLE
MENU_PROJECTION_MODULE_STATE_UNAVAILABLE
MENU_PROJECTION_INDETERMINATE
MENU_PROJECTION_CACHE_STALE
MENU_PROJECTION_PERSONALIZATION_INVALID
MENU_PROJECTION_FAVORITE_NOT_ELIGIBLE
MENU_PROJECTION_GENERATION_FAILED
```

---

# 119. Projection Checklist

- [ ] Subject active.
- [ ] Tenant resolved.
- [ ] Active scope trusted.
- [ ] Registry version active.
- [ ] Effective permissions loaded.
- [ ] Module states loaded.
- [ ] Tenant capabilities loaded.
- [ ] Feature flags loaded.
- [ ] Workspace valid.
- [ ] Locale valid.
- [ ] Device class valid.
- [ ] Cache key complete.
- [ ] Projection checksum generated.

---

# 120. Cache Checklist

- [ ] Subject included.
- [ ] Tenant included.
- [ ] Scope included.
- [ ] Registry version included.
- [ ] Permission version included.
- [ ] Feature version included.
- [ ] Module version included.
- [ ] Capability version included.
- [ ] Personalization version included.
- [ ] Critical invalidation tested.
- [ ] ETag generated.

---

# 121. UAT — Permission Projection

- [ ] User with permission sees node.
- [ ] User without permission does not see node.
- [ ] `ANY_OF` works.
- [ ] `ALL_OF` works.
- [ ] Retired permission hides node.
- [ ] Role change invalidates projection.
- [ ] Deny remains enforced by endpoint.
- [ ] Hidden menu cannot authorize direct URL.
- [ ] Permission/projection version matches.

---

# 122. UAT — Scope Projection

- [ ] Tenant menu projects at tenant scope.
- [ ] Clinic menu projects only for valid clinic.
- [ ] Cross-tenant scope rejected.
- [ ] Scope switch regenerates menu.
- [ ] Parent-to-child applicability works.
- [ ] Resource context action requires trusted resource.
- [ ] Unknown scope fails closed.
- [ ] Cache isolated per scope.

---

# 123. UAT — Feature Flag & Capability

- [ ] Enabled flag shows eligible node.
- [ ] Disabled flag hides node.
- [ ] Targeted rollout deterministic.
- [ ] Flag failure hides mandatory node.
- [ ] Tenant capability required.
- [ ] Capability absence hides node.
- [ ] Capability cannot replace permission.
- [ ] Flag change invalidates projection.

---

# 124. UAT — Module & Industry

- [ ] Active module nodes project.
- [ ] Suspended module nodes disappear.
- [ ] Deprecated module follows policy.
- [ ] Industry pack applies correct workspace.
- [ ] General pack fallback works.
- [ ] Tenant cannot expose inactive module.
- [ ] Module state change invalidates cache.

---

# 125. UAT — Hierarchy & Ordering

- [ ] Parent retained for eligible child.
- [ ] Empty parent hidden.
- [ ] Empty section hidden.
- [ ] Separator cleanup works.
- [ ] Navigable parent remains when eligible.
- [ ] Ordering deterministic.
- [ ] Tenant reorder obeys guardrail.
- [ ] Duplicate order ties resolve consistently.

---

# 126. UAT — Personalization

- [ ] Favorite eligible node appears.
- [ ] Ineligible favorite hidden/unavailable.
- [ ] Retired favorite reconciled.
- [ ] Collapsed sections persist.
- [ ] Default workspace persists.
- [ ] Personalization cannot change permission.
- [ ] Cross-tenant personalization rejected.
- [ ] Update increments version.

---

# 127. UAT — Badge

- [ ] Badge count respects scope.
- [ ] Badge requires eligible node.
- [ ] Badge failure does not break menu.
- [ ] Badge timeout bounded.
- [ ] Unauthorized count not exposed.
- [ ] Badge cache invalidates appropriately.
- [ ] Mobile badge projection works.

---

# 128. UAT — Cache & Invalidation

- [ ] Cached snapshot returned for same context.
- [ ] ETag returns 304 when unchanged.
- [ ] Role change invalidates cache.
- [ ] Scope switch invalidates cache.
- [ ] Registry publish invalidates cache.
- [ ] Feature flag change invalidates cache.
- [ ] Tenant capability change invalidates cache.
- [ ] Critical revocation removes node immediately.
- [ ] Cache never crosses tenant.

---

# 129. UAT — Resilience

- [ ] Permission service failure hides protected nodes.
- [ ] Feature service failure hides mandatory nodes.
- [ ] Module service failure does not assume active.
- [ ] Badge failure degrades gracefully.
- [ ] Translation fallback works.
- [ ] Projection timeout bounded.
- [ ] Stale snapshot policy is risk-aware.
- [ ] Failure emits metric and correlation ID.

---

# 130. UAT — Performance

- [ ] Cached P95 measured.
- [ ] Uncached P95 measured.
- [ ] Large registry tested.
- [ ] Large permission set tested.
- [ ] N+1 queries absent.
- [ ] Badge queries batched.
- [ ] Concurrent requests coalesced.
- [ ] Snapshot checksum deterministic.

---

# 131. UAT — Security & Audit

- [ ] Client role spoofing ignored.
- [ ] Client tenant spoofing ignored.
- [ ] Hidden permission metadata not exposed.
- [ ] Direct URL remains server-authorized.
- [ ] Cross-tenant leakage absent.
- [ ] Sensitive admin projection auditable.
- [ ] Invalidation events auditable.
- [ ] Correlation ID retained.

---

# 132. Reconciliation

Projection reconciliation membandingkan:

- registry node;
- active permissions;
- active modules;
- feature flags;
- tenant capabilities;
- scope model;
- tenant overrides;
- personalization;
- generated snapshots.

---

# 133. Reconciliation Findings

```text
STALE_PROJECTION
MISSING_PERMISSION_VERSION
MISSING_MODULE_VERSION
INVALID_SCOPE_REFERENCE
INELIGIBLE_FAVORITE
ORPHAN_PERSONALIZATION
FEATURE_FLAG_DRIFT
TENANT_CAPABILITY_DRIFT
CHECKSUM_MISMATCH
CROSS_TENANT_CACHE_KEY
```

---

# 134. Reconciliation Frequency

- after registry publish;
- after bulk RBAC changes;
- nightly/weekly;
- after module activation change;
- after tenant capability change;
- after major feature flag rollout.

---

# 135. Definition of Done — SSOT-MENU-03

SSOT-MENU-03 dianggap selesai bila:

- [ ] projection architecture tersedia;
- [ ] trusted input model tersedia;
- [ ] projection request/result contracts tersedia;
- [ ] eligibility model tersedia;
- [ ] permission projection tersedia;
- [ ] scope projection tersedia;
- [ ] feature flag projection tersedia;
- [ ] module and tenant capability projection tersedia;
- [ ] industry/workspace/device projection tersedia;
- [ ] ancestor retention tersedia;
- [ ] ordering tersedia;
- [ ] tenant override boundaries tersedia;
- [ ] personalization tersedia;
- [ ] badge projection tersedia;
- [ ] pipeline tersedia;
- [ ] explanation tersedia;
- [ ] client payload boundary tersedia;
- [ ] cache and invalidation tersedia;
- [ ] resilience tersedia;
- [ ] audit/logging/metrics tersedia;
- [ ] database direction tersedia;
- [ ] API direction tersedia;
- [ ] SDK contracts tersedia;
- [ ] error codes tersedia;
- [ ] reconciliation tersedia;
- [ ] checklists dan UAT tersedia.

---

# 136. Implementation Roadmap

## Phase 1 — Projection Foundation

- projection request/context;
- registry snapshot loader;
- permission eligibility;
- scope applicability;
- deterministic tree builder;
- basic API.

## Phase 2 — Feature & Tenant Projection

- feature flag resolver;
- tenant capabilities;
- module state;
- industry packs;
- workspaces;
- device metadata.

## Phase 3 — Cache & Personalization

- projection cache;
- versioned cache key;
- invalidation events;
- ETag;
- favorites;
- collapsed sections;
- default workspace.

## Phase 4 — Badge, Explainability & Reconciliation

- badge providers;
- explanation endpoint;
- reconciliation engine;
- projection findings;
- dashboards;
- performance tuning.

## Phase 5 — Distributed Projection

- signed projection snapshots;
- remote module contexts;
- microfrontend navigation;
- edge cache;
- continuous authorization-aware invalidation;
- cross-application workspace projection.

---

# 137. Initial Implementation Backlog

```text
MENUP-001 Projection Request & Context
MENUP-002 Registry Snapshot Loader
MENUP-003 Permission Eligibility Evaluator
MENUP-004 Scope Applicability Evaluator
MENUP-005 Feature Flag Resolver
MENUP-006 Tenant Capability Resolver
MENUP-007 Module State Resolver
MENUP-008 Ancestor Retention Builder
MENUP-009 Deterministic Ordering
MENUP-010 Projection Snapshot Builder
MENUP-011 Projection Cache
MENUP-012 Cache Invalidation Handler
MENUP-013 User Personalization Service
MENUP-014 Badge Provider Framework
MENUP-015 Projection Explain Service
MENUP-016 Projection Reconciliation Engine
```

---

# 138. Approval Gate

Dokumen dapat menjadi Approved setelah:

- Platform Architecture review;
- RBAC Owner review;
- Menu/UX Architecture review;
- Scope Architecture review;
- Feature Flag governance review;
- Multi-tenant isolation review;
- Frontend review;
- Performance review;
- Security review;
- UAT review.

---

# 139. Closing Statement

Menu projection harus memastikan bahwa setiap user menerima navigation yang:

- berasal dari registry aktif;
- sesuai permission efektif;
- sesuai scope aktif;
- sesuai module dan tenant capability;
- sesuai feature flag;
- deterministic;
- cache-safe;
- dapat dijelaskan;
- dapat direkonsiliasi;
- tidak membocorkan menu lintas tenant.

Menu projection adalah representasi UX dari authorization context.

Menu projection bukan authorization decision itu sendiri dan tidak boleh digunakan sebagai satu-satunya kontrol akses.
