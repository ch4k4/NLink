# SSOT-RBAC-05 — Policy Enforcement & Authorization Decision Architecture

---

## Status Dokumen

| Item | Nilai |
|---|---|
| Kode | SSOT-RBAC-05 |
| Judul | Policy Enforcement & Authorization Decision Architecture |
| Versi | 1.0 |
| Status | Draft Architecture |
| Domain | Platform Kernel |
| Kategori | Authorization, Policy Enforcement & Access Control |
| Cakupan | PDP, PEP, PIP, PAP, Authorization Request, Decision, Combining Algorithm, Obligations, Caching, Enforcement, Audit |
| Bergantung pada | SSOT-SCOPE-01, SSOT-SCOPE-02, SSOT-SCOPE-04, SSOT-IAM-01, SSOT-IAM-03, SSOT-IAM-04, SSOT-IAM-06, SSOT-RBAC-01, SSOT-RBAC-02, SSOT-RBAC-03, SSOT-RBAC-04, SSOT-AUDIT-01, SSOT-OBS-01, SSOT-SEC-01 |
| Target Stack | PHP 8.1+, Composer, PSR-4, PDO, MySQL 8/MariaDB, Modular Monolith |
| Target Evolusi | Centralized Policy Decision Service, Distributed Enforcement, ABAC-ready, Microservice-ready |

---

# 1. Executive Summary

SSOT-RBAC-05 menetapkan arsitektur resmi untuk policy enforcement dan authorization decision pada Platform Kernel.

Dokumen ini mengatur:

- Policy Decision Point;
- Policy Enforcement Point;
- Policy Information Point;
- Policy Administration Point;
- canonical authorization request;
- canonical authorization decision;
- allow, deny, not-applicable, dan indeterminate;
- role, permission, scope, constraint, dan deny evaluation;
- policy combining;
- obligations dan advice;
- fail-closed behavior;
- enforcement di HTTP, CLI, scheduler, event consumer, dan background job;
- decision caching;
- cache invalidation;
- audit;
- observability;
- performance;
- resilience;
- database direction;
- API direction;
- SDK contracts;
- UAT;
- Definition of Done;
- implementation roadmap.

Tujuan akhirnya adalah memastikan setiap protected action:

- memiliki authorization request yang lengkap;
- menggunakan trusted context;
- dievaluasi oleh decision engine yang deterministic;
- ditegakkan di server side;
- tidak bergantung pada UI;
- menghasilkan reason code;
- menghasilkan evidence;
- gagal secara aman;
- dapat diaudit;
- dapat didistribusikan tanpa kehilangan consistency.

---

# 2. Objectives

Framework harus:

- memisahkan keputusan dari enforcement;
- menyediakan kontrak keputusan yang stabil;
- menggabungkan RBAC, scope, deny, dan constraints;
- menjaga tenant isolation;
- mendukung policy evolution;
- mendukung enforcement lintas transport;
- menyediakan explanation yang aman;
- mendukung low-latency decision;
- menjaga revocation cepat;
- mendukung audit dan troubleshooting.

---

# 3. Core Principles

```text
Server-Side Enforcement Is Mandatory
Deny Overrides Broad Grants
Untrusted Context Must Not Influence Decisions Directly
Authorization Is Evaluated Per Action
Menu Visibility Is Not Authorization
Fail Closed for Protected Operations
Decision Inputs Must Be Explicit
Decision Outputs Must Be Stable
Critical Revocation Must Propagate Quickly
Every Sensitive Decision Must Be Traceable
```

---

# 4. Scope

Framework berlaku untuk:

```text
HTTP Requests
CLI Commands
Background Jobs
Scheduled Jobs
Event Consumers
Internal Service Calls
Module-to-Module Calls
Administrative Operations
Data Export
File Access
Search Access
Reporting Access
```

---

# 5. Non-Scope

Dokumen ini tidak mendefinisikan secara rinci:

- authentication;
- complete permission catalog;
- role catalog ownership;
- scope hierarchy internals;
- UI menu projection;
- policy language implementation detail.

---

# 6. Reference Architecture

```text
Subject / Caller
      │
      ▼
Policy Enforcement Point (PEP)
      │
      ▼
Policy Decision Point (PDP)
      │
      ├── Role Assignment Resolver
      ├── Permission Resolver
      ├── Scope Resolver
      ├── Deny Resolver
      ├── Constraint Evaluator
      ├── SoD Evaluator
      └── Policy Information Point (PIP)
      │
      ▼
Authorization Decision
      │
      ▼
PEP Enforces Allow / Deny / Obligations
```

---

# 7. Core Components

```text
PAP — Policy Administration Point
PDP — Policy Decision Point
PEP — Policy Enforcement Point
PIP — Policy Information Point
PRP — Policy Retrieval Point
```

---

# 8. Policy Administration Point

PAP mengelola:

- policies;
- policy versions;
- activation;
- deprecation;
- approvals;
- testing;
- rollback;
- publication.

---

# 9. Policy Decision Point

PDP menerima authorization request dan menghasilkan authorization decision.

---

# 10. Policy Enforcement Point

PEP berada di boundary tempat action dieksekusi.

---

# 11. Policy Information Point

PIP menyediakan trusted attributes.

---

# 12. Policy Retrieval Point

PRP menyediakan active policy set ke PDP.

---

# 13. Enforcement Boundaries

PEP wajib tersedia pada:

```text
HTTP Middleware
Controller/Use Case Boundary
CLI Command Boundary
Job Handler Boundary
Event Consumer Boundary
File Download Boundary
Export Boundary
Search Query Boundary
Internal Service Boundary
```

---

# 14. Defense in Depth

Critical operations may enforce at more than one layer:

```text
Route Middleware
→ Application Service
→ Repository/Data Boundary
```

---

# 15. Canonical Authorization Request

Minimum fields:

```text
subject
action
resource
scope
environment
authentication
request metadata
```

---

# 16. Subject Context

```text
subject_id
subject_type
tenant_id
session_id
identity_status
authentication_assurance
```

---

# 17. Action

Action uses stable permission code.

Example:

```text
patient.read
patient.update
homecare.visit.assign
rbac.assignment.approve
```

---

# 18. Resource Context

Potential:

```text
resource_type
resource_id
resource_tenant_id
resource_scope
resource_owner
classification
workflow_state
```

---

# 19. Scope Context

```text
tenant_id
organization_id
clinic_id
department_id
module_code
resource_scope
```

---

# 20. Environment Context

Potential:

```text
timestamp
network_zone
device_assurance
channel
purpose
request_origin
risk_level
```

---

# 21. Request Metadata

```text
request_id
correlation_id
trace_id
route
method
source_service
```

---

# 22. Trusted Context Rule

Trusted context must be assembled server-side.

---

# 23. Untrusted Input

The following are untrusted until validated:

- tenant ID from form;
- clinic ID from query string;
- role from client;
- permission from hidden field;
- resource owner from payload;
- external group claim.

---

# 24. Authorization Request Contract

```php
final readonly class AuthorizationRequest
{
    public function __construct(
        public SubjectContext $subject,
        public string $action,
        public ResourceContext $resource,
        public ScopeContext $scope,
        public EnvironmentContext $environment,
        public RequestMetadata $metadata,
    ) {
    }
}
```

---

# 25. Canonical Decision

```text
ALLOW
DENY
NOT_APPLICABLE
INDETERMINATE
```

---

# 26. Allow

Action may proceed subject to obligations.

---

# 27. Deny

Action must not proceed.

---

# 28. Not Applicable

No policy or assignment applies.

For protected operations, treat as deny.

---

# 29. Indeterminate

Decision could not be completed reliably.

For protected operations, treat as deny.

---

# 30. Decision Fields

```text
decision
reason_code
policy_version
matched_assignments
matched_permissions
matched_denies
obligations
advice
evaluated_at
decision_id
```

---

# 31. Authorization Decision Contract

```php
final readonly class AuthorizationDecision
{
    public function __construct(
        public string $decision,
        public string $reasonCode,
        public string $policyVersion,
        public array $matchedAssignments,
        public array $obligations,
        public array $advice,
        public string $decisionId,
    ) {
    }
}
```

---

# 32. Reason Codes

Reason code must be stable and machine-readable.

---

# 33. Safe Explanation

Explanation must not reveal sensitive role topology or hidden policy details to unauthorized clients.

---

# 34. Internal Explanation

Internal diagnostics may include:

- matched assignment;
- failed scope;
- deny source;
- constraint failure;
- policy version;
- attribute source.

---

# 35. Policy Evaluation Order

Recommended:

```text
Validate Request
→ Validate Subject
→ Validate Tenant
→ Validate Resource Scope
→ Load Active Assignment Set
→ Resolve Permissions
→ Apply Scope Inheritance
→ Evaluate Constraints
→ Evaluate SoD
→ Apply Denies
→ Combine Results
→ Produce Decision
→ Emit Evidence
```

---

# 36. Subject Validation

Deny when subject is:

```text
DISABLED
SUSPENDED
TERMINATED
LOCKED
UNKNOWN
```

unless explicit emergency policy exists.

---

# 37. Tenant Validation

Subject tenant and resource tenant must align according to approved model.

---

# 38. Resource Validation

Resource must exist or use approved not-found masking policy.

---

# 39. Permission Resolution

Permissions originate from active local role assignments.

---

# 40. External Claims

External claims may influence mappings but are not direct permissions.

---

# 41. Scope Resolution

Scope resolution uses SSOT-SCOPE rules.

---

# 42. Constraint Evaluation

Constraints may include:

- time;
- purpose;
- assurance;
- resource ownership;
- workflow state;
- device;
- network;
- case assignment.

---

# 43. Deny Evaluation

Explicit denies apply before final allow.

---

# 44. Combining Algorithms

Supported baseline:

```text
DENY_OVERRIDES
PERMIT_OVERRIDES
FIRST_APPLICABLE
ONLY_ONE_APPLICABLE
```

---

# 45. Default Combining Algorithm

Use:

```text
DENY_OVERRIDES
```

for protected business operations.

---

# 46. Permit Overrides

Use only for explicitly approved low-risk policy domains.

---

# 47. First Applicable

Use only when policy order is stable and governed.

---

# 48. Only One Applicable

Useful when overlapping policies are invalid.

---

# 49. Policy Conflict

Conflicting policies should produce:

```text
INDETERMINATE
```

unless combining rules resolve deterministically.

---

# 50. Default Decision

Protected actions default to deny.

---

# 51. Public Actions

Public actions must be explicitly classified.

---

# 52. Anonymous Subject

Anonymous requests may use dedicated subject type.

---

# 53. Obligations

Obligations are mandatory post-decision actions.

Examples:

```text
MASK_FIELDS
LIMIT_ROWS
REQUIRE_STEP_UP
WRITE_AUDIT
ADD_WATERMARK
RESTRICT_EXPORT
FILTER_SCOPE
```

---

# 54. Advice

Advice is non-mandatory guidance.

---

# 55. Obligation Enforcement

PEP must enforce all mandatory obligations before action completion.

---

# 56. Obligation Failure

If mandatory obligation cannot be applied, deny or rollback.

---

# 57. Field Masking

Authorization may return field masking obligations.

---

# 58. Row Filtering

Authorization may return approved scope filter obligations.

---

# 59. Step-Up

Sensitive action may return `REQUIRE_STEP_UP`.

---

# 60. Watermarking

Export/download may require watermark obligation.

---

# 61. Audit Obligation

Sensitive allow decisions may require audit record.

---

# 62. PEP Contract

```php
interface PolicyEnforcementPointInterface
{
    public function enforce(
        AuthorizationRequest $request
    ): AuthorizationDecision;
}
```

---

# 63. PDP Contract

```php
interface PolicyDecisionPointInterface
{
    public function decide(
        AuthorizationRequest $request
    ): AuthorizationDecision;
}
```

---

# 64. PIP Contract

```php
interface PolicyInformationPointInterface
{
    public function attributesFor(
        AuthorizationRequest $request
    ): PolicyAttributeSet;
}
```

---

# 65. PAP Contract

```php
interface PolicyAdministrationPointInterface
{
    public function publish(PolicySet $policySet): void;
    public function activate(string $policyVersion): void;
    public function retire(string $policyVersion): void;
}
```

---

# 66. HTTP Enforcement

HTTP middleware should:

- authenticate;
- build trusted context;
- identify action;
- invoke PDP;
- enforce decision;
- attach obligations.

---

# 67. Controller Enforcement

Controllers should not implement ad hoc role checks.

---

# 68. Application Service Enforcement

Critical use cases should enforce at application boundary.

---

# 69. Repository Enforcement

Repository filters may provide defense in depth for tenant/scope.

---

# 70. CLI Enforcement

CLI actor must have explicit identity and authorization context.

---

# 71. Scheduler Enforcement

Scheduled jobs must use service identity and approved scope.

---

# 72. Background Job Enforcement

Jobs must preserve or reconstruct trusted authorization context.

---

# 73. Event Consumer Enforcement

Event consumption does not automatically authorize downstream action.

---

# 74. Internal Service Calls

Internal calls require service identity or delegated user context.

---

# 75. Context Propagation

Only signed or trusted internal metadata may propagate authorization context.

---

# 76. User Context Delegation

User-on-behalf-of calls must distinguish:

```text
actor
subject
delegation
```

---

# 77. Confused Deputy Protection

Service must verify it is authorized to act for delegated subject.

---

# 78. Resource Ownership

Ownership checks are contextual constraints, not substitutes for role permission.

---

# 79. Authorization at Data Boundary

Tenant-aware queries must include trusted tenant/scope predicates.

---

# 80. Search Authorization

Search results must be filtered before exposure.

---

# 81. Reporting Authorization

Reports require permission and dataset scope.

---

# 82. Export Authorization

Exports may require separate permission, approval, and obligations.

---

# 83. File Authorization

File metadata and parent business resource scope must be evaluated.

---

# 84. Cache Goals

Decision caching should reduce latency without preserving revoked access.

---

# 85. Cache Key

Potential key:

```text
subject_id
tenant_id
active_scope
action
resource_type
resource_scope
assignment_version
permission_version
deny_version
policy_version
assurance
```

---

# 86. Cache Scope

Never share authorization cache across tenants.

---

# 87. Cache TTL

TTL must be short for sensitive/privileged decisions.

---

# 88. No-Cache Decisions

Recommended for:

- privilege grants;
- role assignment approval;
- secret/key access;
- emergency actions;
- cross-tenant administration;
- high-risk export.

---

# 89. Cache Invalidation

Invalidate on:

- assignment activation/revocation;
- role permission change;
- deny change;
- subject status change;
- scope hierarchy change;
- group mapping change;
- policy activation;
- assurance change.

---

# 90. Negative Caching

Short negative caching may reduce abuse but must not block newly granted critical access beyond policy.

---

# 91. Decision Snapshot

Long-running transaction may use bounded decision snapshot.

---

# 92. TOCTOU Risk

For sensitive operations, re-evaluate near commit or execution.

---

# 93. Transactional Enforcement

Authorization and state change should occur in controlled transaction where feasible.

---

# 94. Bulk Operations

Bulk authorization must prevent one allowed resource from authorizing all others.

---

# 95. Partial Authorization

Bulk operations may return per-item decisions.

---

# 96. Performance Target

Initial target:

```text
P95 local decision <= 20 ms
P99 local decision <= 50 ms
```

Targets must be validated in deployment environment.

---

# 97. Resilience

PDP failure handling must be explicit.

---

# 98. Local PDP Failure

Protected action fails closed.

---

# 99. Remote PDP Failure

Use one of:

```text
FAIL_CLOSED
BOUNDED_LAST_KNOWN_DECISION
OFFLINE_POLICY_BUNDLE
```

based on risk classification.

---

# 100. Last Known Decision

Prohibited for high-risk changing resources unless specifically approved.

---

# 101. Offline Policy Bundle

May support distributed enforcement with signed versioned policy bundle.

---

# 102. Policy Bundle Integrity

Validate:

- signature;
- checksum;
- version;
- issuer;
- effective dates;
- tenant applicability.

---

# 103. Circuit Breaker

Remote PDP may use circuit breaker but must not convert failures to allow.

---

# 104. Timeout

Authorization timeout must be bounded.

---

# 105. Retry

Retry only idempotent decision requests.

---

# 106. Decision Idempotency

Same immutable input and policy version should produce same result.

---

# 107. Policy Versioning

Use immutable versions.

---

# 108. Policy Status

```text
DRAFT
IN_REVIEW
APPROVED
ACTIVE
DEPRECATED
RETIRED
REJECTED
```

---

# 109. Policy Publication

Publication flow:

```text
Draft
→ Validate
→ Test
→ Review
→ Approve
→ Publish
→ Activate
→ Monitor
```

---

# 110. Policy Rollback

Previous approved policy version should be recoverable.

---

# 111. Policy Migration

Breaking policy changes require impact analysis.

---

# 112. Shadow Evaluation

New policies may run in shadow mode.

---

# 113. Shadow Result

Shadow decisions must not affect production action.

---

# 114. Policy Testing

Required tests:

- allow;
- deny;
- not applicable;
- indeterminate;
- tenant mismatch;
- scope inheritance;
- deny override;
- obligations;
- regression.

---

# 115. Policy Linting

Validate:

- unknown permission;
- unknown scope type;
- invalid effect;
- unreachable rule;
- conflict;
- missing owner;
- missing version.

---

# 116. Policy Approval

Critical policies require SoD and security review.

---

# 117. Administrative Permissions

Potential:

```text
rbac.policy.view
rbac.policy.create
rbac.policy.review
rbac.policy.approve
rbac.policy.publish
rbac.policy.activate
rbac.policy.rollback
rbac.decision.explain
rbac.decision.audit.view
```

---

# 118. Policy Ownership

Every policy set must have owner.

---

# 119. Policy Domain

Potential domains:

```text
PLATFORM
TENANT_ADMIN
CLINICAL
HOMECARE
WOUNDCARE
BILLING
REPORTING
AUDIT
SECURITY
INTEGRATION
```

---

# 120. Tenant Custom Policy

Tenant customization must remain within platform guardrails.

---

# 121. Guardrail Policy

Platform guardrails cannot be weakened by tenant policy.

---

# 122. Mandatory Deny

Cross-tenant deny is mandatory platform policy.

---

# 123. Authorization Logging

Operational logs should include:

```text
decision_id
action
resource_type
tenant_id
scope
decision
reason_code
policy_version
duration_ms
correlation_id
```

---

# 124. Sensitive Data

Do not log full resource payload or raw tokens.

---

# 125. Decision Audit

Audit required for:

- privileged allow;
- privileged deny;
- policy changes;
- emergency actions;
- cross-tenant attempts;
- export;
- access to restricted records.

---

# 126. Audit Events

```text
RBAC_POLICY_CREATED
RBAC_POLICY_APPROVED
RBAC_POLICY_ACTIVATED
RBAC_POLICY_ROLLED_BACK
RBAC_DECISION_ALLOWED
RBAC_DECISION_DENIED
RBAC_DECISION_INDETERMINATE
RBAC_OBLIGATION_ENFORCED
RBAC_OBLIGATION_FAILED
RBAC_CROSS_TENANT_DECISION_BLOCKED
```

---

# 127. Metrics

```text
rbac_decision_total
rbac_decision_allow_total
rbac_decision_deny_total
rbac_decision_indeterminate_total
rbac_decision_duration_seconds
rbac_decision_cache_hit_ratio
rbac_policy_conflict_total
rbac_obligation_failure_total
rbac_remote_pdp_failure_total
rbac_cross_tenant_deny_total
```

---

# 128. KPIs

Initial targets:

```text
Protected actions without PEP = 0
Indeterminate converted to allow = 0
Cross-tenant allow decisions = 0
Mandatory obligation failures ignored = 0
Active policies without owner = 0
Policy activation without tests = 0
Critical revocation propagation breach = 0
```

---

# 129. KRIs

```text
Deny rate spikes
Indeterminate growth
PDP latency growth
Cache staleness incidents
Policy conflict count
Obligation failures
Remote PDP outages
Cross-tenant attempts
Shadow policy divergence
```

---

# 130. Database Direction

Potential tables:

```text
rbac_policy_sets
rbac_policy_versions
rbac_policy_rules
rbac_policy_approvals
rbac_policy_deployments
rbac_authorization_decisions
rbac_decision_obligations
rbac_policy_test_runs
rbac_policy_conflicts
```

---

# 131. Table: rbac_policy_sets

```sql
CREATE TABLE rbac_policy_sets (
    id CHAR(26) NOT NULL,
    policy_code VARCHAR(180) NOT NULL,
    name VARCHAR(255) NOT NULL,
    domain_code VARCHAR(100) NOT NULL,
    tenant_id CHAR(26) NULL,
    owner_reference VARCHAR(180) NOT NULL,
    status VARCHAR(30) NOT NULL,
    active_version VARCHAR(100) NULL,
    created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    updated_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6)
        ON UPDATE CURRENT_TIMESTAMP(6),

    PRIMARY KEY (id),
    UNIQUE KEY uq_rbac_policy_code (
        tenant_id,
        policy_code
    ),
    KEY idx_rbac_policy_status (
        status,
        domain_code
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

# 132. Table: rbac_policy_versions

```sql
CREATE TABLE rbac_policy_versions (
    id CHAR(26) NOT NULL,
    policy_set_id CHAR(26) NOT NULL,
    version VARCHAR(100) NOT NULL,
    combining_algorithm VARCHAR(50) NOT NULL,
    policy_document_json JSON NOT NULL,
    checksum_sha256 CHAR(64) NOT NULL,
    status VARCHAR(30) NOT NULL,
    approved_by VARCHAR(180) NULL,
    effective_from DATETIME(6) NULL,
    effective_to DATETIME(6) NULL,

    PRIMARY KEY (id),
    UNIQUE KEY uq_rbac_policy_version (
        policy_set_id,
        version
    ),
    CONSTRAINT fk_rbac_policy_version_set
        FOREIGN KEY (policy_set_id)
        REFERENCES rbac_policy_sets (id)
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

# 133. Table: rbac_policy_rules

```sql
CREATE TABLE rbac_policy_rules (
    id CHAR(26) NOT NULL,
    policy_version_id CHAR(26) NOT NULL,
    rule_code VARCHAR(180) NOT NULL,
    effect VARCHAR(30) NOT NULL,
    action_pattern VARCHAR(255) NOT NULL,
    resource_type VARCHAR(180) NULL,
    condition_json JSON NULL,
    obligations_json JSON NULL,
    priority INT NOT NULL DEFAULT 100,

    PRIMARY KEY (id),
    UNIQUE KEY uq_rbac_policy_rule (
        policy_version_id,
        rule_code
    ),
    KEY idx_rbac_policy_rule_action (
        action_pattern,
        resource_type
    ),
    CONSTRAINT fk_rbac_policy_rule_version
        FOREIGN KEY (policy_version_id)
        REFERENCES rbac_policy_versions (id)
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

# 134. Table: rbac_authorization_decisions

```sql
CREATE TABLE rbac_authorization_decisions (
    id CHAR(26) NOT NULL,
    decision_code VARCHAR(100) NOT NULL,
    subject_id CHAR(26) NOT NULL,
    tenant_id CHAR(26) NOT NULL,
    action_code VARCHAR(180) NOT NULL,
    resource_type VARCHAR(180) NULL,
    resource_id CHAR(26) NULL,
    scope_type VARCHAR(30) NOT NULL,
    scope_id CHAR(26) NOT NULL,
    decision VARCHAR(30) NOT NULL,
    reason_code VARCHAR(180) NOT NULL,
    policy_version VARCHAR(100) NOT NULL,
    correlation_id VARCHAR(100) NOT NULL,
    duration_microseconds BIGINT UNSIGNED NOT NULL,
    decided_at DATETIME(6) NOT NULL,

    PRIMARY KEY (id),
    UNIQUE KEY uq_rbac_decision_code (
        decision_code
    ),
    KEY idx_rbac_decision_subject (
        tenant_id,
        subject_id,
        decided_at
    ),
    KEY idx_rbac_decision_result (
        decision,
        decided_at
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

# 135. Table: rbac_decision_obligations

```sql
CREATE TABLE rbac_decision_obligations (
    id CHAR(26) NOT NULL,
    authorization_decision_id CHAR(26) NOT NULL,
    obligation_code VARCHAR(100) NOT NULL,
    obligation_payload_json JSON NULL,
    enforcement_status VARCHAR(30) NOT NULL,
    enforced_at DATETIME(6) NULL,
    failure_code VARCHAR(180) NULL,

    PRIMARY KEY (id),
    KEY idx_rbac_obligation_decision (
        authorization_decision_id,
        enforcement_status
    ),
    CONSTRAINT fk_rbac_obligation_decision
        FOREIGN KEY (authorization_decision_id)
        REFERENCES rbac_authorization_decisions (id)
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

# 136. API Direction

```text
POST /api/internal/v1/authorization/decisions
POST /api/internal/v1/authorization/batch-decisions
GET  /api/internal/v1/authorization/decisions/{decisionId}
GET  /api/internal/v1/rbac/policies
POST /api/internal/v1/rbac/policies
POST /api/internal/v1/rbac/policies/{id}/submit
POST /api/internal/v1/rbac/policies/{id}/approve
POST /api/internal/v1/rbac/policies/{id}/activate
POST /api/internal/v1/rbac/policies/{id}/rollback
POST /api/internal/v1/rbac/policies/{id}/test
```

---

# 137. Decision API Request

```json
{
  "subject": {
    "id": "01J...",
    "type": "USER",
    "tenant_id": "01T..."
  },
  "action": "patient.read",
  "resource": {
    "type": "PATIENT",
    "id": "01P..."
  },
  "scope": {
    "type": "CLINIC",
    "id": "01C..."
  }
}
```

---

# 138. Decision API Response

```json
{
  "data": {
    "decision": "ALLOW",
    "reason_code": "RBAC_MATCHED_SCOPED_ASSIGNMENT",
    "decision_id": "01D...",
    "policy_version": "2026.07.1",
    "obligations": [
      {
        "code": "MASK_FIELDS",
        "fields": ["national_id"]
      }
    ]
  },
  "meta": {
    "request_id": "01R..."
  }
}
```

---

# 139. Error Codes

```text
RBAC_DECISION_REQUEST_INVALID
RBAC_DECISION_SUBJECT_INVALID
RBAC_DECISION_TENANT_MISMATCH
RBAC_DECISION_SCOPE_UNRESOLVED
RBAC_DECISION_RESOURCE_INVALID
RBAC_DECISION_NO_APPLICABLE_POLICY
RBAC_DECISION_POLICY_CONFLICT
RBAC_DECISION_CONSTRAINT_FAILED
RBAC_DECISION_EXPLICIT_DENY
RBAC_DECISION_INDETERMINATE
RBAC_DECISION_TIMEOUT
RBAC_DECISION_PDP_UNAVAILABLE
RBAC_DECISION_OBLIGATION_FAILED
RBAC_DECISION_CACHE_STALE
```

---

# 140. Policy Authoring Checklist

- [ ] Policy code unique.
- [ ] Owner assigned.
- [ ] Domain assigned.
- [ ] Tenant applicability defined.
- [ ] Effect explicit.
- [ ] Actions use catalog codes.
- [ ] Scope rules explicit.
- [ ] Combining algorithm defined.
- [ ] Obligations defined.
- [ ] Tests complete.
- [ ] Conflict scan complete.
- [ ] Approval complete.
- [ ] Rollback version available.

---

# 141. PEP Checklist

- [ ] Protected action mapped to permission.
- [ ] Trusted context assembled.
- [ ] PDP invoked before side effect.
- [ ] Deny enforced.
- [ ] Indeterminate enforced as deny.
- [ ] Obligations enforced.
- [ ] Correlation ID propagated.
- [ ] Decision evidence recorded.
- [ ] Sensitive errors masked.
- [ ] No client-side-only authorization.

---

# 142. Cache Checklist

- [ ] Cache key tenant-aware.
- [ ] Policy version included.
- [ ] Assignment version included.
- [ ] Deny version included.
- [ ] Sensitive actions excluded where required.
- [ ] TTL risk-based.
- [ ] Revocation invalidation tested.
- [ ] Scope move invalidation tested.
- [ ] Metrics enabled.
- [ ] Stale decision detection available.

---

# 143. UAT — Canonical Decision

- [ ] Valid allow decision works.
- [ ] Missing assignment denies.
- [ ] Explicit deny overrides allow.
- [ ] Not-applicable denies protected action.
- [ ] Indeterminate denies protected action.
- [ ] Reason code stable.
- [ ] Policy version returned.
- [ ] Decision ID generated.
- [ ] Correlation ID preserved.
- [ ] Explanation does not leak sensitive details.

---

# 144. UAT — Scope & Tenant

- [ ] Same-tenant scope works.
- [ ] Cross-tenant resource denied.
- [ ] Invalid clinic denied.
- [ ] Parent-child inheritance evaluated.
- [ ] Resource tenant mismatch denied.
- [ ] Scope move invalidates decision cache.
- [ ] Tenant guardrail cannot be overridden.
- [ ] Global scope restricted.

---

# 145. UAT — Constraints & Denies

- [ ] Time constraint works.
- [ ] Assurance constraint works.
- [ ] Purpose constraint works.
- [ ] Resource ownership constraint works.
- [ ] Unknown restrictive attribute fails closed.
- [ ] Explicit resource deny works.
- [ ] Suspended subject denied.
- [ ] Expired assignment denied.

---

# 146. UAT — Obligations

- [ ] Field masking applied.
- [ ] Row filter applied.
- [ ] Step-up obligation blocks until satisfied.
- [ ] Audit obligation recorded.
- [ ] Watermark obligation applied.
- [ ] Export restriction applied.
- [ ] Obligation failure denies/rolls back.
- [ ] Obligation status audited.

---

# 147. UAT — HTTP & Application Enforcement

- [ ] Middleware enforces route permission.
- [ ] Application service rechecks critical action.
- [ ] Hidden menu does not authorize.
- [ ] Direct endpoint access denied.
- [ ] Controller has no ad hoc role logic.
- [ ] Repository receives trusted scope filter.
- [ ] Error response uses safe code.
- [ ] Audit event contains decision ID.

---

# 148. UAT — CLI, Job & Event

- [ ] CLI requires explicit actor.
- [ ] Scheduler uses service identity.
- [ ] Job reconstructs trusted context.
- [ ] Event consumer reauthorizes side effects.
- [ ] User delegation records actor and subject.
- [ ] Expired delegation denied.
- [ ] Service account scope enforced.
- [ ] Confused deputy attempt denied.

---

# 149. UAT — Cache & Revocation

- [ ] Cache hit returns same decision.
- [ ] Cache is tenant-isolated.
- [ ] Assignment revoke invalidates cache.
- [ ] Role permission change invalidates cache.
- [ ] Deny change invalidates cache.
- [ ] Subject suspension invalidates cache.
- [ ] Policy activation invalidates cache.
- [ ] Critical decision no-cache policy works.
- [ ] Stale decision does not preserve revoked access.

---

# 150. UAT — Policy Lifecycle

- [ ] Draft cannot become active directly.
- [ ] Linter catches invalid permission.
- [ ] Conflict scan detects overlap.
- [ ] Tests required before approval.
- [ ] Maker-checker enforced.
- [ ] Activation versioned.
- [ ] Rollback restores prior version.
- [ ] Shadow evaluation produces comparison.
- [ ] Retired policy no longer applies.
- [ ] Policy changes audited.

---

# 151. UAT — Resilience

- [ ] Local PDP failure denies.
- [ ] Remote PDP timeout bounded.
- [ ] Circuit breaker does not allow by default.
- [ ] Offline bundle signature validated.
- [ ] Expired bundle rejected.
- [ ] Last-known decision unavailable for high-risk action.
- [ ] Retry remains idempotent.
- [ ] Recovery metrics emitted.
- [ ] Degraded mode visible.

---

# 152. UAT — Performance

- [ ] P95 target measured.
- [ ] P99 target measured.
- [ ] Cache ratio measured.
- [ ] Bulk decision bounded.
- [ ] N+1 policy lookups absent.
- [ ] Large role sets tested.
- [ ] Large scope trees tested.
- [ ] Logging overhead measured.
- [ ] Audit persistence does not silently fail.

---

# 153. UAT — Security & Audit

- [ ] Unauthorized policy admin denied.
- [ ] Policy activation requires privilege.
- [ ] Cross-tenant attempts audited.
- [ ] Raw tokens not logged.
- [ ] Raw sensitive payload not logged.
- [ ] Decision audit tamper controls work.
- [ ] Emergency policies visible.
- [ ] Privileged allows auditable.
- [ ] Obligation failures alert.

---

# 154. Definition of Done — SSOT-RBAC-05

SSOT-RBAC-05 dianggap selesai bila:

- [ ] reference architecture tersedia;
- [ ] PDP, PEP, PIP, PAP, PRP didefinisikan;
- [ ] canonical request tersedia;
- [ ] canonical decision tersedia;
- [ ] evaluation order tersedia;
- [ ] combining algorithms tersedia;
- [ ] default-deny tersedia;
- [ ] obligation model tersedia;
- [ ] HTTP enforcement tersedia;
- [ ] CLI/job/event enforcement tersedia;
- [ ] distributed context tersedia;
- [ ] confused deputy controls tersedia;
- [ ] data/search/report/file enforcement tersedia;
- [ ] cache strategy tersedia;
- [ ] revocation invalidation tersedia;
- [ ] resilience model tersedia;
- [ ] policy versioning/lifecycle tersedia;
- [ ] shadow testing tersedia;
- [ ] policy linting tersedia;
- [ ] tenant guardrails tersedia;
- [ ] audit/logging/metrics tersedia;
- [ ] database direction tersedia;
- [ ] API direction tersedia;
- [ ] SDK contracts tersedia;
- [ ] error codes tersedia;
- [ ] checklists dan UAT tersedia.

---

# 155. Implementation Roadmap

## Phase 1 — Canonical Decision Foundation

- authorization request;
- authorization decision;
- PDP interface;
- PEP middleware;
- role/scope integration;
- default deny.

## Phase 2 — Constraints & Obligations

- constraint evaluator;
- deny resolver;
- combining algorithms;
- masking/filter obligations;
- step-up obligation;
- decision audit.

## Phase 3 — Multi-Channel Enforcement

- CLI;
- scheduler;
- background jobs;
- event consumers;
- internal service calls;
- delegated user context.

## Phase 4 — Policy Governance

- PAP;
- policy versions;
- approval;
- testing;
- linting;
- activation;
- rollback;
- shadow mode.

## Phase 5 — Distributed Authorization

- signed policy bundle;
- remote PDP;
- resilient caching;
- microservice context;
- centralized decision analytics;
- ABAC extensions.

---

# 156. Initial Implementation Backlog

```text
RBACP-001 Canonical Authorization Request
RBACP-002 Canonical Authorization Decision
RBACP-003 Policy Decision Point
RBACP-004 HTTP Policy Enforcement Middleware
RBACP-005 Application Service Guard
RBACP-006 Policy Information Point
RBACP-007 Scope & Assignment Resolver
RBACP-008 Constraint Evaluator
RBACP-009 Deny Resolver
RBACP-010 Combining Engine
RBACP-011 Obligation Engine
RBACP-012 Decision Cache
RBACP-013 Cache Invalidation Bus
RBACP-014 Policy Administration Point
RBACP-015 Policy Linter
RBACP-016 Shadow Evaluation
RBACP-017 Decision Audit Store
RBACP-018 Authorization Dashboard
```

---

# 157. Approval Gate

Dokumen dapat menjadi Approved setelah:

- Platform Architecture review;
- IAM review;
- RBAC review;
- Scope Architecture review;
- Security review;
- Multi-tenant isolation review;
- Audit review;
- Operations review;
- Module SDK review;
- performance review;
- resilience review.

---

# 158. Closing Statement

Policy enforcement harus memastikan bahwa setiap protected action:

- dipetakan ke permission yang stabil;
- menggunakan trusted subject dan scope;
- dievaluasi oleh decision engine;
- tunduk pada deny, constraints, dan tenant guardrails;
- menghasilkan decision yang deterministic;
- menerapkan obligations;
- gagal secara aman;
- dapat dicabut dengan cepat;
- dapat dijelaskan;
- dapat diaudit.

Authorization bukan sekadar pengecekan role.

Authorization adalah keputusan server-side berbasis subject, action, resource, scope, environment, policy, dan lifecycle yang harus ditegakkan konsisten pada setiap execution boundary.
