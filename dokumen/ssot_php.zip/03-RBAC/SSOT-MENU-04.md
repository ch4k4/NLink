# SSOT-MENU-04 — Navigation Governance & Route Binding

---

## Status Dokumen

| Item | Nilai |
|---|---|
| Kode | SSOT-MENU-04 |
| Judul | Navigation Governance & Route Binding |
| Versi | 1.0 |
| Status | Draft Architecture |
| Domain | Platform Kernel |
| Kategori | Navigation Governance, Routing & Authorization Integration |
| Cakupan | Route Registry, Menu-to-Route Binding, Use Case Binding, Deep Link, Redirect, Alias, Resource Resolver, Scope Resolver, Route Lifecycle, Reconciliation |
| Bergantung pada | SSOT-GOV-01, SSOT-GOV-02, SSOT-GOV-03, SSOT-SCOPE-01, SSOT-SCOPE-04, SSOT-RBAC-05, SSOT-RBAC-06, SSOT-MENU-01, SSOT-MENU-02, SSOT-MENU-03, SSOT-API-01, SSOT-SDK-01 |
| Target Stack | PHP 8.1+, Composer, PSR-4, HTTP Router, Middleware, PDO, MySQL 8/MariaDB |
| Target Evolusi | Route Registry Service, Multi-Frontend Navigation, Microfrontend-ready, Distributed Route Contracts |

---

# 1. Executive Summary

SSOT-MENU-04 menetapkan tata kelola resmi untuk navigation dan route binding pada Platform Kernel.

Dokumen ini mengatur:

- canonical route registry;
- route ownership;
- stable route name;
- menu-to-route binding;
- route-to-use-case binding;
- permission binding;
- scope resolver;
- resource resolver;
- route parameter governance;
- deep link;
- redirect;
- alias;
- deprecated route;
- external route;
- contextual navigation;
- route lifecycle;
- route compatibility;
- route change management;
- route reconciliation;
- authorization enforcement boundary;
- audit;
- metrics;
- database direction;
- API direction;
- SDK contracts;
- UAT;
- Definition of Done;
- implementation roadmap.

Tujuan akhirnya adalah memastikan navigation:

- menggunakan route name yang stabil;
- tidak bergantung pada raw URL yang tersebar;
- memiliki owner;
- memiliki use case yang jelas;
- memiliki permission requirement yang eksplisit;
- memiliki scope dan resource resolver yang valid;
- tidak menjadi authorization bypass;
- mendukung redirect dan migration secara aman;
- dapat direkonsiliasi;
- dapat diaudit.

---

# 2. Objectives

Framework harus:

- menyediakan canonical route registry;
- menjaga stable route contracts;
- memisahkan route name dari URL path;
- memastikan setiap protected route memiliki permission binding;
- memastikan scope dan resource resolution server-side;
- mendukung deep link yang aman;
- mengendalikan redirects dan aliases;
- mencegah broken navigation;
- mendukung route deprecation;
- menyediakan reconciliation dan CI gate.

---

# 3. Core Principles

```text
Route Names Are Stable Contracts
Paths May Change, Contracts Must Be Governed
Menu Visibility Is Not Route Authorization
Every Protected Route Requires Permission Binding
Every Scoped Route Requires Trusted Scope Resolution
Every Resource Route Requires Resource Resolution
No Silent Route Override
Redirects Must Be Explicit and Safe
Deprecated Routes Must Have Migration Paths
Every Binding Must Be Testable
```

---

# 4. Scope

Framework berlaku untuk:

```text
Web Routes
Internal Application Routes
API Routes Used by Navigation
Contextual Action Routes
Deep Links
External Navigation Links
Redirect Routes
Legacy Aliases
Workspace Entry Routes
Mobile Navigation Routes
```

---

# 5. Non-Scope

Dokumen ini tidak mendefinisikan:

- complete HTTP routing framework;
- authorization engine internals;
- menu registry internals;
- frontend component rendering;
- public API versioning secara penuh;
- business workflow detail.

---

# 6. Route Definition

Route adalah kontrak navigasi atau request yang menghubungkan caller dengan application capability.

---

# 7. Canonical Route Registry

Route registry adalah single source of truth untuk route contracts yang digunakan oleh menu, API documentation, tests, dan runtime enforcement.

---

# 8. Route Identity

Canonical identity menggunakan stable route name.

Contoh:

```text
homecare.visits.index
homecare.visits.show
homecare.visits.assign
patient.profile.show
rbac.assignments.approve
```

---

# 9. Route Name Rules

Route name harus:

- lowercase;
- menggunakan dot separator;
- dimiliki oleh namespace;
- stabil;
- tidak mengandung tenant ID;
- tidak mengandung environment;
- tidak mengandung locale;
- tidak bergantung pada URL path.

---

# 10. Route Namespace

Format:

```text
{module}.{resource}.{action}
```

Contoh:

```text
billing.invoices.index
woundcare.assessments.create
security.secrets.rotate
```

---

# 11. Reserved Route Namespaces

```text
platform
system
security
iam
rbac
audit
scope
menu
config
```

---

# 12. Route Owner

Every route must have:

- domain owner;
- module owner;
- technical owner;
- security owner for high-risk routes.

---

# 13. Route Metadata

Minimum:

```text
route_name
path_template
http_methods
route_type
owner
module_code
use_case_code
permission_code
scope_resolver
resource_resolver
status
version
```

---

# 14. Optional Metadata

```text
feature_flag
tenant_capability
industry_applicability
authentication_required
assurance_level
csrf_policy
rate_limit_policy
idempotency_policy
cache_policy
deprecated_replacement
```

---

# 15. Route Types

```text
PAGE
ACTION
API
DOWNLOAD
UPLOAD
EXPORT
REDIRECT
EXTERNAL
CONTEXTUAL
WORKSPACE_ENTRY
```

---

# 16. Page Route

Route yang merender halaman atau application shell.

---

# 17. Action Route

Route yang mengeksekusi state-changing use case.

---

# 18. API Route

Route machine-readable untuk frontend/internal client.

---

# 19. Download/Export Route

Route berisiko tinggi yang memerlukan permission terpisah dan audit.

---

# 20. Redirect Route

Route yang meneruskan caller ke canonical destination.

---

# 21. External Route

Route menuju domain luar yang telah disetujui.

---

# 22. Contextual Route

Route membutuhkan resource context aktif.

---

# 23. Workspace Entry

Route masuk ke workspace/module tertentu.

---

# 24. Menu-to-Route Binding

Navigable menu item harus menunjuk route name, bukan raw path, kecuali external/legacy case yang disetujui.

---

# 25. Binding Contract

Minimum:

```text
menu_code
route_name
binding_type
required_parameters
default_parameters
status
```

---

# 26. Binding Types

```text
PRIMARY
SECONDARY
CONTEXTUAL
FALLBACK
LEGACY_ALIAS
EXTERNAL
```

---

# 27. Primary Binding

Main destination untuk menu item.

---

# 28. Secondary Binding

Alternative destination yang masih dalam capability sama.

---

# 29. Contextual Binding

Memerlukan current resource atau workspace context.

---

# 30. Fallback Binding

Digunakan bila preferred route tidak tersedia karena module/feature state.

---

# 31. Route-to-Use-Case Binding

State-changing route harus terikat ke application use case/command.

---

# 32. Use Case Code

Contoh:

```text
homecare.visit.assign
billing.invoice.approve
rbac.assignment.revoke
```

---

# 33. Use Case Boundary

Authorization enforcement utama berada pada application boundary, bukan hanya route middleware.

---

# 34. Route Permission Binding

Protected route wajib memiliki canonical permission code dari SSOT-RBAC-06.

---

# 35. Permission Binding Modes

```text
SINGLE
ANY_OF
ALL_OF
POLICY_DECISION
PUBLIC_EXPLICIT
```

---

# 36. Public Route

Public route harus diberi status eksplisit:

```text
PUBLIC_EXPLICIT
```

Tidak adanya permission bukan berarti public.

---

# 37. Route Authorization Rule

```text
Menu Projection
≠
Route Authorization
```

Direct URL access tetap harus dievaluasi server-side.

---

# 38. Middleware Enforcement

Middleware dapat melakukan early authorization, tetapi critical use case harus recheck di application service.

---

# 39. Scope Resolver

Scoped route wajib memiliki trusted scope resolver.

---

# 40. Scope Resolver Inputs

Dapat menggunakan:

- authenticated session;
- route parameter;
- resource lookup;
- tenant binding;
- current workspace;
- server-side mapping.

---

# 41. Untrusted Scope Input

Raw tenant/clinic ID dari request tidak boleh langsung dipercaya.

---

# 42. Scope Resolver Contract

```php
interface RouteScopeResolverInterface
{
    public function resolve(
        RouteRequestContext $context
    ): ScopeContext;
}
```

---

# 43. Resource Resolver

Resource route harus menyelesaikan canonical business resource.

---

# 44. Resource Resolver Contract

```php
interface RouteResourceResolverInterface
{
    public function resolve(
        RouteRequestContext $context
    ): ResourceContext;
}
```

---

# 45. Resource Not Found

Use approved masking policy:

```text
NOT_FOUND
or
FORBIDDEN_MASKED_AS_NOT_FOUND
```

---

# 46. Route Parameters

Parameters must be typed and validated.

---

# 47. Parameter Types

```text
ULID
UUID
INTEGER
SLUG
ENUM
DATE
TENANT_CODE
MODULE_CODE
```

---

# 48. Parameter Constraints

Each parameter should define:

- type;
- regex/format;
- length;
- optionality;
- source;
- resolver;
- sensitivity.

---

# 49. Route Model Binding

Automatic model binding must preserve tenant and scope filters.

---

# 50. Insecure Direct Object Reference

Resource lookup without scope verification is prohibited.

---

# 51. Deep Link

Deep link is a navigable URL to a specific page or context.

---

# 52. Deep Link Requirements

- route active;
- parameters valid;
- subject authenticated where required;
- permission valid;
- scope valid;
- feature/module active;
- safe fallback.

---

# 53. Deep Link Token

Signed deep link token may be used for controlled navigation.

---

# 54. Deep Link Token Controls

- expiry;
- audience;
- issuer;
- nonce where needed;
- resource binding;
- tenant binding;
- one-time use where needed;
- signature validation.

---

# 55. Deep Link Is Not Authorization

Token may provide navigation context but must not bypass local authorization.

---

# 56. Redirect Governance

Redirects must be explicit and registered.

---

# 57. Redirect Types

```text
PERMANENT
TEMPORARY
POST_LOGIN
POST_ACTION
LEGACY_MIGRATION
EXTERNAL_APPROVED
```

---

# 58. Internal Redirect

Internal redirects should use route names.

---

# 59. External Redirect

External redirect requires host allowlist.

---

# 60. Open Redirect Protection

User-provided redirect target must be validated against approved destinations.

---

# 61. Post-Login Redirect

Must validate:

- target route;
- tenant context;
- permission;
- module state;
- feature state;
- safe fallback.

---

# 62. Return URL

Return URL should be signed or mapped to registered route.

---

# 63. Route Alias

Alias supports migration from old route name/path.

---

# 64. Alias Rules

- one canonical target;
- no alias chain;
- expiry required;
- usage metrics;
- no new menu binding;
- audit.

---

# 65. Legacy Path

Legacy path may redirect to canonical route during transition.

---

# 66. Alias Chain

Prohibited:

```text
old-a → old-b → new-c
```

Use direct mapping:

```text
old-a → new-c
old-b → new-c
```

---

# 67. Route Lifecycle

```text
DRAFT
IN_REVIEW
APPROVED
ACTIVE
DEPRECATED
SUSPENDED
RETIRED
REJECTED
```

---

# 68. Route Activation Preconditions

- owner assigned;
- path unique;
- route name unique;
- use case valid;
- permission valid;
- scope/resource resolver valid;
- tests pass;
- documentation exists.

---

# 69. Route Deprecation

Must define:

- reason;
- replacement route;
- compatibility period;
- affected menus;
- affected clients;
- affected bookmarks;
- migration deadline.

---

# 70. Route Retirement

Blocked while active menu, alias, client, or integration references remain.

---

# 71. Route Suspension

Security/operations may suspend route temporarily.

---

# 72. Feature Flag Binding

Route may depend on feature flag.

---

# 73. Feature Flag Rule

Flag may disable route availability but must not grant access.

---

# 74. Module State Binding

Route unavailable when owning module inactive.

---

# 75. Tenant Capability

Route may require tenant capability.

---

# 76. Industry Applicability

Route may be limited to approved industry packs.

---

# 77. Route Compatibility

Route name should remain stable across non-breaking path changes.

---

# 78. Breaking Route Changes

Examples:

- route name change;
- required parameter change;
- semantic use case change;
- permission change;
- scope model change;
- response contract change.

---

# 79. Non-Breaking Route Changes

Examples:

- internal handler refactor;
- path change with registered redirect;
- optional parameter addition with default;
- metadata update.

---

# 80. Permission Change

Changing route permission requires security impact review.

---

# 81. Scope Resolver Change

Changing resolver may be security-breaking.

---

# 82. Route Versioning

Route metadata versions must be immutable.

---

# 83. Registry Version

Route registry should publish versioned snapshots.

---

# 84. Route Manifest

Every module should publish route manifest.

---

# 85. Route Manifest Example

```yaml
module: homecare
version: 1.4.0
routes:
  - name: homecare.visits.index
    type: PAGE
    path: /homecare/visits
    methods: [GET]
    permission:
      mode: SINGLE
      code: homecare.visit.list
    scope_resolver: clinic_from_session
    use_case: homecare.visit.list

  - name: homecare.visits.assign
    type: ACTION
    path: /homecare/visits/{visitId}/assign
    methods: [POST]
    permission:
      mode: SINGLE
      code: homecare.visit.assign
    resource_resolver: homecare_visit
    scope_resolver: clinic_from_visit
    use_case: homecare.visit.assign
```

---

# 86. Manifest Validation

Validate:

- schema;
- namespace;
- route name;
- path uniqueness;
- method;
- permission;
- use case;
- resolver;
- lifecycle;
- feature/module references.

---

# 87. Route Collision

Occurs when:

- same route name from different owner;
- same method/path with conflicting handler;
- same route name with different permission;
- same route name with different resource semantics;
- reserved namespace misuse.

---

# 88. Collision Result

```text
IDENTICAL_IDEMPOTENT
COMPATIBLE_ALIAS
CONFLICT
REQUIRES_REVIEW
```

---

# 89. Silent Override

Prohibited.

---

# 90. Route Registration

Flow:

```text
Discover
→ Parse Manifest
→ Validate
→ Detect Collision
→ Validate Dependencies
→ Register
→ Publish Registry
```

---

# 91. Idempotent Registration

Same manifest version and checksum must be idempotent.

---

# 92. Checksum Mismatch

Same version with changed content must be rejected.

---

# 93. Contextual Navigation

Resource-specific actions should be contributed through context navigation.

---

# 94. Context Action Conditions

Can reference:

- resource type;
- workflow state;
- permission;
- scope;
- feature flag;
- ownership;
- assurance level.

---

# 95. Context Action Security

Context action visibility still does not replace route authorization.

---

# 96. Breadcrumb Binding

Breadcrumb should derive from route and menu registry where possible.

---

# 97. Route-to-Breadcrumb Mapping

Minimum:

```text
route_name
menu_code
label_key
parent_route
resource_label_resolver
```

---

# 98. Canonical URL

Each page route should define canonical URL generation strategy.

---

# 99. URL Generation

Use route generator, not string concatenation.

---

# 100. URL Generator Contract

```php
interface RouteUrlGeneratorInterface
{
    public function generate(
        string $routeName,
        array $parameters = []
    ): string;
}
```

---

# 101. Route Lookup Contract

```php
interface RouteRegistryInterface
{
    public function find(string $routeName): ?RouteDefinition;

    public function requireActive(string $routeName): RouteDefinition;

    public function current(): RouteRegistrySnapshot;
}
```

---

# 102. Route Binding Validator Contract

```php
interface RouteBindingValidatorInterface
{
    public function validate(
        MenuRouteBinding $binding
    ): RouteBindingValidationResult;
}
```

---

# 103. Navigation Decision

Before generating a link:

```text
Route Active?
Module Active?
Feature Active?
Parameters Available?
Permission Projection Passed?
Scope Context Available?
```

---

# 104. Fallback Navigation

If preferred route unavailable:

- hide item;
- route to approved fallback;
- show disabled state only if UX policy allows;
- never expose broken URL.

---

# 105. Disabled Menu State

Disabled state must not reveal sensitive capability details unnecessarily.

---

# 106. Route Reconciliation

Compare route registry against:

- router runtime;
- menu registry;
- permission catalog;
- use case registry;
- scope resolvers;
- resource resolvers;
- API docs;
- tests;
- redirects;
- aliases.

---

# 107. Reconciliation Outcomes

```text
MATCHED
MISSING_RUNTIME_ROUTE
MISSING_REGISTRY_ROUTE
MISSING_PERMISSION
MISSING_USE_CASE
MISSING_SCOPE_RESOLVER
MISSING_RESOURCE_RESOLVER
ORPHAN_MENU_BINDING
STALE_ALIAS
PATH_COLLISION
STATUS_DRIFT
```

---

# 108. Shadow Route

Runtime route exists but not in registry.

---

# 109. Zombie Route

Retired route remains active at runtime.

---

# 110. Orphan Binding

Menu points to missing/inactive route.

---

# 111. Unused Route

Active route without consumer should be reviewed.

---

# 112. Route Test Requirements

Every active route should have:

- routing test;
- permission test;
- scope test;
- resource test where applicable;
- method test;
- CSRF test for browser state changes;
- redirect test;
- negative test.

---

# 113. CI Gate

Critical reconciliation findings fail build or deployment.

---

# 114. Audit Events

```text
ROUTE_REGISTERED
ROUTE_ACTIVATED
ROUTE_UPDATED
ROUTE_DEPRECATED
ROUTE_RETIRED
ROUTE_SUSPENDED
ROUTE_ALIAS_CREATED
ROUTE_REDIRECT_EXECUTED
ROUTE_BINDING_CHANGED
ROUTE_COLLISION_DETECTED
ROUTE_RECONCILIATION_FAILED
```

---

# 115. Audit Metadata

```text
route_name
path_template
http_methods
module_code
owner
permission_code
scope_resolver
resource_resolver
menu_code
registry_version
correlation_id
```

---

# 116. Metrics

```text
route_registry_total
route_registry_active_total
route_binding_total
route_orphan_binding_total
route_shadow_total
route_zombie_total
route_collision_total
route_deprecated_usage_total
route_redirect_total
route_reconciliation_failure_total
```

---

# 117. KPIs

```text
Protected routes without permission = 0
Scoped routes without scope resolver = 0
Resource routes without resource resolver = 0
Active menu bindings to missing routes = 0
Open redirects = 0
Silent route overrides = 0
Zombie routes = 0
Critical route changes without tests = 0
```

---

# 118. KRIs

```text
Deprecated route usage
Alias growth
Redirect loops
Route collision frequency
Missing resolver findings
Permission drift
Broken deep links
Unauthorized direct URL attempts
```

---

# 119. Database Direction

Potential tables:

```text
route_registry
route_registry_versions
route_manifests
route_menu_bindings
route_permission_bindings
route_scope_resolvers
route_resource_resolvers
route_aliases
route_redirects
route_reconciliation_runs
route_reconciliation_findings
```

---

# 120. Table: route_registry

```sql
CREATE TABLE route_registry (
    id CHAR(26) NOT NULL,
    route_name VARCHAR(255) NOT NULL,
    path_template VARCHAR(1000) NOT NULL,
    http_methods_json JSON NOT NULL,
    route_type VARCHAR(40) NOT NULL,
    module_code VARCHAR(100) NOT NULL,
    owner_reference VARCHAR(180) NOT NULL,
    use_case_code VARCHAR(180) NULL,
    permission_mode VARCHAR(30) NOT NULL,
    permission_codes_json JSON NULL,
    scope_resolver_code VARCHAR(180) NULL,
    resource_resolver_code VARCHAR(180) NULL,
    status VARCHAR(30) NOT NULL,
    current_version VARCHAR(100) NOT NULL,
    created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    updated_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6)
        ON UPDATE CURRENT_TIMESTAMP(6),

    PRIMARY KEY (id),
    UNIQUE KEY uq_route_registry_name (route_name),
    KEY idx_route_registry_module (
        module_code,
        status
    ),
    KEY idx_route_registry_path (
        status
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

# 121. Table: route_menu_bindings

```sql
CREATE TABLE route_menu_bindings (
    id CHAR(26) NOT NULL,
    menu_code VARCHAR(180) NOT NULL,
    route_name VARCHAR(255) NOT NULL,
    binding_type VARCHAR(40) NOT NULL,
    required_parameters_json JSON NULL,
    default_parameters_json JSON NULL,
    status VARCHAR(30) NOT NULL,

    PRIMARY KEY (id),
    UNIQUE KEY uq_route_menu_binding (
        menu_code,
        route_name,
        binding_type
    ),
    KEY idx_route_menu_route (
        route_name,
        status
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

# 122. Table: route_aliases

```sql
CREATE TABLE route_aliases (
    id CHAR(26) NOT NULL,
    alias_route_name VARCHAR(255) NOT NULL,
    canonical_route_name VARCHAR(255) NOT NULL,
    valid_from DATETIME(6) NOT NULL,
    valid_to DATETIME(6) NOT NULL,
    status VARCHAR(30) NOT NULL,
    reason_text VARCHAR(1000) NOT NULL,

    PRIMARY KEY (id),
    UNIQUE KEY uq_route_alias_name (
        alias_route_name
    ),
    KEY idx_route_alias_expiry (
        status,
        valid_to
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

# 123. Table: route_redirects

```sql
CREATE TABLE route_redirects (
    id CHAR(26) NOT NULL,
    source_route_name VARCHAR(255) NOT NULL,
    target_route_name VARCHAR(255) NULL,
    external_target_url VARCHAR(1000) NULL,
    redirect_type VARCHAR(40) NOT NULL,
    status_code INT NOT NULL,
    host_allowlist_code VARCHAR(180) NULL,
    status VARCHAR(30) NOT NULL,
    valid_from DATETIME(6) NOT NULL,
    valid_to DATETIME(6) NULL,

    PRIMARY KEY (id),
    UNIQUE KEY uq_route_redirect_source (
        source_route_name
    ),
    KEY idx_route_redirect_status (
        status,
        valid_to
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

# 124. Table: route_registry_versions

```sql
CREATE TABLE route_registry_versions (
    id CHAR(26) NOT NULL,
    registry_version VARCHAR(100) NOT NULL,
    snapshot_json JSON NOT NULL,
    checksum_sha256 CHAR(64) NOT NULL,
    status VARCHAR(30) NOT NULL,
    published_by VARCHAR(180) NULL,
    published_at DATETIME(6) NULL,
    supersedes_version VARCHAR(100) NULL,

    PRIMARY KEY (id),
    UNIQUE KEY uq_route_registry_version (
        registry_version
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

# 125. API Direction

```text
GET  /api/internal/v1/routes/registry
GET  /api/internal/v1/routes/registry/{routeName}
POST /api/internal/v1/routes/manifests
POST /api/internal/v1/routes/manifests/{id}/validate
POST /api/internal/v1/routes/registry/publish
POST /api/internal/v1/routes/registry/rollback
POST /api/internal/v1/routes/aliases
POST /api/internal/v1/routes/redirects
POST /api/internal/v1/routes/reconcile
GET  /api/internal/v1/routes/reconciliation-runs/{runId}
```

---

# 126. Error Codes

```text
ROUTE_REGISTRY_NOT_FOUND
ROUTE_REGISTRY_NAME_INVALID
ROUTE_REGISTRY_PATH_COLLISION
ROUTE_REGISTRY_OWNER_REQUIRED
ROUTE_REGISTRY_PERMISSION_MISSING
ROUTE_REGISTRY_USE_CASE_MISSING
ROUTE_REGISTRY_SCOPE_RESOLVER_MISSING
ROUTE_REGISTRY_RESOURCE_RESOLVER_MISSING
ROUTE_REGISTRY_ALIAS_CHAIN_FORBIDDEN
ROUTE_REGISTRY_REDIRECT_INVALID
ROUTE_REGISTRY_EXTERNAL_HOST_FORBIDDEN
ROUTE_REGISTRY_BINDING_INVALID
ROUTE_REGISTRY_CHECKSUM_MISMATCH
ROUTE_REGISTRY_RETIREMENT_BLOCKED
ROUTE_REGISTRY_RECONCILIATION_FAILED
```

---

# 127. Route Registration Checklist

- [ ] Route name valid.
- [ ] Namespace owned.
- [ ] Owner assigned.
- [ ] Path template valid.
- [ ] HTTP methods explicit.
- [ ] Route type valid.
- [ ] Use case registered.
- [ ] Permission active.
- [ ] Scope resolver valid.
- [ ] Resource resolver valid.
- [ ] Feature/module references valid.
- [ ] Tests defined.
- [ ] Collision scan passed.
- [ ] Checksum valid.

---

# 128. Menu Binding Checklist

- [ ] Menu code active.
- [ ] Route active.
- [ ] Binding type valid.
- [ ] Required parameters available.
- [ ] Default parameters safe.
- [ ] Permission semantics compatible.
- [ ] Scope semantics compatible.
- [ ] Fallback defined where required.
- [ ] No raw path duplication.
- [ ] Binding audited.

---

# 129. Redirect Checklist

- [ ] Source registered.
- [ ] Target registered.
- [ ] No redirect loop.
- [ ] External host allowlisted.
- [ ] Status code correct.
- [ ] Expiry defined for migration redirect.
- [ ] Permission re-evaluated at destination.
- [ ] Tenant context preserved safely.
- [ ] Usage metrics enabled.
- [ ] Open redirect test passed.

---

# 130. Deprecation Checklist

- [ ] Replacement route defined.
- [ ] Menu bindings identified.
- [ ] API/client consumers identified.
- [ ] Aliases defined where required.
- [ ] Redirects tested.
- [ ] Deadline defined.
- [ ] Usage metrics enabled.
- [ ] Documentation updated.
- [ ] Retirement gate defined.
- [ ] Owner assigned.

---

# 131. UAT — Registration

- [ ] Valid route manifest registers.
- [ ] Same version/checksum is idempotent.
- [ ] Same version/different checksum rejected.
- [ ] Duplicate route name rejected.
- [ ] Method/path collision detected.
- [ ] Reserved namespace protected.
- [ ] Missing owner rejected.
- [ ] Missing use case rejected.
- [ ] Publication audited.

---

# 132. UAT — Permission & Authorization

- [ ] Protected route requires permission.
- [ ] Public route requires explicit classification.
- [ ] Direct URL access denied without permission.
- [ ] Menu visibility does not grant access.
- [ ] Application service rechecks critical action.
- [ ] Permission change invalidates route cache.
- [ ] Retired permission blocks route activation.
- [ ] Authorization decision carries correlation ID.

---

# 133. UAT — Scope & Resource Resolution

- [ ] Valid tenant scope resolves.
- [ ] Raw tenant parameter is not trusted directly.
- [ ] Clinic scope resolves from resource.
- [ ] Cross-tenant resource denied.
- [ ] Missing resolver blocks route activation.
- [ ] Resource not found masking works.
- [ ] Model binding preserves scope filter.
- [ ] IDOR attempt denied.
- [ ] Resolver failure fails closed.

---

# 134. UAT — Menu Binding

- [ ] Active menu resolves route name.
- [ ] Missing route produces reconciliation finding.
- [ ] Contextual route requires context.
- [ ] Fallback route works.
- [ ] Required parameters validated.
- [ ] Raw string URL avoided.
- [ ] Breadcrumb derives correctly.
- [ ] Canonical URL generated correctly.

---

# 135. UAT — Deep Link

- [ ] Valid deep link opens destination.
- [ ] Expired signed link rejected.
- [ ] Wrong tenant rejected.
- [ ] Wrong audience rejected.
- [ ] Invalid signature rejected.
- [ ] Missing permission denied.
- [ ] Inactive feature falls back safely.
- [ ] Deep link does not bypass authorization.
- [ ] One-time link cannot be reused where configured.

---

# 136. UAT — Redirect & Alias

- [ ] Internal redirect uses route name.
- [ ] External redirect host allowlist enforced.
- [ ] Open redirect attempt blocked.
- [ ] Redirect loop detected.
- [ ] Alias resolves canonical route.
- [ ] Alias chain rejected.
- [ ] Alias expiry enforced.
- [ ] Deprecated route usage measured.
- [ ] Destination authorization re-evaluated.

---

# 137. UAT — Lifecycle

- [ ] Draft route unavailable.
- [ ] Active route available.
- [ ] Suspended route unavailable.
- [ ] Deprecated route still redirects.
- [ ] Retirement blocked by active menu binding.
- [ ] Retired route removed from runtime.
- [ ] Registry history retained.
- [ ] Rollback restores prior snapshot.

---

# 138. UAT — Feature, Module & Tenant Capability

- [ ] Inactive module blocks route.
- [ ] Disabled feature blocks route.
- [ ] Tenant capability enforced.
- [ ] Industry restriction enforced.
- [ ] Tenant override cannot expose inactive route.
- [ ] Feature flag does not grant authorization.
- [ ] Safe fallback works.
- [ ] Cache invalidates on state change.

---

# 139. UAT — Reconciliation

- [ ] Shadow runtime route detected.
- [ ] Zombie route detected.
- [ ] Missing permission detected.
- [ ] Missing use case detected.
- [ ] Missing scope resolver detected.
- [ ] Missing resource resolver detected.
- [ ] Orphan menu binding detected.
- [ ] Stale alias detected.
- [ ] Status drift detected.
- [ ] CI fails on critical finding.

---

# 140. UAT — Security

- [ ] CSRF policy enforced for browser state changes.
- [ ] Unsafe method rejected.
- [ ] External URL policy enforced.
- [ ] Sensitive route metadata protected.
- [ ] Unauthorized route publication denied.
- [ ] Silent override impossible.
- [ ] Route changes audited.
- [ ] Correlation ID retained.
- [ ] Rate limit policy applied where required.

---

# 141. UAT — Performance & Resilience

- [ ] Route lookup P95 measured.
- [ ] Registry snapshot load measured.
- [ ] Large route set tested.
- [ ] URL generation bounded.
- [ ] Resolver caching safe.
- [ ] Cache invalidates on publish.
- [ ] Concurrent publication protected.
- [ ] Redirect resolution bounded.
- [ ] Reconciliation runtime bounded.

---

# 142. Definition of Done — SSOT-MENU-04

SSOT-MENU-04 dianggap selesai bila:

- [ ] route registry definition tersedia;
- [ ] route naming and ownership tersedia;
- [ ] route metadata standard tersedia;
- [ ] route types tersedia;
- [ ] menu-to-route binding tersedia;
- [ ] route-to-use-case binding tersedia;
- [ ] permission binding tersedia;
- [ ] scope resolver tersedia;
- [ ] resource resolver tersedia;
- [ ] parameter governance tersedia;
- [ ] deep link governance tersedia;
- [ ] redirect governance tersedia;
- [ ] alias governance tersedia;
- [ ] lifecycle/deprecation/retirement tersedia;
- [ ] feature/module/tenant bindings tersedia;
- [ ] compatibility/versioning tersedia;
- [ ] route manifest tersedia;
- [ ] collision handling tersedia;
- [ ] contextual navigation tersedia;
- [ ] breadcrumb/canonical URL tersedia;
- [ ] reconciliation/CI gate tersedia;
- [ ] audit/logging/metrics tersedia;
- [ ] database direction tersedia;
- [ ] API direction tersedia;
- [ ] SDK contracts tersedia;
- [ ] error codes tersedia;
- [ ] checklists dan UAT tersedia.

---

# 143. Implementation Roadmap

## Phase 1 — Route Registry Foundation

- canonical route schema;
- route name validator;
- ownership registry;
- route manifest;
- runtime router scanner;
- registry API.

## Phase 2 — Authorization & Resolver Binding

- permission binding;
- use case binding;
- scope resolver registry;
- resource resolver registry;
- middleware integration;
- application service guard.

## Phase 3 — Navigation Integration

- menu binding validator;
- contextual navigation;
- breadcrumbs;
- canonical URL generator;
- fallback routes;
- deep link handling.

## Phase 4 — Lifecycle & Compatibility

- route aliases;
- redirects;
- deprecation workflow;
- compatibility checker;
- usage metrics;
- retirement gate.

## Phase 5 — Reconciliation & Distributed Routing

- route/menu/permission reconciliation;
- signed route manifests;
- remote route contracts;
- microfrontend navigation;
- distributed registry snapshots;
- CI/CD enforcement.

---

# 144. Initial Implementation Backlog

```text
ROUTEG-001 Route Registry Schema
ROUTEG-002 Route Name Validator
ROUTEG-003 Route Manifest Schema
ROUTEG-004 Runtime Route Scanner
ROUTEG-005 Route Collision Detector
ROUTEG-006 Permission Binding Validator
ROUTEG-007 Use Case Binding Registry
ROUTEG-008 Scope Resolver Registry
ROUTEG-009 Resource Resolver Registry
ROUTEG-010 Menu Route Binding Validator
ROUTEG-011 URL Generator
ROUTEG-012 Deep Link Service
ROUTEG-013 Redirect & Alias Service
ROUTEG-014 Route Lifecycle Service
ROUTEG-015 Reconciliation Engine
ROUTEG-016 Route Governance Dashboard
```

---

# 145. Approval Gate

Dokumen dapat menjadi Approved setelah:

- Platform Architecture review;
- Menu/UX Architecture review;
- Routing/API Governance review;
- RBAC review;
- Scope Architecture review;
- Security review;
- Module SDK review;
- Multi-tenant isolation review;
- Operations review;
- UAT review.

---

# 146. Closing Statement

Navigation governance harus memastikan bahwa setiap menu dan deep link:

- menunjuk route contract yang stabil;
- memiliki owner;
- memiliki use case;
- memiliki permission binding;
- memiliki scope dan resource resolver yang benar;
- tidak membuka jalur bypass;
- memiliki lifecycle;
- dapat dimigrasikan;
- dapat direkonsiliasi;
- dapat diaudit.

Menu menentukan apa yang ditampilkan.

Route binding menentukan ke mana navigation menuju.

Authorization menentukan apakah action benar-benar boleh dijalankan.
