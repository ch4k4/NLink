# SSOT-RBAC-09 — Access Review & Certification Governance

---

## Status Dokumen

| Item | Nilai |
|---|---|
| Kode | SSOT-RBAC-09 |
| Judul | Access Review & Certification Governance |
| Versi | 1.0 |
| Status | Draft Architecture |
| Domain | Platform Kernel |
| Kategori | Identity Governance, Entitlement Review & Access Certification |
| Cakupan | Access Review Campaigns, Certification, Reviewer Workflow, Remediation, Evidence, Escalation, Continuous Review |
| Bergantung pada | SSOT-GOV-01, SSOT-GOV-04, SSOT-GOV-05, SSOT-SCOPE-01, SSOT-IAM-07, SSOT-IAM-08, SSOT-RBAC-04, SSOT-RBAC-05, SSOT-RBAC-06, SSOT-RBAC-07, SSOT-RBAC-08, SSOT-AUDIT-01, SSOT-WF-01, SSOT-WF-03, SSOT-NOTIFY-01, SSOT-TEST-01 |
| Target Stack | PHP 8.1+, PDO, MySQL 8/MariaDB, Workflow/Notification-ready |
| Target Evolusi | Continuous Access Certification, Risk-Based Campaigns, Automated Remediation, Identity Governance Analytics |

---

# 1. Executive Summary

SSOT-RBAC-09 menetapkan governance resmi untuk periodic access review, entitlement certification, access campaign, reviewer assignment, remediation, evidence, escalation, dan continuous access governance.

Dokumen ini mengatur:

- certification scope;
- campaign types;
- reviewer assignment;
- review frequency;
- review population;
- role certification;
- permission certification;
- scope certification;
- privileged access review;
- external user review;
- service account review;
- temporary grant review;
- orphan access review;
- dormant access review;
- decision outcomes;
- evidence;
- escalation;
- remediation;
- revocation;
- exception;
- delegated review;
- reviewer conflict;
- continuous review;
- audit;
- metrics;
- database direction;
- API direction;
- SDK contracts;
- UAT;
- Definition of Done;
- implementation roadmap.

Tujuan akhirnya adalah memastikan bahwa seluruh access:

- masih dibutuhkan;
- masih sesuai peran;
- masih sesuai scope;
- masih dimiliki oleh subject yang aktif;
- tidak berlebihan;
- tidak konflik;
- tidak dormant;
- tidak orphan;
- direview oleh pihak yang tepat;
- diremediasi tepat waktu;
- memiliki evidence.

---

# 2. Objectives

Framework harus:

- menyediakan periodic certification;
- mendukung risk-based review;
- memastikan reviewer independen;
- menyediakan campaign governance;
- mempercepat remediation;
- mengurangi stale access;
- mendukung privileged access review;
- menyediakan evidence;
- mendukung continuous review;
- mendukung audit dan compliance.

---

# 3. Core Principles

```text
Access Must Be Recertified
Risk Determines Review Frequency
Reviewers Must Be Accountable
No Self-Certification for High-Risk Access
Decisions Must Be Explainable
Revocation Must Be Enforced
Exceptions Must Expire
Dormant and Orphan Access Must Be Removed
Evidence Must Be Complete
Certification Is a Control, Not a Checkbox
```

---

# 4. Scope

Framework berlaku untuk:

```text
User Accounts
Role Assignments
Permission Grants
Scope Assignments
Privileged Access
Temporary Grants
External Users
Contractors
Service Accounts
Machine Identities
Break-Glass Accounts
Delegated Access
```

---

# 5. Non-Scope

Dokumen ini tidak menggantikan:

- initial access approval;
- role design;
- permission catalog governance;
- authentication;
- employment review;
- business performance evaluation.

---

# 6. Certification Object Types

```text
IDENTITY
ACCOUNT
ROLE_ASSIGNMENT
PERMISSION_GRANT
SCOPE_ASSIGNMENT
PRIVILEGED_GRANT
TEMPORARY_GRANT
SERVICE_IDENTITY
EXTERNAL_IDENTITY
BREAK_GLASS_ACCOUNT
```

---

# 7. Campaign Types

```text
PERIODIC
EVENT_DRIVEN
RISK_TRIGGERED
PRIVILEGED
MANAGER
APPLICATION_OWNER
ROLE_OWNER
TENANT
EXCEPTION
TERMINATION_VALIDATION
```

---

# 8. Review Frequencies

Suggested:

| Risk | Frequency |
|---|---:|
| Critical | Monthly or Quarterly |
| High | Quarterly |
| Moderate | Semiannual |
| Low | Annual |
| External/Temporary | At expiry or quarterly |
| Break-glass | After use and quarterly |

---

# 9. Review Triggers

- scheduled cycle;
- role change;
- tenant transfer;
- manager change;
- security incident;
- dormant access;
- orphan identity;
- SoD conflict;
- privileged use;
- repeated break-glass;
- module deactivation;
- contract expiry;
- owner departure.

---

# 10. Review Population

Campaign population may be based on:

- tenant;
- organization;
- clinic;
- department;
- role;
- permission;
- application/module;
- risk tier;
- identity type;
- inactivity;
- access age;
- privileged status.

---

# 11. Campaign Lifecycle

```text
DRAFT
SCOPING
READY
ACTIVE
PAUSED
OVERDUE
COMPLETED
CANCELLED
ARCHIVED
```

---

# 12. Review Item Lifecycle

```text
PENDING
IN_REVIEW
APPROVED
REVOKE
MODIFY
DELEGATED
EXCEPTION_REQUESTED
ESCALATED
REMEDIATION_PENDING
REMEDIATED
CLOSED
```

---

# 13. Campaign Definition

Minimum:

```text
campaign_code
name
type
scope
population_rule
risk_tier
start_at
due_at
reviewer_strategy
remediation_sla
owner
```

---

# 14. Reviewer Strategies

```text
LINE_MANAGER
ROLE_OWNER
APPLICATION_OWNER
SCOPE_OWNER
DATA_OWNER
SECURITY_REVIEWER
SERVICE_OWNER
TENANT_ADMIN
INDEPENDENT_REVIEWER
```

---

# 15. Reviewer Selection

Reviewer must have:

- sufficient knowledge;
- no prohibited conflict;
- active identity;
- correct scope;
- certification responsibility;
- access to necessary evidence.

---

# 16. Self-Certification

Self-certification prohibited for:

- privileged access;
- critical roles;
- break-glass;
- secret/key administration;
- cross-tenant access;
- access with active SoD conflict.

---

# 17. Delegated Review

Delegation requires:

- reason;
- delegate suitability;
- start/end;
- approval where needed;
- audit;
- no circular delegation.

---

# 18. Reviewer Conflict

Potential conflicts:

- reviewer certifies own access;
- reviewer certifies access they approved;
- reviewer lacks scope ownership;
- reviewer is inactive;
- reviewer is subordinate of reviewed privileged subject in prohibited scenario.

---

# 19. Review Evidence

Reviewer should see:

- subject identity;
- lifecycle status;
- manager/owner;
- role/permission;
- scope;
- assignment source;
- granted date;
- expiry;
- last used;
- risk tier;
- SoD conflicts;
- privileged activity;
- business justification;
- prior decisions.

---

# 20. Data Minimization

Review UI should expose only necessary evidence.

---

# 21. Access Usage

Last-used data should be considered but absence of telemetry must be visible.

---

# 22. Decision Outcomes

```text
CERTIFY
REVOKE
MODIFY_SCOPE
REDUCE_PERMISSION
CONVERT_TO_JIT
SUSPEND
REQUEST_EXCEPTION
ESCALATE
NO_DECISION
```

---

# 23. Certify

Reviewer confirms continued need.

---

# 24. Revoke

Access must be removed.

---

# 25. Modify Scope

Access remains but scope must be reduced or changed.

---

# 26. Reduce Permission

Role or permission must be reduced.

---

# 27. Convert to JIT

Standing privilege converted to temporary/JIT.

---

# 28. Suspend

Temporary suspension pending investigation.

---

# 29. Exception

Exception requires expiry, owner, reason, risk, compensating controls, and approval.

---

# 30. Decision Reason

Mandatory for revoke, modify, exception, and escalation.

---

# 31. Bulk Certification

Bulk approval is restricted.

---

# 32. Bulk Decision Controls

- low-risk only by default;
- explicit confirmation;
- population visibility;
- excluded anomalies;
- no privileged bulk certification;
- audit.

---

# 33. Auto-Certification

Generally prohibited for high-risk access.

May be allowed for low-risk technical entitlements with strong evidence and owner policy.

---

# 34. Automated Recommendation

System may recommend but reviewer remains accountable.

---

# 35. Risk-Based Prioritization

Prioritize:

- privileged access;
- dormant access;
- orphan accounts;
- external access;
- cross-tenant access;
- SoD conflicts;
- long-standing grants;
- ownerless assignments.

---

# 36. Certification Scope

Review can cover:

```text
SUBJECT_CENTRIC
ROLE_CENTRIC
APPLICATION_CENTRIC
SCOPE_CENTRIC
PRIVILEGE_CENTRIC
SERVICE_ACCOUNT_CENTRIC
```

---

# 37. Subject-Centric Review

All access for one subject.

---

# 38. Role-Centric Review

All assignments of one role.

---

# 39. Application-Centric Review

All entitlements to a module/application.

---

# 40. Scope-Centric Review

All access within tenant, clinic, department, or resource scope.

---

# 41. Privileged Review

Includes standing privileged roles, JIT history, break-glass, secret access, and critical permissions.

---

# 42. Service Account Review

Must evaluate:

- owner;
- purpose;
- last use;
- credential age;
- scope;
- dependencies;
- human login prohibition;
- expiry/exception.

---

# 43. External User Review

Must evaluate:

- sponsor;
- end date;
- purpose;
- activity;
- scope;
- tenant;
- extension need.

---

# 44. Temporary Grant Review

Review before extension or after repeated renewals.

---

# 45. Dormant Access Review

Dormancy thresholds follow risk tier.

---

# 46. Orphan Access Review

Orphan access should default to suspend/revoke unless owner re-established.

---

# 47. SoD Review

Active conflicts must be visible and resolved or covered by approved exception.

---

# 48. Remediation

Decision must translate into executable remediation.

---

# 49. Remediation Actions

```text
REVOKE_ASSIGNMENT
REDUCE_SCOPE
REMOVE_PERMISSION
SUSPEND_ACCOUNT
EXPIRE_GRANT
CONVERT_TO_JIT
ASSIGN_OWNER
CREATE_EXCEPTION
```

---

# 50. Remediation SLA

Suggested:

| Risk | SLA |
|---|---:|
| Critical | Immediate–24 hours |
| High | 3 business days |
| Moderate | 10 business days |
| Low | 30 days |

---

# 51. Immediate Revocation

Required for:

- terminated identity;
- confirmed compromise;
- critical unauthorized privilege;
- cross-tenant violation;
- expired external engagement.

---

# 52. Remediation Verification

System must confirm actual access state changed.

---

# 53. Failed Remediation

Must create finding, retry, and escalate.

---

# 54. Partial Remediation

Must remain open until complete or approved exception.

---

# 55. Campaign Notifications

Notifications:

- campaign launch;
- reminder;
- approaching deadline;
- overdue;
- escalation;
- remediation assignment;
- completion.

---

# 56. Reminder Schedule

Should be configurable by campaign risk.

---

# 57. Escalation

Possible:

```text
MANAGER
ROLE_OWNER
APPLICATION_OWNER
TENANT_ADMIN
SECURITY
COMPLIANCE
EXECUTIVE_SPONSOR
```

---

# 58. Overdue Review

Overdue high-risk items may trigger temporary suspension.

---

# 59. Reviewer Non-Response

Must not silently certify access.

---

# 60. Campaign Completion

Campaign completes only when:

- all items decided;
- remediation resolved or accepted;
- exceptions approved;
- evidence complete;
- owner sign-off obtained.

---

# 61. Campaign Cancellation

Requires reason and impact analysis.

---

# 62. Campaign Reopen

Allowed for material error or incomplete evidence.

---

# 63. Access Certification Evidence

Minimum:

```text
campaign
review_item
reviewer
decision
reason
evidence_snapshot
decision_at
remediation
verification
```

---

# 64. Evidence Snapshot

Must preserve what reviewer saw at decision time.

---

# 65. Immutable Evidence

Final evidence should be immutable or tamper-evident.

---

# 66. Audit Retention

Retention follows audit/compliance policy.

---

# 67. Continuous Access Review

Continuous review monitors changes between campaigns.

---

# 68. Continuous Triggers

- privilege added;
- role changed;
- scope expanded;
- dormant threshold reached;
- manager changed;
- contract expired;
- new SoD conflict;
- suspicious use;
- repeated temporary extension.

---

# 69. Micro-Certification

Event-driven focused review of one or few access items.

---

# 70. Continuous Certification

May reduce periodic burden but does not eliminate formal review for critical access.

---

# 71. Access Review Policy

Minimum:

```text
policy_code
object_type
risk_tier
frequency
reviewer_strategy
evidence_requirements
decision_options
remediation_sla
escalation
```

---

# 72. Policy Versioning

Review item records policy version used.

---

# 73. Role Owner Certification

Role owner must periodically certify:

- role purpose;
- included permissions;
- risk tier;
- conflicting roles;
- eligible populations;
- scope model;
- usage.

---

# 74. Permission Owner Certification

Permission owner certifies:

- active use;
- owner;
- risk;
- route/action bindings;
- no duplicate semantics;
- retirement status.

---

# 75. Scope Owner Certification

Scope owner certifies access within their organizational boundary.

---

# 76. Break-Glass Certification

Review:

- account owner;
- credential protection;
- last test;
- last use;
- incidents;
- post-use review;
- need for continued existence.

---

# 77. Review Quality

Quality checks:

- suspicious all-certify behavior;
- very short decision time;
- no reasons on negative decisions;
- repeated delegation;
- reviewer conflict;
- overdue rate;
- exception abuse.

---

# 78. Reviewer Analytics

May detect low-quality review patterns, not replace due process.

---

# 79. Certification Coverage

Coverage must include all active assignments in campaign population.

---

# 80. Snapshot Consistency

Population snapshot should be stable while allowing material-change alerts.

---

# 81. In-Campaign Change

If access changes during review:

- item version increments;
- reviewer notified;
- stale decision invalidated where material.

---

# 82. Identity Lifecycle Integration

Terminated or suspended identities should not wait for campaign completion.

---

# 83. Provisioning Integration

Certified decisions become input for desired access state.

---

# 84. Privileged Access Integration

Standing access may be converted to JIT based on review.

---

# 85. Exception Integration

Exceptions must be linked to access item and expiry.

---

# 86. Workflow Integration

Use workflow for review, escalation, approval, and remediation.

---

# 87. Notification Integration

Notifications must respect privacy and avoid exposing sensitive entitlements broadly.

---

# 88. Tenant Isolation

Reviewer can only see items within authorized tenant/scope.

---

# 89. Cross-Tenant Campaign

Requires platform-level governance.

---

# 90. Reviewer Access

Review access is purpose-limited and does not grant operational capability.

---

# 91. Review UI

Should support:

- filters;
- risk sorting;
- evidence;
- comparison;
- bulk low-risk action;
- delegation;
- comments;
- progress;
- remediation status.

---

# 92. Export of Review Data

Requires controlled permission and audit.

---

# 93. Certification API

Should not expose internal sensitive details unnecessarily.

---

# 94. Access Review Service Contract

```php
interface AccessReviewServiceInterface
{
    public function createCampaign(
        AccessReviewCampaignRequest $request
    ): AccessReviewCampaign;

    public function decide(
        AccessReviewDecisionRequest $request
    ): AccessReviewDecisionResult;
}
```

---

# 95. Remediation Service Contract

```php
interface AccessReviewRemediationServiceInterface
{
    public function execute(
        AccessRemediationRequest $request
    ): AccessRemediationResult;
}
```

---

# 96. Campaign Population Contract

```php
interface AccessReviewPopulationBuilderInterface
{
    public function build(
        AccessReviewPopulationRequest $request
    ): AccessReviewPopulationSnapshot;
}
```

---

# 97. Reviewer Resolver Contract

```php
interface AccessReviewReviewerResolverInterface
{
    public function resolve(
        AccessReviewItemContext $context
    ): AccessReviewReviewerAssignment;
}
```

---

# 98. Reconciliation

Compare:

- campaign population;
- actual assignments;
- decisions;
- remediation state;
- exceptions;
- reviewer assignments;
- evidence;
- deadlines.

---

# 99. Reconciliation Findings

```text
UNCERTIFIED_ACTIVE_ACCESS
MISSING_REVIEWER
REVIEWER_CONFLICT
STALE_DECISION
FAILED_REMEDIATION
EXPIRED_EXCEPTION
OVERDUE_CAMPAIGN
MISSING_EVIDENCE
ORPHAN_REVIEW_ITEM
```

---

# 100. Audit Events

```text
RBAC_REVIEW_CAMPAIGN_CREATED
RBAC_REVIEW_CAMPAIGN_STARTED
RBAC_REVIEW_ITEM_ASSIGNED
RBAC_REVIEW_DECISION_RECORDED
RBAC_REVIEW_DELEGATED
RBAC_REVIEW_ESCALATED
RBAC_REMEDIATION_REQUESTED
RBAC_REMEDIATION_COMPLETED
RBAC_REMEDIATION_FAILED
RBAC_REVIEW_CAMPAIGN_COMPLETED
RBAC_REVIEW_EXCEPTION_APPROVED
```

---

# 101. Audit Metadata

```text
campaign_id
review_item_id
subject_id
entitlement
scope
reviewer
decision
reason
risk_tier
remediation
correlation_id
```

---

# 102. Metrics

```text
rbac_review_campaign_total
rbac_review_item_total
rbac_review_completion_rate
rbac_review_overdue_total
rbac_review_revoke_total
rbac_review_modify_total
rbac_review_exception_total
rbac_remediation_failure_total
rbac_uncertified_access_total
rbac_reviewer_conflict_total
```

---

# 103. KPIs

```text
Critical access certified within schedule = 100%
Terminated identities with active access = 0
High-risk remediation overdue = 0
Privileged self-certification = 0
Uncertified active privileged access = 0
Expired exceptions still effective = 0
Failed revocations unresolved = 0
```

---

# 104. KRIs

```text
All-certify reviewer pattern
High bulk-approval rate
Exception growth
Overdue campaign growth
Repeated remediation failure
Dormant access retained
External access extensions
Ownerless service accounts
```

---

# 105. Database Direction

Potential tables:

```text
rbac_access_review_policies
rbac_access_review_campaigns
rbac_access_review_populations
rbac_access_review_items
rbac_access_review_reviewer_assignments
rbac_access_review_decisions
rbac_access_review_remediations
rbac_access_review_exceptions
rbac_access_review_evidence
rbac_access_review_reconciliation_runs
rbac_access_review_reconciliation_findings
```

---

# 106. Table: rbac_access_review_campaigns

```sql
CREATE TABLE rbac_access_review_campaigns (
    id CHAR(26) NOT NULL,
    campaign_code VARCHAR(100) NOT NULL,
    name VARCHAR(255) NOT NULL,
    campaign_type VARCHAR(40) NOT NULL,
    tenant_id CHAR(26) NULL,
    scope_type VARCHAR(30) NULL,
    scope_id CHAR(26) NULL,
    risk_tier VARCHAR(30) NOT NULL,
    status VARCHAR(30) NOT NULL,
    start_at DATETIME(6) NOT NULL,
    due_at DATETIME(6) NOT NULL,
    owner_reference VARCHAR(180) NOT NULL,
    policy_version VARCHAR(100) NOT NULL,
    created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),

    PRIMARY KEY (id),
    UNIQUE KEY uq_rbac_review_campaign_code (
        campaign_code
    ),
    KEY idx_rbac_review_campaign_status (
        status,
        due_at
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

# 107. Table: rbac_access_review_items

```sql
CREATE TABLE rbac_access_review_items (
    id CHAR(26) NOT NULL,
    campaign_id CHAR(26) NOT NULL,
    subject_id CHAR(26) NOT NULL,
    object_type VARCHAR(40) NOT NULL,
    object_reference VARCHAR(255) NOT NULL,
    scope_type VARCHAR(30) NULL,
    scope_id CHAR(26) NULL,
    risk_tier VARCHAR(30) NOT NULL,
    status VARCHAR(30) NOT NULL,
    evidence_snapshot_json JSON NOT NULL,
    version_no INT NOT NULL DEFAULT 1,
    due_at DATETIME(6) NOT NULL,

    PRIMARY KEY (id),
    KEY idx_rbac_review_item_campaign (
        campaign_id,
        status,
        due_at
    ),
    KEY idx_rbac_review_item_subject (
        subject_id,
        status
    ),
    CONSTRAINT fk_rbac_review_item_campaign
        FOREIGN KEY (campaign_id)
        REFERENCES rbac_access_review_campaigns (id)
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

# 108. Table: rbac_access_review_decisions

```sql
CREATE TABLE rbac_access_review_decisions (
    id CHAR(26) NOT NULL,
    review_item_id CHAR(26) NOT NULL,
    reviewer_id CHAR(26) NOT NULL,
    decision VARCHAR(40) NOT NULL,
    reason_text VARCHAR(2000) NULL,
    decision_version INT NOT NULL,
    decided_at DATETIME(6) NOT NULL,
    evidence_reference VARCHAR(1000) NULL,

    PRIMARY KEY (id),
    KEY idx_rbac_review_decision_item (
        review_item_id,
        decided_at
    ),
    CONSTRAINT fk_rbac_review_decision_item
        FOREIGN KEY (review_item_id)
        REFERENCES rbac_access_review_items (id)
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

# 109. Table: rbac_access_review_remediations

```sql
CREATE TABLE rbac_access_review_remediations (
    id CHAR(26) NOT NULL,
    review_item_id CHAR(26) NOT NULL,
    action_type VARCHAR(50) NOT NULL,
    status VARCHAR(30) NOT NULL,
    assigned_to VARCHAR(180) NULL,
    due_at DATETIME(6) NOT NULL,
    completed_at DATETIME(6) NULL,
    verification_json JSON NULL,
    last_error_code VARCHAR(180) NULL,

    PRIMARY KEY (id),
    KEY idx_rbac_review_remediation_status (
        status,
        due_at
    ),
    CONSTRAINT fk_rbac_review_remediation_item
        FOREIGN KEY (review_item_id)
        REFERENCES rbac_access_review_items (id)
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

# 110. Table: rbac_access_review_reviewer_assignments

```sql
CREATE TABLE rbac_access_review_reviewer_assignments (
    id CHAR(26) NOT NULL,
    review_item_id CHAR(26) NOT NULL,
    reviewer_id CHAR(26) NOT NULL,
    assignment_type VARCHAR(40) NOT NULL,
    status VARCHAR(30) NOT NULL,
    delegated_from CHAR(26) NULL,
    assigned_at DATETIME(6) NOT NULL,
    due_at DATETIME(6) NOT NULL,

    PRIMARY KEY (id),
    UNIQUE KEY uq_rbac_review_reviewer (
        review_item_id,
        reviewer_id,
        assignment_type
    ),
    KEY idx_rbac_review_reviewer_due (
        reviewer_id,
        status,
        due_at
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

# 111. API Direction

```text
GET  /api/internal/v1/rbac/access-reviews/campaigns
POST /api/internal/v1/rbac/access-reviews/campaigns
GET  /api/internal/v1/rbac/access-reviews/campaigns/{campaignCode}
POST /api/internal/v1/rbac/access-reviews/campaigns/{campaignCode}/start
GET  /api/internal/v1/rbac/access-reviews/items
POST /api/internal/v1/rbac/access-reviews/items/{itemId}/decide
POST /api/internal/v1/rbac/access-reviews/items/{itemId}/delegate
POST /api/internal/v1/rbac/access-reviews/items/{itemId}/escalate
POST /api/internal/v1/rbac/access-reviews/remediations/{id}/execute
POST /api/internal/v1/rbac/access-reviews/reconcile
```

---

# 112. Error Codes

```text
RBAC_REVIEW_CAMPAIGN_NOT_FOUND
RBAC_REVIEW_CAMPAIGN_INVALID
RBAC_REVIEW_ITEM_NOT_FOUND
RBAC_REVIEW_REVIEWER_NOT_FOUND
RBAC_REVIEW_REVIEWER_CONFLICT
RBAC_REVIEW_SELF_CERTIFICATION_DENIED
RBAC_REVIEW_DECISION_INVALID
RBAC_REVIEW_DECISION_STALE
RBAC_REVIEW_DELEGATION_INVALID
RBAC_REVIEW_REMEDIATION_FAILED
RBAC_REVIEW_EXCEPTION_EXPIRED
RBAC_REVIEW_CAMPAIGN_OVERDUE
RBAC_REVIEW_EVIDENCE_MISSING
RBAC_REVIEW_RECONCILIATION_FAILED
```

---

# 113. Campaign Checklist

- [ ] Campaign owner assigned.
- [ ] Population rule defined.
- [ ] Risk tier defined.
- [ ] Reviewer strategy defined.
- [ ] Conflict rules enabled.
- [ ] Evidence requirements defined.
- [ ] Decision options defined.
- [ ] Remediation SLA defined.
- [ ] Escalation path defined.
- [ ] Notifications configured.
- [ ] Snapshot generated.
- [ ] Audit enabled.

---

# 114. Reviewer Checklist

- [ ] Reviewer active.
- [ ] Reviewer has correct scope.
- [ ] No self-certification conflict.
- [ ] No prohibited approval conflict.
- [ ] Evidence available.
- [ ] Due date known.
- [ ] Delegation policy known.
- [ ] Decision reason rules known.
- [ ] Sensitive data minimized.

---

# 115. Remediation Checklist

- [ ] Decision validated.
- [ ] Action mapped.
- [ ] Owner assigned.
- [ ] SLA set.
- [ ] Revocation executed.
- [ ] Sessions/caches invalidated where needed.
- [ ] Actual state verified.
- [ ] Failure retried/escalated.
- [ ] Evidence attached.
- [ ] Item closed only after verification.

---

# 116. UAT — Campaign Creation

- [ ] Valid campaign creates.
- [ ] Missing owner rejected.
- [ ] Invalid population rule rejected.
- [ ] Duplicate campaign code rejected.
- [ ] High-risk campaign assigns appropriate reviewer.
- [ ] Population snapshot generated.
- [ ] Inactive identities excluded or flagged.
- [ ] Campaign start audited.
- [ ] Notifications sent.

---

# 117. UAT — Reviewer Assignment

- [ ] Line manager resolves correctly.
- [ ] Role owner resolves correctly.
- [ ] Scope owner resolves correctly.
- [ ] Inactive reviewer replaced.
- [ ] Self-certification blocked.
- [ ] Delegation works.
- [ ] Circular delegation blocked.
- [ ] Reviewer conflict escalated.
- [ ] Due date applied.

---

# 118. UAT — Review Decisions

- [ ] Certify decision works.
- [ ] Revoke decision works.
- [ ] Modify scope works.
- [ ] Reduce permission works.
- [ ] Convert to JIT works.
- [ ] Exception requires expiry.
- [ ] Negative decision requires reason.
- [ ] Stale item version rejected.
- [ ] Evidence snapshot retained.

---

# 119. UAT — Privileged Review

- [ ] Standing privileged access visible.
- [ ] JIT history visible.
- [ ] Break-glass usage visible.
- [ ] Secret access history visible where permitted.
- [ ] Self-certification denied.
- [ ] Independent reviewer required.
- [ ] Convert-to-JIT remediation works.
- [ ] Immediate revoke works.
- [ ] Audit complete.

---

# 120. UAT — External & Service Accounts

- [ ] External sponsor shown.
- [ ] Expired engagement flagged.
- [ ] Missing sponsor creates finding.
- [ ] Service account owner shown.
- [ ] Dormant service account flagged.
- [ ] Human login violation flagged.
- [ ] Owner departure triggers review.
- [ ] Revoke remediation works.
- [ ] Evidence retained.

---

# 121. UAT — Remediation

- [ ] Role assignment revoked.
- [ ] Scope reduced.
- [ ] Permission removed.
- [ ] Account suspended.
- [ ] Temporary grant expired.
- [ ] Cache invalidated.
- [ ] Failed connector action escalated.
- [ ] Partial remediation remains open.
- [ ] Actual state verification works.

---

# 122. UAT — Deadline & Escalation

- [ ] Reminder sent.
- [ ] Overdue status applied.
- [ ] Escalation sent to manager.
- [ ] Critical overdue item suspends per policy.
- [ ] Non-response does not auto-certify.
- [ ] Campaign cannot complete with unresolved critical items.
- [ ] Exception approval works.
- [ ] Escalation audited.

---

# 123. UAT — Continuous Review

- [ ] New privileged grant triggers micro-review.
- [ ] Scope expansion triggers review.
- [ ] Dormant threshold triggers review.
- [ ] Manager change reassigns reviewer.
- [ ] New SoD conflict triggers review.
- [ ] Contract expiry triggers revoke.
- [ ] Material in-campaign change invalidates stale decision.
- [ ] Event-driven review evidence retained.

---

# 124. UAT — Reconciliation

- [ ] Uncertified active access detected.
- [ ] Missing reviewer detected.
- [ ] Reviewer conflict detected.
- [ ] Stale decision detected.
- [ ] Failed remediation detected.
- [ ] Expired exception detected.
- [ ] Overdue campaign detected.
- [ ] Missing evidence detected.
- [ ] Critical finding opens case.
- [ ] Report generated.

---

# 125. Definition of Done — SSOT-RBAC-09

SSOT-RBAC-09 dianggap selesai bila:

- [ ] certification object types tersedia;
- [ ] campaign types and frequencies tersedia;
- [ ] trigger and population model tersedia;
- [ ] campaign lifecycle tersedia;
- [ ] reviewer strategies tersedia;
- [ ] conflict/self-certification controls tersedia;
- [ ] evidence model tersedia;
- [ ] decision outcomes tersedia;
- [ ] bulk/auto-certification controls tersedia;
- [ ] privileged/service/external review tersedia;
- [ ] dormant/orphan/SoD review tersedia;
- [ ] remediation and SLA tersedia;
- [ ] notification/escalation tersedia;
- [ ] exception governance tersedia;
- [ ] continuous review tersedia;
- [ ] role/permission/scope owner certification tersedia;
- [ ] reconciliation tersedia;
- [ ] audit/logging/metrics tersedia;
- [ ] database direction tersedia;
- [ ] API direction tersedia;
- [ ] SDK contracts tersedia;
- [ ] error codes tersedia;
- [ ] checklists and UAT tersedia.

---

# 126. Implementation Roadmap

## Phase 1 — Campaign Foundation

- review policy;
- campaign entity;
- population builder;
- reviewer resolver;
- review items;
- basic decisions.

## Phase 2 — Remediation & Escalation

- remediation mapping;
- revocation integration;
- SLA;
- reminders;
- escalation;
- evidence snapshots.

## Phase 3 — High-Risk Certification

- privileged campaigns;
- service account review;
- external user review;
- SoD review;
- exception workflow;
- independent reviewers.

## Phase 4 — Continuous Review

- event-driven micro-certification;
- dormant/orphan triggers;
- in-campaign change detection;
- auto-remediation;
- risk prioritization;
- analytics.

## Phase 5 — Advanced Governance

- reviewer quality analytics;
- certification recommendations;
- identity governance dashboard;
- continuous controls monitoring;
- compliance evidence automation;
- external IGA integration.

---

# 127. Initial Implementation Backlog

```text
RBAC09-001 Access Review Policy Registry
RBAC09-002 Campaign Service
RBAC09-003 Population Builder
RBAC09-004 Reviewer Resolver
RBAC09-005 Reviewer Conflict Validator
RBAC09-006 Decision Service
RBAC09-007 Evidence Snapshot Service
RBAC09-008 Remediation Orchestrator
RBAC09-009 Notification & Escalation
RBAC09-010 Privileged Review Campaign
RBAC09-011 Service Account Review
RBAC09-012 External User Review
RBAC09-013 Continuous Review Triggers
RBAC09-014 Reconciliation Engine
RBAC09-015 Reviewer Analytics
RBAC09-016 Certification Dashboard
```

---

# 128. Approval Gate

Dokumen dapat menjadi Approved setelah:

- RBAC Architecture review;
- IAM Governance review;
- Security review;
- Audit/Compliance review;
- Tenant Administration review;
- Workflow review;
- Operations review;
- Privacy review;
- Quality Engineering review;
- UAT review.

---

# 129. Closing Statement

Access certification harus memastikan bahwa:

- access masih diperlukan;
- reviewer benar;
- scope masih tepat;
- dormant dan orphan access dihapus;
- privileged access direview lebih ketat;
- decisions menghasilkan remediation;
- exceptions berakhir;
- evidence lengkap;
- actual access state sesuai keputusan.

Certification bukan formalitas periodik.

Certification adalah kontrol aktif untuk mengurangi access accumulation, privilege creep, stale access, dan unauthorized standing privilege.
