# SSOT-MENU-02 — Menu Registry & Contribution Model

---

## Status Dokumen

| Item | Nilai |
|---|---|
| Kode | SSOT-MENU-02 |
| Judul | Menu Registry & Contribution Model |
| Versi | 1.0 |
| Status | Draft Architecture |
| Domain | Platform Kernel |
| Kategori | Navigation, Module Contribution & Authorization Projection |
| Cakupan | Menu Registry, Module Contributions, Namespace, Ownership, Ordering, Route Binding, Permission References, Lifecycle, Versioning, Reconciliation |
| Bergantung pada | SSOT-GOV-01, SSOT-GOV-02, SSOT-GOV-03, SSOT-SCOPE-01, SSOT-IAM-01, SSOT-RBAC-04, SSOT-RBAC-05, SSOT-RBAC-06, SSOT-MENU-01, SSOT-SDK-01, SSOT-SDK-04, SSOT-SDK-05 |
| Target Stack | PHP 8.1+, Composer, PSR-4, PDO, MySQL 8/MariaDB, HTML5, CSS3, Vanilla JavaScript |
| Target Evolusi | Dynamic Navigation Projection, Multi-Industry Modules, Remote Module Contributions, Microfrontend-ready |

---

# 1. Executive Summary

SSOT-MENU-02 menetapkan arsitektur resmi untuk menu registry dan contribution model pada Platform Kernel.

Dokumen ini mengatur:

- authoritative menu registry;
- menu item identity;
- menu namespace;
- menu ownership;
- contribution dari Platform Kernel;
- contribution dari business modules;
- contribution dari extension/plugin;
- parent-child hierarchy;
- section, group, item, action, dan separator;
- route binding;
- permission references;
- scope applicability;
- feature flag references;
- ordering;
- icon references;
- localization keys;
- tenant and industry applicability;
- registration;
- validation;
- collision handling;
- versioning;
- activation;
- deprecation;
- retirement;
- reconciliation;
- observability;
- database direction;
- API direction;
- SDK contracts;
- UAT;
- Definition of Done;
- roadmap.

Tujuan akhirnya adalah memastikan menu:

- tidak di-hard-code secara tersebar;
- memiliki single source of truth;
- dapat dikontribusikan oleh module secara aman;
- memiliki owner;
- memiliki namespace;
- memiliki route binding yang valid;
- memiliki permission reference yang valid;
- tidak menjadi sumber authorization;
- dapat disusun ulang secara deterministic;
- dapat direkonsiliasi;
- dapat diaudit;
- mendukung multi-tenant dan multi-industry platform.

---

# 2. Objectives

Framework harus:

- menyediakan canonical menu registry;
- memungkinkan module self-registration;
- mencegah collision;
- menjaga menu hierarchy konsisten;
- menjaga route binding valid;
- menjaga permission references valid;
- mendukung feature flags;
- mendukung localization;
- mendukung tenant dan industry projection;
- menyediakan lifecycle dan reconciliation.

---

# 3. Core Principles

```text
Registry Is Authoritative
Menu Visibility Is Not Authorization
Every Contribution Has an Owner
Every Item Has a Stable Code
Every Route Binding Must Be Valid
Every Permission Reference Must Be Canonical
Ordering Must Be Deterministic
Modules Contribute, Kernel Governs
No Silent Override
Every Change Must Be Auditable
```

---

# 4. Scope

Framework berlaku untuk:

```text
Primary Navigation
Sidebar Navigation
Top Navigation
Workspace Navigation
Module Navigation
Context Navigation
Action Navigation
Administration Navigation
Mobile Navigation
Tenant-Specific Navigation Projection
Industry-Specific Navigation Projection
```

---

# 5. Non-Scope

Dokumen ini tidak mengatur secara penuh:

- authorization engine;
- permission lifecycle;
- route framework internals;
- UI visual design system;
- frontend component implementation detail;
- page-level business logic.

---

# 6. Menu Registry Definition

Menu registry adalah canonical catalog seluruh menu contributions yang valid dan aktif.

---

# 7. Menu Contribution Definition

Menu contribution adalah deklarasi versioned dari kernel, module, plugin, atau extension yang ingin menambahkan atau memperluas navigation tree.

---

# 8. Registry Architecture

```text
Platform Menu Manifest
Module Menu Manifests
Plugin/Extension Manifests
        │
        ▼
Menu Contribution Validator
        │
        ├── Namespace Validation
        ├── Route Validation
        ├── Permission Validation
        ├── Parent Validation
        ├── Collision Detection
        ├── Ordering Validation
        └── Feature/Scope Validation
        │
        ▼
Canonical Menu Registry
        │
        ▼
Menu Projection Engine
```

---

# 9. Contribution Sources

```text
PLATFORM
MODULE
PLUGIN
EXTENSION
TENANT_CONFIGURATION
INDUSTRY_PACK
```

---

# 10. Source Precedence

Recommended precedence:

```text
Platform Guardrails
→ Module Contributions
→ Approved Extension Contributions
→ Tenant Projection Configuration
```

Tenant configuration may hide or reorder within guardrails, but must not redefine core semantics.

---

# 11. Menu Node Types

```text
ROOT
SECTION
GROUP
ITEM
ACTION
SEPARATOR
EXTERNAL_LINK
WORKSPACE
```

---

# 12. Root Node

Root is the logical top-level navigation container.

---

# 13. Section

Section groups related capabilities.

Examples:

```text
Clinical
Operations
Finance
Administration
Security
```

---

# 14. Group

Group provides secondary grouping inside section.

---

# 15. Item

Item represents navigable destination.

---

# 16. Action

Action represents context-specific command or workflow entry.

---

# 17. Separator

Separator is presentation metadata and should not carry authorization semantics.

---

# 18. External Link

External link requires approved URL policy.

---

# 19. Workspace

Workspace represents a dedicated navigation context for a module or persona.

---

# 20. Stable Menu Code

Format:

```text
{namespace}.{area}.{item}
```

Examples:

```text
platform.admin.users
homecare.visits.list
woundcare.assessments.list
billing.invoices.list
```

---

# 21. Namespace

Namespace must identify owner domain or module.

---

# 22. Reserved Namespaces

Recommended:

```text
platform
system
security
iam
rbac
audit
scope
config
```

---

# 23. Module Namespace

Business modules use their module code.

Examples:

```text
homecare
woundcare
patient
billing
crm
```

---

# 24. Namespace Ownership

Each namespace must have one accountable owner.

---

# 25. Menu Code Rules

Menu code must:

- lowercase;
- use dot separator;
- be stable;
- not include tenant IDs;
- not include environment names;
- not include display labels;
- not change due to localization.

---

# 26. Menu Identity

Menu code is the stable logical identity.

Database IDs remain implementation identifiers.

---

# 27. Menu Metadata

Minimum:

```text
menu_code
node_type
label_key
owner
namespace
parent_code
route_name
permission_code
status
order_weight
```

---

# 28. Optional Metadata

```text
icon_key
description_key
feature_flag
scope_model
tenant_applicability
industry_applicability
badge_provider
external_url
open_mode
mobile_visibility
```

---

# 29. Label Key

Use localization key, not hard-coded label as canonical value.

Example:

```text
menu.homecare.visits
```

---

# 30. Description Key

Optional localization key for help text.

---

# 31. Icon Key

Icon must reference approved icon registry.

---

# 32. Icon Governance

Module must not inject arbitrary executable SVG or unsafe HTML.

---

# 33. Parent Code

Parent must exist or be included in same manifest.

---

# 34. Orphan Node

Node without valid parent is rejected unless it is a root contribution.

---

# 35. Hierarchy Depth

Recommended maximum:

```text
4 levels
```

Exceptions require UX review.

---

# 36. Cyclic Hierarchy

Cycles are prohibited.

---

# 37. Route Binding

Navigable items should bind to canonical route name.

---

# 38. Route Name

Route name is preferred over raw path.

Example:

```text
homecare.visits.index
```

---

# 39. Raw Path

Raw path may be used only for approved external or legacy navigation.

---

# 40. Route Validation

Registry must validate:

- route exists;
- HTTP method/navigation compatibility;
- module active;
- route owner;
- route status;
- required parameters.

---

# 41. Dynamic Route Parameters

Menu item should not require arbitrary runtime resource IDs.

Use context navigation for resource-specific routes.

---

# 42. External URL

External URLs require:

- HTTPS where applicable;
- host allowlist;
- owner;
- risk review;
- open-mode policy;
- audit where needed.

---

# 43. Open Mode

```text
SAME_WINDOW
NEW_WINDOW
EMBEDDED_APPROVED
```

---

# 44. Permission Reference

Menu contribution may reference active canonical permission.

---

# 45. Permission Validation

Permission code must exist in SSOT-RBAC-06 catalog.

---

# 46. Authorization Boundary

Menu visibility does not authorize endpoint access.

---

# 47. No-Permission Items

Public or informational items may omit permission only if explicitly classified.

---

# 48. Multiple Permissions

Recommended model:

```text
ANY_OF
ALL_OF
```

---

# 49. Permission Expression

Complex arbitrary expressions are prohibited.

Use structured declarative conditions.

---

# 50. Scope Applicability

Menu item may declare:

```text
GLOBAL
TENANT
ORGANIZATION
CLINIC
DEPARTMENT
RESOURCE_CONTEXT
SELF
```

---

# 51. Scope Projection

Visibility depends on trusted active scope, not client-selected raw ID.

---

# 52. Feature Flag

Menu item may reference feature flag.

---

# 53. Feature Flag Rule

Feature flag can hide feature but cannot grant authorization.

---

# 54. Module State

Menu item should not render when owning module is inactive.

---

# 55. Tenant Applicability

Possible:

```text
ALL_TENANTS
SELECTED_TENANTS
TENANT_CAPABILITY
TENANT_CONFIGURATION
```

---

# 56. Industry Applicability

Possible industry packs:

```text
HEALTHCARE
RETAIL
FINANCE
EDUCATION
GENERAL
```

---

# 57. Multi-Industry Rule

Industry applicability controls projection, not route authorization.

---

# 58. Ordering

Ordering must be deterministic.

---

# 59. Order Weight

Recommended numeric range:

```text
100–9999
```

---

# 60. Ordering Algorithm

```text
parent
→ section weight
→ node weight
→ label key
→ menu code
```

---

# 61. Tie Handling

Tie resolved deterministically using menu code.

---

# 62. Reserved Ordering Bands

Example:

| Band | Owner |
|---|---|
| 100–999 | Platform |
| 1000–4999 | Core modules |
| 5000–7999 | Extensions |
| 8000–8999 | Tenant configuration |
| 9000–9999 | Experimental |

---

# 63. Reordering

Tenant may reorder within allowed zone.

---

# 64. Fixed Position

Critical system items may be fixed by platform policy.

---

# 65. Contribution Manifest

Every source should publish a menu manifest.

---

# 66. Manifest Example

```yaml
module: homecare
version: 1.4.0
namespace: homecare
menus:
  - code: homecare.visits
    type: SECTION
    label_key: menu.homecare.visits
    parent: platform.operations
    order: 2400

  - code: homecare.visits.list
    type: ITEM
    label_key: menu.homecare.visits.list
    parent: homecare.visits
    route: homecare.visits.index
    permission:
      mode: ANY_OF
      codes:
        - homecare.visit.list
    order: 2410
```

---

# 67. Manifest Metadata

Minimum:

```text
source
module_code
module_version
namespace
manifest_version
checksum
owner
menus
```

---

# 68. Manifest Version

Manifest schema version must be explicit.

---

# 69. Manifest Checksum

Checksum supports integrity and drift detection.

---

# 70. Manifest Registration

Flow:

```text
Discover
→ Parse
→ Validate
→ Detect Collision
→ Resolve Parent
→ Validate Route/Permission
→ Register
→ Activate
→ Publish Registry Version
```

---

# 71. Idempotent Registration

Registering same manifest version and checksum must be idempotent.

---

# 72. Changed Manifest

Changed checksum with same version is rejected.

---

# 73. Module Activation Gate

Module cannot become active if mandatory menu contributions fail validation.

---

# 74. Optional Contributions

Optional menu items may fail without blocking module only if manifest marks them optional.

---

# 75. Collision Definition

Collision occurs when:

- same menu code from different owner;
- same code with different node type;
- same code with different route;
- same code with incompatible permission;
- conflicting parent semantics;
- reserved namespace misuse.

---

# 76. Collision Result

```text
NO_COLLISION
IDENTICAL_IDEMPOTENT
COMPATIBLE_EXTENSION
CONFLICT
REQUIRES_REVIEW
```

---

# 77. Silent Override

Silent override is prohibited.

---

# 78. Extension Point

Platform or module may declare extension point.

---

# 79. Extension Point Example

```text
platform.admin.extensions
patient.profile.actions
homecare.visit.context_actions
```

---

# 80. Extension Point Metadata

```text
extension_point_code
allowed_node_types
allowed_namespaces
max_depth
ordering_band
required_permissions
owner
```

---

# 81. Contribution to Extension Point

Contributors must comply with extension point policy.

---

# 82. Cross-Module Parent

Cross-module parent is allowed only through published extension point.

---

# 83. Private Menu Node

Private/internal nodes cannot be used as parent by other modules.

---

# 84. Contribution Ownership

Every contribution retains source owner.

---

# 85. Platform Governance

Platform may reject contribution due to:

- security risk;
- poor UX;
- duplicate semantics;
- invalid route;
- invalid permission;
- namespace violation;
- excessive hierarchy depth.

---

# 86. Menu Lifecycle

```text
DRAFT
IN_REVIEW
APPROVED
ACTIVE
SUSPENDED
DEPRECATED
RETIRED
REJECTED
```

---

# 87. Draft

Not available for production projection.

---

# 88. Active

Available for projection when conditions match.

---

# 89. Suspended

Temporarily hidden globally.

---

# 90. Deprecated

Still available during transition.

---

# 91. Retired

No longer projected or referenced.

---

# 92. Deprecation

Deprecation must define:

- reason;
- replacement;
- affected roles/users;
- affected route;
- deadline;
- owner.

---

# 93. Retirement Preconditions

- no active child nodes;
- no tenant override reference;
- no route dependency;
- replacement available where needed;
- migration complete;
- audit retained.

---

# 94. Alias

Menu aliases should generally be avoided.

If used, aliases must be temporary and resolve to one canonical menu code.

---

# 95. Versioning

Registry must publish immutable registry versions.

---

# 96. Registry Version

Potential:

```text
2026.07.001
```

---

# 97. Snapshot

Each published registry version should have deterministic snapshot.

---

# 98. Rollback

Previous approved registry version should be recoverable.

---

# 99. Change Types

```text
ADD
UPDATE_METADATA
MOVE
REORDER
DEPRECATE
RETIRE
SUSPEND
REACTIVATE
```

---

# 100. Breaking Changes

Examples:

- remove menu code;
- move cross-workspace;
- change route semantics;
- change permission semantics;
- change parent with UX impact.

---

# 101. Compatibility

Metadata label/icon changes are usually non-breaking.

---

# 102. Parent Move

Parent move requires review because bookmarks, expectations, and tenant overrides may be affected.

---

# 103. Tenant Overrides

Tenant overrides may control:

- visibility within policy;
- ordering;
- label override;
- grouping;
- default workspace.

---

# 104. Tenant Override Restrictions

Tenant cannot:

- point to unauthorized route;
- replace permission code;
- expose inactive module;
- override platform guardrail;
- inject arbitrary HTML;
- use unapproved external URL.

---

# 105. Industry Pack Contribution

Industry pack may contribute approved groupings and default menu sets.

---

# 106. Personalization

User personalization may support favorites and collapsed state.

---

# 107. Personalization Boundary

User personalization must not change authorization semantics.

---

# 108. Favorites

Favorites reference stable menu code.

---

# 109. Recent Items

Recent items are user state, not registry entries.

---

# 110. Badge Provider

Menu may reference approved badge provider.

Examples:

```text
pending_approvals
unread_notifications
open_incidents
```

---

# 111. Badge Security

Badge count must respect same authorization and scope as destination.

---

# 112. Badge Performance

Badge providers should be bounded and cacheable.

---

# 113. Mobile Projection

Menu metadata may define mobile priority and compact behavior.

---

# 114. Accessibility

Menu entries should support:

- semantic labels;
- keyboard navigation;
- focus;
- accessible expanded/collapsed state;
- readable localization.

---

# 115. Localization

Every visible label should use translation key.

---

# 116. Missing Translation

Missing translation should use controlled fallback and emit finding.

---

# 117. Route Parameter Context

Contextual actions should be built from trusted current resource context.

---

# 118. Menu Registry Contract

```php
interface MenuRegistryInterface
{
    public function register(
        MenuContributionManifest $manifest
    ): MenuRegistrationResult;

    public function current(): MenuRegistrySnapshot;

    public function find(string $menuCode): ?MenuDefinition;
}
```

---

# 119. Contribution Validator Contract

```php
interface MenuContributionValidatorInterface
{
    public function validate(
        MenuContributionManifest $manifest
    ): MenuValidationReport;
}
```

---

# 120. Extension Point Registry Contract

```php
interface MenuExtensionPointRegistryInterface
{
    public function find(
        string $extensionPointCode
    ): ?MenuExtensionPoint;
}
```

---

# 121. Menu Definition

```php
final readonly class MenuDefinition
{
    public function __construct(
        public string $menuCode,
        public string $nodeType,
        public string $labelKey,
        public ?string $parentCode,
        public ?string $routeName,
        public array $permissionCodes,
        public int $orderWeight,
        public string $owner,
        public string $status,
    ) {
    }
}
```

---

# 122. Registry Snapshot

```php
final readonly class MenuRegistrySnapshot
{
    public function __construct(
        public string $version,
        public string $checksum,
        public array $nodes,
        public \DateTimeImmutable $publishedAt,
    ) {
    }
}
```

---

# 123. Validation Rules

Validator checks:

- schema;
- code format;
- namespace ownership;
- owner;
- parent;
- cycle;
- node type;
- route;
- permission;
- feature flag;
- ordering;
- external URL;
- translations;
- icon reference.

---

# 124. CI Gate

Build should fail on critical findings.

---

# 125. CI Findings

```text
INVALID_CODE
UNKNOWN_PARENT
CYCLE_DETECTED
UNKNOWN_ROUTE
UNKNOWN_PERMISSION
RESERVED_NAMESPACE
COLLISION
INVALID_EXTERNAL_URL
MISSING_OWNER
INVALID_ORDER
```

---

# 126. Runtime Registration

Runtime registration should occur during controlled bootstrap, not arbitrary user request.

---

# 127. Hot Reload

Hot reload may be supported in development.

Production changes require approved publish process.

---

# 128. Registry Cache

Registry snapshot may be cached.

---

# 129. Cache Key

```text
registry_version
tenant_id
industry_pack
locale
```

Authorization-specific projection belongs to MENU-03.

---

# 130. Cache Invalidation

Invalidate on:

- registry publish;
- module activation/deactivation;
- tenant override change;
- industry pack change;
- feature flag change where projection cache includes it.

---

# 131. Reconciliation

Compare registry against:

- manifests;
- routes;
- permission catalog;
- modules;
- feature flags;
- translations;
- icons;
- tenant overrides;
- extension points.

---

# 132. Reconciliation Outcomes

```text
MATCHED
MISSING_MANIFEST
MISSING_ROUTE
MISSING_PERMISSION
ORPHAN_NODE
CYCLE
OWNER_MISSING
STATUS_DRIFT
ORDER_DRIFT
TENANT_OVERRIDE_INVALID
```

---

# 133. Orphan Menu

Menu references missing parent, route, permission, module, or extension point.

---

# 134. Zombie Menu

Retired/inactive source still appears in registry.

---

# 135. Shadow Menu

Code exists in UI/template but not in registry.

---

# 136. Duplicate Navigation

Multiple menu codes point to same route and semantics without approved reason.

---

# 137. Reconciliation Frequency

- CI;
- bootstrap;
- deployment;
- nightly/weekly;
- after module change;
- after permission catalog change;
- after route change.

---

# 138. Audit Events

```text
MENU_CONTRIBUTION_SUBMITTED
MENU_CONTRIBUTION_VALIDATED
MENU_CONTRIBUTION_REJECTED
MENU_NODE_REGISTERED
MENU_NODE_ACTIVATED
MENU_NODE_SUSPENDED
MENU_NODE_DEPRECATED
MENU_NODE_RETIRED
MENU_REGISTRY_PUBLISHED
MENU_REGISTRY_ROLLED_BACK
MENU_COLLISION_DETECTED
MENU_RECONCILIATION_FAILED
```

---

# 139. Audit Metadata

```text
menu_code
namespace
owner
source
module_code
manifest_version
registry_version
change_type
route_name
permission_code
correlation_id
```

---

# 140. Metrics

```text
menu_registry_node_total
menu_registry_active_node_total
menu_contribution_total
menu_collision_total
menu_orphan_node_total
menu_missing_route_total
menu_missing_permission_total
menu_reconciliation_failure_total
menu_registry_publish_duration_seconds
menu_registry_cache_hit_ratio
```

---

# 141. KPIs

```text
Active menu nodes without owner = 0
Active menu nodes with missing route = 0
Active menu nodes with missing permission = 0
Menu hierarchy cycles = 0
Silent overrides = 0
Registry publication without validation = 0
Orphan tenant overrides = 0
```

---

# 142. KRIs

```text
Menu count growth
Hierarchy depth growth
Duplicate route bindings
Collision frequency
Tenant override failures
Missing translations
Registry drift
Inactive module menu exposure
```

---

# 143. Database Direction

Potential tables:

```text
menu_registry_nodes
menu_registry_versions
menu_contribution_manifests
menu_contribution_manifest_versions
menu_extension_points
menu_node_permissions
menu_node_conditions
menu_tenant_overrides
menu_registry_publications
menu_reconciliation_runs
menu_reconciliation_findings
```

---

# 144. Table: menu_registry_nodes

```sql
CREATE TABLE menu_registry_nodes (
    id CHAR(26) NOT NULL,
    menu_code VARCHAR(180) NOT NULL,
    namespace_code VARCHAR(100) NOT NULL,
    node_type VARCHAR(30) NOT NULL,
    label_key VARCHAR(255) NOT NULL,
    description_key VARCHAR(255) NULL,
    parent_menu_code VARCHAR(180) NULL,
    route_name VARCHAR(255) NULL,
    icon_key VARCHAR(180) NULL,
    order_weight INT NOT NULL,
    owner_reference VARCHAR(180) NOT NULL,
    source_type VARCHAR(40) NOT NULL,
    source_reference VARCHAR(180) NOT NULL,
    status VARCHAR(30) NOT NULL,
    current_version VARCHAR(100) NOT NULL,
    created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    updated_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6)
        ON UPDATE CURRENT_TIMESTAMP(6),

    PRIMARY KEY (id),
    UNIQUE KEY uq_menu_registry_code (menu_code),
    KEY idx_menu_registry_parent (
        parent_menu_code,
        status,
        order_weight
    ),
    KEY idx_menu_registry_namespace (
        namespace_code,
        status
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

# 145. Table: menu_contribution_manifests

```sql
CREATE TABLE menu_contribution_manifests (
    id CHAR(26) NOT NULL,
    manifest_code VARCHAR(180) NOT NULL,
    source_type VARCHAR(40) NOT NULL,
    source_reference VARCHAR(180) NOT NULL,
    namespace_code VARCHAR(100) NOT NULL,
    manifest_version VARCHAR(100) NOT NULL,
    schema_version VARCHAR(50) NOT NULL,
    checksum_sha256 CHAR(64) NOT NULL,
    owner_reference VARCHAR(180) NOT NULL,
    status VARCHAR(30) NOT NULL,
    registered_at DATETIME(6) NULL,
    created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),

    PRIMARY KEY (id),
    UNIQUE KEY uq_menu_manifest_version (
        manifest_code,
        manifest_version
    ),
    KEY idx_menu_manifest_source (
        source_type,
        source_reference,
        status
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

# 146. Table: menu_node_permissions

```sql
CREATE TABLE menu_node_permissions (
    id CHAR(26) NOT NULL,
    menu_node_id CHAR(26) NOT NULL,
    permission_code VARCHAR(180) NOT NULL,
    permission_mode VARCHAR(30) NOT NULL,
    status VARCHAR(30) NOT NULL,

    PRIMARY KEY (id),
    UNIQUE KEY uq_menu_node_permission (
        menu_node_id,
        permission_code
    ),
    CONSTRAINT fk_menu_node_permission_node
        FOREIGN KEY (menu_node_id)
        REFERENCES menu_registry_nodes (id)
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

# 147. Table: menu_extension_points

```sql
CREATE TABLE menu_extension_points (
    id CHAR(26) NOT NULL,
    extension_point_code VARCHAR(180) NOT NULL,
    owner_reference VARCHAR(180) NOT NULL,
    allowed_node_types_json JSON NOT NULL,
    allowed_namespaces_json JSON NULL,
    ordering_band_start INT NOT NULL,
    ordering_band_end INT NOT NULL,
    max_depth INT NOT NULL,
    status VARCHAR(30) NOT NULL,

    PRIMARY KEY (id),
    UNIQUE KEY uq_menu_extension_point_code (
        extension_point_code
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

# 148. Table: menu_registry_versions

```sql
CREATE TABLE menu_registry_versions (
    id CHAR(26) NOT NULL,
    registry_version VARCHAR(100) NOT NULL,
    snapshot_json JSON NOT NULL,
    checksum_sha256 CHAR(64) NOT NULL,
    status VARCHAR(30) NOT NULL,
    published_by VARCHAR(180) NULL,
    published_at DATETIME(6) NULL,
    supersedes_version VARCHAR(100) NULL,

    PRIMARY KEY (id),
    UNIQUE KEY uq_menu_registry_version (
        registry_version
    ),
    KEY idx_menu_registry_version_status (
        status,
        published_at
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

# 149. Table: menu_tenant_overrides

```sql
CREATE TABLE menu_tenant_overrides (
    id CHAR(26) NOT NULL,
    tenant_id CHAR(26) NOT NULL,
    menu_code VARCHAR(180) NOT NULL,
    visibility_override VARCHAR(30) NULL,
    order_weight_override INT NULL,
    label_key_override VARCHAR(255) NULL,
    parent_menu_code_override VARCHAR(180) NULL,
    status VARCHAR(30) NOT NULL,
    approved_by VARCHAR(180) NULL,
    created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),

    PRIMARY KEY (id),
    UNIQUE KEY uq_menu_tenant_override (
        tenant_id,
        menu_code
    ),
    KEY idx_menu_tenant_override_status (
        tenant_id,
        status
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

# 150. API Direction

```text
GET  /api/internal/v1/menu/registry
GET  /api/internal/v1/menu/registry/{menuCode}
POST /api/internal/v1/menu/contributions
POST /api/internal/v1/menu/contributions/{id}/validate
POST /api/internal/v1/menu/contributions/{id}/approve
POST /api/internal/v1/menu/registry/publish
POST /api/internal/v1/menu/registry/rollback
GET  /api/internal/v1/menu/extension-points
POST /api/internal/v1/menu/reconcile
GET  /api/internal/v1/menu/reconciliation-runs/{runId}
```

---

# 151. Error Codes

```text
MENU_REGISTRY_NODE_NOT_FOUND
MENU_REGISTRY_CODE_INVALID
MENU_REGISTRY_NAMESPACE_FORBIDDEN
MENU_REGISTRY_OWNER_REQUIRED
MENU_REGISTRY_PARENT_NOT_FOUND
MENU_REGISTRY_CYCLE_DETECTED
MENU_REGISTRY_ROUTE_NOT_FOUND
MENU_REGISTRY_PERMISSION_NOT_FOUND
MENU_REGISTRY_FEATURE_FLAG_NOT_FOUND
MENU_REGISTRY_COLLISION
MENU_REGISTRY_EXTENSION_POINT_INVALID
MENU_REGISTRY_MANIFEST_INVALID
MENU_REGISTRY_CHECKSUM_MISMATCH
MENU_REGISTRY_TENANT_OVERRIDE_INVALID
MENU_REGISTRY_PUBLICATION_FAILED
MENU_REGISTRY_RECONCILIATION_FAILED
```

---

# 152. Contribution Checklist

- [ ] Manifest schema valid.
- [ ] Namespace owned.
- [ ] Owner assigned.
- [ ] Menu codes valid.
- [ ] Parent nodes valid.
- [ ] No hierarchy cycle.
- [ ] Node types allowed.
- [ ] Route names valid.
- [ ] Permission codes active.
- [ ] Feature flags valid.
- [ ] Order weights valid.
- [ ] Translation keys present.
- [ ] Icon keys approved.
- [ ] External URLs approved.
- [ ] Checksum valid.

---

# 153. Extension Point Checklist

- [ ] Extension point published.
- [ ] Owner assigned.
- [ ] Allowed namespaces defined.
- [ ] Allowed node types defined.
- [ ] Ordering band defined.
- [ ] Maximum depth defined.
- [ ] Required permission policy defined.
- [ ] Contribution does not override parent semantics.
- [ ] Collision scan passed.

---

# 154. Publication Checklist

- [ ] All manifests validated.
- [ ] Critical findings zero.
- [ ] Routes reconciled.
- [ ] Permissions reconciled.
- [ ] Modules active.
- [ ] Translations available.
- [ ] Tenant overrides valid.
- [ ] Registry snapshot generated.
- [ ] Checksum generated.
- [ ] Rollback version available.
- [ ] Audit event emitted.

---

# 155. UAT — Manifest Registration

- [ ] Valid platform manifest registers.
- [ ] Valid module manifest registers.
- [ ] Same version/checksum is idempotent.
- [ ] Changed checksum/same version rejected.
- [ ] Unknown namespace rejected.
- [ ] Missing owner rejected.
- [ ] Invalid schema rejected.
- [ ] Registration audited.
- [ ] Module activation gate works.

---

# 156. UAT — Hierarchy

- [ ] Valid parent-child tree registers.
- [ ] Missing parent rejected.
- [ ] Cycle rejected.
- [ ] Excessive depth rejected.
- [ ] Cross-module parent rejected without extension point.
- [ ] Published extension point accepts valid contribution.
- [ ] Private node cannot be extended.
- [ ] Deterministic ordering works.

---

# 157. UAT — Route & Permission Binding

- [ ] Existing route accepted.
- [ ] Missing route rejected.
- [ ] Active permission accepted.
- [ ] Missing permission rejected.
- [ ] Retired permission rejected.
- [ ] Public item without permission requires classification.
- [ ] `ANY_OF` projection metadata accepted.
- [ ] Complex arbitrary expression rejected.
- [ ] Menu visibility does not authorize direct endpoint.

---

# 158. UAT — Collision

- [ ] Same code/same manifest is idempotent.
- [ ] Same code/different owner blocked.
- [ ] Same code/different route blocked.
- [ ] Reserved namespace misuse blocked.
- [ ] Duplicate route semantics flagged.
- [ ] Compatible extension accepted.
- [ ] Silent override impossible.
- [ ] Collision event audited.

---

# 159. UAT — Ordering

- [ ] Platform band ordering works.
- [ ] Module band ordering works.
- [ ] Tenant reorder stays within policy.
- [ ] Fixed-position item cannot be moved.
- [ ] Tie resolves by menu code.
- [ ] Invalid weight rejected.
- [ ] Registry snapshot order deterministic.

---

# 160. UAT — Tenant & Industry Applicability

- [ ] All-tenant item projects.
- [ ] Selected-tenant item projects correctly.
- [ ] Inactive tenant capability hides item.
- [ ] Industry pack applies correct nodes.
- [ ] Tenant override cannot expose inactive module.
- [ ] Tenant override cannot change permission.
- [ ] Cross-tenant override rejected.
- [ ] Guardrail item cannot be hidden.

---

# 161. UAT — Lifecycle

- [ ] Draft item not projected.
- [ ] Active item projected.
- [ ] Suspended item hidden.
- [ ] Deprecated item remains during transition.
- [ ] Retirement blocked with active children.
- [ ] Retired item removed.
- [ ] History retained.
- [ ] Rollback restores prior registry version.

---

# 162. UAT — Localization, Icon, Accessibility

- [ ] Valid translation key resolves.
- [ ] Missing translation emits finding.
- [ ] Approved icon renders.
- [ ] Unsafe icon rejected.
- [ ] Keyboard navigation metadata works.
- [ ] Accessible label present.
- [ ] Mobile visibility metadata respected.
- [ ] External link open mode valid.

---

# 163. UAT — Reconciliation

- [ ] Missing manifest detected.
- [ ] Missing route detected.
- [ ] Missing permission detected.
- [ ] Orphan node detected.
- [ ] Cycle detected.
- [ ] Status drift detected.
- [ ] Tenant override drift detected.
- [ ] Zombie menu detected.
- [ ] Shadow menu detected.
- [ ] Report generated.

---

# 164. UAT — Performance & Cache

- [ ] Registry publication time measured.
- [ ] Large registry tested.
- [ ] Snapshot checksum stable.
- [ ] Cache hit ratio measured.
- [ ] Publish invalidates cache.
- [ ] Tenant override invalidates projection cache.
- [ ] Module deactivation invalidates cache.
- [ ] Concurrent publication protected.
- [ ] Rollback remains bounded.

---

# 165. UAT — Security & Audit

- [ ] Unauthorized contribution denied.
- [ ] Unauthorized publication denied.
- [ ] Reserved namespace protected.
- [ ] External URL allowlist enforced.
- [ ] Arbitrary HTML/SVG rejected.
- [ ] Permission bypass impossible.
- [ ] Changes audited.
- [ ] Correlation ID retained.
- [ ] Sensitive tenant configuration not exposed.

---

# 166. Definition of Done — SSOT-MENU-02

SSOT-MENU-02 dianggap selesai bila:

- [ ] registry architecture tersedia;
- [ ] contribution sources tersedia;
- [ ] node types tersedia;
- [ ] code and namespace rules tersedia;
- [ ] metadata standard tersedia;
- [ ] hierarchy and cycle rules tersedia;
- [ ] route binding tersedia;
- [ ] permission reference tersedia;
- [ ] scope/feature/tenant/industry applicability tersedia;
- [ ] ordering model tersedia;
- [ ] contribution manifest tersedia;
- [ ] module registration flow tersedia;
- [ ] collision handling tersedia;
- [ ] extension point model tersedia;
- [ ] lifecycle/versioning/rollback tersedia;
- [ ] tenant override controls tersedia;
- [ ] localization/icon/accessibility controls tersedia;
- [ ] cache and reconciliation tersedia;
- [ ] audit/logging/metrics tersedia;
- [ ] database direction tersedia;
- [ ] API direction tersedia;
- [ ] SDK contracts tersedia;
- [ ] error codes tersedia;
- [ ] checklists dan UAT tersedia.

---

# 167. Implementation Roadmap

## Phase 1 — Registry Foundation

- canonical node schema;
- code validator;
- namespace ownership;
- hierarchy validator;
- registry repository;
- basic administration API.

## Phase 2 — Module Contributions

- manifest schema;
- manifest validator;
- idempotent registration;
- module activation gate;
- route/permission validation;
- collision detection.

## Phase 3 — Extension & Tenant Model

- extension points;
- tenant overrides;
- industry packs;
- ordering bands;
- localization/icon registry;
- external URL policy.

## Phase 4 — Publication & Reconciliation

- immutable snapshots;
- registry versions;
- publication workflow;
- rollback;
- route/permission reconciliation;
- dashboards and findings.

## Phase 5 — Distributed Navigation

- remote module contributions;
- signed manifests;
- microfrontend navigation contracts;
- registry distribution;
- edge caching;
- cross-application workspaces.

---

# 168. Initial Implementation Backlog

```text
MENUR-001 Menu Registry Node Schema
MENUR-002 Menu Code Validator
MENUR-003 Namespace Ownership Registry
MENUR-004 Hierarchy & Cycle Validator
MENUR-005 Route Binding Validator
MENUR-006 Permission Reference Validator
MENUR-007 Contribution Manifest Schema
MENUR-008 Manifest Registration Service
MENUR-009 Collision Detector
MENUR-010 Extension Point Registry
MENUR-011 Tenant Override Service
MENUR-012 Registry Snapshot Builder
MENUR-013 Registry Publication Service
MENUR-014 Registry Rollback Service
MENUR-015 Reconciliation Engine
MENUR-016 Registry Dashboard
```

---

# 169. Approval Gate

Dokumen dapat menjadi Approved setelah:

- Platform Architecture review;
- RBAC Owner review;
- Menu/UX Architecture review;
- Module SDK review;
- Security review;
- Multi-tenant isolation review;
- API/Route Governance review;
- Frontend review;
- Operations review;
- UAT review.

---

# 170. Closing Statement

Menu registry harus memastikan bahwa setiap navigation contribution:

- memiliki stable code;
- memiliki namespace;
- memiliki owner;
- memiliki parent yang valid;
- memiliki route yang valid;
- memiliki permission reference yang valid;
- memiliki ordering yang deterministic;
- memiliki lifecycle;
- dapat direkonsiliasi;
- dapat diaudit.

Module boleh berkontribusi terhadap navigation.

Module tidak boleh mengubah menu secara diam-diam, menimpa ownership module lain, atau menjadikan menu sebagai pengganti authorization.
