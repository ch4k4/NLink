# SSOT-RBAC-11 — Authorization Reconciliation & Drift Management

## Status Dokumen

| Item | Nilai |
|---|---|
| Kode | SSOT-RBAC-11 |
| Judul | Authorization Reconciliation & Drift Management |
| Versi | 1.0 |
| Status | Draft Architecture |
| Domain | Platform Kernel |
| Kategori | Authorization Assurance, Reconciliation & Drift Control |
| Cakupan | Desired State, Actual State, Role/Permission/Scope Drift, Runtime Cache Drift, Policy Drift, Remediation, Evidence |
| Bergantung pada | SSOT-GOV-01, SSOT-GOV-04, SSOT-GOV-05, SSOT-SCOPE-01, SSOT-SCOPE-04, SSOT-IAM-07, SSOT-RBAC-04, SSOT-RBAC-05, SSOT-RBAC-06, SSOT-RBAC-07, SSOT-RBAC-08, SSOT-RBAC-09, SSOT-RBAC-10, SSOT-MENU-03, SSOT-MENU-04, SSOT-AUDIT-01, SSOT-EVENT-01, SSOT-OBS-01, SSOT-TEST-01 |
| Target Stack | PHP 8.1+, PDO, MySQL 8/MariaDB, Queue/Event-ready |
| Target Evolusi | Continuous Authorization Assurance, Auto-Remediation, Policy Graph Verification, Distributed Authorization Reconciliation |

# 1. Executive Summary

SSOT-RBAC-11 menetapkan governance resmi untuk authorization reconciliation dan drift management.

Dokumen ini mengatur:

- desired authorization state;
- actual authorization state;
- reconciliation sources;
- role drift;
- permission drift;
- assignment drift;
- scope drift;
- policy drift;
- cache drift;
- session drift;
- menu/route drift;
- module contribution drift;
- temporary grant drift;
- privileged access drift;
- stale access;
- orphan access;
- remediation;
- auto-remediation;
- exception handling;
- evidence;
- metrics;
- database direction;
- API direction;
- SDK contracts;
- UAT;
- Definition of Done;
- implementation roadmap.

Tujuan akhirnya adalah memastikan bahwa authorization yang berjalan selalu sesuai dengan state yang disetujui dan terdokumentasi.

# 2. Objectives

Framework harus:

- mendefinisikan desired state;
- mengukur actual state;
- mendeteksi drift;
- mengklasifikasikan risk;
- memperbaiki drift;
- menyediakan evidence;
- menjaga tenant isolation;
- menjaga consistency antar caches;
- mendukung continuous reconciliation;
- mendukung distributed authorization.

# 3. Core Principles

```text
Desired State Is Authoritative
Runtime State Must Be Verifiable
Drift Must Be Detected
Critical Drift Must Fail Closed
Remediation Must Be Traceable
Auto-Remediation Must Be Governed
Caches Are Not Sources of Truth
Every Finding Has an Owner
Exceptions Must Expire
Evidence Must Be Reproducible
```

# 4. Scope

Berlaku untuk:

```text
Roles
Permissions
Assignments
Scope Bindings
Temporary Grants
Privileged Grants
Sessions
Tokens
Authorization Caches
Menu Projections
Route Bindings
Module Contributions
Policy Decisions
External Identity Mappings
```

# 5. Desired State

Desired state berasal dari:

- approved role catalog;
- permission catalog;
- assignment records;
- scope bindings;
- SoD policies;
- access review decisions;
- lifecycle state;
- temporary grants;
- privileged access grants;
- module status;
- tenant capability;
- approved exceptions.

# 6. Actual State

Actual state mencakup:

- database assignments;
- runtime policy output;
- active sessions;
- cached effective permissions;
- cached scope;
- menu projections;
- route enforcement;
- module runtime registration;
- external system access;
- token claims.

# 7. Reconciliation Model

```text
Desired State
→ Snapshot
→ Collect Actual State
→ Normalize
→ Compare
→ Classify Drift
→ Remediate
→ Verify
→ Close
```

# 8. Drift Categories

```text
MISSING
UNEXPECTED
STALE
EXPIRED
CONFLICTING
OVER_PRIVILEGED
UNDER_PRIVILEGED
INCONSISTENT
ORPHAN
ZOMBIE
VERSION_DRIFT
CACHE_DRIFT
POLICY_DRIFT
```

# 9. Role Drift

Examples:

- retired role still assigned;
- role version mismatch;
- missing owner;
- permission set differs from approved version;
- inheritance mismatch.

# 10. Permission Drift

Examples:

- unknown permission active;
- retired permission still enforced;
- route requires permission not in catalog;
- permission risk tier changed but role not recertified.

# 11. Assignment Drift

Examples:

- assignment exists without approval;
- expired assignment active;
- terminated identity still assigned;
- assignment scope differs from approved scope;
- duplicate assignment.

# 12. Scope Drift

Examples:

- identity moved clinic but old scope remains;
- scope cache stale;
- cross-tenant binding;
- resource scope no longer valid;
- inherited scope exceeds current policy.

# 13. Policy Drift

Examples:

- runtime policy version differs;
- decision engine uses old rules;
- deny rule missing;
- SoD policy disabled;
- eligibility rule not applied.

# 14. Cache Drift

Examples:

- revoked permission remains in cache;
- tenant switch preserves old projection;
- menu cache differs from effective permission;
- session claims not refreshed.

# 15. Session Drift

Examples:

- suspended identity has active session;
- role revoked but privileged session remains;
- MFA assurance downgraded but session still high assurance;
- terminated identity refresh token remains valid.

# 16. Menu and Route Drift

Examples:

- menu exposes inactive route;
- route allows access without matching permission;
- hidden menu but direct route authorization missing;
- route permission changed but menu projection not refreshed.

# 17. Module Drift

Examples:

- module inactive but permissions remain assignable;
- module removed but menu/routes remain;
- contribution manifest differs from registry;
- old module version contributes stale permissions.

# 18. Temporary Grant Drift

Examples:

- expired grant active;
- extension without approval;
- missing owner;
- grant converted to permanent without workflow.

# 19. Privileged Drift

Examples:

- standing privileged role where JIT is required;
- privileged assignment without current certification;
- break-glass account active without review;
- privileged session remains after grant expiry.

# 20. Drift Severity

```text
INFO
LOW
MODERATE
HIGH
CRITICAL
```

# 21. Severity Inputs

- tenant impact;
- privilege level;
- data sensitivity;
- cross-tenant exposure;
- duration;
- number of subjects;
- exploitability;
- business impact;
- compliance impact.

# 22. Critical Drift

Examples:

```text
Cross-tenant access
Terminated identity with privileged access
Authorization bypass
Active revoked credential
Missing deny control
Route without server-side authorization
```

# 23. Reconciliation Modes

```text
BUILD_TIME
DEPLOY_TIME
STARTUP
EVENT_DRIVEN
SCHEDULED
ON_DEMAND
POST_INCIDENT
```

# 24. Build-Time Reconciliation

Checks manifests, catalogs, dependencies, and policy schemas.

# 25. Deploy-Time Reconciliation

Checks package, migration, registry, and runtime readiness.

# 26. Startup Reconciliation

Checks active module, permissions, routes, caches, and policy versions.

# 27. Event-Driven Reconciliation

Triggered by:

- role change;
- permission change;
- assignment change;
- scope change;
- termination;
- module state change;
- policy publication;
- grant expiry.

# 28. Scheduled Reconciliation

Recommended:

```text
Critical authorization: hourly
General authorization: daily
Catalog integrity: deployment + daily
External systems: daily or per connector SLA
```

# 29. Snapshot

Desired and actual snapshots must be versioned and timestamped.

# 30. Snapshot Fields

```text
snapshot_id
source
version
tenant
scope
collected_at
checksum
record_count
```

# 31. Normalization

Sources must be normalized into canonical authorization graph.

# 32. Authorization Graph

Nodes:

```text
IDENTITY
ROLE
PERMISSION
SCOPE
POLICY
SESSION
MODULE
ROUTE
MENU
GRANT
```

Edges:

```text
ASSIGNED_TO
CONTAINS
INHERITS
SCOPED_TO
REQUIRES
CONTRIBUTES
PROJECTS
VALID_DURING
```

# 33. Comparison

Comparison must detect:

- missing nodes;
- unexpected nodes;
- changed edges;
- stale versions;
- invalid temporal state;
- policy incompatibility.

# 34. Finding Identity

Finding must have stable fingerprint to deduplicate repeated detections.

# 35. Finding Lifecycle

```text
OPEN
ACKNOWLEDGED
IN_REMEDIATION
PENDING_VERIFICATION
RESOLVED
ACCEPTED_EXCEPTION
SUPPRESSED
REOPENED
```

# 36. Finding Ownership

Owner resolved from:

- role owner;
- permission owner;
- tenant admin;
- module owner;
- IAM owner;
- security owner;
- operations owner.

# 37. Remediation Types

```text
AUTO_REVOKE
AUTO_EXPIRE
CACHE_INVALIDATE
SESSION_TERMINATE
REMOVE_ASSIGNMENT
REDUCE_SCOPE
DISABLE_ROUTE
DISABLE_MODULE_CONTRIBUTION
CREATE_REVIEW
CREATE_INCIDENT
MANUAL_REMEDIATION
```

# 38. Auto-Remediation Eligibility

Auto-remediation allowed when:

- rule deterministic;
- impact understood;
- rollback possible or unnecessary;
- no business ambiguity;
- policy approved;
- evidence retained.

# 39. Auto-Remediation Examples

- expire expired temporary grant;
- invalidate cache;
- terminate session of terminated identity;
- disable retired permission assignment;
- remove orphan menu contribution.

# 40. Manual Remediation

Required when:

- ownership ambiguous;
- business justification disputed;
- scope change complex;
- multiple systems affected;
- data impact significant;
- exception possible.

# 41. Fail-Closed Controls

Critical drift may cause:

- route denial;
- session termination;
- privileged access suspension;
- module isolation;
- tenant-level safety mode.

# 42. Remediation Verification

After remediation:

```text
Recollect Actual State
→ Compare Again
→ Confirm No Drift
→ Attach Evidence
→ Close
```

# 43. Remediation SLA

Suggested:

| Severity | SLA |
|---|---:|
| Critical | Immediate |
| High | 24 hours |
| Moderate | 5 business days |
| Low | 30 days |
| Info | Review cycle |

# 44. Exception

Exception requires:

- business reason;
- risk;
- owner;
- compensating controls;
- expiry;
- approver;
- review schedule.

# 45. Suppression

Suppression only for known false-positive pattern and must expire.

# 46. Repeated Drift

Repeated finding indicates systemic defect and requires root-cause analysis.

# 47. Root-Cause Categories

```text
PROCESS
CODE
CONFIGURATION
CACHE
CONNECTOR
HUMAN_ERROR
MIGRATION
POLICY
DATA_QUALITY
EVENT_ORDERING
```

# 48. Identity Lifecycle Integration

IAM-07 events must trigger reconciliation for joiner, mover, suspension, and leaver.

# 49. Identity Risk Integration

IAM-08 compromised state must trigger session/grant reconciliation.

# 50. Access Review Integration

RBAC-09 remediation decisions become desired-state changes.

# 51. Role Catalog Integration

RBAC-10 role versions define approved role composition.

# 52. Menu Integration

MENU-03 projection must align with effective permissions and scope.

# 53. Route Integration

MENU-04 route enforcement must align with permission catalog and policy.

# 54. Module Integration

MODULE-01 state determines whether contributions are active.

# 55. Event Ordering

Out-of-order lifecycle or assignment events must be detected.

# 56. Idempotency

Reconciliation and remediation operations must be idempotent.

# 57. Concurrency

Concurrent role/assignment changes require version checks.

# 58. Data Quality

Invalid identifiers, duplicate assignments, and missing owners are first-class findings.

# 59. External Systems

External access reconciliation requires connector-specific desired/actual mapping.

# 60. Connector Confidence

Connector must report:

```text
COMPLETE
PARTIAL
STALE
UNAVAILABLE
```

# 61. Partial Visibility

Unknown state must not be interpreted as compliant.

# 62. Evidence

Evidence includes:

- desired snapshot;
- actual snapshot;
- comparison output;
- decision;
- remediation action;
- verification result;
- timestamps;
- actor/system;
- correlation ID.

# 63. Audit Events

```text
RBAC_RECONCILIATION_STARTED
RBAC_RECONCILIATION_COMPLETED
RBAC_DRIFT_DETECTED
RBAC_DRIFT_ACKNOWLEDGED
RBAC_REMEDIATION_STARTED
RBAC_REMEDIATION_COMPLETED
RBAC_REMEDIATION_FAILED
RBAC_DRIFT_EXCEPTION_APPROVED
RBAC_DRIFT_REOPENED
```

# 64. Audit Metadata

```text
run_id
finding_id
tenant_id
subject_id
object_type
object_reference
drift_type
severity
desired_state
actual_state
remediation
correlation_id
```

# 65. Metrics

```text
rbac_reconciliation_run_total
rbac_reconciliation_duration_seconds
rbac_drift_finding_total
rbac_critical_drift_total
rbac_auto_remediation_total
rbac_remediation_failure_total
rbac_drift_age_seconds
rbac_reopened_finding_total
rbac_exception_total
rbac_unknown_state_total
```

# 66. KPIs

```text
Cross-tenant authorization drift = 0
Terminated identities with active access = 0
Expired grants still active = 0
Critical drift unresolved beyond SLA = 0
Runtime permission version drift = 0
Revoked access remaining in cache = 0
Authorization findings without owner = 0
```

# 67. KRIs

```text
Drift growth
Repeated drift fingerprint
Auto-remediation failure rate
Unknown external state
Cache drift frequency
Session drift frequency
Exception growth
Mean time to remediation
```

# 68. Database Direction

Potential tables:

```text
rbac_reconciliation_runs
rbac_reconciliation_snapshots
rbac_reconciliation_findings
rbac_reconciliation_finding_history
rbac_reconciliation_remediations
rbac_reconciliation_exceptions
rbac_reconciliation_connectors
rbac_reconciliation_policies
```

# 69. Table: rbac_reconciliation_runs

```sql
CREATE TABLE rbac_reconciliation_runs (
    id CHAR(26) NOT NULL,
    run_code VARCHAR(100) NOT NULL,
    run_type VARCHAR(40) NOT NULL,
    tenant_id CHAR(26) NULL,
    scope_type VARCHAR(30) NULL,
    scope_id CHAR(26) NULL,
    status VARCHAR(30) NOT NULL,
    started_at DATETIME(6) NOT NULL,
    completed_at DATETIME(6) NULL,
    finding_count INT NOT NULL DEFAULT 0,
    critical_count INT NOT NULL DEFAULT 0,

    PRIMARY KEY (id),
    UNIQUE KEY uq_rbac_reconciliation_run_code (
        run_code
    ),
    KEY idx_rbac_reconciliation_run_status (
        status,
        started_at
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

# 70. Table: rbac_reconciliation_snapshots

```sql
CREATE TABLE rbac_reconciliation_snapshots (
    id CHAR(26) NOT NULL,
    run_id CHAR(26) NOT NULL,
    snapshot_type VARCHAR(30) NOT NULL,
    source_code VARCHAR(100) NOT NULL,
    version_code VARCHAR(100) NULL,
    checksum_sha256 CHAR(64) NOT NULL,
    record_count BIGINT UNSIGNED NOT NULL,
    snapshot_reference VARCHAR(1000) NOT NULL,
    collected_at DATETIME(6) NOT NULL,

    PRIMARY KEY (id),
    KEY idx_rbac_reconciliation_snapshot_run (
        run_id,
        snapshot_type
    ),
    CONSTRAINT fk_rbac_reconciliation_snapshot_run
        FOREIGN KEY (run_id)
        REFERENCES rbac_reconciliation_runs (id)
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

# 71. Table: rbac_reconciliation_findings

```sql
CREATE TABLE rbac_reconciliation_findings (
    id CHAR(26) NOT NULL,
    run_id CHAR(26) NOT NULL,
    finding_fingerprint CHAR(64) NOT NULL,
    drift_type VARCHAR(50) NOT NULL,
    severity VARCHAR(30) NOT NULL,
    object_type VARCHAR(40) NOT NULL,
    object_reference VARCHAR(255) NOT NULL,
    tenant_id CHAR(26) NULL,
    subject_id CHAR(26) NULL,
    desired_state_json JSON NULL,
    actual_state_json JSON NULL,
    status VARCHAR(30) NOT NULL,
    owner_reference VARCHAR(180) NULL,
    due_at DATETIME(6) NULL,
    detected_at DATETIME(6) NOT NULL,

    PRIMARY KEY (id),
    KEY idx_rbac_reconciliation_finding_status (
        status,
        severity,
        due_at
    ),
    KEY idx_rbac_reconciliation_fingerprint (
        finding_fingerprint,
        status
    ),
    CONSTRAINT fk_rbac_reconciliation_finding_run
        FOREIGN KEY (run_id)
        REFERENCES rbac_reconciliation_runs (id)
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

# 72. Table: rbac_reconciliation_remediations

```sql
CREATE TABLE rbac_reconciliation_remediations (
    id CHAR(26) NOT NULL,
    finding_id CHAR(26) NOT NULL,
    remediation_type VARCHAR(50) NOT NULL,
    status VARCHAR(30) NOT NULL,
    requested_by VARCHAR(180) NOT NULL,
    executed_by VARCHAR(180) NULL,
    started_at DATETIME(6) NULL,
    completed_at DATETIME(6) NULL,
    verification_json JSON NULL,
    error_code VARCHAR(180) NULL,

    PRIMARY KEY (id),
    KEY idx_rbac_reconciliation_remediation_status (
        status,
        started_at
    ),
    CONSTRAINT fk_rbac_reconciliation_remediation_finding
        FOREIGN KEY (finding_id)
        REFERENCES rbac_reconciliation_findings (id)
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

# 73. API Direction

```text
POST /api/internal/v1/rbac/reconciliation/runs
GET  /api/internal/v1/rbac/reconciliation/runs
GET  /api/internal/v1/rbac/reconciliation/runs/{runCode}
GET  /api/internal/v1/rbac/reconciliation/findings
POST /api/internal/v1/rbac/reconciliation/findings/{findingId}/acknowledge
POST /api/internal/v1/rbac/reconciliation/findings/{findingId}/remediate
POST /api/internal/v1/rbac/reconciliation/findings/{findingId}/exception
POST /api/internal/v1/rbac/reconciliation/findings/{findingId}/verify
GET  /api/internal/v1/rbac/reconciliation/metrics
```

# 74. SDK Contracts

Potential:

```text
AuthorizationDesiredStateProviderInterface
AuthorizationActualStateCollectorInterface
AuthorizationReconciliationServiceInterface
AuthorizationDriftClassifierInterface
AuthorizationRemediationServiceInterface
AuthorizationReconciliationEvidenceInterface
```

# 75. Reconciliation Service Contract

```php
interface AuthorizationReconciliationServiceInterface
{
    public function run(
        AuthorizationReconciliationRequest $request
    ): AuthorizationReconciliationResult;
}
```

# 76. State Provider Contract

```php
interface AuthorizationDesiredStateProviderInterface
{
    public function snapshot(
        AuthorizationSnapshotRequest $request
    ): AuthorizationStateSnapshot;
}
```

# 77. Error Codes

```text
RBAC_RECONCILIATION_SOURCE_UNAVAILABLE
RBAC_RECONCILIATION_SNAPSHOT_INVALID
RBAC_RECONCILIATION_COMPARISON_FAILED
RBAC_DRIFT_CRITICAL
RBAC_DRIFT_OWNER_MISSING
RBAC_REMEDIATION_NOT_ALLOWED
RBAC_REMEDIATION_FAILED
RBAC_REMEDIATION_VERIFICATION_FAILED
RBAC_DRIFT_EXCEPTION_INVALID
RBAC_RECONCILIATION_PARTIAL_STATE
RBAC_RECONCILIATION_UNKNOWN_STATE
```

# 78. Reconciliation Checklist

- [ ] Desired source identified.
- [ ] Actual source identified.
- [ ] Snapshot versioned.
- [ ] Tenant/scope bounded.
- [ ] Data normalized.
- [ ] Drift classified.
- [ ] Severity assigned.
- [ ] Owner resolved.
- [ ] SLA assigned.
- [ ] Evidence retained.
- [ ] Critical fail-closed policy applied.
- [ ] Remediation verified.

# 79. Auto-Remediation Checklist

- [ ] Rule deterministic.
- [ ] Policy approved.
- [ ] Risk understood.
- [ ] Scope bounded.
- [ ] Idempotent.
- [ ] Rollback/recovery defined.
- [ ] Audit enabled.
- [ ] Verification enabled.
- [ ] Failure escalation configured.
- [ ] Exception path defined.

# 80. UAT — Role & Permission Drift

- [ ] Retired role assignment detected.
- [ ] Missing permission detected.
- [ ] Role version drift detected.
- [ ] Inheritance drift detected.
- [ ] Unknown permission detected.
- [ ] Permission risk change triggers review.
- [ ] Ownerless role detected.
- [ ] Remediation verified.

# 81. UAT — Assignment & Scope Drift

- [ ] Expired assignment detected.
- [ ] Terminated identity access detected.
- [ ] Old clinic scope detected.
- [ ] Cross-tenant scope detected.
- [ ] Duplicate assignment detected.
- [ ] Invalid eligibility detected.
- [ ] Auto-revoke works.
- [ ] Cache invalidated.
- [ ] Evidence retained.

# 82. UAT — Session & Cache Drift

- [ ] Revoked permission cache detected.
- [ ] Tenant switch stale cache detected.
- [ ] Suspended identity session detected.
- [ ] Expired privileged session detected.
- [ ] Stale token claims detected.
- [ ] Session termination works.
- [ ] Cache invalidation works.
- [ ] Recheck confirms clean state.

# 83. UAT — Menu, Route & Module Drift

- [ ] Menu exposes inactive route detected.
- [ ] Route missing permission detected.
- [ ] Module inactive contribution detected.
- [ ] Old module permission detected.
- [ ] Menu projection mismatch detected.
- [ ] Route disabled on critical drift.
- [ ] Contribution removed.
- [ ] Reconciliation report complete.

# 84. UAT — Privileged Drift

- [ ] Standing privilege without approval detected.
- [ ] Expired JIT grant detected.
- [ ] Break-glass account review missing.
- [ ] Privileged session survives grant expiry detected.
- [ ] Convert-to-JIT remediation works.
- [ ] Immediate suspension works.
- [ ] Security notified.
- [ ] Evidence retained.

# 85. UAT — Auto-Remediation

- [ ] Expired grant auto-expires.
- [ ] Terminated session auto-terminates.
- [ ] Revoked permission cache invalidates.
- [ ] Failed remediation retries.
- [ ] Unsafe remediation requires manual review.
- [ ] Verification failure reopens finding.
- [ ] Audit complete.
- [ ] Idempotent rerun produces no duplicate effects.

# 86. UAT — Exception & Suppression

- [ ] Exception requires owner.
- [ ] Exception requires expiry.
- [ ] Compensating control required.
- [ ] Expired exception reopens finding.
- [ ] False-positive suppression expires.
- [ ] Critical cross-tenant drift cannot be permanently suppressed.
- [ ] Review schedule enforced.
- [ ] Audit complete.

# 87. UAT — Reconciliation Operations

- [ ] Build-time run works.
- [ ] Deploy-time run works.
- [ ] Event-driven run works.
- [ ] Scheduled run works.
- [ ] Partial connector state flagged unknown.
- [ ] Duplicate finding deduplicated.
- [ ] Repeated drift linked to same fingerprint.
- [ ] Metrics updated.
- [ ] Evidence reproducible.

# 88. Definition of Done — SSOT-RBAC-11

SSOT-RBAC-11 dianggap selesai bila:

- [ ] desired state tersedia;
- [ ] actual state tersedia;
- [ ] reconciliation model tersedia;
- [ ] drift categories tersedia;
- [ ] role/permission drift tersedia;
- [ ] assignment/scope drift tersedia;
- [ ] policy/cache/session drift tersedia;
- [ ] menu/route/module drift tersedia;
- [ ] temporary/privileged drift tersedia;
- [ ] severity and SLA tersedia;
- [ ] reconciliation modes tersedia;
- [ ] snapshots and graph normalization tersedia;
- [ ] finding lifecycle tersedia;
- [ ] remediation and auto-remediation tersedia;
- [ ] fail-closed controls tersedia;
- [ ] exception/suppression tersedia;
- [ ] external connector handling tersedia;
- [ ] evidence and audit tersedia;
- [ ] metrics/KPI/KRI tersedia;
- [ ] database direction tersedia;
- [ ] API direction tersedia;
- [ ] SDK contracts tersedia;
- [ ] UAT and DoD tersedia.

# 89. Implementation Roadmap

## Phase 1 — Reconciliation Foundation

- desired state provider;
- actual state collectors;
- snapshot format;
- comparison engine;
- finding registry;
- basic reporting.

## Phase 2 — Core Authorization Drift

- role drift;
- permission drift;
- assignment drift;
- scope drift;
- cache drift;
- session drift.

## Phase 3 — Remediation

- remediation orchestrator;
- cache invalidation;
- session termination;
- assignment revoke;
- verification;
- escalation.

## Phase 4 — Extended Graph Reconciliation

- menu/route drift;
- module contribution drift;
- privileged drift;
- external connectors;
- continuous triggers;
- graph visualization.

## Phase 5 — Continuous Authorization Assurance

- automated root-cause analysis;
- policy graph verification;
- safe auto-remediation;
- distributed authorization reconciliation;
- drift prediction;
- control effectiveness dashboard.

# 90. Initial Implementation Backlog

```text
RBAC11-001 Desired State Provider
RBAC11-002 Actual State Collector
RBAC11-003 Snapshot Normalizer
RBAC11-004 Authorization Graph
RBAC11-005 Drift Comparator
RBAC11-006 Drift Classifier
RBAC11-007 Finding Registry
RBAC11-008 Remediation Orchestrator
RBAC11-009 Cache Invalidation Adapter
RBAC11-010 Session Revocation Adapter
RBAC11-011 Menu/Route Drift Scanner
RBAC11-012 Module Drift Scanner
RBAC11-013 External Connector Framework
RBAC11-014 Evidence Publisher
RBAC11-015 Reconciliation Scheduler
RBAC11-016 Authorization Assurance Dashboard
```

# 91. Approval Gate

Dokumen dapat menjadi Approved setelah:

- RBAC Architecture review;
- IAM Governance review;
- Security review;
- Scope Architecture review;
- Menu/Route review;
- Module Architecture review;
- Audit/Compliance review;
- Operations review;
- Quality Engineering review;
- UAT review.

# 92. Closing Statement

Authorization tidak cukup hanya dirancang dengan benar.

Authorization harus terus diverifikasi.

Setiap role, permission, scope, assignment, session, cache, menu, route, dan module contribution harus dapat dibandingkan dengan desired state dan diremediasi saat terjadi drift.
