# SSOT-MDM-03 — Data Ownership, Quality & Stewardship

---

## Status Dokumen

| Item | Nilai |
|---|---|
| Kode | SSOT-MDM-03 |
| Judul | Data Ownership, Quality & Stewardship |
| Versi | 1.0 |
| Status | Draft for Review |
| Domain | Platform Kernel |
| Kategori | Data Governance, Data Quality & Stewardship |
| Cakupan | Ownership, Stewardship, Accountability, Data Quality Rules, Scorecards, Issue Management, Certification, Remediation, Exceptions, Audit |
| Bergantung pada | SSOT-MDM-01, SSOT-MDM-02, SSOT-GOV-01, SSOT-GOV-04, SSOT-GOV-05, SSOT-SEC-01 |
| Target Stack | PHP 8.1+, MySQL 8/MariaDB, Modular Monolith, Multi-Tenant |
| Target Evolusi | Enterprise Data Governance, Data Products, Automated Quality Controls, Stewardship Workbench |

---

# 1. Executive Summary

SSOT-MDM-03 menetapkan framework resmi untuk ownership, data quality, dan stewardship seluruh data domain pada Platform Kernel dan module bisnis.

Dokumen ini mengatur:

- data ownership;
- stewardship roles;
- accountability;
- decision rights;
- data domain responsibility;
- critical data elements;
- quality dimensions;
- quality rules;
- validation controls;
- quality scorecards;
- issue management;
- remediation;
- exception management;
- data certification;
- stewardship workflow;
- escalation;
- quality monitoring;
- quality evidence;
- audit;
- metrics;
- UAT;
- Definition of Done.

Tujuan akhirnya adalah memastikan setiap data domain:

- memiliki owner;
- memiliki steward;
- memiliki custodian;
- memiliki definisi;
- memiliki quality targets;
- memiliki rules;
- memiliki issue workflow;
- memiliki escalation;
- memiliki evidence;
- dapat disertifikasi;
- dapat diaudit;
- tidak menjadi tanggung jawab “semua orang” tanpa accountability yang jelas.

---

# 2. Objectives

Framework harus:

- menetapkan accountability yang eksplisit;
- memastikan quality expectations;
- mengurangi data defects;
- mempercepat issue resolution;
- menjaga data fitness for purpose;
- mendukung regulatory and audit needs;
- menyediakan scorecard;
- mengontrol exceptions;
- mendukung stewardship operations;
- mendorong continuous improvement.

---

# 3. Core Principles

```text
Every Data Domain Has an Owner
Every Critical Data Element Has a Steward
Quality Must Be Measurable
Rules Must Be Explicit
Issues Must Be Owned
Exceptions Must Expire
Certification Requires Evidence
Remediation Must Be Traceable
Quality Is Shared but Accountability Is Clear
Stewardship Is an Operational Function
```

---

# 4. Scope

Framework berlaku untuk:

```text
Master Data
Reference Data
Transactional Data
Analytical Data
Configuration Data
Audit Data
Security Data
Integration Data
Operational Metadata
Data Products
```

---

# 5. Definitions

## Data Owner

Pihak yang memiliki accountability bisnis terhadap arti, penggunaan, quality, access, dan lifecycle data.

## Data Steward

Pihak yang menjalankan pengelolaan operasional quality, definition, issue, mapping, dan remediation.

## Technical Custodian

Pihak yang menjaga storage, availability, backup, security controls, dan implementation.

## Data Consumer

Pihak yang menggunakan data untuk proses, laporan, integration, atau keputusan.

## Data Producer

Pihak atau sistem yang membuat atau memperbarui data.

## Critical Data Element

Attribute atau data element yang kegagalannya dapat menimbulkan dampak signifikan terhadap bisnis, compliance, security, atau operasi.

---

# 6. Accountability Model

```text
Data Owner
    │
    ├── Defines Business Meaning
    ├── Approves Quality Targets
    ├── Approves Access and Lifecycle
    └── Resolves High-Impact Conflicts
        │
        ▼
Data Steward
    ├── Maintains Definitions
    ├── Monitors Quality
    ├── Resolves Issues
    └── Coordinates Consumers
        │
        ▼
Technical Custodian
    ├── Implements Controls
    ├── Maintains Storage
    ├── Runs Monitoring
    └── Preserves Evidence
```

---

# 7. Ownership Levels

```text
ENTERPRISE
DOMAIN
SUBDOMAIN
DATA_PRODUCT
DATA_ELEMENT
```

---

# 8. Enterprise Data Owner

Responsible for enterprise-wide data policy and cross-domain conflicts.

---

# 9. Domain Owner

Responsible for one data domain.

Examples:

- Patient;
- Organization;
- Clinic;
- Practitioner;
- Service;
- Billing;
- Security Identity.

---

# 10. Subdomain Owner

Responsible for a bounded subset of a domain.

---

# 11. Data Product Owner

Responsible for governed analytical or operational data product.

---

# 12. Data Element Owner

May be assigned for high-impact critical attributes.

---

# 13. Ownership Registry

Minimum fields:

```text
ownership_id
domain_code
subdomain
data_product
data_element
owner_reference
owner_type
effective_from
effective_to
status
```

---

# 14. Ownership Rules

- every active domain must have one accountable owner;
- co-ownership should be avoided;
- delegated responsibility does not remove accountability;
- ownership must be effective-dated;
- owner changes must be auditable.

---

# 15. Ownership Status

```text
PROPOSED
ACTIVE
DELEGATED
VACANT
EXPIRED
RETIRED
```

---

# 16. Vacant Ownership

Critical domains must not remain without active owner.

---

# 17. Ownership Delegation

Delegation must define:

- scope;
- delegate;
- authority;
- effective dates;
- retained accountability;
- approval.

---

# 18. Stewardship Model

Stewardship types:

```text
BUSINESS_STEWARD
TECHNICAL_STEWARD
DATA_QUALITY_STEWARD
REFERENCE_DATA_STEWARD
INTEGRATION_STEWARD
PRIVACY_STEWARD
```

---

# 19. Business Steward

Maintains:

- business definitions;
- business rules;
- accepted values;
- issue decisions;
- consumer communication.

---

# 20. Technical Steward

Coordinates:

- schema;
- lineage;
- integration;
- metadata;
- technical quality rules;
- reconciliation.

---

# 21. Data Quality Steward

Responsible for:

- quality monitoring;
- issue triage;
- root cause analysis;
- remediation tracking;
- scorecards.

---

# 22. Reference Data Steward

Responsible for:

- code sets;
- mappings;
- taxonomy;
- publication;
- deprecation.

---

# 23. Integration Steward

Responsible for:

- source-target mapping;
- interface quality;
- sync issues;
- reconciliation.

---

# 24. Privacy Steward

Advises on:

- sensitivity;
- purpose;
- minimization;
- retention;
- access;
- data subject obligations.

---

# 25. Steward Assignment

Minimum fields:

```text
stewardship_id
domain_code
scope
steward_reference
steward_type
responsibilities
effective_from
effective_to
status
```

---

# 26. Stewardship Capacity

Stewardship assignments should define expected capacity and SLA.

---

# 27. Stewardship RACI

| Activity | Owner | Steward | Custodian | Producer | Consumer |
|---|---|---|---|---|---|
| Define meaning | A | R | C | C | C |
| Define quality rules | A | R | C | C | C |
| Implement controls | C | C | R/A | R | I |
| Monitor quality | A | R | R | C | C |
| Resolve defects | A | R | C | R | C |
| Approve exceptions | A | R | C | I | I |
| Certify data | A | R | C | C | C |

---

# 28. Decision Rights

Data Owner approves:

- definitions;
- quality thresholds;
- critical rules;
- high-impact remediation;
- exceptions;
- certification;
- retirement.

Data Steward may approve:

- routine corrections;
- mappings;
- low-risk quality fixes;
- metadata updates;
- issue closure within delegated authority.

---

# 29. Data Domain Charter

Each domain should have charter containing:

```text
Purpose
Scope
Owner
Stewards
Systems
Critical Data Elements
Quality Targets
Consumers
Security Classification
Retention
Key Risks
```

---

# 30. Critical Data Elements

CDE criteria:

- regulatory importance;
- security importance;
- financial impact;
- patient/customer safety;
- operational dependency;
- reporting materiality;
- cross-domain reuse.

---

# 31. CDE Registry

Minimum:

```text
cde_code
domain
attribute
definition
owner
steward
sensitivity
quality_tier
source
consumers
controls
```

---

# 32. CDE Status

```text
PROPOSED
ACTIVE
DEPRECATED
RETIRED
```

---

# 33. CDE Quality Requirement

Every active CDE must have at least:

- validity rule;
- completeness rule where applicable;
- ownership;
- source;
- quality threshold;
- monitoring frequency.

---

# 34. Data Quality Dimensions

```text
ACCURACY
COMPLETENESS
VALIDITY
UNIQUENESS
CONSISTENCY
TIMELINESS
INTEGRITY
CONFORMITY
TRACEABILITY
ACCESSIBILITY
```

---

# 35. Accuracy

Data reflects real-world state correctly.

---

# 36. Completeness

Required data is present.

---

# 37. Validity

Data conforms to rules, types, ranges, and code sets.

---

# 38. Uniqueness

Duplicate records or identifiers are absent.

---

# 39. Consistency

Data is consistent across attributes, records, and systems.

---

# 40. Timeliness

Data is available and current within required period.

---

# 41. Integrity

Relationships and references remain valid.

---

# 42. Conformity

Data follows standard format and canonical model.

---

# 43. Traceability

Origin and transformations are known.

---

# 44. Accessibility

Authorized consumers can access data reliably.

---

# 45. Quality Tier

```text
TIER_0_MISSION_CRITICAL
TIER_1_CRITICAL
TIER_2_IMPORTANT
TIER_3_STANDARD
```

---

# 46. Tier 0

Failure may cause severe safety, security, regulatory, or operational impact.

---

# 47. Tier 1

Failure materially affects key processes.

---

# 48. Tier 2

Failure affects quality or efficiency but has workarounds.

---

# 49. Tier 3

Lower-risk supporting data.

---

# 50. Quality Rule Model

Minimum fields:

```text
rule_code
domain
data_element
dimension
description
expression
severity
threshold
frequency
owner
steward
scope
status
```

---

# 51. Rule Types

```text
FIELD_VALIDATION
CROSS_FIELD_VALIDATION
REFERENTIAL_INTEGRITY
DUPLICATE_DETECTION
FORMAT_VALIDATION
RANGE_VALIDATION
TIMELINESS_CHECK
RECONCILIATION
BUSINESS_RULE
STATISTICAL_ANOMALY
```

---

# 52. Quality Rule Severity

```text
INFO
WARNING
ERROR
CRITICAL
```

---

# 53. Rule Status

```text
DRAFT
IN_REVIEW
ACTIVE
SUSPENDED
DEPRECATED
RETIRED
```

---

# 54. Rule Execution Timing

```text
ON_ENTRY
ON_UPDATE
PRE_COMMIT
POST_COMMIT
BATCH
PRE_PUBLICATION
POST_SYNCHRONIZATION
ON_DEMAND
```

---

# 55. Preventive Controls

Prevent invalid data before persistence.

Examples:

- required fields;
- code set validation;
- uniqueness constraints;
- scope checks;
- type validation.

---

# 56. Detective Controls

Detect issues after creation.

Examples:

- duplicate scans;
- stale data checks;
- reconciliation;
- anomaly detection;
- orphan detection.

---

# 57. Corrective Controls

Correct or compensate for identified defects.

---

# 58. Rule Expression

Rule expressions should be versioned and testable.

---

# 59. Rule Scope

```text
GLOBAL
TENANT
ORGANIZATION
CLINIC
DOMAIN
DATA_PRODUCT
```

---

# 60. Rule Override

Tenant-specific rule override allowed only when policy permits and canonical requirements remain intact.

---

# 61. Quality Threshold

Threshold examples:

```text
100% critical identifier uniqueness
>= 99.5% required demographic completeness
< 1 hour synchronization lag
0 unresolved referential integrity errors
```

---

# 62. Quality Target

Targets must be:

- measurable;
- time-bound;
- owned;
- risk-based;
- approved.

---

# 63. Quality Measurement

Recommended:

```text
records_evaluated
records_passed
records_failed
pass_rate
failure_rate
trend
```

---

# 64. Quality Score

Potential weighted score:

```text
Σ(Dimension Score × Weight)
```

---

# 65. Scorecard Dimensions

Example:

```text
Completeness 20%
Validity 20%
Uniqueness 15%
Consistency 15%
Timeliness 15%
Integrity 15%
```

---

# 66. Scorecard Status

```text
GREEN
AMBER
RED
UNKNOWN
```

---

# 67. Scorecard Thresholds

Example:

```text
GREEN >= 98
AMBER >= 95 and < 98
RED < 95
```

Thresholds must be domain-specific.

---

# 68. Quality Certification

Certification confirms data meets approved fitness-for-purpose criteria.

---

# 69. Certification Types

```text
DOMAIN_CERTIFICATION
DATA_PRODUCT_CERTIFICATION
DATASET_CERTIFICATION
REFERENCE_SET_CERTIFICATION
MIGRATION_CERTIFICATION
```

---

# 70. Certification Status

```text
NOT_ASSESSED
CONDITIONALLY_CERTIFIED
CERTIFIED
CERTIFICATION_EXPIRED
REJECTED
REVOKED
```

---

# 71. Certification Requirements

- owner assigned;
- rules active;
- quality score meets target;
- critical issues closed;
- lineage available;
- access controls validated;
- exceptions approved;
- evidence complete.

---

# 72. Conditional Certification

Allowed with:

- documented conditions;
- owner;
- remediation deadline;
- compensating controls;
- approval;
- expiry.

---

# 73. Certification Expiry

Certification should expire after defined period or material change.

---

# 74. Re-Certification Triggers

- major schema change;
- source system change;
- migration;
- quality decline;
- ownership change;
- critical incident;
- new regulatory requirement.

---

# 75. Quality Issue Lifecycle

```text
DETECTED
→ TRIAGED
→ ASSIGNED
→ INVESTIGATING
→ REMEDIATING
→ VALIDATING
→ RESOLVED
→ CLOSED
```

Alternative terminal states:

```text
ACCEPTED_RISK
DUPLICATE
INVALID
DEFERRED
```

---

# 76. Quality Issue Record

Minimum:

```text
issue_code
domain
rule_code
severity
scope
detected_at
record_count
owner
steward
root_cause
remediation
target_date
status
```

---

# 77. Issue Severity

```text
SEV_1_CRITICAL
SEV_2_HIGH
SEV_3_MEDIUM
SEV_4_LOW
```

---

# 78. Severity Criteria

Consider:

- safety impact;
- regulatory impact;
- security impact;
- financial impact;
- number of records;
- affected tenants;
- operational disruption;
- duration.

---

# 79. Triage

Triage should determine:

- validity;
- severity;
- scope;
- owner;
- root cause category;
- immediate containment;
- SLA.

---

# 80. Root Cause Categories

```text
SOURCE_ENTRY
PROCESS
SYSTEM_VALIDATION
INTEGRATION
MAPPING
MIGRATION
DUPLICATE
MANUAL_CORRECTION
REFERENCE_DATA
CONFIGURATION
```

---

# 81. Remediation Types

```text
DATA_CORRECTION
RULE_FIX
PROCESS_CHANGE
SOURCE_FIX
MAPPING_FIX
REPROCESS
MERGE
TRAINING
CONTROL_ENHANCEMENT
```

---

# 82. Containment

Critical issue may require:

- block new data;
- suspend import;
- disable integration;
- quarantine records;
- freeze publication;
- notify consumers.

---

# 83. Remediation Plan

Minimum:

```text
action
owner
target_date
affected_records
method
validation
rollback_or_compensation
evidence
```

---

# 84. Bulk Data Correction

Requires:

- impact analysis;
- backup;
- preview;
- approval;
- script review;
- dry run;
- audit;
- post-correction validation.

---

# 85. Correction Provenance

Record:

- original value reference;
- corrected value;
- reason;
- actor;
- method;
- approval;
- timestamp.

---

# 86. Issue SLA

Example:

| Severity | Triage | Containment | Resolution Target |
|---|---:|---:|---:|
| SEV 1 | 4 hours | 8 hours | 1–3 business days |
| SEV 2 | 1 business day | 2 business days | 10 business days |
| SEV 3 | 3 business days | as needed | 30 business days |
| SEV 4 | 5 business days | not required | planned backlog |

---

# 87. SLA Exception

Requires approval and revised target.

---

# 88. Escalation

Escalate when:

- SLA breached;
- issue grows;
- critical consumer impacted;
- cross-tenant impact;
- regulatory impact;
- remediation fails;
- recurring defect.

---

# 89. Recurring Issue

Recurring issue should trigger control redesign, not repeated manual correction only.

---

# 90. Data Quality Incident

Critical quality defects may be managed as incident.

---

# 91. Quality Exception

Exception permits temporary non-compliance.

---

# 92. Exception Record

Minimum:

```text
exception_code
rule_code
scope
reason
risk
compensating_control
owner
approver
effective_from
expires_at
status
```

---

# 93. Exception Status

```text
REQUESTED
UNDER_REVIEW
APPROVED
REJECTED
EXPIRED
REVOKED
CLOSED
```

---

# 94. Exception Rules

- must be time-bound;
- cannot silently disable critical control;
- must be visible in scorecards;
- must have remediation path;
- must be auditable.

---

# 95. Stewardship Work Queue

Queue types:

```text
QUALITY_ISSUE
DUPLICATE_REVIEW
MAPPING_REVIEW
OWNERSHIP_GAP
CERTIFICATION_TASK
EXCEPTION_REVIEW
RECONCILIATION_MISMATCH
BULK_CHANGE_REVIEW
```

---

# 96. Work Item Fields

```text
work_item_code
type
domain
priority
owner
assignee
due_at
status
related_issue
related_record
```

---

# 97. Work Item Status

```text
OPEN
ASSIGNED
IN_PROGRESS
BLOCKED
AWAITING_APPROVAL
COMPLETED
CANCELLED
```

---

# 98. Stewardship Dashboard

Should show:

- open issues;
- overdue issues;
- quality score;
- CDE failures;
- ownership gaps;
- certification status;
- exception expiry;
- recurring issues;
- workload by steward.

---

# 99. Data Definition Governance

Every governed data element should have:

```text
business_name
technical_name
definition
domain
owner
steward
type
allowed_values
sensitivity
source
quality_rules
```

---

# 100. Business Glossary

Glossary should avoid conflicting definitions.

---

# 101. Definition Conflict

Conflict resolution authority belongs to Data Owner or Data Governance Council.

---

# 102. Metadata Stewardship

Stewards maintain:

- definitions;
- lineage;
- classifications;
- source mappings;
- usage notes;
- quality rules.

---

# 103. Producer Accountability

Producers must:

- validate at source;
- provide lineage;
- respond to defects;
- meet quality contracts;
- avoid undocumented transformations.

---

# 104. Consumer Accountability

Consumers must:

- use approved data;
- report defects;
- declare critical use;
- not alter canonical meaning;
- reconcile cached/local copies;
- respect versioning.

---

# 105. Data Contract

Producer-consumer contract may define:

```text
schema
semantics
quality targets
freshness
availability
version
ownership
issue channel
```

---

# 106. Data Product Quality

Data products should expose:

- owner;
- consumers;
- SLOs;
- schema;
- lineage;
- quality score;
- certification;
- support.

---

# 107. Data Quality SLO

Potential:

```text
freshness
completeness
availability
validity
reconciliation lag
```

---

# 108. Quality at Entry

Use UI/API validation and code set controls.

---

# 109. Quality at Integration

Use schema validation, mapping validation, idempotency, and reconciliation.

---

# 110. Quality at Rest

Use batch rules, constraints, anomaly checks, and duplicate detection.

---

# 111. Quality at Consumption

Use certification, version checks, and consumer reconciliation.

---

# 112. Multi-Tenant Quality

Quality rules must preserve tenant scope.

---

# 113. Tenant Quality Score

May calculate score per tenant, clinic, domain, and module.

---

# 114. Cross-Tenant Aggregation

Only authorized aggregated metrics may cross tenant boundaries.

---

# 115. Tenant-Specific Issues

Issue visibility must be tenant-scoped.

---

# 116. Shared Root Cause

Platform-wide defects may affect multiple tenants but evidence must preserve scope.

---

# 117. Privacy and Security

Quality operations must not expose unnecessary sensitive data.

---

# 118. Masked Quality Evidence

Use counts, hashes, and references where raw data is not required.

---

# 119. Sensitive Data Correction

Requires enhanced authorization and audit.

---

# 120. Quality Tool Access

Access roles:

```text
DATA_OWNER
DATA_STEWARD
QUALITY_ANALYST
TECHNICAL_CUSTODIAN
AUDITOR
READ_ONLY_CONSUMER
```

---

# 121. Segregation of Duties

High-impact correction should separate:

- requester;
- approver;
- executor;
- verifier.

---

# 122. Audit Events

Audit:

```text
DATA_OWNER_ASSIGNED
DATA_STEWARD_ASSIGNED
QUALITY_RULE_CREATED
QUALITY_RULE_CHANGED
QUALITY_ISSUE_DETECTED
QUALITY_ISSUE_ASSIGNED
QUALITY_REMEDIATION_APPLIED
QUALITY_EXCEPTION_APPROVED
DATA_CERTIFIED
DATA_CERTIFICATION_REVOKED
BULK_CORRECTION_EXECUTED
```

---

# 123. Audit Metadata

Include:

```text
actor
domain
rule
issue
scope
tenant
before_reference
after_reference
reason
approval
correlation
```

---

# 124. Evidence Requirements

Minimum evidence:

- ownership registry;
- stewardship registry;
- rule definitions;
- execution results;
- scorecards;
- issue records;
- remediation logs;
- exception approvals;
- certification reports;
- validation results.

---

# 125. Rule Testing

Quality rules should have:

- positive tests;
- negative tests;
- boundary tests;
- tenant isolation tests;
- performance tests for large volumes.

---

# 126. Rule Versioning

Rules must be versioned.

---

# 127. Rule Change Impact

Assess:

- scorecard changes;
- issue volume;
- false positives;
- false negatives;
- consumer impact;
- historical comparability.

---

# 128. Rule Deployment

Flow:

```text
Draft
→ Test
→ Review
→ Approve
→ Deploy
→ Observe
→ Tune
```

---

# 129. Rule Rollback

Previous rule version should be restorable.

---

# 130. False Positive Management

Stewards should be able to mark and analyze false positives.

---

# 131. False Negative Review

Critical incidents may reveal missing rules.

---

# 132. Quality Monitoring Frequency

Risk-based:

```text
REAL_TIME
HOURLY
DAILY
WEEKLY
MONTHLY
ON_DEMAND
```

---

# 133. Trend Analysis

Track:

- improvement;
- deterioration;
- recurring patterns;
- seasonal changes;
- impact of remediation.

---

# 134. Threshold Breach

Threshold breach should:

- create issue;
- alert steward;
- affect certification;
- trigger escalation based on severity.

---

# 135. Reconciliation Integration

Reconciliation mismatches should enter stewardship workflow.

---

# 136. Duplicate Integration

Duplicate candidates should enter stewardship queue.

---

# 137. MDM Integration

Ownership and quality metadata should integrate with MDM domain and reference registries.

---

# 138. API Direction

Potential endpoints:

```text
GET  /api/internal/v1/data-governance/ownership
POST /api/internal/v1/data-governance/ownership
GET  /api/internal/v1/data-governance/stewards
GET  /api/internal/v1/data-quality/rules
POST /api/internal/v1/data-quality/rules
POST /api/internal/v1/data-quality/runs
GET  /api/internal/v1/data-quality/issues
POST /api/internal/v1/data-quality/issues/{issueId}/assign
POST /api/internal/v1/data-quality/issues/{issueId}/resolve
POST /api/internal/v1/data-quality/certifications
GET  /api/internal/v1/data-quality/scorecards
```

---

# 139. API Security

Administrative operations require:

- authorization;
- tenant scope;
- audit;
- approval where applicable;
- idempotency for bulk operations.

---

# 140. Database Direction

Potential tables:

```text
dq_ownership_assignments
dq_steward_assignments
dq_domain_charters
dq_critical_data_elements
dq_quality_rules
dq_quality_rule_versions
dq_quality_runs
dq_quality_results
dq_quality_issues
dq_remediation_actions
dq_exceptions
dq_certifications
dq_stewardship_work_items
dq_scorecards
dq_audit_evidence
```

---

# 141. Table: dq_ownership_assignments

```sql
CREATE TABLE dq_ownership_assignments (
    id CHAR(26) NOT NULL,
    domain_code VARCHAR(100) NOT NULL,
    subdomain_code VARCHAR(100) NULL,
    data_product_code VARCHAR(100) NULL,
    data_element_code VARCHAR(180) NULL,
    owner_reference VARCHAR(180) NOT NULL,
    owner_type VARCHAR(30) NOT NULL,
    status VARCHAR(30) NOT NULL,
    effective_from DATETIME(6) NOT NULL,
    effective_to DATETIME(6) NULL,
    delegated_to VARCHAR(180) NULL,

    PRIMARY KEY (id),
    KEY idx_dq_owner_scope (
        domain_code,
        status,
        effective_from
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

# 142. Table: dq_steward_assignments

```sql
CREATE TABLE dq_steward_assignments (
    id CHAR(26) NOT NULL,
    domain_code VARCHAR(100) NOT NULL,
    scope_reference VARCHAR(255) NULL,
    steward_reference VARCHAR(180) NOT NULL,
    steward_type VARCHAR(40) NOT NULL,
    responsibilities_json JSON NULL,
    status VARCHAR(30) NOT NULL,
    effective_from DATETIME(6) NOT NULL,
    effective_to DATETIME(6) NULL,

    PRIMARY KEY (id),
    KEY idx_dq_steward_scope (
        domain_code,
        steward_type,
        status
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

# 143. Table: dq_critical_data_elements

```sql
CREATE TABLE dq_critical_data_elements (
    id CHAR(26) NOT NULL,
    cde_code VARCHAR(180) NOT NULL,
    domain_code VARCHAR(100) NOT NULL,
    data_element_path VARCHAR(500) NOT NULL,
    business_definition LONGTEXT NOT NULL,
    owner_reference VARCHAR(180) NOT NULL,
    steward_reference VARCHAR(180) NOT NULL,
    sensitivity VARCHAR(30) NOT NULL,
    quality_tier VARCHAR(30) NOT NULL,
    source_reference VARCHAR(255) NOT NULL,
    status VARCHAR(30) NOT NULL,

    PRIMARY KEY (id),
    UNIQUE KEY uq_dq_cde_code (
        cde_code
    ),
    KEY idx_dq_cde_domain (
        domain_code,
        status
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

# 144. Table: dq_quality_rules

```sql
CREATE TABLE dq_quality_rules (
    id CHAR(26) NOT NULL,
    rule_code VARCHAR(180) NOT NULL,
    domain_code VARCHAR(100) NOT NULL,
    data_element_path VARCHAR(500) NULL,
    dimension VARCHAR(30) NOT NULL,
    rule_type VARCHAR(50) NOT NULL,
    severity VARCHAR(30) NOT NULL,
    threshold_value DECIMAL(12,4) NULL,
    execution_frequency VARCHAR(30) NOT NULL,
    owner_reference VARCHAR(180) NOT NULL,
    steward_reference VARCHAR(180) NOT NULL,
    scope_type VARCHAR(30) NOT NULL,
    current_version VARCHAR(100) NOT NULL,
    status VARCHAR(30) NOT NULL,

    PRIMARY KEY (id),
    UNIQUE KEY uq_dq_rule_code (
        rule_code
    ),
    KEY idx_dq_rule_domain (
        domain_code,
        status,
        severity
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

# 145. Table: dq_quality_rule_versions

```sql
CREATE TABLE dq_quality_rule_versions (
    id CHAR(26) NOT NULL,
    quality_rule_id CHAR(26) NOT NULL,
    version VARCHAR(100) NOT NULL,
    expression_text LONGTEXT NOT NULL,
    test_reference VARCHAR(1000) NULL,
    change_summary VARCHAR(1000) NULL,
    approved_by VARCHAR(180) NULL,
    effective_from DATETIME(6) NOT NULL,
    effective_to DATETIME(6) NULL,
    status VARCHAR(30) NOT NULL,

    PRIMARY KEY (id),
    UNIQUE KEY uq_dq_rule_version (
        quality_rule_id,
        version
    ),
    CONSTRAINT fk_dq_rule_version_rule
        FOREIGN KEY (quality_rule_id)
        REFERENCES dq_quality_rules (id)
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

# 146. Table: dq_quality_runs

```sql
CREATE TABLE dq_quality_runs (
    id CHAR(26) NOT NULL,
    run_code VARCHAR(100) NOT NULL,
    domain_code VARCHAR(100) NOT NULL,
    scope_type VARCHAR(30) NOT NULL,
    tenant_id CHAR(26) NULL,
    status VARCHAR(30) NOT NULL,
    started_at DATETIME(6) NOT NULL,
    completed_at DATETIME(6) NULL,
    records_evaluated BIGINT UNSIGNED NOT NULL DEFAULT 0,
    records_failed BIGINT UNSIGNED NOT NULL DEFAULT 0,
    triggered_by VARCHAR(180) NULL,

    PRIMARY KEY (id),
    UNIQUE KEY uq_dq_run_code (
        run_code
    ),
    KEY idx_dq_run_status (
        domain_code,
        status,
        started_at
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

# 147. Table: dq_quality_results

```sql
CREATE TABLE dq_quality_results (
    id CHAR(26) NOT NULL,
    quality_run_id CHAR(26) NOT NULL,
    quality_rule_id CHAR(26) NOT NULL,
    records_evaluated BIGINT UNSIGNED NOT NULL,
    records_passed BIGINT UNSIGNED NOT NULL,
    records_failed BIGINT UNSIGNED NOT NULL,
    pass_rate DECIMAL(8,4) NOT NULL,
    threshold_met_flag TINYINT(1) NOT NULL,
    evidence_reference VARCHAR(1000) NULL,

    PRIMARY KEY (id),
    UNIQUE KEY uq_dq_result_rule_run (
        quality_run_id,
        quality_rule_id
    ),
    CONSTRAINT fk_dq_result_run
        FOREIGN KEY (quality_run_id)
        REFERENCES dq_quality_runs (id),
    CONSTRAINT fk_dq_result_rule
        FOREIGN KEY (quality_rule_id)
        REFERENCES dq_quality_rules (id)
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

# 148. Table: dq_quality_issues

```sql
CREATE TABLE dq_quality_issues (
    id CHAR(26) NOT NULL,
    issue_code VARCHAR(100) NOT NULL,
    domain_code VARCHAR(100) NOT NULL,
    quality_rule_id CHAR(26) NULL,
    severity VARCHAR(30) NOT NULL,
    scope_type VARCHAR(30) NOT NULL,
    tenant_id CHAR(26) NULL,
    affected_record_count BIGINT UNSIGNED NOT NULL DEFAULT 0,
    owner_reference VARCHAR(180) NOT NULL,
    steward_reference VARCHAR(180) NOT NULL,
    root_cause_category VARCHAR(50) NULL,
    status VARCHAR(30) NOT NULL,
    target_date DATE NULL,
    detected_at DATETIME(6) NOT NULL,
    resolved_at DATETIME(6) NULL,

    PRIMARY KEY (id),
    UNIQUE KEY uq_dq_issue_code (
        issue_code
    ),
    KEY idx_dq_issue_status (
        severity,
        status,
        target_date
    ),
    CONSTRAINT fk_dq_issue_rule
        FOREIGN KEY (quality_rule_id)
        REFERENCES dq_quality_rules (id)
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

# 149. Table: dq_remediation_actions

```sql
CREATE TABLE dq_remediation_actions (
    id CHAR(26) NOT NULL,
    quality_issue_id CHAR(26) NOT NULL,
    action_type VARCHAR(50) NOT NULL,
    description_text LONGTEXT NOT NULL,
    owner_reference VARCHAR(180) NOT NULL,
    target_date DATE NULL,
    status VARCHAR(30) NOT NULL,
    validation_reference VARCHAR(1000) NULL,
    completed_at DATETIME(6) NULL,

    PRIMARY KEY (id),
    KEY idx_dq_remediation_status (
        status,
        target_date
    ),
    CONSTRAINT fk_dq_remediation_issue
        FOREIGN KEY (quality_issue_id)
        REFERENCES dq_quality_issues (id)
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

# 150. Table: dq_exceptions

```sql
CREATE TABLE dq_exceptions (
    id CHAR(26) NOT NULL,
    exception_code VARCHAR(100) NOT NULL,
    quality_rule_id CHAR(26) NOT NULL,
    scope_reference VARCHAR(255) NOT NULL,
    reason_text LONGTEXT NOT NULL,
    risk_rating VARCHAR(30) NOT NULL,
    compensating_control LONGTEXT NOT NULL,
    owner_reference VARCHAR(180) NOT NULL,
    approved_by VARCHAR(180) NULL,
    status VARCHAR(30) NOT NULL,
    effective_from DATETIME(6) NOT NULL,
    expires_at DATETIME(6) NOT NULL,

    PRIMARY KEY (id),
    UNIQUE KEY uq_dq_exception_code (
        exception_code
    ),
    KEY idx_dq_exception_status (
        status,
        expires_at
    ),
    CONSTRAINT fk_dq_exception_rule
        FOREIGN KEY (quality_rule_id)
        REFERENCES dq_quality_rules (id)
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

# 151. Table: dq_certifications

```sql
CREATE TABLE dq_certifications (
    id CHAR(26) NOT NULL,
    certification_code VARCHAR(100) NOT NULL,
    certification_type VARCHAR(50) NOT NULL,
    subject_reference VARCHAR(255) NOT NULL,
    owner_reference VARCHAR(180) NOT NULL,
    score DECIMAL(8,4) NULL,
    status VARCHAR(40) NOT NULL,
    conditions_json JSON NULL,
    evidence_reference VARCHAR(1000) NULL,
    certified_at DATETIME(6) NULL,
    expires_at DATETIME(6) NULL,

    PRIMARY KEY (id),
    UNIQUE KEY uq_dq_certification_code (
        certification_code
    ),
    KEY idx_dq_certification_status (
        status,
        expires_at
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

# 152. SDK Contract Direction

Potential contracts:

```text
DataOwnershipServiceInterface
StewardshipServiceInterface
DataQualityRuleServiceInterface
DataQualityExecutionServiceInterface
DataQualityIssueServiceInterface
DataCertificationServiceInterface
QualityScorecardServiceInterface
```

---

# 153. Data Ownership Service

```php
interface DataOwnershipServiceInterface
{
    public function ownerOf(
        string $domain,
        ?string $dataElement = null
    ): ?DataOwnershipRecord;

    public function assertOwner(
        string $domain,
        string $ownerReference
    ): void;
}
```

---

# 154. Data Quality Validation

```php
interface DataQualityExecutionServiceInterface
{
    public function evaluate(
        string $domain,
        DataQualityExecutionContext $context
    ): DataQualityRunResult;
}
```

---

# 155. Data Quality Issue Service

```php
interface DataQualityIssueServiceInterface
{
    public function create(
        DataQualityIssueRequest $request
    ): DataQualityIssue;

    public function assign(
        string $issueId,
        string $stewardReference
    ): void;

    public function resolve(
        string $issueId,
        DataQualityResolution $resolution
    ): void;
}
```

---

# 156. Event Codes

```text
DQ_OWNER_ASSIGNED
DQ_OWNER_CHANGED
DQ_STEWARD_ASSIGNED
DQ_CDE_REGISTERED
DQ_RULE_CREATED
DQ_RULE_ACTIVATED
DQ_RULE_FAILED
DQ_QUALITY_THRESHOLD_BREACHED
DQ_ISSUE_CREATED
DQ_ISSUE_ESCALATED
DQ_REMEDIATION_STARTED
DQ_REMEDIATION_COMPLETED
DQ_EXCEPTION_APPROVED
DQ_EXCEPTION_EXPIRED
DQ_DATA_CERTIFIED
DQ_CERTIFICATION_REVOKED
```

---

# 157. Error Codes

```text
DQ_OWNER_NOT_FOUND
DQ_STEWARD_NOT_FOUND
DQ_DOMAIN_UNOWNED
DQ_CDE_NOT_FOUND
DQ_RULE_NOT_FOUND
DQ_RULE_INVALID
DQ_RULE_EXECUTION_FAILED
DQ_THRESHOLD_BREACHED
DQ_ISSUE_NOT_FOUND
DQ_ISSUE_ASSIGNMENT_INVALID
DQ_REMEDIATION_FAILED
DQ_EXCEPTION_INVALID
DQ_EXCEPTION_EXPIRED
DQ_CERTIFICATION_REQUIREMENTS_NOT_MET
DQ_CROSS_TENANT_SCOPE_INVALID
```

---

# 158. Metrics

```text
dq_owned_domain_ratio
dq_unowned_domain_total
dq_active_steward_total
dq_cde_total
dq_rule_total
dq_rule_failure_total
dq_quality_score
dq_open_issue_total
dq_overdue_issue_total
dq_remediation_lead_time
dq_exception_total
dq_expired_exception_total
dq_certified_dataset_total
dq_certification_failure_total
```

---

# 159. KPIs

Initial targets:

```text
Active domains with owner = 100%
Critical domains with steward = 100%
Tier 0 CDEs with active rules = 100%
Critical quality issues overdue = 0
Expired active exceptions = 0
Certified critical data products = 100%
Cross-tenant quality evidence violations = 0
```

---

# 160. KRIs

```text
Unowned critical domains
Quality score decline
Recurring issue count
Overdue remediation
Exception growth
Certification revocations
False-positive rate
Bulk correction frequency
```

---

# 161. Dashboard Views

Recommended:

- ownership coverage;
- stewardship assignments;
- CDE coverage;
- quality scores by domain;
- issues by severity;
- overdue remediation;
- recurring root causes;
- active exceptions;
- certification status;
- tenant quality trends.

---

# 162. Reference Ownership Record

```yaml
domain: patient
owner: patient_data_owner
owner_type: DOMAIN
status: ACTIVE
effective_from: 2026-07-05
delegated_to: patient_operations_lead
```

---

# 163. Reference CDE Record

```yaml
cde_code: PATIENT-NATIONAL-ID
domain: patient
attribute: national_identifier
definition: Government-issued primary patient identity number
owner: patient_data_owner
steward: patient_data_steward
sensitivity: RESTRICTED
quality_tier: TIER_0_MISSION_CRITICAL
source: patient_master
```

---

# 164. Reference Quality Rule

```yaml
rule_code: DQ-PATIENT-001
domain: patient
data_element: national_identifier
dimension: UNIQUENESS
rule_type: DUPLICATE_DETECTION
severity: CRITICAL
threshold: 100
frequency: ON_ENTRY
owner: patient_data_owner
steward: patient_data_steward
status: ACTIVE
```

---

# 165. Reference Quality Issue

```yaml
issue_code: DQI-2026-0012
domain: patient
rule_code: DQ-PATIENT-001
severity: SEV_1_CRITICAL
affected_records: 14
root_cause: MIGRATION
owner: patient_data_owner
steward: patient_data_steward
status: REMEDIATING
target_date: 2026-07-08
```

---

# 166. Reference Certification

```yaml
certification_code: DQCERT-PATIENT-Q3-2026
type: DOMAIN_CERTIFICATION
subject: patient
score: 99.2
status: CERTIFIED
certified_at: 2026-07-05
expires_at: 2026-10-05
```

---

# 167. Ownership Onboarding Checklist

- [ ] Domain defined.
- [ ] Owner assigned.
- [ ] Steward assigned.
- [ ] Technical custodian assigned.
- [ ] Decision rights documented.
- [ ] Delegation documented.
- [ ] Effective dates recorded.
- [ ] Escalation path defined.
- [ ] Consumer representatives identified.
- [ ] Ownership evidence retained.

---

# 168. CDE Checklist

- [ ] CDE code unique.
- [ ] Business definition clear.
- [ ] Owner assigned.
- [ ] Steward assigned.
- [ ] Sensitivity classified.
- [ ] Source defined.
- [ ] Consumers identified.
- [ ] Quality tier assigned.
- [ ] Rules active.
- [ ] Threshold approved.
- [ ] Monitoring frequency defined.

---

# 169. Quality Rule Checklist

- [ ] Rule code unique.
- [ ] Dimension defined.
- [ ] Expression testable.
- [ ] Severity defined.
- [ ] Threshold defined.
- [ ] Scope defined.
- [ ] Owner assigned.
- [ ] Steward assigned.
- [ ] Tests pass.
- [ ] Effective dates defined.
- [ ] Version recorded.
- [ ] Deployment approved.

---

# 170. Quality Issue Checklist

- [ ] Issue valid.
- [ ] Severity assigned.
- [ ] Scope assessed.
- [ ] Tenant impact identified.
- [ ] Owner assigned.
- [ ] Steward assigned.
- [ ] Root cause assessed.
- [ ] Containment defined.
- [ ] SLA target assigned.
- [ ] Remediation planned.
- [ ] Validation defined.
- [ ] Evidence retained.

---

# 171. Certification Checklist

- [ ] Ownership complete.
- [ ] Stewardship active.
- [ ] CDEs identified.
- [ ] Rules active.
- [ ] Quality score meets target.
- [ ] Critical issues closed.
- [ ] Exceptions valid.
- [ ] Lineage available.
- [ ] Access controls verified.
- [ ] Evidence complete.
- [ ] Owner approves.
- [ ] Expiry defined.

---

# 172. UAT — Ownership

- [ ] Active domain requires owner.
- [ ] Owner assignment effective-dated.
- [ ] Delegation retains accountability.
- [ ] Vacant critical ownership alerts.
- [ ] Owner changes audited.
- [ ] Decision rights enforced.
- [ ] Cross-domain conflict escalates.
- [ ] Ownership coverage metric works.

---

# 173. UAT — Stewardship

- [ ] Steward types supported.
- [ ] Assignments effective-dated.
- [ ] Steward queue works.
- [ ] SLA and due dates work.
- [ ] Workload visibility works.
- [ ] Escalation works.
- [ ] Steward changes audited.
- [ ] Consumer communication recorded.

---

# 174. UAT — Critical Data Elements

- [ ] CDE registry works.
- [ ] Owner/steward required.
- [ ] Sensitivity required.
- [ ] Quality tier required.
- [ ] Source required.
- [ ] Consumer inventory works.
- [ ] Active rules required for Tier 0.
- [ ] Retirement preserves history.

---

# 175. UAT — Quality Rules

- [ ] Rule types supported.
- [ ] Expressions versioned.
- [ ] On-entry validation works.
- [ ] Batch validation works.
- [ ] Thresholds work.
- [ ] Tenant scope enforced.
- [ ] Rule tests pass.
- [ ] Rollback restores prior version.
- [ ] Critical failures block where required.

---

# 176. UAT — Scorecards

- [ ] Dimension scores calculate.
- [ ] Weights work.
- [ ] Domain thresholds configurable.
- [ ] Green/amber/red works.
- [ ] Trends visible.
- [ ] Tenant score isolation works.
- [ ] Exceptions reflected.
- [ ] Missing data shows unknown, not false green.

---

# 177. UAT — Issue Management

- [ ] Failed rule creates issue.
- [ ] Triage works.
- [ ] Severity assigned.
- [ ] Assignment works.
- [ ] SLA calculates.
- [ ] Containment recorded.
- [ ] Root cause captured.
- [ ] Remediation tracked.
- [ ] Validation required before closure.
- [ ] Recurring issue detected.

---

# 178. UAT — Exceptions

- [ ] Exception request works.
- [ ] Approval required.
- [ ] Expiry mandatory.
- [ ] Compensating control mandatory.
- [ ] Scorecard reflects exception.
- [ ] Expired exception alerts.
- [ ] Revocation works.
- [ ] Audit complete.
- [ ] Critical controls cannot be silently disabled.

---

# 179. UAT — Certification

- [ ] Certification types supported.
- [ ] Requirements evaluated.
- [ ] Conditional certification works.
- [ ] Expiry works.
- [ ] Re-certification triggers work.
- [ ] Critical issue blocks certification.
- [ ] Revocation works.
- [ ] Evidence linked.
- [ ] Consumer can view certification status.

---

# 180. UAT — Multi-Tenant & Security

- [ ] Tenant-specific issues isolated.
- [ ] Cross-tenant evidence restricted.
- [ ] Aggregated metrics authorized.
- [ ] Sensitive record samples masked.
- [ ] High-impact correction requires privilege.
- [ ] SoD enforced.
- [ ] Bulk correction audited.
- [ ] Purpose limitation respected.

---

# 181. UAT — Metrics & Governance

- [ ] Ownership coverage visible.
- [ ] Stewardship workload visible.
- [ ] CDE coverage visible.
- [ ] Quality scores visible.
- [ ] Issue backlog visible.
- [ ] Remediation lead time visible.
- [ ] Exception expiry visible.
- [ ] Certification status visible.
- [ ] KPIs/KRIs defined.
- [ ] Evidence retained.

---

# 182. Definition of Done — SSOT-MDM-03

SSOT-MDM-03 dianggap selesai bila:

- [ ] objectives/principles tersedia;
- [ ] ownership model tersedia;
- [ ] ownership levels tersedia;
- [ ] registry/delegation/status tersedia;
- [ ] stewardship types tersedia;
- [ ] RACI/decision rights tersedia;
- [ ] domain charter tersedia;
- [ ] CDE model tersedia;
- [ ] quality dimensions tersedia;
- [ ] quality tiers tersedia;
- [ ] quality rule model tersedia;
- [ ] preventive/detective/corrective controls tersedia;
- [ ] thresholds/targets tersedia;
- [ ] scorecard tersedia;
- [ ] certification tersedia;
- [ ] issue lifecycle tersedia;
- [ ] severity/triage/root cause tersedia;
- [ ] remediation/containment tersedia;
- [ ] SLA/escalation tersedia;
- [ ] exception model tersedia;
- [ ] stewardship queue tersedia;
- [ ] glossary/metadata stewardship tersedia;
- [ ] producer/consumer accountability tersedia;
- [ ] data contract/data product quality tersedia;
- [ ] lifecycle quality controls tersedia;
- [ ] multi-tenant quality tersedia;
- [ ] privacy/security/SoD tersedia;
- [ ] audit/evidence tersedia;
- [ ] rule testing/versioning/deployment tersedia;
- [ ] reconciliation/duplicate integration tersedia;
- [ ] API/database direction tersedia;
- [ ] SDK contracts tersedia;
- [ ] event/error codes tersedia;
- [ ] metrics/KPI/KRI tersedia;
- [ ] examples/checklists/UAT tersedia.

---

# 183. Implementation Roadmap

## Phase 1 — Ownership Foundation

- inventory data domains;
- assign owners;
- assign stewards;
- define charters;
- identify critical data elements;
- create decision rights.

## Phase 2 — Quality Rule Framework

- create rule registry;
- define dimensions and tiers;
- implement validation engine;
- version rules;
- create test harness;
- define thresholds.

## Phase 3 — Issue & Stewardship Operations

- create issue workflow;
- stewardship queue;
- SLA/escalation;
- remediation tracking;
- exception workflow;
- evidence registry.

## Phase 4 — Scorecards & Certification

- quality scorecards;
- domain dashboards;
- certification workflow;
- tenant-level reporting;
- recurring issue analytics;
- trend monitoring.

## Phase 5 — Automation & Continuous Improvement

- automated rule execution;
- anomaly detection;
- predictive quality alerts;
- automated reconciliation integration;
- root-cause analytics;
- policy-as-code quality controls.

---

# 184. Initial Implementation Backlog

```text
DQ-001 Ownership Registry
DQ-002 Stewardship Registry
DQ-003 Domain Charter
DQ-004 Critical Data Element Registry
DQ-005 Quality Dimension Catalog
DQ-006 Quality Rule Registry
DQ-007 Rule Versioning
DQ-008 Rule Test Harness
DQ-009 Quality Execution Engine
DQ-010 Quality Scorecard
DQ-011 Quality Issue Workflow
DQ-012 Stewardship Work Queue
DQ-013 Remediation Tracker
DQ-014 Exception Workflow
DQ-015 Certification Service
DQ-016 SLA & Escalation Engine
DQ-017 Quality Dashboard
DQ-018 Audit Evidence Registry
```

---

# 185. Approval Gate

Dokumen dapat menjadi Approved setelah:

- Data Governance review;
- Platform Governance review;
- Domain Owner review;
- Data Steward review;
- Platform Architecture review;
- Security and Privacy review;
- Multi-tenant isolation review;
- Audit and Compliance review;
- Data Quality Operations review;
- Certification and exception review.

---

# 186. Closing Statement

Data ownership, quality, dan stewardship harus memastikan setiap data domain dan critical data element:

- memiliki owner;
- memiliki steward;
- memiliki definisi;
- memiliki rules;
- memiliki target;
- dipantau;
- memiliki issue workflow;
- memiliki remediation;
- memiliki exception yang time-bound;
- dapat disertifikasi;
- dapat diaudit.

Data quality tidak boleh diperlakukan sebagai aktivitas pembersihan data setelah masalah terjadi.

Data quality harus menjadi operating model yang memiliki accountability, controls, evidence, dan continuous improvement di seluruh lifecycle data.
