# SSOT-MDM-01 — Master & Reference Data Framework

---

## Status Dokumen

| Item | Nilai |
|---|---|
| Kode | SSOT-MDM-01 |
| Judul | Master & Reference Data Framework |
| Versi | 1.0 |
| Status | Draft for Review |
| Domain | Platform Kernel |
| Kategori | Master Data Management, Reference Data & Data Governance |
| Cakupan | Ownership, Stewardship, Canonical Records, Code Sets, Hierarchies, Quality, Versioning, Distribution, Reconciliation, Multi-Tenant Controls |
| Bergantung pada | SSOT-GOV-01, SSOT-GOV-04, SSOT-GOV-05, SSOT-SDK-01, SSOT-DEPLOY-02, SSOT-SEC-01 |
| Target Stack | PHP 8.1+, MySQL 8/MariaDB, Modular Monolith, Multi-Tenant |
| Target Evolusi | Enterprise MDM, Domain Data Products, Event-Driven Distribution, Microservice-ready |

---

# 1. Executive Summary

SSOT-MDM-01 menetapkan framework resmi untuk pengelolaan master data dan reference data pada Platform Kernel serta seluruh module bisnis.

Dokumen ini mengatur:

- master data domains;
- reference data domains;
- canonical records;
- golden record;
- identifiers;
- ownership;
- stewardship;
- lifecycle;
- hierarchy;
- classification;
- code sets;
- effective dating;
- versioning;
- data quality;
- matching and duplicate handling;
- merge and survivorship;
- tenant and clinic scope;
- distribution;
- synchronization;
- reconciliation;
- lineage;
- audit;
- retention;
- security;
- metrics;
- UAT;
- Definition of Done.

Tujuan akhirnya adalah memastikan data bersama:

- memiliki owner;
- memiliki definisi;
- memiliki sumber kebenaran;
- memiliki identifier stabil;
- memiliki lifecycle;
- memiliki quality rules;
- memiliki version;
- dapat didistribusikan;
- dapat direkonsiliasi;
- tenant-safe;
- dapat diaudit;
- tidak diduplikasi secara tidak terkendali antar module.

---

# 2. Objectives

Framework harus:

- menetapkan source of truth untuk data bersama;
- mengurangi duplikasi;
- menjaga konsistensi antar module;
- mendukung identifier stabil;
- memastikan quality dan lineage;
- mengontrol perubahan code set;
- menjaga tenant isolation;
- mendukung hierarchy dan effective dating;
- menyediakan reconciliation;
- mendukung future service extraction.

---

# 3. Core Principles

```text
One Authoritative Source per Data Element
Stable Identifiers
Explicit Ownership
Stewardship Before Automation
Canonical Data over Local Copies
Effective-Dated Changes
Quality by Design
Tenant Scope Is Mandatory
Traceable Distribution
Reconciliation Is Continuous
```

---

# 4. Scope

Framework berlaku untuk:

```text
Organization
Tenant
Clinic
Facility
Department
User
Staff
Practitioner
Patient Identity
Service Catalog
Product Catalog
Location
Geography
Code Sets
Taxonomies
Units
Currencies
Languages
Statuses
Categories
Reason Codes
Reference Mappings
```

---

# 5. Definitions

## Master Data

Data inti yang menggambarkan entitas utama dan digunakan oleh banyak proses bisnis.

Examples:

- patient;
- practitioner;
- organization;
- clinic;
- service;
- product;
- location.

## Reference Data

Data terkontrol yang digunakan untuk klasifikasi, validasi, status, atau pemetaan.

Examples:

- status codes;
- country codes;
- gender codes;
- service categories;
- unit codes;
- reason codes.

## Canonical Record

Representasi standar yang digunakan lintas module.

## Golden Record

Record terbaik hasil resolusi beberapa sumber berdasarkan survivorship rules.

## Source of Truth

Sistem atau domain yang memiliki authority atas data tertentu.

---

# 6. MDM Domain Types

```text
PARTY
ORGANIZATION
LOCATION
PRODUCT
SERVICE
CLINICAL
FINANCIAL
WORKFORCE
REFERENCE
```

---

# 7. Master Data Domain Inventory

Minimum fields:

```text
domain_code
domain_name
description
owner
steward
source_of_truth
identifier_strategy
tenant_scope
quality_tier
retention
distribution_policy
```

---

# 8. Reference Data Domain Inventory

Minimum fields:

```text
code_set
name
owner
steward
scope
versioning_model
effective_dating
external_standard
status
```

---

# 9. Ownership Model

Every domain must have:

- Data Owner;
- Data Steward;
- Technical Custodian;
- Data Consumer Owners;
- Security/Privacy Reviewer where applicable.

---

# 10. Data Owner

Responsible for:

- meaning;
- policy;
- quality targets;
- access;
- lifecycle;
- conflict decisions.

---

# 11. Data Steward

Responsible for:

- definitions;
- quality monitoring;
- duplicate resolution;
- mapping;
- issue handling;
- business validation.

---

# 12. Technical Custodian

Responsible for:

- storage;
- distribution;
- backup;
- performance;
- technical controls;
- schema implementation.

---

# 13. RACI Direction

| Activity | Owner | Steward | Custodian | Consumer |
|---|---|---|---|---|
| Define attributes | A | R | C | C |
| Approve code changes | A | R | C | C |
| Implement storage | C | C | R/A | I |
| Resolve duplicates | A | R | C | C |
| Monitor quality | A | R | R | C |
| Consume data | I | C | C | R |

---

# 14. Source of Truth

Each mastered attribute must have authoritative source.

---

# 15. Attribute-Level Authority

Authority may differ by attribute.

Example:

```text
Patient demographic identity → Patient Master
Clinical episode status → Clinical Module
Billing customer class → Billing Master
```

---

# 16. System of Entry

System where data is initially captured.

System of Entry may differ from Source of Truth.

---

# 17. System of Record

System responsible for authoritative persistence.

---

# 18. System of Reference

System used by consumers to read standardized data.

---

# 19. Canonical Data Model

Canonical models should:

- use stable identifiers;
- use explicit types;
- separate codes from labels;
- support effective dates;
- support status;
- support lineage;
- support tenant scope.

---

# 20. Canonical Attribute Rules

Every attribute should define:

```text
name
business_definition
type
required
format
allowed_values
source
owner
sensitivity
quality_rule
```

---

# 21. Identifier Strategy

Preferred:

```text
ULID
UUID
Stable Business Key where governed
```

---

# 22. Internal Identifier

Use immutable system-generated ID.

---

# 23. Business Identifier

Examples:

- medical record number;
- employee number;
- service code;
- clinic code.

Business identifiers may change under controlled policy.

---

# 24. Identifier Rules

Identifiers must:

- be unique within defined scope;
- not be recycled;
- have owner;
- have format;
- have issuance policy;
- be auditable.

---

# 25. Identifier Scope

```text
GLOBAL
TENANT
ORGANIZATION
CLINIC
DOMAIN
```

---

# 26. Crosswalk

Crosswalk maps IDs between systems.

Minimum:

```text
source_system
source_id
canonical_id
mapping_status
confidence
effective_at
```

---

# 27. Alias

Aliases preserve historical or alternate identifiers.

---

# 28. Master Record Lifecycle

```text
DRAFT
ACTIVE
INACTIVE
SUSPENDED
MERGED
ARCHIVED
RETIRED
DELETED
```

---

# 29. Reference Value Lifecycle

```text
DRAFT
ACTIVE
DEPRECATED
INACTIVE
RETIRED
```

---

# 30. Lifecycle Transitions

Transitions must be:

- authorized;
- validated;
- effective-dated;
- audited;
- reversible where appropriate.

---

# 31. Soft Delete

Master data should generally use lifecycle status rather than hard delete.

---

# 32. Hard Delete

Allowed only when:

- policy permits;
- dependencies assessed;
- retention satisfied;
- privacy/legal requirements addressed;
- evidence retained.

---

# 33. Effective Dating

Recommended fields:

```text
valid_from
valid_to
recorded_at
```

---

# 34. Business Effective Time

When data is valid in business reality.

---

# 35. System Recorded Time

When system recorded the change.

---

# 36. Bi-Temporal Direction

Critical domains may support both business and system time.

---

# 37. Hierarchy Model

Examples:

```text
Tenant
└── Organization
    └── Clinic
        └── Department
            └── Unit
```

---

# 38. Hierarchy Requirements

- explicit parent;
- hierarchy type;
- effective dates;
- cycle prevention;
- depth limits where needed;
- audit.

---

# 39. Hierarchy Types

```text
ORGANIZATIONAL
GEOGRAPHICAL
SERVICE
PRODUCT
CLINICAL
REPORTING
```

---

# 40. Hierarchy Cycle

Cycles are prohibited unless graph semantics explicitly require them.

---

# 41. Multiple Hierarchies

An entity may participate in multiple named hierarchies.

---

# 42. Classification Model

Classification assigns categories to master entities.

---

# 43. Classification Requirements

```text
classification_scheme
code
label
version
effective_dates
owner
```

---

# 44. Reference Code Set

A code set contains controlled values.

---

# 45. Code Set Naming

Recommended:

```text
domain.subject
```

Examples:

```text
patient.status
service.category
address.type
employment.status
```

---

# 46. Reference Value Fields

```text
code
display_name
description
sort_order
status
valid_from
valid_to
parent_code
metadata
```

---

# 47. Code Immutability

Once published, code meaning must not change incompatibly.

---

# 48. Label Changes

Labels may change without changing code when semantics remain same.

---

# 49. Code Reuse

Retired codes must not be reused for unrelated meaning.

---

# 50. External Standards

Reference data may map to:

- ISO;
- ICD;
- SNOMED;
- LOINC;
- local regulatory standards;
- industry standards.

---

# 51. External Standard Metadata

```text
standard_name
standard_version
publisher
license
effective_date
source_reference
```

---

# 52. Mapping Model

Mappings may be:

```text
EXACT
EQUIVALENT
BROADER
NARROWER
RELATED
UNMAPPED
```

---

# 53. Mapping Confidence

```text
HIGH
MEDIUM
LOW
UNKNOWN
```

---

# 54. Mapping Approval

Critical mappings require domain expert approval.

---

# 55. Code Set Versioning

Recommended:

```text
MAJOR.MINOR.PATCH
```

---

# 56. Major Code Set Change

Used for incompatible semantic changes.

---

# 57. Minor Code Set Change

Used for additive values or compatible hierarchy updates.

---

# 58. Patch Code Set Change

Used for label, description, or metadata correction.

---

# 59. Code Set Publication

Publication flow:

```text
Draft
→ Review
→ Approve
→ Publish
→ Distribute
→ Reconcile
```

---

# 60. Code Set Freeze

Published versions should be immutable.

---

# 61. Data Quality Dimensions

```text
COMPLETENESS
VALIDITY
UNIQUENESS
CONSISTENCY
ACCURACY
TIMELINESS
INTEGRITY
CONFORMITY
```

---

# 62. Quality Rule

Minimum:

```text
rule_code
domain
attribute
dimension
expression
severity
owner
threshold
```

---

# 63. Quality Severity

```text
INFO
WARNING
ERROR
CRITICAL
```

---

# 64. Quality Score

Potential formula:

```text
Passed Rules / Applicable Rules × 100
```

---

# 65. Quality Tier

```text
TIER_0_CRITICAL
TIER_1_HIGH
TIER_2_STANDARD
TIER_3_LOW
```

---

# 66. Quality Threshold

Critical master domains should have explicit target.

---

# 67. Validation Timing

```text
ON_ENTRY
ON_CHANGE
BATCH
PRE_PUBLICATION
POST_SYNCHRONIZATION
```

---

# 68. Reject vs Warn

Critical invalid data should be rejected.

Non-critical issues may warn and create stewardship task.

---

# 69. Duplicate Management

Duplicate lifecycle:

```text
Detect
→ Score
→ Review
→ Confirm
→ Merge/Link/Reject
→ Audit
```

---

# 70. Match Types

```text
EXACT
DETERMINISTIC
PROBABILISTIC
MANUAL
```

---

# 71. Match Attributes

Examples:

- normalized name;
- date of birth;
- identifier;
- phone;
- email;
- address;
- organization code.

---

# 72. Match Thresholds

```text
AUTO_MATCH
MANUAL_REVIEW
NO_MATCH
```

---

# 73. False Positive Control

High-risk merges require manual approval.

---

# 74. Golden Record

Golden record may combine multiple source records.

---

# 75. Survivorship Rules

Examples:

```text
Trusted Source Wins
Most Recent Valid Value
Highest Quality Score
Steward-Approved Value
Non-Null Preferred
```

---

# 76. Attribute-Level Survivorship

Survivorship should operate per attribute where needed.

---

# 77. Merge Record

Minimum:

```text
surviving_id
merged_id
reason
approved_by
merged_at
attribute_decisions
```

---

# 78. Unmerge

Unmerge should be supported where technically and legally feasible.

---

# 79. Duplicate Link

Some duplicates may be linked without destructive merge.

---

# 80. Data Lineage

Lineage should answer:

- where data came from;
- how it changed;
- who approved;
- where it was distributed;
- which version was used.

---

# 81. Lineage Fields

```text
source_system
source_record_id
ingested_at
transformation
canonical_record_id
published_version
```

---

# 82. Data Provenance

Provenance must distinguish:

- manually entered;
- imported;
- synchronized;
- derived;
- merged;
- corrected.

---

# 83. Change Reason

Critical changes should require reason code.

---

# 84. Master Data Change Workflow

```text
Request
→ Validate
→ Steward Review
→ Owner Approval if Required
→ Apply
→ Publish
→ Reconcile
```

---

# 85. Change Types

```text
CREATE
UPDATE
MERGE
SPLIT
INACTIVATE
REACTIVATE
RECLASSIFY
REMAP
RETIRE
```

---

# 86. Approval Levels

Risk-based approval:

```text
STANDARD
SENSITIVE
HIGH_IMPACT
REGULATED
```

---

# 87. High-Impact Changes

Examples:

- organization hierarchy;
- patient merge;
- service code retirement;
- external standard mapping;
- tenant ownership change.

---

# 88. Bulk Change

Bulk changes require:

- preview;
- validation;
- approval;
- rollback/compensation;
- audit;
- reconciliation.

---

# 89. Import Framework

Imports must define:

```text
source
schema
mapping
validation
duplicate handling
error handling
tenant scope
owner
```

---

# 90. Import Staging

Bulk imports should use staging area.

---

# 91. Import Status

```text
UPLOADED
VALIDATING
READY
PROCESSING
COMPLETED
COMPLETED_WITH_ERRORS
FAILED
CANCELLED
```

---

# 92. Import Error Handling

Provide row-level and file-level errors.

---

# 93. Export Framework

Exports must enforce:

- authorization;
- tenant scope;
- classification;
- format;
- audit;
- retention.

---

# 94. Canonical Distribution

Distribution methods:

```text
SYNCHRONOUS_API
EVENT
BATCH_EXPORT
READ_MODEL
REPLICATION
CACHE
```

---

# 95. Distribution Principle

Consumers should prefer canonical access over maintaining unmanaged copies.

---

# 96. Event Distribution

Master data changes should emit versioned events where needed.

---

# 97. Event Examples

```text
mdm.patient.created.v1
mdm.patient.updated.v1
mdm.organization.merged.v1
mdm.reference-set.published.v1
```

---

# 98. Event Envelope

Include:

```text
event_id
event_type
event_version
domain
record_id
tenant_id
effective_at
occurred_at
change_version
correlation_id
```

---

# 99. Consumer Contract

Consumers should:

- declare consumed domain/version;
- handle duplicate events;
- reconcile missed events;
- preserve tenant scope;
- tolerate additive fields.

---

# 100. Data Synchronization

Synchronization modes:

```text
PUSH
PULL
EVENT_DRIVEN
SCHEDULED
ON_DEMAND
```

---

# 101. Synchronization State

Track:

```text
consumer
domain
last_version
last_sync_at
status
lag
```

---

# 102. Reconciliation

Reconciliation compares authoritative and consumer state.

---

# 103. Reconciliation Types

```text
COUNT
CHECKSUM
VERSION
RECORD
ATTRIBUTE
HIERARCHY
```

---

# 104. Reconciliation Status

```text
MATCHED
MISMATCH
MISSING_SOURCE
MISSING_TARGET
STALE
ERROR
```

---

# 105. Reconciliation Response

```text
Detect
→ Classify
→ Correct
→ Republish
→ Verify
→ Record
```

---

# 106. Caching

Reference data may be cached.

---

# 107. Cache Rules

Cache must be:

- version-aware;
- tenant-aware;
- invalidation-aware;
- bounded;
- observable.

---

# 108. Cache Key

Recommended:

```text
domain
code_set
version
tenant
locale
```

---

# 109. Multi-Tenant Model

Master data may be:

```text
GLOBAL
TENANT
ORGANIZATION
CLINIC
SHARED_WITH_OVERRIDE
```

---

# 110. Global Data

Examples:

- countries;
- currencies;
- standard units;
- global taxonomies.

---

# 111. Tenant Data

Examples:

- tenant service catalog;
- tenant organization;
- tenant-specific staff identifiers.

---

# 112. Shared with Override

Global values may allow tenant display or behavior override without changing canonical semantics.

---

# 113. Tenant Isolation

All tenant-scoped master operations require trusted tenant context.

---

# 114. Cross-Tenant Sharing

Must be explicit, authorized, and auditable.

---

# 115. Clinic Scope

Clinic-level master data must validate parent tenant.

---

# 116. Tenant Migration

Tenant transfer or consolidation requires controlled mapping and ownership review.

---

# 117. Security Classification

Master/reference attributes must carry classification where relevant.

---

# 118. Sensitive Master Data

Examples:

- patient identifiers;
- staff personal data;
- contractual identifiers;
- restricted organization relationships.

---

# 119. Access Control

Access should support:

- domain permission;
- attribute masking;
- tenant scope;
- purpose;
- role;
- privileged approval.

---

# 120. Attribute-Level Security

Sensitive attributes may require separate permission.

---

# 121. Purpose Limitation

Consumers should access only data needed for approved purpose.

---

# 122. Audit Requirements

Audit critical:

- create;
- update;
- merge;
- unmerge;
- hierarchy change;
- code publication;
- mapping approval;
- import;
- export;
- cross-tenant sharing.

---

# 123. Audit Metadata

Include:

```text
actor
tenant
action
record
before_reference
after_reference
reason
approval
correlation
```

---

# 124. Retention

Retention depends on domain, legal, contractual, and operational needs.

---

# 125. Archive

Inactive master data may be archived but remain resolvable for historical transactions.

---

# 126. Historical Reference

Transactions should retain code/version used at time of execution.

---

# 127. Referential Integrity

Consumers should not break historical records when reference value is retired.

---

# 128. Localization

Reference values may support localized labels.

---

# 129. Localization Fields

```text
locale
display_name
description
effective_dates
```

---

# 130. Locale Fallback

Fallback must be deterministic.

---

# 131. Search

Master data search should support:

- canonical identifiers;
- aliases;
- normalized names;
- hierarchy;
- status;
- tenant scope.

---

# 132. Search Security

Search results must enforce authorization and tenant scope.

---

# 133. Data API Direction

Potential endpoints:

```text
GET  /api/internal/v1/mdm/domains
GET  /api/internal/v1/mdm/{domain}/records
GET  /api/internal/v1/mdm/{domain}/records/{id}
POST /api/internal/v1/mdm/{domain}/records
PATCH /api/internal/v1/mdm/{domain}/records/{id}
POST /api/internal/v1/mdm/{domain}/records/{id}/merge
GET  /api/internal/v1/mdm/reference-sets
GET  /api/internal/v1/mdm/reference-sets/{codeSet}/versions/{version}
POST /api/internal/v1/mdm/reconciliation
```

---

# 134. API Contract Requirements

- versioned;
- tenant-aware;
- authorization-aware;
- typed;
- paginated;
- auditable;
- idempotent where needed.

---

# 135. Database Direction

Potential tables:

```text
mdm_domains
mdm_entities
mdm_entity_versions
mdm_identifiers
mdm_aliases
mdm_hierarchies
mdm_hierarchy_nodes
mdm_reference_sets
mdm_reference_values
mdm_reference_mappings
mdm_quality_rules
mdm_quality_results
mdm_duplicate_candidates
mdm_merge_records
mdm_distribution_subscriptions
mdm_reconciliation_runs
mdm_lineage
```

---

# 136. Table: mdm_domains

```sql
CREATE TABLE mdm_domains (
    id CHAR(26) NOT NULL,
    domain_code VARCHAR(100) NOT NULL,
    name VARCHAR(255) NOT NULL,
    domain_type VARCHAR(30) NOT NULL,
    owner_reference VARCHAR(180) NOT NULL,
    steward_reference VARCHAR(180) NOT NULL,
    source_of_truth VARCHAR(255) NOT NULL,
    identifier_scope VARCHAR(30) NOT NULL,
    tenant_scope VARCHAR(30) NOT NULL,
    quality_tier VARCHAR(30) NOT NULL,
    status VARCHAR(30) NOT NULL,

    PRIMARY KEY (id),
    UNIQUE KEY uq_mdm_domain_code (
        domain_code
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

# 137. Table: mdm_entities

```sql
CREATE TABLE mdm_entities (
    id CHAR(26) NOT NULL,
    domain_id CHAR(26) NOT NULL,
    tenant_id CHAR(26) NULL,
    canonical_code VARCHAR(180) NULL,
    lifecycle_status VARCHAR(30) NOT NULL,
    current_version BIGINT UNSIGNED NOT NULL DEFAULT 1,
    valid_from DATETIME(6) NULL,
    valid_to DATETIME(6) NULL,
    created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    updated_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6)
        ON UPDATE CURRENT_TIMESTAMP(6),

    PRIMARY KEY (id),
    KEY idx_mdm_entity_domain_scope (
        domain_id,
        tenant_id,
        lifecycle_status
    ),
    UNIQUE KEY uq_mdm_entity_code_scope (
        domain_id,
        tenant_id,
        canonical_code
    ),
    CONSTRAINT fk_mdm_entity_domain
        FOREIGN KEY (domain_id)
        REFERENCES mdm_domains (id)
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

# 138. Table: mdm_entity_versions

```sql
CREATE TABLE mdm_entity_versions (
    id CHAR(26) NOT NULL,
    entity_id CHAR(26) NOT NULL,
    version_no BIGINT UNSIGNED NOT NULL,
    data_json JSON NOT NULL,
    source_system VARCHAR(180) NOT NULL,
    source_record_id VARCHAR(255) NULL,
    change_type VARCHAR(30) NOT NULL,
    change_reason VARCHAR(500) NULL,
    recorded_at DATETIME(6) NOT NULL,
    valid_from DATETIME(6) NULL,
    valid_to DATETIME(6) NULL,
    approved_by VARCHAR(180) NULL,

    PRIMARY KEY (id),
    UNIQUE KEY uq_mdm_entity_version (
        entity_id,
        version_no
    ),
    CONSTRAINT fk_mdm_version_entity
        FOREIGN KEY (entity_id)
        REFERENCES mdm_entities (id)
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

# 139. Table: mdm_identifiers

```sql
CREATE TABLE mdm_identifiers (
    id CHAR(26) NOT NULL,
    entity_id CHAR(26) NOT NULL,
    identifier_type VARCHAR(100) NOT NULL,
    identifier_value VARCHAR(255) NOT NULL,
    issuer VARCHAR(180) NULL,
    scope_type VARCHAR(30) NOT NULL,
    primary_flag TINYINT(1) NOT NULL DEFAULT 0,
    status VARCHAR(30) NOT NULL,
    valid_from DATETIME(6) NULL,
    valid_to DATETIME(6) NULL,

    PRIMARY KEY (id),
    UNIQUE KEY uq_mdm_identifier (
        identifier_type,
        identifier_value,
        issuer,
        scope_type
    ),
    KEY idx_mdm_identifier_entity (
        entity_id,
        status
    ),
    CONSTRAINT fk_mdm_identifier_entity
        FOREIGN KEY (entity_id)
        REFERENCES mdm_entities (id)
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

# 140. Table: mdm_reference_sets

```sql
CREATE TABLE mdm_reference_sets (
    id CHAR(26) NOT NULL,
    code_set VARCHAR(180) NOT NULL,
    name VARCHAR(255) NOT NULL,
    owner_reference VARCHAR(180) NOT NULL,
    steward_reference VARCHAR(180) NOT NULL,
    current_version VARCHAR(100) NOT NULL,
    external_standard VARCHAR(255) NULL,
    status VARCHAR(30) NOT NULL,

    PRIMARY KEY (id),
    UNIQUE KEY uq_mdm_reference_set (
        code_set
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

# 141. Table: mdm_reference_values

```sql
CREATE TABLE mdm_reference_values (
    id CHAR(26) NOT NULL,
    reference_set_id CHAR(26) NOT NULL,
    version VARCHAR(100) NOT NULL,
    code VARCHAR(180) NOT NULL,
    display_name VARCHAR(500) NOT NULL,
    description_text LONGTEXT NULL,
    parent_code VARCHAR(180) NULL,
    sort_order INT NOT NULL DEFAULT 0,
    status VARCHAR(30) NOT NULL,
    valid_from DATETIME(6) NULL,
    valid_to DATETIME(6) NULL,
    metadata_json JSON NULL,

    PRIMARY KEY (id),
    UNIQUE KEY uq_mdm_reference_value (
        reference_set_id,
        version,
        code
    ),
    KEY idx_mdm_reference_status (
        reference_set_id,
        version,
        status,
        sort_order
    ),
    CONSTRAINT fk_mdm_reference_value_set
        FOREIGN KEY (reference_set_id)
        REFERENCES mdm_reference_sets (id)
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

# 142. Table: mdm_duplicate_candidates

```sql
CREATE TABLE mdm_duplicate_candidates (
    id CHAR(26) NOT NULL,
    domain_id CHAR(26) NOT NULL,
    entity_a_id CHAR(26) NOT NULL,
    entity_b_id CHAR(26) NOT NULL,
    match_type VARCHAR(30) NOT NULL,
    match_score DECIMAL(8,4) NOT NULL,
    review_status VARCHAR(30) NOT NULL,
    reviewed_by VARCHAR(180) NULL,
    reviewed_at DATETIME(6) NULL,
    decision_reason VARCHAR(1000) NULL,

    PRIMARY KEY (id),
    UNIQUE KEY uq_mdm_duplicate_pair (
        domain_id,
        entity_a_id,
        entity_b_id
    ),
    KEY idx_mdm_duplicate_review (
        review_status,
        match_score
    ),
    CONSTRAINT fk_mdm_duplicate_domain
        FOREIGN KEY (domain_id)
        REFERENCES mdm_domains (id)
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

# 143. Table: mdm_merge_records

```sql
CREATE TABLE mdm_merge_records (
    id CHAR(26) NOT NULL,
    domain_id CHAR(26) NOT NULL,
    surviving_entity_id CHAR(26) NOT NULL,
    merged_entity_id CHAR(26) NOT NULL,
    reason_text LONGTEXT NOT NULL,
    attribute_decisions_json JSON NULL,
    approved_by VARCHAR(180) NOT NULL,
    merged_at DATETIME(6) NOT NULL,
    reversed_at DATETIME(6) NULL,
    reversed_by VARCHAR(180) NULL,

    PRIMARY KEY (id),
    KEY idx_mdm_merge_survivor (
        surviving_entity_id,
        merged_at
    ),
    CONSTRAINT fk_mdm_merge_domain
        FOREIGN KEY (domain_id)
        REFERENCES mdm_domains (id)
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

# 144. Quality Rule Table Direction

Potential fields:

```text
rule_code
domain_id
attribute_path
dimension
severity
expression
threshold
owner
status
```

---

# 145. Reconciliation Table Direction

Potential fields:

```text
run_code
domain
consumer
expected_version
actual_version
status
mismatch_count
started_at
completed_at
```

---

# 146. SDK Contract Direction

Potential contracts:

```text
MasterDataReaderInterface
MasterDataWriterInterface
ReferenceDataServiceInterface
IdentifierResolverInterface
HierarchyServiceInterface
DuplicateResolutionServiceInterface
ReconciliationServiceInterface
```

---

# 147. Master Data Reader

```php
interface MasterDataReaderInterface
{
    public function get(
        string $domain,
        string $id,
        TenantContextInterface $tenant
    ): ?MasterDataRecord;

    public function search(
        MasterDataSearchRequest $request
    ): PageResult;
}
```

---

# 148. Reference Data Service

```php
interface ReferenceDataServiceInterface
{
    public function values(
        string $codeSet,
        ?string $version = null,
        ?TenantContextInterface $tenant = null
    ): array;

    public function validate(
        string $codeSet,
        string $code,
        ?string $version = null
    ): bool;
}
```

---

# 149. Identifier Resolver

```php
interface IdentifierResolverInterface
{
    public function resolve(
        string $identifierType,
        string $identifierValue,
        ?string $issuer,
        TenantContextInterface $tenant
    ): ?string;
}
```

---

# 150. Hierarchy Service

```php
interface HierarchyServiceInterface
{
    public function ancestors(
        string $hierarchyCode,
        string $entityId,
        \DateTimeImmutable $asOf
    ): array;

    public function descendants(
        string $hierarchyCode,
        string $entityId,
        \DateTimeImmutable $asOf
    ): array;
}
```

---

# 151. MDM Event Codes

```text
MDM_DOMAIN_REGISTERED
MDM_RECORD_CREATED
MDM_RECORD_UPDATED
MDM_RECORD_INACTIVATED
MDM_RECORD_MERGED
MDM_RECORD_UNMERGED
MDM_IDENTIFIER_ASSIGNED
MDM_HIERARCHY_CHANGED
MDM_REFERENCE_SET_PUBLISHED
MDM_REFERENCE_VALUE_DEPRECATED
MDM_DUPLICATE_DETECTED
MDM_RECONCILIATION_MISMATCH
MDM_QUALITY_RULE_FAILED
MDM_IMPORT_COMPLETED
```

---

# 152. MDM Error Codes

```text
MDM_DOMAIN_NOT_FOUND
MDM_RECORD_NOT_FOUND
MDM_IDENTIFIER_DUPLICATE
MDM_IDENTIFIER_INVALID
MDM_TENANT_SCOPE_INVALID
MDM_HIERARCHY_CYCLE
MDM_REFERENCE_CODE_INVALID
MDM_REFERENCE_VERSION_NOT_FOUND
MDM_DUPLICATE_REVIEW_REQUIRED
MDM_MERGE_NOT_ALLOWED
MDM_QUALITY_VALIDATION_FAILED
MDM_RECONCILIATION_FAILED
MDM_IMPORT_INVALID
```

---

# 153. Metrics

```text
mdm_record_total
mdm_duplicate_candidate_total
mdm_merge_total
mdm_quality_failure_total
mdm_quality_score
mdm_reference_set_version_total
mdm_reconciliation_mismatch_total
mdm_sync_lag_seconds
mdm_unowned_domain_total
mdm_stewardship_backlog_total
```

---

# 154. KPIs

Initial targets:

```text
Master domains without owner = 0
Reference sets without steward = 0
Critical duplicate backlog overdue = 0
Critical quality rule pass rate = 100%
Unresolved critical reconciliation mismatches = 0
Published code reuse violations = 0
Cross-tenant MDM violations = 0
```

---

# 155. KRIs

```text
Duplicate rate
Quality score decline
Synchronization lag
Unmapped external codes
Stale reference versions
Unapproved bulk changes
Merge reversal rate
Cross-tenant access attempts
```

---

# 156. Dashboard Views

Recommended:

- domains and owners;
- quality scores;
- duplicate candidates;
- merges;
- code set versions;
- mapping completeness;
- reconciliation status;
- sync lag;
- stewardship backlog;
- tenant scope violations.

---

# 157. Data Stewardship Work Queue

Work item types:

```text
DUPLICATE_REVIEW
QUALITY_EXCEPTION
MAPPING_REVIEW
HIERARCHY_REVIEW
IDENTIFIER_CONFLICT
BULK_CHANGE_REVIEW
RECONCILIATION_MISMATCH
```

---

# 158. Stewardship SLA

Risk-based by domain criticality.

---

# 159. Exception Management

Exceptions must use SSOT-GOV-04.

---

# 160. Reference Master Domain: Organization

Attributes may include:

```text
organization_id
tenant_id
organization_code
legal_name
display_name
organization_type
status
parent_organization
valid_from
valid_to
```

---

# 161. Reference Master Domain: Clinic

Attributes may include:

```text
clinic_id
tenant_id
organization_id
clinic_code
name
clinic_type
address_reference
timezone
status
valid_from
valid_to
```

---

# 162. Reference Master Domain: Service

Attributes may include:

```text
service_id
tenant_id
service_code
name
category_code
unit_code
duration
status
valid_from
valid_to
```

---

# 163. Reference Code Set Example

```yaml
code_set: service.category
version: 1.2.0
owner: service_governance
steward: master_data_team
values:
  - code: HOMECARE
    display_name: Homecare
    status: ACTIVE
  - code: WOUNDCARE
    display_name: Wound Care
    status: ACTIVE
```

---

# 164. Quality Rule Example

```yaml
rule_code: MDM-CLINIC-001
domain: clinic
attribute: clinic_code
dimension: UNIQUENESS
severity: CRITICAL
expression: unique within tenant
threshold: 100
owner: clinic_data_steward
```

---

# 165. Duplicate Rule Example

```yaml
domain: patient
match:
  exact:
    - national_identifier
  probabilistic:
    - normalized_name
    - date_of_birth
    - phone
thresholds:
  auto_match: 0.98
  manual_review: 0.80
```

---

# 166. Reconciliation Example

```yaml
domain: service
source: mdm
consumer: billing
expected_version: 2026.07.05.12
actual_version: 2026.07.05.10
status: STALE
action: republish_delta
```

---

# 167. Domain Onboarding Checklist

- [ ] Domain defined.
- [ ] Owner assigned.
- [ ] Steward assigned.
- [ ] Source of truth identified.
- [ ] Canonical attributes defined.
- [ ] Identifier strategy defined.
- [ ] Tenant scope defined.
- [ ] Quality rules defined.
- [ ] Lifecycle defined.
- [ ] Distribution consumers listed.
- [ ] Security classification assigned.
- [ ] Retention defined.

---

# 168. Reference Set Checklist

- [ ] Code set name unique.
- [ ] Owner and steward assigned.
- [ ] Codes immutable.
- [ ] Version defined.
- [ ] Effective dates defined.
- [ ] External standard documented.
- [ ] Mapping rules documented.
- [ ] Publication approved.
- [ ] Consumers notified.
- [ ] Historical version retained.

---

# 169. Merge Checklist

- [ ] Duplicate confirmed.
- [ ] Tenant scope matches.
- [ ] High-risk attributes reviewed.
- [ ] Survivor selected.
- [ ] Attribute survivorship documented.
- [ ] Dependencies assessed.
- [ ] Approval obtained.
- [ ] Audit captured.
- [ ] Consumer events published.
- [ ] Reconciliation completed.
- [ ] Unmerge feasibility recorded.

---

# 170. Bulk Import Checklist

- [ ] Source approved.
- [ ] Schema mapped.
- [ ] Tenant scope validated.
- [ ] Staging used.
- [ ] Quality validation run.
- [ ] Duplicates assessed.
- [ ] Preview approved.
- [ ] Error handling defined.
- [ ] Rollback/compensation defined.
- [ ] Audit and reconciliation active.

---

# 171. UAT — Domain Governance

- [ ] Domains registered.
- [ ] Owners assigned.
- [ ] Stewards assigned.
- [ ] Source of truth defined.
- [ ] Attribute authority defined.
- [ ] Classification defined.
- [ ] Lifecycle defined.
- [ ] Retention defined.
- [ ] Consumers inventoried.

---

# 172. UAT — Identifiers

- [ ] Internal IDs immutable.
- [ ] Business ID scope enforced.
- [ ] Duplicate IDs rejected.
- [ ] Alias works.
- [ ] Crosswalk resolves.
- [ ] Retired IDs are not reused.
- [ ] Identifier assignment audited.
- [ ] Tenant scope enforced.

---

# 173. UAT — Reference Data

- [ ] Code sets versioned.
- [ ] Published version immutable.
- [ ] Code reuse blocked.
- [ ] Label changes preserve code.
- [ ] Effective dates work.
- [ ] Hierarchy parent validation works.
- [ ] Historical values remain resolvable.
- [ ] External mappings are traceable.

---

# 174. UAT — Data Quality

- [ ] Quality rules execute.
- [ ] Critical invalid data rejected.
- [ ] Warnings create steward tasks.
- [ ] Quality score calculated.
- [ ] Threshold alerts work.
- [ ] Rule owners exist.
- [ ] Results are auditable.
- [ ] Quality trends visible.

---

# 175. UAT — Duplicate & Merge

- [ ] Duplicate candidates detected.
- [ ] Match thresholds work.
- [ ] Manual review works.
- [ ] High-risk auto-merge blocked.
- [ ] Survivorship rules applied.
- [ ] Merge event published.
- [ ] Alias resolves merged ID.
- [ ] Unmerge works where supported.
- [ ] Consumer reconciliation passes.

---

# 176. UAT — Hierarchy

- [ ] Parent relationships work.
- [ ] Cycles are blocked.
- [ ] Effective dating works.
- [ ] Multiple hierarchies work.
- [ ] Ancestor/descendant queries work.
- [ ] Tenant boundaries enforced.
- [ ] Hierarchy changes audited.
- [ ] Historical hierarchy resolvable.

---

# 177. UAT — Distribution & Reconciliation

- [ ] API distribution works.
- [ ] Event distribution works.
- [ ] Consumers declare versions.
- [ ] Duplicate events tolerated.
- [ ] Sync state tracked.
- [ ] Reconciliation detects mismatch.
- [ ] Republish/recovery works.
- [ ] Cache invalidation works.
- [ ] Sync lag visible.

---

# 178. UAT — Multi-Tenant & Security

- [ ] Global and tenant scopes distinguished.
- [ ] Tenant context required.
- [ ] Clinic belongs to tenant.
- [ ] Cross-tenant reads denied.
- [ ] Shared overrides preserve canonical meaning.
- [ ] Sensitive attributes masked.
- [ ] Export authorization works.
- [ ] Audit trail complete.
- [ ] Purpose limitation enforced where required.

---

# 179. UAT — Import & Bulk Change

- [ ] Staging import works.
- [ ] Row-level errors available.
- [ ] Duplicate handling works.
- [ ] Bulk preview works.
- [ ] Approval gate works.
- [ ] Rollback/compensation works.
- [ ] Quality validation works.
- [ ] Reconciliation runs after import.
- [ ] Audit evidence retained.

---

# 180. UAT — Metrics & Governance

- [ ] Metrics available.
- [ ] KPIs/KRIs defined.
- [ ] Dashboard views defined.
- [ ] Stewardship queue works.
- [ ] SLA escalation works.
- [ ] Exceptions expire.
- [ ] Change approvals traceable.
- [ ] Evidence retained.

---

# 181. Definition of Done — SSOT-MDM-01

SSOT-MDM-01 dianggap selesai bila:

- [ ] objectives/principles tersedia;
- [ ] definitions/domain types tersedia;
- [ ] domain inventories tersedia;
- [ ] ownership/stewardship tersedia;
- [ ] source of truth model tersedia;
- [ ] canonical model tersedia;
- [ ] identifier strategy tersedia;
- [ ] crosswalk/alias tersedia;
- [ ] lifecycle tersedia;
- [ ] effective dating tersedia;
- [ ] hierarchy model tersedia;
- [ ] classification tersedia;
- [ ] code set model tersedia;
- [ ] external standards/mapping tersedia;
- [ ] versioning/publication tersedia;
- [ ] quality dimensions/rules tersedia;
- [ ] duplicate management tersedia;
- [ ] golden record/survivorship tersedia;
- [ ] merge/unmerge tersedia;
- [ ] lineage/provenance tersedia;
- [ ] change workflow tersedia;
- [ ] bulk import/export tersedia;
- [ ] distribution tersedia;
- [ ] synchronization/reconciliation tersedia;
- [ ] caching tersedia;
- [ ] multi-tenant scope tersedia;
- [ ] security/access/audit tersedia;
- [ ] retention/archive tersedia;
- [ ] localization/search tersedia;
- [ ] API/database direction tersedia;
- [ ] SDK contract direction tersedia;
- [ ] event/error codes tersedia;
- [ ] metrics/KPI/KRI tersedia;
- [ ] stewardship queue tersedia;
- [ ] examples/checklists/UAT tersedia.

---

# 182. Implementation Roadmap

## Phase 1 — Governance Foundation

- inventory master/reference domains;
- assign owners and stewards;
- identify sources of truth;
- define canonical attributes;
- define identifier policies.

## Phase 2 — Reference Data Registry

- create reference set registry;
- implement versioning;
- implement effective dating;
- publish APIs;
- add localization and mappings.

## Phase 3 — Master Data Services

- entity registry;
- identifiers and aliases;
- hierarchy services;
- lifecycle controls;
- tenant-aware APIs.

## Phase 4 — Quality & Duplicate Management

- quality rules;
- stewardship queue;
- duplicate detection;
- survivorship;
- merge/unmerge;
- lineage.

## Phase 5 — Distribution & Reconciliation

- versioned events;
- consumer subscriptions;
- sync tracking;
- reconciliation;
- dashboards;
- automated remediation.

---

# 183. Initial Implementation Backlog

```text
MDM-001 Domain Registry
MDM-002 Data Owner & Steward Registry
MDM-003 Canonical Attribute Dictionary
MDM-004 Identifier Service
MDM-005 Alias & Crosswalk Service
MDM-006 Reference Set Registry
MDM-007 Reference Data Versioning
MDM-008 Hierarchy Service
MDM-009 Data Quality Rule Engine
MDM-010 Stewardship Work Queue
MDM-011 Duplicate Detection
MDM-012 Merge & Survivorship Service
MDM-013 Lineage Registry
MDM-014 MDM Event Publisher
MDM-015 Synchronization State Registry
MDM-016 Reconciliation Engine
MDM-017 MDM Dashboard
```

---

# 184. Approval Gate

Dokumen dapat menjadi Approved setelah:

- Platform Governance review;
- Data Governance review;
- Domain Owner review;
- Data Steward review;
- Platform Architecture review;
- Security and Privacy review;
- Multi-tenant isolation review;
- Database Architecture review;
- Module Owner review;
- Quality and reconciliation review.

---

# 185. Closing Statement

Master dan reference data framework harus memastikan setiap shared data domain dan code set:

- memiliki definisi;
- memiliki owner;
- memiliki steward;
- memiliki source of truth;
- memiliki identifier;
- memiliki lifecycle;
- memiliki quality rules;
- memiliki version;
- tenant-safe;
- dapat didistribusikan;
- dapat direkonsiliasi;
- dapat diaudit.

Master data tidak boleh menjadi salinan berbeda di setiap module tanpa authority yang jelas.

Master dan reference data harus dikelola sebagai enterprise asset yang canonical, governed, versioned, high-quality, dan siap digunakan lintas module serta lintas industri.
