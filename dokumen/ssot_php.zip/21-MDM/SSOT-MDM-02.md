# SSOT-MDM-02 — Code Set, Taxonomy & Lookup Governance

---

## Status Dokumen

| Item | Nilai |
|---|---|
| Kode | SSOT-MDM-02 |
| Judul | Code Set, Taxonomy & Lookup Governance |
| Versi | 1.0 |
| Status | Draft for Review |
| Domain | Platform Kernel |
| Kategori | Reference Data, Taxonomy, Lookup & Classification Governance |
| Cakupan | Code Sets, Taxonomies, Lookups, Hierarchies, Mappings, Versioning, Localization, Publication, Distribution, Quality, Retirement |
| Bergantung pada | SSOT-MDM-01, SSOT-GOV-01, SSOT-GOV-04, SSOT-GOV-05, SSOT-SDK-02, SSOT-DEPLOY-02 |
| Target Stack | PHP 8.1+, MySQL 8/MariaDB, Modular Monolith, Multi-Tenant |
| Target Evolusi | Enterprise Reference Data Service, Event-Driven Distribution, External Standard Integration |

---

# 1. Executive Summary

SSOT-MDM-02 menetapkan tata kelola resmi untuk code set, taxonomy, lookup, classification scheme, dan reference mappings pada Platform Kernel serta seluruh module bisnis.

Dokumen ini mengatur:

- definisi code set;
- lookup governance;
- taxonomy structure;
- hierarchy;
- ownership;
- stewardship;
- versioning;
- lifecycle;
- publication;
- localization;
- external standards;
- mappings;
- effective dating;
- aliases;
- deprecation;
- retirement;
- tenant override;
- lookup resolution;
- caching;
- synchronization;
- quality;
- reconciliation;
- audit;
- metrics;
- UAT;
- Definition of Done.

Tujuan akhirnya adalah memastikan setiap lookup dan taxonomy:

- memiliki arti yang jelas;
- memiliki owner;
- memiliki steward;
- memiliki version;
- memiliki lifecycle;
- memiliki code yang stabil;
- tidak di-hardcode secara tidak terkendali;
- dapat digunakan lintas module;
- tenant-safe;
- dapat dilokalkan;
- dapat dipetakan ke standard eksternal;
- dapat diaudit;
- dapat dipulihkan;
- tidak merusak transaksi historis ketika berubah.

---

# 2. Objectives

Framework harus:

- menghilangkan lookup yang tersebar dan tidak terkendali;
- mencegah perubahan makna code secara diam-diam;
- menjaga konsistensi label dan semantics;
- mendukung taxonomy dan hierarchy;
- mendukung versioned publication;
- mendukung localization;
- menjaga historical resolution;
- mengontrol tenant override;
- menyediakan mappings dan reconciliation;
- mendukung future reference data service.

---

# 3. Core Principles

```text
Codes Are Stable
Meaning Is Governed
Labels May Change, Semantics May Not
Every Set Has an Owner and Steward
Published Versions Are Immutable
Historical Values Remain Resolvable
Effective Dates Are Explicit
Tenant Overrides Cannot Change Canonical Meaning
Mappings Are Versioned and Reviewed
Lookups Must Be Served Through Controlled Contracts
```

---

# 4. Scope

Framework berlaku untuk:

```text
Status Codes
Category Codes
Type Codes
Reason Codes
Severity Codes
Priority Codes
Role Categories
Service Categories
Clinical Classifications
Geographic Codes
Currency Codes
Unit Codes
Language Codes
Industry Taxonomies
Product Taxonomies
Workflow Statuses
Integration Code Mappings
```

---

# 5. Definitions

## Code Set

Kumpulan nilai terkontrol dengan code unik dan semantics yang konsisten.

## Lookup

Mekanisme resolusi code menjadi label, metadata, status, atau validasi.

## Taxonomy

Sistem klasifikasi terstruktur, biasanya memiliki hierarchy atau relationship.

## Classification Scheme

Aturan pengelompokan entitas berdasarkan kategori yang didefinisikan.

## Mapping

Relasi antara code pada satu code set dengan code pada code set lain.

## Alias

Code historis atau alternatif yang menunjuk ke nilai canonical.

## Canonical Code

Code resmi yang menjadi acuan utama.

---

# 6. Reference Data Object Types

```text
FLAT_CODE_SET
HIERARCHICAL_TAXONOMY
ORDERED_LOOKUP
STATUS_MACHINE_LOOKUP
EXTERNAL_STANDARD_SET
MAPPING_SET
LOCALIZED_LOOKUP
TENANT_EXTENSIBLE_SET
```

---

# 7. Flat Code Set

Kumpulan code tanpa parent-child relationship.

Examples:

- address type;
- contact method;
- payment status.

---

# 8. Hierarchical Taxonomy

Memiliki parent-child relationship.

Examples:

- service category;
- product category;
- geography;
- organization classification.

---

# 9. Ordered Lookup

Memiliki sort order yang signifikan.

Examples:

- severity;
- priority;
- maturity level.

---

# 10. Status Machine Lookup

Code menggambarkan state dan transition rules.

Examples:

- appointment status;
- visit status;
- claim status.

---

# 11. External Standard Set

Reference set yang berasal dari standard eksternal.

Examples:

- ISO countries;
- ICD;
- SNOMED;
- LOINC;
- currency standards.

---

# 12. Mapping Set

Kumpulan mapping antar code set.

---

# 13. Localized Lookup

Lookup dengan label multi-bahasa.

---

# 14. Tenant Extensible Set

Code set canonical yang mengizinkan tenant-specific extension dalam batas tertentu.

---

# 15. Code Set Registry

Setiap code set harus terdaftar.

Minimum metadata:

```text
code_set
name
description
object_type
owner
steward
scope
current_version
versioning_policy
effective_dating
external_standard
localization
tenant_extensibility
status
```

---

# 16. Naming Convention

Recommended:

```text
domain.subject
```

Examples:

```text
patient.status
patient.identifier.type
service.category
homecare.visit.status
workflow.transition.reason
```

---

# 17. Code Set Naming Rules

- lowercase;
- dot-separated;
- stable;
- domain-owned;
- no ambiguous abbreviations;
- no environment suffix;
- no tenant ID in canonical name.

---

# 18. Code Naming Convention

Recommended:

```text
UPPER_SNAKE_CASE
```

Examples:

```text
ACTIVE
INACTIVE
PENDING_REVIEW
HOMECARE
WOUND_CARE
```

---

# 19. Code Rules

Codes must:

- be unique within set/version;
- be stable;
- not contain labels;
- not be reused;
- avoid database-generated numeric meaning where semantics matter;
- remain resolvable historically.

---

# 20. Numeric Codes

Numeric codes may be used only when:

- required by external standard;
- semantics are governed externally;
- leading zero handling is defined;
- type is stored as string when appropriate.

---

# 21. Label Rules

Labels may:

- change for clarity;
- be localized;
- have short and long forms.

Labels must not silently change semantics.

---

# 22. Description Rules

Descriptions should explain business meaning and usage boundaries.

---

# 23. Metadata Model

Reference values may include:

```text
code
display_name
short_name
description
sort_order
status
parent_code
valid_from
valid_to
metadata
external_identifiers
```

---

# 24. Ownership Model

Every code set must have:

- Data Owner;
- Data Steward;
- Technical Custodian;
- Consumer Representatives;
- Domain Expert where required.

---

# 25. Data Owner Responsibilities

- approve semantics;
- approve high-impact changes;
- define policy;
- resolve disputes;
- approve retirement.

---

# 26. Data Steward Responsibilities

- maintain values;
- validate mappings;
- manage labels;
- monitor quality;
- coordinate consumers;
- prepare publication.

---

# 27. Technical Custodian Responsibilities

- implement storage;
- versioning;
- APIs;
- caching;
- distribution;
- backup;
- reconciliation.

---

# 28. Consumer Responsibilities

- declare consumed version;
- stop hardcoding labels;
- handle deprecation;
- validate compatibility;
- reconcile local caches.

---

# 29. Code Set Scope

```text
GLOBAL
INDUSTRY
TENANT
ORGANIZATION
CLINIC
MODULE
SHARED_WITH_OVERRIDE
```

---

# 30. Global Scope

Digunakan lintas tenant.

Examples:

- country;
- currency;
- language.

---

# 31. Industry Scope

Digunakan oleh industry-specific modules.

---

# 32. Tenant Scope

Dikelola oleh satu tenant.

---

# 33. Organization Scope

Dikelola pada organization.

---

# 34. Clinic Scope

Dikelola pada clinic, harus memiliki parent tenant valid.

---

# 35. Module Scope

Private reference set milik module.

Private set tetap harus didaftarkan bila digunakan sebagai contract lintas module.

---

# 36. Shared with Override

Canonical semantics global dengan tenant-specific display atau activation override.

---

# 37. Tenant Override Rules

Tenant override may change:

- display label;
- visibility;
- sort order;
- local metadata;
- local alias.

Tenant override must not change:

- canonical code meaning;
- security semantics;
- compliance semantics;
- externally governed mapping;
- historical transaction meaning.

---

# 38. Tenant Extension Rules

Tenant may add values only when set is marked extensible.

---

# 39. Extension Namespace

Tenant-defined code recommended:

```text
TNT_{TENANT_CODE}_{LOCAL_CODE}
```

or an opaque canonical ID plus local code.

---

# 40. Canonical vs Local Values

Consumers must distinguish:

```text
CANONICAL
TENANT_DEFINED
EXTERNAL
ALIAS
```

---

# 41. Lifecycle of Code Set

```text
DRAFT
IN_REVIEW
APPROVED
PUBLISHED
DEPRECATED
RETIRED
```

---

# 42. Lifecycle of Reference Value

```text
DRAFT
ACTIVE
DEPRECATED
INACTIVE
RETIRED
```

---

# 43. Draft

Belum boleh digunakan production.

---

# 44. Published

Immutable version yang boleh digunakan consumer.

---

# 45. Deprecated

Masih resolvable, tetapi tidak boleh dipilih untuk transaksi baru kecuali exception.

---

# 46. Inactive

Tidak aktif untuk operasi normal, namun tetap valid untuk history.

---

# 47. Retired

Tidak didukung untuk penggunaan baru.

---

# 48. Code Reuse Prohibition

Retired code must never be reused for unrelated meaning.

---

# 49. Effective Dating

Minimum:

```text
valid_from
valid_to
published_at
retired_at
```

---

# 50. Effective Time Rules

- future activation allowed;
- overlapping validity prohibited unless explicitly modeled;
- valid_to must exceed valid_from;
- historical query must support `as_of`.

---

# 51. As-Of Resolution

Lookup service should support:

```text
current
specific_version
as_of_date
```

---

# 52. Versioning Model

Recommended:

```text
MAJOR.MINOR.PATCH
```

---

# 53. Major Version

Used for incompatible semantic or structural change.

Examples:

- code meaning changed;
- hierarchy semantics changed;
- values removed from active use with incompatible impact;
- mapping model changed.

---

# 54. Minor Version

Used for compatible additions.

Examples:

- new code;
- new localized label;
- new child taxonomy node;
- new compatible metadata.

---

# 55. Patch Version

Used for non-semantic correction.

Examples:

- typo correction;
- description clarification;
- metadata correction;
- sort order correction.

---

# 56. Published Version Immutability

Published version must not be edited in place.

---

# 57. Version Diff

Publication should provide:

```text
added
changed
deprecated
retired
mapping_changes
hierarchy_changes
```

---

# 58. Version Compatibility

```text
BACKWARD_COMPATIBLE
COMPATIBLE_WITH_WARNING
BREAKING
UNKNOWN
```

---

# 59. Consumer Version Pinning

Critical consumers should pin explicit version or approved compatible range.

---

# 60. Latest Version Use

Blind use of `latest` is prohibited for critical or regulated lookups.

---

# 61. Publication Workflow

```text
Change Request
→ Steward Draft
→ Validation
→ Impact Analysis
→ Owner Approval
→ Version Assignment
→ Publish
→ Distribute
→ Reconcile
→ Monitor
```

---

# 62. Publication Preconditions

- owner assigned;
- steward assigned;
- change reason;
- version correct;
- validation passes;
- mappings valid;
- hierarchy valid;
- localization complete;
- consumer impact reviewed;
- rollback/forward plan defined.

---

# 63. Publication Status

```text
DRAFT
VALIDATING
AWAITING_APPROVAL
APPROVED
PUBLISHED
FAILED
CANCELLED
```

---

# 64. High-Impact Change

Examples:

- status semantics;
- clinical classification;
- financial category;
- authorization-related code;
- hierarchy root change;
- retirement of widely used code.

---

# 65. High-Impact Approval

Requires:

- Data Owner;
- Domain Expert;
- Architecture or Security when relevant;
- impacted consumer representatives.

---

# 66. Emergency Change

Allowed for severe operational, legal, or security need.

Requires:

- reason;
- minimum validation;
- approval;
- communication;
- retrospective;
- permanent publication record.

---

# 67. Taxonomy Model

Taxonomy values may define:

```text
node_id
code
parent_code
path
depth
sort_order
validity
metadata
```

---

# 68. Hierarchy Rules

- parent must exist;
- cycle prohibited;
- root defined;
- path deterministic;
- effective dates valid;
- tenant scope compatible.

---

# 69. Multiple Parents

Multiple-parent taxonomy allowed only when explicitly modeled as graph.

---

# 70. Tree vs DAG

Supported structures:

```text
TREE
DIRECTED_ACYCLIC_GRAPH
FLAT
```

---

# 71. Hierarchy Cycle Detection

Must run:

- on change;
- before publication;
- after import;
- during reconciliation.

---

# 72. Orphan Node

Orphan nodes are prohibited unless explicitly allowed as root.

---

# 73. Depth Limit

Optional depth limit should be defined for UI/performance.

---

# 74. Path Materialization

May be used for performance, but source parent relationships remain authoritative.

---

# 75. Taxonomy Relationships

Potential relationships:

```text
PARENT_OF
CHILD_OF
RELATED_TO
BROADER_THAN
NARROWER_THAN
EQUIVALENT_TO
```

---

# 76. Classification Assignment

Assignment links entity to taxonomy node.

Minimum:

```text
entity_type
entity_id
taxonomy_code
node_code
valid_from
valid_to
source
```

---

# 77. Multiple Classification

An entity may have multiple classifications if scheme allows.

---

# 78. Primary Classification

May be marked explicitly.

---

# 79. Lookup Behavior

Lookup service must define:

- code resolution;
- label resolution;
- status filtering;
- version;
- locale;
- tenant scope;
- fallback.

---

# 80. Lookup Resolution Priority

Recommended:

```text
Tenant Override
→ Canonical Localized Label
→ Canonical Default Label
→ Alias Resolution
→ Not Found
```

---

# 81. Lookup Result Contract

Minimum result:

```text
code
canonical_code
display_name
description
status
version
source
scope
valid_from
valid_to
metadata
```

---

# 82. Lookup Not Found

Must return explicit error or null result according contract.

Do not silently invent label from code.

---

# 83. Lookup Validation

Validation should support:

```text
is_valid
is_active
is_deprecated
is_allowed_for_new_use
```

---

# 84. Selection vs Historical Resolution

A retired value may remain resolvable historically but not selectable for new records.

---

# 85. Aliases

Alias supports:

- previous code;
- external code;
- local abbreviation;
- migration compatibility.

---

# 86. Alias Rules

- alias unique within scope;
- alias points to canonical code;
- alias lifecycle tracked;
- alias resolution audited where high impact.

---

# 87. Canonicalization

Input code should be canonicalized before persistence when possible.

---

# 88. External Standards

External standard sets must record:

```text
standard_name
publisher
version
license
release_date
effective_date
source_reference
```

---

# 89. External Update Review

External version upgrades require impact analysis.

---

# 90. External License

License constraints must be documented and enforced.

---

# 91. Mapping Governance

Mappings connect source and target code sets.

---

# 92. Mapping Types

```text
EXACT
EQUIVALENT
BROADER
NARROWER
RELATED
CONDITIONAL
UNMAPPED
```

---

# 93. Mapping Direction

Mappings must define source and target direction.

---

# 94. Mapping Cardinality

```text
ONE_TO_ONE
ONE_TO_MANY
MANY_TO_ONE
MANY_TO_MANY
```

---

# 95. Mapping Conditions

Conditional mappings should define rules.

---

# 96. Mapping Confidence

```text
HIGH
MEDIUM
LOW
UNKNOWN
```

---

# 97. Mapping Status

```text
DRAFT
APPROVED
ACTIVE
DEPRECATED
RETIRED
REJECTED
```

---

# 98. Mapping Ownership

Mappings require owner and steward.

---

# 99. Mapping Approval

Clinical, financial, regulatory, or security-sensitive mappings require subject matter expert approval.

---

# 100. Unmapped Values

Unmapped values must be visible and tracked.

---

# 101. Mapping Versioning

Mapping set has independent version.

---

# 102. Mapping Validation

Validate:

- source exists;
- target exists;
- effective dates;
- cardinality;
- no conflicting active mapping;
- condition syntax;
- approval.

---

# 103. Localization

Code labels may have multiple locales.

---

# 104. Localization Fields

```text
locale
display_name
short_name
description
valid_from
valid_to
translation_status
```

---

# 105. Translation Status

```text
DRAFT
REVIEWED
APPROVED
MACHINE_TRANSLATED
REJECTED
```

---

# 106. Locale Fallback

Recommended:

```text
Requested Locale
→ Tenant Default Locale
→ Platform Default Locale
→ Canonical Code
```

---

# 107. Canonical Code as Fallback

Use code as last fallback only when UI policy allows.

---

# 108. Translation Governance

High-impact labels require human review.

---

# 109. Lookup Presentation

Presentation layer should not redefine canonical semantics.

---

# 110. Sort Order

Sort order may vary by locale or tenant only if policy allows.

---

# 111. Data Quality Dimensions

```text
VALIDITY
UNIQUENESS
COMPLETENESS
CONSISTENCY
INTEGRITY
TIMELINESS
CONFORMITY
```

---

# 112. Quality Rules

Examples:

- code unique;
- active label present;
- parent exists;
- no hierarchy cycle;
- valid date range;
- published version immutable;
- mapping target valid;
- localization complete.

---

# 113. Quality Severity

```text
INFO
WARNING
ERROR
CRITICAL
```

---

# 114. Publication Blocking Rules

Critical quality failures block publication.

---

# 115. Lookup Drift

Drift occurs when consumer/local copy differs from published version.

---

# 116. Drift Detection

Compare:

```text
Version
Checksum
Count
Value Hash
Hierarchy Hash
Mapping Hash
```

---

# 117. Drift Status

```text
MATCHED
STALE
MISMATCH
MISSING
UNKNOWN
```

---

# 118. Reconciliation

Reconciliation should identify:

- missing values;
- extra values;
- stale labels;
- incorrect mappings;
- hierarchy mismatch;
- wrong version.

---

# 119. Reconciliation Response

```text
Detect
→ Assess
→ Republish/Refresh
→ Verify
→ Record
```

---

# 120. Distribution Methods

```text
SYNCHRONOUS_API
EVENT
BATCH_EXPORT
CACHE
READ_MODEL
```

---

# 121. Reference Data API

Preferred for current queries and validation.

---

# 122. Event Distribution

Use for version publication and changes.

Examples:

```text
mdm.reference-set.published.v1
mdm.reference-value.deprecated.v1
mdm.taxonomy.changed.v1
mdm.mapping-set.published.v1
```

---

# 123. Consumer Subscription

Consumer declares:

```text
code_set
version_range
delivery_method
owner
reconciliation_policy
```

---

# 124. Consumer Responsibilities

- process idempotently;
- validate version;
- preserve tenant scope;
- reconcile;
- handle deprecation;
- report failure.

---

# 125. Cache Strategy

Reference data may be cached aggressively when version-aware.

---

# 126. Cache Key

Recommended:

```text
code_set
version
tenant
locale
scope
```

---

# 127. Cache Invalidation

Invalidation triggers:

- new publication;
- tenant override;
- localization update;
- mapping update;
- retirement.

---

# 128. Cache Stampede

Use controlled refresh for high-traffic code sets.

---

# 129. Offline Use

Offline consumers must pin version and define synchronization.

---

# 130. API Direction

Potential endpoints:

```text
GET  /api/internal/v1/reference-sets
GET  /api/internal/v1/reference-sets/{codeSet}
GET  /api/internal/v1/reference-sets/{codeSet}/versions
GET  /api/internal/v1/reference-sets/{codeSet}/versions/{version}/values
GET  /api/internal/v1/reference-sets/{codeSet}/resolve/{code}
POST /api/internal/v1/reference-sets/{codeSet}/validate
POST /api/internal/v1/reference-sets/{codeSet}/publish
GET  /api/internal/v1/taxonomies/{taxonomyCode}/tree
GET  /api/internal/v1/mappings/{mappingSet}
```

---

# 131. API Query Parameters

Potential:

```text
version
as_of
locale
tenant_id
include_deprecated
parent_code
depth
```

Trusted tenant context should not be derived only from raw `tenant_id`.

---

# 132. SDK Contract Direction

Potential contracts:

```text
ReferenceDataServiceInterface
TaxonomyServiceInterface
LookupResolverInterface
MappingServiceInterface
ReferenceDataPublisherInterface
ReferenceDataReconciliationInterface
```

---

# 133. Reference Data Service

```php
interface ReferenceDataServiceInterface
{
    public function values(
        string $codeSet,
        ReferenceDataQuery $query
    ): array;

    public function resolve(
        string $codeSet,
        string $code,
        ReferenceDataQuery $query
    ): ?ReferenceValue;

    public function validate(
        string $codeSet,
        string $code,
        ReferenceDataQuery $query
    ): ReferenceValidationResult;
}
```

---

# 134. Reference Data Query

```php
final readonly class ReferenceDataQuery
{
    public function __construct(
        public ?string $version = null,
        public ?\DateTimeImmutable $asOf = null,
        public ?string $locale = null,
        public ?TenantContextInterface $tenant = null,
        public bool $includeDeprecated = false,
    ) {
    }
}
```

---

# 135. Taxonomy Service

```php
interface TaxonomyServiceInterface
{
    public function children(
        string $taxonomyCode,
        string $parentCode,
        ReferenceDataQuery $query
    ): array;

    public function ancestors(
        string $taxonomyCode,
        string $code,
        ReferenceDataQuery $query
    ): array;

    public function tree(
        string $taxonomyCode,
        ReferenceDataQuery $query
    ): array;
}
```

---

# 136. Mapping Service

```php
interface MappingServiceInterface
{
    public function map(
        string $mappingSet,
        string $sourceCode,
        MappingContext $context
    ): array;
}
```

---

# 137. Database Direction

Potential tables:

```text
mdm_reference_sets
mdm_reference_set_versions
mdm_reference_values
mdm_reference_value_localizations
mdm_reference_aliases
mdm_taxonomy_relationships
mdm_mapping_sets
mdm_mapping_set_versions
mdm_reference_mappings
mdm_reference_publications
mdm_reference_consumers
mdm_reference_reconciliation_runs
mdm_reference_overrides
```

---

# 138. Table: mdm_reference_sets

```sql
CREATE TABLE mdm_reference_sets (
    id CHAR(26) NOT NULL,
    code_set VARCHAR(180) NOT NULL,
    name VARCHAR(255) NOT NULL,
    object_type VARCHAR(50) NOT NULL,
    owner_reference VARCHAR(180) NOT NULL,
    steward_reference VARCHAR(180) NOT NULL,
    scope_type VARCHAR(30) NOT NULL,
    current_version VARCHAR(100) NULL,
    tenant_extensible_flag TINYINT(1) NOT NULL DEFAULT 0,
    localization_flag TINYINT(1) NOT NULL DEFAULT 0,
    status VARCHAR(30) NOT NULL,

    PRIMARY KEY (id),
    UNIQUE KEY uq_mdm_reference_set_code (
        code_set
    ),
    KEY idx_mdm_reference_set_status (
        status,
        object_type
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

# 139. Table: mdm_reference_set_versions

```sql
CREATE TABLE mdm_reference_set_versions (
    id CHAR(26) NOT NULL,
    reference_set_id CHAR(26) NOT NULL,
    version VARCHAR(100) NOT NULL,
    compatibility_status VARCHAR(30) NOT NULL,
    checksum_sha256 CHAR(64) NOT NULL,
    change_summary_json JSON NULL,
    publication_status VARCHAR(30) NOT NULL,
    approved_by VARCHAR(180) NULL,
    published_at DATETIME(6) NULL,
    effective_from DATETIME(6) NULL,

    PRIMARY KEY (id),
    UNIQUE KEY uq_mdm_reference_set_version (
        reference_set_id,
        version
    ),
    UNIQUE KEY uq_mdm_reference_version_hash (
        reference_set_id,
        checksum_sha256
    ),
    CONSTRAINT fk_mdm_ref_version_set
        FOREIGN KEY (reference_set_id)
        REFERENCES mdm_reference_sets (id)
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

# 140. Table: mdm_reference_values

```sql
CREATE TABLE mdm_reference_values (
    id CHAR(26) NOT NULL,
    reference_set_version_id CHAR(26) NOT NULL,
    code VARCHAR(180) NOT NULL,
    display_name VARCHAR(500) NOT NULL,
    short_name VARCHAR(255) NULL,
    description_text LONGTEXT NULL,
    parent_code VARCHAR(180) NULL,
    sort_order INT NOT NULL DEFAULT 0,
    value_status VARCHAR(30) NOT NULL,
    valid_from DATETIME(6) NULL,
    valid_to DATETIME(6) NULL,
    metadata_json JSON NULL,

    PRIMARY KEY (id),
    UNIQUE KEY uq_mdm_reference_value (
        reference_set_version_id,
        code
    ),
    KEY idx_mdm_reference_value_status (
        reference_set_version_id,
        value_status,
        sort_order
    ),
    CONSTRAINT fk_mdm_reference_value_version
        FOREIGN KEY (reference_set_version_id)
        REFERENCES mdm_reference_set_versions (id)
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

# 141. Table: mdm_reference_value_localizations

```sql
CREATE TABLE mdm_reference_value_localizations (
    id CHAR(26) NOT NULL,
    reference_value_id CHAR(26) NOT NULL,
    locale VARCHAR(30) NOT NULL,
    display_name VARCHAR(500) NOT NULL,
    short_name VARCHAR(255) NULL,
    description_text LONGTEXT NULL,
    translation_status VARCHAR(30) NOT NULL,
    valid_from DATETIME(6) NULL,
    valid_to DATETIME(6) NULL,

    PRIMARY KEY (id),
    UNIQUE KEY uq_mdm_reference_localization (
        reference_value_id,
        locale
    ),
    CONSTRAINT fk_mdm_reference_localization_value
        FOREIGN KEY (reference_value_id)
        REFERENCES mdm_reference_values (id)
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

# 142. Table: mdm_reference_aliases

```sql
CREATE TABLE mdm_reference_aliases (
    id CHAR(26) NOT NULL,
    reference_set_id CHAR(26) NOT NULL,
    tenant_id CHAR(26) NULL,
    alias_code VARCHAR(180) NOT NULL,
    canonical_code VARCHAR(180) NOT NULL,
    alias_type VARCHAR(30) NOT NULL,
    status VARCHAR(30) NOT NULL,
    valid_from DATETIME(6) NULL,
    valid_to DATETIME(6) NULL,

    PRIMARY KEY (id),
    UNIQUE KEY uq_mdm_reference_alias (
        reference_set_id,
        tenant_id,
        alias_code
    ),
    CONSTRAINT fk_mdm_reference_alias_set
        FOREIGN KEY (reference_set_id)
        REFERENCES mdm_reference_sets (id)
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

# 143. Table: mdm_mapping_sets

```sql
CREATE TABLE mdm_mapping_sets (
    id CHAR(26) NOT NULL,
    mapping_set_code VARCHAR(180) NOT NULL,
    source_reference_set_id CHAR(26) NOT NULL,
    target_reference_set_id CHAR(26) NOT NULL,
    owner_reference VARCHAR(180) NOT NULL,
    steward_reference VARCHAR(180) NOT NULL,
    current_version VARCHAR(100) NULL,
    status VARCHAR(30) NOT NULL,

    PRIMARY KEY (id),
    UNIQUE KEY uq_mdm_mapping_set_code (
        mapping_set_code
    ),
    CONSTRAINT fk_mdm_mapping_source_set
        FOREIGN KEY (source_reference_set_id)
        REFERENCES mdm_reference_sets (id),
    CONSTRAINT fk_mdm_mapping_target_set
        FOREIGN KEY (target_reference_set_id)
        REFERENCES mdm_reference_sets (id)
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

# 144. Table: mdm_reference_mappings

```sql
CREATE TABLE mdm_reference_mappings (
    id CHAR(26) NOT NULL,
    mapping_set_id CHAR(26) NOT NULL,
    mapping_version VARCHAR(100) NOT NULL,
    source_code VARCHAR(180) NOT NULL,
    target_code VARCHAR(180) NOT NULL,
    mapping_type VARCHAR(30) NOT NULL,
    cardinality VARCHAR(30) NOT NULL,
    confidence VARCHAR(30) NOT NULL,
    condition_json JSON NULL,
    mapping_status VARCHAR(30) NOT NULL,
    valid_from DATETIME(6) NULL,
    valid_to DATETIME(6) NULL,
    approved_by VARCHAR(180) NULL,

    PRIMARY KEY (id),
    UNIQUE KEY uq_mdm_reference_mapping (
        mapping_set_id,
        mapping_version,
        source_code,
        target_code
    ),
    KEY idx_mdm_mapping_status (
        mapping_set_id,
        mapping_version,
        mapping_status
    ),
    CONSTRAINT fk_mdm_reference_mapping_set
        FOREIGN KEY (mapping_set_id)
        REFERENCES mdm_mapping_sets (id)
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

# 145. Table: mdm_reference_overrides

```sql
CREATE TABLE mdm_reference_overrides (
    id CHAR(26) NOT NULL,
    reference_set_id CHAR(26) NOT NULL,
    tenant_id CHAR(26) NOT NULL,
    clinic_id CHAR(26) NULL,
    canonical_code VARCHAR(180) NOT NULL,
    display_name_override VARCHAR(500) NULL,
    sort_order_override INT NULL,
    visibility_status VARCHAR(30) NULL,
    metadata_json JSON NULL,
    config_version VARCHAR(100) NOT NULL,
    status VARCHAR(30) NOT NULL,

    PRIMARY KEY (id),
    UNIQUE KEY uq_mdm_reference_override (
        reference_set_id,
        tenant_id,
        clinic_id,
        canonical_code,
        config_version
    ),
    CONSTRAINT fk_mdm_reference_override_set
        FOREIGN KEY (reference_set_id)
        REFERENCES mdm_reference_sets (id)
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

# 146. Publication Artifact

A publication package should contain:

```text
code_set
version
values
hierarchy
localizations
aliases
mappings
checksum
change_summary
effective_date
approval
```

---

# 147. Publication Integrity

Validate checksum and immutability.

---

# 148. Lookup Snapshot

Consumers may use versioned lookup snapshots.

---

# 149. Snapshot Metadata

```text
code_set
version
checksum
generated_at
locale
tenant
```

---

# 150. Import Governance

Imports must:

- use staging;
- validate schema;
- validate codes;
- detect duplicates;
- validate hierarchy;
- validate mappings;
- produce preview;
- require approval;
- generate publication version.

---

# 151. Import Status

```text
UPLOADED
VALIDATING
READY
PROCESSING
COMPLETED
COMPLETED_WITH_ERRORS
FAILED
CANCELLED
```

---

# 152. Export Governance

Exports should preserve:

- version;
- codes;
- labels;
- hierarchy;
- effective dates;
- mapping metadata;
- checksum.

---

# 153. CSV Export Direction

Recommended columns:

```text
code_set
version
code
display_name
description
parent_code
sort_order
status
valid_from
valid_to
```

---

# 154. JSON Export Direction

Recommended for structured taxonomies and mappings.

---

# 155. Change Request Record

Minimum:

```text
change_id
code_set
change_type
reason
requested_by
owner
impact
target_version
status
```

---

# 156. Change Types

```text
ADD_VALUE
UPDATE_LABEL
UPDATE_DESCRIPTION
CHANGE_HIERARCHY
ADD_MAPPING
DEPRECATE_VALUE
RETIRE_VALUE
LOCALIZE
TENANT_OVERRIDE
```

---

# 157. Impact Analysis

Assess:

- consumers;
- workflows;
- validation;
- reports;
- APIs;
- integrations;
- historical data;
- tenant overrides;
- mappings.

---

# 158. Rollback Strategy

Published versions are not edited.

Rollback means consumers return to previous published version where compatible.

---

# 159. Roll-Forward Strategy

Preferred when:

- new values already used;
- historical transactions reference new code;
- mappings changed irreversibly;
- previous version incompatible.

---

# 160. Historical Integrity

Transactions should store:

- code;
- code set;
- version where critical;
- optional label snapshot for legal/reporting use.

---

# 161. Display Label Snapshot

May be stored in transactions only when required, but canonical code remains authoritative.

---

# 162. Security

Sensitive code sets may require restricted access.

Examples:

- fraud reasons;
- security incident categories;
- privileged access reasons;
- restricted clinical classifications.

---

# 163. Authorization

Permissions may include:

```text
mdm.reference.view
mdm.reference.manage
mdm.reference.publish
mdm.reference.map
mdm.reference.override
mdm.reference.retire
```

---

# 164. Segregation of Duties

High-impact publication should separate:

- requester;
- steward;
- approver;
- publisher;
- verifier.

---

# 165. Audit Events

Audit:

```text
REFERENCE_SET_CREATED
REFERENCE_VALUE_ADDED
REFERENCE_VALUE_CHANGED
REFERENCE_VALUE_DEPRECATED
REFERENCE_VALUE_RETIRED
REFERENCE_SET_PUBLISHED
TAXONOMY_CHANGED
MAPPING_APPROVED
TENANT_OVERRIDE_CHANGED
REFERENCE_IMPORT_COMPLETED
REFERENCE_RECONCILIATION_FAILED
```

---

# 166. Audit Metadata

Include:

```text
actor
code_set
version
code
change_type
before_reference
after_reference
reason
approval
tenant
correlation
```

---

# 167. Event Codes

```text
MDM_CODE_SET_REGISTERED
MDM_CODE_SET_VERSION_CREATED
MDM_CODE_SET_PUBLISHED
MDM_REFERENCE_VALUE_ADDED
MDM_REFERENCE_VALUE_DEPRECATED
MDM_REFERENCE_VALUE_RETIRED
MDM_TAXONOMY_NODE_MOVED
MDM_MAPPING_SET_PUBLISHED
MDM_LOCALIZATION_APPROVED
MDM_LOOKUP_DRIFT_DETECTED
MDM_LOOKUP_RECONCILIATION_COMPLETED
```

---

# 168. Error Codes

```text
MDM_CODE_SET_NOT_FOUND
MDM_CODE_SET_VERSION_NOT_FOUND
MDM_CODE_DUPLICATE
MDM_CODE_REUSE_PROHIBITED
MDM_CODE_INVALID
MDM_REFERENCE_VALUE_NOT_FOUND
MDM_REFERENCE_VALUE_INACTIVE
MDM_REFERENCE_VALUE_DEPRECATED
MDM_TAXONOMY_PARENT_NOT_FOUND
MDM_TAXONOMY_CYCLE
MDM_MAPPING_CONFLICT
MDM_MAPPING_TARGET_INVALID
MDM_LOCALE_NOT_SUPPORTED
MDM_TENANT_OVERRIDE_NOT_ALLOWED
MDM_PUBLICATION_BLOCKED
MDM_LOOKUP_DRIFT_DETECTED
```

---

# 169. Metrics

```text
mdm_code_set_total
mdm_published_version_total
mdm_deprecated_value_total
mdm_retired_value_total
mdm_unmapped_value_total
mdm_mapping_conflict_total
mdm_taxonomy_cycle_attempt_total
mdm_lookup_drift_total
mdm_reference_reconciliation_mismatch_total
mdm_translation_pending_total
mdm_tenant_override_total
```

---

# 170. KPIs

Initial targets:

```text
Published code sets without owner = 0
Published code sets without steward = 0
Code reuse violations = 0
Critical mapping conflicts unresolved = 0
Critical lookup drift unresolved = 0
Published versions with checksum = 100%
High-impact publications with approval = 100%
Cross-tenant override violations = 0
```

---

# 171. KRIs

```text
Deprecated values still used for new transactions
Unmapped external codes
Stale consumer versions
Taxonomy hierarchy churn
Translation backlog
Tenant override growth
Emergency publications
Repeated reconciliation mismatch
```

---

# 172. Dashboard Views

Recommended:

- code sets by status;
- published versions;
- upcoming deprecations;
- retired values still referenced;
- mapping completeness;
- mapping conflicts;
- taxonomy health;
- localization status;
- consumer version adoption;
- reconciliation status;
- tenant overrides.

---

# 173. Reference Example: Workflow Status

```yaml
code_set: workflow.status
version: 1.0.0
object_type: STATUS_MACHINE_LOOKUP
values:
  - code: DRAFT
    display_name: Draft
    status: ACTIVE
    sort_order: 10
  - code: SUBMITTED
    display_name: Submitted
    status: ACTIVE
    sort_order: 20
  - code: APPROVED
    display_name: Approved
    status: ACTIVE
    sort_order: 30
```

---

# 174. Reference Example: Service Taxonomy

```yaml
code_set: service.category
version: 2.0.0
object_type: HIERARCHICAL_TAXONOMY
values:
  - code: HEALTHCARE
    display_name: Healthcare
  - code: HOMECARE
    display_name: Homecare
    parent_code: HEALTHCARE
  - code: WOUND_CARE
    display_name: Wound Care
    parent_code: HOMECARE
```

---

# 175. Reference Example: External Mapping

```yaml
mapping_set: local-service-to-external-standard
version: 1.1.0
source_code_set: service.category
target_code_set: external.service.classification
mappings:
  - source: WOUND_CARE
    target: EXT-1042
    type: EQUIVALENT
    confidence: HIGH
    status: ACTIVE
```

---

# 176. Reference Example: Tenant Override

```yaml
tenant_id: tenant-001
code_set: service.category
canonical_code: WOUND_CARE
display_name_override: Perawatan Luka
visibility_status: ACTIVE
config_version: CFG-TNT-001-MDM-004
```

---

# 177. Code Set Onboarding Checklist

- [ ] Code set name unique.
- [ ] Object type defined.
- [ ] Owner assigned.
- [ ] Steward assigned.
- [ ] Scope defined.
- [ ] Versioning policy defined.
- [ ] Effective dating defined.
- [ ] Localization policy defined.
- [ ] Tenant extensibility defined.
- [ ] Security classification assigned.
- [ ] Consumers identified.
- [ ] Initial quality rules defined.

---

# 178. Publication Checklist

- [ ] Change request approved.
- [ ] Version increment correct.
- [ ] Codes unique.
- [ ] Code reuse absent.
- [ ] Labels complete.
- [ ] Effective dates valid.
- [ ] Hierarchy valid.
- [ ] Mappings valid.
- [ ] Localizations reviewed.
- [ ] Consumer impact assessed.
- [ ] Checksum generated.
- [ ] Publication artifact stored.
- [ ] Distribution triggered.
- [ ] Reconciliation scheduled.

---

# 179. Taxonomy Checklist

- [ ] Root defined.
- [ ] Parents exist.
- [ ] Cycles absent.
- [ ] Orphans absent.
- [ ] Depth acceptable.
- [ ] Effective dates consistent.
- [ ] Multiple-parent policy defined.
- [ ] Historical hierarchy resolvable.
- [ ] Tenant scope valid.
- [ ] Path/checksum generated.

---

# 180. Mapping Checklist

- [ ] Source set exists.
- [ ] Target set exists.
- [ ] Source code valid.
- [ ] Target code valid.
- [ ] Mapping type defined.
- [ ] Cardinality defined.
- [ ] Confidence defined.
- [ ] Conditions validated.
- [ ] Effective dates valid.
- [ ] Owner/steward approval complete.
- [ ] Conflicts absent.
- [ ] Unmapped values reported.

---

# 181. Tenant Override Checklist

- [ ] Set allows override.
- [ ] Tenant context trusted.
- [ ] Canonical code exists.
- [ ] Semantics unchanged.
- [ ] Security meaning unchanged.
- [ ] Localization valid.
- [ ] Sort/visibility override valid.
- [ ] Version recorded.
- [ ] Audit event recorded.
- [ ] Cache invalidated.

---

# 182. UAT — Registry & Ownership

- [ ] Code sets registered.
- [ ] Names unique.
- [ ] Owners required.
- [ ] Stewards required.
- [ ] Object types valid.
- [ ] Scope rules enforced.
- [ ] Consumers inventoried.
- [ ] Security classification available.

---

# 183. UAT — Code Governance

- [ ] Duplicate code rejected.
- [ ] Retired code reuse rejected.
- [ ] Labels may change safely.
- [ ] Semantic change requires major version.
- [ ] Historical code remains resolvable.
- [ ] New selection excludes retired values.
- [ ] Alias resolves canonical code.
- [ ] Numeric leading zeros preserved.

---

# 184. UAT — Versioning & Publication

- [ ] SemVer rules work.
- [ ] Published versions immutable.
- [ ] Diff generated.
- [ ] Compatibility assessed.
- [ ] High-impact approval required.
- [ ] Publication artifact created.
- [ ] Checksum validates.
- [ ] Emergency publication audited.
- [ ] Rollback/roll-forward documented.

---

# 185. UAT — Taxonomy

- [ ] Parent validation works.
- [ ] Cycle detection works.
- [ ] Orphan detection works.
- [ ] Tree queries work.
- [ ] Ancestor/descendant queries work.
- [ ] Effective dating works.
- [ ] Multiple hierarchy policy works.
- [ ] Historical tree resolution works.
- [ ] Tenant boundaries enforced.

---

# 186. UAT — Mapping

- [ ] Mapping sets versioned.
- [ ] Mapping types validated.
- [ ] Cardinality validated.
- [ ] Conflicts detected.
- [ ] Conditional mapping works.
- [ ] Confidence recorded.
- [ ] Unmapped values visible.
- [ ] Expert approval enforced.
- [ ] Historical mappings resolvable.

---

# 187. UAT — Localization

- [ ] Locale labels resolve.
- [ ] Fallback deterministic.
- [ ] Translation status enforced.
- [ ] High-impact translation review works.
- [ ] Tenant label override works.
- [ ] Canonical semantics preserved.
- [ ] Missing locale handled safely.
- [ ] Cache keys include locale.

---

# 188. UAT — Lookup Service

- [ ] Current resolution works.
- [ ] Version resolution works.
- [ ] As-of resolution works.
- [ ] Tenant override priority works.
- [ ] Deprecated status visible.
- [ ] Active selection filtering works.
- [ ] Not-found behavior explicit.
- [ ] Validation result distinguishes active/deprecated.
- [ ] Authorization enforced for restricted sets.

---

# 189. UAT — Distribution & Cache

- [ ] API distribution works.
- [ ] Publication event emitted.
- [ ] Consumer version tracked.
- [ ] Idempotent processing works.
- [ ] Cache versioning works.
- [ ] Cache invalidation works.
- [ ] Offline snapshot includes checksum.
- [ ] Stale consumer detected.
- [ ] Reconciliation corrects drift.

---

# 190. UAT — Multi-Tenant Controls

- [ ] Global and tenant sets distinguished.
- [ ] Tenant extension allowed only when configured.
- [ ] Tenant code namespace enforced.
- [ ] Cross-tenant override denied.
- [ ] Clinic belongs to tenant.
- [ ] Canonical meaning cannot be overridden.
- [ ] Security semantics protected.
- [ ] Audit trail complete.
- [ ] Tenant cache isolation works.

---

# 191. UAT — Governance & Metrics

- [ ] Change requests traceable.
- [ ] SoD enforced.
- [ ] Audit events complete.
- [ ] Metrics available.
- [ ] KPIs/KRIs defined.
- [ ] Dashboard views defined.
- [ ] Deprecation backlog visible.
- [ ] Mapping backlog visible.
- [ ] Exceptions expire.

---

# 192. Definition of Done — SSOT-MDM-02

SSOT-MDM-02 dianggap selesai bila:

- [ ] objectives/principles tersedia;
- [ ] definitions/object types tersedia;
- [ ] registry model tersedia;
- [ ] naming rules tersedia;
- [ ] code/label/metadata rules tersedia;
- [ ] ownership/stewardship tersedia;
- [ ] scope model tersedia;
- [ ] tenant override/extension rules tersedia;
- [ ] lifecycle tersedia;
- [ ] effective dating tersedia;
- [ ] versioning tersedia;
- [ ] compatibility/diff tersedia;
- [ ] publication workflow tersedia;
- [ ] high-impact/emergency change tersedia;
- [ ] taxonomy model tersedia;
- [ ] tree/DAG/cycle controls tersedia;
- [ ] classification assignment tersedia;
- [ ] lookup behavior tersedia;
- [ ] alias/canonicalization tersedia;
- [ ] external standard governance tersedia;
- [ ] mapping model tersedia;
- [ ] localization tersedia;
- [ ] quality rules tersedia;
- [ ] drift/reconciliation tersedia;
- [ ] distribution/caching tersedia;
- [ ] API/SDK direction tersedia;
- [ ] database direction tersedia;
- [ ] publication/import/export tersedia;
- [ ] historical integrity tersedia;
- [ ] security/authorization/SoD tersedia;
- [ ] audit/event/error codes tersedia;
- [ ] metrics/KPI/KRI tersedia;
- [ ] examples/checklists/UAT tersedia.

---

# 193. Implementation Roadmap

## Phase 1 — Registry Foundation

- create code set registry;
- assign owners/stewards;
- define naming and lifecycle;
- define schema;
- register current lookup sources.

## Phase 2 — Versioned Reference Service

- implement version tables;
- immutable publication;
- lookup API;
- locale support;
- cache/version controls.

## Phase 3 — Taxonomy & Mapping

- hierarchy service;
- cycle validation;
- mapping registry;
- external standards;
- classification assignments.

## Phase 4 — Tenant Governance

- tenant overrides;
- tenant extensions;
- clinic scope;
- permission controls;
- audit and reconciliation.

## Phase 5 — Distribution & Automation

- publication events;
- consumer subscriptions;
- version adoption dashboards;
- automated drift detection;
- reference data quality gates.

---

# 194. Initial Implementation Backlog

```text
MDMR-001 Code Set Registry
MDMR-002 Reference Set Schema
MDMR-003 Version Publication Service
MDMR-004 Lookup Resolver
MDMR-005 As-Of Lookup Support
MDMR-006 Localization Registry
MDMR-007 Alias Resolver
MDMR-008 Taxonomy Service
MDMR-009 Hierarchy Cycle Validator
MDMR-010 Mapping Registry
MDMR-011 External Standard Registry
MDMR-012 Tenant Override Service
MDMR-013 Tenant Extension Service
MDMR-014 Reference Cache
MDMR-015 Publication Event Publisher
MDMR-016 Consumer Subscription Registry
MDMR-017 Reconciliation Engine
MDMR-018 Reference Governance Dashboard
```

---

# 195. Approval Gate

Dokumen dapat menjadi Approved setelah:

- Data Governance review;
- Platform Governance review;
- Domain Owner review;
- Data Steward review;
- Platform Architecture review;
- Security and Privacy review;
- Multi-tenant isolation review;
- Module Owner review;
- Integration review;
- localization and external-standard review;
- reconciliation and quality review.

---

# 196. Closing Statement

Code set, taxonomy, dan lookup governance harus memastikan setiap reference value:

- memiliki code stabil;
- memiliki arti yang jelas;
- memiliki owner;
- memiliki steward;
- memiliki version;
- memiliki lifecycle;
- memiliki effective dates;
- dapat dilokalkan;
- dapat dipetakan;
- tenant-safe;
- dapat didistribusikan;
- dapat direkonsiliasi;
- dapat diaudit;
- tetap resolvable secara historis.

Lookup tidak boleh menjadi hardcoded array yang tersebar di controller, form, database, dan module secara terpisah.

Reference data harus menjadi governed contract yang versioned, canonical, reusable, dan aman untuk seluruh platform.
