
# SSOT-ROADMAP.md
# Enterprise Platform Kernel Roadmap

**Version:** 1.0
**Terakhir disinkronkan ke SSOT-INDEX Versi 2.0:** 2026-07-07 (lihat catatan besar di bagian bawah dokumen, sebelum "Dependency Flow", untuk ringkasan lengkap perluasan paket SSOT dari 84 menjadi 132 file / 26 folder yang terjadi di luar kendali dokumen ini)

---

# Tujuan

Roadmap ini menjadi acuan resmi urutan implementasi Platform Kernel sehingga seluruh tim membangun fondasi terlebih dahulu sebelum modul bisnis.

Prinsip:

- Foundation First
- Security by Default
- Reuse Before Build
- Event Driven
- Incremental Delivery

---

# Phase 0 — Governance & Vision

## Objective

Menyamakan visi dan aturan platform.

### Deliverables

- README
- SSOT-INDEX
- Vision & Principles
- Scope
- Architecture Blueprint
- Development Planning

**Status:** ✅

### Update 2026-07-05 — Governance Framework diperluas

Enam dokumen governance formal telah selesai, melampaui cakupan awal Phase 0 (yang semula hanya visi/prinsip):

- SSOT-GOV-01 — Governance Framework
- SSOT-GOV-02 — Architecture Decision Records (ADR), termasuk 5 ADR contoh
- SSOT-GOV-03 — Coding Standards Governance
- SSOT-GOV-04 — Risk, Control & Exception Management
- SSOT-GOV-05 — Compliance & Audit Governance
- SSOT-GOV-06 — Change & Release Governance

### Update 2026-07-06 — Implementation & Coding Standards ditemukan belum terindeks

Re-check SSOT menemukan folder `17-Implementation/` (5 file, sudah ada di disk sejak awal proyek, dikutip di kode sejak modul pertama) belum pernah masuk SSOT-INDEX/ROADMAP/DEPENDENCY-MATRIX:

- SSOT-STACK-01 — PHP + MySQL + XAMPP Standard
- SSOT-CODE-01 — PHP Coding Standard
- SSOT-DEV-01 — Local Development Guide for Windows
- SSOT-IMPLEMENTATION-01 — Modular Monolith Architecture & Module Lifecycle
- SSOT-MYSQL-01 — MySQL Implementation Rules

Ditempatkan di sini (Phase 0) karena sifatnya cross-cutting/konvensi, bukan runtime dependency gate seperti fase lain — lihat SSOT-INDEX.md §17 "Implementation Standards" untuk detail (catatan: nomor section ini berubah menjadi §17 tanpa collision setelah SSOT-INDEX.md disinkronkan ulang ke Versi 2.0 pada 2026-07-07; referensi sebelumnya ke "§16B" pada catatan ini sudah usang, lihat catatan besar di bawah Phase 16 tentang perluasan SSOT yang jauh lebih luas dari perbaikan kecil ini).

**Overlap yang perlu diperhatikan, bukan kesalahan tapi layak diketahui**: SSOT-GOV-03 (di atas, "Coding Standards Governance") dan SSOT-CODE-01 ("PHP Coding Standard") membahas topik yang sama dari sudut berbeda — GOV-03 lebih luas (PHP+SQL+HTML+JS+API+Testing+Security+Review+Automation, level governance/proses), CODE-01 lebih sempit dan preskriptif (PHP saja, lengkap dengan contoh kode konkret). Keduanya konsisten satu sama lain sejauh yang diperiksa (strict_types, PSR-12, final class, no SQL di view, dst.), tapi platform ini punya DUA dokumen "coding standard" yang tumpang tindih, bukan satu. Belum ada keputusan formal (ADR) tentang mana yang otoritatif bila keduanya berbeda di masa depan.

### Update 2026-07-07 — SSOT-GOV-07 ditambahkan (SSOT Repository Integrity Governance)

`SSOT-GOV-07 — SSOT Repository Integrity, Document Identity & Dependency Validation Governance` ditambahkan oleh sebuah proses konsolidasi otomatis (lihat catatan besar di bawah dokumen ini). GOV-07 sendiri adalah dokumen yang mendefinisikan aturan index/taxonomy/dependency-validation yang dipakai proses konsolidasi tersebut untuk menghasilkan `SSOT-INTEGRITY-REPORT.md` dan `SSOT-INDEX.md` Versi 2.0. Bergantung pada GOV-01..06, AUDIT-01, TEST-01.

---

# Phase 1 — Identity & Security Foundation

## Objective

Membangun identitas pengguna dan keamanan dasar.

### Domain

- IAM
- RBAC
- Scope
- Audit

### Deliverables

- User Management
- Authentication
- MFA
- Service Account
- API Key
- Permission Engine
- Audit Trail

**Status:** ✅

### Update 2026-07-07 — 14 dokumen IAM/RBAC/Menu baru ditambahkan

Perluasan besar terjadi di luar kendali sesi kerja ini (lihat catatan besar di bawah dokumen). Fase ini semula hanya IAM-01..05 + RBAC-01..03 + MENU-01, sekarang mencakup:

- SSOT-IAM-06 — Federation, SSO & External Identity Architecture (OIDC/OAuth2/SAML2)
- SSOT-IAM-07 — Identity Lifecycle Provisioning & Deprovisioning (joiner/mover/leaver)
- SSOT-IAM-08 — Identity Risk, Account Recovery & Identity Proofing
- SSOT-MENU-02 — Menu Registry & Contribution Model
- SSOT-MENU-03 — Menu Projection by Role, Scope & Feature Flag
- SSOT-MENU-04 — Navigation Governance & Route Binding
- SSOT-RBAC-04 — Scoped Role Assignment & Authorization Scope
- SSOT-RBAC-05 — Policy Enforcement & Authorization Decision Architecture (PDP/PEP/PIP/PAP)
- SSOT-RBAC-06 — Permission Catalog Governance
- SSOT-RBAC-07 — Segregation of Duties & Conflict Policy
- SSOT-RBAC-08 — Privileged Access & Temporary Grant Governance (PAM/JIT/break-glass)
- SSOT-RBAC-09 — Access Review & Certification Governance
- SSOT-RBAC-10 — Role Catalog & Role Lifecycle Governance
- SSOT-RBAC-11 — Authorization Reconciliation & Drift Management

Semua "Draft Architecture" (belum diimplementasikan di `nerslink-mvp` — MVP saat ini hanya menerapkan MFA sederhana, role-grant restriction system_admin-only, dan dynamic menu dasar; tidak ada federation/SSO, PDP/PEP terpisah, SoD, PAM, atau access-review campaign). Ini adalah backlog governance, bukan regresi dari yang sudah dibangun.

**Catatan konsistensi**: SSOT-RBAC-04 dan beberapa dokumen baru lain mencantumkan `SSOT-SCOPE-01` sebagai dependency — per ADR-0001 (lihat catatan besar di bawah dokumen), dependency tersebut secara konseptual harus dibaca sebagai mengarah ke SCOPE-01A/skema yang sudah dibangun untuk keperluan implementasi nyata, bukan ke hierarchy/schema SCOPE-01 yang superseded. Dokumen-dokumen RBAC baru ini sendiri belum direview ulang untuk memastikan konsisten dengan keputusan ini (di luar cakupan re-check kali ini).

---

# Phase 2 — Data Foundation

## Objective

Standarisasi penyimpanan data.

### Domain

- Database Standards
- Migration
- Repository
- Data Lifecycle
- Backup & Disaster Recovery

**Status:** ✅

### Update 2026-07-06 — SSOT-DATA-05 ditemukan belum terindeks

Re-check SSOT menemukan `SSOT-DATA-05 — Backup & Disaster Recovery` sudah ada di disk (`05-Data/`) sejak awal proyek tapi belum pernah masuk SSOT-INDEX.md/ROADMAP/DEPENDENCY-MATRIX. Sudah ditambahkan ke ketiganya. Catatan: isinya overlap dengan SSOT-DEPLOY-04 (Phase 12) — DATA-05 adalah standar level data (RPO/RTO, strategi backup, restore test), DEPLOY-04 adalah prosedur level deployment/infra. Belum ada implementasi backup/DR nyata di MVP (di luar scope MVP saat ini, murni dokumentasi kernel).

### Update 2026-07-07 — 6 dokumen Data/Analytics/Records/Privacy baru ditambahkan

Perluasan besar di luar kendali sesi kerja ini (lihat catatan besar di bawah dokumen). Ditambahkan ke Data Foundation:

- SSOT-DATA-06 — Data Classification, Privacy & Access Governance
- SSOT-DATA-07 — Data Exchange, Canonical Mapping & Transformation Governance (ini mengisi gap "Data Exchange" yang sebelumnya dicatat sebagai satu-satunya gap prioritas #1 di SSOT-INDEX §23 versi lama)
- SSOT-DATA-08 — Data Quality Operations, Issue Management & Remediation Governance
- SSOT-DATA-09 — Data Lifecycle Enforcement, Archival & Secure Disposal Governance
- SSOT-ANALYTICS-01 — Analytics, Metrics & Semantic Layer Governance (folder `22-Analytics/`, tapi INDEX v2.0 mengelompokkannya di bawah domain "05. Data")

Dua dokumen lagi ditambahkan yang secara isi adalah perluasan data-governance (retensi/legal-hold dan privacy-rights), tapi SSOT-INDEX v2.0 menaruhnya di bawah domain "01. Scope" — penempatan yang tidak konsisten dengan folder fisiknya (`23-Records/`, `24-Privacy/`) maupun isinya. Dicatat di sini (Data Foundation) karena secara substansi keduanya adalah data-lifecycle/governance, bukan scope-hierarchy:

- SSOT-RECORDS-01 — Records, Retention, Legal Hold & Defensible Disposition Governance
- SSOT-PRIVACY-01 — Privacy Operations, Data Subject Rights & Request Fulfillment Governance

Semua "Draft Architecture", belum diimplementasikan di `nerslink-mvp` (tidak ada data classification/masking, canonical data exchange, data quality monitoring, retention/legal-hold enforcement, atau privacy-request fulfillment nyata di MVP saat ini).

---

# Phase 3 — Business Process Foundation

## Objective

Membangun mesin proses bisnis.

### Domain

- Workflow
- State Machine
- Approval
- Scheduler

**Status:** ✅

### Update 2026-07-07 — 3 dokumen Workflow governance baru

- SSOT-WF-05 — Workflow Definition Registry & Versioning Governance
- SSOT-WF-06 — Human Task, Inbox & Assignment Governance
- SSOT-WF-07 — Workflow Recovery, Compensation & Reconciliation Governance

Draft Architecture, belum diimplementasikan (MVP saat ini tidak punya workflow engine terpisah — status transition Appointment/Encounter ditangani langsung di masing-masing Service class, bukan lewat definition registry/human-task-inbox generik).

---

# Phase 4 — Communication Foundation

## Objective

Standarisasi komunikasi internal.

### Domain

- Notification
- Template
- Preference

**Status:** ✅

### Update 2026-07-07 — 2 dokumen Notification governance baru

- SSOT-NOTIFY-04 — Notification Delivery, Retry & Failure Governance
- SSOT-NOTIFY-05 — Consent, Preference & Communication Compliance

Draft Architecture, belum diimplementasikan (`NotificationService` MVP saat ini minimal — tidak ada retry/dead-letter/consent-preference-center).

---

# Phase 5 — API Foundation

## Objective

Standarisasi akses platform.

### Domain

- REST API
- Authentication Flow
- Gateway
- Webhook
- Versioning

**Status:** ✅

### Update 2026-07-07 — 4 dokumen API governance baru

- SSOT-API-06 — API Authorization, Scope & Resource Binding Governance
- SSOT-API-07 — API Idempotency, Concurrency & Request Safety Governance
- SSOT-API-08 — API Consumer, Client Registration & Credential Governance
- SSOT-API-09 — API Consumer Certification & Conformance Governance

Draft Architecture, belum diimplementasikan (MVP tidak punya idempotency-key handling, client-registration registry, atau conformance certification untuk API consumer).

---

# Phase 6 — Event Foundation

## Objective

Membangun komunikasi asynchronous.

### Domain

- Event Bus
- Event Store
- Outbox

**Status:** ✅

### Update 2026-07-07 — 2 dokumen Event governance baru

- SSOT-EVENT-04 — Event Schema Registry & Compatibility Governance
- SSOT-EVENT-05 — Event Replay, Recovery & Dead-Letter Governance

Draft Architecture, belum diimplementasikan (MVP tidak punya event bus/outbox worker nyata sama sekali — audit log ada, tapi bukan domain-event publishing).

---

# Phase 7 — Digital Asset Foundation

## Objective

Standarisasi file.

### Domain

- File Storage
- Object Storage

**Status:** ✅

### Update 2026-07-07 — 2 dokumen File governance baru

- SSOT-FILE-02 — File Security, Malware Scanning & Access Control
- SSOT-FILE-03 — File Retention, Versioning & Evidence Governance

Draft Architecture. `FileService` MVP (dibangun untuk modul Encounter, lihat Phase 15) sudah mengimplementasikan sebagian kecil dari FILE-01 (single-table, local filesystem, ULID filename) tapi TIDAK mengimplementasikan malware scanning, versioning, atau retention/evidence dari FILE-02/03 — reduksi MVP ini sudah didokumentasikan eksplisit di README "Encounter" -> "What this is not".

---

# Phase 8 — Search Foundation

## Objective

Pencarian cepat.

### Domain

- Search
- Indexing

**Status:** ✅

### Update 2026-07-07 — 2 dokumen Search governance baru

- SSOT-SEARCH-02 — Search Authorization & Tenant-Aware Indexing
- SSOT-SEARCH-03 — Search Reindexing, Consistency & Lifecycle Governance

Draft Architecture, belum diimplementasikan (MVP tidak punya fitur search/indexing sama sekali).

---

# Phase 9 — Integration Foundation

## Objective

Integrasi eksternal.

### Domain

- Connector
- Adapter
- Mapping
- Sync
- Webhook

**Status:** ✅

### Update 2026-07-07 — 3 dokumen Integration governance baru

- SSOT-INTEGRATION-02 — Integration Credential & Connection Governance
- SSOT-INTEGRATION-03 — Webhook, Callback & Partner Security
- SSOT-INTEGRATION-04 — Integration Reliability, Retry & Reconciliation

Draft Architecture, belum diimplementasikan (MVP tidak punya integrasi eksternal sama sekali — tidak ada SATUSEHAT/BPJS/payment gateway yang disebut di SSOT-DEPENDENCY-MATRIX.md "Dampak Perubahan").

---

# Phase 10 — Observability

## Objective

Monitoring operasional.

### Delivered SSOT (2026-07-05)

Cakupan aktual jauh lebih luas dari rencana awal (4 dokumen) — 11 dokumen selesai:

- OBS-01 Observability Architecture
- OBS-02 Structured Logging Standard
- OBS-03 Metrics & KPI Framework
- OBS-04 Distributed Tracing
- OBS-05 Health Check Framework
- OBS-06 Monitoring Dashboard Framework
- OBS-07 Alerting & Incident Management Framework
- OBS-08 Log Retention & Archiving Framework
- OBS-09 Performance Monitoring Framework
- OBS-10 Audit vs Logging vs Event Guideline
- OBS-11 Observability Governance & Maturity Framework

**Status:** ✅ (melebihi rencana awal — OBS-05–11 tidak ada di rencana semula)

---

# Phase 11 — Security Platform

## Delivered SSOT (2026-07-05)

Judul dan struktur aktual berbeda dari rencana awal (Secrets/Encryption/OWASP/Data Protection/Key Rotation sebagai dokumen terpisah). Yang dibuat justru 2 dokumen konsolidasi + 1 runbook:

- SSOT-SEC-01 Security Implementation Framework (mencakup identity/access, data protection & cryptography, security infra & ops)
- SSOT-SEC-02 Secure SDLC & Application Security Framework
- DEPLOY-SEC-01 Deployment & UAT Manual (rollout SEC-01+SEC-02, model aktivasi bertahap OFF→SHADOW→MONITOR→WARN→ENFORCE)

**Status:** ✅ (struktur dokumen menyimpang dari rencana awal — lihat catatan di atas)

### Update 2026-07-07 — SSOT-SEC-03 ditambahkan

- SSOT-SEC-03 — Secrets, Key & Certificate Management

Draft Architecture. Sebagian kecil dari cakupan SEC-03 (encryption key rotation) SUDAH diimplementasikan di MVP (`Encryptor` service, AES-256-GCM, multi-version key rotation — lihat README "Key rotation") jauh sebelum dokumen SEC-03 ini ditambahkan ke paket SSOT; implementasi tersebut awalnya dibangun mengacu ke SSOT-SEC-01 §39-49 saja. Belum diverifikasi apakah SEC-03 menambah requirement baru di luar apa yang sudah dibangun (mis. certificate management, KMS/HSM integration, secret vault) — perlu peninjauan terpisah, bukan diasumsikan otomatis konsisten.

---

# Phase 12 — DevOps & Deployment

## Delivered SSOT (2026-07-05)

- SSOT-DEPLOY-01 Deployment Architecture
- SSOT-DEPLOY-02 Environment & Configuration Management
- SSOT-DEPLOY-03 Release, Promotion & Rollback Strategy
- SSOT-DEPLOY-04 Backup, Restore & Disaster Recovery
- SSOT-DEPLOY-05 Infrastructure & Runtime Hardening (tambahan di luar rencana awal)

**Status:** ✅

---

# Phase 13 — Quality Engineering

## Delivered SSOT (2026-07-07)

- SSOT-TEST-01 — Testing Strategy & Quality Governance (test pyramid, unit/integration/contract/E2E, security/performance/migration/tenant-isolation testing, quality gates, evidence)

**Status:** ✅ (direvisi dari 🚧 — `16-Testing/` sebelumnya kosong, sekarang berisi 1 dokumen komprehensif; ditambahkan di luar kendali sesi kerja ini, lihat catatan besar di bawah dokumen). SSOT-TEST-01 sekarang menjadi dependency yang dicantumkan di HAMPIR SEMUA dokumen baru lain (RBAC-09/10/11, DATA-06..09, WF-05..07, dst.) — lihat SSOT-DEPENDENCY-MATRIX.md "Testing Governance Addition". Belum ada implementasi test suite formal (PHPUnit/Pest) di `nerslink-mvp` — seluruh testing MVP sejauh ini adalah script Python ad-hoc terhadap sandbox `php -S` + MariaDB, bukan test suite yang tersimpan di repo.

---

# Phase 14 — Platform SDK

## Objective

Menyediakan SDK standar.

### Delivered SSOT (2026-07-05)

Struktur aktual berbeda dari rencana awal (bukan 5 SDK per-domain, melainkan satu lapisan kontrak modul lintas-domain):

- SSOT-SDK-01 Platform SDK Architecture (merealisasikan ADR-0002)
- SSOT-SDK-02 Module SDK Contracts
- SSOT-SDK-03 SDK Versioning & Compatibility
- SSOT-SDK-04 Module Registration & Bootstrap
- SSOT-SDK-05 Extension, Plugin & Capability Model

**Status:** ✅ (struktur menyimpang dari rencana "Repository/Workflow/Event/Notification/API SDK" — lihat catatan di atas)

---

# Phase 14B — Enterprise UI Architecture

> Ditambahkan 2026-07-07, tidak ada di rencana Phase 0-16 awal manapun. Tidak diberi nomor bulat baru untuk menghindari menggeser nomor Phase 15/16 yang sudah dikenal (lihat catatan besar di bawah dokumen).

## Delivered SSOT

- SSOT-UI-01 — Enterprise UI Architecture & Design System (design tokens, theme engine, layout/responsive, accessibility, components, navigation integration, frontend security)

**Status:** ✅ (dokumen saja). Bergantung pada SSOT-RBAC-05, SSOT-MENU-02..04, SSOT-TEST-01, SSOT-MODULE-01 (lihat Phase 14C di bawah). Target stack: "HTML5, CSS3, Vanilla JavaScript-first" — konsisten dengan `master.css` dan view PHP server-rendered yang sudah dipakai `nerslink-mvp`, tapi MVP belum mengimplementasikan design token system, theme engine, atau component library formal apa pun; layout MVP saat ini ad-hoc per halaman.

---

# Phase 14C — Business Module Architecture

> Ditambahkan 2026-07-07. Secara dependensi seharusnya berada SEBELUM Phase 15 Business Modules (module bisnis butuh contract lifecycle-nya dulu), ditempatkan di sini karena historis ditemukan setelah SDK.

## Delivered SSOT

- SSOT-MODULE-01 — Business Module Architecture & Lifecycle (bounded context, manifest, registration, activation, upgrade, uninstall, contribution model, certification)

**Status:** ✅ (dokumen saja).

**Temuan yang perlu diklarifikasi arsitek, bukan ditebak**: field "Bergantung pada" SSOT-MODULE-01 mencantumkan kode yang tidak pernah ada di paket SSOT manapun: `SSOT-01, SSOT-02, SSOT-03A, SSOT-03B, SSOT-03C, SSOT-04`. Ini kemungkinan besar typo/placeholder yang tidak pernah diisi kode asli saat dokumen ditulis. Dicatat juga di SSOT-INDEX.md §23 gap #4. Setiap modul bisnis `nerslink-mvp` yang sudah dibangun (Business Entity s.d. Encounter) secara de facto SUDAH mengikuti pola lifecycle 10-langkah yang mirip dengan yang dijelaskan SSOT-MODULE-01 §4 (migration -> permission -> menu -> route -> workflow -> event -> notification -> UAT -> go-live) meski dokumen ini belum ada saat modul-modul itu dibangun — MVP secara kebetulan konvergen ke pola yang sama, bukan mengikuti dokumen ini secara eksplisit.

---

# Phase 15 — Business Modules

Kernel selesai terlebih dahulu, kemudian modul bisnis dibangun.

Prioritas:

1. Master Data
2. Patient
3. Appointment
4. Encounter
5. EMR
6. Homecare
7. Woundcare
8. Billing
9. Pharmacy
10. Laboratory
11. Radiology
12. CRM
13. ERP
14. Inventory
15. HR
16. Finance
17. Retail
18. Manufacturing

---

# Phase 16 — Master & Reference Data (MDM)

> Ditambahkan 2026-07-05. Tidak ada di rencana Phase 0-15 awal. Secara dependensi, domain ini seharusnya berada sebelum Business Modules (module bisnis butuh code set/reference data), tetapi nomor fase mengikuti urutan histori penambahan, bukan urutan dependensi murni — lihat Dependency Flow di bawah untuk urutan yang benar.

## Objective

Tata kelola master data dan reference data (golden record, code set, taxonomy, lookup, data quality/stewardship) untuk seluruh Platform Kernel dan module bisnis.

### Delivered SSOT

- SSOT-MDM-01 Master & Reference Data Framework
- SSOT-MDM-02 Code Set, Taxonomy & Lookup Governance
- SSOT-MDM-03 Data Ownership, Quality & Stewardship

**Status:** ✅

---

# Catatan Besar — Perluasan Paket SSOT 2026-07-07 (84 → 132 file, 26 folder)

Selama sesi kerja re-check kecil ini (semula hanya untuk mengindeks 6 file yang terlewat: `17-Implementation/*` dan `SSOT-DATA-05`), paket `ssot/` di luar kendali dokumen ini mengalami perluasan besar: dari 84 file/20 folder menjadi 132 file/26 folder. `SSOT-INDEX.md` disinkronkan ulang menjadi Versi 2.0 dan `SSOT-DEPENDENCY-MATRIX.md` mendapat ~30 blok "Addition" baru oleh sebuah proses konsolidasi otomatis (didorong oleh `SSOT-GOV-07`, menghasilkan `SSOT-INTEGRITY-REPORT.md`). Dokumen ROADMAP ini TIDAK disentuh oleh proses tersebut, sehingga sempat tertinggal sampai disinkronkan manual pada 2026-07-07 (update-update di atas).

Ringkasan dokumen baru yang ditambahkan (~45 dokumen, seluruhnya berstatus "Draft Architecture", belum diimplementasikan di `nerslink-mvp` kecuali disebutkan lain di update masing-masing fase di atas):

- Governance: GOV-07 (repository integrity)
- IAM: IAM-06/07/08 (SSO/federation, lifecycle, risk & recovery)
- RBAC/Menu: RBAC-04..11 (8 dokumen), MENU-02..04 (3 dokumen)
- Data/Analytics/Records/Privacy: DATA-06..09 (4), ANALYTICS-01, RECORDS-01, PRIVACY-01
- Workflow: WF-05..07
- Notification: NOTIFY-04/05
- API: API-06..09
- Event: EVENT-04/05
- File: FILE-02/03
- Search: SEARCH-02/03
- Integration: INTEGRATION-02..04
- Security: SEC-03
- UI: UI-01 (baru, domain yang sebelumnya tidak ada sama sekali)
- Module Architecture: MODULE-01 (baru, domain yang sebelumnya tidak ada sama sekali)
- Testing: TEST-01 (baru, mengisi gap yang sebelumnya kosong — lihat Phase 13)
- Scope: SSOT-SCOPE-01 (ditemukan sendiri oleh integrity report sebagai gap index yang tidak diperbaiki, sudah Claude perbaiki di SSOT-INDEX.md)

**Dua temuan penting yang butuh keputusan arsitek**:

1. **RESOLVED 2026-07-07 (ADR-0001)** — Konflik SSOT-SCOPE-01 vs SSOT-SCOPE-01A: SCOPE-01 (baru, generik, 6 level: Tenant→Organization→Facility/Clinic→Department→Team→Resource, skema `scope_registry` polymorphic sendiri) TIDAK SAMA dengan SCOPE-01A (docx lama, "Enterprise Scope Hierarchy", 10 level: Tenant→Organization→Business Entity→Branch→Division→Department→Service→Team→Workgroup→Assignment) yang menjadi basis skema `nerslink-mvp` (migrasi 001-045, seluruh 10 level sudah dibangun dan diuji). **Keputusan pemilik platform**: SCOPE-01A/02/03/04 tetap otoritatif untuk hierarchy/schema (status quo); SCOPE-01 superseded untuk hierarchy/schema tapi konsep governance-nya (tenant mutation, reconciliation, versioning, delegation) disimpan sebagai backlog kernel masa depan, dibangun sebagai lapisan tambahan bukan pengganti. Detail lengkap + considered options: `nerslink-mvp/ADR-0001-scope-hierarchy-authority.md`. Anotasi status ditambahkan ke `SSOT-SCOPE-01.md` sendiri dan `SSOT-INDEX.md` §01.
2. **Belum diselesaikan** — SSOT-MODULE-01 mencantumkan dependency ke kode yang tidak ada (`SSOT-01, SSOT-02, SSOT-03A/B/C, SSOT-04`) — lihat Phase 14C.

Sesi kerja ini TIDAK melakukan pembacaan arsitektur mendalam untuk setiap satu dari ~45 dokumen baru (banyak yang hanya diverifikasi header + ringkasan dependency dari blok "Addition" `SSOT-DEPENDENCY-MATRIX.md`, bukan dibaca penuh). Confidence: [Medium] untuk detail isi tiap dokumen individual di luar 2 temuan besar di atas (yang dibaca penuh); [High] untuk fakta bahwa perluasan ini terjadi dan skala/cakupannya, karena itu didasarkan pada perbandingan file langsung (`find`, `stat`, `Read`) bukan ringkasan pihak ketiga.

---

# Dependency Flow

Governance (+ Implementation & Coding Standards, cross-cutting)
→ Scope (✅ SCOPE-01A tetap otoritatif, konflik dengan SCOPE-01 resolved via ADR-0001 — lihat catatan besar di atas)
→ IAM
→ RBAC & Dynamic Menu
→ Audit
→ Data (+ Analytics, Records, Privacy)
→ Workflow
→ Notification
→ API
→ Event
→ File
→ Search
→ Integration
→ Observability
→ Security
→ Deployment
→ Platform SDK
→ Enterprise UI Architecture
→ Business Module Architecture
→ Master & Reference Data (MDM)
→ Testing
→ Business Modules

Catatan (2026-07-05): urutan Platform SDK sebelum MDM dikonfirmasi dari dependency yang dideklarasikan tiap dokumen — SSOT-MDM-01 secara eksplisit mencantumkan `SSOT-SDK-01` sebagai salah satu dependency-nya.

Catatan (2026-07-07): UI Architecture dan Module Architecture disisipkan antara SDK dan MDM karena UI-01 bergantung pada MODULE-01 dan MENU-02..04, dan MODULE-01 bergantung pada seluruh SDK-01..05 -- keduanya logis berada setelah SDK selesai. Testing sekarang berstatus selesai (✅, bukan lagi 🚧) tapi tetap ditempatkan mendekati akhir karena isinya mereferensikan hampir seluruh domain di atasnya.

---

# Milestone

| Milestone | Target |
|---|---|
| Kernel Foundation Complete | Setelah seluruh SSOT Kernel selesai (dokumen ✅ per 2026-07-07; implementasi MVP masih parsial, lihat Exit Criteria) |
| SDK Ready | Setelah Observability, Security, Deployment |
| UI Architecture Ready | Setelah SDK dan Menu governance stabil |
| Module Architecture Ready | Setelah SDK stabil |
| MDM Ready | Setelah Platform SDK stabil |
| First Healthcare Module | Setelah SDK dan MDM stabil |
| First Non-Healthcare Module | Setelah Healthcare Core stabil |
| Multi-product Platform | Setelah modul inti reusable |

---

# Exit Criteria

Kernel dianggap selesai apabila:

- Scope selesai
- IAM selesai
- RBAC selesai
- Audit selesai
- Data selesai
- Workflow selesai
- Notification selesai
- API selesai
- Event selesai
- File selesai
- Search selesai
- Integration selesai
- Observability selesai
- Security selesai
- Deployment selesai
- Platform SDK selesai
- Enterprise UI Architecture selesai
- Business Module Architecture selesai
- Master & Reference Data (MDM) selesai
- Testing selesai

Baru setelah itu pengembangan modul bisnis dilakukan secara paralel.

**Status per 2026-07-07:** seluruh item di atas ✅ sebagai DOKUMEN (termasuk Testing, direvisi dari 🚧). "Selesai" di sini berarti dokumen SSOT tersedia, BUKAN berarti seluruh isinya sudah diimplementasikan di `nerslink-mvp` — MVP saat ini mengimplementasikan sebagian kecil dari total cakupan governance yang sekarang ada (lihat catatan "Draft Architecture, belum diimplementasikan" di tiap update fase di atas). Lihat juga "Catatan Besar — Perluasan Paket SSOT 2026-07-07" untuk 2 temuan yang butuh keputusan arsitek sebelum modul bisnis baru dilanjutkan dengan percaya diri penuh.

---

# Governance Rule

Perubahan roadmap harus:

- direview arsitek
- memperbarui SSOT terkait
- memperbarui SSOT-CHANGELOG
- dikomunikasikan kepada tim pengembang
