# SSOT-EVENT-05 — Event Replay, Recovery & Dead-Letter Governance

## Status Dokumen

| Item | Nilai |
|---|---|
| Kode | SSOT-EVENT-05 |
| Judul | Event Replay, Recovery & Dead-Letter Governance |
| Versi | 1.0 |
| Status | Draft Architecture |
| Domain | Platform Kernel |
| Kategori | Event Recovery, Replay, Dead-Letter & Operational Governance |
| Cakupan | Replay Scope, Dead-Letter Lifecycle, Poison Events, Recovery Checkpoints, Ordering, Idempotency, Reprocessing, Reconciliation |
| Bergantung pada | SSOT-GOV-01, SSOT-GOV-04, SSOT-GOV-05, SSOT-AUDIT-01, SSOT-EVENT-01, SSOT-EVENT-02, SSOT-EVENT-03, SSOT-EVENT-04, SSOT-INTEGRATION-04, SSOT-OBS-01, SSOT-TEST-01 |
| Target Stack | PHP 8.1+, Queue/Event Broker-compatible, PDO, MySQL 8/MariaDB |
| Target Evolusi | Automated Replay Orchestration, Event Time Travel, Cross-Region Recovery, Continuous Event Assurance |

# 1. Executive Summary

SSOT-EVENT-05 menetapkan governance resmi untuk event replay, dead-letter, poison-event handling, checkpoint recovery, controlled reprocessing, event-order recovery, dan reconciliation.

Dokumen ini memastikan bahwa event yang gagal:

- tidak hilang;
- tidak diproses berulang tanpa kontrol;
- dapat diisolasi;
- dapat direplay secara aman;
- tetap menjaga idempotency;
- tetap menjaga ordering;
- tetap menjaga tenant boundary;
- dapat dipulihkan dari checkpoint;
- dapat direkonsiliasi;
- dapat diaudit.

# 2. Objectives

Framework harus:

- menyediakan canonical dead-letter lifecycle;
- membedakan transient dan permanent failure;
- menyediakan replay governance;
- menjaga idempotency;
- menjaga ordering;
- mendukung checkpoint recovery;
- mendukung selective replay;
- mendukung disaster recovery;
- menyediakan reconciliation;
- menghasilkan evidence operasional.

# 3. Core Principles

```text
No Event Is Silently Lost
Replay Must Be Controlled
Dead-Letter Requires Ownership
Poison Events Must Be Isolated
Idempotency Is Mandatory
Ordering Must Be Preserved Where Required
Checkpoints Must Be Durable
Replay Scope Must Be Explicit
Recovery Must Be Verifiable
Every Replay Is Auditable
```

# 4. Scope

Berlaku untuk:

```text
Domain Events
Integration Events
Workflow Events
Security Events
Notification Events
Audit Events
Consumer Failures
Broker Dead-Letter Queues
Replay Jobs
Recovery Jobs
Cross-Region Event Recovery
```

# 5. Failure Categories

```text
TRANSIENT
PERMANENT
SCHEMA_INVALID
AUTHENTICATION
AUTHORIZATION
DEPENDENCY_UNAVAILABLE
TIMEOUT
POISON_EVENT
ORDERING_VIOLATION
DUPLICATE
UNKNOWN
```

# 6. Event Processing States

```text
RECEIVED
VALIDATED
PROCESSING
SUCCEEDED
FAILED_RETRYABLE
FAILED_FINAL
DEAD_LETTERED
REPLAY_PENDING
REPLAYING
RECONCILING
RESOLVED
DISCARDED
```

# 7. Dead-Letter Purpose

Dead-letter bukan tempat pembuangan.

Dead-letter adalah managed operational state untuk event yang:

- gagal setelah retry;
- tidak valid;
- tidak dapat diproses karena dependency;
- menyebabkan poison loop;
- membutuhkan manual review;
- memiliki unknown outcome.

# 8. Dead-Letter Reasons

```text
MAX_ATTEMPTS_EXCEEDED
SCHEMA_INVALID
UNKNOWN_SCHEMA_VERSION
CONSUMER_ERROR
DEPENDENCY_RETIRED
AUTHORIZATION_FAILED
ORDERING_VIOLATION
POISON_EVENT
MANUAL_QUARANTINE
UNKNOWN_FAILURE
```

# 9. Dead-Letter Record

Minimum:

```text
dead_letter_id
event_id
event_name
schema_version
tenant_id
consumer_code
partition
offset
failure_reason
attempt_count
first_failed_at
last_failed_at
owner
status
payload_reference
payload_hash
```

# 10. Dead-Letter Lifecycle

```text
OPEN
TRIAGED
ROOT_CAUSE_IDENTIFIED
REPLAY_APPROVED
REPLAYING
RESOLVED
DISCARDED
ESCALATED
```

# 11. Ownership

Dead-letter owner resolved from:

- consumer owner;
- event owner;
- module owner;
- integration owner;
- platform operations;
- security owner for security events.

# 12. Poison Event

Poison event adalah event yang secara konsisten membuat consumer gagal.

# 13. Poison Event Handling

- isolate event;
- stop repeated hot-loop retry;
- preserve evidence;
- prevent partition blockage where possible;
- open incident if systemic;
- require root-cause classification.

# 14. Retry vs Replay

Retry:

- automatic;
- short-lived;
- same processing intent;
- bounded attempts;
- transient failure focus.

Replay:

- explicit;
- controlled;
- may occur long after original event;
- may target new consumer version;
- requires governance.

# 15. Replay Types

```text
SINGLE_EVENT
EVENT_RANGE
PARTITION_RANGE
TENANT_RANGE
TIME_RANGE
CONSUMER_RANGE
SCHEMA_VERSION_RANGE
DEAD_LETTER_REPLAY
FULL_STREAM_REPLAY
```

# 16. Replay Scope

Replay scope harus menyebutkan:

```text
event names
tenant(s)
consumer(s)
partition(s)
offset range
time window
schema versions
purpose
expected effects
```

# 17. Selective Replay

Default choice adalah selective replay dengan scope paling kecil.

# 18. Full Stream Replay

High-risk dan membutuhkan:

- architecture approval;
- capacity review;
- business-effect review;
- idempotency verification;
- rollback/recovery plan;
- monitoring;
- dry run where possible.

# 19. Replay Preconditions

- root cause resolved;
- target consumer version known;
- event schema supported;
- idempotency verified;
- tenant scope verified;
- ordering impact reviewed;
- external side effects reviewed;
- approval complete.

# 20. Replay Identity

Every replay run must have:

```text
replay_run_id
source
scope
requested_by
approved_by
started_at
completed_at
status
```

# 21. Replay Attempt Identity

Setiap replayed event memperoleh replay attempt ID baru, tetapi mempertahankan original event ID.

# 22. Original Event Integrity

Original event payload tidak boleh dimodifikasi diam-diam.

# 23. Event Transformation

Jika transform diperlukan:

- use registered transformer;
- record source schema;
- record target schema;
- retain original payload;
- generate transformation evidence;
- validate output.

# 24. Idempotency

Replay consumer harus idempotent.

# 25. Idempotency Keys

Recommended:

```text
consumer_code
event_id
processing_version
effect_scope
```

# 26. Duplicate Outcomes

```text
FIRST_PROCESSING
ALREADY_COMPLETED
IN_PROGRESS
CONFLICT
REPLAY_SAFE
```

# 27. Effectively-Once Outcome

Target:

```text
at-least-once event delivery
+
consumer idempotency
+
effect reconciliation
=
effectively-once business effect
```

# 28. Ordering

Ordering may be required by:

- aggregate ID;
- subject ID;
- tenant;
- account;
- workflow instance;
- resource.

# 29. Partition Key

Events requiring order harus menggunakan stable partition key.

# 30. Out-of-Order Detection

Consumer harus membandingkan:

- sequence number;
- source version;
- occurred_at;
- prior event reference;
- aggregate version.

# 31. Ordering Violations

Possible outcomes:

```text
BUFFER
DEFER
REJECT
DEAD_LETTER
RECONCILE
```

# 32. Replay Ordering

Replay harus menjaga order dalam scope yang memerlukannya.

# 33. Parallel Replay

Parallelism hanya boleh melintasi partitions atau keys yang tidak saling bergantung.

# 34. Checkpoint

Checkpoint menyimpan posisi processing yang durable.

# 35. Checkpoint Fields

```text
consumer_code
stream
partition
offset
source_version
updated_at
checksum
```

# 36. Checkpoint Commit

Commit hanya setelah:

- durable processing;
- durable handoff;
- idempotency record committed;
- side effects in known state.

# 37. Checkpoint Recovery

Flow:

```text
Load Checkpoint
→ Validate Consumer Version
→ Validate Partition Assignment
→ Resume from Next Safe Position
→ Reconcile Gaps
→ Monitor
```

# 38. Checkpoint Corruption

Must trigger:

- stop processing;
- preserve current state;
- compare broker offsets;
- use last verified checkpoint;
- perform bounded replay;
- open incident.

# 39. Offset Reset

Offset reset requires explicit approval and evidence.

# 40. Consumer Group Recovery

Must define:

- partition reassignment;
- rebalance behavior;
- in-flight processing;
- duplicate tolerance;
- checkpoint ownership.

# 41. Snapshot-Assisted Recovery

Consumers may restore materialized state from snapshot then replay delta.

# 42. Snapshot Requirements

- versioned;
- checksummed;
- schema-compatible;
- tenant-aware;
- timestamped;
- source offsets recorded.

# 43. Snapshot Recovery Flow

```text
Restore Snapshot
→ Verify Checksum
→ Restore Checkpoint
→ Replay Delta
→ Reconcile State
→ Activate
```

# 44. Event Store Retention

Replay depends on sufficient retention.

# 45. Retention Inputs

- recovery point objective;
- consumer outage duration;
- legal/audit need;
- reprocessing need;
- storage cost;
- privacy requirements.

# 46. Replay Window

Every event family must define supported replay window.

# 47. Expired Source Events

If source event is no longer retained:

- restore from archive;
- use evidence package;
- rebuild from source of truth;
- or mark unrecoverable with approval.

# 48. Archived Events

Archived event data must preserve:

- payload;
- envelope;
- schema version;
- checksum;
- partition;
- offset;
- tenant;
- timestamps.

# 49. Replay from Archive

Requires integrity verification and schema availability.

# 50. Schema Compatibility

Replay consumer must support original schema or approved transformation.

# 51. Consumer Versioning

Replay must record consumer processing version.

# 52. Changed Business Rules

Replaying old events against new rules can change outcomes.

Policy must define:

```text
ORIGINAL_RULES
CURRENT_RULES
MIGRATION_RULES
MANUAL_DECISION
```

# 53. Side-Effect Classification

```text
PURE_PROJECTION
INTERNAL_STATE_CHANGE
EXTERNAL_API_CALL
FINANCIAL_EFFECT
NOTIFICATION
SECURITY_EFFECT
IRREVERSIBLE_EFFECT
```

# 54. Pure Projection Replay

Generally low risk if idempotent.

# 55. External Side-Effect Replay

Requires stricter controls.

# 56. Notification Replay

Must not resend user messages unless explicitly intended.

# 57. Financial Replay

Requires transaction-level reconciliation and approval.

# 58. Security Event Replay

Must avoid re-triggering destructive security actions without policy.

# 59. Dry Run

Dry run should report:

- event count;
- affected tenants;
- affected consumers;
- expected effects;
- unsupported schemas;
- ordering risks;
- estimated duration;
- capacity impact.

# 60. Replay Approval

Approval tier based on:

- event volume;
- tenant count;
- side-effect class;
- sensitivity;
- financial impact;
- production impact.

# 61. Replay Throttling

Replay must not starve live traffic.

# 62. Capacity Isolation

Use:

- separate queue;
- separate consumer group;
- concurrency limits;
- rate limits;
- tenant quotas.

# 63. Live vs Replay Priority

Live traffic generally has priority unless emergency recovery policy says otherwise.

# 64. Replay Cancellation

Replay jobs must be cancellable and checkpointed.

# 65. Replay Resume

Resume from last verified replay checkpoint.

# 66. Dead-Letter Replay

Before replay:

- revalidate schema;
- revalidate tenant;
- revalidate authorization;
- check event relevance;
- check expiry;
- check current consumer compatibility.

# 67. Discard

Discard requires:

- reason;
- owner;
- approval according to severity;
- business-impact assessment;
- evidence retention.

# 68. Irrecoverable Event

Event may be marked irrecoverable only after:

- source exhausted;
- archive checked;
- snapshot checked;
- producer/source state checked;
- business impact documented;
- approval complete.

# 69. Recovery Modes

```text
RETRY
DEAD_LETTER_REPLAY
OFFSET_REWIND
SNAPSHOT_RESTORE
SOURCE_REBUILD
CROSS_REGION_RESTORE
MANUAL_COMPENSATION
```

# 70. Cross-Region Recovery

Must preserve:

- tenant residency;
- event order;
- offsets;
- schema registry access;
- encryption;
- dead-letter state;
- replay evidence.

# 71. Disaster Recovery

DR plan must define:

- event broker recovery;
- registry recovery;
- checkpoint recovery;
- dead-letter recovery;
- replay source;
- RTO;
- RPO;
- validation.

# 72. Recovery Point Objective

RPO determines acceptable event loss window.

# 73. Recovery Time Objective

RTO determines maximum restoration duration.

# 74. Post-Recovery Validation

Validate:

- event counts;
- offsets;
- dead-letter counts;
- consumer lag;
- state projections;
- tenant boundaries;
- critical business outcomes.

# 75. Event Reconciliation

Compare:

- producer event log;
- broker records;
- consumer inbox;
- checkpoints;
- dead-letter;
- materialized state;
- external effects;
- replay history.

# 76. Reconciliation Findings

```text
EVENT_MISSING_IN_BROKER
EVENT_NOT_CONSUMED
CHECKPOINT_AHEAD_OF_EFFECT
CHECKPOINT_BEHIND
DUPLICATE_EFFECT
DEAD_LETTER_WITHOUT_OWNER
REPLAYED_EVENT_WITHOUT_EVIDENCE
ORDERING_GAP
SCHEMA_UNSUPPORTED
SNAPSHOT_OFFSET_MISMATCH
```

# 77. Auto-Remediation

Examples:

- replay missed projection event;
- reset stale transient failure;
- assign dead-letter owner;
- rebuild missing materialized view;
- repair checkpoint behind known completed effect.

# 78. Manual Remediation

Required for:

- financial effect;
- irreversible side effect;
- ambiguous ordering;
- cross-tenant risk;
- missing source evidence;
- security-sensitive replay.

# 79. Audit Events

```text
EVENT_PROCESSING_FAILED
EVENT_DEAD_LETTERED
EVENT_DEAD_LETTER_TRIAGED
EVENT_REPLAY_REQUESTED
EVENT_REPLAY_APPROVED
EVENT_REPLAY_STARTED
EVENT_REPLAY_COMPLETED
EVENT_REPLAY_FAILED
EVENT_REPLAY_CANCELLED
EVENT_CHECKPOINT_RESET
EVENT_RECOVERY_STARTED
EVENT_RECOVERY_COMPLETED
EVENT_RECONCILIATION_FAILED
```

# 80. Metrics

```text
event_processing_failure_total
event_dead_letter_total
event_dead_letter_age_seconds
event_replay_run_total
event_replay_event_total
event_replay_failure_total
event_checkpoint_lag
event_ordering_violation_total
event_recovery_duration_seconds
event_reconciliation_failure_total
```

# 81. KPIs

```text
Silent event loss = 0
Dead-letter without owner = 0
Replay without approval = 0
Duplicate critical business effects = 0
Checkpoint committed before durable processing = 0
Unsupported schema replay = 0
Cross-tenant replay leakage = 0
```

# 82. KRIs

```text
Dead-letter growth
Oldest dead-letter age
Replay failure rate
Checkpoint lag
Ordering violation frequency
Poison-event recurrence
Full-stream replay frequency
Recovery duration growth
```

# 83. Database Direction

Potential tables:

```text
event_dead_letters
event_dead_letter_history
event_replay_runs
event_replay_scopes
event_replay_attempts
event_consumer_checkpoints
event_recovery_runs
event_recovery_snapshots
event_reconciliation_runs
event_reconciliation_findings
```

# 84. Table: event_dead_letters

```sql
CREATE TABLE event_dead_letters (
    id CHAR(26) NOT NULL,
    event_id CHAR(26) NOT NULL,
    event_name VARCHAR(255) NOT NULL,
    schema_version VARCHAR(100) NOT NULL,
    tenant_id CHAR(26) NULL,
    consumer_code VARCHAR(180) NOT NULL,
    partition_key VARCHAR(255) NULL,
    broker_offset VARCHAR(255) NULL,
    failure_reason VARCHAR(180) NOT NULL,
    attempt_count INT NOT NULL,
    payload_reference VARCHAR(1000) NOT NULL,
    payload_hash CHAR(64) NOT NULL,
    owner_reference VARCHAR(180) NULL,
    status VARCHAR(30) NOT NULL,
    first_failed_at DATETIME(6) NOT NULL,
    last_failed_at DATETIME(6) NOT NULL,

    PRIMARY KEY (id),
    UNIQUE KEY uq_event_dead_letter (
        event_id,
        consumer_code
    ),
    KEY idx_event_dead_letter_status (
        status,
        last_failed_at
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

# 85. Table: event_replay_runs

```sql
CREATE TABLE event_replay_runs (
    id CHAR(26) NOT NULL,
    replay_code VARCHAR(100) NOT NULL,
    replay_type VARCHAR(40) NOT NULL,
    purpose_code VARCHAR(180) NOT NULL,
    requested_by VARCHAR(180) NOT NULL,
    approved_by VARCHAR(180) NULL,
    consumer_version VARCHAR(100) NULL,
    status VARCHAR(30) NOT NULL,
    started_at DATETIME(6) NULL,
    completed_at DATETIME(6) NULL,

    PRIMARY KEY (id),
    UNIQUE KEY uq_event_replay_code (
        replay_code
    ),
    KEY idx_event_replay_status (
        status,
        started_at
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

# 86. Table: event_replay_scopes

```sql
CREATE TABLE event_replay_scopes (
    id CHAR(26) NOT NULL,
    replay_run_id CHAR(26) NOT NULL,
    event_name VARCHAR(255) NULL,
    tenant_id CHAR(26) NULL,
    consumer_code VARCHAR(180) NULL,
    partition_key VARCHAR(255) NULL,
    offset_from VARCHAR(255) NULL,
    offset_to VARCHAR(255) NULL,
    time_from DATETIME(6) NULL,
    time_to DATETIME(6) NULL,

    PRIMARY KEY (id),
    KEY idx_event_replay_scope_run (
        replay_run_id
    ),
    CONSTRAINT fk_event_replay_scope_run
        FOREIGN KEY (replay_run_id)
        REFERENCES event_replay_runs (id)
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

# 87. Table: event_consumer_checkpoints

```sql
CREATE TABLE event_consumer_checkpoints (
    id CHAR(26) NOT NULL,
    consumer_code VARCHAR(180) NOT NULL,
    stream_code VARCHAR(180) NOT NULL,
    partition_key VARCHAR(255) NOT NULL,
    broker_offset VARCHAR(255) NOT NULL,
    source_version VARCHAR(100) NULL,
    checksum_sha256 CHAR(64) NOT NULL,
    updated_at DATETIME(6) NOT NULL,

    PRIMARY KEY (id),
    UNIQUE KEY uq_event_consumer_checkpoint (
        consumer_code,
        stream_code,
        partition_key
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

# 88. Table: event_reconciliation_findings

```sql
CREATE TABLE event_reconciliation_findings (
    id CHAR(26) NOT NULL,
    run_id CHAR(26) NOT NULL,
    finding_type VARCHAR(60) NOT NULL,
    severity VARCHAR(30) NOT NULL,
    event_id CHAR(26) NULL,
    consumer_code VARCHAR(180) NULL,
    tenant_id CHAR(26) NULL,
    expected_state_json JSON NULL,
    actual_state_json JSON NULL,
    status VARCHAR(30) NOT NULL,
    detected_at DATETIME(6) NOT NULL,

    PRIMARY KEY (id),
    KEY idx_event_reconciliation_finding (
        severity,
        status,
        detected_at
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

# 89. API Direction

```text
GET  /api/internal/v1/events/dead-letters
GET  /api/internal/v1/events/dead-letters/{id}
POST /api/internal/v1/events/dead-letters/{id}/triage
POST /api/internal/v1/events/dead-letters/{id}/replay
POST /api/internal/v1/events/dead-letters/{id}/discard
POST /api/internal/v1/events/replay-runs
GET  /api/internal/v1/events/replay-runs/{replayCode}
POST /api/internal/v1/events/replay-runs/{replayCode}/approve
POST /api/internal/v1/events/replay-runs/{replayCode}/cancel
POST /api/internal/v1/events/recovery-runs
POST /api/internal/v1/events/reconciliation/runs
```

# 90. SDK Contracts

```text
EventDeadLetterServiceInterface
EventReplayServiceInterface
EventReplayPolicyInterface
EventCheckpointStoreInterface
EventRecoveryServiceInterface
EventReconciliationServiceInterface
EventTransformationServiceInterface
```

# 91. Replay Contract

```php
interface EventReplayServiceInterface
{
    public function plan(
        EventReplayPlanRequest $request
    ): EventReplayPlan;

    public function execute(
        EventReplayExecutionRequest $request
    ): EventReplayResult;
}
```

# 92. Checkpoint Contract

```php
interface EventCheckpointStoreInterface
{
    public function load(
        EventConsumerPartition $partition
    ): ?EventCheckpoint;

    public function commit(
        EventCheckpointCommit $commit
    ): void;
}
```

# 93. Dead-Letter Contract

```php
interface EventDeadLetterServiceInterface
{
    public function quarantine(
        EventFailure $failure
    ): EventDeadLetterRecord;

    public function replay(
        EventDeadLetterReplayRequest $request
    ): EventReplayResult;
}
```

# 94. Error Codes

```text
EVENT_DEAD_LETTER_NOT_FOUND
EVENT_REPLAY_SCOPE_INVALID
EVENT_REPLAY_NOT_APPROVED
EVENT_REPLAY_SCHEMA_UNSUPPORTED
EVENT_REPLAY_IDEMPOTENCY_REQUIRED
EVENT_REPLAY_ORDERING_RISK
EVENT_REPLAY_SIDE_EFFECT_BLOCKED
EVENT_CHECKPOINT_INVALID
EVENT_CHECKPOINT_RESET_DENIED
EVENT_RECOVERY_FAILED
EVENT_RECONCILIATION_FAILED
```

# 95. Dead-Letter Checklist

- [ ] Event identity preserved.
- [ ] Failure classified.
- [ ] Payload hash stored.
- [ ] Tenant context stored.
- [ ] Consumer identified.
- [ ] Attempt count stored.
- [ ] Owner assigned.
- [ ] Status created.
- [ ] Evidence retained.
- [ ] Alert generated when required.

# 96. Replay Approval Checklist

- [ ] Scope explicit.
- [ ] Root cause resolved.
- [ ] Schema supported.
- [ ] Consumer version defined.
- [ ] Idempotency verified.
- [ ] Ordering reviewed.
- [ ] Side effects classified.
- [ ] Tenant boundaries reviewed.
- [ ] Capacity reviewed.
- [ ] Monitoring enabled.
- [ ] Approval complete.

# 97. UAT — Dead-Letter Lifecycle

- [ ] Exhausted retry creates dead-letter.
- [ ] Poison event isolated.
- [ ] Owner assigned.
- [ ] Triage records root cause.
- [ ] Replay approval required.
- [ ] Discard requires reason.
- [ ] Escalation works.
- [ ] Resolution preserves evidence.
- [ ] Audit complete.

# 98. UAT — Selective Replay

- [ ] Single-event replay works.
- [ ] Tenant-scoped replay isolates correctly.
- [ ] Time-range replay selects correct events.
- [ ] Consumer-scoped replay works.
- [ ] Unsupported schema blocks replay.
- [ ] Expired event follows policy.
- [ ] Cancellation preserves checkpoint.
- [ ] Resume continues safely.
- [ ] Metrics update.

# 99. UAT — Idempotency & Side Effects

- [ ] Replayed event does not duplicate projection.
- [ ] Duplicate financial effect blocked.
- [ ] Notification not resent unless intended.
- [ ] External API call requires policy.
- [ ] Same event/consumer returns completed result.
- [ ] Conflicting replay request rejected.
- [ ] Processing version recorded.
- [ ] Effect reconciliation confirms outcome.

# 100. UAT — Ordering

- [ ] Aggregate sequence preserved.
- [ ] Out-of-order event detected.
- [ ] Buffer policy works.
- [ ] Stale aggregate version rejected.
- [ ] Parallel replay separates independent partitions.
- [ ] Dependent events remain ordered.
- [ ] Ordering gap creates finding.
- [ ] Recovery restores correct sequence.

# 101. UAT — Checkpoint Recovery

- [ ] Durable checkpoint loads.
- [ ] Resume starts at next safe offset.
- [ ] Duplicate after crash handled idempotently.
- [ ] Corrupt checkpoint detected.
- [ ] Offset reset requires approval.
- [ ] Rebalance preserves ownership.
- [ ] Snapshot checkpoint aligns.
- [ ] Gap reconciliation works.
- [ ] Audit complete.

# 102. UAT — Snapshot & DR Recovery

- [ ] Snapshot checksum validates.
- [ ] Snapshot schema compatible.
- [ ] Delta replay catches up.
- [ ] Tombstoned/deleted events respected.
- [ ] Dead-letter state restored.
- [ ] Registry available.
- [ ] Cross-region tenant residency preserved.
- [ ] RTO measured.
- [ ] RPO measured.
- [ ] Post-recovery validation passes.

# 103. UAT — Reconciliation

- [ ] Missing broker event detected.
- [ ] Unconsumed event detected.
- [ ] Checkpoint ahead of effect detected.
- [ ] Checkpoint behind detected.
- [ ] Duplicate effect detected.
- [ ] Dead-letter without owner detected.
- [ ] Replay without evidence detected.
- [ ] Ordering gap detected.
- [ ] Snapshot offset mismatch detected.
- [ ] Critical finding opens incident.

# 104. Definition of Done — SSOT-EVENT-05

SSOT-EVENT-05 dianggap selesai bila:

- [ ] failure taxonomy tersedia;
- [ ] processing states tersedia;
- [ ] dead-letter lifecycle tersedia;
- [ ] poison-event controls tersedia;
- [ ] retry vs replay guidance tersedia;
- [ ] replay types and scope tersedia;
- [ ] approval gates tersedia;
- [ ] idempotency requirements tersedia;
- [ ] ordering controls tersedia;
- [ ] checkpoint model tersedia;
- [ ] snapshot-assisted recovery tersedia;
- [ ] archive replay tersedia;
- [ ] side-effect classification tersedia;
- [ ] dry-run/throttling/cancellation tersedia;
- [ ] DR and cross-region recovery tersedia;
- [ ] reconciliation tersedia;
- [ ] audit and metrics tersedia;
- [ ] database direction tersedia;
- [ ] API direction tersedia;
- [ ] SDK contracts tersedia;
- [ ] UAT and DoD tersedia.

# 105. Implementation Roadmap

## Phase 1 — Dead-Letter Foundation

- dead-letter registry;
- failure taxonomy;
- owner routing;
- triage workflow;
- evidence;
- dashboards.

## Phase 2 — Controlled Replay

- replay plans;
- replay scope;
- approvals;
- idempotency checks;
- schema checks;
- selective replay.

## Phase 3 — Ordering & Checkpoints

- durable checkpoints;
- offset management;
- sequence validation;
- replay checkpoints;
- partition-aware parallelism;
- cancellation/resume.

## Phase 4 — Recovery & Reconciliation

- snapshots;
- archive replay;
- DR recovery;
- event reconciliation;
- side-effect verification;
- incident workflow.

## Phase 5 — Continuous Event Assurance

- automated replay recommendations;
- replay simulation;
- cross-region recovery automation;
- continuous gap detection;
- poison-event analytics;
- event recovery dashboard.

# 106. Initial Implementation Backlog

```text
EVENT05-001 Failure Taxonomy
EVENT05-002 Dead-Letter Registry
EVENT05-003 Dead-Letter Triage
EVENT05-004 Replay Planning Service
EVENT05-005 Replay Approval Workflow
EVENT05-006 Replay Scope Resolver
EVENT05-007 Replay Execution Engine
EVENT05-008 Idempotency Guard
EVENT05-009 Ordering Validator
EVENT05-010 Checkpoint Store
EVENT05-011 Snapshot Recovery
EVENT05-012 Archive Replay
EVENT05-013 Side-Effect Policy
EVENT05-014 Reconciliation Engine
EVENT05-015 Recovery Orchestrator
EVENT05-016 Event Recovery Dashboard
```

# 107. Approval Gate

Dokumen dapat menjadi Approved setelah:

- Event Architecture review;
- Operations/SRE review;
- Data Architecture review;
- Security review;
- Integration Architecture review;
- Disaster Recovery review;
- Audit/Compliance review;
- Quality Engineering review;
- UAT review.

# 108. Closing Statement

Event failure tidak boleh berarti event hilang.

Dead-letter harus memiliki owner.

Replay harus memiliki scope, approval, idempotency, ordering, dan evidence.

Checkpoint tidak boleh maju sebelum processing durable.

Recovery harus dapat diverifikasi melalui reconciliation.
