
# SSOT-EVENT-01 — Event Bus & Domain Events

## Status Dokumen

| Item | Nilai |
|---|---|
| Kode | SSOT-EVENT-01 |
| Nama | Event Bus & Domain Events |
| Versi | 1.0 |
| Status | Draft Architecture |
| Domain | Platform Kernel / Event |
| Berlaku Untuk | Multi-tenant, multi-organization, multi-business entity, healthcare, non-healthcare |
| Dependensi | SSOT-SCOPE, SSOT-RBAC, SSOT-AUDIT, SSOT-DATA, SSOT-WF, SSOT-NOTIFY, SSOT-API |

---

# 1. Tujuan

Event Bus & Domain Events adalah fondasi komunikasi antar modul tanpa ketergantungan langsung.

Tujuan utama:

- mengurangi coupling antar modul;
- mendukung workflow event-driven;
- mendukung notification otomatis;
- mendukung audit dan integration;
- mendukung async processing;
- mendukung future migration ke microservices;
- menjaga setiap perubahan penting dapat dipublikasikan sebagai event.

Contoh:

```text
patient.created
encounter.closed
homecare.visit.completed
woundcare.assessment.submitted
billing.invoice.paid
approval.request.approved
```

---

# 2. Prinsip Dasar

## 2.1 Event menggambarkan sesuatu yang sudah terjadi

Gunakan past tense.

Benar:

```text
patient.created
invoice.paid
workflow.transition.executed
```

Salah:

```text
create.patient
pay.invoice
execute.workflow
```

## 2.2 Event bukan command

Command meminta sesuatu dilakukan.

Event memberitahu sesuatu telah terjadi.

```text
Command: CreatePatient
Event: patient.created
```

## 2.3 Event harus immutable

Event yang sudah diterbitkan tidak boleh diubah.

Jika koreksi diperlukan, terbitkan event baru.

## 2.4 Event harus scope-aware

Setiap event wajib membawa scope snapshot.

## 2.5 Event harus audit-aware

Event penting harus terhubung dengan audit trail dan correlation ID.

---

# 3. Komponen

```text
event_definitions
event_versions
event_bus
event_publishers
event_subscribers
event_handlers
event_messages
event_deliveries
event_failures
event_dead_letters
event_subscriptions
```

---

# 4. Jenis Event

```text
domain_event
integration_event
system_event
security_event
workflow_event
notification_event
audit_event
```

## Domain Event

Event dari modul bisnis.

Contoh:

```text
patient.created
homecare.visit.completed
```

## Integration Event

Event untuk sistem eksternal.

Contoh:

```text
satusehat.encounter.ready_to_send
payment.callback.received
```

## System Event

Event platform.

Contoh:

```text
backup.completed
job.failed
```

## Security Event

Event keamanan.

Contoh:

```text
auth.login.failed
api.key.revoked
```

## Workflow Event

Event dari workflow.

Contoh:

```text
workflow.instance.started
approval.request.approved
```

## Notification Event

Event yang memicu notifikasi.

Contoh:

```text
notification.delivery.failed
```

---

# 5. Event Naming Convention

Format:

```text
domain.resource.action_past_tense
```

Contoh:

```text
patient.record.created
encounter.visit.closed
homecare.visit.assigned
woundcare.assessment.submitted
billing.invoice.paid
approval.request.rejected
```

Aturan:

- lowercase;
- dot-separated;
- jelas dan stabil;
- hindari singkatan tidak umum;
- jangan masukkan ID ke nama event.

---

# 6. Event Envelope

Semua event memakai envelope standar.

```json
{
  "event_id": "uuid",
  "event_code": "patient.record.created",
  "event_version": "1.0",
  "occurred_at": "2026-07-03T10:00:00Z",
  "published_at": "2026-07-03T10:00:01Z",
  "correlation_id": "cor_xxx",
  "causation_id": "evt_previous",
  "tenant_id": 1,
  "scope_snapshot": {},
  "actor": {},
  "resource": {},
  "payload": {},
  "metadata": {}
}
```

---

# 7. Event Payload

Payload berisi data minimum yang dibutuhkan subscriber.

Jangan mengirim seluruh resource jika tidak perlu.

Contoh:

```json
{
  "patient_id": 103,
  "medical_record_number": "RM-000103",
  "created_by": 12
}
```

Untuk data sensitif, gunakan reference ID dan biarkan subscriber mengambil data via repository dengan permission/scope yang tepat.

---

# 8. Scope Snapshot

Setiap event wajib membawa:

```text
tenant_id
organization_id
business_entity_id
branch_id
department_id
service_id
team_id
scope_level
```

Ini penting untuk:

- filtering subscriber;
- audit;
- notification;
- integration;
- tenant isolation.

---

# 9. Actor Snapshot

Event membawa actor:

```json
{
  "actor_type": "human_user",
  "actor_user_id": 12,
  "display_name": "Siti Aminah"
}
```

Untuk service account:

```json
{
  "actor_type": "service_account",
  "service_account_id": 5,
  "code": "report_scheduler"
}
```

---

# 10. Resource Reference

Resource standar:

```json
{
  "resource_type": "patient",
  "resource_id": 103,
  "resource_display": "RM-000103"
}
```

---

# 11. Correlation & Causation

## Correlation ID

Mengelompokkan event dalam satu proses.

## Causation ID

Menunjukkan event penyebab.

Contoh:

```text
approval.request.approved
→ billing.refund.approved
→ notification.message.created
```

---

# 12. Database — event_definitions

```sql
CREATE TABLE event_definitions (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,

    code VARCHAR(150) NOT NULL UNIQUE,
    name VARCHAR(150) NOT NULL,
    description TEXT NULL,

    event_type ENUM(
        'domain_event',
        'integration_event',
        'system_event',
        'security_event',
        'workflow_event',
        'notification_event',
        'audit_event'
    ) NOT NULL DEFAULT 'domain_event',

    domain_code VARCHAR(100) NULL,
    industry_type VARCHAR(50) NULL,

    status ENUM('active','inactive','deprecated') NOT NULL DEFAULT 'active',

    created_at TIMESTAMP NULL,
    updated_at TIMESTAMP NULL,
    deleted_at TIMESTAMP NULL
);
```

---

# 13. Database — event_versions

```sql
CREATE TABLE event_versions (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,

    event_definition_id BIGINT UNSIGNED NOT NULL,

    version_number VARCHAR(20) NOT NULL,
    schema_json JSON NULL,

    status ENUM('draft','active','deprecated','retired') NOT NULL DEFAULT 'draft',

    effective_from DATETIME NULL,
    effective_until DATETIME NULL,

    created_by BIGINT UNSIGNED NULL,
    approved_by BIGINT UNSIGNED NULL,
    approved_at DATETIME NULL,

    created_at TIMESTAMP NULL,
    updated_at TIMESTAMP NULL,

    UNIQUE KEY uq_event_version (event_definition_id, version_number),
    INDEX idx_event_version_status (status)
);
```

---

# 14. Database — event_messages

```sql
CREATE TABLE event_messages (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,

    event_uuid CHAR(36) NOT NULL UNIQUE,

    event_code VARCHAR(150) NOT NULL,
    event_version VARCHAR(20) NOT NULL DEFAULT '1.0',

    tenant_id BIGINT UNSIGNED NULL,
    organization_id BIGINT UNSIGNED NULL,
    business_entity_id BIGINT UNSIGNED NULL,

    scope_snapshot JSON NULL,
    actor_snapshot JSON NULL,
    resource_snapshot JSON NULL,

    payload JSON NOT NULL,
    metadata JSON NULL,

    correlation_id VARCHAR(100) NULL,
    causation_id VARCHAR(100) NULL,

    status ENUM('published','processing','processed','failed','dead_letter') NOT NULL DEFAULT 'published',

    occurred_at DATETIME NOT NULL,
    published_at DATETIME NOT NULL,

    created_at TIMESTAMP NULL,

    INDEX idx_event_code (event_code),
    INDEX idx_event_scope (tenant_id, business_entity_id),
    INDEX idx_event_correlation (correlation_id),
    INDEX idx_event_resource ((CAST(resource_snapshot->>'$.resource_type' AS CHAR(100)))),
    INDEX idx_event_published_at (published_at)
);
```

Catatan: ekspresi JSON index perlu disesuaikan dengan database engine.

---

# 15. Database — event_subscriptions

```sql
CREATE TABLE event_subscriptions (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,

    subscriber_code VARCHAR(150) NOT NULL,
    event_code VARCHAR(150) NOT NULL,

    handler_class VARCHAR(255) NOT NULL,

    delivery_mode ENUM('sync','async') NOT NULL DEFAULT 'async',

    tenant_id BIGINT UNSIGNED NULL,
    business_entity_id BIGINT UNSIGNED NULL,

    filter_json JSON NULL,

    status ENUM('active','inactive') NOT NULL DEFAULT 'active',

    created_at TIMESTAMP NULL,
    updated_at TIMESTAMP NULL,

    INDEX idx_event_subscription_event (event_code),
    INDEX idx_event_subscription_status (status)
);
```

---

# 16. Database — event_deliveries

```sql
CREATE TABLE event_deliveries (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,

    event_message_id BIGINT UNSIGNED NOT NULL,
    event_subscription_id BIGINT UNSIGNED NOT NULL,

    handler_class VARCHAR(255) NOT NULL,

    status ENUM('queued','running','completed','failed','retrying','dead_letter') NOT NULL DEFAULT 'queued',

    attempts INT NOT NULL DEFAULT 0,
    max_attempts INT NOT NULL DEFAULT 3,

    next_retry_at DATETIME NULL,
    started_at DATETIME NULL,
    completed_at DATETIME NULL,
    failed_at DATETIME NULL,

    failure_reason TEXT NULL,

    created_at TIMESTAMP NULL,
    updated_at TIMESTAMP NULL,

    INDEX idx_event_delivery_status (status, next_retry_at),
    INDEX idx_event_delivery_message (event_message_id),
    INDEX idx_event_delivery_subscription (event_subscription_id)
);
```

---

# 17. Database — event_dead_letters

```sql
CREATE TABLE event_dead_letters (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,

    event_message_id BIGINT UNSIGNED NOT NULL,
    event_delivery_id BIGINT UNSIGNED NULL,

    reason TEXT NOT NULL,
    payload_snapshot JSON NULL,

    resolved TINYINT(1) NOT NULL DEFAULT 0,
    resolved_by BIGINT UNSIGNED NULL,
    resolved_at DATETIME NULL,
    resolution_note TEXT NULL,

    created_at TIMESTAMP NULL,

    INDEX idx_dead_letter_event (event_message_id),
    INDEX idx_dead_letter_resolved (resolved)
);
```

---

# 18. Event Bus Interface

```php
interface EventBusInterface
{
    public function publish(DomainEvent $event): void;

    public function subscribe(string $eventCode, string $handlerClass): void;

    public function dispatch(EventMessage $message): void;
}
```

---

# 19. Domain Event Interface

```php
interface DomainEventInterface
{
    public function eventCode(): string;

    public function eventVersion(): string;

    public function occurredAt(): DateTimeImmutable;

    public function payload(): array;

    public function metadata(): array;
}
```

---

# 20. Event Handler Interface

```php
interface EventHandlerInterface
{
    public function handle(EventMessage $event): void;
}
```

---

# 21. Publish Flow

```text
Business action succeeds
→ Domain event created
→ Event envelope built
→ Event message stored
→ Subscriptions resolved
→ Deliveries created
→ Sync handlers run immediately
→ Async handlers queued
→ Audit event published if required
```

---

# 22. Subscribe Flow

```text
Module registers handler
→ Event subscription stored
→ Event bus routes matching event
→ Handler receives event message
```

---

# 23. Sync vs Async Handler

## Sync Handler

Digunakan jika hasil handler harus terjadi dalam transaksi utama.

Contoh:

```text
write audit event
update local read model
```

## Async Handler

Digunakan untuk:

```text
notification
integration
reporting
search indexing
webhook
```

---

# 24. Retry Policy

Event delivery gagal harus dapat retry.

Strategi:

```text
fixed delay
exponential backoff
max attempts
dead letter
```

Default:

```text
max_attempts = 3
```

---

# 25. Idempotency

Handler wajib idempotent.

Gunakan:

```text
event_uuid
handler_class
```

untuk mencegah pemrosesan ganda.

---

# 26. Ordering

Event ordering tidak selalu terjamin jika async.

Jika ordering penting, gunakan:

```text
aggregate_id
sequence_number
single queue per aggregate
```

Detail Event Store dibuat di SSOT-EVENT-02.

---

# 27. Event Schema Versioning

Event payload harus versioned.

Perubahan non-breaking:

- tambah field opsional;
- tambah metadata.

Breaking change:

- ganti tipe field;
- hapus field;
- ubah makna field.

Breaking change harus naik versi event.

---

# 28. Event Filtering

Subscriber dapat filter berdasarkan:

```text
tenant_id
business_entity_id
event_code
resource_type
payload attribute
metadata
```

---

# 29. Security

Event tidak boleh membawa secret.

Hindari:

```text
password
api_key
token
otp
full clinical note
full identity document
```

Gunakan reference ID dan repository lookup.

---

# 30. Healthcare Privacy Rule

Untuk healthcare event:

- PHI/PII minim;
- event membawa ID dan metadata cukup;
- subscriber mengambil detail dengan scope/RBAC;
- audit read access tetap berlaku.

Contoh aman:

```json
{
  "patient_id": 103,
  "encounter_id": 22
}
```

---

# 31. Audit Integration

Event penting menghasilkan audit.

Audit event dapat dibuat oleh handler khusus:

```text
AuditEventHandler
```

Event yang wajib audit:

```text
auth.*
rbac.*
scope.*
patient.*
emr.*
billing.*
workflow.*
approval.*
api.*
integration.*
```

---

# 32. Notification Integration

Notification Framework subscribe ke event.

Contoh:

```text
approval.request.submitted
→ notification.message.created
```

---

# 33. Workflow Integration

Workflow Engine publish event:

```text
workflow.instance.started
workflow.transition.executed
workflow.task.created
workflow.task.completed
```

---

# 34. Scheduler Integration

Scheduler dapat publish event:

```text
job.completed
job.failed
approval.expired
task.overdue
```

---

# 35. API Integration

API request dapat menghasilkan event setelah business action berhasil.

Contoh:

```text
POST /patients
→ patient.record.created
```

---

# 36. Webhook Integration

Webhook delivery adalah subscriber dari integration event.

Contoh:

```text
invoice.paid
→ webhook.delivery.queued
```

---

# 37. Search Integration

Search indexer subscribe ke event:

```text
patient.record.updated
→ search.index.update
```

---

# 38. Read Model Integration

Projection/read model update melalui event.

Contoh:

```text
billing.invoice.paid
→ daily_revenue_summary.updated
```

---

# 39. Event Bus Implementation Options

Fase awal:

```text
database-backed event bus
```

Fase lanjut:

```text
Redis queue
RabbitMQ
Kafka
cloud pub/sub
```

Arsitektur harus memungkinkan upgrade tanpa mengubah domain service.

---

# 40. Transaction Boundary

Event hanya boleh dipublish setelah transaksi bisnis berhasil.

Risiko jika publish sebelum commit:

```text
subscriber menerima event untuk data yang rollback
```

Solusi reliable dibuat di SSOT-EVENT-03 Outbox Pattern.

---

# 41. Database-backed Event Bus

Cocok untuk fase awal modular monolith.

Kelebihan:

- sederhana;
- mudah debug;
- tidak butuh broker eksternal.

Kekurangan:

- throughput terbatas;
- ordering/retry perlu desain baik.

---

# 42. Broker-backed Event Bus

Cocok untuk skala besar/microservice.

Pilihan:

```text
RabbitMQ
Kafka
NATS
Redis Streams
Cloud Pub/Sub
```

---

# 43. Event Monitoring

Pantau:

```text
published event count
failed deliveries
dead letter count
handler latency
queue backlog
retry count
event processing lag
```

---

# 44. Event Governance

Setiap event harus punya:

- owner;
- schema;
- version;
- description;
- payload contract;
- sensitivity classification;
- retention policy.

---

# 45. Seed Event Definitions

Contoh seed awal:

```text
workflow.instance.started
workflow.transition.executed
approval.request.submitted
approval.request.approved
notification.message.created
audit.event.created
auth.login.success
auth.login.failed
rbac.user_role.assigned
scope.switched
api.request.completed
```

Healthcare seed:

```text
patient.record.created
encounter.visit.created
emr.note.signed
homecare.visit.assigned
woundcare.assessment.submitted
billing.invoice.created
```

---

# 46. UAT Scenario

## Scenario 1 — Publish Domain Event

```text
Given patient berhasil dibuat
When service commit transaksi
Then event patient.record.created dipublish
And event_messages berisi event
```

## Scenario 2 — Async Handler

```text
Given approval.request.submitted dipublish
When notification subscriber aktif
Then notification delivery dibuat
```

## Scenario 3 — Handler Failed

```text
Given handler gagal
When attempts < max_attempts
Then delivery status retrying
And next_retry_at terisi
```

## Scenario 4 — Dead Letter

```text
Given handler gagal melebihi max attempts
Then delivery masuk dead_letter
And audit tercatat
```

## Scenario 5 — Idempotency

```text
Given event yang sama diproses dua kali
When handler idempotent
Then efek samping hanya terjadi sekali
```

---

# 47. Anti-pattern

Hindari:

```text
event berisi password/token
event dipublish sebelum transaksi commit
handler tidak idempotent
event tanpa version
event tanpa schema
event digunakan sebagai command
subscriber memanggil controller
payload terlalu besar
PHI penuh dikirim ke semua subscriber
```

---

# 48. Definition of Done

Event Bus & Domain Events dianggap siap bila:

- event naming standard tersedia;
- event envelope tersedia;
- event definitions tersedia;
- event versions tersedia;
- event messages tersedia;
- event subscriptions tersedia;
- event deliveries tersedia;
- retry tersedia;
- dead letter tersedia;
- idempotency didukung;
- scope snapshot tersedia;
- actor/resource snapshot tersedia;
- audit integration tersedia;
- notification integration tersedia;
- workflow integration tersedia;
- future-ready untuk broker eksternal.
