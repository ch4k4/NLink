
# SSOT-EVENT-02 — Event Store & Replay

## Status Dokumen

| Item | Nilai |
|---|---|
| Kode | SSOT-EVENT-02 |
| Nama | Event Store & Replay |
| Versi | 1.0 |
| Status | Draft Architecture |
| Domain | Platform Kernel / Event |
| Bergantung pada | SSOT-EVENT-01, SSOT-AUDIT, SSOT-DATA, SSOT-SCOPE, SSOT-RBAC |

---

# 1. Tujuan

Event Store adalah penyimpanan historis untuk event yang telah terjadi.

Replay adalah mekanisme memutar ulang event untuk:

- membangun ulang read model;
- membangun ulang projection;
- memperbaiki handler yang gagal;
- reindex search;
- audit teknis;
- migrasi ke sistem baru;
- rekonsiliasi data.

Event Store bukan pengganti database transaksi utama pada fase awal, tetapi menjadi fondasi future-ready untuk event sourcing dan microservices.

---

# 2. Prinsip Dasar

- Event immutable.
- Event memiliki urutan.
- Event memiliki versi schema.
- Event replay harus aman dan terkontrol.
- Replay tidak boleh menyebabkan efek samping eksternal tanpa izin.
- Replay harus audit-aware.
- Event yang berisi data sensitif harus minimal dan terlindungi.

---

# 3. Event Store vs Audit Trail

| Aspek | Event Store | Audit Trail |
|---|---|---|
| Fokus | Perubahan domain dan integrasi | Jejak siapa melakukan apa |
| Konsumen | Sistem/subscriber/projection | Auditor/security/compliance |
| Replay | Ya | Umumnya tidak |
| Payload | Kontrak event | Bukti aktivitas |
| Immutability | Wajib | Wajib |

Event Store dan Audit Trail dapat saling terhubung lewat `correlation_id`.

---

# 4. Event Store Use Case

```text
rebuild notification projection
rebuild search index
rebuild reporting summary
retry integration after bug fix
replay failed webhook
migrate event stream to broker
generate historical read model
```

---

# 5. Komponen

```text
event_store
event_streams
event_snapshots
event_replay_jobs
event_replay_items
event_projection_offsets
event_projection_checkpoints
event_schema_registry
```

---

# 6. Event Stream

Event stream adalah kumpulan event berdasarkan aggregate/resource.

Contoh stream:

```text
patient:103
encounter:22
invoice:9001
workflow_instance:77
```

Stream menjaga ordering event untuk satu aggregate.

---

# 7. Aggregate ID

Setiap event yang terkait resource bisnis sebaiknya memiliki:

```text
aggregate_type
aggregate_id
sequence_number
```

Contoh:

```text
aggregate_type = patient
aggregate_id = 103
sequence_number = 5
```

---

# 8. Sequence Number

Sequence number memastikan urutan event dalam aggregate.

Rule:

- sequence naik satu per aggregate;
- tidak boleh duplikat;
- digunakan untuk optimistic concurrency.

---

# 9. Database — event_store

```sql
CREATE TABLE event_store (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,

    event_uuid CHAR(36) NOT NULL UNIQUE,

    event_code VARCHAR(150) NOT NULL,
    event_version VARCHAR(20) NOT NULL DEFAULT '1.0',

    aggregate_type VARCHAR(100) NULL,
    aggregate_id BIGINT UNSIGNED NULL,
    sequence_number BIGINT UNSIGNED NULL,

    tenant_id BIGINT UNSIGNED NULL,
    organization_id BIGINT UNSIGNED NULL,
    business_entity_id BIGINT UNSIGNED NULL,

    scope_snapshot JSON NULL,
    actor_snapshot JSON NULL,
    resource_snapshot JSON NULL,

    payload JSON NOT NULL,
    metadata JSON NULL,

    correlation_id VARCHAR(100) NULL,
    causation_id VARCHAR(100) NULL,

    occurred_at DATETIME NOT NULL,
    stored_at DATETIME NOT NULL,

    event_hash CHAR(64) NULL,
    previous_event_hash CHAR(64) NULL,

    created_at TIMESTAMP NULL,

    UNIQUE KEY uq_event_stream_sequence (aggregate_type, aggregate_id, sequence_number),
    INDEX idx_event_store_code (event_code),
    INDEX idx_event_store_aggregate (aggregate_type, aggregate_id),
    INDEX idx_event_store_scope (tenant_id, business_entity_id),
    INDEX idx_event_store_correlation (correlation_id),
    INDEX idx_event_store_occurred_at (occurred_at)
);
```

---

# 10. Database — event_streams

```sql
CREATE TABLE event_streams (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,

    aggregate_type VARCHAR(100) NOT NULL,
    aggregate_id BIGINT UNSIGNED NOT NULL,

    tenant_id BIGINT UNSIGNED NULL,
    business_entity_id BIGINT UNSIGNED NULL,

    current_sequence BIGINT UNSIGNED NOT NULL DEFAULT 0,

    status ENUM('active','archived') NOT NULL DEFAULT 'active',

    created_at TIMESTAMP NULL,
    updated_at TIMESTAMP NULL,

    UNIQUE KEY uq_event_stream (aggregate_type, aggregate_id),
    INDEX idx_event_stream_scope (tenant_id, business_entity_id)
);
```

---

# 11. Database — event_snapshots

```sql
CREATE TABLE event_snapshots (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,

    aggregate_type VARCHAR(100) NOT NULL,
    aggregate_id BIGINT UNSIGNED NOT NULL,

    sequence_number BIGINT UNSIGNED NOT NULL,

    snapshot_payload JSON NOT NULL,
    snapshot_version VARCHAR(20) NOT NULL DEFAULT '1.0',

    created_by VARCHAR(100) NULL,
    created_at TIMESTAMP NULL,

    UNIQUE KEY uq_event_snapshot_sequence (aggregate_type, aggregate_id, sequence_number),
    INDEX idx_event_snapshot_aggregate (aggregate_type, aggregate_id)
);
```

Snapshot digunakan untuk mempercepat rebuild aggregate dari event panjang.

---

# 12. Database — event_replay_jobs

```sql
CREATE TABLE event_replay_jobs (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,

    replay_code VARCHAR(150) NOT NULL,
    replay_reason TEXT NOT NULL,

    event_code_filter VARCHAR(150) NULL,
    aggregate_type_filter VARCHAR(100) NULL,

    tenant_id BIGINT UNSIGNED NULL,
    business_entity_id BIGINT UNSIGNED NULL,

    from_occurred_at DATETIME NULL,
    to_occurred_at DATETIME NULL,

    target_handler VARCHAR(255) NOT NULL,

    dry_run TINYINT(1) NOT NULL DEFAULT 1,

    status ENUM('draft','approved','running','completed','failed','cancelled') NOT NULL DEFAULT 'draft',

    requested_by BIGINT UNSIGNED NOT NULL,
    approved_by BIGINT UNSIGNED NULL,
    approved_at DATETIME NULL,

    started_at DATETIME NULL,
    completed_at DATETIME NULL,

    created_at TIMESTAMP NULL,
    updated_at TIMESTAMP NULL,

    INDEX idx_replay_status (status),
    INDEX idx_replay_scope (tenant_id, business_entity_id)
);
```

---

# 13. Database — event_replay_items

```sql
CREATE TABLE event_replay_items (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,

    replay_job_id BIGINT UNSIGNED NOT NULL,
    event_store_id BIGINT UNSIGNED NOT NULL,

    status ENUM('pending','processed','failed','skipped') NOT NULL DEFAULT 'pending',

    failure_reason TEXT NULL,
    processed_at DATETIME NULL,

    created_at TIMESTAMP NULL,
    updated_at TIMESTAMP NULL,

    INDEX idx_replay_item_job_status (replay_job_id, status),
    INDEX idx_replay_item_event (event_store_id)
);
```

---

# 14. Database — event_projection_offsets

```sql
CREATE TABLE event_projection_offsets (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,

    projection_code VARCHAR(150) NOT NULL UNIQUE,

    last_event_store_id BIGINT UNSIGNED NULL,
    last_processed_at DATETIME NULL,

    status ENUM('active','paused','failed') NOT NULL DEFAULT 'active',

    created_at TIMESTAMP NULL,
    updated_at TIMESTAMP NULL
);
```

---

# 15. Database — event_projection_checkpoints

```sql
CREATE TABLE event_projection_checkpoints (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,

    projection_code VARCHAR(150) NOT NULL,
    checkpoint_name VARCHAR(150) NOT NULL,

    event_store_id BIGINT UNSIGNED NOT NULL,
    checkpoint_payload JSON NULL,

    created_at TIMESTAMP NULL,

    INDEX idx_projection_checkpoint (projection_code, event_store_id)
);
```

---

# 16. Database — event_schema_registry

```sql
CREATE TABLE event_schema_registry (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,

    event_code VARCHAR(150) NOT NULL,
    event_version VARCHAR(20) NOT NULL,

    schema_json JSON NOT NULL,

    status ENUM('draft','active','deprecated','retired') NOT NULL DEFAULT 'draft',

    created_by BIGINT UNSIGNED NULL,
    approved_by BIGINT UNSIGNED NULL,
    approved_at DATETIME NULL,

    created_at TIMESTAMP NULL,
    updated_at TIMESTAMP NULL,

    UNIQUE KEY uq_event_schema (event_code, event_version),
    INDEX idx_event_schema_status (status)
);
```

---

# 17. Event Store Write Flow

```text
Domain action succeeds
→ Domain event created
→ Validate event schema
→ Resolve stream
→ Assign sequence number
→ Build hash
→ Store event
→ Publish to event bus
→ Audit if required
```

---

# 18. Append-only Rule

Event Store hanya boleh insert.

Tidak boleh:

```sql
UPDATE event_store
DELETE FROM event_store
```

Koreksi dilakukan dengan event baru.

---

# 19. Hash Chain

Untuk deteksi perubahan ilegal:

```text
event_hash = hash(event payload + metadata + previous_event_hash)
```

Hash chain dapat per aggregate stream atau global.

Rekomendasi awal:

```text
per aggregate stream
```

---

# 20. Replay Mode

Jenis replay:

```text
dry_run
safe_replay
side_effect_replay
```

## Dry Run

Tidak mengubah data, hanya simulasi.

## Safe Replay

Mengubah projection/read model internal.

## Side Effect Replay

Boleh memicu efek eksternal, misalnya webhook ulang. Harus approval khusus.

---

# 21. Replay Safety Rule

Replay default tidak boleh:

- mengirim email/WhatsApp ulang;
- memanggil payment gateway ulang;
- membuat invoice baru;
- mengubah transaksi finansial tanpa approval;
- mengirim data eksternal ulang.

Efek eksternal harus explicit opt-in.

---

# 22. Replay Approval

Replay data sensitif atau side effect wajib approval.

Approval menyimpan:

```text
reason
scope
filter
target handler
dry_run flag
requested_by
approved_by
```

---

# 23. Projection

Projection adalah read model yang dibangun dari event.

Contoh:

```text
patient_search_index
daily_revenue_summary
workflow_task_dashboard
notification_inbox
```

---

# 24. Projection Rebuild Flow

```text
Pause projection
→ Clear or mark rebuild target
→ Replay event from offset
→ Update projection
→ Store checkpoint
→ Resume projection
```

---

# 25. Event Replay Flow

```text
Create replay job
→ Approve if required
→ Select events
→ Create replay items
→ Process item one by one
→ Track success/failure
→ Complete job
→ Audit replay
```

---

# 26. Idempotency

Replay handler wajib idempotent.

Gunakan:

```text
event_uuid
handler_name
projection_code
```

untuk mencegah duplicate side effect.

---

# 27. Ordering During Replay

Replay harus menjaga ordering:

- berdasarkan aggregate sequence jika aggregate-specific;
- berdasarkan occurred_at/stored_at jika global;
- berdasarkan event_store.id jika deterministic ordering diperlukan.

---

# 28. Schema Evolution

Replay event lama harus memperhatikan schema version.

Handler harus mampu:

- membaca versi lama;
- menggunakan upcaster;
- atau menolak dengan alasan jelas.

---

# 29. Event Upcaster

Upcaster mengubah payload lama menjadi bentuk baru saat replay.

Contoh:

```text
patient.created v1 → patient.created v2
```

Upcaster tidak mengubah event asli.

---

# 30. Retention

Event Store retention bergantung pada:

- event type;
- regulasi;
- kebutuhan replay;
- audit/compliance;
- legal hold.

Event penting biasanya disimpan jangka panjang.

---

# 31. Archive

Event lama dapat diarsipkan ke cold storage.

Syarat:

- masih dapat direplay jika dibutuhkan;
- hash/integrity tetap terjaga;
- metadata pencarian tetap tersedia.

---

# 32. Legal Hold

Event yang terkait investigasi tidak boleh dipurge.

Legal hold dapat berdasarkan:

```text
correlation_id
resource
event_code
tenant
date range
```

---

# 33. Healthcare Privacy

Event Store tidak boleh menjadi repositori PHI penuh.

Untuk event healthcare:

- simpan ID dan metadata minimum;
- detail klinis tetap di EMR repository;
- replay yang mengakses PHI harus audit read access.

---

# 34. Security

Akses Event Store dibatasi.

Permission:

```text
event.store.read
event.store.replay.request
event.store.replay.approve
event.store.replay.run
event.store.verify_integrity
```

---

# 35. Audit Events

Event audit:

```text
event.store.appended
event.replay.requested
event.replay.approved
event.replay.started
event.replay.item.processed
event.replay.item.failed
event.replay.completed
event.replay.cancelled
event.integrity.verified
event.integrity.failed
```

---

# 36. Monitoring

Pantau:

```text
event_store_growth
replay_job_status
projection_lag
projection_failed_count
dead_letter_count
handler_latency
event_schema_errors
```

---

# 37. Backup & DR

Event Store wajib masuk strategi backup.

Restore Event Store harus menjaga:

- ordering;
- sequence;
- hash chain;
- projection offset.

---

# 38. Event Store Implementation Phases

## Phase 1 — Modular Monolith

```text
database event store
database queue
manual replay
```

## Phase 2 — Scaled Platform

```text
Redis/RabbitMQ
projection workers
automated replay
```

## Phase 3 — Distributed

```text
Kafka/PubSub
stream partitioning
cross-service replay
```

---

# 39. UAT Scenario

## Scenario 1 — Append Event

```text
Given patient created
When event stored
Then event_store contains patient.record.created
And sequence_number assigned
```

## Scenario 2 — Replay Dry Run

```text
Given replay job dry_run
When executed
Then no projection is changed
And replay result recorded
```

## Scenario 3 — Projection Rebuild

```text
Given search index kosong
When replay patient events
Then search projection rebuilt
```

## Scenario 4 — Replay Side Effect Blocked

```text
Given replay would send WhatsApp
When side_effect_replay not approved
Then handler skipped/blocked
```

## Scenario 5 — Hash Verification

```text
Given event hash chain
When integrity check runs
Then tampering detected if payload changed
```

---

# 40. Anti-pattern

Hindari:

```text
event store bisa update/delete
replay mengirim notifikasi eksternal tanpa approval
event payload berisi secret
event replay tanpa idempotency
projection tidak punya checkpoint
event tanpa schema version
PHI lengkap disimpan di event store
```

---

# 41. Definition of Done

Event Store & Replay dianggap siap bila:

- event store append-only tersedia;
- aggregate stream tersedia;
- sequence number tersedia;
- schema registry tersedia;
- replay job tersedia;
- replay item tracking tersedia;
- dry-run tersedia;
- projection offset tersedia;
- checkpoint tersedia;
- idempotent handler tersedia;
- hash chain tersedia;
- legal hold/retention dipertimbangkan;
- audit replay tersedia;
- healthcare privacy rule diterapkan.
