
# SSOT-EVENT-03 — Outbox Pattern & Reliable Messaging

## Status Dokumen

| Item | Nilai |
|---|---|
| Kode | SSOT-EVENT-03 |
| Nama | Outbox Pattern & Reliable Messaging |
| Versi | 1.0 |
| Status | Draft Architecture |
| Domain | Platform Kernel / Event |
| Bergantung pada | SSOT-EVENT-01, SSOT-EVENT-02, SSOT-WF, SSOT-NOTIFY, SSOT-AUDIT, SSOT-DATA |

# 1. Tujuan

Menjamin bahwa perubahan data bisnis dan publikasi event berlangsung secara andal tanpa kehilangan event walaupun terjadi crash aplikasi, restart worker, atau gangguan jaringan.

# 2. Masalah yang Diselesaikan

Tanpa Outbox:

Business Transaction
→ Commit Database
→ Publish Event

Jika aplikasi gagal setelah commit tetapi sebelum publish, maka event hilang.

Dengan Outbox:

Business Transaction
→ Update Business Data
→ Insert Audit
→ Insert Outbox Message
→ COMMIT
→ Dispatcher
→ Event Bus
→ Subscriber

# 3. Prinsip

- Atomic transaction.
- At-least-once delivery.
- Consumer wajib idempotent.
- Publisher dapat diulang.
- Retry otomatis.
- Dead-letter tersedia.
- Semua proses diaudit.

# 4. Komponen

- outbox_messages
- outbox_dispatch_logs
- inbox_messages
- message_deduplication
- dead_letter_messages
- dispatcher_workers

# 5. Database — outbox_messages

```sql
CREATE TABLE outbox_messages(
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 message_uuid CHAR(36) NOT NULL UNIQUE,
 event_code VARCHAR(150) NOT NULL,
 event_version VARCHAR(20) NOT NULL,
 aggregate_type VARCHAR(100),
 aggregate_id BIGINT UNSIGNED,
 tenant_id BIGINT UNSIGNED,
 payload JSON NOT NULL,
 metadata JSON NULL,
 correlation_id VARCHAR(100),
 causation_id VARCHAR(100),
 status ENUM('pending','publishing','published','failed','dead_letter') DEFAULT 'pending',
 attempts INT DEFAULT 0,
 max_attempts INT DEFAULT 5,
 next_retry_at DATETIME NULL,
 locked_by VARCHAR(100) NULL,
 locked_until DATETIME NULL,
 published_at DATETIME NULL,
 created_at TIMESTAMP NULL,
 updated_at TIMESTAMP NULL,
 INDEX idx_outbox_status(status,next_retry_at),
 INDEX idx_outbox_aggregate(aggregate_type,aggregate_id)
);
```

# 6. Database — outbox_dispatch_logs

Menyimpan histori publish:

- worker
- waktu
- hasil
- latency
- broker response
- error

# 7. Database — inbox_messages

Menyimpan message yang telah diproses consumer.

Kolom minimum:

- message_uuid
- consumer_code
- processed_at
- result

Unique:

(message_uuid, consumer_code)

# 8. Database — message_deduplication

Digunakan untuk mencegah side effect ganda.

Kunci:

- idempotency_key
- handler
- resource

# 9. Database — dead_letter_messages

Menyimpan message yang gagal permanen:

- payload
- reason
- stack summary
- last_attempt
- resolved flag

# 10. Transaction Boundary

Dalam satu transaksi:

- update business table
- update audit
- insert outbox

Tidak boleh publish broker di dalam transaksi.

# 11. Dispatcher Flow

Pending
→ lock
→ publish
→ success = published
atau
→ gagal
→ retry
→ dead-letter

# 12. Locking

Worker mengambil lock menggunakan:

- locked_by
- locked_until

Lease timeout mencegah lock selamanya.

# 13. Multi Worker

Beberapa worker boleh berjalan bersamaan.

Satu message hanya boleh diproses satu worker.

# 14. Delivery Guarantee

- Internal: At-least-once.
- Consumer wajib idempotent.
- Exactly-once tidak diasumsikan.

# 15. Retry

Default:

- max_attempts = 5
- exponential backoff

Contoh:

1m
5m
15m
1h
6h

# 16. Poison Message

Message yang selalu gagal dipindahkan ke dead-letter.

Tidak boleh retry tanpa batas.

# 17. Inbox Pattern

Consumer memeriksa inbox:

Jika message_uuid sudah pernah diproses:

→ abaikan.

# 18. Ordering

Ordering dijaga per aggregate.

Gunakan:

aggregate_type
aggregate_id
sequence_number

# 19. Batch Publish

Dispatcher dapat mengambil batch, misalnya 100 message sekali proses.

# 20. Replay Integration

Replay dapat membuat ulang outbox bila diperlukan.

Default replay tidak mengirim efek eksternal tanpa approval.

# 21. Notification Integration

Notification subscribe melalui event bus, bukan membaca business table langsung.

# 22. Workflow Integration

Workflow transition menghasilkan outbox event.

# 23. API Integration

Request API:
→ commit
→ outbox
→ dispatcher
→ subscriber

# 24. Monitoring

Pantau:

- pending messages
- publish latency
- retry count
- dead-letter
- worker throughput
- oldest pending message

# 25. Alert

Alert jika:

- pending > threshold
- dead-letter bertambah
- dispatcher berhenti
- retry tinggi

# 26. Security

Payload:

- tanpa password
- tanpa token
- tanpa API key
- PHI minimum

# 27. Healthcare Rule

Event EMR, Homecare, Woundcare:

- gunakan reference ID
- detail diambil melalui repository sesuai RBAC & Scope

# 28. Audit

Event:

- outbox.created
- outbox.locked
- outbox.published
- outbox.retry
- outbox.dead_letter
- inbox.processed

# 29. UAT

Scenario:

- crash setelah commit → event tetap terkirim.
- dispatcher restart → melanjutkan pending.
- retry berhasil.
- poison message masuk dead-letter.
- duplicate message diproses sekali.
- multi-worker tidak memproses message yang sama.

# 30. Anti-pattern

- publish broker dalam transaksi DB
- retry tanpa batas
- consumer tidak idempotent
- payload sensitif
- tanpa dead-letter
- lock permanen
- dispatcher update business table

# 31. Definition of Done

- Outbox append tersedia.
- Inbox tersedia.
- Dispatcher tersedia.
- Lease locking tersedia.
- Retry & backoff tersedia.
- Dead-letter tersedia.
- Idempotent consumer tersedia.
- Monitoring & alert tersedia.
- Workflow, Notification, API, dan Event Bus terintegrasi.
- Mendukung modular monolith dan siap migrasi ke broker eksternal.
