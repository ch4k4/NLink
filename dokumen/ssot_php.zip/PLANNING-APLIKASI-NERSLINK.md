# PLANNING-APLIKASI-NERSLINK
# Roadmap Pembuatan Aplikasi Nerslink

**Status:** Draft planning awal  
**Basis:** SSOT Platform Kernel, `ssot/sprint.md`, Scope, IAM, RBAC, Audit, Data, Workflow, API, Security, Deployment, SDK, dan MDM  

---

# 1. Tujuan

Dokumen ini menjadi rencana kerja awal pembuatan aplikasi Nerslink berbasis Enterprise Platform Kernel.

Fokus awal aplikasi:

- multi-tenant klinik/RS/homecare center;
- user, role, permission, dan dynamic menu;
- scope-aware access untuk tenant, organisasi, business entity, unit, team, dan assignment;
- audit trail untuk aktivitas penting;
- master staff, nurse, doctor, patient;
- homecare dan woundcare sebagai modul klinis prioritas;
- compliance-ready sesuai prinsip Permenkes 6/2026.

---

# 2. Prinsip Implementasi

1. Foundation first.
2. Scope sebelum RBAC.
3. RBAC sebelum business rule.
4. Semua transaksi penting wajib audit.
5. Controller tipis, business logic di Service.
6. Query database hanya melalui Repository.
7. Semua tabel transaksi wajib punya scope columns.
8. Semua modul klinis wajib siap untuk event, audit, dan workflow.
9. Fitur dibuat bertahap, tetapi struktur fondasi tidak boleh dibuat sementara yang sulit dimigrasikan.

Execution order standar:

```text
Auth
→ Scope Resolver / Scope Guard
→ RBAC Checker
→ Business Rule
→ Service
→ Repository
→ Audit / Event
```

---

# 3. Target Produk Versi Awal

Versi awal Nerslink harus mampu:

- login aman;
- mengelola tenant/klinik/RS/homecare center;
- mengelola user, role, permission, dan menu dinamis;
- membatasi akses data berdasarkan active scope;
- mencatat audit login, akses data sensitif, create, update, delete, approval, dan finalisasi klinis;
- mengelola staff, dokter, perawat, STR/SIP, credentialing, dan clinical privilege dasar;
- mengelola patient master;
- mengelola homecare visit;
- mengelola woundcare assessment, foto luka, dan episode luka;
- mendukung dokter default/supervisor untuk review klinis;
- menyediakan dashboard operasional awal.

---

# 4. Arsitektur Target

```text
Web / Mobile UI
        |
Controller / API Controller
        |
Middleware: Auth, Scope, RBAC, CSRF/API Auth
        |
Application Service
        |
Domain Rule / Workflow / Audit / Event
        |
Repository
        |
MySQL
```

Module target:

```text
Core
├── Scope
├── IAM
├── RBAC
├── Audit
├── Menu
├── Notification
├── File
└── MDM

Business
├── Organization
├── Staff
├── Credentialing
├── Patient
├── Encounter
├── Homecare
├── Woundcare
├── Consent
├── Billing
└── Reporting
```

---

# 5. Phase 0 — Project Bootstrap

**Tujuan:** membuat kerangka aplikasi siap dikembangkan secara modular.

Deliverables:

- struktur folder aplikasi;
- konfigurasi environment;
- koneksi database;
- migration runner;
- routing web dan API;
- layout dasar web;
- error handling;
- logger dasar;
- base Controller, Service, Repository;
- base middleware pipeline.

Exit criteria:

- aplikasi bisa berjalan lokal;
- database bisa migrate;
- route health check tersedia;
- error ditangani konsisten;
- struktur sudah mendukung modular monolith.

---

# 6. Phase 1 — Kernel Foundation

**Tujuan:** membangun fondasi keamanan dan akses data.

Sprint 1.1 — Scope Engine:

- tabel `tenants`;
- `organizations`;
- `business_entities`;
- `branches`;
- `divisions`;
- `departments`;
- `services`;
- `teams`;
- `workgroups`;
- `assignments`;
- `user_scope_assignments`;
- `scope_access_logs`;
- `ScopeContext`;
- `ScopeResolver`;
- `ScopeGuard`;
- `ScopeMiddleware`;
- switch active scope.

Sprint 1.2 — IAM:

- user management;
- password hashing;
- login/logout;
- session security;
- failed login logging;
- user status lifecycle;
- password reset foundation.

Sprint 1.3 — RBAC:

- roles;
- permissions;
- role_permissions;
- user_role_assignments;
- user_permission_overrides;
- permission checker;
- permission middleware;
- permission cache;
- access denied audit.

Sprint 1.4 — Dynamic Menu:

- modules;
- menus;
- menu_items;
- menu_item_permissions;
- module entity availability;
- feature flags;
- menu builder berdasarkan scope, module, industry, permission, dan feature flag.

Sprint 1.5 — Audit Trail:

- audit_events;
- audit_event_details;
- audit_subjects;
- audit_actors;
- audit helper/logger;
- audit middleware;
- CRUD diff engine.

Exit criteria:

- user bisa login;
- active scope terbentuk;
- route bisa dilindungi permission;
- menu muncul sesuai permission dan active scope;
- semua create/update/delete penting masuk audit.

---

# 7. Phase 2 — Organization & MDM

**Tujuan:** membangun master organisasi dan reference data.

Deliverables:

- legal entity;
- profil klinik/RS/homecare center;
- unit/instalasi;
- jabatan;
- struktur organisasi;
- service catalog operasional;
- lookup/status/reference data;
- code set awal untuk healthcare;
- ownership data master.

Exit criteria:

- tenant memiliki minimal satu organization dan business entity;
- unit dan service bisa dipakai sebagai scope;
- lookup tidak hardcoded di controller/view;
- data master punya status, audit, dan owner.

---

# 8. Phase 3 — Staff, Credentialing & Clinical Privilege

**Tujuan:** memastikan tenaga klinis punya identitas, dokumen, dan kewenangan klinis.

Deliverables:

- staff profile;
- doctor profile;
- nurse profile;
- unit/team assignment;
- STR/SIP/certificate registry;
- expiry warning;
- credentialing request/review/approval;
- clinical privilege catalog;
- privilege assignment;
- privilege checker.

Exit criteria:

- dokter/perawat dapat ditugaskan ke scope tertentu;
- STR/SIP expiry dapat memberi warning/block;
- tindakan klinis dapat dicek terhadap privilege;
- approval credentialing tercatat di audit.

---

# 9. Phase 4 — Patient & Encounter Foundation

**Tujuan:** transaksi pasien mulai berjalan.

Deliverables:

- patient master;
- nomor rekam medis;
- alamat dan kontak;
- emergency contact;
- duplicate detection dasar;
- encounter/visit;
- appointment dasar;
- consent foundation.

Exit criteria:

- pasien dapat dibuat dan dicari sesuai scope;
- visit/encounter dapat dibuat;
- pasien tidak bocor lintas tenant/business entity;
- akses patient record sensitif diaudit.

---

# 10. Phase 5 — Homecare Core

**Tujuan:** mendukung operasional kunjungan homecare.

Deliverables:

- homecare visit;
- assignment nurse/doctor;
- jadwal kunjungan;
- visit status lifecycle;
- catatan kunjungan;
- vital sign dasar;
- finalisasi kunjungan;
- escalation/referral dasar;
- event untuk visit created/updated/finalized.

Exit criteria:

- nurse hanya melihat visit yang sesuai scope/assignment;
- visit bisa difinalisasi sesuai permission;
- doctor default/supervisor dapat direferensikan;
- perubahan penting masuk audit;
- homecare siap menjadi dependency woundcare.

---

# 11. Phase 6 — Woundcare Core

**Tujuan:** membangun modul woundcare klinis prioritas.

Deliverables:

- wound episode;
- wound assessment;
- wound assessment photo;
- wound measurement;
- wound stage/status;
- care plan dasar;
- progress note;
- escalation;
- finalization;
- file upload aman;
- audit akses foto dan data klinis.

Exit criteria:

- assessment terkait episode dan visit;
- foto luka disimpan melalui file service, bukan public upload langsung;
- update assessment mengikuti permission dan scope;
- finalisasi tidak bisa diedit langsung tanpa amendment;
- data siap dicari dan dilaporkan.

---

# 12. Phase 7 — Notification, Workflow & Approval

**Tujuan:** membuat proses klinis dan administratif tidak hardcoded.

Deliverables:

- notification template;
- notification preference;
- reminder dokumen expired;
- workflow definition;
- state machine;
- approval engine;
- scheduler/job engine;
- approval untuk credentialing, refund, finalisasi khusus, dan break-glass access.

Exit criteria:

- notifikasi tidak hardcoded di controller;
- workflow transition tidak ubah state langsung;
- approval maker-checker tersedia;
- scheduler bisa menjalankan reminder.

---

# 13. Phase 8 — Billing Foundation

**Tujuan:** layanan dapat ditagihkan.

Deliverables:

- service catalog billing;
- tariff version;
- bill item;
- invoice;
- payment;
- refund request;
- refund approval;
- audit nominal.

Exit criteria:

- tarif punya masa berlaku;
- invoice dapat dibentuk dari layanan;
- refund wajib approval;
- perubahan nominal tercatat audit.

---

# 14. Phase 9 — Reporting, Search & Integration

**Tujuan:** data dapat dicari, diekspor, dan diintegrasikan.

Deliverables:

- search index;
- patient/homecare/woundcare search;
- report definition;
- report run log;
- export PDF/Excel;
- integration endpoint registry;
- API credential;
- request/response log;
- retry/error handling.

Exit criteria:

- search tidak menampilkan data di luar scope;
- report mematuhi RBAC;
- export terekam audit;
- integrasi tidak menyimpan credential plain.

---

# 15. Phase 10 — Security, Observability & Deployment

**Tujuan:** aplikasi siap diuji dan dirilis.

Deliverables:

- structured logging;
- correlation ID;
- health check;
- metrics dasar;
- security baseline;
- CSRF untuk web form;
- API auth untuk API;
- rate limiting dasar;
- backup/restore plan;
- deployment checklist;
- UAT checklist.

Exit criteria:

- setiap request punya correlation ID;
- health check tersedia;
- log tidak membocorkan secret/PHI berlebihan;
- backup dan restore test terdokumentasi;
- deployment mengikuti mode bertahap: OFF, SHADOW, MONITOR, WARN, ENFORCE untuk kontrol keamanan tertentu.

---

# 16. Prioritas MVP

Urutan MVP yang direkomendasikan:

1. Bootstrap aplikasi.
2. Scope Engine.
3. IAM.
4. RBAC.
5. Dynamic Menu.
6. Audit Trail.
7. Organization master.
8. Staff/nurse/doctor profile.
9. Credentialing dan clinical privilege dasar.
10. Patient master.
11. Homecare visit.
12. Woundcare assessment.
13. File upload klinis.
14. Dashboard operasional awal.
15. Notification reminder dasar.

---

# 17. Definition of Done Umum

Satu fitur dianggap selesai bila:

- migration tersedia;
- seeder tersedia bila diperlukan;
- route/controller tersedia;
- service layer tersedia;
- repository layer tersedia;
- scope filter diterapkan;
- permission diterapkan;
- audit event diterapkan untuk aksi penting;
- validasi input tersedia;
- error handling konsisten;
- UI/API mengikuti standar;
- test minimal tersedia untuk happy path, denied by scope, denied by permission;
- dokumentasi singkat diperbarui.

---

# 18. Risiko Utama

| Risiko | Mitigasi |
|---|---|
| Scope terlambat dibuat | Scope wajib Sprint 1.1 |
| RBAC hanya berbasis role kasar | Gunakan permission granular dan active scope |
| Audit ditambahkan belakangan | Audit masuk Phase 1 |
| Clinical privilege dilupakan | Dibuat sebelum modul klinis |
| File klinis disimpan public | Gunakan File Service sejak Woundcare |
| Workflow hardcoded | Pakai state machine untuk proses approval/finalisasi |
| Lookup tersebar di kode | MDM/reference data dibuat sebelum modul besar |

---

# 19. Keputusan Awal

1. Aplikasi dibangun sebagai Modular Monolith First.
2. Database utama MySQL.
3. Runtime lokal mengikuti standar PHP + MySQL + XAMPP.
4. Scope menggunakan hierarchy enterprise: tenant, organization, business entity, branch, division, department, service, team, workgroup, assignment.
5. Healthcare memakai business entity type seperti hospital, clinic, homecare_center, woundcare_service sesuai kebutuhan implementasi.
6. Modul klinis pertama adalah Homecare dan Woundcare setelah fondasi kernel siap.

---

# 20. Langkah Berikutnya

Langkah teknis berikutnya:

1. Tentukan stack final project skeleton.
2. Buat struktur aplikasi modular.
3. Buat migration Phase 0 dan Phase 1.
4. Implement Scope Engine.
5. Implement IAM login/session.
6. Implement RBAC checker dan dynamic menu.
7. Implement audit logger.
8. Baru masuk master organisasi dan staff.

