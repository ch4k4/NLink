# SSOT-PRIVACY-01 — Privacy Operations, Data Subject Rights & Request Fulfillment Governance

## Status Dokumen

| Item | Nilai |
|---|---|
| Kode | SSOT-PRIVACY-01 |
| Judul | Privacy Operations, Data Subject Rights & Request Fulfillment Governance |
| Versi | 1.0 |
| Status | Draft Architecture |
| Domain | Platform Kernel |
| Kategori | Privacy Operations, Data Subject Rights, Request Fulfillment & Evidence |
| Cakupan | Access, Correction, Restriction, Objection, Portability, Deletion, Identity Verification, Discovery, Fulfillment, Exemptions, Evidence, Reconciliation |
| Bergantung pada | SSOT-GOV-01, SSOT-GOV-04, SSOT-GOV-05, SSOT-DATA-01..08, SSOT-RECORDS-01, SSOT-SCOPE-01, SSOT-IAM-01..08, SSOT-AUDIT-01, SSOT-FILE-02..03, SSOT-API-06..09, SSOT-SEC-03, SSOT-TEST-01 |
| Target Stack | PHP 8.1+, REST/JSON, PDO, MySQL 8/MariaDB, File/Object Storage |
| Target Evolusi | Central Privacy Operations Service, Automated Data Discovery, Policy-Driven Fulfillment, Continuous Privacy Assurance |

# 1. Executive Summary

SSOT-PRIVACY-01 menetapkan governance resmi untuk privacy operations dan pemenuhan hak subjek data.

Dokumen ini memastikan setiap privacy request:

- terdaftar;
- memiliki identity verification;
- memiliki legal/policy basis;
- memiliki owner;
- memiliki SLA;
- memiliki discovery scope;
- memiliki fulfillment plan;
- memperhitungkan retention dan legal hold;
- menghasilkan evidence;
- dapat direkonsiliasi lintas sistem;
- dapat diaudit.

# 2. Objectives

Framework harus:

- menyediakan privacy-request registry;
- menyediakan identity verification;
- mengatur rights assessment;
- menyediakan discovery;
- mengatur fulfillment;
- menangani exemptions;
- mengatur retention/legal-hold conflicts;
- menyediakan communications;
- menghasilkan evidence;
- menyediakan reconciliation.

# 3. Core Principles

```text
Every Privacy Request Is Registered
Identity Must Be Verified
Rights Are Evaluated, Not Assumed
Discovery Must Be Complete
Data Minimization Applies to Fulfillment
Retention and Legal Hold Must Be Respected
Fulfillment Must Be Traceable
Exceptions Must Be Explicit
Evidence Must Be Preserved
Every Request Must Be Reconciled
```

# 4. Scope

Berlaku untuk:

```text
Patients
Customers
Employees
Practitioners
Partners
Portal Users
Prospects
Vendors
Representatives
Authorized Agents
```

# 5. Privacy Request Types

```text
ACCESS
CORRECTION
DELETION
RESTRICTION
OBJECTION
PORTABILITY
CONSENT_WITHDRAWAL
PROCESSING_INFORMATION
AUTOMATED_DECISION_REVIEW
REPRESENTATIVE_REQUEST
```

# 6. Request Registry

Minimum:

```text
request_code
request_type
subject_reference
requester_reference
tenant
received_at
due_at
status
owner
verification_status
decision
```

# 7. Request Lifecycle

```text
RECEIVED
ACKNOWLEDGED
IDENTITY_VERIFICATION
IN_ASSESSMENT
DISCOVERY
FULFILLMENT_PLANNING
FULFILLING
QUALITY_REVIEW
READY_TO_DELIVER
DELIVERED
PARTIALLY_FULFILLED
DENIED
WITHDRAWN
CLOSED
REOPENED
```

# 8. Request Channels

```text
PORTAL
EMAIL
FORM
CALL_CENTER
IN_PERSON
AUTHORIZED_AGENT
REGULATOR
INTERNAL_ESCALATION
```

# 9. Request Ownership

Setiap request memiliki:

- privacy operations owner;
- data owner;
- business owner;
- legal/compliance reviewer where required;
- technical fulfillment owner;
- communication owner.

# 10. Identity Verification

Verification harus risk-based dan proportionate.

# 11. Verification Methods

```text
AUTHENTICATED_PORTAL
MULTI_FACTOR_CHALLENGE
KNOWN_ACCOUNT_FACTORS
DOCUMENT_REVIEW
IN_PERSON_VERIFICATION
AUTHORIZED_REPRESENTATIVE
MANUAL_APPROVED
```

# 12. Verification States

```text
NOT_STARTED
PENDING
VERIFIED
FAILED
EXPIRED
WAIVED_APPROVED
```

# 13. Verification Evidence

Minimum:

```text
method
verified attributes
verifier
timestamp
expiry
evidence reference
```

# 14. Data Minimization in Verification

Jangan mengumpulkan identitas tambahan melebihi kebutuhan.

# 15. Authorized Representative

Requires:

- subject identity;
- representative identity;
- authority evidence;
- scope;
- validity;
- revocation status.

# 16. Minor or Dependent Subjects

Requires guardian/representative policy and evidence.

# 17. Request Authentication

Submission itself does not prove identity.

# 18. Rights Assessment

Assessment determines whether right applies and to what scope.

# 19. Assessment Inputs

- subject category;
- jurisdiction/policy;
- processing purpose;
- legal basis;
- retention obligations;
- legal hold;
- exemptions;
- identity status;
- system scope.

# 20. Decision Outcomes

```text
APPROVED
PARTIALLY_APPROVED
DENIED
MORE_INFORMATION_REQUIRED
NOT_APPLICABLE
WITHDRAWN
```

# 21. Decision Reason Codes

```text
IDENTITY_NOT_VERIFIED
REQUEST_TOO_BROAD
RETENTION_REQUIRED
LEGAL_HOLD_ACTIVE
THIRD_PARTY_RIGHTS
SECURITY_RISK
DUPLICATE_REQUEST
NO_DATA_FOUND
EXEMPTION_APPLIES
FULFILLED_PREVIOUSLY
```

# 22. SLA

Request SLA must define:

- acknowledgment;
- verification;
- assessment;
- discovery;
- fulfillment;
- delivery;
- closure.

# 23. SLA Clock

Start/stop/pause rules must be explicit.

# 24. SLA Pause

May pause for:

- identity evidence;
- clarification;
- authorized-representative evidence;
- regulator-approved extension.

# 25. Extension

Requires:

- reason;
- approval;
- updated due date;
- notice to requester;
- evidence.

# 26. Escalation

Triggered by:

- SLA breach risk;
- critical subject;
- regulator request;
- broad cross-system scope;
- legal conflict;
- security/privacy incident;
- no owner.

# 27. Data Discovery

Discovery must locate subject data across authoritative and derivative systems.

# 28. Discovery Sources

```text
Operational Databases
Master Data
Files and Attachments
Audit Logs
Events
Search Indexes
Analytics Datasets
Exports
Archives
Backups where applicable
External Processors
```

# 29. Discovery Query

Must be based on verified identifiers and aliases.

# 30. Identity Resolution

Use MDM and authoritative identity registries where applicable.

# 31. Discovery Manifest

Minimum:

```text
system
dataset
record type
identifier used
match result
record count
classification
owner
```

# 32. Discovery Completeness

Must compare expected systems against actual search results.

# 33. No-Data Result

Must still preserve evidence of systems searched.

# 34. False Positive Handling

Potential matches require verification before disclosure or correction.

# 35. Third-Party Data

Access package must redact or exclude unrelated third-party data as required.

# 36. Access Request

Must provide subject data and processing information within approved scope.

# 37. Access Package

May include:

- data copy;
- source categories;
- purposes;
- recipients/categories;
- retention information;
- rights/complaint information;
- automated decision information where applicable.

# 38. Access Package Format

Must be understandable, secure, and commonly usable.

# 39. Secure Delivery

Possible:

```text
AUTHENTICATED_PORTAL
ENCRYPTED_DOWNLOAD
SECURE_FILE_TRANSFER
IN_PERSON
REGISTERED_DELIVERY_APPROVED
```

# 40. Delivery Authentication

Delivery must verify recipient and protect confidentiality.

# 41. Correction Request

Must distinguish:

- factual correction;
- disputed interpretation;
- amendment;
- source-system correction;
- annotation.

# 42. Correction Preconditions

- identity verified;
- target record identified;
- correction evidence reviewed;
- source authority checked;
- downstream impact known.

# 43. Correction Method

Prefer correction at authoritative source and propagate downstream.

# 44. Correction History

Must preserve original value, corrected value, reason, actor, and timestamp.

# 45. Disputed Data

If not corrected, a dispute annotation may be required.

# 46. Deletion Request

Deletion is subject to retention, legal hold, legal obligations, and technical feasibility.

# 47. Deletion Outcomes

```text
FULL_DELETION
PARTIAL_DELETION
RESTRICTION_INSTEAD
ANONYMIZATION
DENIED_RETENTION_REQUIRED
DENIED_LEGAL_HOLD
NO_DATA_FOUND
```

# 48. Deletion Planning

Must include:

- authoritative systems;
- derivative systems;
- files;
- indexes;
- analytics;
- integrations;
- external processors;
- backups policy.

# 49. Deletion Propagation

Every downstream copy must receive deletion/restriction instruction where applicable.

# 50. Backup Handling

Deletion may follow documented backup rotation if restored data is re-deleted.

# 51. Tombstone

May retain minimum evidence to prevent recreation or demonstrate fulfillment.

# 52. Anonymization

Only acceptable if irreversible under approved standard.

# 53. Restriction Request

Restriction may block selected processing while preserving required data.

# 54. Restriction States

```text
ACTIVE
PARTIAL
PENDING
RELEASED
EXPIRED
```

# 55. Restriction Effects

May block:

- marketing;
- profiling;
- exports;
- sharing;
- automated processing;
- selected workflows.

# 56. Objection Request

Must evaluate processing purpose, legal basis, and compelling grounds.

# 57. Portability Request

Must produce subject-provided/observed data in structured, commonly used, machine-readable format.

# 58. Portability Exclusions

Derived analytics, confidential logic, and third-party data may require exclusion.

# 59. Consent Withdrawal

Must identify all processing activities dependent on the withdrawn consent.

# 60. Consent Withdrawal Effects

- stop future processing;
- update preferences;
- revoke downstream permissions;
- preserve historical lawful processing evidence;
- notify processors where required.

# 61. Automated Decision Review

Must provide human review where policy requires.

# 62. Automated Decision Information

May include:

- decision purpose;
- input categories;
- material factors;
- outcome;
- review path.

# 63. Processing Information Request

May require inventory of purposes, categories, recipients, retention, and sources.

# 64. Exemptions

Examples:

```text
LEGAL_PRIVILEGE
THIRD_PARTY_RIGHTS
SECURITY_PROTECTION
FRAUD_PREVENTION
REGULATORY_RESTRICTION
EMPLOYMENT_CONFIDENTIALITY
CLINICAL_SAFETY
TRADE_SECRET
```

# 65. Exemption Governance

Every exemption requires:

- code;
- legal/policy basis;
- scope;
- approver;
- explanation;
- evidence.

# 66. Partial Fulfillment

Allowed when some data/right is exempt or unavailable.

# 67. Denial Notice

Must explain outcome safely and provide escalation/complaint route where required.

# 68. Retention Conflict

RECORDS-01 determines mandatory retention and legal hold.

# 69. Legal Hold Conflict

Active legal hold blocks deletion or destructive correction.

# 70. Restriction Instead of Deletion

Where data must be retained, processing may be restricted.

# 71. Security Conflict

Data disclosure must not expose credentials, secrets, security controls, or attack-sensitive information.

# 72. Third-Party Processor

Processor fulfillment requires:

- processor registry;
- request dispatch;
- acknowledgment;
- due date;
- completion evidence;
- reconciliation.

# 73. Processor Request States

```text
SENT
ACKNOWLEDGED
IN_PROGRESS
COMPLETED
FAILED
OVERDUE
```

# 74. Processor Contract

Must define assistance, response time, deletion, return, evidence, and audit rights.

# 75. Request Fulfillment Plan

Minimum:

```text
systems
actions
owners
due dates
dependencies
exceptions
delivery method
verification
```

# 76. Fulfillment Task Types

```text
DISCOVER
EXPORT
REDACT
CORRECT
DELETE
ANONYMIZE
RESTRICT
NOTIFY_PROCESSOR
VERIFY
DELIVER
```

# 77. Task Dependency

Deletion should not precede required evidence capture or legal review.

# 78. Fulfillment Idempotency

Repeated tasks must not create duplicate side effects.

# 79. Fulfillment Verification

Must verify:

- task completed;
- target state achieved;
- downstream propagation;
- no unauthorized disclosure;
- evidence available.

# 80. Quality Review

Before delivery:

- identity rechecked where needed;
- data package complete;
- redactions correct;
- exclusions documented;
- delivery secure;
- evidence complete.

# 81. Communication Lifecycle

```text
ACKNOWLEDGMENT
CLARIFICATION
EXTENSION
DECISION
DELIVERY
CLOSURE
REOPENING
```

# 82. Communication Templates

Templates must be versioned and approved.

# 83. Sensitive Communication

Do not include sensitive data in unsecured channels.

# 84. Request Withdrawal

Requester may withdraw; evidence and partial actions must remain recorded.

# 85. Duplicate Request

Duplicate handling should link requests without hiding new scope.

# 86. Reopened Request

Allowed when delivery failed, scope was incomplete, or decision was challenged.

# 87. Complaint and Appeal

Must link to internal review or regulator process.

# 88. Incident Linkage

Privacy requests may reveal:

- unauthorized access;
- incorrect disclosure;
- data loss;
- inaccurate records;
- processing without basis.

# 89. Breach Escalation

Potential breach must follow incident/privacy-breach process.

# 90. Request Evidence Package

Minimum:

```text
request
identity verification
assessment
discovery manifest
decisions
fulfillment tasks
processor responses
communications
delivery proof
closure approval
```

# 91. Evidence Integrity

Evidence must be timestamped, attributable, checksummed, retained, and access-controlled.

# 92. Audit Events

```text
PRIVACY_REQUEST_RECEIVED
PRIVACY_IDENTITY_VERIFIED
PRIVACY_IDENTITY_FAILED
PRIVACY_REQUEST_APPROVED
PRIVACY_REQUEST_PARTIALLY_APPROVED
PRIVACY_REQUEST_DENIED
PRIVACY_DISCOVERY_COMPLETED
PRIVACY_FULFILLMENT_TASK_COMPLETED
PRIVACY_DELETION_EXECUTED
PRIVACY_RESTRICTION_APPLIED
PRIVACY_PACKAGE_DELIVERED
PRIVACY_REQUEST_CLOSED
PRIVACY_RECONCILIATION_FAILED
```

# 93. Privacy Reconciliation

Compare:

- request registry;
- verification state;
- discovery systems;
- fulfillment tasks;
- processor responses;
- deletion/restriction state;
- delivery evidence;
- closure status;
- audit events.

# 94. Reconciliation Findings

```text
REQUEST_WITHOUT_OWNER
VERIFIED_REQUEST_WITHOUT_ASSESSMENT
SYSTEM_NOT_DISCOVERED
FULFILLMENT_TASK_OVERDUE
PROCESSOR_RESPONSE_MISSING
DELETION_NOT_PROPAGATED
RESTRICTION_NOT_ENFORCED
DELIVERY_WITHOUT_PROOF
CLOSED_REQUEST_WITH_OPEN_TASK
EXEMPTION_WITHOUT_EVIDENCE
```

# 95. Auto-Remediation

Examples:

- reopen incomplete request;
- resend processor task;
- reapply restriction;
- re-run discovery;
- repair missing evidence linkage;
- escalate overdue task.

# 96. Manual Remediation

Required for:

- identity ambiguity;
- legal conflict;
- third-party rights;
- clinical safety;
- cross-tenant contamination;
- disclosure error;
- failed deletion.

# 97. Metrics

```text
privacy_request_total
privacy_request_open_total
privacy_request_overdue_total
privacy_identity_failure_total
privacy_access_request_total
privacy_deletion_request_total
privacy_partial_fulfillment_total
privacy_denial_total
privacy_processor_overdue_total
privacy_reconciliation_failure_total
```

# 98. KPIs

```text
Requests without owner = 0
Verified requests without assessment = 0
Closed requests with open tasks = 0
Deliveries without proof = 0
Deletion requests without propagation evidence = 0
Exemptions without documented basis = 0
Cross-tenant privacy disclosure = 0
```

# 99. KRIs

```text
Overdue request growth
Identity verification failures
Partial fulfillment rate
Deletion propagation failures
Processor delays
Reopened requests
Complaint rate
Discovery coverage gaps
```

# 100. Database Direction

Potential tables:

```text
privacy_requests
privacy_request_subjects
privacy_identity_verifications
privacy_request_assessments
privacy_request_discovery_runs
privacy_request_discovery_results
privacy_fulfillment_tasks
privacy_request_exemptions
privacy_processor_tasks
privacy_delivery_packages
privacy_request_communications
privacy_request_evidence
privacy_reconciliation_runs
privacy_reconciliation_findings
```

# 101. Table: privacy_requests

```sql
CREATE TABLE privacy_requests (
    id CHAR(26) NOT NULL,
    request_code VARCHAR(180) NOT NULL,
    request_type VARCHAR(50) NOT NULL,
    tenant_id CHAR(26) NOT NULL,
    subject_reference VARCHAR(255) NOT NULL,
    requester_reference VARCHAR(255) NOT NULL,
    channel VARCHAR(40) NOT NULL,
    verification_status VARCHAR(30) NOT NULL,
    status VARCHAR(40) NOT NULL,
    owner_reference VARCHAR(180) NULL,
    received_at DATETIME(6) NOT NULL,
    due_at DATETIME(6) NOT NULL,
    closed_at DATETIME(6) NULL,

    PRIMARY KEY (id),
    UNIQUE KEY uq_privacy_request_code (request_code),
    KEY idx_privacy_request_status (
        tenant_id,
        status,
        due_at
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

# 102. Table: privacy_identity_verifications

```sql
CREATE TABLE privacy_identity_verifications (
    id CHAR(26) NOT NULL,
    request_id CHAR(26) NOT NULL,
    verification_method VARCHAR(50) NOT NULL,
    status VARCHAR(30) NOT NULL,
    verified_attributes_json JSON NULL,
    evidence_reference VARCHAR(1000) NULL,
    verified_by VARCHAR(180) NULL,
    verified_at DATETIME(6) NULL,
    expires_at DATETIME(6) NULL,

    PRIMARY KEY (id),
    KEY idx_privacy_verification_request (
        request_id,
        status
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

# 103. Table: privacy_fulfillment_tasks

```sql
CREATE TABLE privacy_fulfillment_tasks (
    id CHAR(26) NOT NULL,
    request_id CHAR(26) NOT NULL,
    task_type VARCHAR(50) NOT NULL,
    target_system VARCHAR(180) NOT NULL,
    target_reference VARCHAR(1000) NULL,
    owner_reference VARCHAR(180) NOT NULL,
    status VARCHAR(30) NOT NULL,
    due_at DATETIME(6) NOT NULL,
    completed_at DATETIME(6) NULL,
    evidence_reference VARCHAR(1000) NULL,

    PRIMARY KEY (id),
    KEY idx_privacy_task_status (
        request_id,
        status,
        due_at
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

# 104. Table: privacy_request_exemptions

```sql
CREATE TABLE privacy_request_exemptions (
    id CHAR(26) NOT NULL,
    request_id CHAR(26) NOT NULL,
    exemption_code VARCHAR(100) NOT NULL,
    basis_reference VARCHAR(1000) NOT NULL,
    scope_json JSON NOT NULL,
    approved_by VARCHAR(180) NOT NULL,
    approved_at DATETIME(6) NOT NULL,
    expires_at DATETIME(6) NULL,

    PRIMARY KEY (id),
    KEY idx_privacy_exemption_request (
        request_id,
        exemption_code
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

# 105. API Direction

```text
GET  /api/internal/v1/privacy/requests
POST /api/internal/v1/privacy/requests
GET  /api/internal/v1/privacy/requests/{requestCode}
POST /api/internal/v1/privacy/requests/{requestCode}/verify-identity
POST /api/internal/v1/privacy/requests/{requestCode}/assess
POST /api/internal/v1/privacy/requests/{requestCode}/discover
POST /api/internal/v1/privacy/requests/{requestCode}/tasks
POST /api/internal/v1/privacy/requests/{requestCode}/deliver
POST /api/internal/v1/privacy/requests/{requestCode}/close
POST /api/internal/v1/privacy/requests/{requestCode}/reopen
POST /api/internal/v1/privacy/reconciliation/runs
```

# 106. SDK Contracts

```text
PrivacyRequestRegistryInterface
PrivacyIdentityVerificationServiceInterface
PrivacyRightsAssessmentServiceInterface
PrivacyDiscoveryServiceInterface
PrivacyFulfillmentServiceInterface
PrivacyDeliveryServiceInterface
PrivacyReconciliationServiceInterface
```

# 107. Request Registry Contract

```php
interface PrivacyRequestRegistryInterface
{
    public function find(
        string $requestCode
    ): ?PrivacyRequest;

    public function requireOpen(
        string $requestCode
    ): PrivacyRequest;
}
```

# 108. Discovery Contract

```php
interface PrivacyDiscoveryServiceInterface
{
    public function discover(
        PrivacyDiscoveryRequest $request
    ): PrivacyDiscoveryResult;
}
```

# 109. Fulfillment Contract

```php
interface PrivacyFulfillmentServiceInterface
{
    public function execute(
        PrivacyFulfillmentTaskRequest $request
    ): PrivacyFulfillmentTaskResult;
}
```

# 110. Error Codes

```text
PRIVACY_REQUEST_NOT_FOUND
PRIVACY_IDENTITY_NOT_VERIFIED
PRIVACY_REQUEST_NOT_APPLICABLE
PRIVACY_DISCOVERY_INCOMPLETE
PRIVACY_LEGAL_HOLD_ACTIVE
PRIVACY_RETENTION_REQUIRED
PRIVACY_THIRD_PARTY_REVIEW_REQUIRED
PRIVACY_FULFILLMENT_FAILED
PRIVACY_DELIVERY_FAILED
PRIVACY_EXEMPTION_REQUIRED
PRIVACY_CLOSURE_DENIED
PRIVACY_RECONCILIATION_FAILED
```

# 111. Request Intake Checklist

- [ ] Request type identified.
- [ ] Tenant resolved.
- [ ] Subject identified.
- [ ] Requester identified.
- [ ] Channel recorded.
- [ ] Owner assigned.
- [ ] SLA calculated.
- [ ] Verification method selected.
- [ ] Acknowledgment sent.
- [ ] Audit generated.

# 112. Fulfillment Checklist

- [ ] Identity verified.
- [ ] Assessment approved.
- [ ] Discovery complete.
- [ ] Retention checked.
- [ ] Legal holds checked.
- [ ] Exemptions reviewed.
- [ ] Tasks assigned.
- [ ] Processor tasks completed.
- [ ] Quality review passed.
- [ ] Delivery secured.
- [ ] Evidence complete.
- [ ] Closure approved.

# 113. UAT — Intake & Identity Verification

- [ ] Request registers.
- [ ] Duplicate request links correctly.
- [ ] Authenticated portal verification works.
- [ ] Failed verification blocks fulfillment.
- [ ] Representative authority validated.
- [ ] Expired verification rejected.
- [ ] SLA pause works for missing evidence.
- [ ] Acknowledgment records correctly.
- [ ] Audit complete.

# 114. UAT — Discovery

- [ ] Operational database searched.
- [ ] Master-data aliases resolved.
- [ ] Files discovered.
- [ ] Search indexes discovered.
- [ ] Analytics datasets discovered.
- [ ] External processors queried.
- [ ] Third-party false positives removed.
- [ ] No-data result preserves evidence.
- [ ] Completeness reconciliation passes.

# 115. UAT — Access & Portability

- [ ] Access package includes approved data.
- [ ] Third-party data redacted.
- [ ] Secrets excluded.
- [ ] Processing information included.
- [ ] Portability format machine-readable.
- [ ] Derived confidential data excluded where required.
- [ ] Delivery authentication works.
- [ ] Download expires.
- [ ] Delivery proof retained.

# 116. UAT — Correction

- [ ] Authoritative record corrected.
- [ ] Original value retained.
- [ ] Downstream copies updated.
- [ ] Dispute annotation works.
- [ ] Active legal hold blocks destructive overwrite.
- [ ] Correction evidence retained.
- [ ] Incorrect target rejected.
- [ ] Audit complete.
- [ ] Verification passes.

# 117. UAT — Deletion & Restriction

- [ ] Eligible data deleted.
- [ ] Retention-required data preserved.
- [ ] Legal-hold data preserved.
- [ ] Restriction applied instead of deletion.
- [ ] Search/index copies handled.
- [ ] Analytics copies handled.
- [ ] Processor deletion verified.
- [ ] Backup re-deletion policy recorded.
- [ ] Tombstone retained where required.
- [ ] Propagation reconciliation passes.

# 118. UAT — Consent & Objection

- [ ] Consent withdrawal stops dependent processing.
- [ ] Historical evidence retained.
- [ ] Marketing preference updated.
- [ ] Processor notified.
- [ ] Objection assessment records grounds.
- [ ] Compelling-ground denial requires approval.
- [ ] Restriction applies during assessment where required.
- [ ] Communication delivered.
- [ ] Audit complete.

# 119. UAT — Exemptions & Partial Fulfillment

- [ ] Valid exemption applies.
- [ ] Invalid exemption rejected.
- [ ] Third-party rights trigger review.
- [ ] Partial package excludes exempt data.
- [ ] Denial notice contains safe explanation.
- [ ] Appeal route included.
- [ ] Exemption evidence retained.
- [ ] Expired exemption rejected.
- [ ] Closure review passes.

# 120. UAT — Reconciliation

- [ ] Request without owner detected.
- [ ] Verified request without assessment detected.
- [ ] Missing discovery system detected.
- [ ] Overdue task detected.
- [ ] Missing processor response detected.
- [ ] Deletion propagation failure detected.
- [ ] Restriction failure detected.
- [ ] Delivery without proof detected.
- [ ] Closed request with open task detected.
- [ ] Exemption without evidence detected.

# 121. Definition of Done — SSOT-PRIVACY-01

SSOT-PRIVACY-01 dianggap selesai bila:

- [ ] request types tersedia;
- [ ] request registry tersedia;
- [ ] lifecycle tersedia;
- [ ] ownership tersedia;
- [ ] identity verification tersedia;
- [ ] representative handling tersedia;
- [ ] rights assessment tersedia;
- [ ] decision codes tersedia;
- [ ] SLA/escalation tersedia;
- [ ] discovery manifest tersedia;
- [ ] access fulfillment tersedia;
- [ ] correction tersedia;
- [ ] deletion/restriction tersedia;
- [ ] portability tersedia;
- [ ] consent withdrawal tersedia;
- [ ] objection and automated-decision review tersedia;
- [ ] exemptions tersedia;
- [ ] retention/legal-hold conflict tersedia;
- [ ] processor fulfillment tersedia;
- [ ] fulfillment tasks tersedia;
- [ ] secure delivery tersedia;
- [ ] communications tersedia;
- [ ] evidence package tersedia;
- [ ] reconciliation tersedia;
- [ ] audit and metrics tersedia;
- [ ] database direction tersedia;
- [ ] API direction tersedia;
- [ ] SDK contracts tersedia;
- [ ] UAT and DoD tersedia.

# 122. Implementation Roadmap

## Phase 1 — Request Registry Foundation

- request registry;
- ownership;
- lifecycle;
- SLA;
- intake channels;
- communications.

## Phase 2 — Identity, Assessment & Discovery

- identity verification;
- representative validation;
- rights assessment;
- discovery connectors;
- discovery manifests;
- completeness checks.

## Phase 3 — Fulfillment Operations

- access packages;
- correction;
- deletion;
- restriction;
- portability;
- consent withdrawal;
- processor tasks.

## Phase 4 — Evidence & Assurance

- secure delivery;
- evidence packages;
- exemptions;
- quality review;
- reconciliation;
- operational dashboards.

## Phase 5 — Privacy Operations Platform

- automated discovery;
- policy-assisted assessment;
- cross-system fulfillment orchestration;
- continuous privacy assurance;
- regulator-ready evidence;
- privacy operations dashboard.

# 123. Initial Implementation Backlog

```text
PRIVACY01-001 Privacy Request Registry
PRIVACY01-002 Identity Verification
PRIVACY01-003 Representative Authority
PRIVACY01-004 Rights Assessment
PRIVACY01-005 SLA & Escalation
PRIVACY01-006 Discovery Connectors
PRIVACY01-007 Discovery Manifest
PRIVACY01-008 Access Package Builder
PRIVACY01-009 Correction Workflow
PRIVACY01-010 Deletion/Restriction Orchestrator
PRIVACY01-011 Portability Export
PRIVACY01-012 Consent Withdrawal
PRIVACY01-013 Processor Task Management
PRIVACY01-014 Secure Delivery & Evidence
PRIVACY01-015 Reconciliation Engine
PRIVACY01-016 Privacy Operations Dashboard
```

# 124. Approval Gate

Dokumen dapat menjadi Approved setelah:

- Privacy review;
- Legal/Compliance review;
- Data Architecture review;
- Records Management review;
- IAM/Security review;
- Integration Architecture review;
- Operations review;
- Audit review;
- Quality Engineering review;
- UAT review.

# 125. Closing Statement

Privacy operations tidak selesai hanya dengan menerima permintaan.

Setiap request harus diverifikasi, dinilai, ditemukan datanya, dipenuhi secara aman, dan dibuktikan.

Retention dan legal hold harus dihormati.

Deletion dan restriction harus dipropagasikan lintas sistem.

Setiap keputusan, pengecualian, dan delivery harus dapat diaudit dan direkonsiliasi.
