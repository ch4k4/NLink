
# SSOT-NOTIFY-02 — Template Engine

## Status Dokumen

| Item | Nilai |
|---|---|
| Kode | SSOT-NOTIFY-02 |
| Nama | Template Engine |
| Domain | Platform Kernel / Notification |
| Bergantung pada | SSOT-NOTIFY-01, SSOT-DATA, SSOT-AUDIT |

# 1. Tujuan

Template Engine memisahkan isi pesan dari kode aplikasi sehingga seluruh notifikasi menggunakan template yang dapat dikelola, diberi versi, diaudit, dan dilokalkan.

# 2. Prinsip

- Tidak ada isi pesan hardcoded di source code.
- Template memiliki versioning.
- Template mendukung multi-bahasa.
- Rendering aman (escaping).
- Template dapat dipakai lintas kanal.

# 3. Komponen

```text
template_definitions
template_versions
template_variables
template_locales
template_render_logs
```

# 4. Struktur Template

Template terdiri dari:

- subject (opsional)
- body
- channel
- locale
- variable schema

Contoh:

Subject:
```text
Homecare Visit {{visit_number}}
```

Body:
```text
Halo {{patient_name}},
Kunjungan dijadwalkan pada {{visit_date}} pukul {{visit_time}}.
```

# 5. Variabel

Gunakan format:

```text
{{patient_name}}
{{visit_date}}
{{nurse_name}}
```

Tidak boleh mengeksekusi ekspresi atau kode.

# 6. Validasi

Saat publish template:

- semua placeholder valid
- schema sesuai
- tidak ada placeholder duplikat
- tidak ada placeholder tidak dikenal

# 7. Versioning

Setiap perubahan membuat versi baru.

```text
v1
v2
v3
```

Instance lama tetap dapat menggunakan versi yang berlaku saat dibuat bila diperlukan.

# 8. Multi-language

Contoh locale:

```text
id-ID
en-US
```

Fallback:

```text
requested locale
→ tenant default
→ system default
```

# 9. Database

## template_definitions

```sql
CREATE TABLE template_definitions (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 code VARCHAR(150) NOT NULL UNIQUE,
 name VARCHAR(150) NOT NULL,
 channel_code VARCHAR(50) NOT NULL,
 status ENUM('active','inactive') DEFAULT 'active',
 created_at TIMESTAMP NULL,
 updated_at TIMESTAMP NULL
);
```

## template_versions

```sql
CREATE TABLE template_versions (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 template_definition_id BIGINT UNSIGNED NOT NULL,
 version_number INT NOT NULL,
 locale VARCHAR(20) NOT NULL,
 subject_template TEXT NULL,
 body_template LONGTEXT NOT NULL,
 variables_schema JSON NULL,
 status ENUM('draft','active','deprecated') DEFAULT 'draft',
 approved_by BIGINT UNSIGNED NULL,
 approved_at DATETIME NULL,
 created_at TIMESTAMP NULL,
 updated_at TIMESTAMP NULL,
 UNIQUE KEY uq_template_version(template_definition_id,version_number,locale)
);
```

## template_render_logs

Menyimpan:

- template
- versi
- locale
- correlation_id
- render_result
- rendered_at

# 10. Rendering Flow

```text
Receive event
→ Resolve template
→ Resolve locale
→ Validate payload
→ Render
→ Escape output
→ Create notification message
```

# 11. Escaping

Default escape untuk mencegah injection.

Hanya placeholder yang telah divalidasi yang boleh dirender.

# 12. Attachment

Template dapat mendefinisikan attachment dinamis.

Contoh:

```text
invoice.pdf
visit-summary.pdf
```

# 13. Preview

Admin dapat melakukan preview dengan sample payload tanpa mengirim notifikasi.

# 14. Approval

Perubahan template dapat menggunakan Approval Engine sebelum dipublikasikan.

# 15. Audit

Event:

```text
template.created
template.updated
template.version.published
template.rendered
template.previewed
```

# 16. Healthcare Rule

Template untuk pasien:

- jangan menampilkan PHI sensitif di kanal tidak aman;
- gunakan wording umum;
- arahkan pengguna membuka aplikasi untuk detail klinis.

# 17. UAT

- Publish versi baru berhasil.
- Fallback locale bekerja.
- Placeholder tervalidasi.
- Preview sesuai payload.
- Render log tercatat.

# 18. Anti-pattern

Hindari:

- string hardcoded di service
- template tanpa versi
- placeholder bebas
- HTML/script tidak disanitasi
- perubahan template langsung di production tanpa audit

# 19. Definition of Done

- Template versioning tersedia.
- Multi-language tersedia.
- Placeholder tervalidasi.
- Preview tersedia.
- Audit tersedia.
- Terintegrasi dengan Notification Framework.
