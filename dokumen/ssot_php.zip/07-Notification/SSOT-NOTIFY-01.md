
# SSOT-NOTIFY-01 — Notification Framework

## Status Dokumen

| Item | Nilai |
|---|---|
| Kode | SSOT-NOTIFY-01 |
| Nama | Notification Framework |
| Versi | 1.0 |
| Status | Draft Architecture |
| Domain | Platform Kernel / Notification |
| Berlaku Untuk | Multi-tenant, multi-organization, multi-business entity, healthcare, non-healthcare |
| Dependensi | SSOT-IAM, SSOT-SCOPE, SSOT-RBAC, SSOT-AUDIT, SSOT-WF-01 s.d. SSOT-WF-04, SSOT-DATA |

---

# 1. Tujuan

Notification Framework adalah komponen Platform Kernel untuk mengirim notifikasi secara konsisten melalui berbagai kanal.

Kanal yang didukung:

```text
in_app
email
sms
whatsapp
push_notification
webhook
```

Notification Framework dipakai oleh:

- Workflow Engine;
- Approval Engine;
- Scheduler & Job Engine;
- IAM;
- Audit & Security;
- Modul bisnis healthcare;
- Modul bisnis non-healthcare.

---

# 2. Prinsip Dasar

## 2.1 Notification tidak boleh hardcoded di controller

Tidak boleh:

```php
mail($email, 'Approval', 'Please approve');
```

Harus melalui Notification Service.

## 2.2 Notification harus event-driven

Notifikasi idealnya dipicu oleh event.

Contoh:

```text
approval.request.submitted
homecare.visit.assigned
auth.password.reset.requested
billing.invoice.created
```

## 2.3 Notification harus template-based

Isi pesan tidak boleh hardcoded di service.

Gunakan template.

## 2.4 Notification harus auditable

Setiap notifikasi penting harus dicatat.

## 2.5 Notification harus preference-aware

User dapat memiliki preferensi kanal bila policy mengizinkan.

## 2.6 Notification harus retryable

Kegagalan pengiriman harus dapat diulang.

---

# 3. Jenis Notifikasi

```text
transactional
security
workflow
reminder
marketing
system
integration
```

## 3.1 Transactional

Contoh:

```text
invoice created
payment received
appointment confirmed
```

## 3.2 Security

Contoh:

```text
login from new device
password changed
MFA enabled
API key created
```

## 3.3 Workflow

Contoh:

```text
approval assigned
task overdue
workflow rejected
```

## 3.4 Reminder

Contoh:

```text
homecare visit reminder
credential expiry reminder
document review reminder
```

## 3.5 Marketing

Opsional dan harus mengikuti consent.

## 3.6 System

Contoh:

```text
backup failed
integration failed
queue backlog high
```

## 3.7 Integration

Contoh:

```text
webhook sent
partner notification
```

---

# 4. Kanal Notifikasi

## 4.1 In-App

Muncul di aplikasi.

## 4.2 Email

Digunakan untuk notifikasi formal, laporan, reset password, dan approval.

## 4.3 SMS

Fallback untuk OTP/reminder penting.

## 4.4 WhatsApp

Penting untuk konteks Indonesia, appointment reminder, homecare reminder, customer communication.

## 4.5 Push Notification

Untuk mobile app.

## 4.6 Webhook

Untuk sistem eksternal.

---

# 5. Komponen Framework

```text
notification_events
notification_templates
notification_template_versions
notification_recipients
notification_messages
notification_deliveries
notification_channels
notification_providers
notification_preferences
notification_subscriptions
notification_failures
notification_webhooks
```

---

# 6. Notification Event

Notification event adalah trigger.

Contoh:

```text
approval.request.submitted
approval.request.approved
homecare.visit.assigned
auth.password.reset.requested
```

---

# 7. Notification Message

Message adalah pesan yang akan dikirim ke recipient.

Message dapat menghasilkan beberapa delivery berdasarkan kanal.

Contoh:

```text
1 message → email + in_app + whatsapp
```

---

# 8. Notification Delivery

Delivery adalah pengiriman aktual ke kanal tertentu.

Contoh:

```text
message_id = 100
channel = whatsapp
status = sent
```

---

# 9. Database — notification_events

```sql
CREATE TABLE notification_events (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,

    code VARCHAR(150) NOT NULL UNIQUE,
    name VARCHAR(150) NOT NULL,
    description TEXT NULL,

    domain_code VARCHAR(100) NULL,
    event_type VARCHAR(100) NOT NULL,

    default_priority ENUM('low','normal','high','critical') NOT NULL DEFAULT 'normal',
    status ENUM('active','inactive') NOT NULL DEFAULT 'active',

    created_at TIMESTAMP NULL,
    updated_at TIMESTAMP NULL,
    deleted_at TIMESTAMP NULL
);
```

---

# 10. Database — notification_channels

```sql
CREATE TABLE notification_channels (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,

    code VARCHAR(50) NOT NULL UNIQUE,
    name VARCHAR(100) NOT NULL,

    status ENUM('active','inactive') NOT NULL DEFAULT 'active',

    created_at TIMESTAMP NULL,
    updated_at TIMESTAMP NULL
);
```

Seed channel:

```text
in_app
email
sms
whatsapp
push
webhook
```

---

# 11. Database — notification_providers

```sql
CREATE TABLE notification_providers (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,

    tenant_id BIGINT UNSIGNED NULL,
    business_entity_id BIGINT UNSIGNED NULL,

    channel_code VARCHAR(50) NOT NULL,
    provider_code VARCHAR(100) NOT NULL,
    provider_name VARCHAR(150) NOT NULL,

    credential_reference VARCHAR(255) NULL,
    configuration_json JSON NULL,

    status ENUM('active','inactive','revoked') NOT NULL DEFAULT 'active',

    created_at TIMESTAMP NULL,
    updated_at TIMESTAMP NULL,
    deleted_at TIMESTAMP NULL,

    INDEX idx_provider_scope (tenant_id, business_entity_id),
    INDEX idx_provider_channel (channel_code, status)
);
```

Contoh provider:

```text
smtp
sendgrid
twilio
whatsapp_cloud_api
fonnte
firebase
custom_webhook
```

---

# 12. Database — notification_templates

```sql
CREATE TABLE notification_templates (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,

    code VARCHAR(150) NOT NULL UNIQUE,
    name VARCHAR(150) NOT NULL,

    channel_code VARCHAR(50) NOT NULL,
    domain_code VARCHAR(100) NULL,

    status ENUM('draft','active','inactive','deprecated') NOT NULL DEFAULT 'draft',

    created_at TIMESTAMP NULL,
    updated_at TIMESTAMP NULL,
    deleted_at TIMESTAMP NULL,

    INDEX idx_template_channel (channel_code, status)
);
```

---

# 13. Database — notification_template_versions

```sql
CREATE TABLE notification_template_versions (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,

    notification_template_id BIGINT UNSIGNED NOT NULL,

    version_number INT NOT NULL,

    subject_template TEXT NULL,
    body_template TEXT NOT NULL,

    locale VARCHAR(20) NULL,
    variables_schema JSON NULL,

    status ENUM('draft','active','deprecated') NOT NULL DEFAULT 'draft',

    created_by BIGINT UNSIGNED NULL,
    approved_by BIGINT UNSIGNED NULL,
    approved_at DATETIME NULL,

    created_at TIMESTAMP NULL,
    updated_at TIMESTAMP NULL,

    UNIQUE KEY uq_template_version (notification_template_id, version_number),
    INDEX idx_template_version_status (status)
);
```

---

# 14. Database — notification_recipients

```sql
CREATE TABLE notification_recipients (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,

    recipient_type ENUM('user','role','team','department','external','patient','customer','service_account') NOT NULL,
    recipient_id BIGINT UNSIGNED NULL,

    recipient_name VARCHAR(150) NULL,
    recipient_address VARCHAR(255) NULL,

    channel_code VARCHAR(50) NOT NULL,

    created_at TIMESTAMP NULL,
    updated_at TIMESTAMP NULL,

    INDEX idx_recipient_type (recipient_type, recipient_id),
    INDEX idx_recipient_channel (channel_code)
);
```

---

# 15. Database — notification_messages

```sql
CREATE TABLE notification_messages (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,

    tenant_id BIGINT UNSIGNED NULL,
    organization_id BIGINT UNSIGNED NULL,
    business_entity_id BIGINT UNSIGNED NULL,
    branch_id BIGINT UNSIGNED NULL,
    department_id BIGINT UNSIGNED NULL,
    service_id BIGINT UNSIGNED NULL,
    team_id BIGINT UNSIGNED NULL,

    event_code VARCHAR(150) NULL,
    template_code VARCHAR(150) NULL,

    resource_type VARCHAR(100) NULL,
    resource_id BIGINT UNSIGNED NULL,

    title VARCHAR(255) NULL,
    summary TEXT NULL,
    payload JSON NULL,

    priority ENUM('low','normal','high','critical') NOT NULL DEFAULT 'normal',

    status ENUM('created','queued','sent','partial','failed','cancelled') NOT NULL DEFAULT 'created',

    correlation_id VARCHAR(100) NULL,

    created_by BIGINT UNSIGNED NULL,
    created_at TIMESTAMP NULL,
    updated_at TIMESTAMP NULL,

    INDEX idx_notification_scope (tenant_id, business_entity_id),
    INDEX idx_notification_resource (resource_type, resource_id),
    INDEX idx_notification_status (status),
    INDEX idx_notification_event (event_code)
);
```

---

# 16. Database — notification_deliveries

```sql
CREATE TABLE notification_deliveries (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,

    notification_message_id BIGINT UNSIGNED NOT NULL,

    channel_code VARCHAR(50) NOT NULL,
    provider_code VARCHAR(100) NULL,

    recipient_type VARCHAR(50) NOT NULL,
    recipient_id BIGINT UNSIGNED NULL,
    recipient_address VARCHAR(255) NULL,

    subject TEXT NULL,
    body TEXT NULL,

    status ENUM('queued','sending','sent','failed','cancelled','skipped') NOT NULL DEFAULT 'queued',

    attempts INT NOT NULL DEFAULT 0,
    max_attempts INT NOT NULL DEFAULT 3,

    scheduled_at DATETIME NULL,
    sent_at DATETIME NULL,
    failed_at DATETIME NULL,

    provider_message_id VARCHAR(255) NULL,
    failure_reason TEXT NULL,

    correlation_id VARCHAR(100) NULL,

    created_at TIMESTAMP NULL,
    updated_at TIMESTAMP NULL,

    INDEX idx_delivery_message (notification_message_id),
    INDEX idx_delivery_status (status, scheduled_at),
    INDEX idx_delivery_recipient (recipient_type, recipient_id),
    INDEX idx_delivery_channel (channel_code)
);
```

---

# 17. Database — notification_preferences

```sql
CREATE TABLE notification_preferences (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,

    user_id BIGINT UNSIGNED NOT NULL,

    event_code VARCHAR(150) NULL,
    channel_code VARCHAR(50) NOT NULL,

    enabled TINYINT(1) NOT NULL DEFAULT 1,

    created_at TIMESTAMP NULL,
    updated_at TIMESTAMP NULL,

    UNIQUE KEY uq_notification_preference (user_id, event_code, channel_code)
);
```

Catatan:

Security notification tertentu tidak boleh dimatikan user.

---

# 18. Database — notification_subscriptions

```sql
CREATE TABLE notification_subscriptions (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,

    subscriber_type ENUM('user','role','team','department','external') NOT NULL,
    subscriber_id BIGINT UNSIGNED NULL,

    event_code VARCHAR(150) NOT NULL,

    channel_code VARCHAR(50) NOT NULL,

    status ENUM('active','inactive') NOT NULL DEFAULT 'active',

    created_at TIMESTAMP NULL,
    updated_at TIMESTAMP NULL,

    INDEX idx_subscription_event (event_code),
    INDEX idx_subscription_subscriber (subscriber_type, subscriber_id)
);
```

---

# 19. Database — notification_failures

```sql
CREATE TABLE notification_failures (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,

    notification_delivery_id BIGINT UNSIGNED NOT NULL,

    attempt_number INT NOT NULL,
    failure_code VARCHAR(100) NULL,
    failure_message TEXT NULL,
    provider_response JSON NULL,

    failed_at DATETIME NOT NULL,

    created_at TIMESTAMP NULL,

    INDEX idx_notification_failure_delivery (notification_delivery_id),
    INDEX idx_notification_failure_failed_at (failed_at)
);
```

---

# 20. Notification Service Interface

```php
interface NotificationServiceInterface
{
    public function notifyEvent(
        string $eventCode,
        array $recipients,
        array $payload,
        ?ScopeContext $scope = null,
        ?string $correlationId = null
    ): NotificationMessage;

    public function sendMessage(
        NotificationMessage $message
    ): void;
}
```

---

# 21. Channel Provider Interface

```php
interface NotificationChannelProviderInterface
{
    public function send(NotificationDelivery $delivery): NotificationProviderResult;
}
```

Provider implementasi:

```text
EmailProvider
SmsProvider
WhatsAppProvider
PushProvider
InAppProvider
WebhookProvider
```

---

# 22. Notification Flow

```text
Domain event terjadi
→ NotificationService menerima event
→ Resolve template
→ Resolve recipients
→ Check preferences/subscriptions
→ Create notification message
→ Create deliveries
→ Queue delivery jobs
→ Provider sends message
→ Update delivery status
→ Audit
```

---

# 23. Recipient Resolution

Recipient dapat berasal dari:

```text
specific user
role
team
department
external address
patient/customer contact
dynamic resolver
```

Dynamic resolver contoh:

```text
assigned_nurse
patient_primary_contact
approval_current_level_approver
department_manager
```

---

# 24. Template Rendering

Template rendering menggunakan payload.

Contoh payload:

```json
{
  "patient_name": "Budi",
  "visit_date": "2026-07-04",
  "nurse_name": "Siti"
}
```

Template:

```text
Halo {{patient_name}}, kunjungan homecare dijadwalkan pada {{visit_date}}.
```

Detail template engine dibuat di SSOT-NOTIFY-02.

---

# 25. Retry Policy

Kegagalan pengiriman dapat di-retry.

Strategi:

```text
fixed delay
exponential backoff
max attempts
dead letter
```

Default:

```text
max_attempts = 3
```

---

# 26. Priority

Prioritas:

```text
critical
high
normal
low
```

Contoh critical:

```text
security alert
break-glass notification
integration failure critical
```

---

# 27. Scheduling

Notification dapat dikirim:

```text
immediate
scheduled
delayed
recurring reminder
```

Scheduler & Job Engine menjalankan scheduled notification.

---

# 28. In-App Notification

In-app notification disimpan agar dapat dibaca user.

Status:

```text
unread
read
archived
```

---

# 29. Email Notification

Email digunakan untuk:

- reset password;
- approval;
- report;
- formal notification.

Email harus mendukung:

```text
subject
body
attachment
cc/bcc policy
```

---

# 30. WhatsApp Notification

WhatsApp digunakan untuk:

- reminder;
- appointment;
- homecare;
- patient/customer communication.

Harus memperhatikan:

- consent;
- template provider;
- rate limit;
- opt-out policy.

---

# 31. SMS Notification

SMS sebaiknya fallback untuk:

- OTP;
- urgent notification;
- reminder pendek.

Jangan kirim PHI/PII sensitif lewat SMS.

---

# 32. Push Notification

Push digunakan untuk mobile.

Payload harus ringkas dan tidak memuat data sensitif berlebihan.

---

# 33. Webhook Notification

Webhook digunakan untuk sistem eksternal.

Harus mendukung:

```text
signature
timestamp
retry
delivery log
provider response
```

---

# 34. Security Notification

Security notification tertentu wajib dan tidak boleh dimatikan.

Contoh:

```text
password changed
MFA disabled
API key created
login from new device
break-glass started
```

---

# 35. Healthcare Privacy Rule

Untuk healthcare:

- jangan kirim isi EMR detail di channel tidak aman;
- gunakan pesan ringkas;
- arahkan user login untuk melihat detail;
- patient communication harus mengikuti consent.

Contoh aman:

```text
Anda memiliki jadwal kunjungan baru. Silakan buka aplikasi untuk detail.
```

Hindari:

```text
Luka diabetes Anda di kaki kanan memburuk...
```

---

# 36. Consent & Preference

Notifikasi tertentu membutuhkan consent:

```text
marketing
patient reminder via WhatsApp
SMS non-keamanan
```

Security notification dan legal notification dapat diwajibkan sesuai kebijakan.

---

# 37. Audit Integration

Event audit:

```text
notification.message.created
notification.delivery.queued
notification.delivery.sent
notification.delivery.failed
notification.delivery.cancelled
notification.preference.updated
notification.subscription.created
notification.webhook.sent
notification.webhook.failed
```

Audit menyimpan:

```text
event_code
channel_code
recipient_type
recipient_id
resource_type
resource_id
status
correlation_id
scope_snapshot
```

---

# 38. Workflow Integration

Workflow memicu notifikasi saat:

```text
task assigned
approval requested
approval approved
approval rejected
SLA breach
workflow completed
```

---

# 39. Scheduler Integration

Scheduler mengirim:

```text
reminder
retry failed delivery
digest
scheduled report
expiry warning
```

---

# 40. IAM Integration

IAM memakai notification untuk:

```text
invitation
password reset
MFA alert
new device login
account locked
```

---

# 41. API/Webhook Integration

Webhook notification menggunakan API client/service account.

Harus mengikuti:

```text
API Key Architecture
Audit
Rate limit
Signature
Retry
```

---

# 42. Monitoring

Pantau:

```text
delivery success rate
failed deliveries
provider latency
queue backlog
retry count
critical notification failed
webhook failure rate
```

---

# 43. Anti-pattern

Hindari:

```text
send email langsung dari controller
isi pesan hardcoded
notifikasi tanpa audit
notifikasi PHI lengkap via WhatsApp/SMS
retry tanpa batas
secret provider di kode
provider response tidak disimpan
semua notifikasi bisa dimatikan user
```

---

# 44. UAT Scenario

## Scenario 1 — Workflow Task Assigned

```text
Given workflow task assigned ke user
When event task.assigned terjadi
Then in-app notification dibuat
And email dikirim jika preference aktif
And audit tercatat
```

## Scenario 2 — WhatsApp Reminder

```text
Given pasien consent WhatsApp aktif
When jadwal homecare H-1
Then WhatsApp reminder dikirim
And delivery status sent/failed tercatat
```

## Scenario 3 — Security Notification

```text
Given password user berubah
When event auth.password.changed terjadi
Then security notification dikirim
And user tidak bisa menonaktifkan event tersebut
```

## Scenario 4 — Failed Delivery Retry

```text
Given provider email gagal
When delivery failed
Then sistem retry sesuai policy
And failure log tercatat
```

## Scenario 5 — Webhook Signature

```text
Given webhook dikirim ke partner
When request dikirim
Then signature header tersedia
And delivery log tercatat
```

---

# 45. Definition of Done

Notification Framework dianggap siap bila:

- mendukung multi-channel;
- provider abstraction tersedia;
- template versioning tersedia;
- recipient resolver tersedia;
- preference/subscription tersedia;
- retry policy tersedia;
- delivery log tersedia;
- audit tersedia;
- workflow integration tersedia;
- scheduler integration tersedia;
- IAM integration tersedia;
- healthcare privacy rule diterapkan;
- webhook signature tersedia;
- monitoring tersedia.
