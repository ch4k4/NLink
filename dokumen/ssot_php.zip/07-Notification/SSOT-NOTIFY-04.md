# SSOT-NOTIFY-04 — Notification Delivery, Retry & Failure Governance

## Status Dokumen

| Item | Nilai |
|---|---|
| Kode | SSOT-NOTIFY-04 |
| Judul | Notification Delivery, Retry & Failure Governance |
| Versi | 1.0 |
| Status | Draft Architecture |
| Domain | Platform Kernel |
| Kategori | Notification Reliability, Delivery Operations & Failure Governance |
| Cakupan | Delivery Lifecycle, Provider Routing, Retry, Fallback, Dead-Letter, Suppression, Status Tracking, Reconciliation |
| Bergantung pada | SSOT-GOV-01, SSOT-GOV-04, SSOT-GOV-05, SSOT-AUDIT-01, SSOT-INTEGRATION-02, SSOT-INTEGRATION-04, SSOT-NOTIFY-01, SSOT-NOTIFY-02, SSOT-NOTIFY-03, SSOT-OBS-01, SSOT-TEST-01 |
| Target Stack | PHP 8.1+, Queue/Event-ready, Email/SMS/Push Provider-compatible |
| Target Evolusi | Intelligent Provider Routing, Delivery Optimization, Adaptive Retry, Multi-Channel Reliability Platform |

# 1. Executive Summary

SSOT-NOTIFY-04 menetapkan governance resmi untuk delivery lifecycle, provider routing, retry, fallback, dead-letter, failure handling, suppression, status tracking, reconciliation, dan recovery notifikasi.

Dokumen ini mengatur:

- notification delivery states;
- provider selection;
- provider health;
- retry policy;
- fallback;
- timeout;
- idempotency;
- duplicate suppression;
- provider status callbacks;
- bounce handling;
- complaint handling;
- invalid destination handling;
- dead-letter;
- poison notifications;
- throttling;
- quiet hours integration;
- delivery receipts;
- status reconciliation;
- incident handling;
- audit;
- metrics;
- database direction;
- API direction;
- SDK contracts;
- UAT;
- Definition of Done;
- implementation roadmap.

Tujuan akhirnya adalah memastikan setiap notifikasi:

- diproses satu kali secara logis;
- memiliki delivery status;
- menggunakan provider yang sehat;
- tidak retry tanpa batas;
- dapat fallback secara aman;
- tidak dikirim ke destination invalid;
- tidak dikirim ulang secara duplikat;
- dapat direkonsiliasi;
- dapat diaudit.

# 2. Objectives

Framework harus:

- menyediakan canonical delivery lifecycle;
- mendukung multi-provider routing;
- mendukung bounded retry;
- mendukung provider fallback;
- mengendalikan duplicate delivery;
- menyediakan dead-letter;
- menangani bounce/complaint;
- menyediakan receipt reconciliation;
- mendukung throttling;
- menyediakan observability.

# 3. Core Principles

```text
Every Notification Has a Delivery State
Retries Must Be Bounded
Fallback Must Preserve Idempotency
Provider Health Must Influence Routing
Duplicate Delivery Must Be Prevented
Invalid Destinations Must Be Suppressed
Complaints Must Stop Future Delivery
Dead-Letter Requires Ownership
Delivery Receipts Must Be Reconciled
Every Delivery Attempt Must Be Auditable
```

# 4. Scope

Berlaku untuk:

```text
Email
SMS
Push Notification
WhatsApp/Chat Provider
In-App Notification
Voice Call
Webhook Notification
Batch Notification
Transactional Notification
Scheduled Notification
```

# 5. Non-Scope

Dokumen ini tidak menetapkan:

- consent and communication preference policy;
- template content governance;
- campaign marketing strategy;
- provider commercial selection;
- business event semantics.

# 6. Delivery Lifecycle States

```text
CREATED
QUEUED
ROUTING
SENDING
ACCEPTED
DELIVERED
READ
FAILED_RETRYABLE
FAILED_FINAL
BOUNCED
COMPLAINED
SUPPRESSED
EXPIRED
CANCELLED
DEAD_LETTERED
```

# 7. Delivery Attempt States

```text
PENDING
IN_PROGRESS
ACCEPTED_BY_PROVIDER
REJECTED_BY_PROVIDER
TIMEOUT
FAILED
SUCCEEDED
UNKNOWN
```

# 8. Notification Identity

Minimum:

```text
notification_id
tenant_id
channel
recipient
template
event
priority
idempotency_key
status
created_at
expires_at
```

# 9. Delivery Identity

Minimum:

```text
delivery_id
notification_id
provider
attempt_number
provider_message_id
status
started_at
completed_at
```

# 10. Idempotency

Logical notification must have stable idempotency key.

Recommended scope:

```text
tenant
business_event
recipient
channel
template_version
```

# 11. Duplicate Suppression

Suppress duplicates within configured deduplication window.

# 12. Duplicate Exceptions

Repeat notifications may be allowed when business event version changes or reminder sequence requires it.

# 13. Provider Registry

Every provider must declare:

- channels;
- environment;
- tenant availability;
- credentials;
- health;
- rate limits;
- supported receipts;
- supported regions;
- priority;
- cost tier;
- fallback eligibility.

# 14. Provider Status

```text
ACTIVE
DEGRADED
UNHEALTHY
SUSPENDED
RETIRED
```

# 15. Provider Routing

Routing inputs:

- channel;
- tenant;
- region;
- provider health;
- destination;
- priority;
- cost policy;
- data residency;
- feature support;
- rate limit;
- fallback policy.

# 16. Routing Outcomes

```text
PRIMARY
SECONDARY
FALLBACK
DEFER
REJECT
```

# 17. Provider Health

Health includes:

- connectivity;
- authentication;
- acceptance rate;
- delivery rate;
- latency;
- bounce rate;
- callback health;
- quota.

# 18. Retry Eligibility

Retryable:

```text
temporary provider error
network timeout
rate limit
provider unavailable
temporary queue failure
```

Non-retryable:

```text
invalid destination
invalid template
blocked recipient
complaint
hard bounce
unsupported channel
authorization failure
```

# 19. Retry Policy

Minimum:

```text
max_attempts
initial_delay
backoff
jitter
max_delay
deadline
retryable_codes
fallback_after
```

# 20. Retry Deadline

Retry must stop after notification expiry or business deadline.

# 21. Fallback

Fallback may switch provider or channel.

# 22. Provider Fallback

Must preserve:

- notification identity;
- idempotency;
- recipient;
- content version;
- audit;
- suppression state.

# 23. Channel Fallback

Example:

```text
push → SMS
email → SMS
SMS → voice
```

Requires explicit policy and communication preference compatibility.

# 24. Fallback Restrictions

Do not fallback to a channel that:

- lacks consent;
- violates quiet hours;
- has invalid destination;
- changes confidentiality level;
- cannot represent required content safely.

# 25. Timeout

Define:

- queue timeout;
- provider connect timeout;
- send timeout;
- receipt timeout;
- total delivery deadline.

# 26. Provider Acceptance

Accepted by provider does not equal delivered.

# 27. Delivery Receipt

Possible:

```text
ACCEPTED
DELIVERED
READ
FAILED
BOUNCED
COMPLAINED
EXPIRED
UNKNOWN
```

# 28. Receipt Correlation

Use:

- provider message ID;
- delivery ID;
- recipient hash;
- timestamp;
- event reference.

# 29. Unknown Receipt

Unknown provider message IDs must be quarantined and investigated.

# 30. Out-of-Order Receipts

Status transitions must be monotonic or policy-controlled.

# 31. Status Precedence

Example:

```text
READ > DELIVERED > ACCEPTED
COMPLAINED and HARD_BOUNCED are terminal
```

# 32. Bounce Handling

Bounce types:

```text
HARD
SOFT
TRANSIENT
POLICY
UNKNOWN
```

# 33. Hard Bounce

Hard bounce should suppress destination.

# 34. Soft Bounce

Soft bounce may retry within bounded policy.

# 35. Complaint Handling

Complaint must immediately suppress future non-essential delivery to destination according to policy.

# 36. Invalid Destination

Invalid email, phone, token, or account should be marked and suppressed.

# 37. Push Token Lifecycle

Invalid/expired push tokens must be removed or disabled.

# 38. SMS Destination Validation

Use canonical phone format and country rules.

# 39. Email Destination Validation

Syntax validation alone is insufficient; use delivery outcomes for reputation.

# 40. Suppression Registry

Reasons:

```text
HARD_BOUNCE
COMPLAINT
INVALID_DESTINATION
MANUAL_BLOCK
SECURITY_BLOCK
PROVIDER_BLOCK
EXPIRED_TOKEN
POLICY_BLOCK
```

# 41. Suppression Scope

```text
recipient
destination
channel
tenant
provider
global
```

# 42. Suppression Override

Requires permission, reason, expiry, and audit.

# 43. Dead-Letter

Notification enters dead-letter when automatic delivery cannot continue.

# 44. Dead-Letter Reasons

```text
MAX_ATTEMPTS
NO_PROVIDER_AVAILABLE
INVALID_TEMPLATE
UNKNOWN_PROVIDER_STATE
RECEIPT_CORRELATION_FAILED
POISON_NOTIFICATION
CONFIGURATION_ERROR
```

# 45. Dead-Letter States

```text
OPEN
TRIAGED
RETRY_APPROVED
REPLAYING
RESOLVED
DISCARDED
ESCALATED
```

# 46. Poison Notification

Repeatedly failing notification must not block queue partition.

# 47. Dead-Letter Replay

Requires:

- root cause resolved;
- destination still valid;
- content still relevant;
- expiry not passed;
- consent/preferences still valid;
- idempotency preserved.

# 48. Priority

```text
CRITICAL
HIGH
NORMAL
LOW
BULK
```

# 49. Priority Queues

Critical notifications should use isolated capacity.

# 50. Throttling

Apply by:

- tenant;
- recipient;
- channel;
- provider;
- template;
- campaign;
- time window.

# 51. Recipient Flood Protection

Prevent excessive messages to one recipient.

# 52. Provider Quota

Track quota and proactively route/defer.

# 53. Backpressure

When providers degrade:

- reduce concurrency;
- delay low-priority;
- open circuit;
- use fallback;
- preserve critical capacity.

# 54. Quiet Hours

Delivery engine must evaluate quiet hours before send.

# 55. Quiet Hours Exception

Critical/emergency notifications may bypass only by explicit policy.

# 56. Expiry

Expired notifications must not be sent.

# 57. Cancellation

Cancellation supported before provider acceptance where possible.

# 58. Batch Delivery

Batch should track per-recipient status.

# 59. Partial Batch Failure

Failed recipients must not cause successful recipients to resend.

# 60. In-App Delivery

In-app notifications may have delivered/read state without external provider.

# 61. Provider Callback Security

Use INTEGRATION-03 signature and replay controls.

# 62. Provider Credential Governance

Use INTEGRATION-02.

# 63. Reliability Governance

Use INTEGRATION-04 for retry, idempotency, and circuit patterns.

# 64. Delivery Reconciliation

Compare:

- internal delivery status;
- provider status;
- callback receipts;
- provider reports;
- suppression registry;
- queue state.

# 65. Reconciliation Findings

```text
ACCEPTED_WITHOUT_RECEIPT
DELIVERED_STATUS_MISMATCH
UNKNOWN_PROVIDER_MESSAGE
DUPLICATE_DELIVERY
SUPPRESSED_DESTINATION_SENT
EXPIRED_NOTIFICATION_SENT
MISSING_ATTEMPT
CALLBACK_NOT_APPLIED
PROVIDER_REPORT_MISMATCH
```

# 66. Reconciliation Schedule

- real-time callback;
- hourly for critical;
- daily for general;
- provider statement-based;
- post-incident.

# 67. Auto-Remediation

Examples:

- apply late receipt;
- suppress hard-bounced destination;
- mark expired token;
- repair missing provider ID;
- retry safe unresolved delivery.

# 68. Manual Remediation

Required for:

- complaint disputes;
- unknown provider transaction;
- duplicate critical message;
- privacy-sensitive misdelivery;
- high-volume provider mismatch.

# 69. Incident Handling

```text
Detect
→ Pause/Suppress
→ Preserve Evidence
→ Identify Recipients
→ Reconcile Provider State
→ Recover
→ Notify Stakeholders
→ Review
```

# 70. Misdelivery

Potential misdelivery requires security/privacy incident process.

# 71. Delivery Evidence

Preserve:

- notification ID;
- delivery ID;
- attempt ID;
- provider;
- provider message ID;
- recipient reference;
- content/template version;
- status;
- timestamps;
- receipt;
- correlation ID.

# 72. Content Privacy

Do not store full sensitive rendered content in delivery logs unless required and protected.

# 73. Audit Events

```text
NOTIFICATION_CREATED
NOTIFICATION_QUEUED
NOTIFICATION_ROUTED
NOTIFICATION_SEND_ATTEMPTED
NOTIFICATION_PROVIDER_ACCEPTED
NOTIFICATION_DELIVERED
NOTIFICATION_READ
NOTIFICATION_BOUNCED
NOTIFICATION_COMPLAINED
NOTIFICATION_SUPPRESSED
NOTIFICATION_DEAD_LETTERED
NOTIFICATION_RECONCILIATION_FAILED
```

# 74. Metrics

```text
notification_created_total
notification_delivery_attempt_total
notification_delivery_success_total
notification_delivery_failure_total
notification_retry_total
notification_fallback_total
notification_bounce_total
notification_complaint_total
notification_suppressed_total
notification_dead_letter_total
notification_delivery_latency_seconds
```

# 75. KPIs

```text
Unbounded notification retries = 0
Delivery to hard-bounced destination = 0
Delivery after complaint suppression = 0
Expired notifications sent = 0
Critical delivery without provider status tracking = 0
Dead-letter items without owner = 0
Duplicate critical notifications = 0
```

# 76. KRIs

```text
Bounce-rate growth
Complaint-rate growth
Provider failure concentration
Fallback frequency
Dead-letter growth
Delivery latency growth
Receipt mismatch rate
Recipient flood incidents
```

# 77. Database Direction

Potential tables:

```text
notification_deliveries
notification_delivery_attempts
notification_provider_routes
notification_provider_health
notification_delivery_receipts
notification_suppressions
notification_dead_letters
notification_reconciliation_runs
notification_reconciliation_findings
```

# 78. Table: notification_deliveries

```sql
CREATE TABLE notification_deliveries (
    id CHAR(26) NOT NULL,
    notification_id CHAR(26) NOT NULL,
    tenant_id CHAR(26) NOT NULL,
    channel VARCHAR(30) NOT NULL,
    recipient_reference VARCHAR(255) NOT NULL,
    idempotency_key VARCHAR(255) NOT NULL,
    priority VARCHAR(20) NOT NULL,
    status VARCHAR(30) NOT NULL,
    expires_at DATETIME(6) NULL,
    created_at DATETIME(6) NOT NULL,
    completed_at DATETIME(6) NULL,

    PRIMARY KEY (id),
    UNIQUE KEY uq_notification_delivery_idempotency (
        tenant_id,
        channel,
        idempotency_key
    ),
    KEY idx_notification_delivery_status (
        status,
        priority,
        created_at
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

# 79. Table: notification_delivery_attempts

```sql
CREATE TABLE notification_delivery_attempts (
    id CHAR(26) NOT NULL,
    delivery_id CHAR(26) NOT NULL,
    provider_code VARCHAR(180) NOT NULL,
    attempt_number INT NOT NULL,
    attempt_id VARCHAR(180) NOT NULL,
    provider_message_id VARCHAR(255) NULL,
    status VARCHAR(30) NOT NULL,
    error_code VARCHAR(180) NULL,
    started_at DATETIME(6) NOT NULL,
    completed_at DATETIME(6) NULL,

    PRIMARY KEY (id),
    UNIQUE KEY uq_notification_attempt (
        delivery_id,
        attempt_number
    ),
    KEY idx_notification_attempt_provider (
        provider_code,
        status,
        started_at
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

# 80. Table: notification_suppressions

```sql
CREATE TABLE notification_suppressions (
    id CHAR(26) NOT NULL,
    tenant_id CHAR(26) NULL,
    channel VARCHAR(30) NOT NULL,
    destination_hash CHAR(64) NOT NULL,
    suppression_scope VARCHAR(30) NOT NULL,
    reason_code VARCHAR(180) NOT NULL,
    status VARCHAR(30) NOT NULL,
    valid_from DATETIME(6) NOT NULL,
    valid_to DATETIME(6) NULL,

    PRIMARY KEY (id),
    KEY idx_notification_suppression_lookup (
        channel,
        destination_hash,
        status
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

# 81. Table: notification_delivery_receipts

```sql
CREATE TABLE notification_delivery_receipts (
    id CHAR(26) NOT NULL,
    provider_code VARCHAR(180) NOT NULL,
    provider_message_id VARCHAR(255) NOT NULL,
    receipt_type VARCHAR(40) NOT NULL,
    receipt_status VARCHAR(30) NOT NULL,
    received_at DATETIME(6) NOT NULL,
    payload_hash CHAR(64) NULL,
    applied_at DATETIME(6) NULL,

    PRIMARY KEY (id),
    UNIQUE KEY uq_notification_receipt (
        provider_code,
        provider_message_id,
        receipt_type,
        received_at
    ),
    KEY idx_notification_receipt_status (
        receipt_status,
        received_at
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

# 82. API Direction

```text
GET  /api/internal/v1/notifications/deliveries
GET  /api/internal/v1/notifications/deliveries/{deliveryId}
POST /api/internal/v1/notifications/deliveries/{deliveryId}/retry
POST /api/internal/v1/notifications/deliveries/{deliveryId}/cancel
GET  /api/internal/v1/notifications/dead-letters
POST /api/internal/v1/notifications/dead-letters/{id}/replay
GET  /api/internal/v1/notifications/suppressions
POST /api/internal/v1/notifications/suppressions
POST /api/internal/v1/notifications/reconciliation/runs
```

# 83. SDK Contracts

```text
NotificationDeliveryServiceInterface
NotificationProviderRouterInterface
NotificationRetryPolicyInterface
NotificationSuppressionServiceInterface
NotificationReceiptServiceInterface
NotificationDeadLetterServiceInterface
NotificationReconciliationServiceInterface
```

# 84. Delivery Service Contract

```php
interface NotificationDeliveryServiceInterface
{
    public function deliver(
        NotificationDeliveryRequest $request
    ): NotificationDeliveryResult;
}
```

# 85. Provider Router Contract

```php
interface NotificationProviderRouterInterface
{
    public function route(
        NotificationRoutingRequest $request
    ): NotificationProviderRoute;
}
```

# 86. Suppression Contract

```php
interface NotificationSuppressionServiceInterface
{
    public function evaluate(
        NotificationSuppressionRequest $request
    ): NotificationSuppressionDecision;
}
```

# 87. Error Codes

```text
NOTIFICATION_DELIVERY_NOT_FOUND
NOTIFICATION_DESTINATION_INVALID
NOTIFICATION_DESTINATION_SUPPRESSED
NOTIFICATION_PROVIDER_UNAVAILABLE
NOTIFICATION_PROVIDER_RATE_LIMITED
NOTIFICATION_RETRY_LIMIT_EXCEEDED
NOTIFICATION_EXPIRED
NOTIFICATION_DUPLICATE
NOTIFICATION_RECEIPT_UNKNOWN
NOTIFICATION_DEAD_LETTERED
NOTIFICATION_RECONCILIATION_FAILED
```

# 88. Delivery Checklist

- [ ] Notification identity valid.
- [ ] Recipient valid.
- [ ] Preferences/consent checked.
- [ ] Suppression checked.
- [ ] Quiet hours checked.
- [ ] Idempotency key acquired.
- [ ] Provider selected.
- [ ] Expiry checked.
- [ ] Attempt audited.
- [ ] Receipt tracking configured.

# 89. Retry Checklist

- [ ] Error classified.
- [ ] Retry permitted.
- [ ] Expiry not passed.
- [ ] Idempotency preserved.
- [ ] Destination not suppressed.
- [ ] Provider health checked.
- [ ] Backoff applied.
- [ ] Fallback policy checked.
- [ ] Attempt limit enforced.
- [ ] Dead-letter path available.

# 90. UAT — Delivery Lifecycle

- [ ] Created notification queues.
- [ ] Provider route resolves.
- [ ] Provider accepts notification.
- [ ] Delivery receipt updates status.
- [ ] Read receipt updates status.
- [ ] Expired notification does not send.
- [ ] Cancellation before send works.
- [ ] Out-of-order receipt handled.
- [ ] Audit complete.

# 91. UAT — Retry & Fallback

- [ ] Transient provider error retries.
- [ ] Permanent invalid destination does not retry.
- [ ] Backoff and jitter work.
- [ ] Maximum attempts enforced.
- [ ] Provider fallback preserves idempotency.
- [ ] Channel fallback checks consent.
- [ ] Fallback does not bypass quiet hours.
- [ ] Exhausted delivery enters dead-letter.
- [ ] Metrics updated.

# 92. UAT — Suppression

- [ ] Hard bounce suppresses email.
- [ ] Complaint suppresses future delivery.
- [ ] Invalid push token disabled.
- [ ] Manual block works.
- [ ] Tenant-specific suppression isolated.
- [ ] Global security suppression applies.
- [ ] Override requires permission and reason.
- [ ] Expired suppression releases correctly.
- [ ] Suppressed destination never sends.

# 93. UAT — Provider Routing

- [ ] Healthy primary selected.
- [ ] Degraded provider deprioritized.
- [ ] Unhealthy provider excluded.
- [ ] Tenant provider restriction respected.
- [ ] Region/residency respected.
- [ ] Quota exhaustion routes safely.
- [ ] Critical queue retains capacity.
- [ ] No provider produces controlled failure.
- [ ] Route decision audited.

# 94. UAT — Receipts & Reconciliation

- [ ] Valid provider receipt correlates.
- [ ] Unknown provider message quarantined.
- [ ] Duplicate receipt idempotent.
- [ ] Late receipt updates status safely.
- [ ] Internal/provider mismatch detected.
- [ ] Suppressed destination sent detected.
- [ ] Expired notification sent detected.
- [ ] Missing attempt detected.
- [ ] Auto-remediation applies safe late receipt.
- [ ] Critical mismatch opens incident.

# 95. UAT — Batch & Flood Protection

- [ ] Per-recipient batch status works.
- [ ] One failure does not resend successes.
- [ ] Recipient flood limit enforced.
- [ ] Tenant throttle enforced.
- [ ] Provider throttle enforced.
- [ ] Critical messages use isolated queue.
- [ ] Low-priority messages deferred during degradation.
- [ ] Backpressure recovers.
- [ ] Queue metrics available.

# 96. UAT — Dead-Letter

- [ ] Max attempts creates dead-letter.
- [ ] Poison notification isolated.
- [ ] Owner assigned.
- [ ] Replay requires current relevance.
- [ ] Replay rechecks suppression and preference.
- [ ] Replay preserves idempotency.
- [ ] Discard requires reason.
- [ ] High-risk replay requires approval.
- [ ] Evidence retained.

# 97. Definition of Done — SSOT-NOTIFY-04

SSOT-NOTIFY-04 dianggap selesai bila:

- [ ] delivery lifecycle tersedia;
- [ ] attempt lifecycle tersedia;
- [ ] idempotency and deduplication tersedia;
- [ ] provider registry/routing tersedia;
- [ ] provider health tersedia;
- [ ] retry/timeout policies tersedia;
- [ ] provider/channel fallback tersedia;
- [ ] receipt correlation tersedia;
- [ ] bounce/complaint handling tersedia;
- [ ] suppression registry tersedia;
- [ ] dead-letter governance tersedia;
- [ ] priority/throttling/backpressure tersedia;
- [ ] quiet hours integration tersedia;
- [ ] batch partial failure handling tersedia;
- [ ] reconciliation tersedia;
- [ ] incident/evidence tersedia;
- [ ] audit and metrics tersedia;
- [ ] database direction tersedia;
- [ ] API direction tersedia;
- [ ] SDK contracts tersedia;
- [ ] UAT and DoD tersedia.

# 98. Implementation Roadmap

## Phase 1 — Delivery Foundation

- delivery registry;
- attempt registry;
- idempotency;
- provider adapters;
- routing;
- status model.

## Phase 2 — Retry & Provider Resilience

- retry policies;
- provider health;
- fallback;
- timeouts;
- circuit integration;
- backpressure.

## Phase 3 — Receipt & Suppression

- receipt callbacks;
- bounce handling;
- complaint handling;
- suppression registry;
- invalid destination lifecycle;
- push-token lifecycle.

## Phase 4 — Dead-Letter & Reconciliation

- dead-letter;
- controlled replay;
- provider report import;
- reconciliation engine;
- incident workflow;
- remediation.

## Phase 5 — Intelligent Delivery Platform

- adaptive routing;
- delivery optimization;
- cost/latency policies;
- anomaly detection;
- continuous reconciliation;
- reliability dashboard.

# 99. Initial Implementation Backlog

```text
NOTIFY04-001 Delivery Registry
NOTIFY04-002 Delivery Attempt Registry
NOTIFY04-003 Idempotency & Deduplication
NOTIFY04-004 Provider Router
NOTIFY04-005 Provider Health Monitor
NOTIFY04-006 Retry Policy Engine
NOTIFY04-007 Fallback Orchestrator
NOTIFY04-008 Receipt Processor
NOTIFY04-009 Bounce Handler
NOTIFY04-010 Complaint Handler
NOTIFY04-011 Suppression Registry
NOTIFY04-012 Dead-Letter Service
NOTIFY04-013 Throttling & Flood Protection
NOTIFY04-014 Reconciliation Engine
NOTIFY04-015 Incident Workflow
NOTIFY04-016 Notification Reliability Dashboard
```

# 100. Approval Gate

Dokumen dapat menjadi Approved setelah:

- Notification Architecture review;
- Integration Architecture review;
- Operations/SRE review;
- Security and Privacy review;
- Messaging/Provider review;
- Audit/Compliance review;
- Quality Engineering review;
- UAT review.

# 101. Closing Statement

Notification reliability bukan sekadar mengirim ulang saat gagal.

Setiap delivery harus memiliki identity, provider route, bounded retry, receipt, suppression check, dan reconciliation.

Fallback tidak boleh menggandakan pesan.

Dead-letter tidak boleh menjadi tempat pembuangan tanpa owner.
