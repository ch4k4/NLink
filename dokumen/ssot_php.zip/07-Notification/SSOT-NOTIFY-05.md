# SSOT-NOTIFY-05 — Consent, Preference & Communication Compliance

## Status Dokumen

| Item | Nilai |
|---|---|
| Kode | SSOT-NOTIFY-05 |
| Judul | Consent, Preference & Communication Compliance |
| Versi | 1.0 |
| Status | Draft Architecture |
| Domain | Platform Kernel |
| Kategori | Consent Governance, Communication Preference & Compliance |
| Cakupan | Consent, Opt-In/Opt-Out, Channel Preference, Quiet Hours, Frequency Caps, Lawful Basis, Proof of Consent, Suppression Compliance |
| Bergantung pada | SSOT-GOV-01, SSOT-GOV-04, SSOT-GOV-05, SSOT-DATA-06, SSOT-AUDIT-01, SSOT-IAM-07, SSOT-NOTIFY-01, SSOT-NOTIFY-02, SSOT-NOTIFY-03, SSOT-NOTIFY-04, SSOT-TEST-01 |
| Target Stack | PHP 8.1+, PDO, MySQL 8/MariaDB, Queue/Event-ready |
| Target Evolusi | Consent Policy Engine, Preference Center, Jurisdiction-Aware Communication Rules, Continuous Compliance Reconciliation |

# 1. Executive Summary

SSOT-NOTIFY-05 menetapkan governance resmi untuk consent, lawful basis, opt-in, opt-out, channel preference, quiet hours, frequency caps, suppression compliance, proof of consent, dan communication eligibility.

Dokumen ini memastikan setiap komunikasi memiliki basis yang valid, menghormati consent dan preference, tidak dikirim setelah opt-out, tidak melewati quiet hours tanpa dasar, tidak melebihi frequency cap, memisahkan transactional dan promotional communication, menyimpan proof of consent, dan dapat direkonsiliasi serta diaudit.

# 2. Core Principles

```text
No Communication Without a Valid Basis
Consent Must Be Specific
Opt-Out Must Be Easy
Preferences Must Be Honored
Transactional and Promotional Messages Are Different
Quiet Hours Must Be Enforced
Frequency Must Be Controlled
Consent Evidence Must Be Verifiable
Suppression Must Override Routing
Every Compliance Decision Must Be Auditable
```

# 3. Communication Categories

```text
TRANSACTIONAL
SERVICE
REMINDER
SECURITY
MARKETING
PROMOTIONAL
RESEARCH
EMERGENCY
REGULATORY
```

# 4. Lawful Basis

```text
CONSENT
CONTRACT
LEGAL_OBLIGATION
VITAL_INTEREST
LEGITIMATE_INTEREST
PUBLIC_TASK
EXPLICIT_BUSINESS_RULE
```

Lawful basis ditentukan per category, purpose, jurisdiction, channel, dan recipient context.

# 5. Consent Model

Consent types:

```text
GENERAL
CHANNEL_SPECIFIC
PURPOSE_SPECIFIC
PRODUCT_SPECIFIC
CAMPAIGN_SPECIFIC
RESEARCH_SPECIFIC
SENSITIVE_DATA_EXPLICIT
```

Consent status:

```text
PENDING
GRANTED
DENIED
WITHDRAWN
EXPIRED
SUSPENDED
UNKNOWN
```

Consent minimal mengikat subject, tenant, purpose, channel, category, jurisdiction, dan policy version.

# 6. Proof of Consent

Minimum evidence:

```text
subject_id
tenant_id
consent_type
purpose
channel
status
captured_at
capture_source
policy_version
evidence_reference
actor
```

Consent harus informed, specific, unambiguous, revocable, dan traceable.

# 7. Consent Lifecycle

```text
REQUESTED
PENDING_VERIFICATION
GRANTED
RENEWAL_DUE
WITHDRAWN
EXPIRED
REVOKED
```

Renewal membuat evidence baru dan tidak menimpa history. Withdrawal berlaku untuk future communication, memicu suppression, mempertahankan evidence historis, serta dipropagasi ke provider dan downstream systems.

# 8. Opt-In

Supported models:

```text
SINGLE_OPT_IN
DOUBLE_OPT_IN
ADMIN_VERIFIED
CONTRACTUAL_OPT_IN
```

Double opt-in flow:

```text
Preference Requested
→ Verification Sent
→ Recipient Confirms
→ Consent Activated
→ Evidence Stored
```

# 9. Opt-Out

Scopes:

```text
GLOBAL
CHANNEL
CATEGORY
PURPOSE
CAMPAIGN
TENANT
```

Global opt-out menghentikan communication non-essential. Security, emergency, legal, atau essential service communication hanya dapat tetap dikirim bila lawful basis dan policy mengizinkan.

# 10. Preference Center

Harus mendukung:

- channel preferences;
- category preferences;
- language;
- timezone;
- quiet hours;
- digest mode;
- frequency preference;
- global opt-out;
- consent history;
- accessible UX.

Preference status:

```text
ENABLED
DISABLED
MUTED
DIGEST_ONLY
MANDATORY
UNAVAILABLE
```

# 11. Communication Eligibility

Sebelum pengiriman:

```text
Destination valid?
Channel allowed?
Lawful basis valid?
Consent valid?
Preference enabled?
Suppression absent?
Quiet hours allowed?
Frequency cap available?
Jurisdiction rule satisfied?
```

Outcomes:

```text
ALLOW
DEFER
BLOCK
ALLOW_WITH_MASKING
ALLOW_ESSENTIAL_ONLY
```

# 12. Transactional vs Promotional

Transactional messages tidak boleh disisipi promotional content yang mengubah legal basis. Mixed-purpose messages harus dipisah atau mengikuti basis paling ketat.

# 13. Quiet Hours

Quiet hours dapat ditentukan oleh recipient timezone, tenant policy, jurisdiction, channel, dan category.

Outcomes:

```text
SEND_NOW
DEFER
BLOCK
ALLOW_EXCEPTION
```

Exception hanya untuk security incident, emergency, vital interest, critical service interruption, explicit preference, atau mandatory regulatory notice.

# 14. Frequency Caps

Dimensions:

```text
per recipient
per channel
per category
per campaign
per tenant
per hour/day/week/month
```

Outcomes:

```text
ALLOW
DEFER
DIGEST
BLOCK
ESCALATE
```

# 15. Suppression Priority

```text
SECURITY_BLOCK
LEGAL_BLOCK
GLOBAL_OPT_OUT
COMPLAINT
HARD_BOUNCE
CHANNEL_OPT_OUT
CATEGORY_OPT_OUT
QUIET_HOURS
FREQUENCY_CAP
```

Suppression harus dipropagasi ke delivery engine, campaign system, provider lists, integrations, caches, dan scheduled jobs.

# 16. Unsubscribe

Promotional messages harus menyediakan usable unsubscribe mechanism.

Unsubscribe token harus opaque, signed, recipient-bound, purpose-bound, non-enumerable, dan memiliki validity policy.

# 17. Scheduled and Batch Messages

Eligibility harus dievaluasi ulang pada saat send. Audience eligibility tidak boleh hanya diperiksa saat campaign dibuat. Batch evaluation dilakukan per recipient.

# 18. Imported Consent

Imported consent membutuhkan source, capture date, policy version, evidence, import authority, tenant binding, dan quality validation. Unknown consent tidak dianggap granted.

# 19. Guardian Consent

Bila berlaku, model harus menyimpan subject, guardian, authority, relationship, expiry, dan transition rule.

# 20. Jurisdiction Policy

Policy resolution order:

```text
law/regulation
platform mandatory policy
tenant policy
recipient preference
campaign policy
provider constraints
```

Setiap decision menyimpan policy version dan jurisdiction context.

# 21. Decision Reasons

```text
CONSENT_GRANTED
CONSENT_MISSING
CONSENT_WITHDRAWN
GLOBAL_OPT_OUT
CHANNEL_DISABLED
QUIET_HOURS
FREQUENCY_CAP
ESSENTIAL_MESSAGE
JURISDICTION_BLOCK
SUPPRESSED
```

# 22. Cache Governance

Preference cache key harus mencakup tenant, subject, channel, category, dan policy version.

Invalidate on consent change, opt-out, preference change, timezone/jurisdiction change, policy publication, complaint, dan suppression.

# 23. Reconciliation

Compare:

- consent registry;
- preference center;
- suppression registry;
- provider suppression lists;
- scheduled messages;
- campaign audience;
- downstream integrations;
- policy versions.

Findings:

```text
WITHDRAWN_CONSENT_STILL_ACTIVE
GLOBAL_OPT_OUT_NOT_PROPAGATED
PROVIDER_SUPPRESSION_MISSING
SCHEDULED_MESSAGE_INELIGIBLE
CONSENT_EVIDENCE_MISSING
POLICY_VERSION_DRIFT
CHANNEL_PREFERENCE_MISMATCH
QUIET_HOURS_POLICY_DRIFT
FREQUENCY_COUNTER_DRIFT
```

# 24. Auto-Remediation

Examples:

- suppress withdrawn consent;
- cancel ineligible scheduled promotion;
- sync provider suppression;
- invalidate preference cache;
- expire old consent.

Manual remediation dibutuhkan untuk conflicting evidence, guardian disputes, jurisdiction ambiguity, legal exceptions, dan uncertain partner imports.

# 25. Audit Events

```text
CONSENT_REQUESTED
CONSENT_GRANTED
CONSENT_DENIED
CONSENT_WITHDRAWN
CONSENT_EXPIRED
PREFERENCE_CHANGED
GLOBAL_OPT_OUT_APPLIED
UNSUBSCRIBE_APPLIED
QUIET_HOURS_DEFERRED
FREQUENCY_CAP_BLOCKED
COMMUNICATION_ELIGIBILITY_DECIDED
CONSENT_RECONCILIATION_FAILED
```

# 26. Metrics

```text
consent_granted_total
consent_withdrawn_total
global_opt_out_total
preference_change_total
quiet_hours_deferred_total
frequency_cap_blocked_total
communication_eligibility_denied_total
consent_evidence_missing_total
suppression_propagation_failure_total
consent_reconciliation_failure_total
```

# 27. KPIs

```text
Promotional messages after opt-out = 0
Messages sent without valid basis = 0
Withdrawn consent not propagated beyond SLA = 0
Scheduled promotional message sent after withdrawal = 0
Consent records without evidence = 0
Quiet-hours bypass without approved exception = 0
Provider suppression drift = 0
```

# 28. Database Direction

Potential tables:

```text
communication_consents
communication_consent_events
communication_preferences
communication_preference_history
communication_quiet_hours
communication_frequency_policies
communication_frequency_counters
communication_suppressions
communication_unsubscribe_tokens
communication_eligibility_decisions
communication_reconciliation_runs
communication_reconciliation_findings
```

# 29. Table: communication_consents

```sql
CREATE TABLE communication_consents (
    id CHAR(26) NOT NULL,
    subject_id CHAR(26) NOT NULL,
    tenant_id CHAR(26) NOT NULL,
    consent_type VARCHAR(50) NOT NULL,
    purpose_code VARCHAR(180) NOT NULL,
    channel VARCHAR(30) NULL,
    category VARCHAR(50) NULL,
    lawful_basis VARCHAR(50) NOT NULL,
    status VARCHAR(30) NOT NULL,
    policy_version VARCHAR(100) NOT NULL,
    evidence_reference VARCHAR(1000) NULL,
    captured_at DATETIME(6) NOT NULL,
    expires_at DATETIME(6) NULL,
    PRIMARY KEY (id),
    KEY idx_communication_consent_lookup (
        tenant_id, subject_id, purpose_code, channel, status
    )
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
```

# 30. Table: communication_preferences

```sql
CREATE TABLE communication_preferences (
    id CHAR(26) NOT NULL,
    subject_id CHAR(26) NOT NULL,
    tenant_id CHAR(26) NOT NULL,
    channel VARCHAR(30) NOT NULL,
    category VARCHAR(50) NOT NULL,
    preference_status VARCHAR(30) NOT NULL,
    language_code VARCHAR(20) NULL,
    timezone_name VARCHAR(100) NULL,
    policy_version VARCHAR(100) NOT NULL,
    updated_at DATETIME(6) NOT NULL,
    PRIMARY KEY (id),
    UNIQUE KEY uq_communication_preference (
        tenant_id, subject_id, channel, category
    )
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
```

# 31. Table: communication_frequency_counters

```sql
CREATE TABLE communication_frequency_counters (
    id CHAR(26) NOT NULL,
    tenant_id CHAR(26) NOT NULL,
    subject_id CHAR(26) NOT NULL,
    channel VARCHAR(30) NOT NULL,
    category VARCHAR(50) NOT NULL,
    window_start DATETIME(6) NOT NULL,
    window_end DATETIME(6) NOT NULL,
    delivery_count INT NOT NULL DEFAULT 0,
    updated_at DATETIME(6) NOT NULL,
    PRIMARY KEY (id),
    UNIQUE KEY uq_communication_frequency_counter (
        tenant_id, subject_id, channel, category, window_start
    )
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
```

# 32. API Direction

```text
GET  /api/internal/v1/communications/consents
POST /api/internal/v1/communications/consents
POST /api/internal/v1/communications/consents/{id}/withdraw
GET  /api/internal/v1/communications/preferences/{subjectId}
PUT  /api/internal/v1/communications/preferences/{subjectId}
POST /api/internal/v1/communications/unsubscribe
POST /api/internal/v1/communications/eligibility/evaluate
GET  /api/internal/v1/communications/suppressions
POST /api/internal/v1/communications/reconciliation/runs
```

# 33. SDK Contracts

```text
CommunicationConsentServiceInterface
CommunicationPreferenceServiceInterface
CommunicationEligibilityServiceInterface
CommunicationQuietHoursServiceInterface
CommunicationFrequencyCapServiceInterface
CommunicationUnsubscribeServiceInterface
CommunicationComplianceReconciliationInterface
```

# 34. Eligibility Contract

```php
interface CommunicationEligibilityServiceInterface
{
    public function evaluate(
        CommunicationEligibilityRequest $request
    ): CommunicationEligibilityDecision;
}
```

# 35. Error Codes

```text
COMMUNICATION_CONSENT_REQUIRED
COMMUNICATION_CONSENT_WITHDRAWN
COMMUNICATION_CHANNEL_DISABLED
COMMUNICATION_GLOBAL_OPT_OUT
COMMUNICATION_QUIET_HOURS
COMMUNICATION_FREQUENCY_CAP
COMMUNICATION_SUPPRESSED
COMMUNICATION_JURISDICTION_BLOCK
COMMUNICATION_EVIDENCE_MISSING
COMMUNICATION_UNSUBSCRIBE_INVALID
COMMUNICATION_RECONCILIATION_FAILED
```

# 36. UAT — Consent Lifecycle

- [ ] Consent dapat diberikan.
- [ ] Evidence tersimpan.
- [ ] Consent expiry berjalan.
- [ ] Withdrawal segera berlaku.
- [ ] Withdrawal menjaga history.
- [ ] Double opt-in membutuhkan confirmation.
- [ ] Unknown consent tidak dianggap granted.
- [ ] Renewal membuat evidence baru.
- [ ] Policy version tercatat.

# 37. UAT — Preferences and Opt-Out

- [ ] Channel preference berubah.
- [ ] Category opt-out berlaku.
- [ ] Global opt-out berlaku.
- [ ] Essential message tetap mengikuti lawful basis.
- [ ] Unsubscribe token bekerja.
- [ ] Invalid token ditolak aman.
- [ ] Cache invalidated.
- [ ] Scheduled message re-evaluated.
- [ ] Audit complete.

# 38. UAT — Quiet Hours and Frequency Caps

- [ ] Recipient timezone diterapkan.
- [ ] Low-priority message deferred.
- [ ] Promotional message blocked.
- [ ] Emergency exception tervalidasi.
- [ ] Unauthorized bypass ditolak.
- [ ] Hourly/daily/category caps bekerja.
- [ ] Concurrent sends tidak melewati cap.
- [ ] Digest mode bekerja.
- [ ] Counter reset benar.

# 39. UAT — Suppression and Reconciliation

- [ ] Withdrawal membuat suppression.
- [ ] Global opt-out sampai ke delivery engine.
- [ ] Provider suppression sync bekerja.
- [ ] Scheduled promotional message dibatalkan.
- [ ] Missing consent evidence terdeteksi.
- [ ] Policy drift terdeteksi.
- [ ] Frequency counter drift terdeteksi.
- [ ] Safe remediation bekerja.
- [ ] Critical finding membuka case.

# 40. Definition of Done — SSOT-NOTIFY-05

SSOT-NOTIFY-05 dianggap selesai bila:

- [ ] categories dan lawful basis tersedia;
- [ ] consent type/status tersedia;
- [ ] proof-of-consent tersedia;
- [ ] lifecycle dan withdrawal tersedia;
- [ ] opt-in/opt-out tersedia;
- [ ] preference center tersedia;
- [ ] transactional/promotional separation tersedia;
- [ ] quiet-hours governance tersedia;
- [ ] frequency caps/digest tersedia;
- [ ] suppression priority tersedia;
- [ ] unsubscribe tersedia;
- [ ] scheduled/batch re-evaluation tersedia;
- [ ] imported/guardian consent tersedia;
- [ ] jurisdiction resolution tersedia;
- [ ] reconciliation tersedia;
- [ ] audit/metrics tersedia;
- [ ] database/API/SDK direction tersedia;
- [ ] UAT dan DoD tersedia.

# 41. Implementation Roadmap

## Phase 1 — Consent Foundation

- consent registry;
- consent events;
- lawful basis;
- evidence;
- grant/withdraw APIs.

## Phase 2 — Preference Center

- channel/category preferences;
- global opt-out;
- timezone/language;
- unsubscribe;
- cache invalidation.

## Phase 3 — Eligibility Controls

- eligibility engine;
- quiet hours;
- frequency caps;
- suppression integration;
- scheduled-message recheck.

## Phase 4 — Jurisdiction & Compliance

- jurisdiction rules;
- guardian consent;
- imported consent;
- policy versioning;
- compliance reports.

## Phase 5 — Continuous Compliance

- provider suppression reconciliation;
- automated drift remediation;
- fatigue analytics;
- adaptive frequency policy;
- compliance dashboard.

# 42. Initial Implementation Backlog

```text
NOTIFY05-001 Consent Registry
NOTIFY05-002 Consent Event History
NOTIFY05-003 Proof of Consent
NOTIFY05-004 Preference Center
NOTIFY05-005 Global Opt-Out
NOTIFY05-006 Unsubscribe Service
NOTIFY05-007 Eligibility Engine
NOTIFY05-008 Quiet Hours Service
NOTIFY05-009 Frequency Cap Service
NOTIFY05-010 Suppression Propagation
NOTIFY05-011 Scheduled Message Recheck
NOTIFY05-012 Jurisdiction Policy Resolver
NOTIFY05-013 Imported Consent Validator
NOTIFY05-014 Compliance Reconciliation
NOTIFY05-015 Compliance Evidence Report
NOTIFY05-016 Communication Compliance Dashboard
```

# 43. Approval Gate

Dokumen dapat menjadi Approved setelah Notification Architecture, Data Privacy, Legal/Compliance, Security, Tenant Governance, Customer Experience, Audit, Quality Engineering, dan UAT review.

# 44. Closing Statement

Komunikasi tidak boleh dikirim hanya karena alamat tujuan tersedia.

Setiap message harus memiliki basis yang valid, menghormati consent, preference, suppression, quiet hours, dan frequency caps.

Opt-out harus segera berlaku. Consent evidence harus dapat dibuktikan. Compliance harus dievaluasi kembali pada saat pengiriman.
