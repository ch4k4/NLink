
# SSOT-NOTIFY-03 — Notification Preferences & Subscription

## Status Dokumen

| Item | Nilai |
|---|---|
| Kode | SSOT-NOTIFY-03 |
| Domain | Platform Kernel / Notification |
| Bergantung pada | SSOT-NOTIFY-01, SSOT-NOTIFY-02, SSOT-IAM, SSOT-AUDIT |

# 1. Tujuan

Mengatur bagaimana pengguna menerima notifikasi berdasarkan preferensi, consent, subscription, dan kebijakan organisasi tanpa mengurangi notifikasi yang bersifat wajib.

# 2. Prinsip

- Preference bersifat per pengguna.
- Subscription dapat berbasis user, role, team, atau department.
- Security notification tertentu wajib dikirim.
- Mendukung multi-tenant.
- Semua perubahan diaudit.

# 3. Konsep

```text
Preference = kanal yang dipilih pengguna
Subscription = event yang ingin diterima
Policy = aturan organisasi
Consent = izin pengguna
```

# 4. Jenis Preferensi

- In-app
- Email
- SMS
- WhatsApp
- Push
- Webhook (service account)

# 5. Quiet Hours

Pengguna dapat menentukan:

```text
22:00–06:00
```

Kecuali:
- OTP
- Security alert
- Break-glass
- Incident kritis

# 6. Mandatory Notification

Tidak dapat dinonaktifkan:

- Password berubah
- Login dari perangkat baru
- MFA berubah
- API Key dibuat/dihapus
- Break-glass
- Kejadian keamanan kritis

# 7. Consent

Contoh consent:

- WhatsApp reminder
- SMS reminder
- Marketing
- Newsletter

Consent harus dapat dicabut.

# 8. Digest

Mendukung:

- harian
- mingguan
- bulanan

Agar beberapa event dapat digabung menjadi satu notifikasi.

# 9. Rate Limiting

Batasi pengiriman berulang.

Contoh:

```text
maksimal 5 reminder/jam
```

# 10. Database

## notification_preferences

```sql
CREATE TABLE notification_preferences (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 user_id BIGINT UNSIGNED NOT NULL,
 channel_code VARCHAR(50) NOT NULL,
 event_code VARCHAR(150) NULL,
 enabled TINYINT(1) NOT NULL DEFAULT 1,
 quiet_hours_enabled TINYINT(1) DEFAULT 0,
 quiet_start TIME NULL,
 quiet_end TIME NULL,
 created_at TIMESTAMP NULL,
 updated_at TIMESTAMP NULL,
 UNIQUE KEY uq_pref(user_id,channel_code,event_code)
);
```

## notification_subscriptions

```sql
CREATE TABLE notification_subscriptions (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 subscriber_type ENUM('user','role','team','department') NOT NULL,
 subscriber_id BIGINT UNSIGNED NOT NULL,
 event_code VARCHAR(150) NOT NULL,
 channel_code VARCHAR(50) NOT NULL,
 status ENUM('active','inactive') DEFAULT 'active',
 created_at TIMESTAMP NULL,
 updated_at TIMESTAMP NULL
);
```

## notification_consents

```sql
CREATE TABLE notification_consents (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 user_id BIGINT UNSIGNED NOT NULL,
 consent_code VARCHAR(100) NOT NULL,
 granted TINYINT(1) NOT NULL,
 granted_at DATETIME NULL,
 revoked_at DATETIME NULL,
 created_at TIMESTAMP NULL,
 updated_at TIMESTAMP NULL,
 UNIQUE KEY uq_consent(user_id,consent_code)
);
```

# 11. Resolution Flow

```text
Event
→ Check mandatory policy
→ Resolve subscription
→ Resolve consent
→ Resolve preference
→ Check quiet hours
→ Apply rate limit
→ Queue delivery
```

# 12. Priority Override

Critical notification mengabaikan:

- quiet hours
- digest
- marketing preference

Jika sesuai kebijakan keamanan.

# 13. Audit

Event:

```text
notification.preference.updated
notification.subscription.created
notification.subscription.removed
notification.consent.granted
notification.consent.revoked
notification.quiet_hours.updated
```

# 14. Healthcare Rule

Pasien hanya menerima reminder melalui kanal yang telah disetujui.

PHI sensitif tidak dikirim melalui SMS/WhatsApp kecuali kebijakan dan consent mengizinkan.

# 15. UAT

- Preference tersimpan.
- Quiet hours bekerja.
- Mandatory notification tetap terkirim.
- Consent memblokir marketing.
- Digest berjalan sesuai jadwal.
- Audit tercatat.

# 16. Anti-pattern

Hindari:

- semua notifikasi dapat dimatikan
- tanpa consent
- tanpa rate limiting
- quiet hours untuk OTP/security alert
- preference tanpa audit

# 17. Definition of Done

- Preference tersedia.
- Subscription tersedia.
- Consent tersedia.
- Quiet hours tersedia.
- Digest tersedia.
- Rate limiting tersedia.
- Mandatory notification diterapkan.
- Audit lengkap.
