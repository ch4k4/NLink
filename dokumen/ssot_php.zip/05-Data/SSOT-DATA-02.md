
# SSOT-DATA-02 — Migration & Schema Management

## Status Dokumen

| Item | Nilai |
|---|---|
| Kode | SSOT-DATA-02 |
| Domain | Platform Kernel |
| Bergantung pada | SSOT-DATA-01 |

# 1. Tujuan

Dokumen ini menetapkan standar pengelolaan schema database dan migration agar perubahan struktur database aman, dapat ditelusuri, mudah di-deploy, dan mendukung continuous delivery.

# 2. Prinsip

- Migration-first
- Source of truth berada di repository
- Forward-only sebagai pendekatan utama
- Rollback disiapkan bila memungkinkan
- Zero-downtime migration untuk production
- Setiap perubahan schema dapat diaudit

# 3. Struktur Direktori

```text
database/
  migrations/
  seeds/
  views/
  functions/
  procedures/
```

# 4. Penamaan Migration

Format:

```text
YYYYMMDD_HHMMSS_deskripsi_perubahan
```

Contoh:

```text
20260703_101500_create_patients_table
20260705_083000_add_status_to_users
```

# 5. Aturan Migration

- Satu migration = satu tujuan perubahan.
- Tidak menggabungkan perubahan yang tidak berkaitan.
- Migration harus idempotent bila framework mendukung.
- Tidak mengubah data produksi secara diam-diam.

# 6. Expand / Contract Pattern

## Expand
- Tambah tabel
- Tambah kolom nullable
- Tambah index
- Tambah constraint yang aman

## Contract
- Hapus kolom lama
- Hapus tabel lama
- Ubah constraint lama

Contract hanya dilakukan setelah aplikasi tidak lagi menggunakan struktur lama.

# 7. Zero-Downtime Guideline

Hindari:

- rename kolom langsung
- drop kolom yang masih dipakai
- perubahan tipe data destruktif saat jam operasional

Gunakan migrasi bertahap:
1. tambah kolom baru
2. dual write/backfill
3. ubah aplikasi
4. hapus kolom lama

# 8. Data Migration

Pisahkan:
- schema migration
- data migration

Data migration harus:
- dapat dipantau
- memiliki log
- dapat diulang dengan aman bila memungkinkan

# 9. Rollback

Rollback harus tersedia untuk perubahan yang memungkinkan.

Jika rollback berisiko kehilangan data:
- dokumentasikan
- gunakan backup sebelum deploy

# 10. Seed Management

Kategori:
- reference seed
- configuration seed
- demo seed
- test seed

Reference seed tidak boleh bergantung pada demo seed.

# 11. Versioning

Semua migration memiliki urutan eksekusi yang deterministik.

Jangan mengubah migration yang sudah dipakai di production.

Perubahan baru dibuat sebagai migration baru.

# 12. Index Management

Setiap index baru harus memiliki alasan:

- performa query
- uniqueness
- foreign key

Review index secara berkala untuk menghindari duplikasi.

# 13. View, Function, Procedure

Objek database juga harus dikelola melalui migration.

Tidak boleh dibuat manual di production.

# 14. Deployment Flow

```text
Backup
→ Jalankan migration
→ Jalankan data migration
→ Jalankan seed (bila diperlukan)
→ Verifikasi
→ Deploy aplikasi
```

# 15. Validation Checklist

- Migration berhasil pada database kosong.
- Migration berhasil pada database berisi data.
- Rollback diuji (bila tersedia).
- Index tervalidasi.
- Foreign key tervalidasi.

# 16. Anti-pattern

Hindari:

- edit migration lama
- menjalankan SQL manual di production
- drop table tanpa backup
- menggabungkan puluhan perubahan dalam satu migration
- seed demo pada production

# 17. UAT

- Database baru dapat dibangun hanya dari migration.
- Semua migration berjalan berurutan.
- Deployment dari versi lama ke baru berhasil.
- Rollback mengikuti prosedur yang ditetapkan.

# 18. Definition of Done

- Semua perubahan schema melalui migration.
- Repository menjadi single source of truth.
- Mendukung deployment bertahap.
- Mendukung zero-downtime bila diperlukan.
- Memiliki strategi rollback dan data migration.
