
# SSOT-DATA-04 — Data Lifecycle

## Status Dokumen

| Item | Nilai |
|---|---|
| Kode | SSOT-DATA-04 |
| Domain | Platform Kernel / Data |
| Bergantung pada | SSOT-DATA-01, SSOT-DATA-02, SSOT-DATA-03, SSOT-AUDIT |

# 1. Tujuan

Menetapkan standar siklus hidup data sejak dibuat hingga diarsipkan atau dimusnahkan sesuai kebijakan organisasi dan regulasi.

# 2. Tahapan Lifecycle

```text
Create
→ Read
→ Update
→ Archive
→ Restore
→ Legal Hold
→ Purge (bila diizinkan)
```

# 3. Prinsip

- Data memiliki pemilik (owner).
- Data memiliki klasifikasi.
- Data memiliki masa retensi.
- Penghapusan mengikuti kebijakan dan regulasi.
- Semua aksi penting diaudit.

# 4. Klasifikasi Data

```text
Public
Internal
Confidential
Restricted
PII
PHI
Financial
Credential
```

Setiap tabel wajib memiliki klasifikasi yang terdokumentasi.

# 5. Data Ownership

Setiap domain memiliki owner, misalnya:
- Patient → Pelayanan Klinis
- Billing → Keuangan
- IAM → Tim Platform

Owner menyetujui perubahan retensi dan pemusnahan.

# 6. Active Data

Data aktif digunakan transaksi harian dan berada pada database operasional.

# 7. Archived Data

Data lama dipindahkan ke media arsip tanpa mengubah integritas.

Aturan:
- read-only
- tetap dapat dicari bila diizinkan
- tetap memiliki audit

# 8. Restore

Restore harus:
- melalui permission khusus
- diaudit
- memulihkan metadata penting

# 9. Soft Delete

Default untuk data bisnis:
- deleted_at
- deleted_by

Tidak menghapus data fisik.

# 10. Purge

Purge hanya dilakukan bila:
- masa retensi berakhir
- tidak ada legal hold
- diizinkan regulasi

Purge wajib diaudit.

# 11. Legal Hold

Jika data terkait:
- investigasi
- sengketa hukum
- audit regulator

maka:
- archive tetap boleh
- purge dilarang

# 12. Retention Policy

Retention ditentukan berdasarkan:
- jenis data
- regulasi
- kebutuhan bisnis

Policy disimpan terpusat dan dapat berbeda antar domain.

# 13. Data Anonymization

Untuk analitik atau dataset uji:
- hapus identitas langsung
- masking PII/PHI
- gunakan pseudonym bila diperlukan

# 14. Data Disposal

Media penyimpanan yang tidak dipakai lagi harus dimusnahkan sesuai kebijakan keamanan.

# 15. Archive Job

Archive dilakukan oleh background job yang:
- idempotent
- dapat dijadwalkan
- menghasilkan audit
- memiliki laporan hasil

# 16. Monitoring

Pantau:
- data mendekati akhir retensi
- archive gagal
- restore gagal
- purge gagal
- legal hold aktif

# 17. UAT

- Soft delete bekerja.
- Archive memindahkan data sesuai kebijakan.
- Restore mengembalikan data.
- Purge menolak data dengan legal hold.
- Semua aktivitas tercatat di Audit Trail.

# 18. Anti-pattern

Hindari:
- hard delete transaksi
- purge tanpa audit
- archive tanpa verifikasi
- legal hold diabaikan
- data uji memakai PII asli

# 19. Definition of Done

- Lifecycle terdokumentasi.
- Retention tersedia.
- Archive, restore, purge memiliki prosedur.
- Legal hold didukung.
- Seluruh aktivitas lifecycle diaudit.
