
# SSOT-DATA-03 — Repository & Data Access Layer

## Status Dokumen

| Item | Nilai |
|---|---|
| Kode | SSOT-DATA-03 |
| Nama | Repository & Data Access Layer |
| Versi | 1.0 |
| Status | Draft Architecture |
| Domain | Platform Kernel / Data |
| Bergantung pada | SSOT-DATA-01, SSOT-DATA-02, SSOT-SCOPE, SSOT-RBAC, SSOT-AUDIT |

---

# 1. Tujuan

Dokumen ini menetapkan standar akses data untuk seluruh modul platform.

Tujuannya:

- mencegah query liar tanpa scope;
- memastikan semua transaksi database konsisten;
- memisahkan business logic dari query SQL;
- mendukung audit trail;
- mendukung soft delete;
- mendukung pagination;
- mendukung caching;
- mendukung transaction handling;
- memudahkan refactor database tanpa merusak controller/service.

---

# 2. Prinsip Dasar

## 2.1 Controller tidak boleh query langsung

Tidak boleh:

```php
$db->query("SELECT * FROM patients");
```

Controller harus memanggil service atau repository.

## 2.2 Repository bertanggung jawab atas akses data

Repository menangani:

- query;
- insert;
- update;
- soft delete;
- scope filter;
- pagination;
- locking;
- query optimization.

## 2.3 Service bertanggung jawab atas business logic

Service menangani:

- validasi proses;
- workflow;
- transaction boundary;
- panggilan antar repository;
- audit event;
- domain rule.

## 2.4 Scope filter wajib

Semua repository transaksi wajib scope-aware.

## 2.5 Audit-aware

Aksi create/update/delete penting harus menghasilkan audit.

---

# 3. Layering Standar

```text
Controller
→ Application Service
→ Domain Service
→ Repository
→ Database
```

Jangan:

```text
Controller
→ Database
```

---

# 4. Jenis Repository

```text
BaseRepository
ScopedRepository
ReadRepository
WriteRepository
AuditAwareRepository
SoftDeleteRepository
CachedRepository
```

---

# 5. BaseRepository

BaseRepository menyediakan fungsi umum:

```text
findById
findAll
insert
update
delete
exists
count
paginate
```

Namun untuk tabel transaksi, fungsi ini harus dibungkus scope.

---

# 6. ScopedRepository

ScopedRepository wajib digunakan oleh tabel yang memiliki scope.

Scope minimum:

```text
tenant_id
organization_id
business_entity_id
```

Opsional:

```text
branch_id
division_id
department_id
service_id
team_id
workgroup_id
assignment_id
```

Contoh query:

```sql
SELECT *
FROM patients
WHERE tenant_id = :tenant_id
AND business_entity_id = :business_entity_id
```

---

# 7. Scope Filter Rule

Jika active scope lebih detail, filter harus mengikuti detail tersebut.

Contoh:

```text
active_scope = team
```

Maka query dapat memakai:

```sql
tenant_id
organization_id
business_entity_id
department_id
service_id
team_id
```

---

# 8. Insert Rule

Insert tidak boleh menerima scope dari request user.

Salah:

```php
$data['tenant_id'] = $_POST['tenant_id'];
```

Benar:

```php
$data['tenant_id'] = $scope->tenantId;
$data['business_entity_id'] = $scope->businessEntityId;
```

---

# 9. Update Rule

Update wajib memakai scope filter.

```sql
UPDATE patients
SET full_name = :full_name
WHERE id = :id
AND tenant_id = :tenant_id
AND business_entity_id = :business_entity_id
```

Jika affected row = 0:

```text
Data tidak ditemukan atau Anda tidak memiliki akses.
```

---

# 10. Delete Rule

Gunakan soft delete untuk data bisnis.

```sql
UPDATE patients
SET deleted_at = NOW(),
    deleted_by = :user_id
WHERE id = :id
AND tenant_id = :tenant_id
```

Hard delete hanya untuk:

- temporary table;
- queue transient;
- cache table;
- data test;
- data yang secara eksplisit boleh dihapus permanen.

---

# 11. SoftDeleteRepository

Fungsi standar:

```text
softDelete(id, reason)
restore(id)
findWithDeleted(id)
onlyDeleted()
```

Setiap soft delete harus audit-aware.

---

# 12. AuditAwareRepository

Repository tidak selalu langsung menulis audit, tetapi harus menyediakan data lama dan baru untuk AuditLogger.

Update flow:

```text
load old data
→ apply scope
→ update
→ load new data
→ create audit diff
```

---

# 13. Transaction Manager

Operasi multi-tabel harus menggunakan transaction manager.

Contoh:

```text
create patient
→ create identifier
→ create encounter
→ create audit event
```

Harus atomik.

Jika salah satu gagal, rollback.

---

# 14. Unit of Work

Unit of Work dipakai saat satu business process menyentuh banyak repository.

Contoh:

```text
RegistrationService
- PatientRepository
- EncounterRepository
- BillingRepository
- AuditLogger
```

---

# 15. Query Specification

Untuk filter kompleks, gunakan specification object.

Contoh:

```text
PatientSearchSpecification
EncounterFilterSpecification
AuditLogFilterSpecification
```

Manfaat:

- filter reusable;
- query tidak tersebar di controller;
- mudah diuji.

---

# 16. Pagination Standard

Semua list besar wajib pagination.

Parameter standar:

```text
page
per_page
sort
direction
filters
```

Response standar:

```json
{
  "data": [],
  "meta": {
    "page": 1,
    "per_page": 20,
    "total": 100,
    "total_pages": 5
  }
}
```

---

# 17. Sorting Standard

Sorting hanya boleh pada kolom whitelist.

Tidak boleh langsung menerima nama kolom mentah dari request tanpa validasi.

---

# 18. Filtering Standard

Filter harus:

- divalidasi;
- typed;
- scope-aware;
- tidak membuka SQL injection.

Contoh filter:

```text
status
date_from
date_to
keyword
department_id
service_id
```

---

# 19. Search Standard

Pencarian keyword harus dibatasi.

Contoh:

```text
nama pasien
nomor RM
nomor invoice
nomor encounter
```

Hindari full table scan pada tabel besar.

---

# 20. Read Model

Untuk dashboard/report, boleh membuat read model atau materialized table agar query transaksi tidak terlalu berat.

Contoh:

```text
daily_patient_summary
billing_dashboard_snapshots
audit_event_daily_counts
```

---

# 21. Write Model

Write model harus menjaga konsistensi data utama.

Jangan mengorbankan integritas transaksi demi dashboard.

---

# 22. Caching Strategy

Caching boleh untuk:

- master data;
- permission;
- menu;
- configuration;
- reference data;
- dashboard ringan.

Caching tidak boleh sembarangan untuk:

- EMR aktif;
- transaksi pembayaran;
- audit event;
- data yang sangat sensitif.

---

# 23. Cache Invalidation

Cache harus invalidated saat:

```text
data updated
role changed
permission changed
scope switched
configuration changed
feature flag changed
```

---

# 24. Locking Strategy

Gunakan locking untuk proses kritis:

- pembayaran;
- refund;
- closing encounter;
- sign EMR;
- inventory adjustment;
- claim submission.

Jenis:

```text
optimistic locking
pessimistic locking
```

---

# 25. Optimistic Locking

Tambahkan kolom:

```text
version
```

Update:

```sql
UPDATE table
SET version = version + 1
WHERE id = :id
AND version = :version
```

---

# 26. Pessimistic Locking

Gunakan untuk proses finansial/kritis.

Contoh:

```sql
SELECT *
FROM invoices
WHERE id = :id
FOR UPDATE
```

---

# 27. Error Handling

Repository harus melempar exception domain/data yang jelas:

```text
RecordNotFound
ScopeDenied
DuplicateRecord
OptimisticLockFailed
ForeignKeyViolation
DatabaseUnavailable
```

Jangan bocorkan SQL mentah ke user.

---

# 28. Data Mapper vs Active Record

Platform boleh memakai framework Active Record, tetapi akses data enterprise sebaiknya tetap dibungkus repository.

Tujuannya:

- scope filter konsisten;
- audit konsisten;
- transaksi konsisten;
- mudah refactor.

---

# 29. DTO / Data Transfer Object

Repository tidak harus mengembalikan array mentah.

Gunakan DTO untuk data penting:

```text
PatientData
EncounterData
UserData
AuditEventData
```

---

# 30. Repository Interface

Setiap repository penting memiliki interface.

Contoh:

```php
interface PatientRepositoryInterface
{
    public function findById(int $id): ?PatientData;
    public function paginate(PatientFilter $filter): PaginatedResult;
    public function create(array $data): int;
    public function update(int $id, array $data): void;
    public function softDelete(int $id, string $reason): void;
}
```

---

# 31. Dependency Injection

Service menerima repository melalui constructor.

```php
final class PatientService
{
    public function __construct(
        private PatientRepositoryInterface $patients
    ) {}
}
```

---

# 32. Repository Naming

Format:

```text
{Domain}{Resource}Repository
```

Contoh:

```text
PatientRepository
EncounterRepository
AuditEventRepository
UserRepository
RoleRepository
```

---

# 33. Service Naming

Format:

```text
{Domain}{Action}Service
```

Contoh:

```text
RegisterPatientService
CloseEncounterService
AssignRoleService
CreateAuditEventService
```

---

# 34. Query Builder Policy

Jika memakai query builder:

- bind parameter;
- whitelist sort;
- apply scope;
- apply soft delete;
- apply pagination.

---

# 35. Raw SQL Policy

Raw SQL boleh untuk:

- query performa tinggi;
- report kompleks;
- migration;
- bulk operation.

Syarat:

- parameterized;
- review keamanan;
- scope filter jelas;
- documented.

---

# 36. Bulk Operation

Bulk update/delete harus sangat dibatasi.

Wajib:

- scope filter;
- permission khusus;
- audit summary;
- dry-run bila berisiko.

---

# 37. Import Data

Import harus melalui service layer.

Flow:

```text
upload file
→ validate
→ preview
→ approve
→ process batch
→ audit
```

---

# 38. Export Data

Export harus melalui permission dan audit.

Repository menyediakan data, tetapi export service menangani:

- format;
- filter;
- approval;
- audit;
- masking.

---

# 39. Multi-Database Future

Repository layer harus memungkinkan pemindahan beberapa modul ke database terpisah di masa depan.

Controller dan service tidak boleh bergantung pada detail koneksi database.

---

# 40. Tenant Isolation

Tenant isolation wajib di repository.

Tidak boleh ada query transaksi tanpa:

```text
tenant_id
```

Kecuali tabel platform-level yang memang global.

---

# 41. Healthcare-Specific Rule

Untuk modul klinis, repository harus mendukung:

- patient scope;
- encounter scope;
- assignment scope;
- read access audit;
- masking;
- clinical privilege check di service layer.

Repository tidak menentukan clinical privilege, tetapi harus menyediakan data untuk service mengecek.

---

# 42. Non-Healthcare Rule

Untuk retail/manufacturing/education, repository tetap memakai scope yang sama.

Kernel tidak boleh hardcode:

```text
hospital
clinic
patient
doctor
nurse
```

pada repository platform.

---

# 43. Testing Repository

Test wajib:

- find by id dengan scope benar;
- find by id lintas scope tertolak;
- insert otomatis memakai scope aktif;
- update lintas scope tertolak;
- soft delete mencatat deleted_at/deleted_by;
- pagination benar;
- sorting whitelist bekerja;
- transaction rollback saat gagal.

---

# 44. Anti-pattern

Hindari:

```text
query langsung di controller
SELECT *
update berdasarkan id saja
delete permanen data transaksi
scope dari request user
filter string mentah
role check di repository
business rule besar di repository
```

---

# 45. Definition of Done

Repository & Data Access Layer dianggap siap bila:

- semua modul memakai repository;
- repository transaksi scope-aware;
- insert memakai active scope;
- update/delete memakai scope filter;
- soft delete tersedia;
- pagination standar;
- sorting/filtering aman;
- transaction manager tersedia;
- audit-aware update tersedia;
- read access sensitif dapat diaudit;
- raw SQL dibatasi dan terdokumentasi;
- test repository tersedia.
