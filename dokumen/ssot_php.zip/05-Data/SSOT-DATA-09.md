# SSOT-DATA-09 — Data Lifecycle Enforcement, Archival & Secure Disposal Governance

## Status Dokumen

| Item | Nilai |
|---|---|
| Kode | SSOT-DATA-09 |
| Judul | Data Lifecycle Enforcement, Archival & Secure Disposal Governance |
| Versi | 1.0 |
| Status | Draft Architecture |
| Domain | Platform Kernel |
| Kategori | Data Lifecycle Enforcement, Archival, Disposal & Reconciliation |
| Cakupan | Lifecycle Policies, State Transitions, Archival, Deletion Propagation, Tombstones, Backup Handling, Secure Disposal, Evidence, Reconciliation |
| Bergantung pada | SSOT-GOV-01, SSOT-GOV-04, SSOT-GOV-05, SSOT-DATA-01..08, SSOT-RECORDS-01, SSOT-PRIVACY-01, SSOT-FILE-02..03, SSOT-EVENT-04..05, SSOT-AUDIT-01, SSOT-SCOPE-01, SSOT-SEC-03, SSOT-TEST-01 |
| Target Stack | PHP 8.1+, PDO, MySQL 8/MariaDB, Object Storage, Search, Analytics, Queue/Event-ready |
| Target Evolusi | Central Lifecycle Orchestrator, Policy-as-Code Retention Enforcement, Immutable Disposal Evidence, Continuous Lifecycle Assurance |

# 1. Executive Summary

SSOT-DATA-09 menetapkan governance resmi untuk mengeksekusi lifecycle data secara nyata di seluruh platform.

Dokumen ini memastikan policy retention, archival, restriction, tombstone, deletion, anonymization, dan secure disposal tidak berhenti sebagai dokumen, tetapi benar-benar diterapkan ke:

- database;
- file storage;
- search index;
- cache;
- analytics;
- event store;
- replicas;
- exports;
- backups;
- external processors.

# 2. Objectives

Framework harus:

- menyediakan lifecycle policy registry;
- menyediakan lifecycle state machine;
- menghitung eligibility;
- menjalankan archival;
- menjalankan deletion propagation;
- menangani tombstones;
- mengatur backup restoration;
- menyediakan secure disposal;
- menghasilkan evidence;
- menyediakan reconciliation.

# 3. Core Principles

```text
Lifecycle Policies Must Be Enforced
Records Rules Override Generic Deletion
Legal Hold Blocks Destruction
Privacy Requests Must Be Propagated
Deletion Must Reach Derived Copies
Archival Must Preserve Integrity
Tombstones Prevent Silent Recreation
Backups Require Re-Deletion After Restore
Disposal Must Be Verifiable
Every Lifecycle Action Must Be Reconciled
```

# 4. Scope

Berlaku untuk:

```text
Operational Databases
Master Data
Files and Attachments
Search Indexes
Caches
Analytics Datasets
Exports
Events
Replicas
Archives
Backups
External Processors
Temporary Storage
```

# 5. Lifecycle Policy Registry

Minimum:

```text
policy_code
resource_type
owner
trigger
state transitions
retention source
archival rule
disposal rule
evidence requirement
status
```

# 6. Policy Sources

```text
RECORDS_RETENTION
PRIVACY_REQUEST
BUSINESS_LIFECYCLE
SECURITY_INCIDENT
CONTRACT_TERMINATION
TENANT_OFFBOARDING
MANUAL_APPROVED
```

# 7. Lifecycle States

```text
ACTIVE
INACTIVE
RESTRICTED
FROZEN
ARCHIVE_PENDING
ARCHIVED
DISPOSITION_ELIGIBLE
DISPOSITION_PENDING
DISPOSING
DISPOSED
FAILED
ON_HOLD
```

# 8. State Machine Governance

Setiap resource type harus memiliki lifecycle state machine yang valid.

# 9. Transition Requirements

Setiap transition harus memiliki:

- source state;
- target state;
- trigger;
- preconditions;
- authorization;
- evidence;
- rollback/recovery;
- audit event.

# 10. Eligibility Calculation

Eligibility harus memperhitungkan:

- retention schedule;
- legal hold;
- privacy restriction;
- resource status;
- dependencies;
- active workflows;
- unresolved incidents;
- external processor state.

# 11. Eligibility Outcomes

```text
ELIGIBLE
NOT_YET_ELIGIBLE
BLOCKED_BY_HOLD
BLOCKED_BY_DEPENDENCY
BLOCKED_BY_POLICY
REVIEW_REQUIRED
```

# 12. Lifecycle Trigger Types

```text
TIME_BASED
EVENT_BASED
STATUS_BASED
REQUEST_BASED
CONTRACT_BASED
TENANT_BASED
MANUAL_APPROVED
```

# 13. Time-Based Trigger

Examples:

- creation + duration;
- closure + duration;
- last activity + duration;
- contract end + duration;
- superseded + duration.

# 14. Event-Based Trigger

Examples:

- patient discharged;
- account closed;
- contract terminated;
- privacy request approved;
- tenant offboarded.

# 15. Trigger Resolution

Trigger resolution must be deterministic and versioned.

# 16. Policy Versioning

Published lifecycle policies must be immutable and effective-dated.

# 17. Policy Precedence

Recommended:

```text
Legal hold
→ Records retention
→ Security/privacy restriction
→ Contractual rule
→ Business lifecycle
→ Default disposition
```

# 18. Records Integration

RECORDS-01 determines whether destruction is legally and operationally allowed.

# 19. Privacy Integration

PRIVACY-01 may request deletion, restriction, anonymization, or portability-related cleanup.

# 20. Scope Integration

Every lifecycle action must respect tenant and resource scope.

# 21. Archival

Archival moves inactive data to approved archive while preserving required accessibility and integrity.

# 22. Archival Preconditions

- resource inactive/closed;
- no active write requirement;
- archival policy exists;
- archive target available;
- metadata complete;
- checksum generated;
- access model defined.

# 23. Archive Package

Minimum:

```text
resource identifiers
resource type
tenant/scope
policy version
payload/data
metadata
checksums
classification
retention status
hold status
lineage
```

# 24. Archive Targets

```text
ARCHIVE_DATABASE
OBJECT_STORAGE
WORM_STORAGE
COLD_STORAGE
SEALED_PACKAGE
EXTERNAL_ARCHIVE_APPROVED
```

# 25. Archive Integrity

Must support:

- checksums;
- encryption;
- immutable manifests;
- periodic verification;
- retrieval tests;
- migration planning.

# 26. Archive Access

Access must be:

- authorized;
- purpose-bound;
- audited;
- read-only where possible;
- time-limited where required.

# 27. Archive Retrieval

Retrieval must preserve source, version, and chain of custody.

# 28. Archive Restore

Restore must not silently reactivate expired or restricted data.

# 29. Archive Migration

Required when storage format or medium becomes obsolete.

# 30. Active-to-Archive Transition

Must be atomic or recoverable.

# 31. Deletion Propagation

Deletion must reach all in-scope copies.

# 32. Propagation Targets

```text
PRIMARY_DATABASE
READ_REPLICA
FILE_STORAGE
SEARCH_INDEX
CACHE
ANALYTICS
EXPORT
EVENT_PROJECTION
TEMP_STORAGE
EXTERNAL_PROCESSOR
```

# 33. Authoritative Deletion

Authoritative source deletion is followed by downstream propagation.

# 34. Derived Copies

Derived data must either:

- be deleted;
- be anonymized;
- be recomputed;
- be tombstoned;
- remain under approved exception.

# 35. Search Index Deletion

Must remove searchable traces and cached snippets.

# 36. Cache Deletion

Must invalidate all keys that can expose deleted or restricted data.

# 37. Analytics Deletion

Must address:

- raw zones;
- staging;
- marts;
- extracts;
- snapshots;
- dashboards;
- cached results.

# 38. Event Store Handling

Events may be immutable; policy must define:

- payload redaction;
- encryption-key destruction;
- access restriction;
- compensating tombstone;
- retention exception.

# 39. Export Handling

Exports must have expiry and deletion evidence.

# 40. Temporary Data

Temporary storage must have short TTL and automatic cleanup.

# 41. External Processor Deletion

Requires:

- request dispatch;
- acknowledgment;
- completion evidence;
- due date;
- escalation;
- reconciliation.

# 42. Deletion Orchestration

Flow:

```text
Eligibility
→ Hold Check
→ Dependency Check
→ Plan
→ Execute Authoritative Action
→ Propagate
→ Verify
→ Record Evidence
→ Reconcile
```

# 43. Tombstone

Tombstone preserves minimal state to prevent silent recreation.

# 44. Tombstone Content

May include:

```text
canonical identifier
resource type
disposition reason
disposed_at
policy version
non-sensitive hash
recreation block flag
```

# 45. Tombstone Restrictions

Tombstone must not retain unnecessary personal data.

# 46. Recreation Prevention

Inbound sync/import must check tombstones where policy requires.

# 47. Anonymization

Anonymization may substitute deletion only if irreversible and approved.

# 48. Pseudonymization

Pseudonymization is not deletion.

# 49. Cryptographic Erasure

Allowed where encryption keys are uniquely scoped and destruction is verifiable.

# 50. Physical Destruction

Applies to media and approved storage hardware processes.

# 51. Database Deletion

Must consider:

- foreign keys;
- cascades;
- audit requirements;
- tombstones;
- orphan prevention;
- transaction boundaries.

# 52. Soft Delete

Soft delete is a lifecycle state, not final disposal.

# 53. Hard Delete

Hard delete requires eligibility, authorization, and evidence.

# 54. Cascade Governance

Cascade behavior must be explicit and tested.

# 55. Dependency Graph

Lifecycle engine must know dependent resources.

# 56. Dependency Types

```text
PARENT_CHILD
REFERENCE
DERIVED
PROJECTION
ATTACHMENT
EXPORT
CACHE
INDEX
PROCESSOR_COPY
```

# 57. Blocking Dependencies

Some dependencies must be resolved before disposal.

# 58. Non-Blocking Dependencies

Some derived copies can be cleaned asynchronously.

# 59. Lifecycle Job

Every lifecycle job must have:

- job ID;
- tenant/scope;
- policy version;
- candidate set;
- execution state;
- checkpoint;
- evidence;
- retry policy.

# 60. Job States

```text
PLANNED
APPROVED
RUNNING
PARTIAL
COMPLETED
FAILED
CANCELLED
RECONCILING
```

# 61. Batch Safety

Large lifecycle jobs require:

- dry run;
- bounded batches;
- checkpoints;
- idempotency;
- partial-failure isolation;
- pause/resume;
- rollback where feasible.

# 62. Idempotency

Repeated lifecycle execution must not duplicate destructive effects.

# 63. Concurrency

Lifecycle actions must use resource version or locking where needed.

# 64. Race Prevention

Prevent:

- update during disposal;
- restore during deletion;
- new sync after tombstone;
- archive and delete collision;
- hold applied after eligibility but before destruction.

# 65. Final Hold Check

Destructive action must re-check legal hold immediately before execution.

# 66. Two-Phase Disposition

Recommended:

```text
Mark disposition pending
→ Cooling/review period
→ Final hold check
→ Execute destruction
```

# 67. Cooling Period

Provides opportunity for cancellation or hold intervention.

# 68. Approval Model

High-risk disposal requires maker-checker.

# 69. Emergency Stop

Global and tenant-level kill switch must stop lifecycle jobs.

# 70. Kill Switch Conditions

- legal hold incident;
- policy defect;
- cross-tenant risk;
- deletion anomaly;
- unexpected volume;
- evidence failure.

# 71. Disposal Evidence

Minimum:

```text
resource identifiers
policy version
eligibility result
hold checks
approvals
execution steps
target systems
verification
exceptions
timestamps
actor/job
```

# 72. Evidence Integrity

Evidence must be immutable, checksummed, access-controlled, and retained.

# 73. Partial Failure

Partial failure must identify exact completed and incomplete targets.

# 74. Recovery

Recovery may:

- retry failed target;
- restore from checkpoint;
- reopen lifecycle job;
- quarantine affected resource;
- escalate incident.

# 75. Failed Disposal

Failed disposal must not be marked completed.

# 76. Verification

Verification methods:

```text
NOT_FOUND
TOMBSTONE_PRESENT
HASH_ABSENT
INDEX_ABSENT
PROCESSOR_CONFIRMED
ARCHIVE_CHECKSUM_VALID
KEY_DESTROYED
```

# 77. Negative Verification

A delete success response alone is insufficient.

# 78. Backup Handling

Backups may retain disposed data until rotation if documented.

# 79. Restore Re-Deletion

Any restore must replay tombstones and deletion instructions.

# 80. Backup Catalog

Must track:

- backup ID;
- coverage period;
- systems;
- retention;
- encryption;
- restore date;
- deletion replay status.

# 81. Backup Isolation

Disposed data in backup must not return to normal processing.

# 82. Replica Handling

Replicas and standby systems must receive lifecycle changes.

# 83. Offline Media

Offline media requires rotation/destruction policy and evidence.

# 84. Tenant Offboarding

Lifecycle enforcement must support:

- export;
- retention check;
- legal hold check;
- restriction;
- archival;
- disposal;
- processor cleanup;
- evidence.

# 85. Scope Closure

Closing organization/clinic does not automatically delete records.

# 86. Resource Transfer

Transfer must update lifecycle ownership without resetting retention improperly.

# 87. Privacy Restriction

Restriction must propagate to search, analytics, exports, and processing flags.

# 88. Restriction Release

Must be authorized and audited.

# 89. Data Freeze

Freeze blocks mutation but preserves data.

# 90. Lifecycle Events

```text
data.lifecycle.eligible.v1
data.lifecycle.archived.v1
data.lifecycle.restricted.v1
data.lifecycle.disposition.started.v1
data.lifecycle.disposed.v1
data.lifecycle.failed.v1
data.lifecycle.tombstone.created.v1
```

# 91. Lifecycle Event Security

Events must not expose deleted content unnecessarily.

# 92. Reconciliation

Compare:

- lifecycle policy registry;
- candidate records;
- current states;
- archives;
- tombstones;
- search indexes;
- analytics copies;
- exports;
- external processors;
- backups;
- evidence.

# 93. Reconciliation Findings

```text
ELIGIBLE_NOT_PROCESSED
DISPOSED_STILL_PRESENT
ARCHIVED_WITHOUT_MANIFEST
TOMBSTONE_MISSING
HOLD_BYPASSED
PROCESSOR_DELETION_MISSING
SEARCH_INDEX_STALE
ANALYTICS_COPY_STALE
BACKUP_REDELETE_PENDING
EVIDENCE_INCOMPLETE
```

# 94. Auto-Remediation

Examples:

- re-run index cleanup;
- invalidate caches;
- resend processor deletion;
- rebuild tombstone;
- replay deletion after restore;
- reopen failed job.

# 95. Manual Remediation

Required for:

- cross-tenant deletion;
- active-hold violation;
- archive corruption;
- lost evidence;
- unknown processor state;
- failed cryptographic erasure;
- large-scale mismatch.

# 96. Audit Events

```text
DATA_LIFECYCLE_POLICY_PUBLISHED
DATA_LIFECYCLE_ELIGIBILITY_CALCULATED
DATA_ARCHIVAL_STARTED
DATA_ARCHIVED
DATA_RESTRICTION_APPLIED
DATA_DISPOSITION_APPROVED
DATA_DISPOSITION_STARTED
DATA_DISPOSED
DATA_TOMBSTONE_CREATED
DATA_DISPOSITION_FAILED
DATA_LIFECYCLE_KILL_SWITCH_USED
DATA_LIFECYCLE_RECONCILIATION_FAILED
```

# 97. Metrics

```text
data_lifecycle_candidate_total
data_lifecycle_archived_total
data_lifecycle_disposed_total
data_lifecycle_failed_total
data_lifecycle_hold_blocked_total
data_lifecycle_processor_pending_total
data_lifecycle_backup_redelete_pending_total
data_lifecycle_reconciliation_failure_total
data_lifecycle_job_duration_seconds
```

# 98. KPIs

```text
Disposed records still present = 0
Destruction with active hold = 0
Lifecycle jobs without evidence = 0
Processor deletions without confirmation = 0
Restored deleted data reactivated = 0
Cross-tenant lifecycle action = 0
Unverified disposal completion = 0
```

# 99. KRIs

```text
Disposition backlog
Archive failures
Deletion propagation delay
Processor overdue count
Backup re-delete backlog
Tombstone recreation attempts
Lifecycle job partial failures
Kill-switch usage
```

# 100. Database Direction

Potential tables:

```text
data_lifecycle_policies
data_lifecycle_policy_versions
data_lifecycle_states
data_lifecycle_candidates
data_lifecycle_jobs
data_lifecycle_job_items
data_lifecycle_dependencies
data_lifecycle_tombstones
data_lifecycle_evidence
data_backup_catalog
data_lifecycle_reconciliation_runs
data_lifecycle_reconciliation_findings
```

# 101. Table: data_lifecycle_policies

```sql
CREATE TABLE data_lifecycle_policies (
    id CHAR(26) NOT NULL,
    policy_code VARCHAR(180) NOT NULL,
    resource_type VARCHAR(180) NOT NULL,
    owner_reference VARCHAR(180) NOT NULL,
    trigger_type VARCHAR(50) NOT NULL,
    retention_source VARCHAR(50) NOT NULL,
    archival_action VARCHAR(50) NULL,
    disposal_action VARCHAR(50) NOT NULL,
    status VARCHAR(30) NOT NULL,
    current_version VARCHAR(100) NOT NULL,
    created_at DATETIME(6) NOT NULL,

    PRIMARY KEY (id),
    UNIQUE KEY uq_data_lifecycle_policy_code (policy_code),
    KEY idx_data_lifecycle_policy_status (
        resource_type,
        status
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

# 102. Table: data_lifecycle_jobs

```sql
CREATE TABLE data_lifecycle_jobs (
    id CHAR(26) NOT NULL,
    job_code VARCHAR(180) NOT NULL,
    policy_code VARCHAR(180) NOT NULL,
    policy_version VARCHAR(100) NOT NULL,
    tenant_id CHAR(26) NULL,
    status VARCHAR(30) NOT NULL,
    candidate_count BIGINT NOT NULL DEFAULT 0,
    completed_count BIGINT NOT NULL DEFAULT 0,
    failed_count BIGINT NOT NULL DEFAULT 0,
    checkpoint_reference VARCHAR(1000) NULL,
    requested_by VARCHAR(180) NOT NULL,
    approved_by VARCHAR(180) NULL,
    started_at DATETIME(6) NULL,
    completed_at DATETIME(6) NULL,

    PRIMARY KEY (id),
    UNIQUE KEY uq_data_lifecycle_job_code (job_code),
    KEY idx_data_lifecycle_job_status (
        status,
        started_at
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

# 103. Table: data_lifecycle_job_items

```sql
CREATE TABLE data_lifecycle_job_items (
    id CHAR(26) NOT NULL,
    job_id CHAR(26) NOT NULL,
    resource_type VARCHAR(180) NOT NULL,
    resource_reference VARCHAR(1000) NOT NULL,
    eligibility_result VARCHAR(40) NOT NULL,
    hold_check_result VARCHAR(40) NOT NULL,
    status VARCHAR(30) NOT NULL,
    completed_targets_json JSON NULL,
    failed_targets_json JSON NULL,
    evidence_reference VARCHAR(1000) NULL,
    completed_at DATETIME(6) NULL,

    PRIMARY KEY (id),
    UNIQUE KEY uq_data_lifecycle_job_item (
        job_id,
        resource_type,
        resource_reference
    ),
    KEY idx_data_lifecycle_item_status (
        status,
        completed_at
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

# 104. Table: data_lifecycle_tombstones

```sql
CREATE TABLE data_lifecycle_tombstones (
    id CHAR(26) NOT NULL,
    resource_type VARCHAR(180) NOT NULL,
    canonical_identifier VARCHAR(255) NOT NULL,
    tenant_id CHAR(26) NULL,
    disposition_reason VARCHAR(180) NOT NULL,
    policy_version VARCHAR(100) NOT NULL,
    recreation_blocked TINYINT(1) NOT NULL DEFAULT 1,
    non_sensitive_hash CHAR(64) NULL,
    disposed_at DATETIME(6) NOT NULL,

    PRIMARY KEY (id),
    UNIQUE KEY uq_data_lifecycle_tombstone (
        resource_type,
        tenant_id,
        canonical_identifier
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

# 105. API Direction

```text
GET  /api/internal/v1/data-lifecycle/policies
POST /api/internal/v1/data-lifecycle/policies
POST /api/internal/v1/data-lifecycle/policies/{policyCode}/publish
POST /api/internal/v1/data-lifecycle/eligibility/evaluate
GET  /api/internal/v1/data-lifecycle/jobs
POST /api/internal/v1/data-lifecycle/jobs
POST /api/internal/v1/data-lifecycle/jobs/{jobCode}/approve
POST /api/internal/v1/data-lifecycle/jobs/{jobCode}/execute
POST /api/internal/v1/data-lifecycle/jobs/{jobCode}/pause
POST /api/internal/v1/data-lifecycle/jobs/{jobCode}/resume
POST /api/internal/v1/data-lifecycle/reconciliation/runs
```

# 106. SDK Contracts

```text
DataLifecyclePolicyRegistryInterface
DataLifecycleEligibilityServiceInterface
DataLifecycleArchiveServiceInterface
DataLifecycleDispositionServiceInterface
DataLifecycleTombstoneServiceInterface
DataLifecycleEvidenceServiceInterface
DataLifecycleReconciliationServiceInterface
```

# 107. Eligibility Contract

```php
interface DataLifecycleEligibilityServiceInterface
{
    public function evaluate(
        DataLifecycleEligibilityRequest $request
    ): DataLifecycleEligibilityDecision;
}
```

# 108. Disposition Contract

```php
interface DataLifecycleDispositionServiceInterface
{
    public function plan(
        DataLifecycleDispositionPlanRequest $request
    ): DataLifecycleDispositionPlan;

    public function execute(
        DataLifecycleDispositionExecutionRequest $request
    ): DataLifecycleDispositionResult;
}
```

# 109. Tombstone Contract

```php
interface DataLifecycleTombstoneServiceInterface
{
    public function create(
        DataLifecycleTombstoneRequest $request
    ): DataLifecycleTombstone;

    public function blocksRecreation(
        string $resourceType,
        string $canonicalIdentifier,
        ?string $tenantId
    ): bool;
}
```

# 110. Error Codes

```text
DATA_LIFECYCLE_POLICY_NOT_FOUND
DATA_LIFECYCLE_TRANSITION_INVALID
DATA_LIFECYCLE_NOT_ELIGIBLE
DATA_LIFECYCLE_HOLD_ACTIVE
DATA_LIFECYCLE_DEPENDENCY_BLOCKED
DATA_LIFECYCLE_ARCHIVE_FAILED
DATA_LIFECYCLE_DISPOSITION_FAILED
DATA_LIFECYCLE_PROCESSOR_PENDING
DATA_LIFECYCLE_TOMBSTONE_CONFLICT
DATA_LIFECYCLE_EVIDENCE_INCOMPLETE
DATA_LIFECYCLE_RECONCILIATION_FAILED
```

# 111. Policy Registration Checklist

- [ ] Resource type defined.
- [ ] Owner assigned.
- [ ] Trigger defined.
- [ ] Retention source defined.
- [ ] State machine defined.
- [ ] Archive action defined.
- [ ] Disposal action defined.
- [ ] Hold behavior defined.
- [ ] Evidence requirements defined.
- [ ] Reconciliation defined.

# 112. Lifecycle Job Checklist

- [ ] Policy/version valid.
- [ ] Candidate population defined.
- [ ] Dry run completed.
- [ ] Tenant/scope verified.
- [ ] Hold checks completed.
- [ ] Dependencies resolved.
- [ ] Approval complete.
- [ ] Kill switch available.
- [ ] Evidence storage available.
- [ ] Reconciliation scheduled.

# 113. UAT — Eligibility & Policy

- [ ] Eligible record identified.
- [ ] Retention-not-expired record blocked.
- [ ] Active hold blocks disposal.
- [ ] Privacy restriction applied.
- [ ] Dependency block works.
- [ ] Policy version recorded.
- [ ] Cross-tenant candidate rejected.
- [ ] Unknown policy denied.
- [ ] Audit complete.

# 114. UAT — Archival

- [ ] Eligible data archives.
- [ ] Manifest generated.
- [ ] Checksum validates.
- [ ] Access becomes read-only.
- [ ] Archive retrieval works.
- [ ] Restore does not reactivate disposed state.
- [ ] Format migration works.
- [ ] Failed archive creates issue.
- [ ] Evidence retained.

# 115. UAT — Deletion Propagation

- [ ] Primary database deleted.
- [ ] Replica updated.
- [ ] File removed.
- [ ] Search index cleaned.
- [ ] Cache invalidated.
- [ ] Analytics copy removed/anonymized.
- [ ] Export removed.
- [ ] Processor confirmed.
- [ ] Event projection handled.
- [ ] Final verification passes.

# 116. UAT — Tombstones & Recreation Prevention

- [ ] Tombstone created.
- [ ] Sensitive data minimized.
- [ ] Re-import blocked.
- [ ] Sync recreation blocked.
- [ ] Authorized restoration follows policy.
- [ ] Tombstone lookup tenant-safe.
- [ ] Duplicate tombstone handled.
- [ ] Audit complete.
- [ ] Reconciliation passes.

# 117. UAT — Batch Safety

- [ ] Dry run lists exact population.
- [ ] Maker-checker approval works.
- [ ] Checkpoint resumes correctly.
- [ ] Partial failure isolated.
- [ ] Retry is idempotent.
- [ ] Final hold recheck works.
- [ ] Kill switch stops job.
- [ ] Concurrent update conflict detected.
- [ ] Evidence complete.

# 118. UAT — Backup & Restore

- [ ] Backup catalog identifies affected copies.
- [ ] Restored deleted data remains restricted.
- [ ] Tombstones replay.
- [ ] Re-deletion job runs.
- [ ] Legal-hold records remain preserved.
- [ ] Offline media follows rotation.
- [ ] Pending re-delete creates finding.
- [ ] Evidence retained.
- [ ] Reconciliation passes.

# 119. UAT — Reconciliation

- [ ] Eligible-not-processed detected.
- [ ] Disposed-still-present detected.
- [ ] Archive without manifest detected.
- [ ] Missing tombstone detected.
- [ ] Hold bypass detected.
- [ ] Processor deletion missing detected.
- [ ] Stale search index detected.
- [ ] Stale analytics copy detected.
- [ ] Backup re-delete pending detected.
- [ ] Incomplete evidence detected.

# 120. Definition of Done — SSOT-DATA-09

SSOT-DATA-09 dianggap selesai bila:

- [ ] lifecycle policy registry tersedia;
- [ ] state machine tersedia;
- [ ] eligibility calculation tersedia;
- [ ] trigger types tersedia;
- [ ] policy precedence/versioning tersedia;
- [ ] records/privacy/scope integration tersedia;
- [ ] archival governance tersedia;
- [ ] deletion propagation tersedia;
- [ ] database/file/search/cache/analytics controls tersedia;
- [ ] event/export/processor handling tersedia;
- [ ] tombstones tersedia;
- [ ] anonymization/crypto-erasure tersedia;
- [ ] dependency graph tersedia;
- [ ] lifecycle jobs/checkpoints tersedia;
- [ ] idempotency/concurrency tersedia;
- [ ] final hold check tersedia;
- [ ] maker-checker/kill switch tersedia;
- [ ] disposal evidence tersedia;
- [ ] recovery/verification tersedia;
- [ ] backup re-deletion tersedia;
- [ ] tenant offboarding tersedia;
- [ ] lifecycle events tersedia;
- [ ] reconciliation tersedia;
- [ ] audit and metrics tersedia;
- [ ] database direction tersedia;
- [ ] API direction tersedia;
- [ ] SDK contracts tersedia;
- [ ] UAT and DoD tersedia.

# 121. Implementation Roadmap

## Phase 1 — Lifecycle Policy Foundation

- policy registry;
- state machines;
- trigger resolver;
- eligibility engine;
- administrative APIs;
- audit events.

## Phase 2 — Archive & Restriction

- archive packaging;
- integrity manifests;
- archive access;
- restriction propagation;
- retrieval;
- verification.

## Phase 3 — Disposal Orchestration

- dependency graph;
- disposition planning;
- maker-checker;
- tombstones;
- deletion propagation;
- processor coordination.

## Phase 4 — Recovery & Assurance

- checkpoints;
- partial-failure recovery;
- backup re-deletion;
- reconciliation;
- auto-remediation;
- evidence dashboards.

## Phase 5 — Continuous Lifecycle Platform

- policy-as-code;
- automated cross-system discovery;
- central lifecycle orchestrator;
- continuous verification;
- predictive backlog management;
- lifecycle governance dashboard.

# 122. Initial Implementation Backlog

```text
DATA09-001 Lifecycle Policy Registry
DATA09-002 Lifecycle State Machine
DATA09-003 Trigger Resolver
DATA09-004 Eligibility Engine
DATA09-005 Archive Package Service
DATA09-006 Archive Integrity Monitor
DATA09-007 Dependency Graph
DATA09-008 Disposition Planner
DATA09-009 Lifecycle Job Orchestrator
DATA09-010 Tombstone Service
DATA09-011 Deletion Propagation
DATA09-012 Processor Deletion Coordinator
DATA09-013 Backup Re-Deletion
DATA09-014 Evidence Store
DATA09-015 Reconciliation Engine
DATA09-016 Lifecycle Governance Dashboard
```

# 123. Approval Gate

Dokumen dapat menjadi Approved setelah:

- Data Architecture review;
- Records Management review;
- Privacy review;
- Security review;
- File/Storage Architecture review;
- Event/Integration Architecture review;
- Operations/SRE review;
- Audit/Compliance review;
- Quality Engineering review;
- UAT review.

# 124. Closing Statement

Lifecycle governance tidak selesai pada retention schedule.

Policy harus dieksekusi ke setiap salinan data.

Archival harus menjaga integritas.

Deletion harus dipropagasikan dan diverifikasi.

Tombstone harus mencegah recreating data secara diam-diam.

Backup restore harus menjalankan ulang deletion obligations.

Setiap lifecycle action harus memiliki evidence dan reconciliation.
