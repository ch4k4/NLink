
# SSOT-DATA-01 — Database Standards

## Status Dokumen

| Item | Nilai |
|---|---|
| Kode | SSOT-DATA-01 |
| Domain | Platform Kernel |
| Berlaku Untuk | Seluruh modul platform |

# 1. Tujuan

Dokumen ini menjadi standar tunggal desain database untuk seluruh platform agar seluruh modul memiliki pola yang konsisten, mudah dipelihara, dan siap berkembang.

# 2. Prinsip

- Konsisten
- Normalisasi secukupnya
- Multi-tenant sejak awal
- Scope-aware
- Audit-ready
- Soft delete
- Migration-first
- Backward compatible saat refactor

# 3. Penamaan

## Tabel
- snake_case
- bentuk jamak

Contoh:
```text
users
patients
audit_events
```

## Kolom
- snake_case
- foreign key diakhiri `_id`

# 4. Primary Key

Gunakan:
- BIGINT UNSIGNED AUTO_INCREMENT untuk PK internal.
- UUID untuk identitas publik bila diperlukan.

# 5. Foreign Key

- FK untuk relasi kuat.
- Jangan cascade delete pada data transaksi.
- Gunakan RESTRICT atau SET NULL sesuai kebutuhan.

# 6. Kolom Standar

Semua tabel transaksi minimal memiliki:

```text
id
tenant_id
organization_id
business_entity_id
created_at
updated_at
deleted_at
created_by
updated_by
deleted_by
```

# 7. Scope Columns

Setiap data yang dapat dibatasi aksesnya harus menyimpan scope minimum:

```text
tenant_id
organization_id
business_entity_id
```

Opsional:

```text
branch_id
department_id
team_id
service_id
```

# 8. Audit Columns

Kolom audit metadata:

```text
created_by
updated_by
deleted_by
created_at
updated_at
deleted_at
```

Audit detail disimpan di modul Audit Trail.

# 9. Soft Delete

Gunakan:

```text
deleted_at
deleted_by
```

Hard delete hanya untuk data sementara sesuai kebijakan.

# 10. Status

Hindari boolean untuk lifecycle.

Gunakan ENUM atau lookup:

```text
pending
active
inactive
disabled
archived
```

# 11. JSON Policy

JSON hanya untuk:
- snapshot
- konfigurasi
- metadata fleksibel

Jangan menyimpan relasi utama dalam JSON.

# 12. Index Strategy

Minimal:
- PK
- FK
- created_at
- status
- tenant_id
- unique business key

Tambahkan composite index untuk query yang sering digunakan.

# 13. Unique Constraint

Gunakan unique sesuai scope.

Contoh:

```text
tenant_id + username
tenant_id + code
business_entity_id + medical_record_number
```

# 14. Migration Standard

- Satu perubahan = satu migration.
- Migration harus idempotent.
- Tidak mengubah data bisnis tanpa skrip migrasi eksplisit.

# 15. Seed Standard

Pisahkan:
- reference seed
- demo seed
- test seed

Seed harus dapat dijalankan berulang dengan aman.

# 16. Transaction Guideline

Gunakan transaksi database untuk operasi multi-tabel yang harus atomik.

# 17. Referential Integrity

- Hindari orphan record.
- Validasi FK di aplikasi dan database.
- Snapshot digunakan untuk histori.

# 18. Data Retention

Setiap tabel harus memiliki kebijakan:
- retention
- archive
- purge (bila diizinkan)

# 19. Performance

- Hindari SELECT *
- Index berdasarkan pola query
- Partition untuk tabel besar (audit, log)
- Batch insert untuk volume tinggi

# 20. Naming Convention

Contoh:
```text
patient_id
encounter_id
homecare_visit_id
```

Hindari:
```text
pid
eid
hcid
```

# 21. Anti-pattern

Jangan:
- menyimpan password plain
- menyimpan role di tabel users
- menyimpan clinic_id sebagai satu-satunya scope
- menyimpan list relasi dalam string
- hard delete data transaksi

# 22. UAT

- Semua tabel memiliki kolom standar.
- Semua FK valid.
- Soft delete bekerja.
- Migration dapat dijalankan dari database kosong.
- Seed dapat dijalankan berulang.

# 23. Definition of Done

- Standar diterapkan pada seluruh migration baru.
- Seluruh modul mengikuti naming convention.
- Seluruh data transaksi scope-aware.
- Seluruh data mendukung audit dan soft delete.
