# SSOT-DATA-06 — Data Classification, Privacy & Access Governance

---

## Status Dokumen

| Item | Nilai |
|---|---|
| Kode | SSOT-DATA-06 |
| Judul | Data Classification, Privacy & Access Governance |
| Versi | 1.0 |
| Status | Draft Architecture |
| Domain | Platform Kernel |
| Kategori | Data Governance, Privacy, Security & Access Control |
| Cakupan | Data Classification, Field Sensitivity, Purpose, Consent, Masking, Retention, Export, Deletion, Field-Level Access, Privacy Evidence |
| Bergantung pada | SSOT-GOV-01, SSOT-GOV-04, SSOT-GOV-05, SSOT-SCOPE-01, SSOT-IAM-01, SSOT-RBAC-05, SSOT-RBAC-06, SSOT-AUDIT-01, SSOT-DATA-01, SSOT-DATA-02, SSOT-DATA-03, SSOT-DATA-04, SSOT-DATA-05, SSOT-SEC-01, SSOT-SEC-03, SSOT-TEST-01 |
| Target Stack | PHP 8.1+, PDO, MySQL 8/MariaDB, Policy Engine-ready |
| Target Evolusi | Automated Data Catalog, Field-Level Policy Enforcement, Consent Platform, Data Loss Prevention Integration |

---

# 1. Executive Summary

SSOT-DATA-06 menetapkan governance resmi untuk klasifikasi data, privacy, purpose limitation, consent, masking, field-level access, retention, export, deletion, dan privacy evidence pada Platform Kernel.

Dokumen ini mengatur:

- data classification;
- data sensitivity;
- data category;
- subject category;
- business purpose;
- lawful/approved basis;
- consent;
- field-level policy;
- record-level policy;
- masking;
- redaction;
- tokenization;
- encryption applicability;
- export controls;
- bulk access;
- retention;
- deletion;
- legal hold;
- anonymization;
- pseudonymization;
- data minimization;
- tenant isolation;
- cross-border/location constraints;
- access logging;
- data subject requests;
- privacy incident support;
- database direction;
- API direction;
- SDK contracts;
- UAT;
- Definition of Done;
- implementation roadmap.

Tujuan akhirnya adalah memastikan setiap data:

- memiliki classification;
- memiliki owner;
- memiliki purpose;
- memiliki access policy;
- memiliki retention rule;
- dapat dimasking;
- dapat diekspor hanya dengan kontrol;
- dapat dihapus atau dianonimkan sesuai policy;
- dapat diaudit;
- tidak digunakan di luar tujuan yang disetujui.

---

# 2. Objectives

Framework harus:

- menyediakan canonical data classification;
- menjaga data minimization;
- mendukung field-level access;
- mendukung consent dan purpose checks;
- mengendalikan exports;
- menjaga tenant isolation;
- mendukung retention/deletion;
- menyediakan privacy evidence;
- mendukung audit/compliance;
- mendukung automation dan policy engine.

---

# 3. Core Principles

```text
Every Data Element Has an Owner
Every Data Element Has a Classification
Collect Only What Is Needed
Use Data Only for Approved Purposes
Access Is Based on Need, Scope, and Purpose
Sensitive Fields Require Stronger Controls
Exports Are Separate Privileged Actions
Retention Is Explicit
Deletion Is Governed
Privacy Decisions Must Be Auditable
```

---

# 4. Scope

Framework berlaku untuk:

```text
Master Data
Transactional Data
Identity Data
Clinical/Health Data
Financial Data
Audit Data
File Metadata
Search Indexes
Reports
Analytics Datasets
Integration Payloads
Backups
Logs and Telemetry
```

---

# 5. Non-Scope

Dokumen ini tidak menggantikan:

- legal interpretation;
- sector-specific legal advice;
- complete records management policy;
- cryptographic algorithm policy;
- endpoint authorization architecture.

---

# 6. Data Classification Model

Recommended levels:

```text
PUBLIC
INTERNAL
CONFIDENTIAL
RESTRICTED
REGULATED
```

---

# 7. Public

Data yang dapat dipublikasikan tanpa material harm.

---

# 8. Internal

Data operasional non-public dengan risiko terbatas.

---

# 9. Confidential

Data yang dapat menimbulkan harm bila bocor.

---

# 10. Restricted

Data sangat sensitif dengan akses sangat terbatas.

---

# 11. Regulated

Data yang tunduk pada legal, contractual, sectoral, atau compliance controls.

---

# 12. Data Categories

```text
IDENTITY
CONTACT
DEMOGRAPHIC
AUTHENTICATION
AUTHORIZATION
CLINICAL
FINANCIAL
PAYMENT
EMPLOYMENT
LOCATION
COMMUNICATION
BIOMETRIC
AUDIT
SECURITY
OPERATIONAL
ANALYTICS
```

---

# 13. Sensitive Data Flags

Optional flags:

```text
PII
PHI
PCI
SECRET
CREDENTIAL
BIOMETRIC
CHILD_DATA
LOCATION_PRECISE
FINANCIAL_ACCOUNT
```

---

# 14. Data Asset

Data asset dapat berupa:

```text
TABLE
COLUMN
DOCUMENT
FILE
EVENT
REPORT
SEARCH_INDEX
BACKUP
LOG_STREAM
DATASET
```

---

# 15. Data Element Registry

Minimum:

```text
data_element_code
asset_type
owner
classification
category
purpose
retention_policy
masking_policy
access_policy
status
```

---

# 16. Data Element Code

Format:

```text
{domain}.{resource}.{field}
```

Contoh:

```text
patient.profile.national_id
patient.profile.phone_number
billing.invoice.total_amount
iam.user.password_hash
```

---

# 17. Data Owner

Every data element must have:

- business owner;
- data owner;
- technical custodian;
- privacy/security reviewer where required.

---

# 18. Data Steward

Steward membantu quality, metadata, dan lifecycle namun tidak menggantikan accountability owner.

---

# 19. Classification Assignment

Classification ditentukan berdasarkan:

- sensitivity;
- impact;
- identifiability;
- legal obligations;
- business criticality;
- aggregation risk;
- reversibility.

---

# 20. Aggregation Risk

Data berklasifikasi rendah dapat menjadi lebih sensitif setelah digabungkan.

---

# 21. Default Classification

Unclassified data defaults to:

```text
CONFIDENTIAL
```

hingga direview.

---

# 22. Classification Lifecycle

```text
Propose
→ Review
→ Approve
→ Apply
→ Monitor
→ Reclassify
→ Retire
```

---

# 23. Classification Review

Trigger:

- schema change;
- new use case;
- new integration;
- new report;
- incident;
- legal/compliance change;
- major data aggregation.

---

# 24. Data Purpose

Every processing activity should have approved purpose.

Examples:

```text
CARE_DELIVERY
BILLING
CUSTOMER_SERVICE
SECURITY
AUDIT
LEGAL
ANALYTICS
PRODUCT_IMPROVEMENT
MARKETING_APPROVED
```

---

# 25. Purpose Limitation

Data access/use must be compatible with approved purpose.

---

# 26. Purpose Context

Authorization request may include:

```text
purpose_code
workflow
case
ticket
legal_basis
consent_reference
```

---

# 27. Purpose-Based Access

Permission alone may be insufficient for regulated/restricted data.

---

# 28. Consent

Consent, where required, must be:

- specific;
- informed;
- recorded;
- versioned;
- time-bound where applicable;
- revocable;
- auditable.

---

# 29. Consent Status

```text
REQUESTED
GRANTED
PARTIAL
REVOKED
EXPIRED
NOT_REQUIRED
DENIED
```

---

# 30. Consent Record

Minimum:

```text
subject_id
purpose
data_categories
granted_at
valid_to
source
version
status
revoked_at
```

---

# 31. Consent Withdrawal

Withdrawal must propagate to future processing where applicable.

---

# 32. Consent Is Not Universal Authorization

Consent does not grant operator access by itself.

---

# 33. Data Minimization

Collect, store, display, export, and log only necessary fields.

---

# 34. Field-Level Access

Field policy may depend on:

- permission;
- role;
- scope;
- purpose;
- subject relationship;
- assurance;
- environment;
- data classification.

---

# 35. Field Access Decisions

```text
ALLOW_FULL
ALLOW_MASKED
ALLOW_REDACTED
ALLOW_AGGREGATED
DENY
```

---

# 36. Field Policy Example

```text
patient.profile.national_id
classification = RESTRICTED
read = patient.identity.read_sensitive
default_projection = MASKED
export = patient.identity.export_sensitive
```

---

# 37. Record-Level Access

Record access depends on scope/resource relation.

---

# 38. Row and Field Combined

Both row-level and field-level decisions must pass.

---

# 39. Masking

Masking retains partial utility while reducing exposure.

Examples:

```text
********1234
a***@example.com
0812****789
```

---

# 40. Redaction

Redaction removes value entirely from projection.

---

# 41. Tokenization

Tokenization replaces sensitive data with controlled token.

---

# 42. Pseudonymization

Pseudonymization separates direct identifiers from analytical records.

---

# 43. Anonymization

Anonymization must reduce re-identification risk to accepted level.

---

# 44. Masking Policy

Minimum:

```text
policy_code
data_category
classification
masking_method
allowed_contexts
owner
version
```

---

# 45. Server-Side Masking

Sensitive masking must be enforced server-side.

---

# 46. UI Masking

UI masking alone is insufficient.

---

# 47. Logging Masking

Logs must use separate data minimization/masking rules.

---

# 48. Search Index Masking

Search indexes should not contain fields beyond approved need.

---

# 49. Analytics Data

Analytics datasets should prefer aggregated, pseudonymized, or anonymized data.

---

# 50. Export Governance

Export is a distinct privileged capability.

---

# 51. Export Types

```text
SINGLE_RECORD
BULK
REPORT
DATASET
BACKUP
INTEGRATION
SUBJECT_ACCESS
```

---

# 52. Export Controls

May require:

- dedicated permission;
- purpose;
- approval;
- MFA;
- watermark;
- encryption;
- expiry;
- download limits;
- audit;
- recipient restrictions.

---

# 53. Bulk Export

Bulk export should be high-risk by default.

---

# 54. Export Minimization

Export only approved fields and records.

---

# 55. Export File Protection

Use:

- encryption;
- password or recipient key where approved;
- signed URL;
- expiry;
- access logging;
- secure deletion.

---

# 56. Watermark

May include:

```text
actor
tenant
timestamp
purpose
export_id
```

---

# 57. Data Sharing

External sharing requires approved recipient and agreement/purpose.

---

# 58. Integration Payload

Integration contracts must define:

- fields;
- classification;
- purpose;
- recipient;
- retention;
- encryption;
- error handling.

---

# 59. Cross-Tenant Data

Cross-tenant aggregation requires platform governance.

---

# 60. Tenant Isolation

Data access, cache, search, files, reports, and exports must preserve tenant boundaries.

---

# 61. Location/Residency

Data location constraints may apply by tenant, category, or regulation.

---

# 62. Cross-Border Transfer

Must be explicitly governed where relevant.

---

# 63. Retention

Every governed data asset must have retention policy.

---

# 64. Retention Policy Fields

```text
policy_code
data_category
trigger
duration
action
legal_hold_behavior
owner
```

---

# 65. Retention Trigger

Examples:

```text
CREATED_AT
LAST_ACTIVITY
ACCOUNT_CLOSED
CONTRACT_ENDED
CASE_CLOSED
PATIENT_DECEASED
```

---

# 66. Retention Actions

```text
KEEP
ARCHIVE
ANONYMIZE
PSEUDONYMIZE
DELETE
REVIEW
```

---

# 67. Legal Hold

Legal hold suspends normal deletion for specified data.

---

# 68. Legal Hold Scope

```text
SUBJECT
CASE
TENANT
RESOURCE
DATE_RANGE
DATA_CATEGORY
```

---

# 69. Deletion

Deletion must be controlled, traceable, and dependency-aware.

---

# 70. Deletion Types

```text
SOFT_DELETE
HARD_DELETE
CRYPTO_ERASURE
ANONYMIZATION
TOMBSTONE
```

---

# 71. Deletion Preconditions

- authority validated;
- legal hold checked;
- retention checked;
- dependencies checked;
- backups considered;
- audit retained;
- verification planned.

---

# 72. Crypto Erasure

May be used when encrypted data can be rendered inaccessible by key destruction, subject to policy.

---

# 73. Backup Deletion

Deletion from active systems may not immediately remove data from immutable backups.

Policy must define delayed expiry and restoration handling.

---

# 74. Restore Handling

Restored backups must reapply deletion/tombstone records.

---

# 75. Data Subject Requests

Potential request types:

```text
ACCESS
CORRECTION
EXPORT
DELETION
RESTRICTION
OBJECTION
CONSENT_WITHDRAWAL
```

---

# 76. Request Identity Verification

Must be proportionate and secure.

---

# 77. Request Workflow

```text
Receive
→ Verify
→ Scope
→ Search
→ Review
→ Fulfill
→ Verify
→ Close
```

---

# 78. Access Report

Should include only data permitted by policy and applicable request scope.

---

# 79. Correction

Correction must preserve audit/history where required.

---

# 80. Privacy Incident Support

System must help identify:

- affected subjects;
- affected data categories;
- exposure window;
- actors;
- exports;
- downstream recipients.

---

# 81. Data Lineage

Lineage should map:

```text
source
→ transformation
→ storage
→ report/index/export
→ recipient
```

---

# 82. Data Flow Registry

Every high-risk data flow should be documented.

---

# 83. Access Logging

Sensitive access logs should record:

- actor;
- subject/workload;
- data asset;
- purpose;
- scope;
- result;
- timestamp;
- correlation ID.

---

# 84. Value Logging

Do not log full sensitive values.

---

# 85. Break-Glass Data Access

Requires:

- incident/emergency;
- strong MFA;
- reason;
- limited time;
- enhanced audit;
- review.

---

# 86. Field Access Contract

```php
interface DataAccessPolicyInterface
{
    public function decide(
        DataAccessRequest $request
    ): DataAccessDecision;
}
```

---

# 87. Data Access Request

```php
final readonly class DataAccessRequest
{
    public function __construct(
        public string $subjectId,
        public string $dataElementCode,
        public string $action,
        public ScopeContext $scope,
        public ?string $purposeCode,
        public array $context = [],
    ) {
    }
}
```

---

# 88. Data Access Decision

```php
final readonly class DataAccessDecision
{
    public function __construct(
        public string $result,
        public ?string $maskingPolicyCode,
        public string $reasonCode,
        public array $obligations = [],
    ) {
    }
}
```

---

# 89. Obligations

Examples:

```text
MASK
WATERMARK
LOG_ACCESS
REQUIRE_APPROVAL
REQUIRE_MFA
LIMIT_FIELDS
LIMIT_ROWS
ENCRYPT_EXPORT
```

---

# 90. Data Catalog Contract

```php
interface DataCatalogInterface
{
    public function find(string $dataElementCode): ?DataElementDefinition;

    public function requireActive(string $dataElementCode): DataElementDefinition;
}
```

---

# 91. Masking Contract

```php
interface DataMaskingServiceInterface
{
    public function mask(
        string $value,
        string $policyCode
    ): string;
}
```

---

# 92. Retention Contract

```php
interface DataRetentionServiceInterface
{
    public function evaluate(
        RetentionEvaluationRequest $request
    ): RetentionDecision;
}
```

---

# 93. Consent Contract

```php
interface ConsentServiceInterface
{
    public function hasValidConsent(
        string $subjectId,
        string $purposeCode,
        array $dataCategories
    ): bool;
}
```

---

# 94. Data Catalog Registration

Module must declare data elements and classifications through manifest or catalog registration.

---

# 95. Data Manifest Example

```yaml
module: patient
version: 2.0.0
data_elements:
  - code: patient.profile.national_id
    asset: patient_profiles.national_id
    classification: RESTRICTED
    category: IDENTITY
    flags: [PII]
    owner: patient-domain
    retention_policy: patient_identity_retention
    masking_policy: national_id_default
```

---

# 96. Schema Change Gate

New columns/tables require data classification before migration approval.

---

# 97. Unclassified Field

Production deployment should fail or warn according to risk policy.

---

# 98. Sensitive Defaults

Sensitive fields should not be included in generic serializers by default.

---

# 99. DTO Governance

DTOs must explicitly declare sensitive field inclusion.

---

# 100. API Response Governance

API schemas should annotate field classification where tooling supports.

---

# 101. Report Governance

Reports must define:

- owner;
- fields;
- classifications;
- purpose;
- scope;
- exportability;
- retention.

---

# 102. Search Governance

Search result snippets must respect masking and access policy.

---

# 103. File Metadata

Files and attachments must inherit classification from content/use case.

---

# 104. Event Governance

Events should minimize sensitive fields and define retention.

---

# 105. Cache Governance

Cache entries must:

- preserve tenant;
- respect field policy;
- use bounded TTL;
- invalidate on revocation/policy change;
- not leak sensitive values.

---

# 106. Test Data

Production sensitive data cannot be used in test without approved masking.

---

# 107. Development Logs

No production sensitive payload in local/debug logs.

---

# 108. Data Quality

Privacy controls should not prevent correction and quality management.

---

# 109. Data Accuracy

Subject-facing data should support correction workflows where appropriate.

---

# 110. Access Review

Restricted/regulated data permissions should be periodically reviewed.

---

# 111. Dormant Access

Unused sensitive-data access should be removed or converted to JIT.

---

# 112. Data Access Certification

Certification confirms:

- owner;
- purpose;
- permissions;
- scope;
- masking;
- retention;
- logging;
- recipients.

---

# 113. Reconciliation

Compare:

- schema;
- catalog;
- API schemas;
- serializers;
- reports;
- exports;
- search indexes;
- event schemas;
- retention jobs;
- access policies.

---

# 114. Reconciliation Findings

```text
UNCLASSIFIED_FIELD
OWNER_MISSING
POLICY_MISSING
MASKING_DRIFT
RETENTION_DRIFT
UNAPPROVED_EXPORT
SEARCH_INDEX_OVEREXPOSURE
LOGGING_OVEREXPOSURE
ORPHAN_DATASET
CONSENT_POLICY_DRIFT
```

---

# 115. Reconciliation Frequency

- migration CI;
- deployment;
- nightly/weekly;
- post-incident;
- policy change;
- periodic privacy review.

---

# 116. Audit Events

```text
DATA_CLASSIFICATION_CREATED
DATA_CLASSIFICATION_CHANGED
DATA_SENSITIVE_FIELD_ACCESSED
DATA_MASKING_APPLIED
DATA_EXPORT_REQUESTED
DATA_EXPORTED
DATA_RETENTION_EXECUTED
DATA_DELETION_REQUESTED
DATA_DELETED
DATA_LEGAL_HOLD_APPLIED
DATA_CONSENT_GRANTED
DATA_CONSENT_REVOKED
DATA_RECONCILIATION_FAILED
```

---

# 117. Audit Metadata

```text
data_element_code
classification
category
actor
subject
purpose
scope
decision
masking_policy
export_id
correlation_id
```

---

# 118. Metrics

```text
data_catalog_element_total
data_unclassified_field_total
data_sensitive_access_total
data_masked_projection_total
data_export_total
data_bulk_export_total
data_retention_job_total
data_deletion_total
data_consent_revocation_total
data_reconciliation_failure_total
```

---

# 119. KPIs

```text
Production fields without classification = 0
Restricted fields without owner = 0
Restricted fields without access policy = 0
Bulk exports without audit = 0
Retention policies without execution = 0
Sensitive values in application logs = 0
Cross-tenant data access success = 0
```

---

# 120. KRIs

```text
Sensitive field count growth
Bulk export frequency
Masking bypass attempts
Overdue deletion
Legal hold volume
Consent-related failures
Unclassified schema growth
Sensitive log findings
Cross-border transfer volume
```

---

# 121. Database Direction

Potential tables:

```text
data_catalog_elements
data_classification_versions
data_purposes
data_processing_activities
data_consent_records
data_masking_policies
data_retention_policies
data_legal_holds
data_subject_requests
data_export_records
data_access_reviews
data_reconciliation_runs
data_reconciliation_findings
```

---

# 122. Table: data_catalog_elements

```sql
CREATE TABLE data_catalog_elements (
    id CHAR(26) NOT NULL,
    data_element_code VARCHAR(255) NOT NULL,
    asset_type VARCHAR(40) NOT NULL,
    asset_reference VARCHAR(500) NOT NULL,
    classification VARCHAR(30) NOT NULL,
    category_code VARCHAR(100) NOT NULL,
    sensitivity_flags_json JSON NULL,
    owner_reference VARCHAR(180) NOT NULL,
    purpose_codes_json JSON NOT NULL,
    masking_policy_code VARCHAR(180) NULL,
    retention_policy_code VARCHAR(180) NOT NULL,
    status VARCHAR(30) NOT NULL,
    current_version VARCHAR(100) NOT NULL,
    created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),

    PRIMARY KEY (id),
    UNIQUE KEY uq_data_catalog_element_code (
        data_element_code
    ),
    KEY idx_data_catalog_classification (
        classification,
        status
    ),
    KEY idx_data_catalog_owner (
        owner_reference,
        status
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

# 123. Table: data_masking_policies

```sql
CREATE TABLE data_masking_policies (
    id CHAR(26) NOT NULL,
    policy_code VARCHAR(180) NOT NULL,
    name VARCHAR(255) NOT NULL,
    masking_method VARCHAR(50) NOT NULL,
    rule_document_json JSON NOT NULL,
    owner_reference VARCHAR(180) NOT NULL,
    status VARCHAR(30) NOT NULL,
    current_version VARCHAR(100) NOT NULL,

    PRIMARY KEY (id),
    UNIQUE KEY uq_data_masking_policy_code (
        policy_code
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

# 124. Table: data_retention_policies

```sql
CREATE TABLE data_retention_policies (
    id CHAR(26) NOT NULL,
    policy_code VARCHAR(180) NOT NULL,
    name VARCHAR(255) NOT NULL,
    trigger_type VARCHAR(50) NOT NULL,
    duration_days INT NULL,
    retention_action VARCHAR(40) NOT NULL,
    legal_hold_behavior VARCHAR(40) NOT NULL,
    owner_reference VARCHAR(180) NOT NULL,
    status VARCHAR(30) NOT NULL,
    current_version VARCHAR(100) NOT NULL,

    PRIMARY KEY (id),
    UNIQUE KEY uq_data_retention_policy_code (
        policy_code
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

# 125. Table: data_consent_records

```sql
CREATE TABLE data_consent_records (
    id CHAR(26) NOT NULL,
    subject_id CHAR(26) NOT NULL,
    tenant_id CHAR(26) NOT NULL,
    purpose_code VARCHAR(180) NOT NULL,
    data_categories_json JSON NOT NULL,
    consent_version VARCHAR(100) NOT NULL,
    status VARCHAR(30) NOT NULL,
    granted_at DATETIME(6) NULL,
    valid_to DATETIME(6) NULL,
    revoked_at DATETIME(6) NULL,
    source_reference VARCHAR(500) NULL,

    PRIMARY KEY (id),
    KEY idx_data_consent_subject (
        tenant_id,
        subject_id,
        purpose_code,
        status
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

# 126. Table: data_export_records

```sql
CREATE TABLE data_export_records (
    id CHAR(26) NOT NULL,
    export_code VARCHAR(100) NOT NULL,
    tenant_id CHAR(26) NOT NULL,
    requested_by CHAR(26) NOT NULL,
    purpose_code VARCHAR(180) NOT NULL,
    export_type VARCHAR(40) NOT NULL,
    data_elements_json JSON NOT NULL,
    record_count BIGINT UNSIGNED NULL,
    status VARCHAR(30) NOT NULL,
    file_reference VARCHAR(1000) NULL,
    expires_at DATETIME(6) NULL,
    created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),

    PRIMARY KEY (id),
    UNIQUE KEY uq_data_export_code (export_code),
    KEY idx_data_export_tenant (
        tenant_id,
        status,
        created_at
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

# 127. API Direction

```text
GET  /api/internal/v1/data/catalog
POST /api/internal/v1/data/catalog
GET  /api/internal/v1/data/catalog/{dataElementCode}
POST /api/internal/v1/data/classifications/{dataElementCode}/review
GET  /api/internal/v1/data/masking-policies
GET  /api/internal/v1/data/retention-policies
POST /api/internal/v1/data/exports
POST /api/internal/v1/data/subject-requests
POST /api/internal/v1/data/legal-holds
POST /api/internal/v1/data/reconcile
```

---

# 128. Error Codes

```text
DATA_ELEMENT_NOT_FOUND
DATA_ELEMENT_UNCLASSIFIED
DATA_OWNER_REQUIRED
DATA_PURPOSE_INVALID
DATA_CONSENT_REQUIRED
DATA_CONSENT_INVALID
DATA_ACCESS_DENIED
DATA_MASKING_POLICY_MISSING
DATA_EXPORT_DENIED
DATA_EXPORT_APPROVAL_REQUIRED
DATA_RETENTION_POLICY_MISSING
DATA_LEGAL_HOLD_ACTIVE
DATA_DELETION_BLOCKED
DATA_TENANT_SCOPE_VIOLATION
DATA_RECONCILIATION_FAILED
```

---

# 129. Classification Checklist

- [ ] Data element identified.
- [ ] Owner assigned.
- [ ] Category selected.
- [ ] Classification selected.
- [ ] Sensitivity flags selected.
- [ ] Purpose defined.
- [ ] Access policy defined.
- [ ] Masking policy defined.
- [ ] Retention policy defined.
- [ ] Export policy defined.
- [ ] Logging policy defined.
- [ ] Review approved.

---

# 130. Export Checklist

- [ ] Requester authorized.
- [ ] Purpose valid.
- [ ] Scope valid.
- [ ] Fields minimized.
- [ ] Records minimized.
- [ ] Sensitive fields masked or approved.
- [ ] Approval completed where required.
- [ ] MFA completed where required.
- [ ] File encrypted.
- [ ] Expiry set.
- [ ] Watermark applied.
- [ ] Audit generated.

---

# 131. Deletion Checklist

- [ ] Request authority verified.
- [ ] Subject/resource identified.
- [ ] Retention evaluated.
- [ ] Legal hold checked.
- [ ] Dependencies identified.
- [ ] Backups considered.
- [ ] Deletion method selected.
- [ ] Audit evidence retained.
- [ ] Verification completed.
- [ ] Downstream systems notified.

---

# 132. UAT — Classification

- [ ] New field requires classification.
- [ ] Missing owner blocks approval.
- [ ] Default confidential classification applies.
- [ ] Restricted field requires stronger policy.
- [ ] Reclassification creates new version.
- [ ] Schema/catalog drift detected.
- [ ] Aggregation risk review works.
- [ ] Classification history retained.

---

# 133. UAT — Field-Level Access

- [ ] Full access returns full value.
- [ ] Masked access returns masked value.
- [ ] Redacted access omits value.
- [ ] Denied access returns no value.
- [ ] Wrong purpose denied.
- [ ] Wrong tenant denied.
- [ ] Wrong scope denied.
- [ ] Direct serializer bypass prevented.
- [ ] Decision audited.

---

# 134. UAT — Consent

- [ ] Valid consent accepted.
- [ ] Revoked consent rejected.
- [ ] Expired consent rejected.
- [ ] Wrong purpose rejected.
- [ ] Partial consent limits categories.
- [ ] Consent withdrawal propagates.
- [ ] Consent history retained.
- [ ] Operator permission still required.
- [ ] Non-required basis works per policy.

---

# 135. UAT — Masking

- [ ] National ID masks correctly.
- [ ] Email masks correctly.
- [ ] Phone masks correctly.
- [ ] Logs never contain full value.
- [ ] Search snippets respect masking.
- [ ] Export uses approved masking.
- [ ] UI cannot unmask without permission.
- [ ] Server-side masking enforced.
- [ ] Policy version recorded.

---

# 136. UAT — Export

- [ ] Single export succeeds with permission.
- [ ] Bulk export requires elevated permission.
- [ ] Wrong tenant denied.
- [ ] Field minimization enforced.
- [ ] Approval/MFA enforced.
- [ ] File encryption applied.
- [ ] Signed URL expires.
- [ ] Watermark present.
- [ ] Download audited.
- [ ] Expired export unavailable.

---

# 137. UAT — Retention & Deletion

- [ ] Retention trigger calculates correctly.
- [ ] Archive action works.
- [ ] Anonymization works.
- [ ] Deletion works.
- [ ] Legal hold blocks deletion.
- [ ] Backup restore reapplies tombstone.
- [ ] Downstream index removal works.
- [ ] Deletion verification recorded.
- [ ] Overdue retention alerts.

---

# 138. UAT — Tenant & Purpose Isolation

- [ ] Tenant A cannot access Tenant B data.
- [ ] Cross-tenant report blocked.
- [ ] Cache remains tenant-scoped.
- [ ] Search remains tenant-scoped.
- [ ] Export remains tenant-scoped.
- [ ] Purpose mismatch denied.
- [ ] Break-glass purpose audited.
- [ ] Tenant switch re-evaluates policy.
- [ ] Cross-border constraint enforced where configured.

---

# 139. UAT — Data Subject Requests

- [ ] Identity verification required.
- [ ] Access request returns scoped data.
- [ ] Correction request updates data.
- [ ] Export request creates secure package.
- [ ] Deletion request checks legal hold.
- [ ] Restriction request limits processing.
- [ ] Consent withdrawal processed.
- [ ] SLA tracked.
- [ ] Evidence retained.

---

# 140. UAT — Reconciliation

- [ ] Unclassified field detected.
- [ ] Missing owner detected.
- [ ] Missing masking policy detected.
- [ ] Retention drift detected.
- [ ] Unapproved export detected.
- [ ] Search overexposure detected.
- [ ] Logging overexposure detected.
- [ ] Consent policy drift detected.
- [ ] Critical finding opens case.
- [ ] Report generated.

---

# 141. Definition of Done — SSOT-DATA-06

SSOT-DATA-06 dianggap selesai bila:

- [ ] classification model tersedia;
- [ ] data categories and flags tersedia;
- [ ] data catalog and ownership tersedia;
- [ ] purpose limitation tersedia;
- [ ] consent governance tersedia;
- [ ] data minimization tersedia;
- [ ] field-level access tersedia;
- [ ] masking/redaction/tokenization tersedia;
- [ ] export governance tersedia;
- [ ] tenant/location controls tersedia;
- [ ] retention/legal hold tersedia;
- [ ] deletion/anonymization tersedia;
- [ ] data subject requests tersedia;
- [ ] lineage and access logging tersedia;
- [ ] module/schema registration tersedia;
- [ ] report/search/file/event/cache controls tersedia;
- [ ] review/certification tersedia;
- [ ] reconciliation tersedia;
- [ ] audit/logging/metrics tersedia;
- [ ] database direction tersedia;
- [ ] API direction tersedia;
- [ ] SDK contracts tersedia;
- [ ] error codes tersedia;
- [ ] checklists and UAT tersedia.

---

# 142. Implementation Roadmap

## Phase 1 — Data Catalog Foundation

- classification taxonomy;
- data element registry;
- ownership;
- schema annotations;
- migration quality gate;
- basic catalog API.

## Phase 2 — Access & Masking

- field-level policy;
- masking service;
- serializer integration;
- report/search integration;
- sensitive access logging;
- policy testing.

## Phase 3 — Purpose, Consent & Export

- purpose registry;
- consent records;
- export workflow;
- approval/MFA;
- encryption/watermark;
- recipient controls.

## Phase 4 — Retention & Subject Rights

- retention engine;
- legal hold;
- deletion/anonymization;
- backup tombstones;
- subject request workflow;
- verification evidence.

## Phase 5 — Continuous Privacy Governance

- automated discovery;
- lineage;
- DLP integration;
- privacy risk dashboard;
- cross-border policy;
- continuous reconciliation;
- compliance evidence automation.

---

# 143. Initial Implementation Backlog

```text
DATA06-001 Data Classification Taxonomy
DATA06-002 Data Catalog Registry
DATA06-003 Schema Classification Validator
DATA06-004 Field Access Policy
DATA06-005 Data Masking Service
DATA06-006 Purpose Registry
DATA06-007 Consent Service
DATA06-008 Export Governance Service
DATA06-009 Retention Policy Engine
DATA06-010 Legal Hold Service
DATA06-011 Deletion & Anonymization Service
DATA06-012 Subject Request Workflow
DATA06-013 Sensitive Access Audit
DATA06-014 Search/Report Privacy Integration
DATA06-015 Reconciliation Engine
DATA06-016 Privacy Governance Dashboard
```

---

# 144. Approval Gate

Dokumen dapat menjadi Approved setelah:

- Data Architecture review;
- Privacy/Data Protection review;
- Security Architecture review;
- RBAC/Scope review;
- Audit/Compliance review;
- Legal/Policy review where applicable;
- Module SDK review;
- Database review;
- Quality Engineering review;
- UAT review.

---

# 145. Closing Statement

Data governance harus memastikan bahwa setiap data element:

- memiliki owner;
- memiliki classification;
- memiliki purpose;
- memiliki access policy;
- memiliki masking policy;
- memiliki retention policy;
- memiliki export policy;
- dapat diaudit;
- dapat direkonsiliasi.

Data tidak boleh diakses hanya karena tersedia.

Data harus digunakan karena actor, scope, permission, purpose, dan context memang membenarkannya.
