
# SSOT-DATA-05 — Backup & Disaster Recovery

## Status Dokumen

| Item | Nilai |
|---|---|
| Kode | SSOT-DATA-05 |
| Domain | Platform Kernel / Data |
| Bergantung pada | SSOT-DATA-01 s.d. SSOT-DATA-04, SSOT-AUDIT |

# 1. Tujuan

Menetapkan standar backup, pemulihan, dan disaster recovery agar platform dapat dipulihkan dengan kehilangan data dan waktu henti yang terukur.

# 2. Prinsip

- Backup otomatis.
- Backup terenkripsi.
- Restore diuji berkala.
- Backup bukan pengganti High Availability.
- Semua aktivitas backup dan restore diaudit.

# 3. Strategi Backup

- Full backup
- Incremental backup
- Differential backup (opsional)
- Transaction log backup (bila didukung)

# 4. Frekuensi

Contoh:
- Full: mingguan
- Incremental: harian
- Transaction log: periodik sesuai kebutuhan bisnis

Frekuensi final mengikuti target RPO.

# 5. RPO & RTO

Definisikan per sistem:

- RPO (Recovery Point Objective)
- RTO (Recovery Time Objective)

Contoh:
- Platform IAM: RPO ≤ 15 menit
- EMR: ditentukan sesuai kebijakan organisasi

# 6. Enkripsi

Backup wajib:
- terenkripsi saat disimpan
- terenkripsi saat dikirim
- kunci dikelola terpisah

# 7. Lokasi Backup

Minimal:
- penyimpanan utama
- salinan di lokasi berbeda

Opsional:
- region berbeda
- immutable storage

# 8. Retensi Backup

Retensi mengikuti kebijakan organisasi dan regulasi.

Contoh kategori:
- harian
- mingguan
- bulanan
- tahunan

# 9. Restore

Restore harus mendukung:
- seluruh database
- tabel tertentu
- point-in-time (bila tersedia)

Restore wajib:
- terdokumentasi
- diaudit
- diverifikasi

# 10. Restore Test

Lakukan uji restore berkala.

Verifikasi:
- integritas data
- aplikasi dapat berjalan
- audit tetap konsisten

# 11. High Availability

Backup tidak menggantikan:
- replication
- clustering
- failover

HA dan backup adalah lapisan berbeda.

# 12. Disaster Recovery

Runbook minimal:
1. Identifikasi insiden.
2. Aktifkan tim.
3. Tentukan strategi pemulihan.
4. Restore/failover.
5. Validasi aplikasi.
6. Dokumentasi dan audit.

# 13. Monitoring

Pantau:
- backup gagal
- backup terlambat
- kapasitas penyimpanan
- restore gagal
- replikasi gagal

# 14. Audit

Event:
- backup.started
- backup.completed
- backup.failed
- restore.started
- restore.completed
- restore.failed
- dr.failover.started
- dr.failback.completed

# 15. Keamanan

- Akses backup dibatasi.
- Backup tidak boleh memakai shared account.
- Backup production tidak dipakai sebagai data uji tanpa anonymization.

# 16. Anti-pattern

Hindari:
- backup tidak pernah diuji
- hanya satu salinan backup
- backup tanpa enkripsi
- restore langsung di production tanpa validasi
- menganggap replication = backup

# 17. UAT

- Backup berhasil dibuat.
- Restore ke lingkungan uji berhasil.
- Audit backup tercatat.
- Integritas data tervalidasi.
- Target RPO/RTO diuji.

# 18. Definition of Done

- Strategi backup terdokumentasi.
- Restore dapat dilakukan.
- Disaster Recovery Runbook tersedia.
- Monitoring aktif.
- Audit backup & restore tersedia.
