# SSOT-SDK-04 — Module Registration & Bootstrap

---

## Status Dokumen

| Item | Nilai |
|---|---|
| Kode | SSOT-SDK-04 |
| Judul | Module Registration & Bootstrap |
| Versi | 1.0 |
| Status | Draft for Review |
| Domain | Platform Kernel |
| Kategori | Platform SDK, Module Runtime & Lifecycle |
| Cakupan | Discovery, Manifest Validation, Registration, Dependency Resolution, Bootstrap, Activation, Tenant Enablement, Health, Upgrade, Deactivation, Retirement |
| Bergantung pada | SSOT-SDK-01, SSOT-SDK-02, SSOT-SDK-03, SSOT-DEPLOY-02, SSOT-GOV-06 |
| Target Stack | PHP 8.1+, Composer, PSR-4, Modular Monolith |
| Target Evolusi | Package-ready, Multi-tenant Module Runtime, Remote Module Registry-ready |

---

# 1. Executive Summary

SSOT-SDK-04 menetapkan standar resmi untuk registration dan bootstrap lifecycle seluruh module pada Platform Kernel.

Dokumen ini mengatur:

- module discovery;
- package and source validation;
- manifest parsing;
- version validation;
- SDK compatibility;
- dependency resolution;
- cycle detection;
- capability declaration;
- service registration;
- route registration;
- permissions;
- configuration definitions;
- menu contributions;
- migrations;
- seeders;
- event subscriptions;
- scheduled tasks;
- health checks;
- activation;
- tenant/clinic enablement;
- upgrade;
- deactivation;
- failure isolation;
- rollback;
- retirement;
- audit;
- metrics;
- UAT;
- Definition of Done.

Tujuan akhirnya adalah memastikan setiap module:

- dikenal secara eksplisit;
- memiliki manifest valid;
- memiliki owner;
- memiliki version;
- kompatibel dengan SDK;
- memiliki dependencies yang valid;
- tidak menciptakan circular dependency;
- dapat diaktifkan secara aman;
- dapat dinonaktifkan secara terkendali;
- dapat di-upgrade;
- dapat diobservasi;
- dapat diaudit;
- tidak mengganggu module lain ketika gagal.

---

# 2. Objectives

Framework harus:

- menghindari hidden module discovery;
- memastikan deterministic bootstrap;
- memvalidasi compatibility sebelum runtime;
- mengendalikan dependencies;
- memastikan registration order;
- menjaga tenant-safe activation;
- mengisolasi failure;
- mendukung upgrade/rollback;
- menyediakan health visibility;
- menjaga complete audit trail.

---

# 3. Core Principles

```text
Explicit Registration
Manifest Before Execution
Validate Before Activate
Deterministic Order
No Circular Dependency
Fail Closed for Critical Module Errors
Tenant Enablement Is Explicit
Bootstrap Must Be Observable
Activation Must Be Reversible
Retirement Must Preserve Data Governance
```

---

# 4. Scope

Framework berlaku untuk:

```text
Platform Modules
Business Modules
Shared Capability Modules
Internal Extension Modules
Optional Tenant Modules
System Modules
Integration Modules
Reporting Modules
```

---

# 5. Non-Scope

Framework tidak mengatur secara detail:

- business logic internal module;
- UI design;
- public API design;
- database schema business module secara lengkap;
- plugin marketplace eksternal;
- remote microservice orchestration.

---

# 6. Module Lifecycle

```text
DISCOVERED
→ VALIDATING
→ REGISTERED
→ BOOTSTRAPPING
→ READY
→ ACTIVE
→ DEGRADED
→ DISABLED
→ DEPRECATED
→ RETIRED
→ FAILED
```

---

# 7. Lifecycle Status Definitions

## DISCOVERED

Module package/source ditemukan tetapi belum divalidasi.

## VALIDATING

Manifest, version, signature, dependency, dan capability sedang diperiksa.

## REGISTERED

Module sudah tercatat di registry tetapi belum diaktifkan.

## BOOTSTRAPPING

Service, extension, event, config, route, dan runtime hooks sedang dibentuk.

## READY

Bootstrap berhasil dan health check lulus.

## ACTIVE

Module aktif secara global atau untuk scope tenant yang diizinkan.

## DEGRADED

Module masih berjalan tetapi sebagian capability bermasalah.

## DISABLED

Module dinonaktifkan secara administratif atau operasional.

## DEPRECATED

Module masih didukung sementara namun dijadwalkan untuk diganti.

## RETIRED

Module tidak lagi tersedia untuk activation.

## FAILED

Registration/bootstrap/activation gagal.

---

# 8. Module Sources

Allowed module sources:

```text
IN_REPOSITORY
COMPOSER_PACKAGE
INTERNAL_ARTIFACT
SIGNED_EXTENSION_PACKAGE
REMOTE_REGISTRY_REFERENCE
```

---

# 9. Discovery Strategy

Recommended discovery methods:

```text
Explicit Module List
Composer Package Metadata
Approved Module Registry
Deployment Manifest
```

Avoid uncontrolled recursive filesystem scanning in production.

---

# 10. Explicit Module List

Example:

```php
return [
    App\Modules\Patient\Module\PatientModuleProvider::class,
    App\Modules\Homecare\Module\HomecareModuleProvider::class,
    App\Modules\Woundcare\Module\WoundcareModuleProvider::class,
];
```

---

# 11. Composer Discovery

Composer packages may declare module provider metadata.

Example:

```json
{
  "extra": {
    "platform-module": {
      "provider": "Vendor\\Module\\ModuleProvider",
      "manifest": "module.yaml"
    }
  }
}
```

---

# 12. Discovery Security

Discovery must not execute arbitrary module code before trust and manifest validation.

---

# 13. Module Package Validation

Validate:

- source;
- signature;
- checksum;
- package name;
- manifest;
- version;
- owner;
- dependencies;
- SDK constraints;
- prohibited files;
- malware scan where applicable.

---

# 14. Package Integrity

Module package should have:

```text
artifact_id
sha256
signature
sbom
source_reference
build_id
```

---

# 15. Module Manifest

Manifest is the authoritative declaration of module identity and requirements.

---

# 16. Manifest Minimum Fields

```text
module_id
name
description
version
sdk_version
provider
owner
status
dependencies
capabilities_required
capabilities_provided
permissions
configuration
migrations
seeders
events
routes
menu
jobs
health_checks
```

---

# 17. Manifest Example

```yaml
module_id: homecare
name: Homecare
description: Homecare visit management
version: 1.4.0
sdk_version: "^1.2"
provider: App\Modules\Homecare\Module\HomecareModuleProvider
owner: homecare_team
status: ACTIVE

dependencies:
  - module: patient
    version: ">=1.2 <2.0"
    optional: false

capabilities_required:
  identity: "^1.0"
  authorization: "^1.1"
  audit: "^1.0"
  workflow: "^2.0"
  notification: "^1.0"

capabilities_provided:
  homecare.visit: "1.0"

permissions:
  - homecare.visit.view
  - homecare.visit.create
  - homecare.visit.assign
  - homecare.visit.complete

configuration:
  - homecare.visit.max_daily_assignments
  - homecare.visit.allow_reschedule

migrations:
  - 202607050001_create_homecare_tables

health_checks:
  - homecare.database
  - homecare.workflow
```

---

# 18. Manifest Schema

Manifest must be validated against a versioned schema.

---

# 19. Manifest Schema Version

Recommended:

```text
manifest_schema: "1.0"
```

---

# 20. Manifest Validation Result

```text
VALID
VALID_WITH_WARNING
INVALID
UNSUPPORTED_SCHEMA
```

---

# 21. Manifest Error Examples

```text
MODULE_ID_MISSING
MODULE_VERSION_INVALID
SDK_CONSTRAINT_INVALID
PROVIDER_CLASS_INVALID
DEPENDENCY_INVALID
CAPABILITY_INVALID
PERMISSION_DUPLICATE
MIGRATION_DUPLICATE
```

---

# 22. Module ID Rules

Module ID must:

- be globally unique;
- use lowercase kebab-case or snake_case consistently;
- remain stable across versions;
- not be reused after retirement for unrelated module.

---

# 23. Module Name

Display name may change.

Module ID must not change casually.

---

# 24. Module Version

Use semantic versioning.

---

# 25. SDK Constraint

Every module must declare supported SDK range.

---

# 26. Module Owner

Every module must have accountable owner.

---

# 27. Module Classification

Recommended:

```text
CORE
SHARED
BUSINESS
INTEGRATION
REPORTING
OPTIONAL
EXPERIMENTAL
```

---

# 28. Criticality

```text
CRITICAL
HIGH
MEDIUM
LOW
```

---

# 29. Core Module

Core module may be required for platform startup.

---

# 30. Optional Module

Optional module may fail or remain disabled without blocking platform startup, subject to dependency impact.

---

# 31. Dependency Descriptor

Minimum:

```text
module_id
version_constraint
optional
activation_required
```

---

# 32. Dependency Types

```text
REQUIRED
OPTIONAL
RUNTIME
BUILD_TIME
MIGRATION_ONLY
```

---

# 33. Dependency Resolution

Resolution steps:

```text
Collect Dependencies
→ Validate Versions
→ Build Graph
→ Detect Cycles
→ Topological Sort
→ Verify Availability
→ Produce Activation Order
```

---

# 34. Dependency Graph

Registry should expose module dependency graph.

---

# 35. Circular Dependency

Circular dependencies are prohibited.

---

# 36. Cycle Detection

Cycle detection must run:

- during CI;
- module installation;
- startup;
- upgrade;
- activation.

---

# 37. Optional Dependency

Optional dependency must define behavior when absent.

---

# 38. Missing Required Dependency

Must block registration or activation.

---

# 39. Dependency Version Conflict

Must block activation.

---

# 40. Dependency Activation Order

Required dependencies activate before dependent module.

---

# 41. Reverse Dependency Check

Before deactivation/retirement, identify dependent modules.

---

# 42. Capability Declaration

Modules declare required and provided capabilities.

---

# 43. Required Capability Validation

Validate:

- capability exists;
- version compatible;
- owner exists;
- capability active;
- environment support exists.

---

# 44. Provided Capability Registration

Provided capability must include:

```text
name
version
contract
stability
owner
```

---

# 45. Capability Conflict

Two providers for same exclusive capability must trigger conflict unless multi-provider policy exists.

---

# 46. Multi-Provider Capability

Allowed only when registry defines selection strategy.

---

# 47. Selection Strategies

```text
PRIMARY
PRIORITY
ROUND_ROBIN
ALL
TENANT_SPECIFIC
```

---

# 48. Module Provider

Provider is module bootstrap entrypoint.

---

# 49. Module Provider Interface

```php
interface ModuleProviderInterface
{
    public function manifest(): ModuleManifestInterface;

    public function register(ModuleRegistryInterface $registry): void;

    public function boot(ModuleRuntimeContext $context): void;
}
```

---

# 50. Registration Phase

Registration phase should:

- declare bindings;
- register capabilities;
- register extensions;
- register config definitions;
- register permissions;
- avoid external I/O;
- avoid database writes;
- avoid network calls.

---

# 51. Bootstrap Phase

Bootstrap phase may:

- validate runtime dependencies;
- register event subscribers;
- register scheduled tasks;
- register health checks;
- initialize adapters;
- validate config;
- verify migration state.

---

# 52. Activation Phase

Activation phase makes module available to runtime traffic.

---

# 53. Phase Separation

```text
DISCOVERY
VALIDATION
REGISTRATION
BOOTSTRAP
READINESS
ACTIVATION
```

Each phase must be independently observable.

---

# 54. Registration Context

Registration context should provide only safe registry operations.

---

# 55. Runtime Context

Runtime context may provide approved capabilities, environment, correlation, and health reporter.

---

# 56. Service Registration

Allowed registration:

- interface-to-implementation;
- factories;
- decorators;
- module-scoped services;
- adapters.

---

# 57. Service Registration Rules

- contract must be explicit;
- duplicate binding policy must be defined;
- service lifetime must be declared;
- implementation must be compatible;
- internal services remain private.

---

# 58. Service Lifetimes

```text
SINGLETON
REQUEST
TRANSIENT
MODULE
JOB
```

---

# 59. Global Service Registration

Global services require architecture review.

---

# 60. Service Override

Service override is prohibited unless extension policy explicitly allows it.

---

# 61. Route Registration

Routes must define:

```text
method
path
handler
permission
tenant_scope
name
```

---

# 62. Route Conflict

Duplicate route name or path/method conflict must block activation.

---

# 63. Route Security

Every protected route must declare authorization behavior.

---

# 64. Route Naming

Recommended:

```text
module.resource.action
```

Example:

```text
homecare.visit.assign
```

---

# 65. Permission Registration

Permissions must be:

- globally unique;
- namespaced by module;
- owned;
- documented;
- seeded idempotently.

---

# 66. Permission Naming

Recommended:

```text
module.resource.action
```

---

# 67. Permission Conflict

Duplicate permission with different meaning is prohibited.

---

# 68. Configuration Registration

Module must register config definitions before reading values.

---

# 69. Config Definition Requirements

```text
key
type
default
required
tenant_overridable
clinic_overridable
sensitive
owner
validation
```

---

# 70. Config Validation

Invalid required config blocks readiness.

---

# 71. Feature Flag Registration

Flags must define:

- key;
- type;
- safe default;
- owner;
- expiry;
- targeting scope.

---

# 72. Menu Registration

Menu contributions require:

- code;
- label;
- route;
- permission;
- parent;
- order;
- feature flag optional.

---

# 73. Menu Conflict

Duplicate menu code must block module activation or use explicit override policy.

---

# 74. Event Subscriber Registration

Subscribers must declare:

- event type;
- supported version;
- handler;
- priority;
- retry policy.

---

# 75. Event Publisher Declaration

Published events should be listed in manifest.

---

# 76. Event Version Validation

Unsupported event version must fail clearly.

---

# 77. Scheduled Task Registration

Tasks must define:

```text
task_code
schedule
handler
owner
timeout
overlap_policy
retry_policy
tenant_scope
```

---

# 78. Task Conflict

Duplicate task code is prohibited.

---

# 79. Job Handler Registration

Job types must be unique and versioned where payload evolves.

---

# 80. Health Check Registration

Modules should register health checks for critical dependencies.

---

# 81. Health Check Types

```text
READINESS
LIVENESS
DEPENDENCY
DEGRADED_SERVICE
```

---

# 82. Health Check Requirements

- fast;
- bounded timeout;
- safe;
- no secret exposure;
- clear result;
- owner.

---

# 83. Health Status

```text
HEALTHY
DEGRADED
UNHEALTHY
UNKNOWN
```

---

# 84. Module Readiness

Module is READY only when:

- manifest valid;
- SDK compatible;
- dependencies active;
- capabilities available;
- required config valid;
- migrations current;
- health checks pass;
- registration completed.

---

# 85. Readiness Gate Result

```text
PASS
PASS_WITH_WARNING
FAIL
UNKNOWN
```

---

# 86. Activation Policy

Activation requires readiness PASS.

`PASS_WITH_WARNING` may require explicit approval.

---

# 87. Global Activation

Global activation makes module available platform-wide, subject to tenant enablement.

---

# 88. Tenant Activation

Tenant activation enables module for one tenant.

---

# 89. Clinic Activation

Clinic activation may be supported when module design allows.

---

# 90. Tenant Enablement Record

Minimum:

```text
tenant_id
module_id
module_version
status
enabled_at
enabled_by
config_version
license_reference
```

---

# 91. Tenant Enablement Status

```text
REQUESTED
VALIDATING
ENABLED
DISABLED
SUSPENDED
FAILED
```

---

# 92. Tenant Enablement Preconditions

- module globally active;
- tenant valid;
- entitlement/license valid where applicable;
- dependencies enabled;
- config valid;
- permissions seeded;
- migrations ready;
- health acceptable.

---

# 93. Tenant-Specific Dependencies

If module depends on another tenant-enabled module, dependency must also be enabled for that tenant.

---

# 94. Tenant Disablement

Disablement should:

- block new operations;
- preserve data;
- handle active workflows;
- stop tenant-scoped jobs;
- hide menu;
- preserve audit.

---

# 95. Suspension

Suspension is temporary operational disablement.

---

# 96. Module Bootstrap Order

Recommended:

```text
Core Infrastructure
→ Identity/Tenancy
→ Authorization
→ Audit/Observability
→ Shared Capabilities
→ Business Modules
→ Optional Integrations
```

---

# 97. Deterministic Ordering

Activation order must derive from dependency graph plus stable priority.

---

# 98. Bootstrap Priority

Priority may resolve independent modules only.

It must not override dependency order.

---

# 99. Bootstrap Transaction

Registration metadata may use transaction.

Runtime side effects should be carefully staged.

---

# 100. Partial Bootstrap Failure

On failure:

- mark module FAILED;
- rollback reversible registration;
- disable routes/jobs/subscribers;
- preserve logs and evidence;
- assess dependent modules.

---

# 101. Failure Isolation

Optional module failure should not crash unrelated modules.

---

# 102. Critical Module Failure

Critical core module failure may block platform readiness.

---

# 103. Degraded Module

Module may be DEGRADED when optional dependency fails but core service remains usable.

---

# 104. Failure Policy

Each module should declare:

```text
FAIL_PLATFORM
FAIL_MODULE
DEGRADE_MODULE
DISABLE_FEATURE
```

---

# 105. Bootstrap Timeout

Each phase should have bounded timeout.

---

# 106. Retry Policy

Bootstrap retry allowed only for transient failures.

---

# 107. Idempotent Bootstrap

Registration and bootstrap must be safe to repeat.

---

# 108. Registration Ledger

Track completed bootstrap steps.

---

# 109. Bootstrap Ledger Fields

```text
module_id
module_version
phase
step
status
started_at
completed_at
error_code
```

---

# 110. Migration Registration

Module migrations must be registered before execution.

---

# 111. Migration Ownership

Module owns its own schema migrations.

---

# 112. Migration Naming

Recommended:

```text
YYYYMMDDHHMMSS_module_description
```

---

# 113. Migration Ordering

Global order must be deterministic.

---

# 114. Cross-Module Foreign Keys

Use cautiously.

Prefer stable IDs/events/contracts over tight database coupling.

---

# 115. Migration Preconditions

- backup ready;
- compatible SDK;
- dependency migrations applied;
- checksum valid;
- environment approved.

---

# 116. Migration Failure

Must block activation if schema is required.

---

# 117. Seeder Registration

Seeders should be:

- idempotent;
- versioned;
- environment-aware;
- tenant-aware where applicable.

---

# 118. Permission Seeder

Permission seeding must avoid duplicates and semantic drift.

---

# 119. Tenant Seeder

Tenant-specific seeders require explicit scope.

---

# 120. Module Installation

Installation flow:

```text
Acquire Package
→ Verify Artifact
→ Parse Manifest
→ Validate SDK
→ Resolve Dependencies
→ Register Module
→ Register Definitions
→ Run Migrations
→ Run Seeders
→ Bootstrap
→ Health Check
→ Activate
```

---

# 121. Installation Status

```text
REQUESTED
VALIDATING
INSTALLING
MIGRATING
BOOTSTRAPPING
READY
COMPLETED
FAILED
ROLLED_BACK
```

---

# 122. Installation Rollback

Rollback may include:

- unregister module;
- remove routes/jobs/subscribers;
- revert config definitions if safe;
- reverse migration if safe;
- preserve evidence.

---

# 123. Module Upgrade

Upgrade flow:

```text
Assess Compatibility
→ Backup
→ Disable New Traffic if Needed
→ Install New Artifact
→ Run Migrations
→ Bootstrap New Version
→ Verify
→ Switch Active Version
→ Hypercare
```

---

# 124. Side-by-Side Version

May be used only when runtime supports version isolation.

---

# 125. Upgrade Preconditions

- target version certified;
- SDK compatible;
- dependencies compatible;
- migration plan ready;
- rollback/forward plan ready;
- config migration ready;
- UAT passed.

---

# 126. Upgrade Failure

Use rollback or roll-forward based on schema/data compatibility.

---

# 127. Module Downgrade

Allowed only when:

- prior version retained;
- schema compatible;
- event/data changes reversible;
- dependency constraints satisfied.

---

# 128. Module Deactivation

Deactivation flow:

```text
Assess Dependents
→ Block New Work
→ Drain Jobs
→ Stop Schedules
→ Remove Routes/Menu
→ Unsubscribe Events
→ Verify
→ Mark Disabled
```

---

# 129. Deactivation Preconditions

- dependent modules assessed;
- active workflows assessed;
- jobs drained;
- data retention defined;
- communication completed.

---

# 130. Force Deactivation

Allowed only during incident/emergency.

Requires retrospective review.

---

# 131. Module Uninstall

Uninstall is different from deactivate.

Uninstall removes executable package and registration, not necessarily business data.

---

# 132. Uninstall Preconditions

- module disabled;
- dependencies clear;
- data disposition approved;
- audit retained;
- backups available;
- migrations handled.

---

# 133. Data Preservation

Module uninstall must not blindly drop data.

---

# 134. Module Retirement

Retirement lifecycle:

```text
Deprecate
→ Announce
→ Stop New Enablement
→ Migrate Consumers
→ Disable
→ Archive Data/Contracts
→ Retire
```

---

# 135. Retirement Record

Minimum:

```text
module_id
replacement
deprecated_at
new_enablement_end
support_end
retired_at
data_disposition
owner
```

---

# 136. Module Replacement

Replacement plan should map:

- features;
- data;
- permissions;
- events;
- routes;
- workflows;
- tenant configuration.

---

# 137. Runtime Registry

Runtime registry should expose:

- modules;
- versions;
- status;
- capabilities;
- dependencies;
- health;
- tenant enablement;
- certification.

---

# 138. Registry Contract

```php
interface RuntimeModuleRegistryInterface
{
    public function get(string $moduleId): ModuleRuntimeRecord;

    public function all(): array;

    public function active(): array;

    public function dependenciesOf(string $moduleId): array;

    public function dependentsOf(string $moduleId): array;
}
```

---

# 139. Module Runtime Record

```php
final readonly class ModuleRuntimeRecord
{
    public function __construct(
        public string $moduleId,
        public string $version,
        public string $status,
        public string $compatibilityStatus,
        public string $healthStatus,
        public array $capabilities,
        public array $dependencies,
    ) {
    }
}
```

---

# 140. Registry Persistence

Persistent registry should survive restart.

---

# 141. Registry as Source of Truth

The registry must distinguish:

```text
Installed
Registered
Active
Tenant Enabled
Healthy
Certified
```

---

# 142. Cache

Runtime registry may be cached but source state must remain authoritative.

---

# 143. Registry Drift

Detect differences between:

- installed package;
- manifest;
- database registry;
- active runtime;
- deployment manifest.

---

# 144. Drift Severity

```text
LOW
MEDIUM
HIGH
CRITICAL
```

---

# 145. Critical Drift Examples

- active module absent from registry;
- package hash mismatch;
- wrong active version;
- required dependency missing;
- uncertified version active;
- tenant enabled while global module disabled.

---

# 146. Drift Response

```text
Detect
→ Block if Critical
→ Alert
→ Reconcile
→ Verify
→ Record
```

---

# 147. Security Controls

Registration/bootstrap must enforce:

- package integrity;
- approved provider class;
- least privilege capabilities;
- tenant-safe config;
- permission registration;
- no raw secret exposure;
- audit trail;
- restricted plugin trust.

---

# 148. Provider Trust

Only approved provider namespaces/classes may be instantiated.

---

# 149. Arbitrary Code Execution Risk

Module package installation is privileged and must be restricted.

---

# 150. Capability Least Privilege

Module receives only declared capabilities.

---

# 151. Secret Access

Secret capability access requires explicit declaration and review.

---

# 152. Filesystem Access

Modules should not receive unrestricted filesystem access.

---

# 153. Database Access

Modules should use owned repositories/connections and approved transaction boundaries.

---

# 154. Cross-Tenant Protection

Tenant-enabled module operations must use trusted tenant context.

---

# 155. Audit Events

Critical events:

```text
MODULE_DISCOVERED
MODULE_VALIDATED
MODULE_REGISTERED
MODULE_BOOTSTRAP_STARTED
MODULE_READY
MODULE_ACTIVATED
MODULE_DEGRADED
MODULE_DISABLED
MODULE_FAILED
MODULE_UPGRADE_STARTED
MODULE_UPGRADE_COMPLETED
MODULE_RETIRED
TENANT_MODULE_ENABLED
TENANT_MODULE_DISABLED
```

---

# 156. Observability

Bootstrap logs should include:

- module ID;
- version;
- phase;
- duration;
- result;
- error code;
- dependency state;
- correlation ID.

---

# 157. Metrics

```text
module_total
module_active_total
module_failed_total
module_degraded_total
module_bootstrap_duration_seconds
module_activation_failure_total
module_dependency_failure_total
module_health_failure_total
tenant_module_enabled_total
module_registry_drift_total
```

---

# 158. KPIs

Initial targets:

```text
Active modules without valid manifest = 0
Circular dependencies = 0
Incompatible module activation = 0
Critical module bootstrap failures unresolved = 0
Tenant enablement without dependency readiness = 0
Registry critical drift = 0
```

---

# 159. KRIs

```text
Failed bootstrap rate
Uncertified active modules
Repeated module degradation
Long bootstrap duration
Dependency conflict count
Emergency force deactivation count
Registry drift count
```

---

# 160. Module Dashboard

Recommended:

- modules by lifecycle status;
- versions;
- SDK compatibility;
- dependency graph;
- health;
- tenant enablement;
- bootstrap failures;
- migrations;
- deprecations;
- registry drift.

---

# 161. Administrative API Direction

Potential endpoints:

```text
GET  /api/internal/v1/modules
GET  /api/internal/v1/modules/{moduleId}
POST /api/internal/v1/modules/discover
POST /api/internal/v1/modules/{moduleId}/validate
POST /api/internal/v1/modules/{moduleId}/register
POST /api/internal/v1/modules/{moduleId}/bootstrap
POST /api/internal/v1/modules/{moduleId}/activate
POST /api/internal/v1/modules/{moduleId}/deactivate
POST /api/internal/v1/modules/{moduleId}/upgrade
GET  /api/internal/v1/modules/{moduleId}/health
```

---

# 162. Tenant Module API Direction

```text
GET  /api/internal/v1/tenants/{tenantId}/modules
POST /api/internal/v1/tenants/{tenantId}/modules/{moduleId}/enable
POST /api/internal/v1/tenants/{tenantId}/modules/{moduleId}/disable
GET  /api/internal/v1/tenants/{tenantId}/modules/{moduleId}/status
```

---

# 163. API Security

Administrative endpoints require privileged permission, strong audit, and tenant scope where applicable.

---

# 164. Database Direction

Potential tables:

```text
sdk_modules
sdk_module_versions
sdk_module_dependencies
sdk_module_capabilities
sdk_module_registrations
sdk_module_bootstrap_runs
sdk_module_health
sdk_module_migrations
sdk_module_tenant_enablements
sdk_module_lifecycle_events
sdk_module_retirements
```

---

# 165. Table: sdk_modules

```sql
CREATE TABLE sdk_modules (
    id CHAR(26) NOT NULL,
    module_code VARCHAR(100) NOT NULL,
    name VARCHAR(255) NOT NULL,
    classification VARCHAR(30) NOT NULL,
    criticality VARCHAR(30) NOT NULL,
    owner_reference VARCHAR(180) NOT NULL,
    lifecycle_status VARCHAR(30) NOT NULL,
    current_version VARCHAR(100) NULL,
    created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    updated_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6)
        ON UPDATE CURRENT_TIMESTAMP(6),

    PRIMARY KEY (id),
    UNIQUE KEY uq_sdk_module_code (
        module_code
    ),
    KEY idx_sdk_module_lifecycle (
        lifecycle_status,
        criticality
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

# 166. Table: sdk_module_versions

```sql
CREATE TABLE sdk_module_versions (
    id CHAR(26) NOT NULL,
    module_id CHAR(26) NOT NULL,
    module_version VARCHAR(100) NOT NULL,
    sdk_version_constraint VARCHAR(100) NOT NULL,
    manifest_schema_version VARCHAR(50) NOT NULL,
    manifest_json JSON NOT NULL,
    artifact_sha256 CHAR(64) NULL,
    certification_status VARCHAR(30) NOT NULL,
    status VARCHAR(30) NOT NULL,
    created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),

    PRIMARY KEY (id),
    UNIQUE KEY uq_sdk_module_version (
        module_id,
        module_version
    ),
    CONSTRAINT fk_sdk_module_version_module
        FOREIGN KEY (module_id)
        REFERENCES sdk_modules (id)
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

# 167. Table: sdk_module_dependencies

```sql
CREATE TABLE sdk_module_dependencies (
    id CHAR(26) NOT NULL,
    module_version_id CHAR(26) NOT NULL,
    dependency_module_code VARCHAR(100) NOT NULL,
    version_constraint VARCHAR(100) NOT NULL,
    dependency_type VARCHAR(30) NOT NULL,
    optional_flag TINYINT(1) NOT NULL DEFAULT 0,

    PRIMARY KEY (id),
    UNIQUE KEY uq_sdk_module_dependency (
        module_version_id,
        dependency_module_code,
        dependency_type
    ),
    CONSTRAINT fk_sdk_module_dependency_version
        FOREIGN KEY (module_version_id)
        REFERENCES sdk_module_versions (id)
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

# 168. Table: sdk_module_bootstrap_runs

```sql
CREATE TABLE sdk_module_bootstrap_runs (
    id CHAR(26) NOT NULL,
    module_version_id CHAR(26) NOT NULL,
    bootstrap_code VARCHAR(100) NOT NULL,
    phase VARCHAR(30) NOT NULL,
    status VARCHAR(30) NOT NULL,
    started_at DATETIME(6) NOT NULL,
    completed_at DATETIME(6) NULL,
    duration_ms BIGINT UNSIGNED NULL,
    error_code VARCHAR(100) NULL,
    error_summary VARCHAR(1000) NULL,
    correlation_id VARCHAR(100) NOT NULL,

    PRIMARY KEY (id),
    UNIQUE KEY uq_sdk_bootstrap_code (
        bootstrap_code
    ),
    KEY idx_sdk_bootstrap_status (
        status,
        phase,
        started_at
    ),
    CONSTRAINT fk_sdk_bootstrap_module_version
        FOREIGN KEY (module_version_id)
        REFERENCES sdk_module_versions (id)
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

# 169. Table: sdk_module_tenant_enablements

```sql
CREATE TABLE sdk_module_tenant_enablements (
    id CHAR(26) NOT NULL,
    tenant_id CHAR(26) NOT NULL,
    module_id CHAR(26) NOT NULL,
    module_version VARCHAR(100) NOT NULL,
    status VARCHAR(30) NOT NULL,
    config_version VARCHAR(100) NULL,
    license_reference VARCHAR(255) NULL,
    enabled_by VARCHAR(180) NULL,
    enabled_at DATETIME(6) NULL,
    disabled_at DATETIME(6) NULL,

    PRIMARY KEY (id),
    UNIQUE KEY uq_sdk_tenant_module (
        tenant_id,
        module_id
    ),
    KEY idx_sdk_tenant_module_status (
        tenant_id,
        status
    ),
    CONSTRAINT fk_sdk_tenant_module_module
        FOREIGN KEY (module_id)
        REFERENCES sdk_modules (id)
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

# 170. Table: sdk_module_health

```sql
CREATE TABLE sdk_module_health (
    id CHAR(26) NOT NULL,
    module_id CHAR(26) NOT NULL,
    module_version VARCHAR(100) NOT NULL,
    health_status VARCHAR(30) NOT NULL,
    readiness_result VARCHAR(30) NOT NULL,
    details_json JSON NULL,
    checked_at DATETIME(6) NOT NULL,

    PRIMARY KEY (id),
    KEY idx_sdk_module_health (
        module_id,
        health_status,
        checked_at
    ),
    CONSTRAINT fk_sdk_module_health_module
        FOREIGN KEY (module_id)
        REFERENCES sdk_modules (id)
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

# 171. Module Event Codes

```text
SDK_MODULE_DISCOVERED
SDK_MODULE_PACKAGE_VERIFIED
SDK_MODULE_MANIFEST_VALIDATED
SDK_MODULE_REGISTERED
SDK_MODULE_BOOTSTRAP_STARTED
SDK_MODULE_BOOTSTRAP_COMPLETED
SDK_MODULE_READY
SDK_MODULE_ACTIVATED
SDK_MODULE_DEGRADED
SDK_MODULE_FAILED
SDK_MODULE_DISABLED
SDK_MODULE_UPGRADE_STARTED
SDK_MODULE_UPGRADE_COMPLETED
SDK_MODULE_RETIRED
SDK_TENANT_MODULE_ENABLED
SDK_TENANT_MODULE_DISABLED
SDK_MODULE_REGISTRY_DRIFT_DETECTED
```

---

# 172. Module Error Codes

```text
SDK_MODULE_NOT_FOUND
SDK_MODULE_ID_DUPLICATE
SDK_MODULE_PACKAGE_INVALID
SDK_MODULE_SIGNATURE_INVALID
SDK_MODULE_MANIFEST_INVALID
SDK_MODULE_SCHEMA_UNSUPPORTED
SDK_MODULE_VERSION_INVALID
SDK_MODULE_SDK_INCOMPATIBLE
SDK_MODULE_DEPENDENCY_MISSING
SDK_MODULE_DEPENDENCY_CONFLICT
SDK_MODULE_DEPENDENCY_CYCLE
SDK_MODULE_CAPABILITY_MISSING
SDK_MODULE_SERVICE_CONFLICT
SDK_MODULE_ROUTE_CONFLICT
SDK_MODULE_PERMISSION_CONFLICT
SDK_MODULE_CONFIG_INVALID
SDK_MODULE_MIGRATION_FAILED
SDK_MODULE_BOOTSTRAP_FAILED
SDK_MODULE_HEALTH_FAILED
SDK_MODULE_ACTIVATION_BLOCKED
SDK_MODULE_TENANT_DEPENDENCY_MISSING
SDK_MODULE_DEACTIVATION_BLOCKED
SDK_MODULE_REGISTRY_DRIFT
```

---

# 173. Reference Module Registry Configuration

```php
<?php

declare(strict_types=1);

return [
    'modules' => [
        App\Modules\Patient\Module\PatientModuleProvider::class,
        App\Modules\Homecare\Module\HomecareModuleProvider::class,
        App\Modules\Woundcare\Module\WoundcareModuleProvider::class,
    ],
];
```

---

# 174. Reference Bootstrap Runner

```php
final class ModuleBootstrapRunner
{
    public function __construct(
        private ModuleDiscoveryInterface $discovery,
        private ModuleValidatorInterface $validator,
        private DependencyResolverInterface $dependencies,
        private RuntimeModuleRegistryInterface $registry,
        private ModuleHealthRegistryInterface $health,
    ) {
    }

    public function run(): void
    {
        $modules = $this->discovery->discover();
        $validated = $this->validator->validateAll($modules);
        $ordered = $this->dependencies->resolveOrder($validated);

        foreach ($ordered as $module) {
            $this->registry->register($module);
            $module->provider()->register($this->registry);
            $module->provider()->boot(
                $this->registry->runtimeContext($module)
            );

            $this->health->assertReady($module->id());
            $this->registry->activate($module->id());
        }
    }
}
```

---

# 175. Reference Dependency Resolution Result

```yaml
activation_order:
  - identity
  - tenancy
  - authorization
  - audit
  - patient
  - homecare
  - woundcare

warnings:
  - reporting module optional dependency analytics unavailable
```

---

# 176. Reference Tenant Enablement

```yaml
tenant_id: tenant-001
module_id: homecare
module_version: 1.4.0
status: ENABLED
config_version: CFG-TENANT-001-HOMECARE-004
dependencies:
  patient: ENABLED
permissions_seeded: true
health: HEALTHY
```

---

# 177. Module Discovery Checklist

- [ ] Source approved.
- [ ] Provider listed explicitly.
- [ ] Package checksum valid.
- [ ] Signature valid where required.
- [ ] Manifest present.
- [ ] No prohibited file.
- [ ] SBOM available where required.
- [ ] Owner identified.

---

# 178. Manifest Validation Checklist

- [ ] Module ID valid.
- [ ] Version valid.
- [ ] SDK constraint valid.
- [ ] Provider class valid.
- [ ] Owner defined.
- [ ] Dependencies valid.
- [ ] Capabilities valid.
- [ ] Permissions unique.
- [ ] Config definitions valid.
- [ ] Migration IDs unique.
- [ ] Health checks declared.
- [ ] Manifest schema supported.

---

# 179. Registration Checklist

- [ ] Registry record created.
- [ ] Services registered.
- [ ] Capabilities registered.
- [ ] Extensions registered.
- [ ] Permissions registered.
- [ ] Config definitions registered.
- [ ] Routes checked.
- [ ] Menu checked.
- [ ] Events registered.
- [ ] Jobs/tasks registered.
- [ ] No conflicts found.

---

# 180. Readiness Checklist

- [ ] SDK compatible.
- [ ] Required dependencies active.
- [ ] Required capabilities available.
- [ ] Required config valid.
- [ ] Migrations current.
- [ ] Seeders successful.
- [ ] Health checks pass.
- [ ] No critical drift.
- [ ] Certification valid.
- [ ] Readiness result PASS.

---

# 181. Tenant Enablement Checklist

- [ ] Global module active.
- [ ] Tenant valid.
- [ ] Entitlement valid.
- [ ] Dependencies enabled.
- [ ] Tenant config valid.
- [ ] Permissions seeded.
- [ ] Tenant data initialization complete.
- [ ] Health acceptable.
- [ ] Audit event recorded.
- [ ] Menu visibility updated.

---

# 182. Module Upgrade Checklist

- [ ] Target artifact verified.
- [ ] Compatibility passes.
- [ ] Dependencies compatible.
- [ ] Backup ready.
- [ ] Migration tested.
- [ ] Config migration ready.
- [ ] Rollback/forward plan ready.
- [ ] Staging UAT passes.
- [ ] Active workflows assessed.
- [ ] Hypercare defined.

---

# 183. Module Deactivation Checklist

- [ ] Dependents assessed.
- [ ] New work blocked.
- [ ] Active work drained.
- [ ] Jobs stopped.
- [ ] Schedules stopped.
- [ ] Routes/menu removed.
- [ ] Event subscriptions disabled.
- [ ] Data preserved.
- [ ] Audit retained.
- [ ] Status updated.

---

# 184. UAT — Discovery & Manifest

- [ ] Explicit discovery works.
- [ ] Unknown package rejected.
- [ ] Invalid checksum rejected.
- [ ] Invalid signature rejected.
- [ ] Missing manifest rejected.
- [ ] Unsupported schema rejected.
- [ ] Duplicate module ID rejected.
- [ ] Invalid SDK constraint rejected.
- [ ] Owner required.
- [ ] Manifest errors are clear.

---

# 185. UAT — Dependency Resolution

- [ ] Required dependency resolves.
- [ ] Optional dependency may be absent.
- [ ] Version conflict detected.
- [ ] Missing dependency blocks activation.
- [ ] Circular dependency detected.
- [ ] Topological order deterministic.
- [ ] Reverse dependencies visible.
- [ ] Tenant dependencies validated.

---

# 186. UAT — Registration

- [ ] Provider contract works.
- [ ] Registration avoids external I/O.
- [ ] Duplicate service binding rejected.
- [ ] Route conflicts detected.
- [ ] Permission conflicts detected.
- [ ] Config definitions validated.
- [ ] Menu conflicts detected.
- [ ] Task/job conflicts detected.
- [ ] Event versions validated.
- [ ] Registration ledger complete.

---

# 187. UAT — Bootstrap & Readiness

- [ ] Bootstrap order correct.
- [ ] Phase logs emitted.
- [ ] Timeouts enforced.
- [ ] Idempotent retry works.
- [ ] Required config failure blocks readiness.
- [ ] Migration failure blocks readiness.
- [ ] Health failure blocks activation.
- [ ] Optional failure can degrade.
- [ ] Critical module failure blocks platform readiness.
- [ ] Partial registration rolls back safely.

---

# 188. UAT — Activation & Tenant Enablement

- [ ] Global activation requires readiness.
- [ ] Warning activation requires approval.
- [ ] Tenant enablement requires global active state.
- [ ] Tenant dependencies enforced.
- [ ] Clinic scope works where supported.
- [ ] Disabled tenant loses menu/access.
- [ ] Existing data remains preserved.
- [ ] Audit trail complete.
- [ ] Unauthorized enablement denied.

---

# 189. UAT — Upgrade & Rollback

- [ ] Target version certified.
- [ ] Compatibility checked.
- [ ] Backup requirement enforced.
- [ ] Migrations ordered.
- [ ] New version health checked.
- [ ] Version switch controlled.
- [ ] Rollback works when compatible.
- [ ] Roll-forward works when downgrade unsafe.
- [ ] Failed upgrade preserves evidence.
- [ ] Hypercare status visible.

---

# 190. UAT — Deactivation & Retirement

- [ ] Dependents block unsafe deactivation.
- [ ] Jobs drain.
- [ ] Schedules stop.
- [ ] Routes/menu disappear.
- [ ] Events unsubscribe.
- [ ] Data remains governed.
- [ ] Force deactivation requires emergency authority.
- [ ] Deprecation timeline works.
- [ ] New enablement can be blocked.
- [ ] Retirement evidence retained.

---

# 191. UAT — Security & Drift

- [ ] Unapproved provider rejected.
- [ ] Capability least privilege enforced.
- [ ] Secret access restricted.
- [ ] Cross-tenant activation denied.
- [ ] Artifact mismatch detected.
- [ ] Registry drift detected.
- [ ] Uncertified version blocked.
- [ ] Critical drift blocks readiness.
- [ ] Administrative APIs require privilege.

---

# 192. UAT — Observability & Governance

- [ ] Module metrics available.
- [ ] Bootstrap duration visible.
- [ ] Dependency failures visible.
- [ ] Health status visible.
- [ ] Tenant enablement visible.
- [ ] Lifecycle events audited.
- [ ] Dashboard views defined.
- [ ] KPIs/KRIs defined.
- [ ] Owners and decision rights assigned.

---

# 193. Definition of Done — SSOT-SDK-04

SSOT-SDK-04 dianggap selesai bila:

- [ ] objectives/principles tersedia;
- [ ] lifecycle model tersedia;
- [ ] module source/discovery tersedia;
- [ ] package validation tersedia;
- [ ] manifest fields/schema tersedia;
- [ ] module ID/version/owner rules tersedia;
- [ ] classification/criticality tersedia;
- [ ] dependency descriptors tersedia;
- [ ] resolution/cycle detection tersedia;
- [ ] capability declaration tersedia;
- [ ] provider contract tersedia;
- [ ] registration/bootstrap/activation phases tersedia;
- [ ] service lifetime/override rules tersedia;
- [ ] route/permission/config/menu registration tersedia;
- [ ] event/job/task registration tersedia;
- [ ] health/readiness tersedia;
- [ ] global/tenant/clinic activation tersedia;
- [ ] tenant dependencies tersedia;
- [ ] deterministic bootstrap order tersedia;
- [ ] failure isolation/degraded mode tersedia;
- [ ] idempotency/retry/timeout tersedia;
- [ ] bootstrap ledger tersedia;
- [ ] migration/seeder rules tersedia;
- [ ] installation tersedia;
- [ ] upgrade/downgrade tersedia;
- [ ] deactivation/uninstall tersedia;
- [ ] retirement tersedia;
- [ ] runtime registry tersedia;
- [ ] drift detection tersedia;
- [ ] security controls tersedia;
- [ ] observability/audit tersedia;
- [ ] metrics/KPI/KRI tersedia;
- [ ] API/database direction tersedia;
- [ ] event/error codes tersedia;
- [ ] reference examples tersedia;
- [ ] checklists/UAT tersedia.

---

# 194. Implementation Roadmap

## Phase 1 — Registry Foundation

- create module registry;
- define manifest schema;
- implement explicit discovery;
- validate package integrity;
- persist module/version records.

## Phase 2 — Dependency & Registration

- implement dependency graph;
- cycle detection;
- deterministic ordering;
- service/capability registration;
- conflict validation.

## Phase 3 — Bootstrap & Readiness

- implement phased bootstrap;
- config validation;
- migration integration;
- health checks;
- readiness gate;
- failure isolation.

## Phase 4 — Tenant Enablement & Lifecycle

- tenant module enablement;
- clinic scope where needed;
- deactivation;
- upgrade;
- rollback/roll-forward;
- retirement workflow.

## Phase 5 — Automation & Scale

- signed package registry;
- remote module registry;
- automated certification;
- registry drift remediation;
- advanced multi-version isolation.

---

# 195. Initial Implementation Backlog

```text
SDKM-001 Manifest Schema
SDKM-002 Explicit Module Discovery
SDKM-003 Package Integrity Validator
SDKM-004 Module Registry
SDKM-005 Dependency Graph Builder
SDKM-006 Cycle Detector
SDKM-007 Activation Order Resolver
SDKM-008 Registration Conflict Validator
SDKM-009 Bootstrap Runner
SDKM-010 Readiness Gate
SDKM-011 Module Health Registry
SDKM-012 Bootstrap Ledger
SDKM-013 Tenant Module Enablement
SDKM-014 Module Upgrade Coordinator
SDKM-015 Module Deactivation Coordinator
SDKM-016 Registry Drift Detector
SDKM-017 Module Lifecycle Dashboard
```

---

# 196. Approval Gate

Dokumen dapat menjadi Approved setelah:

- Platform Architecture review;
- SDK Technical Owner review;
- Security Governance review;
- Multi-tenant isolation review;
- Database/Migration review;
- Module Owner review;
- QA/Certification review;
- Release Engineering review;
- Operations/Observability review;
- lifecycle and retirement review.

---

# 197. Closing Statement

Module registration dan bootstrap harus memastikan setiap module:

- ditemukan secara eksplisit;
- diverifikasi sebelum dieksekusi;
- memiliki manifest;
- memiliki owner;
- kompatibel dengan SDK;
- memiliki dependency graph yang valid;
- didaftarkan secara deterministik;
- di-bootstrap secara terukur;
- melalui readiness gate;
- diaktifkan secara terkendali;
- dapat dinonaktifkan;
- dapat di-upgrade;
- dapat dipulihkan;
- dapat diaudit.

Module tidak boleh menjadi folder source yang otomatis dianggap aktif.

Module harus menjadi runtime unit yang memiliki identity, lifecycle, governance, health, dependency, dan evidence yang jelas.
