# SSOT-SDK-03 — SDK Versioning & Compatibility

---

## Status Dokumen

| Item | Nilai |
|---|---|
| Kode | SSOT-SDK-03 |
| Judul | SDK Versioning & Compatibility |
| Versi | 1.0 |
| Status | Draft for Review |
| Domain | Platform Kernel |
| Kategori | Platform SDK, Versioning, Compatibility & Lifecycle Governance |
| Cakupan | Semantic Versioning, Stability Levels, Compatibility Matrix, Deprecation, Migration, Certification, Release Policy |
| Bergantung pada | SSOT-SDK-01, SSOT-SDK-02, SSOT-GOV-02, SSOT-GOV-03, SSOT-GOV-06 |
| Target Stack | PHP 8.1+, Composer, PSR-4, Modular Monolith |
| Target Evolusi | Package-ready, Multi-version Support, Remote Adapter-ready |

---

# 1. Executive Summary

SSOT-SDK-03 menetapkan standar resmi untuk versioning dan compatibility Platform SDK.

Dokumen ini mengatur:

- semantic versioning;
- SDK release channels;
- contract stability;
- compatibility rules;
- module version constraints;
- compatibility matrix;
- breaking changes;
- additive changes;
- event and DTO evolution;
- capability versioning;
- deprecation lifecycle;
- migration windows;
- migration guides;
- certification;
- compatibility testing;
- release policy;
- support policy;
- long-term support;
- rollback;
- audit;
- metrics;
- UAT;
- Definition of Done.

Tujuan akhirnya adalah memastikan:

- module tidak rusak saat SDK berkembang;
- breaking changes dikendalikan;
- deprecation memiliki jalur migrasi;
- compatibility dapat diuji;
- versi yang didukung jelas;
- production tidak menjalankan kombinasi versi yang tidak tervalidasi;
- evolusi SDK tetap cepat namun aman.

---

# 2. Objectives

Framework harus:

- menjaga backward compatibility;
- mengontrol breaking change;
- menyediakan compatibility matrix;
- menetapkan lifecycle versi;
- menyediakan migration path;
- mencegah version reuse;
- mendukung module certification;
- menjaga release traceability;
- mempermudah upgrade;
- mendukung future multi-version runtime.

---

# 3. Core Principles

```text
Version Every Public Contract
Backward Compatible by Default
Breaking Changes Are Explicit
Deprecation Before Removal
Migration Guidance Is Mandatory
Compatibility Must Be Tested
Version Reuse Is Prohibited
Support Windows Are Published
Production Uses Certified Combinations
Rollback Must Remain Possible
```

---

# 4. Scope

Framework berlaku untuk:

```text
SDK Package
Public Stable Interfaces
Experimental Interfaces
DTO Schemas
Events
Capabilities
Extension Points
Module Manifests
Error Codes
Enums
Serialization Formats
Test Kits
Adapters
```

---

# 5. Semantic Versioning

Format:

```text
MAJOR.MINOR.PATCH
```

Example:

```text
2.4.1
```

---

# 6. Major Version

Major version berubah bila terdapat breaking change.

Examples:

- interface method removed;
- parameter type changed incompatibly;
- return type changed incompatibly;
- stable error semantics changed;
- event payload changed incompatibly;
- capability contract replaced;
- enum value removed.

---

# 7. Minor Version

Minor version berubah untuk backward-compatible additions.

Examples:

- new interface;
- new capability;
- new optional DTO field;
- new event version;
- new helper value object;
- new test utility.

---

# 8. Patch Version

Patch version berubah untuk:

- bug fix;
- documentation fix;
- non-breaking behavior correction;
- security fix preserving contract;
- test kit fix.

---

# 9. Pre-Release Versions

Recommended:

```text
1.3.0-alpha.1
1.3.0-beta.1
1.3.0-rc.1
```

---

# 10. Build Metadata

Example:

```text
1.3.0+build.20260705.001
```

---

# 11. Version Immutability

A published SDK version must not be replaced with different content.

---

# 12. Package Identity

Minimum:

```text
package_name
version
commit_sha
build_id
artifact_hash
signature
sbom_reference
published_at
```

---

# 13. Version Ownership

SDK Technical Owner owns version assignment.

---

# 14. Release Channels

```text
EXPERIMENTAL
PREVIEW
STABLE
LTS
DEPRECATED
RETIRED
```

---

# 15. Experimental Channel

Used for unstable contracts.

No strong compatibility guarantee.

---

# 16. Preview Channel

Used for contracts approaching stability.

Changes still possible with notice.

---

# 17. Stable Channel

Backward compatibility required within same major version.

---

# 18. LTS Channel

Long-term supported release with extended maintenance.

---

# 19. Deprecated Channel

Supported only during migration window.

---

# 20. Retired Channel

No longer supported.

---

# 21. Contract Stability Levels

```text
STABLE
EXPERIMENTAL
INTERNAL
DEPRECATED
RETIRED
```

---

# 22. Stable Contract

May be consumed by production modules.

Requires:

- owner;
- tests;
- documentation;
- compatibility commitment;
- migration policy.

---

# 23. Experimental Contract

Must be explicitly marked.

Must not be treated as stable dependency.

---

# 24. Internal Contract

Not part of public SDK surface.

---

# 25. Deprecated Contract

Still available temporarily.

Must have replacement and removal plan.

---

# 26. Retired Contract

Unavailable in supported runtime.

---

# 27. Compatibility Dimensions

Compatibility must be assessed across:

```text
Source Compatibility
Binary/Package Compatibility
Behavioral Compatibility
Serialization Compatibility
Event Compatibility
Database Compatibility
Operational Compatibility
Security Compatibility
```

---

# 28. Source Compatibility

Existing module source should compile/run without changes.

---

# 29. Behavioral Compatibility

Existing code should retain expected semantics.

---

# 30. Serialization Compatibility

Serialized DTO/event data should remain readable where required.

---

# 31. Event Compatibility

Consumers should continue processing supported event versions.

---

# 32. Operational Compatibility

Runtime characteristics should remain within documented expectations.

---

# 33. Security Compatibility

Changes must not weaken security assumptions silently.

---

# 34. Module Version Constraints

Module manifest should declare:

```text
sdk_version: ^1.2
```

---

# 35. Constraint Examples

```text
^1.2
~1.4
>=1.3 <2.0
1.5.*
```

---

# 36. Constraint Rules

Production modules should avoid:

- unbounded `*`;
- unspecified versions;
- floating development branches;
- unsupported major versions.

---

# 37. Compatibility Matrix

Minimum fields:

```text
module_id
module_version
sdk_version
status
tested_at
test_suite
notes
```

---

# 38. Compatibility Status

```text
SUPPORTED
SUPPORTED_WITH_WARNING
DEPRECATED
INCOMPATIBLE
UNKNOWN
```

---

# 39. Support Matrix Example

| Module | Module Version | SDK Version | Status |
|---|---:|---:|---|
| Homecare | 1.4.x | 1.2–1.x | Supported |
| Homecare | 2.0.x | 2.x | Supported |
| Patient | 1.1.x | 1.0–1.3 | Deprecated |
| Billing | 0.9.x | 2.x | Incompatible |

---

# 40. Compatibility Checkpoints

Compatibility must be checked during:

- development;
- CI;
- module packaging;
- installation;
- upgrade;
- activation;
- deployment;
- runtime health.

---

# 41. Compatibility Checker

```php
interface CompatibilityCheckerInterface
{
    public function check(
        ModuleManifestInterface $manifest,
        string $sdkVersion
    ): CompatibilityResult;
}
```

---

# 42. Compatibility Result

```php
final readonly class CompatibilityResult
{
    public function __construct(
        public string $status,
        public array $errors = [],
        public array $warnings = [],
    ) {
    }
}
```

---

# 43. Activation Rule

Module activation must fail when status is:

```text
INCOMPATIBLE
UNKNOWN
```

unless approved exception exists.

---

# 44. Warning Mode

`SUPPORTED_WITH_WARNING` may activate only with visible warning and owner.

---

# 45. Runtime Version Check

Runtime should expose:

- current SDK version;
- module version;
- compatibility status;
- certification timestamp.

---

# 46. Breaking Change Definition

A breaking change is any change requiring consumer modification or altering expected behavior incompatibly.

---

# 47. Breaking Interface Changes

Examples:

- removing method;
- adding required method to existing interface;
- changing parameter order;
- narrowing accepted type;
- changing return type;
- changing thrown exception semantics.

---

# 48. Breaking DTO Changes

Examples:

- removing required field;
- changing field type;
- changing meaning;
- changing nullability incompatibly.

---

# 49. Breaking Event Changes

Examples:

- removing payload field;
- changing event meaning;
- changing field type;
- changing ordering guarantees;
- changing idempotency semantics.

---

# 50. Breaking Error Changes

Examples:

- removing error code;
- changing meaning;
- changing retryability;
- changing authorization denial behavior.

---

# 51. Breaking Enum Changes

Removing enum values is breaking.

Adding enum values may still break consumers that assume exhaustive handling.

---

# 52. Breaking Capability Changes

Changing capability behavior or contract incompatibly requires new major capability version.

---

# 53. Breaking Extension Changes

Changing extension point signature or lifecycle incompatibly is breaking.

---

# 54. Additive Change Strategy

Preferred evolution methods:

- add new interface;
- add new capability;
- add new event version;
- add optional DTO field;
- add new extension point;
- add separate method through new interface.

---

# 55. Interface Evolution Strategy

Avoid adding methods to stable interfaces.

Prefer:

```text
InterfaceV2
Additional Capability Interface
Decorator
Adapter
```

---

# 56. DTO Evolution Strategy

Use:

- optional fields;
- defaults;
- explicit schema versions;
- tolerant readers;
- strict writers where appropriate.

---

# 57. Event Evolution Strategy

Use new event versions.

Example:

```text
homecare.visit.assigned.v1
homecare.visit.assigned.v2
```

---

# 58. Event Consumer Strategy

Consumers should:

- explicitly declare supported versions;
- ignore unknown additive fields;
- reject unsupported major payload versions clearly;
- remain idempotent.

---

# 59. Capability Versioning

Format:

```text
capability.authorization@1
capability.workflow@2
```

---

# 60. Capability Compatibility

A module should declare capability version constraints separately when needed.

---

# 61. Error Code Versioning

Stable error codes should not be renamed casually.

New error codes are additive.

---

# 62. Serialization Schema Version

Externally persisted or transmitted DTOs should carry schema version where needed.

---

# 63. Deprecation Lifecycle

```text
Identify
→ Announce
→ Document Replacement
→ Warn
→ Measure Usage
→ Support Migration
→ Disable in Preview
→ Remove in Major Version
```

---

# 64. Deprecation Metadata

Minimum:

```text
contract
deprecated_since
replacement
removal_version
migration_guide
owner
usage_count
```

---

# 65. Deprecation Notice

Notice should include:

- what is deprecated;
- why;
- replacement;
- migration steps;
- deadline;
- affected modules.

---

# 66. Deprecation Window

Recommended:

| Contract Type | Minimum Window |
|---|---:|
| Internal controlled module | 1 minor cycle |
| Stable internal SDK | 2 minor cycles |
| Broad stable SDK | 1 major cycle |
| Third-party contract | defined external support window |

---

# 67. Security Deprecation

Unsafe contracts may have accelerated deprecation.

---

# 68. Emergency Removal

Immediate removal allowed only for severe active risk.

Requires:

- security approval;
- incident reference;
- migration workaround;
- communication;
- retrospective.

---

# 69. Runtime Deprecation Warning

Warnings should include:

```text
contract
consumer_module
replacement
removal_version
```

---

# 70. Warning Rate Limit

Warnings must be rate-limited.

---

# 71. Usage Measurement

Track deprecated contract usage.

---

# 72. Removal Gate

A deprecated contract may be removed only when:

- removal version reached;
- migration guide exists;
- known consumers migrated or exception approved;
- release notes include removal;
- tests updated.

---

# 73. Migration Policy

Every breaking or major compatibility change must include migration plan.

---

# 74. Migration Guide

Minimum sections:

```text
Summary
Affected Contracts
Old Usage
New Usage
Behavior Differences
Error Differences
Data/Event Migration
Testing
Rollback
Deadline
```

---

# 75. Automated Migration

Provide codemods/scripts where practical.

---

# 76. Manual Migration

Manual steps must be explicit and testable.

---

# 77. Dual Support Window

SDK may support old and new contract versions temporarily.

---

# 78. Adapter Strategy

Use adapters to bridge old and new contracts.

---

# 79. Compatibility Adapter

Example:

```php
final class AuthorizationServiceV1Adapter
    implements AuthorizationServiceV1Interface
{
    public function __construct(
        private AuthorizationServiceV2Interface $v2
    ) {
    }
}
```

---

# 80. Adapter Lifetime

Adapters should have planned removal date.

---

# 81. Version Negotiation

Remote-capable adapters may negotiate supported version.

---

# 82. Default Version Selection

Default version must be explicit.

---

# 83. Multi-Version Runtime

Supporting multiple SDK major versions in one runtime is complex and should be exceptional.

---

# 84. Multi-Version Isolation

If supported, isolate:

- namespaces;
- adapters;
- dependency graphs;
- events;
- configuration;
- tests.

---

# 85. Support Policy

Each SDK release must publish:

- support start;
- maintenance end;
- security support end;
- retirement date.

---

# 86. Support Phases

```text
ACTIVE
MAINTENANCE
SECURITY_ONLY
END_OF_SUPPORT
RETIRED
```

---

# 87. Active Phase

Receives features, fixes, and security updates.

---

# 88. Maintenance Phase

Receives bug and security fixes.

---

# 89. Security-Only Phase

Receives critical security fixes only.

---

# 90. End of Support

No fixes guaranteed.

---

# 91. Long-Term Support

LTS releases should have:

- extended support;
- stricter change control;
- published maintenance schedule;
- upgrade guidance.

---

# 92. LTS Candidate Criteria

- stable adoption;
- low critical defect rate;
- complete documentation;
- compatibility test coverage;
- operational maturity.

---

# 93. Release Policy

SDK release workflow:

```text
Plan
→ Implement
→ Contract Review
→ Compatibility Tests
→ Security Review
→ Documentation
→ Version Assignment
→ Build
→ Sign
→ Publish
→ Notify
```

---

# 94. Release Types

```text
MAJOR
MINOR
PATCH
SECURITY_PATCH
PREVIEW
```

---

# 95. Release Readiness

Checks:

- tests pass;
- compatibility matrix updated;
- changelog updated;
- migration guide available;
- deprecations recorded;
- artifact signed;
- SBOM generated;
- release notes approved.

---

# 96. Release Blocking Conditions

Block when:

- contract tests fail;
- compatibility tests fail;
- breaking change undocumented;
- version increment incorrect;
- migration guide missing;
- security finding open;
- deprecated removal not approved;
- artifact integrity invalid.

---

# 97. Release Manifest

Example:

```yaml
package: platform/kernel-sdk
version: 2.0.0
commit_sha: abcdef123456
build_id: sdk-build-20260705-001
artifact_sha256: ...
channel: stable
breaking_changes:
  - authorization-service-v2
deprecated:
  - authorization-service-v1
migration_guides:
  - docs/migration/1-to-2.md
```

---

# 98. Changelog

Use structured sections:

```text
Added
Changed
Deprecated
Removed
Fixed
Security
Migration
```

---

# 99. Release Notes

Must identify:

- compatibility impact;
- migration requirement;
- known issues;
- support status;
- affected modules.

---

# 100. Version Selection Policy

New modules should use the latest supported stable or LTS version.

---

# 101. Upgrade Policy

Upgrade should proceed:

```text
Assess
→ Test
→ Certify
→ Stage
→ Promote
→ Verify
```

---

# 102. Major Upgrade

Requires:

- migration plan;
- compatibility inventory;
- module owner commitment;
- staging rehearsal;
- rollback or forward strategy.

---

# 103. Minor Upgrade

Requires compatibility tests and release review.

---

# 104. Patch Upgrade

May use streamlined process if no breaking change.

---

# 105. Downgrade Policy

Downgrade is allowed only when:

- compatibility known;
- no irreversible data/event change;
- artifact retained;
- module versions compatible.

---

# 106. Rollback Strategy

SDK rollback must consider:

- package version;
- module compatibility;
- generated code;
- event schemas;
- config;
- migrations.

---

# 107. Roll-Forward Strategy

Preferred when downgrade is unsafe.

---

# 108. Version Pinning

Production should pin exact artifact versions.

---

# 109. Lockfile Governance

Composer lockfile should be versioned and reviewed.

---

# 110. Floating Dependencies

Avoid floating dependencies in production.

---

# 111. Dependency Compatibility

SDK dependencies must follow their own supported version ranges.

---

# 112. Transitive Dependency Risk

Changes in transitive dependencies must be tested.

---

# 113. PHP Version Compatibility

SDK versions must declare supported PHP range.

Example:

```json
"php": "^8.1 || ^8.2"
```

---

# 114. Platform Runtime Compatibility

SDK release must declare supported runtime/kernel versions.

---

# 115. Module Certification

Certification verifies a module against a specific SDK version.

---

# 116. Certification Record

Minimum:

```text
module_id
module_version
sdk_version
result
test_suite_version
tested_at
artifact_hash
notes
```

---

# 117. Certification Status

```text
NOT_TESTED
PASSED
PASSED_WITH_WARNING
FAILED
EXPIRED
```

---

# 118. Certification Expiry

Certification may expire when:

- SDK changes materially;
- module changes;
- security baseline changes;
- test suite changes significantly.

---

# 119. Re-Certification Triggers

- module major/minor release;
- SDK major release;
- critical security contract change;
- event schema change;
- tenant boundary change.

---

# 120. Contract Test Suite

Must include:

```text
Signature Tests
Behavior Tests
Error Tests
Serialization Tests
Event Compatibility Tests
Security Tests
Tenant Isolation Tests
Deprecation Tests
```

---

# 121. Signature Hash

A stable signature hash may help detect contract changes.

---

# 122. Behavioral Tests

Verify documented semantics, not only signatures.

---

# 123. Golden Serialization Tests

Use known payload fixtures for DTO/event compatibility.

---

# 124. Consumer-Driven Compatibility

Consumer modules may publish expectations.

---

# 125. Matrix Test Strategy

Test supported combinations.

---

# 126. Minimum Matrix

At minimum test:

- current SDK + current module;
- current SDK + previous supported module;
- previous supported SDK + current compatible module;
- next preview SDK + current module where feasible.

---

# 127. Upgrade Simulation

Automated CI should simulate upgrade paths.

---

# 128. Deprecation Test

Verify deprecated contract still works until removal version.

---

# 129. Removal Test

Verify retired contract is absent in target major version.

---

# 130. Security Compatibility Test

Verify upgrade does not weaken:

- authorization;
- tenant isolation;
- audit;
- secret handling;
- file access;
- privileged capability controls.

---

# 131. Runtime Compatibility Monitor

Runtime may expose:

- incompatible module count;
- deprecated usage count;
- certification status;
- unsupported SDK versions.

---

# 132. Compatibility Dashboard

Recommended views:

- SDK versions in use;
- modules by SDK version;
- incompatible modules;
- deprecated contract usage;
- certification status;
- support phase;
- upcoming removals;
- upgrade backlog.

---

# 133. Metrics

```text
sdk_version_total
sdk_supported_version_total
sdk_unsupported_version_total
sdk_incompatible_module_total
sdk_deprecated_usage_total
sdk_certification_failure_total
sdk_major_upgrade_lead_time
sdk_migration_overdue_total
```

---

# 134. KPIs

Initial targets:

```text
Production incompatible modules = 0
Production modules on unsupported SDK = 0
Stable contracts without owner = 0
Breaking changes without migration guide = 0
Deprecated contracts past removal deadline = 0
Production modules certified before deployment = 100%
```

---

# 135. KRIs

```text
Unsupported SDK versions
Deprecated usage growth
Certification failures
Emergency breaking changes
Long-lived compatibility adapters
Unbounded version constraints
Version drift across environments
```

---

# 136. Governance Roles

```text
SDK Product Owner
SDK Technical Owner
Compatibility Owner
Contract Owner
Module Owner
Release Engineer
Security Reviewer
Architecture Review Board
```

---

# 137. Decision Rights

| Decision | Authority |
|---|---|
| Patch release | SDK Technical Owner |
| Minor release | SDK Owner + Architecture |
| Major release | Architecture Review Board |
| Emergency security release | Security + SDK Owner |
| Deprecation start | Contract Owner + SDK Owner |
| Contract removal | Architecture Review Board |
| Support extension | Platform Governance |

---

# 138. Major Version Approval

Requires:

- ADR;
- impact analysis;
- migration plan;
- compatibility matrix;
- release roadmap;
- rollback/forward plan;
- communication plan.

---

# 139. Emergency Breaking Change

Allowed only for severe active risk.

Requires retrospective governance.

---

# 140. Version Exception

Any unsupported combination requires time-bound exception.

---

# 141. Exception Record

Minimum:

```text
module
module_version
sdk_version
reason
risk
compensating_control
owner
expires_at
approval
```

---

# 142. Version Registry

Recommended fields:

```text
sdk_version
channel
support_phase
released_at
maintenance_end
security_end
retired_at
artifact_hash
documentation_reference
```

---

# 143. Compatibility Registry

Recommended fields:

```text
module_id
module_version
sdk_version
status
certification_id
tested_at
expires_at
```

---

# 144. Database Direction

Potential tables:

```text
sdk_versions
sdk_support_windows
sdk_compatibility_matrix
sdk_certifications
sdk_deprecations
sdk_migrations
sdk_version_exceptions
sdk_release_manifests
```

---

# 145. Table: sdk_versions

```sql
CREATE TABLE sdk_versions (
    id CHAR(26) NOT NULL,
    version VARCHAR(100) NOT NULL,
    release_channel VARCHAR(30) NOT NULL,
    support_phase VARCHAR(30) NOT NULL,
    artifact_sha256 CHAR(64) NOT NULL,
    commit_sha VARCHAR(64) NOT NULL,
    released_at DATETIME(6) NOT NULL,
    maintenance_end_at DATETIME(6) NULL,
    security_end_at DATETIME(6) NULL,
    retired_at DATETIME(6) NULL,

    PRIMARY KEY (id),
    UNIQUE KEY uq_sdk_version (
        version
    ),
    UNIQUE KEY uq_sdk_version_hash (
        artifact_sha256
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

# 146. Table: sdk_compatibility_matrix

```sql
CREATE TABLE sdk_compatibility_matrix (
    id CHAR(26) NOT NULL,
    module_code VARCHAR(100) NOT NULL,
    module_version VARCHAR(100) NOT NULL,
    sdk_version VARCHAR(100) NOT NULL,
    compatibility_status VARCHAR(30) NOT NULL,
    test_suite_version VARCHAR(100) NULL,
    tested_at DATETIME(6) NULL,
    expires_at DATETIME(6) NULL,
    notes_text LONGTEXT NULL,

    PRIMARY KEY (id),
    UNIQUE KEY uq_sdk_compatibility (
        module_code,
        module_version,
        sdk_version
    ),
    KEY idx_sdk_compatibility_status (
        compatibility_status,
        tested_at
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

# 147. Table: sdk_deprecations

```sql
CREATE TABLE sdk_deprecations (
    id CHAR(26) NOT NULL,
    contract_code VARCHAR(180) NOT NULL,
    deprecated_since VARCHAR(100) NOT NULL,
    replacement_code VARCHAR(180) NULL,
    removal_version VARCHAR(100) NOT NULL,
    migration_guide_reference VARCHAR(1000) NOT NULL,
    owner_reference VARCHAR(180) NOT NULL,
    usage_count BIGINT UNSIGNED NOT NULL DEFAULT 0,
    status VARCHAR(30) NOT NULL,

    PRIMARY KEY (id),
    UNIQUE KEY uq_sdk_deprecation_contract (
        contract_code
    ),
    KEY idx_sdk_deprecation_status (
        status,
        removal_version
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

# 148. Table: sdk_certifications

```sql
CREATE TABLE sdk_certifications (
    id CHAR(26) NOT NULL,
    certification_code VARCHAR(100) NOT NULL,
    module_code VARCHAR(100) NOT NULL,
    module_version VARCHAR(100) NOT NULL,
    sdk_version VARCHAR(100) NOT NULL,
    test_suite_version VARCHAR(100) NOT NULL,
    artifact_sha256 CHAR(64) NOT NULL,
    result VARCHAR(30) NOT NULL,
    tested_at DATETIME(6) NOT NULL,
    expires_at DATETIME(6) NULL,
    report_reference VARCHAR(1000) NULL,

    PRIMARY KEY (id),
    UNIQUE KEY uq_sdk_certification_code (
        certification_code
    ),
    KEY idx_sdk_certification_result (
        result,
        tested_at
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

# 149. Event Codes

```text
SDK_VERSION_RELEASED
SDK_VERSION_DEPRECATED
SDK_VERSION_RETIRED
SDK_COMPATIBILITY_CHECK_PASSED
SDK_COMPATIBILITY_CHECK_FAILED
SDK_CERTIFICATION_PASSED
SDK_CERTIFICATION_FAILED
SDK_CONTRACT_DEPRECATED
SDK_CONTRACT_REMOVED
SDK_MIGRATION_STARTED
SDK_MIGRATION_COMPLETED
```

---

# 150. Error Codes

```text
SDK_VERSION_NOT_FOUND
SDK_VERSION_ALREADY_EXISTS
SDK_VERSION_UNSUPPORTED
SDK_VERSION_RETIRED
SDK_MODULE_INCOMPATIBLE
SDK_CERTIFICATION_REQUIRED
SDK_CERTIFICATION_EXPIRED
SDK_MIGRATION_GUIDE_MISSING
SDK_DEPRECATION_WINDOW_INVALID
SDK_BREAKING_CHANGE_UNAPPROVED
SDK_VERSION_CONSTRAINT_INVALID
```

---

# 151. Sample SDK Version Record

```yaml
version: 2.0.0
channel: STABLE
support_phase: ACTIVE
released_at: 2026-07-05
maintenance_end: 2027-07-05
security_end: 2028-01-05
artifact_sha256: ...
```

---

# 152. Sample Compatibility Record

```yaml
module_id: homecare
module_version: 2.1.0
sdk_version: 2.0.0
status: SUPPORTED
test_suite_version: 2.0.3
tested_at: 2026-07-05
```

---

# 153. Sample Deprecation Record

```yaml
contract: authorization.service.v1
deprecated_since: 1.8.0
replacement: authorization.service.v2
removal_version: 2.0.0
migration_guide: docs/migration/auth-v1-to-v2.md
owner: platform_security
status: ACTIVE
```

---

# 154. Sample Version Exception

```yaml
module: legacy_reporting
module_version: 0.9.4
sdk_version: 1.6.0
reason: migration not yet complete
risk: HIGH
compensating_controls:
  - restricted tenant access
  - read-only mode
owner: reporting_team
expires_at: 2026-09-30
status: ACTIVE
```

---

# 155. Version Release Checklist

- [ ] Version unique.
- [ ] SemVer increment correct.
- [ ] Contract tests pass.
- [ ] Compatibility matrix updated.
- [ ] Changelog updated.
- [ ] Migration guide available.
- [ ] Deprecations registered.
- [ ] Artifact signed.
- [ ] SBOM generated.
- [ ] Release notes approved.
- [ ] Support window defined.
- [ ] Module owners notified.

---

# 156. Breaking Change Checklist

- [ ] Breaking change confirmed.
- [ ] ADR approved.
- [ ] New major version assigned.
- [ ] Impacted modules identified.
- [ ] Adapter strategy assessed.
- [ ] Migration guide complete.
- [ ] Compatibility tests added.
- [ ] Rollback/forward plan defined.
- [ ] Support window published.
- [ ] Communication complete.

---

# 157. Deprecation Checklist

- [ ] Contract identified.
- [ ] Replacement exists.
- [ ] Owner assigned.
- [ ] Warning implemented.
- [ ] Usage measured.
- [ ] Removal version defined.
- [ ] Migration guide published.
- [ ] Consumers notified.
- [ ] Removal gate scheduled.

---

# 158. Module Upgrade Checklist

- [ ] Current versions inventoried.
- [ ] Target SDK selected.
- [ ] Compatibility check passes.
- [ ] Module certification passes.
- [ ] Deprecated usage resolved.
- [ ] Migration executed.
- [ ] Staging verified.
- [ ] Rollback/forward plan ready.
- [ ] Production promotion approved.
- [ ] Runtime compatibility monitored.

---

# 159. UAT — Semantic Versioning

- [ ] Major/minor/patch rules defined.
- [ ] Pre-release versions supported.
- [ ] Version reuse blocked.
- [ ] Package metadata complete.
- [ ] Release channels defined.
- [ ] Support phases defined.
- [ ] Version pinning works.

---

# 160. UAT — Compatibility

- [ ] Module constraints parsed.
- [ ] Unbounded constraints rejected.
- [ ] Compatibility matrix works.
- [ ] Incompatible activation blocked.
- [ ] Warning mode works.
- [ ] Runtime compatibility visible.
- [ ] Environment version drift visible.
- [ ] Unknown compatibility blocked.

---

# 161. UAT — Breaking Changes

- [ ] Breaking interface changes detected.
- [ ] DTO incompatibility detected.
- [ ] Event incompatibility detected.
- [ ] Error semantics changes detected.
- [ ] Enum change risk assessed.
- [ ] Capability version change detected.
- [ ] Major version required.
- [ ] ADR required.

---

# 162. UAT — Deprecation & Migration

- [ ] Deprecation metadata complete.
- [ ] Runtime warning works.
- [ ] Usage metrics work.
- [ ] Removal version tracked.
- [ ] Migration guide linked.
- [ ] Adapter works.
- [ ] Removal gate blocks premature removal.
- [ ] Emergency removal process works.

---

# 163. UAT — Certification

- [ ] Certification suite runs.
- [ ] Results recorded.
- [ ] Expiry works.
- [ ] Re-certification triggers work.
- [ ] Failed certification blocks production.
- [ ] Artifact hash linked.
- [ ] Test suite version linked.
- [ ] Reports retained.

---

# 164. UAT — Release Policy

- [ ] Release workflow defined.
- [ ] Readiness gates work.
- [ ] Blocking conditions enforced.
- [ ] Changelog structure enforced.
- [ ] Support window published.
- [ ] Artifact integrity verified.
- [ ] Release notification works.
- [ ] Rollback/forward strategy documented.

---

# 165. UAT — Governance & Metrics

- [ ] Owners assigned.
- [ ] Decision rights enforced.
- [ ] Exceptions are time-bound.
- [ ] Metrics available.
- [ ] KPIs/KRIs defined.
- [ ] Dashboard views defined.
- [ ] Audit events recorded.
- [ ] Unsupported versions escalate.

---

# 166. Definition of Done — SSOT-SDK-03

SSOT-SDK-03 dianggap selesai bila:

- [ ] objectives/principles tersedia;
- [ ] semantic versioning tersedia;
- [ ] release channels tersedia;
- [ ] stability levels tersedia;
- [ ] compatibility dimensions tersedia;
- [ ] module constraints tersedia;
- [ ] compatibility matrix tersedia;
- [ ] activation rules tersedia;
- [ ] breaking change definitions tersedia;
- [ ] additive evolution strategy tersedia;
- [ ] interface/DTO/event/capability evolution tersedia;
- [ ] deprecation lifecycle tersedia;
- [ ] deprecation metadata/window tersedia;
- [ ] emergency removal tersedia;
- [ ] migration policy/guide tersedia;
- [ ] adapter/dual support tersedia;
- [ ] multi-version guidance tersedia;
- [ ] support policy/LTS tersedia;
- [ ] release policy/readiness tersedia;
- [ ] changelog/release notes tersedia;
- [ ] upgrade/downgrade/rollback tersedia;
- [ ] pinning/lockfile/dependency rules tersedia;
- [ ] PHP/runtime compatibility tersedia;
- [ ] certification tersedia;
- [ ] test matrix tersedia;
- [ ] runtime monitoring tersedia;
- [ ] governance/decision rights tersedia;
- [ ] exception model tersedia;
- [ ] registry/database direction tersedia;
- [ ] event/error codes tersedia;
- [ ] samples/checklists tersedia;
- [ ] metrics/KPI/KRI tersedia;
- [ ] UAT tersedia.

---

# 167. Implementation Roadmap

## Phase 1 — Version Registry

- create SDK version registry;
- define SemVer policy;
- define release channels;
- publish support windows;
- enforce version immutability.

## Phase 2 — Compatibility Engine

- parse module constraints;
- implement compatibility checker;
- create compatibility matrix;
- block incompatible activation;
- expose runtime version status.

## Phase 3 — Deprecation & Migration

- create deprecation registry;
- implement warnings;
- measure usage;
- publish migration guides;
- add adapter patterns.

## Phase 4 — Certification & Release

- build certification suite;
- define matrix tests;
- sign release artifacts;
- enforce readiness gates;
- automate release notes/changelog checks.

## Phase 5 — Advanced Lifecycle

- LTS releases;
- multi-version isolation where required;
- remote version negotiation;
- automated upgrade simulation;
- predictive compatibility risk.

---

# 168. Initial Backlog

```text
SDKV-001 Semantic Version Parser
SDKV-002 Version Registry
SDKV-003 Compatibility Matrix
SDKV-004 Compatibility Checker
SDKV-005 Module Constraint Validator
SDKV-006 Deprecation Registry
SDKV-007 Runtime Deprecation Warning
SDKV-008 Migration Guide Template
SDKV-009 Compatibility Adapter Pattern
SDKV-010 Certification Registry
SDKV-011 Matrix Test Runner
SDKV-012 Support Window Registry
SDKV-013 Release Manifest Generator
SDKV-014 Version Dashboard
```

---

# 169. Approval Gate

Dokumen dapat menjadi Approved setelah:

- Platform Architecture review;
- SDK Product Owner review;
- SDK Technical Owner review;
- Module Owner review;
- Security Governance review;
- QA/Compatibility review;
- Release Engineering review;
- Platform Governance review;
- support-window review;
- migration/deprecation review.

---

# 170. Closing Statement

SDK versioning dan compatibility harus memastikan setiap SDK release dan module combination:

- memiliki versi unik;
- memiliki support status;
- memiliki compatibility result;
- memiliki test evidence;
- memiliki migration path;
- memiliki owner;
- memiliki deprecation timeline;
- dapat di-upgrade;
- dapat di-rollback atau di-roll-forward;
- dapat diaudit.

Versioning tidak boleh menjadi sekadar nomor pada package.

Versioning harus menjadi kontrak governance yang menjelaskan compatibility, support, migration, dan risiko operasional secara eksplisit.
