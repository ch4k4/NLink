# SSOT-SDK-02 — Module SDK Contracts

---

## Status Dokumen

| Item | Nilai |
|---|---|
| Kode | SSOT-SDK-02 |
| Judul | Module SDK Contracts |
| Versi | 1.0 |
| Status | Draft for Review |
| Domain | Platform Kernel |
| Kategori | Platform SDK, Module Contracts & Integration Standards |
| Cakupan | Module Contracts, DTOs, Context, Capabilities, Events, Errors, Compatibility, Contract Testing |
| Bergantung pada | SSOT-SDK-01, SSOT-GOV-03, SSOT-SEC-01, SSOT-OBS-01, SSOT-DEPLOY-02 |
| Target Stack | PHP 8.1+, Composer, PSR-4, Modular Monolith |
| Target Evolusi | Package-ready, Remote Adapter-ready, Microservice-ready |

---

# 1. Executive Summary

SSOT-SDK-02 menetapkan kontrak konkret yang wajib digunakan oleh seluruh business module ketika berinteraksi dengan Platform Kernel dan module lain.

Dokumen ini mengatur:

- contract taxonomy;
- interface conventions;
- DTO conventions;
- value objects;
- result objects;
- error contracts;
- module manifest contract;
- module provider contract;
- module runtime context;
- identity contract;
- authorization contract;
- tenant context contract;
- audit contract;
- configuration contract;
- feature flag contract;
- command/query contracts;
- event contracts;
- workflow contract;
- notification contract;
- file contract;
- job and scheduler contract;
- menu contract;
- observability contract;
- health contract;
- compatibility;
- versioning;
- contract testing;
- UAT;
- Definition of Done.

Tujuan akhirnya adalah memastikan module:

- memiliki integration boundary yang eksplisit;
- tidak bergantung pada kernel internals;
- menggunakan typed contracts;
- menggunakan trusted context;
- menjaga tenant isolation;
- memiliki consistent error semantics;
- dapat diuji;
- dapat di-upgrade;
- dapat dipindahkan ke adapter remote tanpa rewrite besar.

---

# 2. Objectives

Module SDK Contracts harus:

- menyediakan contract stabil;
- menjaga dependency direction;
- mencegah kernel internals leakage;
- menjaga consistency antar module;
- memastikan tenant-aware behavior;
- memastikan authorization;
- menyediakan error semantics yang konsisten;
- mendukung observability;
- mendukung compatibility testing;
- mendukung future service extraction.

---

# 3. Core Principles

```text
Explicit Contracts
Typed Inputs and Outputs
Trusted Context Only
No Raw Infrastructure Leakage
Stable Error Semantics
Tenant-Aware by Default
Authorization Before Action
Events Are Facts
Commands Are Intent
Queries Do Not Mutate
Backward Compatibility by Default
```

---

# 4. Scope

Kontrak mencakup:

```text
Module Lifecycle
Identity
Authorization
Tenancy
Audit
Configuration
Feature Flags
Commands
Queries
Events
Workflow
Notification
Files
Jobs
Scheduler
Menu
Observability
Health
Compatibility
Testing
```

---

# 5. Contract Taxonomy

```text
Lifecycle Contract
Capability Contract
Context Contract
Data Contract
Behavior Contract
Event Contract
Error Contract
Extension Contract
Testing Contract
```

---

# 6. Stability Classification

```text
STABLE
EXPERIMENTAL
INTERNAL
DEPRECATED
RETIRED
```

---

# 7. Contract Naming

Recommended suffixes:

```text
Interface
Request
Result
Context
Descriptor
Reference
Exception
Event
Command
Query
```

Examples:

```text
AuthorizationServiceInterface
AuthorizationRequest
AuthorizationDecision
TenantContext
FileReference
ModuleRegistrationException
```

---

# 8. Namespace Layout

```text
Platform\Sdk\Module
Platform\Sdk\Identity
Platform\Sdk\Authorization
Platform\Sdk\Tenancy
Platform\Sdk\Audit
Platform\Sdk\Configuration
Platform\Sdk\Events
Platform\Sdk\Commands
Platform\Sdk\Queries
Platform\Sdk\Workflow
Platform\Sdk\Notification
Platform\Sdk\Files
Platform\Sdk\Jobs
Platform\Sdk\Menu
Platform\Sdk\Observability
Platform\Sdk\Health
```

---

# 9. Interface Rules

Interfaces must:

- be small;
- be cohesive;
- use typed signatures;
- avoid arrays unless schema is fixed;
- avoid concrete kernel classes;
- avoid PDO;
- avoid service container;
- avoid framework request/response objects;
- define exception behavior.

---

# 10. DTO Rules

DTOs should:

- be immutable;
- be `readonly` where possible;
- validate invariants;
- use value objects;
- avoid infrastructure dependencies;
- be serializable where remote use is possible.

---

# 11. Value Object Rules

Value objects should:

- validate format;
- be immutable;
- compare by value;
- avoid null ambiguity;
- provide explicit string conversion.

---

# 12. Identifier Contracts

Recommended identifiers:

```php
interface IdentifierInterface
{
    public function toString(): string;
}
```

Concrete examples:

```text
TenantId
ClinicId
OrganizationId
UserId
ActorId
ModuleId
PermissionCode
CorrelationId
RequestId
EventId
FileId
WorkflowId
```

---

# 13. Nullability

Use nullable types only when absence is meaningful.

Avoid sentinel empty strings.

---

# 14. Collection Contracts

Use typed collections where domain semantics matter.

---

# 15. Date and Time

Use:

```php
\DateTimeImmutable
```

All timestamps should be timezone-aware.

---

# 16. Duration

Use explicit duration value object or integer unit documented in contract.

---

# 17. Enumeration

Use PHP enums for stable finite values where possible.

---

# 18. Result Contract

Operations should return explicit result objects.

---

# 19. Result Status

Recommended:

```text
SUCCESS
PARTIAL
REJECTED
FAILED
NOT_FOUND
CONFLICT
```

---

# 20. Error Contract

Base exception:

```php
interface SdkExceptionInterface extends \Throwable
{
    public function errorCode(): string;

    public function context(): array;
}
```

---

# 21. Error Context

Error context must not contain secrets or unrestricted sensitive data.

---

# 22. Stable Error Codes

Error codes are part of the contract.

Changing meaning is breaking.

---

# 23. Common Error Codes

```text
SDK_INVALID_ARGUMENT
SDK_NOT_FOUND
SDK_CONFLICT
SDK_PERMISSION_DENIED
SDK_TENANT_CONTEXT_MISSING
SDK_CAPABILITY_UNAVAILABLE
SDK_VERSION_INCOMPATIBLE
SDK_CONFIGURATION_INVALID
SDK_OPERATION_FAILED
```

---

# 24. Retryability

Exceptions should indicate retryability where relevant.

---

# 25. Retryable Error Contract

```php
interface RetryableExceptionInterface
{
    public function retryAfterSeconds(): ?int;
}
```

---

# 26. Correlation Context

Every cross-module operation should carry correlation context.

---

# 27. Correlation Context Contract

```php
final readonly class CorrelationContext
{
    public function __construct(
        public string $requestId,
        public string $correlationId,
        public ?string $causationId = null,
    ) {
    }
}
```

---

# 28. Module Manifest Contract

```php
interface ModuleManifestInterface
{
    public function moduleId(): string;

    public function name(): string;

    public function version(): string;

    public function sdkVersionConstraint(): string;

    public function requiredCapabilities(): array;

    public function providedCapabilities(): array;

    public function dependencies(): array;

    public function permissions(): array;

    public function configurationKeys(): array;
}
```

---

# 29. Module Dependency Descriptor

```php
final readonly class ModuleDependency
{
    public function __construct(
        public string $moduleId,
        public string $versionConstraint,
        public bool $optional = false,
    ) {
    }
}
```

---

# 30. Module Provider Contract

```php
interface ModuleProviderInterface
{
    public function manifest(): ModuleManifestInterface;

    public function register(ModuleRegistryInterface $registry): void;

    public function boot(ModuleRuntimeContext $context): void;
}
```

---

# 31. Module Registry Contract

```php
interface ModuleRegistryInterface
{
    public function registerService(
        string $contract,
        string $implementation
    ): void;

    public function registerCapability(
        CapabilityDescriptor $capability
    ): void;

    public function registerExtension(
        string $extensionPoint,
        object $extension
    ): void;
}
```

---

# 32. Module Runtime Context

```php
final readonly class ModuleRuntimeContext
{
    public function __construct(
        public string $environment,
        public CapabilityResolverInterface $capabilities,
        public ModuleHealthReporterInterface $health,
        public CorrelationContext $correlation,
    ) {
    }
}
```

---

# 33. Module Lifecycle Hooks

Optional hooks:

```text
beforeActivate
afterActivate
beforeDeactivate
afterDeactivate
beforeUpgrade
afterUpgrade
```

---

# 34. Lifecycle Hook Rules

Hooks must:

- be idempotent;
- be time-bounded;
- emit observability;
- fail predictably;
- not silently mutate unrelated module state.

---

# 35. Capability Descriptor

```php
final readonly class CapabilityDescriptor
{
    public function __construct(
        public string $name,
        public string $version,
        public string $contract,
        public string $stability,
    ) {
    }
}
```

---

# 36. Capability Resolver

```php
interface CapabilityResolverInterface
{
    public function has(string $name, ?string $version = null): bool;

    public function resolve(string $name): object;
}
```

---

# 37. Identity Contract

```php
interface IdentityContextInterface
{
    public function actorId(): ?string;

    public function actorType(): string;

    public function isAuthenticated(): bool;

    public function assuranceLevel(): string;

    public function attributes(): array;
}
```

---

# 38. Actor Types

```text
USER
SERVICE
SYSTEM
ANONYMOUS
SUPPORT
```

---

# 39. Assurance Levels

```text
ANONYMOUS
PASSWORD
MFA
STRONG
SYSTEM
```

---

# 40. Identity Attributes

Attributes must be minimal and trusted.

---

# 41. Authorization Request

```php
final readonly class AuthorizationRequest
{
    public function __construct(
        public string $permission,
        public ?ResourceReference $resource,
        public TenantContextInterface $tenant,
        public IdentityContextInterface $identity,
        public CorrelationContext $correlation,
    ) {
    }
}
```

---

# 42. Resource Reference

```php
final readonly class ResourceReference
{
    public function __construct(
        public string $type,
        public string $id,
        public array $attributes = [],
    ) {
    }
}
```

---

# 43. Authorization Decision

```php
final readonly class AuthorizationDecision
{
    public function __construct(
        public bool $allowed,
        public string $reasonCode,
        public ?string $policyReference = null,
        public array $obligations = [],
    ) {
    }
}
```

---

# 44. Authorization Service

```php
interface AuthorizationServiceInterface
{
    public function decide(
        AuthorizationRequest $request
    ): AuthorizationDecision;

    public function require(
        AuthorizationRequest $request
    ): void;
}
```

---

# 45. Authorization Obligations

Potential obligations:

```text
MASK_FIELDS
REQUIRE_MFA
REQUIRE_APPROVAL
LIMIT_SCOPE
AUDIT_VERBOSELY
```

---

# 46. Authorization Denial

Denied authorization must use stable reason code.

---

# 47. Tenant Context Contract

```php
interface TenantContextInterface
{
    public function tenantId(): string;

    public function organizationId(): ?string;

    public function clinicId(): ?string;

    public function scopeType(): string;

    public function assertTenant(string $tenantId): void;

    public function assertClinic(?string $clinicId): void;
}
```

---

# 48. Tenant Context Source

Trusted tenant context must originate from:

- authenticated session;
- validated service token;
- trusted job envelope;
- approved system context.

---

# 49. Raw Input Prohibition

Module must not trust:

```text
request tenant_id
query tenant_id
form tenant_id
```

without authoritative scope validation.

---

# 50. System Tenant Context

System jobs must still declare explicit tenant scope or approved global scope.

---

# 51. Global Scope

Global scope is privileged and must be auditable.

---

# 52. Audit Event Contract

```php
final readonly class AuditEvent
{
    public function __construct(
        public string $eventCode,
        public string $action,
        public string $outcome,
        public IdentityContextInterface $identity,
        public TenantContextInterface $tenant,
        public CorrelationContext $correlation,
        public ?ResourceReference $resource = null,
        public array $metadata = [],
    ) {
    }
}
```

---

# 53. Audit Recorder

```php
interface AuditRecorderInterface
{
    public function record(AuditEvent $event): void;
}
```

---

# 54. Audit Outcomes

```text
SUCCESS
DENIED
FAILED
PARTIAL
```

---

# 55. Audit Metadata Rules

Audit metadata must:

- be structured;
- minimize sensitive data;
- use references instead of raw payloads;
- preserve before/after hashes where appropriate.

---

# 56. Configuration Contract

```php
interface ConfigurationInterface
{
    public function string(string $key): string;

    public function nullableString(string $key): ?string;

    public function integer(string $key): int;

    public function boolean(string $key): bool;

    public function durationSeconds(string $key): int;

    public function enum(string $key, string $enumClass): object;

    public function version(): string;
}
```

---

# 57. Module Configuration Scope

```php
interface ModuleConfigurationInterface
{
    public function forModule(
        string $moduleId,
        TenantContextInterface $tenant
    ): ConfigurationInterface;
}
```

---

# 58. Configuration Exceptions

```text
SDK_CONFIG_KEY_NOT_FOUND
SDK_CONFIG_TYPE_MISMATCH
SDK_CONFIG_SCOPE_INVALID
SDK_CONFIG_VALUE_INVALID
```

---

# 59. Feature Flag Request

```php
final readonly class FeatureFlagRequest
{
    public function __construct(
        public string $flagKey,
        public TenantContextInterface $tenant,
        public IdentityContextInterface $identity,
        public array $attributes = [],
    ) {
    }
}
```

---

# 60. Feature Flag Decision

```php
final readonly class FeatureFlagDecision
{
    public function __construct(
        public bool $enabled,
        public string $reasonCode,
        public string $version,
    ) {
    }
}
```

---

# 61. Feature Flag Service

```php
interface FeatureFlagServiceInterface
{
    public function evaluate(
        FeatureFlagRequest $request
    ): FeatureFlagDecision;
}
```

---

# 62. Feature Flag Rule

Feature flags must not replace authorization.

---

# 63. Command Marker

```php
interface CommandInterface
{
}
```

---

# 64. Command Envelope

```php
final readonly class CommandEnvelope
{
    public function __construct(
        public string $commandId,
        public object $command,
        public IdentityContextInterface $identity,
        public TenantContextInterface $tenant,
        public CorrelationContext $correlation,
        public ?string $idempotencyKey = null,
    ) {
    }
}
```

---

# 65. Command Bus

```php
interface CommandBusInterface
{
    public function dispatch(
        CommandEnvelope $command
    ): CommandResult;
}
```

---

# 66. Command Result

```php
final readonly class CommandResult
{
    public function __construct(
        public string $status,
        public ?ResourceReference $resource = null,
        public array $metadata = [],
    ) {
    }
}
```

---

# 67. Command Rules

Commands must:

- represent intent;
- use imperative naming;
- be immutable;
- contain no repositories or services;
- include idempotency where duplicate execution is possible.

---

# 68. Query Marker

```php
interface QueryInterface
{
}
```

---

# 69. Query Envelope

```php
final readonly class QueryEnvelope
{
    public function __construct(
        public object $query,
        public IdentityContextInterface $identity,
        public TenantContextInterface $tenant,
        public CorrelationContext $correlation,
    ) {
    }
}
```

---

# 70. Query Bus

```php
interface QueryBusInterface
{
    public function ask(QueryEnvelope $query): object;
}
```

---

# 71. Query Rules

Queries must:

- not mutate state;
- enforce tenant scope;
- enforce authorization;
- return typed DTOs;
- support pagination for collections.

---

# 72. Pagination Request

```php
final readonly class PageRequest
{
    public function __construct(
        public int $page = 1,
        public int $pageSize = 25,
        public ?string $cursor = null,
    ) {
    }
}
```

---

# 73. Page Result

```php
final readonly class PageResult
{
    public function __construct(
        public array $items,
        public ?string $nextCursor,
        public ?int $total = null,
    ) {
    }
}
```

---

# 74. Platform Event Contract

```php
interface PlatformEventInterface
{
    public function eventId(): string;

    public function eventType(): string;

    public function eventVersion(): int;

    public function occurredAt(): \DateTimeImmutable;
}
```

---

# 75. Event Envelope

```php
final readonly class EventEnvelope
{
    public function __construct(
        public PlatformEventInterface $event,
        public ?string $tenantId,
        public ?string $actorId,
        public string $correlationId,
        public ?string $causationId,
        public array $metadata = [],
    ) {
    }
}
```

---

# 76. Event Publisher

```php
interface EventPublisherInterface
{
    public function publish(EventEnvelope $event): void;
}
```

---

# 77. Event Subscriber

```php
interface EventSubscriberInterface
{
    public function subscribedEvents(): array;

    public function handle(EventEnvelope $event): void;
}
```

---

# 78. Event Naming

Recommended:

```text
domain.entity.action.vN
```

Example:

```text
homecare.visit.assigned.v1
```

---

# 79. Event Payload Rules

Event payloads should:

- contain stable identifiers;
- minimize sensitive data;
- be backward-compatible;
- avoid internal ORM entities;
- use explicit version.

---

# 80. Event Delivery

Consumers must tolerate duplicate delivery.

---

# 81. Idempotent Event Handling

Use event ID or business idempotency key.

---

# 82. Outbox Contract

```php
interface OutboxInterface
{
    public function append(EventEnvelope $event): void;
}
```

---

# 83. Workflow Start Request

```php
final readonly class WorkflowStartRequest
{
    public function __construct(
        public string $workflowCode,
        public ResourceReference $subject,
        public TenantContextInterface $tenant,
        public IdentityContextInterface $identity,
        public array $input = [],
    ) {
    }
}
```

---

# 84. Workflow Transition Request

```php
final readonly class WorkflowTransitionRequest
{
    public function __construct(
        public string $workflowInstanceId,
        public string $transition,
        public TenantContextInterface $tenant,
        public IdentityContextInterface $identity,
        public array $input = [],
    ) {
    }
}
```

---

# 85. Workflow Result

```php
final readonly class WorkflowResult
{
    public function __construct(
        public string $instanceId,
        public string $status,
        public string $currentState,
        public array $availableTransitions = [],
    ) {
    }
}
```

---

# 86. Workflow Service

```php
interface WorkflowServiceInterface
{
    public function start(
        WorkflowStartRequest $request
    ): WorkflowResult;

    public function transition(
        WorkflowTransitionRequest $request
    ): WorkflowResult;

    public function get(
        string $instanceId,
        TenantContextInterface $tenant
    ): WorkflowResult;
}
```

---

# 87. Notification Request

```php
final readonly class NotificationRequest
{
    public function __construct(
        public string $templateCode,
        public array $recipientReferences,
        public TenantContextInterface $tenant,
        public array $variables = [],
        public array $channels = [],
        public ?string $idempotencyKey = null,
    ) {
    }
}
```

---

# 88. Notification Result

```php
final readonly class NotificationResult
{
    public function __construct(
        public string $notificationId,
        public string $status,
        public array $channelResults = [],
    ) {
    }
}
```

---

# 89. Notification Service

```php
interface NotificationServiceInterface
{
    public function send(
        NotificationRequest $request
    ): NotificationResult;
}
```

---

# 90. Notification Rules

Modules must not directly send email/SMS through infrastructure clients when platform capability is available.

---

# 91. File Upload Request

```php
final readonly class FileUploadRequest
{
    public function __construct(
        public string $originalName,
        public string $mimeType,
        public int $sizeBytes,
        public mixed $stream,
        public TenantContextInterface $tenant,
        public IdentityContextInterface $identity,
        public string $purpose,
    ) {
    }
}
```

---

# 92. File Reference

```php
final readonly class FileReference
{
    public function __construct(
        public string $fileId,
        public string $storageKey,
        public string $checksum,
        public string $status,
        public string $classification,
    ) {
    }
}
```

---

# 93. File Service

```php
interface FileServiceInterface
{
    public function upload(
        FileUploadRequest $request
    ): FileReference;

    public function authorizeDownload(
        string $fileId,
        TenantContextInterface $tenant,
        IdentityContextInterface $identity
    ): FileAccessResult;

    public function delete(
        string $fileId,
        TenantContextInterface $tenant,
        IdentityContextInterface $identity
    ): void;
}
```

---

# 94. File Access Result

```php
final readonly class FileAccessResult
{
    public function __construct(
        public bool $allowed,
        public ?string $downloadToken,
        public ?\DateTimeImmutable $expiresAt,
        public string $reasonCode,
    ) {
    }
}
```

---

# 95. File Contract Rules

- never expose physical paths;
- use opaque references;
- require tenant context;
- require authorization;
- preserve checksum;
- expose quarantine status;
- use expiring download token.

---

# 96. Job Request

```php
final readonly class JobRequest
{
    public function __construct(
        public string $jobType,
        public array $payload,
        public TenantContextInterface $tenant,
        public CorrelationContext $correlation,
        public ?string $idempotencyKey = null,
        public int $maxAttempts = 3,
    ) {
    }
}
```

---

# 97. Job Dispatch Result

```php
final readonly class JobDispatchResult
{
    public function __construct(
        public string $jobId,
        public string $status,
    ) {
    }
}
```

---

# 98. Job Dispatcher

```php
interface JobDispatcherInterface
{
    public function dispatch(JobRequest $request): JobDispatchResult;
}
```

---

# 99. Scheduled Task Descriptor

```php
final readonly class ScheduledTaskDescriptor
{
    public function __construct(
        public string $taskCode,
        public string $schedule,
        public string $handler,
        public string $owner,
        public int $timeoutSeconds,
        public bool $overlapAllowed = false,
    ) {
    }
}
```

---

# 100. Scheduler Registry

```php
interface SchedulerRegistryInterface
{
    public function register(
        ScheduledTaskDescriptor $task
    ): void;
}
```

---

# 101. Job Rules

Jobs must:

- carry tenant context;
- be idempotent;
- use bounded retry;
- avoid raw secrets;
- emit status events;
- support dead-letter handling where applicable.

---

# 102. Menu Item Descriptor

```php
final readonly class MenuItemDescriptor
{
    public function __construct(
        public string $code,
        public string $label,
        public string $route,
        public ?string $permission,
        public ?string $parentCode,
        public int $order,
        public ?string $featureFlag = null,
    ) {
    }
}
```

---

# 103. Menu Contributor

```php
interface MenuContributorInterface
{
    public function items(): array;
}
```

---

# 104. Menu Rules

Menu item visibility may use:

- module enabled;
- permission;
- feature flag;
- tenant config.

Menu visibility is not authorization.

---

# 105. Structured Logger

```php
interface StructuredLoggerInterface
{
    public function debug(string $eventCode, array $context = []): void;

    public function info(string $eventCode, array $context = []): void;

    public function warning(string $eventCode, array $context = []): void;

    public function error(string $eventCode, array $context = []): void;
}
```

---

# 106. Metric Recorder

```php
interface MetricRecorderInterface
{
    public function increment(
        string $metric,
        float $value = 1,
        array $labels = []
    ): void;

    public function observe(
        string $metric,
        float $value,
        array $labels = []
    ): void;
}
```

---

# 107. Trace Context

```php
interface TraceContextInterface
{
    public function traceId(): ?string;

    public function spanId(): ?string;
}
```

---

# 108. Observability Context

```php
final readonly class ObservabilityContext
{
    public function __construct(
        public string $moduleId,
        public CorrelationContext $correlation,
        public TenantContextInterface $tenant,
        public ?TraceContextInterface $trace = null,
    ) {
    }
}
```

---

# 109. Observability Rules

Labels must not contain uncontrolled high-cardinality data.

---

# 110. Module Health Check

```php
interface ModuleHealthCheckInterface
{
    public function check(): ModuleHealthResult;
}
```

---

# 111. Module Health Result

```php
final readonly class ModuleHealthResult
{
    public function __construct(
        public string $status,
        public string $message,
        public array $checks = [],
    ) {
    }
}
```

---

# 112. Health Status

```text
HEALTHY
DEGRADED
UNHEALTHY
UNKNOWN
```

---

# 113. Health Check Rules

Health checks must:

- avoid exposing secrets;
- be fast;
- use timeouts;
- distinguish required vs optional dependency;
- be observable.

---

# 114. Extension Point Descriptor

```php
final readonly class ExtensionPointDescriptor
{
    public function __construct(
        public string $code,
        public string $contract,
        public string $version,
        public string $owner,
        public string $stability,
    ) {
    }
}
```

---

# 115. Extension Registration

```php
interface ExtensionRegistryInterface
{
    public function register(
        string $extensionPoint,
        string $extensionId,
        object $extension,
        int $priority = 100
    ): void;

    public function all(string $extensionPoint): array;
}
```

---

# 116. Extension Rules

- explicit registration;
- deterministic ordering;
- unique extension IDs;
- compatibility validation;
- failure isolation;
- security review for privileged extensions.

---

# 117. Repository Contract Guidance

Business repositories should be module-owned.

Example:

```php
interface HomecareVisitRepositoryInterface
{
    public function getById(
        string $visitId,
        TenantContextInterface $tenant
    ): ?HomecareVisit;

    public function save(
        HomecareVisit $visit,
        TenantContextInterface $tenant
    ): void;
}
```

---

# 118. Repository Rules

Repositories must:

- require tenant scope;
- return domain objects or typed DTOs;
- hide SQL;
- avoid cross-module table access;
- use explicit query methods.

---

# 119. Transaction Manager Contract

```php
interface TransactionManagerInterface
{
    public function transactional(callable $operation): mixed;
}
```

---

# 120. Transaction Rules

- no uncontrolled network calls inside long DB transaction;
- no nested ambiguity;
- publish events through outbox when consistency is required;
- transaction owner must be clear.

---

# 121. Clock Contract

```php
interface ClockInterface
{
    public function now(): \DateTimeImmutable;
}
```

---

# 122. ID Generator Contract

```php
interface IdGeneratorInterface
{
    public function generate(): string;
}
```

---

# 123. Current User Convenience Contract

Avoid broad `CurrentUser` object with uncontrolled fields.

Use identity context.

---

# 124. Locale Contract

```php
interface LocaleContextInterface
{
    public function locale(): string;

    public function timezone(): string;
}
```

---

# 125. Serialization Contract

DTOs crossing process boundaries should support explicit serialization schema.

---

# 126. API Adapter Contract

Remote adapters should map network response into SDK DTOs.

---

# 127. Local Adapter Contract

In-process adapters implement the same SDK contract.

---

# 128. Remote Error Mapping

Remote errors must map to stable SDK error codes.

---

# 129. Timeout Contract

Remote-capable operations should define timeout behavior.

---

# 130. Cancellation

Long-running operations may support cancellation token where needed.

---

# 131. Idempotency Contract

```php
interface IdempotencyStoreInterface
{
    public function has(string $key): bool;

    public function get(string $key): mixed;

    public function put(
        string $key,
        mixed $result,
        \DateTimeImmutable $expiresAt
    ): void;
}
```

---

# 132. Idempotency Scope

Idempotency key should include tenant and operation context.

---

# 133. Contract Versioning

Use semantic versioning at SDK package level.

Use explicit version for:

- events;
- capabilities;
- externalizable DTO schemas;
- extension points.

---

# 134. Breaking Changes

Breaking examples:

- remove interface method;
- change parameter type;
- make nullable parameter required;
- change error code meaning;
- remove enum value;
- alter event payload incompatibly.

---

# 135. Non-Breaking Changes

Potentially safe:

- add new interface;
- add optional DTO field with default;
- add new event version;
- add new error code;
- add new capability.

---

# 136. Interface Additions

Adding a method to a stable interface is breaking for implementers.

Prefer new interface version or separate capability.

---

# 137. Deprecation Metadata

```text
deprecated_since
replacement
removal_version
migration_guide
owner
```

---

# 138. Compatibility Contract

```php
interface CompatibilityCheckerInterface
{
    public function check(
        ModuleManifestInterface $manifest,
        string $sdkVersion
    ): CompatibilityResult;
}
```

---

# 139. Compatibility Result

```php
final readonly class CompatibilityResult
{
    public function __construct(
        public string $status,
        public array $errors = [],
        public array $warnings = [],
    ) {
    }
}
```

---

# 140. Compatibility Status

```text
SUPPORTED
SUPPORTED_WITH_WARNING
DEPRECATED
INCOMPATIBLE
UNKNOWN
```

---

# 141. Contract Test Kit

SDK should provide:

```text
FakeIdentityContext
FakeTenantContext
FakeAuthorizationService
FakeAuditRecorder
FakeConfiguration
FakeFeatureFlagService
InMemoryEventPublisher
InMemoryCommandBus
InMemoryQueryBus
FakeClock
FakeIdGenerator
FakeFileService
FakeJobDispatcher
```

---

# 142. Fake Tenant Context

Must preserve scope assertions.

---

# 143. Fake Authorization

Should allow explicit allow/deny scenarios.

---

# 144. In-Memory Event Publisher

Should capture published envelopes for assertions.

---

# 145. Contract Test Categories

```text
Signature Tests
Behavior Tests
Error Tests
Security Tests
Tenant Isolation Tests
Compatibility Tests
Serialization Tests
Idempotency Tests
```

---

# 146. Signature Tests

Verify contract signatures remain compatible.

---

# 147. Behavior Tests

Verify implementation semantics.

---

# 148. Error Tests

Verify stable error codes and retryability.

---

# 149. Security Tests

Verify:

- missing authorization denied;
- missing tenant context denied;
- raw secret not exposed;
- privileged operation audited.

---

# 150. Tenant Isolation Tests

Verify cross-tenant access is denied.

---

# 151. Serialization Tests

Verify DTO/event serialization remains compatible.

---

# 152. Idempotency Tests

Verify duplicate command/job/event handling.

---

# 153. Consumer-Driven Tests

Modules may publish consumer expectations for kernel capability implementations.

---

# 154. Certification Suite

A module passes certification when:

- manifest valid;
- contracts resolve;
- capabilities available;
- authorization works;
- tenant isolation passes;
- events valid;
- health check passes;
- observability works;
- compatibility passes.

---

# 155. Architecture Tests

Automated checks should reject imports from:

```text
Platform\Kernel\Internal
App\Kernel\Infrastructure\Internal
OtherModule\Infrastructure
```

---

# 156. Static Analysis

SDK contracts should be validated with high static-analysis strictness.

---

# 157. Documentation Requirements

Each stable contract must document:

- purpose;
- inputs;
- outputs;
- errors;
- side effects;
- tenant behavior;
- authorization;
- idempotency;
- examples;
- stability.

---

# 158. Contract Reference Template

```text
Contract Name
Namespace
Stability
Owner
Purpose
Method Signatures
Input Rules
Output Rules
Error Codes
Authorization
Tenant Scope
Side Effects
Idempotency
Observability
Examples
```

---

# 159. Governance

Public stable contract changes require review.

---

# 160. Contract Owner

Every contract must have owner.

---

# 161. Review Triggers

Mandatory review when changing:

- authorization;
- tenant context;
- event schema;
- file access;
- secrets;
- workflow transitions;
- privileged jobs;
- module lifecycle.

---

# 162. Approval Matrix

| Change | Approval |
|---|---|
| Patch documentation | Contract Owner |
| Additive experimental contract | SDK Owner |
| Stable additive contract | Platform Architecture |
| Breaking contract | Architecture Review Board |
| Security-sensitive contract | Architecture + Security |
| Data contract change | Architecture + Data Governance |

---

# 163. Contract Registry

Recommended metadata:

```text
contract_code
namespace
version
stability
owner
introduced_in
deprecated_in
removed_in
documentation_reference
```

---

# 164. Database Direction

Potential tables:

```text
sdk_contracts
sdk_contract_versions
sdk_contract_owners
sdk_contract_deprecations
sdk_contract_compatibility
sdk_contract_test_results
```

---

# 165. Table: sdk_contracts

```sql
CREATE TABLE sdk_contracts (
    id CHAR(26) NOT NULL,
    contract_code VARCHAR(180) NOT NULL,
    namespace_name VARCHAR(500) NOT NULL,
    contract_type VARCHAR(50) NOT NULL,
    owner_reference VARCHAR(180) NOT NULL,
    stability VARCHAR(30) NOT NULL,
    current_version VARCHAR(100) NOT NULL,
    status VARCHAR(30) NOT NULL,

    PRIMARY KEY (id),
    UNIQUE KEY uq_sdk_contract_code (
        contract_code
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

# 166. Table: sdk_contract_versions

```sql
CREATE TABLE sdk_contract_versions (
    id CHAR(26) NOT NULL,
    contract_id CHAR(26) NOT NULL,
    version VARCHAR(100) NOT NULL,
    signature_hash CHAR(64) NOT NULL,
    schema_reference VARCHAR(1000) NULL,
    introduced_in VARCHAR(100) NOT NULL,
    deprecated_in VARCHAR(100) NULL,
    removed_in VARCHAR(100) NULL,
    status VARCHAR(30) NOT NULL,

    PRIMARY KEY (id),
    UNIQUE KEY uq_sdk_contract_version (
        contract_id,
        version
    ),
    CONSTRAINT fk_sdk_contract_version_contract
        FOREIGN KEY (contract_id)
        REFERENCES sdk_contracts (id)
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

# 167. Table: sdk_contract_test_results

```sql
CREATE TABLE sdk_contract_test_results (
    id CHAR(26) NOT NULL,
    contract_version_id CHAR(26) NOT NULL,
    consumer_module VARCHAR(100) NOT NULL,
    consumer_version VARCHAR(100) NOT NULL,
    test_suite VARCHAR(100) NOT NULL,
    result VARCHAR(30) NOT NULL,
    report_reference VARCHAR(1000) NULL,
    tested_at DATETIME(6) NOT NULL,

    PRIMARY KEY (id),
    KEY idx_sdk_contract_test_result (
        result,
        tested_at
    ),
    CONSTRAINT fk_sdk_contract_test_version
        FOREIGN KEY (contract_version_id)
        REFERENCES sdk_contract_versions (id)
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

# 168. Contract Event Codes

```text
SDK_CONTRACT_REGISTERED
SDK_CONTRACT_VERSION_PUBLISHED
SDK_CONTRACT_DEPRECATED
SDK_CONTRACT_RETIRED
SDK_CONTRACT_TEST_PASSED
SDK_CONTRACT_TEST_FAILED
SDK_CONTRACT_COMPATIBILITY_FAILED
SDK_CONTRACT_SECURITY_REVIEW_REQUIRED
```

---

# 169. Contract Error Codes

```text
SDK_CONTRACT_NOT_FOUND
SDK_CONTRACT_VERSION_INVALID
SDK_CONTRACT_SIGNATURE_MISMATCH
SDK_CONTRACT_INCOMPATIBLE
SDK_CONTRACT_DEPRECATED
SDK_CONTRACT_RETIRED
SDK_CONTRACT_IMPLEMENTATION_INVALID
SDK_CONTRACT_TEST_FAILED
```

---

# 170. Metrics

```text
sdk_contract_total
sdk_stable_contract_total
sdk_experimental_contract_total
sdk_deprecated_contract_total
sdk_contract_test_failure_total
sdk_compatibility_failure_total
sdk_direct_kernel_dependency_total
sdk_cross_tenant_contract_failure_total
```

---

# 171. Initial KPIs

```text
Stable contracts without owner = 0
Production modules with direct kernel internal dependency = 0
Incompatible contract deployment = 0
Critical contract test failures unresolved = 0
Cross-tenant contract test failures = 0
Breaking changes with migration guide = 100%
```

---

# 172. Dashboard Views

Recommended:

- contracts by stability;
- contract versions;
- deprecated usage;
- consumer modules;
- compatibility failures;
- contract test failures;
- security review status;
- direct kernel dependency violations.

---

# 173. Reference Contract Package Structure

```text
src/
├── Module/
├── Identity/
├── Authorization/
├── Tenancy/
├── Audit/
├── Configuration/
├── Commands/
├── Queries/
├── Events/
├── Workflow/
├── Notification/
├── Files/
├── Jobs/
├── Menu/
├── Observability/
├── Health/
└── Support/
```

---

# 174. Reference Module Contract Usage

```php
final class AssignHomecareNurseHandler
{
    public function __construct(
        private AuthorizationServiceInterface $authorization,
        private AuditRecorderInterface $audit,
        private EventPublisherInterface $events,
        private HomecareVisitRepositoryInterface $visits,
    ) {
    }

    public function handle(
        AssignHomecareNurse $command,
        IdentityContextInterface $identity,
        TenantContextInterface $tenant,
        CorrelationContext $correlation,
    ): CommandResult {
        $this->authorization->require(
            new AuthorizationRequest(
                permission: 'homecare.visit.assign',
                resource: new ResourceReference(
                    type: 'homecare_visit',
                    id: $command->visitId,
                ),
                tenant: $tenant,
                identity: $identity,
                correlation: $correlation,
            )
        );

        $visit = $this->visits->getById(
            $command->visitId,
            $tenant
        );

        if ($visit === null) {
            throw new VisitNotFoundException(
                'HOMECARE_VISIT_NOT_FOUND'
            );
        }

        $visit->assignNurse($command->nurseId);
        $this->visits->save($visit, $tenant);

        return new CommandResult(
            status: 'SUCCESS',
            resource: new ResourceReference(
                type: 'homecare_visit',
                id: $visit->id(),
            ),
        );
    }
}
```

---

# 175. Contract Review Checklist

- [ ] Purpose clear.
- [ ] Owner assigned.
- [ ] Stability assigned.
- [ ] Inputs typed.
- [ ] Outputs typed.
- [ ] Errors defined.
- [ ] Tenant behavior defined.
- [ ] Authorization defined.
- [ ] Side effects documented.
- [ ] Idempotency documented.
- [ ] Observability documented.
- [ ] Compatibility assessed.
- [ ] Tests available.

---

# 176. Module Contract Adoption Checklist

- [ ] Manifest uses SDK contract.
- [ ] Provider uses SDK registry.
- [ ] Identity context used.
- [ ] Tenant context used.
- [ ] Authorization contract used.
- [ ] Audit contract used.
- [ ] Configuration contract used.
- [ ] Events use envelope/version.
- [ ] Jobs carry tenant context.
- [ ] Files use opaque references.
- [ ] Menu does not replace authorization.
- [ ] Health check implemented.
- [ ] Contract tests pass.

---

# 177. UAT — Contract Conventions

- [ ] Interfaces are small.
- [ ] DTOs are immutable.
- [ ] Stable identifiers are used.
- [ ] DateTimeImmutable is used.
- [ ] Nullability is explicit.
- [ ] Error codes are stable.
- [ ] Retryability is explicit.
- [ ] Correlation context is preserved.

---

# 178. UAT — Module Lifecycle

- [ ] Manifest contract works.
- [ ] Provider contract works.
- [ ] Registry rejects duplicates.
- [ ] Boot receives runtime context.
- [ ] Lifecycle hooks are idempotent.
- [ ] Failed boot leaves module inactive.
- [ ] Dependencies are validated.
- [ ] Capabilities are resolved.

---

# 179. UAT — Identity, Authorization & Tenancy

- [ ] Identity context is trusted.
- [ ] Assurance level available.
- [ ] Authorization decision returns reason.
- [ ] Authorization require throws stable error.
- [ ] Tenant context is mandatory.
- [ ] Raw request tenant IDs are rejected.
- [ ] Global scope is privileged.
- [ ] Cross-tenant access is denied.

---

# 180. UAT — Audit, Config & Feature Flags

- [ ] Audit events are structured.
- [ ] Sensitive data is minimized.
- [ ] Config reads are typed.
- [ ] Missing config fails correctly.
- [ ] Module/tenant scope works.
- [ ] Feature flags return reason/version.
- [ ] Feature flags do not bypass authorization.
- [ ] Config version is observable.

---

# 181. UAT — Commands, Queries & Events

- [ ] Commands are immutable.
- [ ] Command envelopes carry context.
- [ ] Idempotency keys work.
- [ ] Queries do not mutate.
- [ ] Pagination works.
- [ ] Events are versioned.
- [ ] Duplicate events are tolerated.
- [ ] Outbox contract works.

---

# 182. UAT — Workflow, Notification & Files

- [ ] Workflow start works.
- [ ] Workflow transition enforces scope.
- [ ] Notification is channel-neutral.
- [ ] Notification idempotency works.
- [ ] File upload returns opaque reference.
- [ ] Download authorization works.
- [ ] Physical paths are hidden.
- [ ] Quarantine state is visible.

---

# 183. UAT — Jobs, Menu & Observability

- [ ] Jobs carry tenant context.
- [ ] Job retries are bounded.
- [ ] Scheduler descriptors validate.
- [ ] Menu contribution is deterministic.
- [ ] Permission visibility works.
- [ ] Menu is not used as authorization.
- [ ] Logs include module/correlation context.
- [ ] Metrics avoid high-cardinality labels.
- [ ] Health checks are safe and fast.

---

# 184. UAT — Compatibility & Testing

- [ ] Contract versions are registered.
- [ ] Signature changes are detected.
- [ ] Compatibility checker works.
- [ ] Deprecated usage is visible.
- [ ] Contract test kit works.
- [ ] Security tests pass.
- [ ] Tenant isolation tests pass.
- [ ] Serialization tests pass.
- [ ] Certification blocks incompatible module.

---

# 185. UAT — Governance

- [ ] Contract owners exist.
- [ ] Stable changes are reviewed.
- [ ] Breaking changes use ADR.
- [ ] Security-sensitive changes receive review.
- [ ] Changelog updated.
- [ ] Migration guide exists.
- [ ] Metrics and dashboards defined.
- [ ] Registry is auditable.

---

# 186. Definition of Done — SSOT-SDK-02

SSOT-SDK-02 dianggap selesai bila:

- [ ] objectives/principles tersedia;
- [ ] contract taxonomy tersedia;
- [ ] stability classification tersedia;
- [ ] naming/namespace rules tersedia;
- [ ] interface/DTO/value object rules tersedia;
- [ ] result/error/retry contracts tersedia;
- [ ] correlation context tersedia;
- [ ] manifest/provider/registry contracts tersedia;
- [ ] lifecycle hooks tersedia;
- [ ] capability contracts tersedia;
- [ ] identity contract tersedia;
- [ ] authorization contract tersedia;
- [ ] tenant context tersedia;
- [ ] audit contract tersedia;
- [ ] configuration contract tersedia;
- [ ] feature flag contract tersedia;
- [ ] command/query contracts tersedia;
- [ ] event/outbox contracts tersedia;
- [ ] workflow contract tersedia;
- [ ] notification contract tersedia;
- [ ] file contract tersedia;
- [ ] job/scheduler contracts tersedia;
- [ ] menu contract tersedia;
- [ ] observability/health contracts tersedia;
- [ ] extension contracts tersedia;
- [ ] repository/transaction guidance tersedia;
- [ ] clock/ID/locale contracts tersedia;
- [ ] remote/local adapter guidance tersedia;
- [ ] idempotency contract tersedia;
- [ ] versioning/compatibility/deprecation tersedia;
- [ ] contract test kit tersedia;
- [ ] certification suite tersedia;
- [ ] architecture/static analysis guidance tersedia;
- [ ] documentation/governance tersedia;
- [ ] registry/database direction tersedia;
- [ ] event/error codes tersedia;
- [ ] metrics/KPI/dashboard tersedia;
- [ ] reference usage tersedia;
- [ ] checklists/UAT tersedia.

---

# 187. Implementation Roadmap

## Phase 1 — Foundational Contracts

- identifiers;
- correlation context;
- manifest;
- provider;
- registry;
- error contracts;
- clock/ID generator.

## Phase 2 — Security & Context

- identity;
- authorization;
- tenant context;
- audit;
- configuration;
- feature flags.

## Phase 3 — Interaction Contracts

- commands;
- queries;
- events;
- outbox;
- workflow;
- notification.

## Phase 4 — Operational Contracts

- files;
- jobs;
- scheduler;
- menu;
- observability;
- health.

## Phase 5 — Compatibility & Certification

- contract registry;
- versioning;
- compatibility checker;
- test kit;
- module certification;
- deprecation management.

---

# 188. Initial Contract Backlog

```text
SDKC-001 Identifier Contracts
SDKC-002 Correlation Context
SDKC-003 Module Manifest
SDKC-004 Module Provider
SDKC-005 Module Registry
SDKC-006 Identity Context
SDKC-007 Tenant Context
SDKC-008 Authorization Service
SDKC-009 Audit Recorder
SDKC-010 Configuration Service
SDKC-011 Feature Flag Service
SDKC-012 Command Bus
SDKC-013 Query Bus
SDKC-014 Event Publisher
SDKC-015 Workflow Service
SDKC-016 Notification Service
SDKC-017 File Service
SDKC-018 Job Dispatcher
SDKC-019 Menu Contributor
SDKC-020 Observability Contracts
SDKC-021 Health Check
SDKC-022 Compatibility Checker
SDKC-023 Contract Test Kit
```

---

# 189. Approval Gate

Dokumen dapat menjadi Approved setelah:

- Platform Architecture review;
- SDK Technical Owner review;
- Security Governance review;
- Multi-tenant isolation review;
- Data Architecture review;
- Module Owner review;
- QA/Contract Testing review;
- Observability review;
- Release Engineering review;
- compatibility and deprecation review.

---

# 190. Closing Statement

Module SDK Contracts harus memastikan setiap interaksi module:

- menggunakan typed contract;
- menggunakan trusted identity;
- menggunakan trusted tenant context;
- melakukan authorization;
- dapat diaudit;
- memiliki stable error semantics;
- membawa correlation context;
- dapat diuji;
- dapat di-version;
- dapat dipromosikan tanpa ketergantungan pada kernel internals.

Contract bukan sekadar interface teknis.

Contract adalah boundary governance yang menjaga security, compatibility, modularity, dan evolusi seluruh platform.
