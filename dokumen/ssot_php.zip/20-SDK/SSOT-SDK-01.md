# SSOT-SDK-01 — Platform SDK Architecture

---

## Status Dokumen

| Item | Nilai |
|---|---|
| Kode | SSOT-SDK-01 |
| Judul | Platform SDK Architecture |
| Versi | 1.0 |
| Status | Draft for Review |
| Domain | Platform Kernel |
| Kategori | Platform SDK, Module Architecture & Extension Governance |
| Cakupan | SDK Boundaries, Contracts, Module Bootstrap, Capabilities, Extensions, Compatibility, Versioning, Testing, Governance |
| Bergantung pada | SSOT-GOV-01, SSOT-GOV-02, SSOT-GOV-03, SSOT-DEPLOY-01, SSOT-SEC-01 |
| Target Stack | PHP 8.1+, Composer, PSR-4, Modular Monolith |
| Target Evolusi | Microservice-ready, Package-ready, Multi-industry Platform |

---

# 1. Executive Summary

SSOT-SDK-01 menetapkan arsitektur resmi Platform SDK untuk Platform Kernel dan seluruh module bisnis.

Platform SDK berfungsi sebagai kontrak stabil antara:

```text
Platform Kernel
↔
Business Modules
↔
External/Internal Extensions
```

Dokumen ini mengatur:

- boundary antara Kernel dan SDK;
- public contracts;
- module bootstrap;
- module manifest;
- capability access;
- extension points;
- events;
- commands;
- queries;
- repositories;
- workflow integration;
- notification integration;
- menu integration;
- configuration integration;
- authorization integration;
- tenant context;
- compatibility;
- semantic versioning;
- deprecation;
- testing;
- documentation;
- governance;
- UAT;
- Definition of Done.

Tujuan akhirnya adalah memastikan business modules:

- tidak bergantung langsung pada kernel internals;
- menggunakan contract yang stabil;
- dapat dikembangkan secara konsisten;
- dapat diuji secara terisolasi;
- dapat diaktifkan per tenant;
- dapat berkembang tanpa menciptakan tight coupling;
- siap diekstrak menjadi service di masa depan.

---

# 2. SDK Vision

Platform SDK harus menjadi:

```text
Stable Contract Surface
Module Integration Boundary
Capability Gateway
Extension Framework
Compatibility Layer
Migration Enabler
```

SDK tidak boleh menjadi tempat menaruh seluruh shared code.

SDK harus kecil, stabil, eksplisit, dan governed.

---

# 3. Objectives

Platform SDK harus:

- memisahkan business module dari kernel implementation;
- menyediakan contract yang konsisten;
- mengontrol dependency direction;
- mendukung module registration;
- menyediakan capability access;
- mendukung extension points;
- menjaga backward compatibility;
- mendukung versioned evolution;
- meningkatkan testability;
- mendukung future extraction ke microservices.

---

# 4. Core Principles

```text
Contracts over Implementations
Stable Surface, Flexible Internals
Explicit Dependencies
No Kernel Internals Leakage
Small SDK Surface
Backward Compatibility by Default
Capability-Based Access
Tenant-Aware by Design
Secure by Default
Testable and Documented
```

---

# 5. Scope

Platform SDK mencakup:

```text
Module Contracts
Module Manifest
Module Registration
Service Contracts
Command/Query Contracts
Event Contracts
Repository Contracts
Authorization Contracts
Tenant Context
Configuration Contracts
Workflow Contracts
Notification Contracts
Menu Contracts
Audit Contracts
Observability Contracts
File Contracts
Job/Scheduler Contracts
Extension Points
Compatibility Layer
```

---

# 6. Non-Scope

Platform SDK bukan tempat untuk:

- business-specific domain logic;
- concrete infrastructure implementation;
- direct database access;
- global helper dumping ground;
- UI templates;
- internal kernel classes;
- environment-specific secrets;
- mutable global state.

---

# 7. High-Level Architecture

```text
Business Module
    │
    ▼
Platform SDK Contracts
    │
    ▼
Platform Kernel Implementations
    │
    ├── IAM
    ├── RBAC
    ├── Audit
    ├── Workflow
    ├── Notification
    ├── Configuration
    ├── Observability
    ├── Files
    └── Integration
```

---

# 8. Dependency Direction

Allowed:

```text
Business Module
→ Platform SDK
→ Shared Standards
```

Not allowed:

```text
Business Module
→ Platform Kernel Internal Implementation
```

---

# 9. Kernel-to-SDK Rule

Kernel implementations may implement SDK contracts.

SDK contracts must not depend on kernel implementations.

---

# 10. Module-to-Module Rule

Modules should communicate through:

- published contracts;
- commands;
- queries;
- events;
- approved shared identifiers;
- SDK extension points.

Modules must not directly access another module's private classes or private tables.

---

# 11. SDK Package Structure

Recommended:

```text
packages/
└── platform-sdk/
    ├── src/
    │   ├── Contracts/
    │   ├── Module/
    │   ├── Identity/
    │   ├── Authorization/
    │   ├── Tenancy/
    │   ├── Audit/
    │   ├── Events/
    │   ├── Commands/
    │   ├── Queries/
    │   ├── Workflow/
    │   ├── Notification/
    │   ├── Menu/
    │   ├── Configuration/
    │   ├── Files/
    │   ├── Observability/
    │   ├── Jobs/
    │   └── Support/
    ├── tests/
    ├── composer.json
    ├── CHANGELOG.md
    ├── README.md
    └── VERSION
```

---

# 12. Namespace Standard

Recommended:

```php
namespace Platform\Sdk;
```

Examples:

```php
Platform\Sdk\Contracts
Platform\Sdk\Module
Platform\Sdk\Authorization
Platform\Sdk\Tenancy
```

---

# 13. SDK Composer Package

Recommended package name:

```text
platform/kernel-sdk
```

or organization-specific equivalent.

---

# 14. Composer Contract

Example:

```json
{
  "name": "platform/kernel-sdk",
  "type": "library",
  "autoload": {
    "psr-4": {
      "Platform\\Sdk\\": "src/"
    }
  },
  "require": {
    "php": "^8.1"
  }
}
```

---

# 15. SDK Surface Classification

```text
PUBLIC_STABLE
PUBLIC_EXPERIMENTAL
INTERNAL
DEPRECATED
RETIRED
```

---

# 16. Public Stable

May be used by production modules.

Must follow compatibility rules.

---

# 17. Public Experimental

May change with documented notice.

Must be explicitly marked.

---

# 18. Internal

Must not be consumed by modules.

---

# 19. Deprecated

Still available temporarily with replacement path.

---

# 20. Retired

No longer available.

---

# 21. Contract Design

Contracts should be:

- small;
- cohesive;
- implementation-neutral;
- explicitly typed;
- stable;
- documented;
- versioned where necessary.

---

# 22. Interface Rules

SDK interfaces must:

- use domain-neutral or platform-level terminology;
- avoid leaking database details;
- avoid framework-specific types where possible;
- avoid returning untyped arrays;
- avoid exposing service container;
- avoid exposing raw PDO.

---

# 23. DTO Rules

SDK DTOs should be:

- immutable;
- typed;
- serialization-aware where needed;
- free from infrastructure dependencies;
- version-safe.

---

# 24. Value Object Rules

Use SDK value objects for:

- TenantId;
- ClinicId;
- UserId;
- ModuleId;
- PermissionCode;
- CorrelationId;
- RequestId;
- FileReference;
- EventId.

---

# 25. Result Objects

Prefer explicit result objects over ambiguous arrays.

Example:

```php
final readonly class AuthorizationDecision
{
    public function __construct(
        public bool $allowed,
        public string $reasonCode,
        public ?string $policyReference = null,
    ) {
    }
}
```

---

# 26. Error Contract

SDK should define stable error abstractions.

Examples:

```text
SdkException
ContractViolationException
CapabilityUnavailableException
AuthorizationDeniedException
ConfigurationException
ModuleRegistrationException
```

---

# 27. Error Codes

Use stable error codes.

Examples:

```text
SDK_CAPABILITY_NOT_AVAILABLE
SDK_MODULE_NOT_REGISTERED
SDK_VERSION_INCOMPATIBLE
SDK_PERMISSION_DENIED
SDK_TENANT_CONTEXT_MISSING
SDK_EXTENSION_POINT_NOT_FOUND
```

---

# 28. Module Architecture

Every business module should expose:

```text
Module Manifest
Module Provider
Public Contracts
Events
Permissions
Configuration Definitions
Migrations
Menu Contributions
Workflow Contributions
Health Checks
```

---

# 29. Module Manifest

Minimum fields:

```text
module_id
name
version
sdk_version
status
capabilities_required
capabilities_provided
dependencies
permissions
configuration_keys
migrations
events
owner
```

---

# 30. Module Manifest Example

```yaml
module_id: homecare
name: Homecare Module
version: 1.4.0
sdk_version: ^1.0
status: ACTIVE
capabilities_required:
  - identity
  - authorization
  - audit
  - workflow
  - notification
capabilities_provided:
  - homecare.visit
dependencies:
  - patient >=1.2
permissions:
  - homecare.visit.create
  - homecare.visit.assign
owner: homecare_team
```

---

# 31. Module Status

```text
DRAFT
REGISTERED
ACTIVE
DISABLED
DEPRECATED
RETIRED
FAILED
```

---

# 32. Module Provider

Module provider is responsible for:

- registration;
- contract binding;
- routes;
- events;
- configuration;
- permissions;
- menu contributions;
- health checks.

---

# 33. Module Provider Interface

Example:

```php
interface ModuleProviderInterface
{
    public function manifest(): ModuleManifest;

    public function register(ModuleRegistryInterface $registry): void;

    public function boot(ModuleRuntimeContext $context): void;
}
```

---

# 34. Registration vs Boot

`register()`:

- define contracts;
- register services;
- declare capabilities;
- avoid runtime I/O.

`boot()`:

- activate runtime hooks;
- register event subscriptions;
- validate readiness;
- may use resolved services.

---

# 35. Module Registry

Module registry should manage:

- module identity;
- versions;
- dependencies;
- capabilities;
- activation;
- status;
- compatibility.

---

# 36. Module Dependency Rules

Dependencies must be:

- explicit;
- versioned;
- cycle-free;
- validated before activation.

---

# 37. Circular Dependencies

Circular module dependencies are prohibited.

---

# 38. Optional Dependencies

Optional dependency must define fallback behavior.

---

# 39. Capability Model

SDK should expose capabilities, not arbitrary service access.

Examples:

```text
identity
authorization
audit
workflow
notification
files
configuration
observability
jobs
menu
```

---

# 40. Capability Contract

Each capability should define:

- name;
- version;
- contract;
- availability;
- owner;
- fallback behavior.

---

# 41. Capability Registry

Potential operations:

```php
interface CapabilityRegistryInterface
{
    public function has(string $capability): bool;

    public function version(string $capability): ?string;

    public function resolve(string $capability): object;
}
```

---

# 42. Capability Access

Modules must request only required capabilities.

---

# 43. Capability Denial

Unavailable capability should fail predictably.

---

# 44. Identity Capability

Should expose:

- current actor;
- actor ID;
- authentication assurance;
- user status;
- actor type.

---

# 45. Authorization Capability

Should expose:

- permission checks;
- policy checks;
- resource authorization;
- denial reason;
- tenant/scope-aware decisions.

---

# 46. Tenant Context Capability

Should expose trusted:

- tenant ID;
- clinic ID;
- organization ID;
- active scope;
- scope assertions.

---

# 47. Tenant Context Rule

Modules must not build trusted tenant context from raw request input.

---

# 48. Audit Capability

Should support:

- business audit events;
- security audit events;
- actor context;
- tenant context;
- correlation IDs;
- before/after references where allowed.

---

# 49. Configuration Capability

Should expose:

- typed config reads;
- module-scoped config;
- tenant-scoped config;
- feature flag checks;
- version metadata.

---

# 50. Notification Capability

Should expose:

- channel-neutral requests;
- templates;
- recipients;
- delivery status;
- idempotency.

---

# 51. Workflow Capability

Should expose:

- workflow start;
- transition;
- assignment;
- approval;
- status query;
- history.

---

# 52. File Capability

Should expose:

- secure upload;
- secure download reference;
- authorization;
- tenant binding;
- metadata;
- checksum;
- quarantine status.

---

# 53. Observability Capability

Should expose:

- structured logging;
- metrics;
- tracing context;
- request/correlation IDs;
- module health indicators.

---

# 54. Job Capability

Should expose:

- job dispatch;
- scheduling registration;
- retry policy;
- idempotency key;
- tenant context.

---

# 55. Menu Capability

Should expose:

- menu contribution;
- permission visibility;
- module status;
- route reference;
- ordering.

Menu visibility must not replace authorization.

---

# 56. Command Architecture

Commands represent intent to change state.

Examples:

```text
CreatePatient
AssignHomecareNurse
ApprovePrivilegedAccess
RotateCredential
```

---

# 57. Command Rules

Commands should:

- be immutable;
- be explicit;
- carry stable identifiers;
- avoid infrastructure objects;
- be validated before handling.

---

# 58. Command Handler Contract

Example:

```php
interface CommandHandlerInterface
{
    public function handle(object $command): object;
}
```

A stronger generic abstraction may be implemented if supported.

---

# 59. Query Architecture

Queries retrieve data without changing state.

---

# 60. Query Rules

Queries should:

- be explicit;
- be bounded;
- support tenant scope;
- use typed result DTOs;
- avoid exposing internal persistence models.

---

# 61. Command Bus

SDK may define a command bus contract.

---

# 62. Query Bus

SDK may define a query bus contract.

---

# 63. Bus Independence

SDK bus contracts should not leak framework-specific implementation.

---

# 64. Event Architecture

Events represent facts that occurred.

Examples:

```text
PatientCreated
HomecareVisitAssigned
RoleAssignmentGranted
FileQuarantined
```

---

# 65. Event Rules

Events should be:

- immutable;
- past tense;
- versioned where externally consumed;
- tenant-aware where applicable;
- free from unnecessary sensitive data.

---

# 66. Event Envelope

Recommended fields:

```text
event_id
event_type
event_version
occurred_at
tenant_id
actor_id
correlation_id
causation_id
payload
```

---

# 67. Event Contract Example

```php
interface PlatformEventInterface
{
    public function eventId(): string;

    public function eventType(): string;

    public function eventVersion(): int;

    public function occurredAt(): \DateTimeImmutable;
}
```

---

# 68. Event Versioning

Breaking event payload changes require new event version.

---

# 69. Event Compatibility

Consumers should tolerate additive fields where possible.

---

# 70. Event Publication

Publication should use approved event/outbox infrastructure.

---

# 71. Event Idempotency

Consumers must handle duplicate delivery.

---

# 72. Repository Contracts

Repository contracts should be module-owned where business-specific.

Platform SDK should define only cross-cutting repository abstractions if necessary.

---

# 73. Repository Boundary

SDK must not expose generic unrestricted data repository.

---

# 74. Transaction Contract

SDK may expose application transaction boundary.

Example:

```php
interface TransactionManagerInterface
{
    public function transactional(callable $operation): mixed;
}
```

---

# 75. Transaction Rules

Transactions should not span uncontrolled external systems.

---

# 76. Extension Points

Extension points allow controlled module contribution.

Examples:

```text
Menu Contributor
Workflow Step Provider
Notification Template Provider
Report Provider
Dashboard Widget Provider
Validation Rule Provider
Health Check Provider
Export Provider
```

---

# 77. Extension Point Contract

Each extension point should define:

- identifier;
- contract;
- lifecycle;
- ordering;
- conflict handling;
- version;
- security requirements.

---

# 78. Extension Registration

Extensions must be registered through SDK registry.

---

# 79. Extension Discovery

Use explicit registration.

Avoid uncontrolled filesystem scanning in production unless governed.

---

# 80. Extension Ordering

Ordering should be deterministic.

---

# 81. Extension Conflict

Conflict resolution should be explicit.

---

# 82. Extension Isolation

One extension failure should not silently corrupt other module behavior.

---

# 83. Plugin Model

External plugins may be supported later through a restricted plugin contract.

---

# 84. Plugin Trust Levels

```text
INTERNAL_TRUSTED
PARTNER_REVIEWED
THIRD_PARTY_RESTRICTED
```

---

# 85. Third-Party Plugin Restrictions

Third-party plugins should not receive unrestricted:

- database access;
- filesystem access;
- secrets;
- privileged capability access;
- cross-tenant access.

---

# 86. Module Bootstrap Lifecycle

```text
Discover
→ Validate Manifest
→ Resolve Dependencies
→ Register
→ Validate Capabilities
→ Boot
→ Health Check
→ Activate
```

---

# 87. Module Activation

Activation should verify:

- SDK compatibility;
- dependencies;
- migrations;
- permissions;
- config;
- required capabilities;
- health.

---

# 88. Module Deactivation

Deactivation should consider:

- active workflows;
- scheduled jobs;
- data ownership;
- routes;
- menu items;
- events;
- tenant enablement.

---

# 89. Module Retirement

Retirement requires:

- replacement/migration plan;
- data retention decision;
- event deprecation;
- dependency cleanup;
- tenant communication.

---

# 90. Tenant Module Enablement

Module enablement may be tenant-scoped.

---

# 91. Enablement Rules

Enablement should verify:

- license/entitlement where applicable;
- dependencies;
- permissions;
- configuration;
- data migrations;
- owner approval.

---

# 92. Clinic-Level Enablement

Clinic-level enablement may be supported only when module semantics allow.

---

# 93. SDK Versioning

Use semantic versioning:

```text
MAJOR.MINOR.PATCH
```

---

# 94. Major Version

May include breaking contract changes.

---

# 95. Minor Version

Adds backward-compatible capabilities or contracts.

---

# 96. Patch Version

Fixes defects without breaking public contracts.

---

# 97. Compatibility Declaration

Module manifest should declare supported SDK version.

Example:

```text
sdk_version: ^1.2
```

---

# 98. Compatibility Matrix

| Module Version | SDK Version | Status |
|---|---|---|
| 1.4.x | 1.2–1.x | Supported |
| 2.0.x | 2.x | Supported |
| 1.0.x | <1.2 | Deprecated |

---

# 99. Compatibility Modes

```text
SUPPORTED
SUPPORTED_WITH_WARNING
DEPRECATED
INCOMPATIBLE
UNKNOWN
```

---

# 100. Compatibility Check

Run during:

- module install;
- module activation;
- deployment;
- upgrade;
- CI.

---

# 101. Backward Compatibility Rules

Avoid breaking:

- interface methods;
- DTO fields;
- event payloads;
- enum values;
- error codes;
- capability names.

---

# 102. Additive Changes

Preferred evolution method:

- add optional methods only with safe strategy;
- add new contracts;
- add optional DTO fields;
- add new event version;
- add new capability version.

---

# 103. Interface Evolution

Changing existing interface methods is breaking.

Prefer a new interface version.

---

# 104. Contract Versioning

Examples:

```text
AuthorizationServiceInterfaceV2
patient.created.v2
capability.workflow@2
```

---

# 105. Deprecation Policy

Deprecation must include:

- deprecated item;
- replacement;
- migration guide;
- warning;
- removal version;
- owner.

---

# 106. Deprecation Window

Recommended minimum:

- one minor cycle for internal modules;
- one major cycle for broadly consumed stable contracts;
- longer where third-party modules exist.

---

# 107. Runtime Deprecation Warning

Warnings should be rate-limited and observable.

---

# 108. Changelog

SDK must maintain changelog.

---

# 109. Migration Guide

Breaking or substantial changes require migration guide.

---

# 110. SDK Release Notes

Must include:

- added contracts;
- changed contracts;
- deprecated contracts;
- removed contracts;
- security notes;
- migration notes.

---

# 111. Stability Annotations

SDK contracts should clearly state stability.

Example:

```php
/**
 * @api
 * @stability stable
 */
```

---

# 112. Security Architecture

SDK must enforce secure patterns by default.

---

# 113. Authorization Boundary

Modules must use SDK authorization contracts for platform-governed permissions.

---

# 114. Tenant Boundary

All tenant-aware capability calls must require trusted tenant context.

---

# 115. Sensitive Data

SDK DTOs should avoid carrying unnecessary sensitive data.

---

# 116. Secret Handling

SDK must expose references or secure operations, not raw long-lived secrets.

---

# 117. Auditability

Critical SDK operations should provide audit hooks.

---

# 118. Input Validation

SDK contract boundaries should validate type and semantic constraints.

---

# 119. Capability Least Privilege

Modules declare only required capabilities.

---

# 120. Privileged Capability

Privileged capabilities may require:

- higher assurance;
- explicit permission;
- approval;
- audit;
- time-bound access.

---

# 121. Observability Requirements

Every module should expose:

- module version;
- health;
- key metrics;
- structured log identity;
- failure events.

---

# 122. Module Health Contract

Example:

```php
interface ModuleHealthCheckInterface
{
    public function check(): ModuleHealthResult;
}
```

---

# 123. Health Status

```text
HEALTHY
DEGRADED
UNHEALTHY
UNKNOWN
```

---

# 124. Module Metrics

Recommended:

```text
module_request_total
module_error_total
module_command_total
module_event_failure_total
module_health_status
```

---

# 125. Logging Context

SDK should provide:

- module ID;
- tenant ID;
- actor ID;
- request ID;
- correlation ID;
- event code.

---

# 126. Testing Strategy

SDK testing layers:

```text
Contract Tests
Unit Tests
Compatibility Tests
Integration Tests
Module Bootstrap Tests
Security Tests
Tenant Isolation Tests
```

---

# 127. Contract Tests

Verify kernel implementation satisfies SDK contracts.

---

# 128. Module Consumer Tests

Verify module usage remains compatible.

---

# 129. Compatibility Tests

Test supported SDK/module version combinations.

---

# 130. Bootstrap Tests

Verify:

- manifest valid;
- dependencies resolved;
- capabilities available;
- module boot succeeds;
- health passes.

---

# 131. Security Tests

Verify:

- unauthorized capability denied;
- missing tenant context denied;
- invalid module manifest rejected;
- restricted extension blocked;
- secret leakage absent.

---

# 132. Tenant Isolation Tests

Verify module SDK operations cannot cross tenant/clinic scope.

---

# 133. SDK Test Kit

SDK should provide test utilities for modules.

Examples:

```text
FakeTenantContext
FakeAuthorizationService
InMemoryEventBus
TestModuleRegistry
FakeClock
FakeAuditRecorder
```

---

# 134. Test Kit Boundary

Test utilities must not leak production internals.

---

# 135. Module Certification

A module may be marked compatible only after passing SDK certification suite.

---

# 136. Certification Status

```text
NOT_TESTED
PASSED
PASSED_WITH_WARNING
FAILED
EXPIRED
```

---

# 137. SDK Governance

Platform Architecture owns SDK design.

---

# 138. SDK Change Approval

Changes to public stable contracts require:

- ADR for significant changes;
- architecture review;
- security/data review where applicable;
- compatibility assessment;
- migration plan.

---

# 139. SDK Ownership

Minimum roles:

```text
SDK Product Owner
SDK Technical Owner
Contract Owner
Compatibility Owner
Documentation Owner
Security Reviewer
```

---

# 140. SDK Decision Rights

| Change | Approval |
|---|---|
| Patch fix | SDK Technical Owner |
| Additive stable contract | Platform Architecture |
| Experimental contract | SDK Owner |
| Breaking contract | Architecture Review Board |
| Security-critical contract | Architecture + Security |

---

# 141. SDK Repository Governance

SDK repository should require:

- protected main branch;
- code review;
- tests;
- static analysis;
- changelog;
- version update;
- release evidence.

---

# 142. SDK Quality Gates

Block release when:

- contract tests fail;
- compatibility tests fail;
- breaking change undocumented;
- changelog missing;
- version incorrect;
- critical security finding open;
- documentation incomplete.

---

# 143. SDK Documentation

Required:

```text
Getting Started
Architecture Overview
Contract Reference
Module Manifest Guide
Module Bootstrap Guide
Capability Guide
Extension Guide
Compatibility Matrix
Migration Guide
Examples
```

---

# 144. Module Developer Guide

Should explain:

- create module;
- declare manifest;
- register provider;
- request capabilities;
- define permissions;
- define events;
- write tests;
- package module;
- validate compatibility.

---

# 145. Reference Module Structure

```text
app/Modules/Homecare/
├── Domain/
├── Application/
├── Infrastructure/
├── Presentation/
├── Contracts/
├── Module/
│   ├── HomecareModuleProvider.php
│   └── homecare.module.yaml
├── Database/
│   ├── Migrations/
│   └── Seeders/
├── Tests/
└── README.md
```

---

# 146. Reference Module Provider

```php
<?php

declare(strict_types=1);

namespace App\Modules\Homecare\Module;

use Platform\Sdk\Module\ModuleProviderInterface;
use Platform\Sdk\Module\ModuleRegistryInterface;
use Platform\Sdk\Module\ModuleRuntimeContext;
use Platform\Sdk\Module\ModuleManifest;

final class HomecareModuleProvider implements ModuleProviderInterface
{
    public function manifest(): ModuleManifest
    {
        return ModuleManifest::fromArray([
            'module_id' => 'homecare',
            'name' => 'Homecare Module',
            'version' => '1.4.0',
            'sdk_version' => '^1.0',
        ]);
    }

    public function register(ModuleRegistryInterface $registry): void
    {
        // Register public contracts and module capabilities.
    }

    public function boot(ModuleRuntimeContext $context): void
    {
        // Register runtime hooks and validate readiness.
    }
}
```

---

# 147. Reference Authorization Usage

```php
$decision = $authorization->decide(
    permission: 'homecare.visit.assign',
    resource: $visit,
    context: $tenantContext
);

if (!$decision->allowed) {
    throw new AuthorizationDeniedException(
        $decision->reasonCode
    );
}
```

---

# 148. Reference Event Envelope

```php
final readonly class EventEnvelope
{
    public function __construct(
        public string $eventId,
        public string $eventType,
        public int $eventVersion,
        public \DateTimeImmutable $occurredAt,
        public ?string $tenantId,
        public ?string $actorId,
        public string $correlationId,
        public array $payload,
    ) {
    }
}
```

---

# 149. Reference Capability Declaration

```yaml
capabilities_required:
  identity: "^1.0"
  authorization: "^1.1"
  audit: "^1.0"
  workflow: "^2.0"
```

---

# 150. SDK Runtime Registry Direction

Potential interfaces:

```text
ModuleRegistryInterface
CapabilityRegistryInterface
ExtensionRegistryInterface
ContractVersionRegistryInterface
CompatibilityCheckerInterface
ModuleHealthRegistryInterface
```

---

# 151. API Direction

Potential internal endpoints:

```text
GET  /api/internal/v1/sdk/modules
GET  /api/internal/v1/sdk/modules/{moduleId}
POST /api/internal/v1/sdk/modules/{moduleId}/validate
POST /api/internal/v1/sdk/modules/{moduleId}/activate
POST /api/internal/v1/sdk/modules/{moduleId}/deactivate
GET  /api/internal/v1/sdk/capabilities
GET  /api/internal/v1/sdk/compatibility
GET  /api/internal/v1/sdk/health
```

---

# 152. Database Direction

Potential tables:

```text
sdk_modules
sdk_module_versions
sdk_module_dependencies
sdk_capabilities
sdk_module_capabilities
sdk_extensions
sdk_compatibility_results
sdk_module_health
sdk_deprecations
```

---

# 153. Table: sdk_modules

```sql
CREATE TABLE sdk_modules (
    id CHAR(26) NOT NULL,
    module_code VARCHAR(100) NOT NULL,
    name VARCHAR(255) NOT NULL,
    owner_reference VARCHAR(180) NOT NULL,
    status VARCHAR(30) NOT NULL,
    current_version VARCHAR(100) NULL,
    created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    updated_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6)
        ON UPDATE CURRENT_TIMESTAMP(6),

    PRIMARY KEY (id),
    UNIQUE KEY uq_sdk_module_code (
        module_code
    ),
    KEY idx_sdk_module_status (
        status,
        current_version
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

# 154. Table: sdk_module_versions

```sql
CREATE TABLE sdk_module_versions (
    id CHAR(26) NOT NULL,
    module_id CHAR(26) NOT NULL,
    module_version VARCHAR(100) NOT NULL,
    sdk_version_constraint VARCHAR(100) NOT NULL,
    manifest_json JSON NOT NULL,
    artifact_reference VARCHAR(1000) NULL,
    status VARCHAR(30) NOT NULL,
    certified_at DATETIME(6) NULL,

    PRIMARY KEY (id),
    UNIQUE KEY uq_sdk_module_version (
        module_id,
        module_version
    ),
    CONSTRAINT fk_sdk_module_version_module
        FOREIGN KEY (module_id)
        REFERENCES sdk_modules (id)
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

# 155. Table: sdk_capabilities

```sql
CREATE TABLE sdk_capabilities (
    id CHAR(26) NOT NULL,
    capability_code VARCHAR(150) NOT NULL,
    capability_version VARCHAR(100) NOT NULL,
    owner_reference VARCHAR(180) NOT NULL,
    stability VARCHAR(30) NOT NULL,
    status VARCHAR(30) NOT NULL,
    deprecated_at DATETIME(6) NULL,
    retired_at DATETIME(6) NULL,

    PRIMARY KEY (id),
    UNIQUE KEY uq_sdk_capability_version (
        capability_code,
        capability_version
    )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

# 156. Table: sdk_module_dependencies

```sql
CREATE TABLE sdk_module_dependencies (
    id CHAR(26) NOT NULL,
    module_version_id CHAR(26) NOT NULL,
    dependency_module_code VARCHAR(100) NOT NULL,
    version_constraint VARCHAR(100) NOT NULL,
    optional_flag TINYINT(1) NOT NULL DEFAULT 0,

    PRIMARY KEY (id),
    UNIQUE KEY uq_sdk_module_dependency (
        module_version_id,
        dependency_module_code
    ),
    CONSTRAINT fk_sdk_dependency_module_version
        FOREIGN KEY (module_version_id)
        REFERENCES sdk_module_versions (id)
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
```

---

# 157. SDK Event Codes

```text
SDK_MODULE_DISCOVERED
SDK_MODULE_REGISTERED
SDK_MODULE_VALIDATED
SDK_MODULE_ACTIVATED
SDK_MODULE_DEACTIVATED
SDK_MODULE_FAILED
SDK_CAPABILITY_REGISTERED
SDK_CAPABILITY_UNAVAILABLE
SDK_COMPATIBILITY_CHECK_PASSED
SDK_COMPATIBILITY_CHECK_FAILED
SDK_CONTRACT_DEPRECATED
SDK_CONTRACT_RETIRED
```

---

# 158. SDK Error Codes

```text
SDK_MODULE_NOT_FOUND
SDK_MANIFEST_INVALID
SDK_VERSION_INCOMPATIBLE
SDK_DEPENDENCY_MISSING
SDK_DEPENDENCY_CYCLE
SDK_CAPABILITY_NOT_AVAILABLE
SDK_EXTENSION_CONFLICT
SDK_MODULE_BOOT_FAILED
SDK_TENANT_CONTEXT_MISSING
SDK_PERMISSION_DENIED
SDK_CONTRACT_DEPRECATED
SDK_CONTRACT_RETIRED
```

---

# 159. SDK Metrics

```text
sdk_module_total
sdk_module_active_total
sdk_module_failed_total
sdk_compatibility_failure_total
sdk_deprecated_contract_usage_total
sdk_capability_resolution_failure_total
sdk_module_boot_duration_seconds
sdk_module_health_failure_total
sdk_extension_conflict_total
```

---

# 160. Initial KPIs

```text
Active modules using kernel internals directly = 0
Production modules without valid manifest = 0
Incompatible module activation = 0
Critical SDK contract without owner = 0
Stable contract changes with migration guide = 100%
Module certification pass rate = 100% before production
```

---

# 161. SDK Dashboard

Recommended views:

- modules by status;
- module versions;
- SDK compatibility;
- capability usage;
- deprecated contract usage;
- module health;
- dependency graph;
- failed activations;
- extension conflicts.

---

# 162. SDK Change Workflow

```text
Proposal
→ Contract Review
→ Compatibility Assessment
→ Security/Data Review
→ ADR if Significant
→ Implementation
→ Contract Tests
→ Documentation
→ Versioning
→ Release
```

---

# 163. Breaking Change Workflow

```text
Identify Need
→ Create ADR
→ Create New Contract Version
→ Publish Migration Guide
→ Support Transition
→ Deprecate Old Version
→ Retire After Policy Window
```

---

# 164. SDK Release Workflow

```text
Prepare
→ Run Tests
→ Compatibility Matrix
→ Generate Changelog
→ Build Package
→ Sign Artifact
→ Publish
→ Notify Module Owners
```

---

# 165. SDK Security Review Triggers

Required when changing:

- identity contract;
- authorization contract;
- tenant context;
- secrets;
- file access;
- privileged capabilities;
- audit behavior;
- external plugin model.

---

# 166. SDK Data Review Triggers

Required when changing:

- cross-module DTOs;
- event schemas;
- shared identifiers;
- retention-related contracts;
- export/import contracts.

---

# 167. SDK Operational Review Triggers

Required when changing:

- health checks;
- jobs;
- schedulers;
- observability;
- deployment hooks;
- module activation behavior.

---

# 168. SDK Anti-Patterns

Avoid:

- service locator access;
- raw container access from modules;
- generic `getService(string $name)`;
- raw PDO in SDK;
- untyped arrays;
- kernel implementation classes in SDK signatures;
- giant base module class;
- global mutable registry;
- hidden module discovery;
- breaking event payload changes without versioning.

---

# 169. Thin SDK Rule

SDK should not become a second kernel.

It defines contracts and lightweight value types only.

---

# 170. Shared Library vs SDK

Shared library:

- reusable implementation utility.

SDK:

- governed integration contract.

Do not confuse both.

---

# 171. Module SDK vs Public API

Module SDK is in-process contract.

Public API is network contract.

They may share concepts but should not be tightly coupled.

---

# 172. Future Microservice Migration

SDK contracts should be designed so selected capabilities can later map to remote APIs or messages.

---

# 173. Local vs Remote Adapter

A capability may have:

```text
InProcess Adapter
Remote API Adapter
Message Adapter
```

without changing module-facing contract where feasible.

---

# 174. Serialization Boundary

Contracts that may become remote should use serializable DTOs and stable identifiers.

---

# 175. Idempotency

Commands crossing asynchronous/remote boundaries should support idempotency keys.

---

# 176. Correlation

Cross-module operations should preserve correlation and causation IDs.

---

# 177. Module Packaging

A module package should include:

```text
Source/Artifact
Manifest
Migrations
Permissions
Configuration Definitions
Events
Documentation
Tests
Checksums
```

---

# 178. Module Installation

Installation process:

```text
Upload/Resolve Package
→ Validate Signature
→ Validate Manifest
→ Check SDK Version
→ Check Dependencies
→ Register
→ Run Migrations
→ Seed Permissions
→ Run Certification
→ Activate
```

---

# 179. Module Upgrade

Upgrade should:

- compare versions;
- validate compatibility;
- run migrations;
- preserve config;
- support rollback/forward strategy;
- verify health.

---

# 180. Module Uninstall

Uninstall must not blindly delete business data.

It requires:

- retention decision;
- dependency analysis;
- deactivation;
- data export/archive;
- permission cleanup;
- route/menu cleanup.

---

# 181. Module Readiness Gate

Before production, module must have:

- valid manifest;
- owner;
- contracts;
- permissions;
- configuration schema;
- migrations;
- tests;
- health check;
- observability;
- UAT;
- rollback plan.

---

# 182. Reference Module Readiness Checklist

- [ ] Module ID unique.
- [ ] Manifest valid.
- [ ] SDK version compatible.
- [ ] Dependencies valid.
- [ ] No circular dependency.
- [ ] Required capabilities available.
- [ ] Permissions registered.
- [ ] Configuration registered.
- [ ] Migrations validated.
- [ ] Health check passes.
- [ ] Contract tests pass.
- [ ] Tenant isolation tests pass.
- [ ] Documentation complete.
- [ ] Owner assigned.

---

# 183. UAT — SDK Boundary

- [ ] Modules depend only on SDK/public contracts.
- [ ] Kernel internals are not imported by modules.
- [ ] Raw PDO is not exposed.
- [ ] Service container is not exposed.
- [ ] Module-to-module private access is blocked.
- [ ] Architecture tests detect violations.

---

# 184. UAT — Module Registration

- [ ] Manifest is required.
- [ ] Module ID is unique.
- [ ] Version is valid.
- [ ] SDK constraint is checked.
- [ ] Dependencies are resolved.
- [ ] Circular dependencies are blocked.
- [ ] Registration succeeds.
- [ ] Boot succeeds.
- [ ] Health is checked.
- [ ] Failed module remains inactive.

---

# 185. UAT — Capabilities

- [ ] Capability registry works.
- [ ] Required capability declarations work.
- [ ] Missing capability fails predictably.
- [ ] Version constraints work.
- [ ] Privileged capability requires authorization.
- [ ] Tenant context is required where applicable.
- [ ] Capability usage is observable.
- [ ] Least privilege is enforced.

---

# 186. UAT — Commands, Queries & Events

- [ ] Commands are immutable.
- [ ] Queries are tenant-aware.
- [ ] Results are typed.
- [ ] Events use past tense.
- [ ] Event envelopes contain IDs and timestamps.
- [ ] Event versions work.
- [ ] Duplicate event delivery is tolerated.
- [ ] Sensitive payloads are minimized.

---

# 187. UAT — Extensions

- [ ] Extension points are explicit.
- [ ] Registration is deterministic.
- [ ] Ordering is deterministic.
- [ ] Conflicts are detected.
- [ ] Extension failure is isolated.
- [ ] Third-party restrictions are enforced.
- [ ] Extension versions are validated.

---

# 188. UAT — Compatibility & Deprecation

- [ ] Semantic versioning is enforced.
- [ ] Compatibility matrix exists.
- [ ] Incompatible activation is blocked.
- [ ] Stable contract breaking change requires new major version.
- [ ] Deprecation warning works.
- [ ] Replacement path is documented.
- [ ] Retirement date is tracked.
- [ ] Migration guide exists.

---

# 189. UAT — Security & Tenancy

- [ ] Authorization contract works.
- [ ] Trusted tenant context is required.
- [ ] Raw request tenant IDs are not trusted.
- [ ] Secret values are not exposed.
- [ ] Audit hooks work.
- [ ] Privileged capabilities are controlled.
- [ ] Cross-tenant tests pass.
- [ ] Plugin access is restricted.

---

# 190. UAT — Testing & Certification

- [ ] Contract tests pass.
- [ ] Consumer tests pass.
- [ ] Compatibility tests pass.
- [ ] Bootstrap tests pass.
- [ ] Security tests pass.
- [ ] Tenant isolation tests pass.
- [ ] Certification status is recorded.
- [ ] Failed certification blocks production.

---

# 191. UAT — Governance & Documentation

- [ ] SDK owner assigned.
- [ ] Contract owners assigned.
- [ ] Public contracts classified.
- [ ] Significant changes use ADR.
- [ ] Changelog updated.
- [ ] Version updated.
- [ ] Documentation complete.
- [ ] Quality gates block invalid releases.
- [ ] Metrics and dashboard are defined.

---

# 192. Definition of Done — SSOT-SDK-01

SSOT-SDK-01 dianggap selesai bila:

- [ ] vision/objectives/principles tersedia;
- [ ] scope/non-scope tersedia;
- [ ] high-level architecture tersedia;
- [ ] dependency direction tersedia;
- [ ] package/namespace structure tersedia;
- [ ] surface classification tersedia;
- [ ] contract/DTO/value object rules tersedia;
- [ ] error contracts tersedia;
- [ ] module architecture tersedia;
- [ ] manifest/status/provider tersedia;
- [ ] registration/boot lifecycle tersedia;
- [ ] dependency validation tersedia;
- [ ] capability model tersedia;
- [ ] identity/authorization/tenant/audit capability tersedia;
- [ ] workflow/notification/files/config/observability/jobs/menu capability tersedia;
- [ ] command/query/event architecture tersedia;
- [ ] repository/transaction guidance tersedia;
- [ ] extension/plugin model tersedia;
- [ ] activation/deactivation/retirement tersedia;
- [ ] tenant module enablement tersedia;
- [ ] SDK versioning/compatibility tersedia;
- [ ] backward compatibility/deprecation tersedia;
- [ ] security architecture tersedia;
- [ ] observability/health tersedia;
- [ ] testing/certification tersedia;
- [ ] governance/decision rights tersedia;
- [ ] documentation tersedia;
- [ ] reference module structure tersedia;
- [ ] API/database direction tersedia;
- [ ] event/error codes tersedia;
- [ ] metrics/KPI/dashboard tersedia;
- [ ] installation/upgrade/uninstall tersedia;
- [ ] readiness checklist tersedia;
- [ ] UAT tersedia.

---

# 193. Implementation Roadmap

## Phase 1 — SDK Foundation

- create SDK package;
- define namespaces;
- define manifest;
- define module provider;
- define module registry;
- define base value objects.

## Phase 2 — Core Capabilities

- identity;
- authorization;
- tenancy;
- audit;
- configuration;
- observability.

## Phase 3 — Module Integration

- commands/queries;
- events;
- workflow;
- notification;
- menu;
- files;
- jobs.

## Phase 4 — Compatibility & Certification

- semantic versioning;
- compatibility checker;
- contract tests;
- module certification suite;
- deprecation registry.

## Phase 5 — Extension & Scale

- extension points;
- plugin restrictions;
- package distribution;
- remote adapters;
- microservice extraction readiness.

---

# 194. Initial SDK Backlog

Recommended implementation sequence:

```text
SDK-01 Module Manifest
SDK-02 Module Provider
SDK-03 Module Registry
SDK-04 Tenant Context Contract
SDK-05 Authorization Contract
SDK-06 Audit Contract
SDK-07 Configuration Contract
SDK-08 Event Envelope
SDK-09 Command/Query Bus Contracts
SDK-10 Module Health Contract
SDK-11 Compatibility Checker
SDK-12 Module Certification Test Kit
```

---

# 195. Approval Gate

Dokumen dapat menjadi Approved setelah:

- Platform Governance review;
- Architecture Review Board review;
- SDK ownership review;
- Security Governance review;
- Data Architecture review;
- Module Owner review;
- QA/Compatibility review;
- Release Engineering review;
- microservice-readiness review;
- module certification review.

---

# 196. Closing Statement

Platform SDK harus memastikan setiap module:

- menggunakan contract stabil;
- tidak bergantung pada kernel internals;
- memiliki manifest;
- memiliki owner;
- mendeklarasikan capabilities;
- mendeklarasikan dependencies;
- dapat diuji;
- dapat divalidasi;
- dapat diaktifkan dengan aman;
- dapat di-upgrade;
- dapat diaudit;
- siap berkembang.

SDK tidak boleh menjadi kumpulan helper yang tidak terkendali.

SDK harus menjadi boundary resmi yang menjaga modularity, compatibility, security, dan evolusi Platform Kernel.
