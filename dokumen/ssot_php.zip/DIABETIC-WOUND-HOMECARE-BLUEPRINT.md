# Diabetic Wound Homecare Blueprint

Status: Sprint 8.0 lifecycle core implemented; remaining sections are development backlog
Owner domain: Homecare, Woundcare
Primary operation: Homecare Visit
Clinical domain: Woundcare Episode
Reference UI: `http://localhost/wc/`
Last compiled: 2026-07-09

## 1. Purpose

Blueprint ini menggabungkan kebutuhan bisnis, klinis, HR, inventory, finance, payroll, quality, audit, dan UI focused mode untuk aplikasi Diabetic Wound Homecare.

Prinsip utama:

- `Homecare Visit` adalah unit operasi lapangan: jadwal, assignment, kunjungan, verifikasi, tindakan, consumables, tanda tangan, dan outcome visit.
- `Woundcare Episode` adalah unit klinis: luka, assessment serial, care plan, progress, escalation, referral, finalization, dan amendment.
- Backend modul lain tidak dihapus. UI focused mode hanya menampilkan modul yang relevan untuk diabetic wound homecare.
- Semua proses harus scope-aware, RBAC-aware, audit-aware, dan mendukung evidence klinis.

## 2. Source Alignment

Blueprint ini disusun dari:

- SSOT platform: Scope, IAM, RBAC, Audit, Workflow, Data, File, Records, Testing, MDM.
- Sprint/application progress: Patient, Encounter, Staff, Credentialing, Homecare, Woundcare, Orders, Medication, Audit.
- Prototype `http://localhost/wc/` sebagai acuan layar Woundcare Episode.
- Keputusan focused mode UI: Diabetic Wound Homecare dengan portal per role.

## 3. Product Scope

### 3.1 In Scope

- Portal pasien untuk request, jadwal, episode summary, edukasi, dan komunikasi dasar.
- Portal perawat untuk visit lapangan dan dokumentasi klinis.
- Portal koordinator untuk intake, screening, scheduling, assignment, dan monitoring.
- Portal supervisor/doctor untuk review, escalation, referral, finalization, dan amendment.
- Woundcare episode lifecycle untuk luka diabetes.
- Homecare visit lifecycle sebagai operasi lapangan.
- Inventory usage untuk woundcare consumables.
- Finance billing readiness dari completed/verified visit.
- Payroll claim readiness dari verified nurse visit.
- Quality indicator dan patient safety event.
- Audit dan records evidence pack.

### 3.2 Out of Scope for First Build

- Full external insurance claim integration.
- Real-time logistics routing optimization.
- AI clinical recommendation as autonomous decision maker.
- Regulatory e-prescribing beyond existing medication module.
- Warehouse multi-branch optimization beyond minimal stock movement.

## 4. Role Model

| Role | Primary Portal | Main Responsibility |
| --- | --- | --- |
| Patient | Portal Pasien | Submit request, view schedule, view care summary, consent, education |
| Family/Caregiver | Portal Pasien | Contact, adherence support, signature, communication |
| Care Coordinator | Portal Koordinator | Triage, scheduling, assignment, service monitoring |
| Woundcare Nurse | Portal Perawat | Field visit, assessment, procedure, consumables, outcome |
| Doctor/Supervisor | Portal Supervisor | Review high-risk case, escalation, referral, closure, amendment |
| Inventory Staff | Backoffice/hidden module | Stock, batch, reservation, issue, return |
| Finance Staff | Backoffice/hidden module | Billing, invoice, payment, AR |
| Payroll Staff | Backoffice/hidden module | Nurse claim verification and payment marking |
| Quality Officer | Backoffice/hidden module | Indicator review, incident, audit evidence |
| Platform Admin | Admin | RBAC, scope, module state, reference data |

## 5. Core Domain Boundary

### 5.1 Homecare Visit

Homecare Visit owns:

- service request/admission linkage;
- visit schedule;
- nurse/doctor assignment;
- location and EVV readiness;
- visit status;
- vital signs;
- patient verification;
- procedure documentation;
- consumables usage;
- patient response;
- patient/family signature;
- visit outcome;
- billing/payroll readiness trigger.

### 5.2 Woundcare Episode

Woundcare Episode owns:

- wound episode identity;
- wound site/location;
- diabetic wound classification;
- risk level and risk reasons;
- initial assessment;
- serial wound assessments;
- wound photos;
- care plan;
- progress notes;
- clinical escalation;
- referral;
- finalization;
- amendment/version history.

### 5.3 Patient and DM Profile

Patient/DM profile owns:

- patient identity;
- contact and caregiver;
- address/service location;
- diabetes type;
- diabetes duration;
- insulin usage;
- HbA1c;
- fasting/random blood sugar;
- smoking status;
- payer/insurance profile;
- consent status.

## 6. End-to-End Lifecycle

Canonical lifecycle:

```text
intake
-> clinical_screening
-> patient_registration
-> episode_opened
-> initial_assessment
-> wound_assessment
-> care_plan
-> visit_scheduled
-> visit_assigned
-> visit_in_progress
-> procedure_documented
-> visit_outcome
-> clinical_review
-> billing_ready
-> payroll_ready
-> quality_review
-> episode_closed
```

Exception lifecycle:

```text
cancelled
no_show
rejected
escalated
referred_out
amendment_requested
amended
reopened
```

## 7. Reference UI Flow from `http://localhost/wc/`

Prototype `/wc/` has nine major steps. These become the canonical product workflow.

### 7.1 Intake Request

Captured data:

- patient name, birth date, gender;
- contact person, phone, relationship;
- service address, city, district, postal code;
- wound type, wound duration, pain level, chief complaint;
- referral source, referrer name;
- initial wound photo;
- data usage consent.

System output:

- intake request record;
- initial lead status;
- initial risk hints;
- attachment evidence.

### 7.2 Clinical Screening

Captured data:

- diabetes type;
- wound duration;
- pain score;
- blood sugar;
- infection signs;
- eligibility notes;
- nurse reviewer;
- care coordinator.

Actions:

- convert to patient;
- schedule visit;
- reject lead;
- mark urgency/risk.

System output:

- screening decision;
- risk level;
- reviewer assignment;
- audit trail.

### 7.3 Patient Registration

Captured data:

- MRN, NIK, full name, gender, birth date;
- phone, email, address;
- diabetes type, duration, insulin usage;
- HbA1c, fasting blood sugar, random blood sugar;
- smoking status;
- payer/insurance;
- emergency contact;
- consent checklist.

System output:

- patient master;
- DM profile;
- payer profile;
- consent records.

### 7.4 Episode Dashboard

Displayed data:

- visit count;
- healing progress;
- days open;
- risk level;
- cost summary;
- visit/procedure timeline;
- classification: Wagner, PEDIS, SINBAD;
- alerts such as infection, HbA1c high, doctor review due.

Actions:

- new visit;
- review care plan;
- doctor review;
- close episode.

### 7.5 Initial Assessment

Captured data:

- BP, heart rate, temperature, respiratory rate, SpO2;
- random blood sugar, HbA1c;
- insulin therapy and medication;
- neuropathy checks;
- vascular checks;
- risk flags.

System output:

- initial clinical baseline;
- risk score update;
- doctor/supervisor review trigger when high risk.

### 7.6 Wound Assessment

Captured data:

- wound location;
- etiology;
- duration;
- recurrent wound flag;
- length, width, depth, area, volume;
- pain score;
- tissue composition;
- exudate amount, color, consistency;
- infection signs;
- periwound condition;
- photos: before/progress/after or assessment phase;
- clinical notes.

System output:

- wound assessment version;
- wound photo relation rows;
- updated healing trend;
- escalation trigger if red flags exist.

### 7.7 Treatment Plan

Captured data:

- goals: reduce wound size, control infection, improve granulation, reduce pain, prevent amputation;
- debridement plan;
- primary dressing;
- secondary dressing;
- dressing frequency;
- infection management;
- offloading;
- diabetes management;
- patient education;
- next visit date/type;
- assigned nurse;
- plan notes.

System output:

- active care plan;
- planned consumables;
- next visit request;
- doctor review queue when required.

### 7.8 Procedure Documentation

Captured data:

- patient identity verification;
- consent/confirmation;
- before photos;
- hand hygiene and preparation checklist;
- cleansing solution, volume, technique;
- debridement performed, type, tissue removed;
- dressing application;
- after photos;
- consumables item and quantity;
- pain before/after;
- tolerance;
- patient/family signature.

System output:

- completed procedure document;
- inventory usage;
- stock movement trigger;
- visit completion candidate;
- billing/payroll readiness candidate.

### 7.9 Outcome and Follow-up

Captured data:

- wound size trend;
- tissue trend;
- exudate trend;
- infection control status;
- goal achievement;
- medication/offloading/diet adherence;
- escalation decision;
- next visit date/type/nurse;
- episode status;
- outcome notes.

Actions:

- continue current plan;
- revise care plan;
- doctor review;
- referral;
- schedule next visit;
- close episode.

System output:

- visit outcome;
- next visit;
- episode status transition;
- quality indicator update.

## 8. Status Model

### 8.1 Intake Status

```text
new
screening
eligible
converted
rejected
cancelled
```

### 8.2 Episode Status

```text
open
active
healing
clinical_review
escalated
referred_out
resolved
closed
amendment_requested
amended
reopened
cancelled
```

### 8.3 Visit Status

```text
requested
scheduled
assigned
confirmed
in_progress
documented
completed
verified
billing_ready
payroll_ready
cancelled
no_show
rescheduled
```

### 8.4 Care Plan Status

```text
draft
pending_review
active
revised
superseded
discontinued
closed
```

### 8.5 Assessment Status

```text
draft
final
amendment_requested
amended
voided
```

## 9. Guard Rules

Minimum transition guards:

- Intake cannot convert to patient without consent and minimum identity/contact data.
- Clinical screening cannot mark eligible without risk level and reviewer.
- Episode cannot open without patient, DM profile, and wound complaint.
- Initial assessment cannot finalize without vitals and DM control fields.
- Wound assessment cannot finalize without measurement, tissue/exudate/infection fields, and required photos.
- Care plan cannot activate if high-risk case requires doctor review and review is missing.
- Visit cannot start without assigned nurse and scheduled time.
- Procedure cannot complete without patient verification, required photos, consumables usage, and patient response.
- Billing cannot be ready until visit is completed or verified according to policy.
- Payroll cannot be ready until visit is verified and no unresolved amendment exists.
- Episode cannot close while active escalation/referral/amendment is unresolved.

## 10. Data Model Blueprint

### 10.1 Existing/Core Tables to Reuse

- `patients`
- `patient_profiles`
- `staff`
- `nurse_profiles`
- `homecare_admissions`
- `homecare_visits`
- `homecare_visit_vital_signs`
- `woundcare_episodes`
- `wound_assessments`
- `wound_assessment_photos`
- `woundcare_care_plans`
- `woundcare_progress_notes`
- `woundcare_escalations`
- `woundcare_referrals`
- `woundcare_finalizations`
- `woundcare_amendments`
- `clinical_files`
- `audit_logs`

### 10.2 New Tables

#### Clinical Intake and Screening

- `woundcare_intake_requests`
- `woundcare_screenings`
- `woundcare_screening_risk_factors`
- `patient_dm_profiles`

#### Episode Lifecycle

- `wound_episode_status_logs`
- `woundcare_episode_classifications`
- `woundcare_episode_reviews`
- `woundcare_episode_quality_flags`

#### Visit Procedure

- `homecare_visit_verifications`
- `homecare_visit_procedure_docs`
- `homecare_visit_procedure_steps`
- `homecare_visit_signatures`
- `homecare_visit_outcomes`
- `homecare_visit_status_logs`

#### Inventory

- `inventory_items`
- `inventory_batches`
- `inventory_locations`
- `inventory_reservations`
- `inventory_movements`
- `homecare_visit_consumables`
- `homecare_visit_consumable_returns`

#### Finance

- `finance_tariffs`
- `finance_price_lists`
- `billing_drafts`
- `billing_draft_lines`
- `invoices`
- `invoice_lines`
- `payments`

#### Payroll

- `payroll_rules`
- `payroll_claims`
- `payroll_claim_lines`
- `payroll_approvals`

#### Quality and Safety

- `quality_indicators`
- `quality_indicator_results`
- `quality_reviews`
- `quality_review_actions`
- `patient_safety_events`

## 11. API Blueprint

### 11.1 Intake and Screening

- `GET /api/v1/woundcare/intakes`
- `POST /api/v1/woundcare/intakes`
- `GET /api/v1/woundcare/intakes/detail?id=...`
- `POST /api/v1/woundcare/intakes/status`
- `POST /api/v1/woundcare/screenings`
- `POST /api/v1/woundcare/screenings/convert-to-patient`
- `POST /api/v1/woundcare/screenings/reject`

### 11.2 Episode

- `GET /api/v1/woundcare/episodes`
- `POST /api/v1/woundcare/episodes`
- `GET /api/v1/woundcare/episodes/detail?id=...`
- `POST /api/v1/woundcare/episodes/status`
- `POST /api/v1/woundcare/episodes/classification`
- `POST /api/v1/woundcare/episodes/review`
- `POST /api/v1/woundcare/episodes/close`
- `POST /api/v1/woundcare/episodes/reopen`

### 11.3 Assessment

- `POST /api/v1/woundcare/initial-assessments`
- `POST /api/v1/woundcare/assessments`
- `POST /api/v1/woundcare/assessments/photos`
- `POST /api/v1/woundcare/assessments/finalize`
- `POST /api/v1/woundcare/assessments/amend`

### 11.4 Care Plan

- `GET /api/v1/woundcare/care-plans`
- `POST /api/v1/woundcare/care-plans`
- `POST /api/v1/woundcare/care-plans/review`
- `POST /api/v1/woundcare/care-plans/activate`
- `POST /api/v1/woundcare/care-plans/revise`

### 11.5 Homecare Visit

- `GET /api/v1/homecare/visits`
- `POST /api/v1/homecare/visits`
- `GET /api/v1/homecare/visits/detail?id=...`
- `POST /api/v1/homecare/visits/assign`
- `POST /api/v1/homecare/visits/status`
- `POST /api/v1/homecare/visits/verify-patient`
- `POST /api/v1/homecare/visits/vitals`
- `POST /api/v1/homecare/visits/procedure`
- `POST /api/v1/homecare/visits/outcome`
- `POST /api/v1/homecare/visits/complete`
- `POST /api/v1/homecare/visits/verify`

### 11.6 Inventory, Finance, Payroll, Quality

- `POST /api/v1/inventory/reservations`
- `POST /api/v1/inventory/movements`
- `POST /api/v1/billing/drafts/from-visit`
- `POST /api/v1/payroll/claims/from-visit`
- `POST /api/v1/quality/reviews/from-episode`
- `POST /api/v1/patient-safety/events`

## 12. UI Blueprint

### 12.1 Focused Mode Navigation

Visible module navigation:

- Dashboard
- Homecare
- Woundcare
- Portal Pasien
- Portal Perawat
- Portal Koordinator
- Portal Supervisor

Hidden but available backend modules:

- Patient
- Encounter
- Staff
- Credentialing
- Clinical Privilege
- Orders
- Medication
- Audit
- Inventory
- Finance
- Payroll
- Quality
- Settings

### 12.2 Portal Pasien

Primary screens:

- Request perawatan luka.
- Jadwal kunjungan.
- Episode summary.
- Foto/edukasi perawatan.
- Consent and signature.
- Message/notification.

### 12.3 Portal Perawat

Primary screens:

- Assigned visits.
- Visit detail.
- Patient verification.
- Vitals.
- Initial/wound assessment.
- Procedure documentation.
- Consumables usage.
- Before/after photos.
- Outcome and next visit.

### 12.4 Portal Koordinator

Primary screens:

- Intake queue.
- Clinical screening queue.
- Patient registration handoff.
- Schedule and assignment.
- Visit monitoring board.
- Exception queue: no-show, reschedule, escalation.

### 12.5 Portal Supervisor

Primary screens:

- High-risk case queue.
- Doctor review.
- Care plan review.
- Escalation/referral.
- Finalization review.
- Amendment review.
- Quality and audit evidence.

## 13. Inventory Blueprint

Inventory responsibilities:

- item master for woundcare consumables;
- batch/lot/expiry tracking;
- stock location;
- visit kit reservation;
- issue to nurse/visit;
- usage confirmation;
- return unused items;
- stock deduction on verified usage;
- COGS calculation basis.

Minimum consumable fields:

- item id;
- batch id;
- quantity planned;
- quantity used;
- quantity returned;
- unit;
- lot number;
- expiry date;
- unit cost;
- usage phase;
- procedure document id.

## 14. Finance Blueprint

Finance responsibilities:

- price list;
- visit fee;
- procedure fee;
- material fee;
- transport fee;
- package/bundle;
- discount/adjustment;
- invoice draft;
- invoice issue;
- payment allocation;
- AR status.

Billing trigger:

```text
homecare_visit.status = verified
AND procedure_doc.status = final
AND no unresolved amendment
AND billing policy satisfied
```

Billing status:

```text
not_billable
billing_ready
draft_created
invoice_issued
partially_paid
paid
voided
```

## 15. Payroll Blueprint

Payroll responsibilities:

- nurse visit claim;
- procedure allowance;
- transport allowance;
- overtime;
- supervisor approval;
- payroll batch;
- paid marker.

Payroll trigger:

```text
homecare_visit.status = verified
AND assigned_nurse_id exists
AND no unresolved clinical amendment
AND payroll rule exists
```

Payroll status:

```text
not_eligible
claim_ready
claim_created
approved
rejected
paid
voided
```

## 16. Quality and Patient Safety Blueprint

Quality indicators:

- assessment completeness;
- required photo completeness;
- care plan review timeliness;
- wound size trend;
- infection escalation timeliness;
- missed visit rate;
- no-show rate;
- amendment rate;
- referral rate;
- episode closure reason;
- patient adherence trend.

Patient safety events:

- worsening infection;
- severe pain;
- uncontrolled blood glucose;
- suspected sepsis;
- fall/injury during visit;
- medication safety issue;
- procedure adverse event;
- delayed referral.

Quality review triggers:

- high/critical risk;
- wound worsened;
- infection uncontrolled;
- repeated no-show;
- visit completed without required evidence;
- amendment after billing/payroll trigger;
- delayed doctor review.

## 17. Audit and Records Blueprint

Audit must capture:

- actor;
- role;
- tenant/organization/clinic scope;
- resource type/id;
- old status/new status;
- transition reason;
- patient-facing impact;
- clinical evidence reference;
- request id/correlation id;
- timestamp.

Critical audit events:

- intake submitted;
- screening decision changed;
- patient converted;
- episode opened/closed/reopened;
- assessment finalized/amended;
- care plan activated/revised;
- visit assigned/status changed;
- procedure finalized;
- consumables usage posted;
- billing draft generated;
- payroll claim generated;
- quality review created/closed;
- patient safety event created;
- file uploaded/downloaded/exported.

Records requirements:

- finalized clinical records are immutable;
- amendments preserve history;
- photo evidence uses relation table and secure file service;
- audit does not store raw sensitive payload beyond allowed metadata;
- evidence pack can be generated per episode.

## 18. RBAC and Permissions

Minimum permission groups:

- `woundcare.intake.read`
- `woundcare.intake.create`
- `woundcare.screening.review`
- `woundcare.episode.read`
- `woundcare.episode.create`
- `woundcare.episode.status`
- `woundcare.assessment.create`
- `woundcare.assessment.finalize`
- `woundcare.assessment.amend`
- `woundcare.care_plan.manage`
- `woundcare.review.doctor`
- `woundcare.escalation.manage`
- `homecare.visit.read`
- `homecare.visit.assign`
- `homecare.visit.verify_patient`
- `homecare.visit.procedure`
- `homecare.visit.complete`
- `homecare.visit.verify`
- `inventory.visit_consumable.manage`
- `finance.billing.manage`
- `payroll.claim.manage`
- `quality.review.manage`
- `audit.woundcare.read`

## 19. Event Blueprint

Domain events:

- `woundcare.intake.submitted`
- `woundcare.screening.completed`
- `woundcare.patient.converted`
- `woundcare.episode.opened`
- `woundcare.initial_assessment.finalized`
- `woundcare.assessment.finalized`
- `woundcare.care_plan.activated`
- `homecare.visit.scheduled`
- `homecare.visit.assigned`
- `homecare.visit.started`
- `homecare.visit.procedure_finalized`
- `homecare.visit.completed`
- `homecare.visit.verified`
- `inventory.consumable.used`
- `finance.billing.ready`
- `payroll.claim.ready`
- `quality.review.required`
- `woundcare.episode.closed`

## 20. Reporting Blueprint

Operational reports:

- active episodes;
- visits today;
- visits overdue;
- nurse workload;
- high-risk cases;
- pending doctor review;
- pending billing;
- pending payroll;
- low stock for woundcare items.

Clinical reports:

- wound healing trend;
- episode duration;
- infection rate;
- escalation/referral rate;
- closure reason;
- adherence trend.

Finance/payroll reports:

- revenue per episode;
- material cost per visit;
- invoice aging;
- nurse claims by period;
- visit margin.

Quality reports:

- evidence completeness;
- delayed review;
- adverse event;
- amendment rate;
- quality gate pass/fail.

## 21. Development Sprint Plan

### Sprint 8.0 - Woundcare Lifecycle Core

Deliver:

- lifecycle state machine;
- episode status log;
- transition guards;
- event/audit emission;
- focused workflow dashboard.

Implementation status: Implemented 2026-07-09 for backend lifecycle core.

Acceptance:

- invalid status rejected;
- all status changes audited;
- episode cannot close with unresolved escalation/referral/amendment.

### Sprint 8.1 - Intake and Clinical Screening

Deliver:

- intake request;
- clinical screening;
- risk level;
- convert to patient;
- reject lead.

Implementation status: Implemented 2026-07-09 for backend intake request, clinical screening, risk allowlist, conversion to patient master/DM profile, reject flow, RBAC, and audit trail.

Implemented APIs:

- `GET /api/v1/woundcare/intakes`;
- `POST /api/v1/woundcare/intakes`;
- `GET /api/v1/woundcare/intakes/detail`;
- `POST /api/v1/woundcare/intakes/status`;
- `POST /api/v1/woundcare/screenings`;
- `POST /api/v1/woundcare/screenings/convert-to-patient`;
- `POST /api/v1/woundcare/screenings/reject`.

Acceptance:

- intake requires consent and contact;
- screening requires reviewer and risk;
- convert creates/links patient and DM profile.

### Sprint 8.2 - Patient DM Profile and Initial Assessment

Deliver:

- DM profile fields;
- initial assessment;
- vitals;
- neuropathy/vascular checks;
- risk flags.

Acceptance:

- high-risk flags trigger review;
- assessment supports draft/final;
- finalized record cannot be overwritten.

### Sprint 8.3 - Wound Assessment Upgrade

Deliver:

- measurement;
- tissue/exudate/infection/periwound;
- multi-photo evidence;
- classification fields: Wagner, PEDIS, SINBAD.

Acceptance:

- assessment finalization requires minimum clinical evidence;
- photos are stored through secure file relation;
- trend is calculated from serial assessments.

### Sprint 8.4 - Treatment Plan and Review

Deliver:

- goals;
- debridement/dressing/offloading/education;
- follow-up scheduling;
- doctor review for high-risk care plan.

Acceptance:

- high-risk plan cannot activate without review;
- revised plan supersedes previous plan;
- next visit can be generated from plan.

### Sprint 8.5 - Procedure Documentation

Deliver:

- patient verification;
- before/after photos;
- preparation checklist;
- cleansing/debridement/dressing;
- patient response;
- signature;
- complete visit.

Acceptance:

- visit cannot complete without required evidence;
- procedure document supports draft/final;
- completion emits audit and event.

### Sprint 8.6 - Outcome and Follow-up

Deliver:

- healing trend;
- goal achievement;
- adherence;
- escalation decision;
- next visit;
- episode status update.

Acceptance:

- worsened outcome triggers review/escalation;
- resolved/closed status requires clinical summary;
- next visit generation works from outcome.

### Sprint 8.7 - Inventory Bridge

Deliver:

- inventory item/batch;
- reservation;
- usage;
- return;
- stock movement;
- unit cost.

Acceptance:

- used consumables deduct stock;
- expired/insufficient stock blocked or flagged;
- usage links to procedure document and visit.

### Sprint 8.8 - Finance Billing

Deliver:

- tariff;
- billing draft from verified visit;
- invoice draft lines;
- payment status marker.

Acceptance:

- billing not generated for incomplete/unverified visit;
- material fee uses consumables;
- billing draft is auditable.

### Sprint 8.9 - Payroll Claim

Deliver:

- payroll rule;
- nurse visit claim;
- approval;
- paid marker.

Acceptance:

- claim not generated for unverified visit;
- unresolved amendment blocks claim;
- claim links to nurse assignment and visit.

### Sprint 8.10 - Quality and Patient Safety

Deliver:

- quality indicator engine;
- quality review queue;
- patient safety events;
- corrective action.

Acceptance:

- high-risk and evidence gaps create quality review;
- patient safety event is audited;
- quality review can close with action.

### Sprint 8.11 - Evidence Pack and Reporting

Deliver:

- episode evidence timeline;
- audit pack;
- clinical summary;
- operational/clinical/finance/quality reports.

Acceptance:

- episode pack includes assessment, photos, plan, procedure, outcome, audit;
- report filters by tenant/organization/clinic;
- no direct raw sensitive payload leakage in audit.

## 22. UAT Scenarios

1. Patient submits diabetic wound request with photo and consent.
2. Coordinator screens request and marks high risk.
3. Patient registration creates DM profile.
4. Episode opens with wound classification.
5. Nurse completes initial assessment.
6. Nurse completes wound assessment with multiple photos.
7. High-risk care plan requires doctor review.
8. Coordinator schedules homecare visit and assigns eligible nurse.
9. Nurse verifies patient, records vitals, procedure, consumables, photos, signature.
10. Visit outcome schedules next visit.
11. Worsened infection triggers escalation/referral.
12. Verified visit generates billing readiness and payroll readiness.
13. Consumables deduct inventory stock with lot/expiry.
14. Quality review is created for missing evidence or high risk.
15. Episode is closed with evidence pack and immutable audit.

## 23. Implementation Principles

- Do not encode lifecycle as scattered `if` statements; use a state machine or centralized transition allowlist.
- Do not treat UI hiding as authorization; backend RBAC remains mandatory.
- Do not overwrite finalized clinical records; use amendment.
- Do not use one photo column for clinical photo workflow; use relation table.
- Do not generate billing/payroll before visit verification and evidence completion.
- Do not store sensitive raw clinical payload in audit metadata.
- Do not let Inventory, Finance, Payroll, or Quality define their own unrelated visit status.

## 24. Immediate Next Build Recommendation

Start with Sprint 8.0 - Woundcare Lifecycle Core.

Reason:

- all downstream domains depend on one shared lifecycle;
- inventory, finance, payroll, quality, and audit need stable transition events;
- UI focused mode already assumes Homecare Visit and Woundcare as the main domain.

Minimal first deliverable:

- define episode and visit transition maps;
- add status log tables if missing;
- add transition service;
- add API `/status` endpoints with allowlist;
- emit audit events for every transition;
- add tests for allowed, forbidden, invalid, and permission-gated transitions.
