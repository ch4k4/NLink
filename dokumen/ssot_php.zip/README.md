
# Enterprise Platform Kernel
## Single Source of Truth (SSOT)

**Version:** 1.0  
**Status:** Living Architecture Repository

---

# Selamat Datang

Repository ini adalah **Single Source of Truth (SSOT)** untuk seluruh pengembangan Enterprise Platform Kernel.

Seluruh keputusan arsitektur, standar pengembangan, keamanan, workflow, database, API, event, integrasi, dan modul bisnis harus mengacu pada dokumen di repository ini sebelum implementasi source code dilakukan.

Prinsip utama:

> **Dokumentasi mendahului implementasi.**

---

# Visi Platform

Membangun satu **Platform Kernel** yang dapat digunakan kembali oleh berbagai domain bisnis.

Contoh domain:

- Healthcare (SIMRS, Klinik, Homecare, Woundcare)
- CRM
- ERP
- Inventory
- Retail
- Finance
- HRIS
- Manufacturing
- Logistics
- Education
- Government

Semua domain tersebut menggunakan kernel yang sama sehingga tidak perlu membangun ulang fondasi aplikasi.

---

# Filosofi Arsitektur

- Build Once, Reuse Everywhere
- Modular Monolith First
- Microservice Ready
- API First
- Event Driven
- Security by Default
- Audit by Default
- Scope by Default
- RBAC by Default
- Configuration over Hardcoding
- Clean Architecture
- SOLID
- Domain Driven Design (bertahap)

---

# Arsitektur Tingkat Tinggi

```text
Business Modules
        │
Platform SDK
        │
Platform Kernel
        │
Infrastructure
```

Platform Kernel menyediakan layanan umum seperti:

- Governance
- Scope
- IAM
- RBAC
- Audit
- Data
- Workflow
- Notification
- API
- Event
- File Storage
- Search
- Integration
- Observability
- Security
- Deployment
- Master & Reference Data (MDM)

---

# Struktur Repository

```text
README.md
SSOT-INDEX.md
SSOT-ROADMAP.md
SSOT-DEPENDENCY-MATRIX.md
SSOT-CHANGELOG.md          (belum dibuat)
SSOT-GLOSSARY.md           (belum dibuat)
SSOT-MDM-01/02/03.md        (root — lihat catatan di bawah)
SSOT-SDK-01..05.md          (root — lihat catatan di bawah)

00-Governance/              (SSOT-GOV-01 s.d. GOV-06)
01-Scope/
02-IAM/
03-RBAC/                   (termasuk SSOT-MENU-01 — Dynamic Menu, karena bergantung langsung pada RBAC & Scope dan tidak punya domain sendiri di SSOT-INDEX)
04-Audit/
05-Data/
06-Workflow/
07-Notification/
08-API/
09-Event/
10-File/
11-Search/
12-Integration/
13-Observability/          (SSOT-OBS-01 s.d. OBS-11)
14-Security/                (SSOT-SEC-01, SEC-02, dan DEPLOY-SEC-01 — lihat catatan di bawah)
15-Deployment/              (SSOT-DEPLOY-01 s.d. DEPLOY-05)
16-Testing/                 (belum ada dokumen)
17-Implementation/         (dokumen stack & coding standard: STACK, DEV, CODE, MYSQL, IMPLEMENTATION — tidak disebut eksplisit di versi awal README ini)
18-UI/                      (design system frontend: master.css — tidak disebut eksplisit di versi awal README ini)
19-Modules/                 (belum ada dokumen — modul bisnis belum dibangun)
```

Catatan: struktur di atas adalah hasil reorganisasi 2026-07-04. Sebelumnya seluruh file berada flat di root `ssot/`, tidak sesuai struktur folder yang dideskripsikan di sini. Folder `17-Implementation/` dan `18-UI/` ditambahkan karena ada dokumen yang tidak masuk kategori domain manapun (panduan stack/coding, dan design system CSS).

Catatan tambahan (2026-07-05): dua domain kernel baru ditambahkan — **Master & Reference Data (MDM)** dan **Platform SDK** — tetapi dokumennya (`SSOT-MDM-01/02/03.md`, `SSOT-SDK-01.md` s.d. `SDK-05.md`) saat ini masih berada di root `ssot/`, belum dipindahkan ke folder bernomor seperti domain lain. Ini adalah inkonsistensi struktural yang belum diperbaiki — pertimbangkan membuat `20-MDM/` dan `21-SDK/` (atau nomor lain yang sesuai) pada reorganisasi berikutnya.

Catatan lain: `DEPLOY-SEC-01.md` berada di `14-Security/` (dipindahkan dari `15-Deployment/` pada 2026-07-05) meski judul dokumennya sendiri "Deployment & UAT Manual", dan namanya masih satu-satunya file di seluruh repository yang tidak memakai prefix `SSOT-`.

---

# Domain Kernel

| Domain | Status |
|---|---|
| Governance | ✅ |
| Scope | ✅ |
| IAM | ✅ |
| RBAC | ✅ |
| Audit | ✅ |
| Data | ✅ |
| Workflow | ✅ |
| Notification | ✅ |
| API | ✅ |
| Event | ✅ |
| File Storage | ✅ |
| Search | ✅ |
| Integration | ✅ |
| Observability | ✅ |
| Security | ✅ |
| Deployment | ✅ |
| Master & Reference Data (MDM) | ✅ |
| Testing | 🚧 |

Catatan: "Platform SDK" (SSOT-SDK-01 s.d. SDK-05, status ✅) tidak dimasukkan ke tabel ini karena secara arsitektur berada satu layer di atas Platform Kernel (lihat "Arsitektur Tingkat Tinggi"), bukan bagian dari kernel itu sendiri.

---

# Urutan Membaca Dokumen

1. README.md
2. SSOT-INDEX.md
3. SSOT-ROADMAP.md
4. Governance
5. Scope
6. IAM
7. RBAC
8. Audit
9. Data
10. Workflow
11. Notification
12. API
13. Event
14. File
15. Search
16. Integration
17. Observability
18. Security
19. Deployment
20. Platform SDK
21. Master & Reference Data (MDM)

---

# Aturan Pengembangan

Semua modul wajib:

- menggunakan Scope
- menggunakan RBAC
- menggunakan Audit Trail
- menggunakan Repository Pattern
- menggunakan Event bila ada perubahan domain
- mengikuti standar API
- mematuhi workflow jika proses membutuhkan approval
- mengikuti kebijakan keamanan dan logging

---

# Prinsip Coding

- Tidak ada business logic di Controller.
- Tidak ada SQL langsung di Controller.
- Gunakan Repository dan Service Layer.
- Gunakan Dependency Injection.
- Gunakan Interface untuk komponen inti.
- Hindari hardcoded configuration.
- Semua perubahan penting menghasilkan audit dan event.

---

# Definition of Done

Sebuah fitur dianggap selesai apabila:

- Database migration selesai
- Seeder tersedia (bila diperlukan)
- Permission selesai
- Workflow selesai (bila diperlukan)
- API selesai
- Event selesai
- Audit selesai
- UAT lulus
- Dokumentasi diperbarui

---

# Dokumen Master

- SSOT-INDEX.md
- SSOT-ROADMAP.md
- SSOT-CHANGELOG.md
- SSOT-GLOSSARY.md
- SSOT-DEPENDENCY-MATRIX.md
- SSOT-IMPLEMENTATION-ORDER.md
- SSOT-QUALITY-GATE.md
- SSOT-DECISIONS.md

---

# Cara Menggunakan Repository

1. Pahami README.
2. Cari dokumen pada SSOT-INDEX.
3. Ikuti dependency yang ditentukan.
4. Implementasikan sesuai standar.
5. Lakukan UAT.
6. Perbarui dokumentasi bila ada perubahan.

---

# Prinsip Perubahan

Tidak diperbolehkan mengubah implementasi yang bertentangan dengan SSOT tanpa memperbarui SSOT dan mendokumentasikan keputusan arsitektur.

---

# Tujuan Akhir

Repository ini menjadi referensi resmi untuk membangun platform enterprise yang:

- konsisten
- aman
- mudah dipelihara
- siap diskalakan
- siap mendukung berbagai domain bisnis
- siap berkembang dari Modular Monolith menuju Microservice bila diperlukan
