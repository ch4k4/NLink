# Riset Rebuild Modul WoundCare Full-Isolated

Tanggal: 2026-07-07  
Target: CRM Medis / WoundCare nurse-led  
Status: Rekomendasi arsitektur sebelum implementasi

## 1. Jawaban Singkat

Bisa dibuat ulang sebagai modul WoundCare full-isolated, dan secara arsitektur itu lebih bersih untuk model nurse-led. Namun pendekatan terbaik bukan memindahkan semuanya sekaligus, melainkan rebuild bertahap dengan anti-corruption layer dari Homecare lama.

Rekomendasi: lanjutkan ke desain ulang WoundCare sebagai bounded context sendiri, dengan WoundCare memiliki scheduling, visit lifecycle, EVV, clinical documentation, outcome, episode, dan portal projection sendiri. Homecare umum tetap ada untuk layanan non-woundcare.

## 2. Kondisi Saat Ini

WoundCare saat ini masih hybrid:

- `WoundCare` sudah punya domain assessment, dressing log, neuropathy, episode, photo relation, dan clinical scoring.
- `Homecare` masih memegang jadwal, lifecycle kunjungan, EVV, vitals, procedure doc, outcome, dan complete visit.
- `WoundCareWebController` masih menerima `HomecareService`.
- `WoundCareRepository::visitInfo()` masih membaca `homecare_visits`.
- UI flow nurse-led masih memakai URL Homecare untuk beberapa tahap inti:
  - `/homecare/new`
  - `/homecare`
  - `/homecare/{id}`
  - `/homecare/{id}/verify`
  - `/homecare/{id}/vitals`
  - `/homecare/{id}/procedure`
  - `/homecare/{id}/outcome`

Implikasi:

- Secara user journey sudah bisa nurse-led.
- Secara module boundary belum isolated.
- Risiko regresi muncul setiap kali Homecare umum berubah.
- Konsep dokter masih mudah bocor dari Homecare/Encounter lama.

## 3. Definisi Full-Isolated

Full-isolated bukan berarti tidak memakai kernel platform. Modul tetap memakai layanan bersama berikut:

- IAM untuk login dan identity.
- RBAC untuk permission.
- Scope untuk tenant, organization, dan clinic.
- Audit untuk jejak aksi.
- File service untuk foto luka.
- Notification untuk notifikasi pasien/staf.
- Event bus untuk integrasi asynchronous.
- Patient master sebagai referensi pasien.
- Nurse profile sebagai referensi perawat.
- Encounter/EMR sebagai downstream clinical record bila diperlukan.

Full-isolated berarti WoundCare tidak lagi bergantung pada Homecare sebagai owner proses bisnis WoundCare.

## 4. Boundary Modul Baru

### 4.1 WoundCare Harus Memiliki

WoundCare module owns:

- Intake WoundCare.
- Eligibility screening.
- WoundCare visit scheduling.
- Nurse assignment.
- Visit lifecycle.
- EVV / location verification.
- Vitals untuk visit woundcare.
- Wound assessment.
- Neuropathy and vascular assessment.
- Procedure and dressing documentation.
- Consumables used during woundcare.
- Outcome visit.
- Wound episode.
- Patient portal projection untuk woundcare.
- Nurse-led discharge/healed flow.

### 4.2 WoundCare Tidak Memiliki

WoundCare should not own:

- Master patient identity.
- Global user account.
- Global nurse profile.
- Billing core.
- General homecare visits.
- General encounter lifecycle outside WoundCare.
- Generic document storage.

## 5. Target Data Model

### 5.1 Core Tables Baru

Gunakan prefix `woundcare_` untuk semua proses milik modul.

```text
woundcare_requests
woundcare_leads
woundcare_visits
woundcare_visit_events
woundcare_visit_verifications
woundcare_vitals
woundcare_episodes
woundcare_assessments
woundcare_assessment_photos
woundcare_neuropathy_assessments
woundcare_dressing_logs
woundcare_procedure_docs
woundcare_procedure_consumables
woundcare_visit_outcomes
woundcare_followups
woundcare_portal_snapshots
```

### 5.2 Referensi Eksternal yang Tetap Boleh

```text
patients.id
patient_profiles.patient_id
nurse_profiles.id
users.id
tenants.id
organizations.id
clinics.id
documents.id
encounters.id (optional downstream)
```

### 5.3 Field Penting `woundcare_visits`

```text
id
uuid
tenant_id
organization_id
clinic_id
patient_id
nurse_id
request_id
lead_id
episode_id
visit_number
address_line
address_notes
latitude
longitude
scheduled_start
scheduled_end
lifecycle_status
urgency
purpose
notes
encounter_id nullable
created_by
created_at
updated_at
deleted_at
```

Tidak ada `doctor_id` dan tidak ada `supervising_doctor_id` di `woundcare_visits`.

Jika butuh eskalasi klinis, gunakan tabel terpisah:

```text
woundcare_escalations
```

Dengan target eskalasi berupa `team`, `hospital`, `external_referral`, bukan dokter sebagai dependency lifecycle.

## 6. Lifecycle Target

### 6.1 Visit Lifecycle

```text
requested
screening
eligible
scheduled
assigned
en_route
arrived
in_progress
documented
outcome_recorded
completed
cancelled
no_access
```

Catatan:

- `doctor_review` tidak menjadi status utama.
- Eskalasi menjadi side flow, bukan happy path.
- `completed` berarti visit selesai, bukan episode selesai.

### 6.2 Episode Lifecycle

```text
active
monitoring
healing
healed_proposed
healed
referred
closed
```

Catatan:

- `healed_proposed` opsional untuk internal QA nurse-led.
- `healed` bisa dilakukan tanpa dokter bila kebijakan klinik mengizinkan.
- `referred` digunakan bila kondisi butuh layanan di luar scope homecare woundcare.

## 7. UI Target

Semua halaman WoundCare berada di namespace WoundCare:

| Kebutuhan | URL target |
|---|---|
| Dashboard WoundCare | `/woundcare` |
| Intake request | `/woundcare/requests/new` |
| Request list | `/woundcare/requests` |
| Screening lead | `/woundcare/leads/{id}` |
| Schedule visit | `/woundcare/visits/new` |
| Visit board | `/woundcare/visits` |
| Visit detail | `/woundcare/visits/{id}` |
| EVV | `/woundcare/visits/{id}/verify` |
| Vitals | `/woundcare/visits/{id}/vitals` |
| Assessment | `/woundcare/visits/{id}/assessment` |
| Procedure | `/woundcare/visits/{id}/procedure` |
| Outcome | `/woundcare/visits/{id}/outcome` |
| Complete visit | `/woundcare/visits/{id}/complete` |
| Episode list | `/woundcare/episodes` |
| Episode detail | `/woundcare/episodes/{id}` |
| Patient portal woundcare | `/portal/woundcare` |
| Patient wound timeline | `/portal/woundcare/timeline` |

Legacy URLs can redirect temporarily:

```text
/homecare/{id}/procedure -> /woundcare/visits/{id}/procedure
/homecare/{id}/outcome   -> /woundcare/visits/{id}/outcome
/homecare/{id}/verify    -> /woundcare/visits/{id}/verify
```

But these redirects should be removed after migration.

## 8. Application Services Target

```text
WoundCareRequestService
WoundCareLeadService
WoundCareVisitService
WoundCareAssessmentService
WoundCareProcedureService
WoundCareOutcomeService
WoundCareEpisodeService
WoundCarePortalService
```

Do not create one large `WoundCareService` for everything. The current service is already broad; full isolation is the chance to split by use-case boundary.

## 9. Event Model

Recommended events:

```text
WoundCareRequestSubmitted
WoundCareLeadScreened
WoundCareVisitScheduled
WoundCareNurseAssigned
WoundCareVisitDeparted
WoundCareVisitArrived
WoundCareAssessmentRecorded
WoundCareProcedureDocumented
WoundCareOutcomeRecorded
WoundCareEpisodeUpdated
WoundCareEpisodeHealed
WoundCareVisitCompleted
WoundCareEscalationFlagged
```

Downstream subscribers:

- Notification sends patient updates.
- EMR creates or updates encounter summary.
- Billing optionally generates charge.
- Audit records all mutation events.
- Portal snapshot refreshes patient-visible timeline.

## 10. Permission Model

Suggested permissions:

```text
woundcare.request.read.clinic
woundcare.request.write.clinic
woundcare.lead.read.clinic
woundcare.lead.write.clinic
woundcare.visit.read.clinic
woundcare.visit.write.clinic
woundcare.visit.read.own
woundcare.visit.write.own
woundcare.assessment.read.clinic
woundcare.assessment.write.clinic
woundcare.assessment.write.own
woundcare.procedure.write.own
woundcare.outcome.write.own
woundcare.episode.read.clinic
woundcare.episode.write.clinic
woundcare.portal.read.own
```

Nurse-led rule:

- Perawat assigned boleh mutate visit sendiri.
- Koordinator boleh schedule dan assign.
- Admin boleh monitoring.
- Dokter tidak menjadi role wajib.

## 11. Integrasi Encounter / EMR

Ada dua opsi:

### Opsi A: WoundCare Visit sebagai clinical visit mandiri

WoundCare membuat `woundcare_visits` sebagai source of truth dan hanya membuat `encounters` saat butuh sinkronisasi EMR.

Kelebihan:

- Boundary paling bersih.
- Tidak dipaksa doctor-centric.
- Nurse-led lebih natural.

Kekurangan:

- Perlu mapping EMR/Encounter yang rapi.

### Opsi B: Encounter dibuat di awal untuk setiap WoundCare visit

WoundCare membuat `encounter_class = home_health` saat visit mulai.

Kelebihan:

- Data klinis mudah masuk rekam medis.
- Portal encounter bisa reuse.

Kekurangan:

- Harus menjaga `doctor_id` tetap nullable untuk `home_health`.
- Ada risiko domain Encounter kembali membawa asumsi dokter.

Rekomendasi: Opsi A untuk source of truth, dengan event-driven EMR sync.

## 12. Risiko Rebuild

| Risiko | Dampak | Mitigasi |
|---|---|---|
| Migrasi data dari `homecare_visits` | Data visit lama bisa kehilangan link | Buat migration map dan dual-read sementara |
| URL lama dipakai user | 404 setelah cutover | Redirect sementara dan warning deprecation |
| Portal pasien masih baca Homecare | Timeline tidak lengkap | Buat `WoundCarePortalService` |
| Billing/notification subscribe event lama | Notifikasi/tagihan tidak terkirim | Publish event kompatibel selama transisi |
| Permission belum lengkap | 403 di browser UAT | Seed permission dan role sebelum UAT |
| Encounter masih doctor-centric | Nurse-led pecah di visit start | Treat Encounter as downstream, not owner |

## 13. Strategi Migrasi

### Phase 0 - Freeze Contract

Output:

- Dokumen kontrak flow nurse-led.
- Data model target.
- Route target.
- Permission target.
- UAT target.

Tidak ada perubahan code besar.

### Phase 1 - Build Isolated Tables

Output:

- Migration `woundcare_*`.
- Repository baru.
- Service skeleton.
- Seed permissions.

Tidak mematikan Homecare lama.

### Phase 2 - Build Visit Flow Isolated

Output:

- `/woundcare/visits/new`
- `/woundcare/visits`
- `/woundcare/visits/{id}`
- depart, verify, arrive, complete.

Goal:

- WoundCare visit bisa hidup tanpa `homecare_visits`.

### Phase 3 - Move Clinical Documentation

Output:

- Vitals WoundCare.
- Procedure WoundCare.
- Outcome WoundCare.
- Assessment tied to `woundcare_visit_id`.

Goal:

- Tidak ada dependency ke `/homecare/{id}/procedure` dan `/homecare/{id}/outcome`.

### Phase 4 - Portal and Reports

Output:

- `/portal/woundcare`
- `/portal/woundcare/timeline`
- dashboard nurse-led.

Goal:

- Pasien melihat data dari WoundCare projection.

### Phase 5 - Migration and Cutover

Output:

- Data migrator dari `homecare_visits` WoundCare lama ke `woundcare_visits`.
- Redirect legacy URL.
- UAT browser full path.

Goal:

- New flow memakai isolated WoundCare.

### Phase 6 - Remove Compatibility

Output:

- Remove Homecare dependency from `WoundCareWebController`.
- Remove reads from `homecare_visits` in WoundCare repository.
- Remove legacy route redirects after approved period.

Goal:

- WoundCare benar-benar isolated.

## 14. Migration Mapping

| Existing | Target |
|---|---|
| `homecare_visits` where `service_type = wound_care` | `woundcare_visits` |
| `homecare_visit_verifications` | `woundcare_visit_verifications` |
| `homecare_vitals` or equivalent | `woundcare_vitals` |
| `homecare_procedure_docs` | `woundcare_procedure_docs` |
| `homecare_procedure_consumables` | `woundcare_procedure_consumables` |
| `homecare_visit_outcomes` | `woundcare_visit_outcomes` |
| `wound_assessments` | `woundcare_assessments` or keep with rename |
| `wound_assessment_photos` | `woundcare_assessment_photos` |
| `wound_episodes` | `woundcare_episodes` |

Recommendation:

- Rename old `wound_*` tables only if migration budget allows.
- If budget is tight, keep `wound_assessments` and `wound_episodes` first, but add `woundcare_visit_id`.
- Do not keep using `homecare_visits` as permanent key.

## 15. Acceptance Criteria Full-Isolated

WoundCare considered full-isolated only if:

- New WoundCare visit can be created without writing to `homecare_visits`.
- WoundCare visit lifecycle does not call `HomecareService`.
- WoundCare procedure and outcome do not use Homecare tables.
- `WoundCareWebController` does not inject `HomecareService`.
- WoundCare repository does not query `homecare_visits`.
- Portal woundcare reads WoundCare projections, not Homecare list.
- Browser UAT passes from request to healed without `doctor_id`.
- `doctor_id` is absent from WoundCare visit schema.

## 16. Recommendation

Build from ulang as full-isolated module, but do it as a strangler migration, not a hard rewrite.

Best next action:

1. Create `DESIGN_WOUNDCARE_FULL_ISOLATED.md` as implementation blueprint.
2. Create migrations for `woundcare_visits`, `woundcare_visit_events`, `woundcare_visit_verifications`, `woundcare_vitals`, `woundcare_procedure_docs`, and `woundcare_visit_outcomes`.
3. Add isolated routes under `/woundcare/visits`.
4. Keep old Homecare-backed flow until the new UAT path is green.
5. Run browser UAT against the new isolated path.
6. Remove Homecare compatibility after cutover.

Decision: recommended to proceed, because current hybrid design is already showing boundary pressure and repeated fixes around doctor optionality, permissions, and route ownership.

